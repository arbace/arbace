//line aot_arbace_repr_go_layout.ae:1
package aot_arbace_repr_go_layout

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_go_lit"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A_New() *A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_layout_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_layout_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_layout_A_const_1, A_arbace_repr_go_layout_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A_New() *A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_repr_go_layout_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_layout_A_const_8.GetRawRoot__O(), A_arbace_repr_go_layout_A_const_9) }















func A_arbace_repr_go_layout_private_QMARK__A_New() *A_arbace_repr_go_layout_private_QMARK__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_private_QMARK__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_repr_go_layout_private_QMARK__A) Ctor() {}
//line :17:1
func (t *A_arbace_repr_go_layout_private_QMARK__A) Invoke_O_O__O(self, k__0 any) any { var and__1927000168__auto____2 any; var root_20 any = A_arbace_repr_go_layout_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = k__0; if linked_21 == nil { and__1927000168__auto____2 = ifn_22.Invoke_O__O(arg_23) } else { and__1927000168__auto____2 = linked_21.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_20, arg_23) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_repr_go_layout_A_const_11.GetRawRoot__O(); var tmp2 any; var root_24 any = A_arbace_repr_go_layout_A_const_12.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = k__0; if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_24, arg_27) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_layout_iobj_QMARK__A_New() *A_arbace_repr_go_layout_iobj_QMARK__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_iobj_QMARK__A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_repr_go_layout_iobj_QMARK__A) Ctor() {}
//line :19:1
func (t *A_arbace_repr_go_layout_iobj_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.IObj_InstanceOf(x__0)).Ref() }

func A_arbace_repr_go_layout_deref_form_QMARK__A_New() *A_arbace_repr_go_layout_deref_form_QMARK__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_deref_form_QMARK__A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_repr_go_layout_deref_form_QMARK__A) Ctor() {}
//line :21:1
func (t *A_arbace_repr_go_layout_deref_form_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var root_28 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = x__0; if linked_29 == nil { and__1927000168__auto____2 = ifn_30.Invoke_O__O(arg_31) } else { and__1927000168__auto____2 = linked_29.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_28, arg_31) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 *lang.Keyword = A_arbace_repr_go_layout_A_const_14; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_layout_form_line_A_New() *A_arbace_repr_go_layout_form_line_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_form_line_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_repr_go_layout_form_line_A) Ctor() {}
//line :23:1
func (t *A_arbace_repr_go_layout_form_line_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var root_32 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_34 lang.IFn
	if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = x__0; if linked_33 == nil { tmp1 = ifn_34.Invoke_O__O(arg_35) } else { tmp1 = linked_33.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_32, arg_35) }
//line :26:1
	if jrt.J2g_Truth(tmp1) {
		return A_arbace_repr_go_layout_A_const_16.Invoke_O__O(x__0) } else {
//line :26:1
			var tmp2 any; var root_36 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_38 lang.IFn

			if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = x__0; if linked_37 == nil { tmp2 = ifn_38.Invoke_O__O(arg_39) } else { tmp2 = linked_37.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_36, arg_39) }
//line :26:1
			if jrt.J2g_Truth(tmp2) {

				var tmp3 *lang.Keyword = A_arbace_repr_go_layout_A_const_18; return tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else {
//line :26:1
					return nil
				}
		}
}



func A_arbace_repr_go_layout_note_BANG__A_New() *A_arbace_repr_go_layout_note_BANG__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_note_BANG__A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_repr_go_layout_note_BANG__A) Ctor() {}
//line :33:1
func (t *A_arbace_repr_go_layout_note_BANG__A) Invoke_O_O__O(self, k__0 any) any { if jrt.J2g_Truth(A_arbace_repr_go_layout_A_const_19.Get__O()) { var root_40 any = A_arbace_repr_go_layout_A_const_20.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = A_arbace_repr_go_layout_A_const_19.Get__O(); var arg_44 any = A_arbace_repr_go_layout_A_const_21.GetRawRoot__O(); var arg_45 any = k__0; var arg_46 any; var root_47 any = A_arbace_repr_go_layout_A_const_22.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_repr_go_layout_A_const_23.GetRawRoot__O(); var arg_51 any = A_arbace_repr_go_layout_A_const_24; if linked_48 == nil { arg_46 = ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { arg_46 = linked_48.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) }; if linked_41 == nil { return ifn_42.Invoke_O_O_O_O__O(arg_43, arg_44, arg_45, arg_46) } else { return linked_41.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_40, arg_43, arg_44, arg_45, arg_46) } } else { return nil } }



func A_arbace_repr_go_layout_prep_A_New() *A_arbace_repr_go_layout_prep_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_repr_go_layout_prep_A) Ctor() {}
//line :37:1
func (t *A_arbace_repr_go_layout_prep_A) Invoke_O_O_O__O(self, x__0, cursor__1 any) any {


	var tmp1 any; var or__1927000174__auto____3 any; var root_52 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_54 lang.IFn
	if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = x__0; if linked_53 == nil { or__1927000174__auto____3 = ifn_54.Invoke_O__O(arg_55) } else { or__1927000174__auto____3 = linked_53.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_52, arg_55) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_56 any = A_arbace_repr_go_layout_A_const_25.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = x__0; if linked_57 == nil { tmp1 = ifn_58.Invoke_O__O(arg_59) } else { tmp1 = linked_57.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_56, arg_59) } }
//line :40:1
	if jrt.J2g_Truth(tmp1) {

		var tmp2 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; if jrt.J2g_Truth(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0))) { return lang.Tuple_Create_O_O__IPersistentVector(x__0, cursor__1) } else { var lines_QMARK___3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_28); var m__4 any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); var vec__1839000017__5 any; var tmp3 any = A_arbace_repr_go_layout_prep_fn__1839000020_A_New_O_O_Z(cursor__1, x__0, lines_QMARK___3); var tmp4 *jrt.Class
			var fncls__199 /*line :42:1*/*jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000020_A_fn_class




			if fncls__199 == nil { var fncls__199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_repr_go_layout_prep_fn__1839000020_A_fn_class = fncls__199d; tmp4 = fncls__199d } else { tmp4 = fncls__199 }; vec__1839000017__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
//line :42:1
			var kids__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(0), nil); var cursor__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(1), nil); var breaks__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(2), nil); var apos__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(3), nil); var afull__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(4), nil); var x_SINGLEQUOTE___11 any; var tmp5 any; var root_200 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_202 lang.IFn
































			if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = x__0; if linked_201 == nil { tmp5 = ifn_202.Invoke_O__O(arg_203) } else { tmp5 = linked_201.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_200, arg_203) }; if jrt.J2g_Truth(tmp5) { var root_204 any = A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = A_arbace_repr_go_layout_A_const_49.GetRawRoot__O(); var arg_208 any = kids__6; if linked_205 == nil { x_SINGLEQUOTE___11 = ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { x_SINGLEQUOTE___11 = linked_205.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) } } else { x_SINGLEQUOTE___11 = kids__6 }
//line :42:1
			var m__12 any; var G__1839000034__12_ any = m__4; var G__1839000034__13_ any; var tmp6 any
			var and__1927000168__auto____13 bool = lines_QMARK___3

































			if and__1927000168__auto____13 { var root_209 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = breaks__8; if linked_210 == nil { tmp6 = ifn_211.Invoke_O__O(arg_212) } else { tmp6 = linked_210.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_209, arg_212) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____13).Ref() }
//line :76:1
			if jrt.J2g_Truth(tmp6) {
				var root_213 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = G__1839000034__12_; var arg_217 any = A_arbace_repr_go_layout_A_const_50; var arg_218 any = breaks__8; if linked_214 == nil { G__1839000034__13_ = ifn_215.Invoke_O_O_O__O(arg_216, arg_217, arg_218) } else { G__1839000034__13_ = linked_214.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_213, arg_216, arg_217, arg_218) } } else {
//line :76:1
					G__1839000034__13_ = G__1839000034__12_ }
//line :42:1
			var G__1839000034__14_ any; var tmp7 any; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_51)



































			if and__1927000168__auto____14 { var root_219 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = apos__9; if linked_220 == nil { tmp7 = ifn_221.Invoke_O__O(arg_222) } else { tmp7 = linked_220.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_219, arg_222) } } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }
//line :76:1
			if jrt.J2g_Truth(tmp7) {

				var root_223 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = G__1839000034__13_; var arg_227 any = A_arbace_repr_go_layout_A_const_52; var arg_228 any = apos__9; if linked_224 == nil { G__1839000034__14_ = ifn_225.Invoke_O_O_O__O(arg_226, arg_227, arg_228) } else { G__1839000034__14_ = linked_224.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_223, arg_226, arg_227, arg_228) } } else {
//line :76:1
					G__1839000034__14_ = G__1839000034__13_ }; if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_51) {


						var root_229 any = A_arbace_repr_go_layout_A_const_53.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = G__1839000034__14_; var arg_233 any; var root_234 any = A_arbace_repr_go_layout_A_const_54.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_238 any; var root_240 any = A_arbace_repr_go_layout_A_const_55.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any; var tmp8 any = A_arbace_repr_go_layout_prep_fn__1839000036_A_New(); var tmp9 *jrt.Class; var fncls__252 *jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000036_A_fn_class; if fncls__252 == nil { var fncls__252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_repr_go_layout_prep_fn__1839000036_A_fn_class = fncls__252d; tmp9 = fncls__252d } else { tmp9 = fncls__252 }; arg_243 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); if linked_241 == nil { arg_238 = ifn_242.Invoke_O__O(arg_243) } else { arg_238 = linked_241.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_240, arg_243) }; var arg_239 any = afull__10; if linked_235 == nil { arg_233 = ifn_236.Invoke_O_O_O__O(arg_237, arg_238, arg_239) } else { arg_233 = linked_235.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_234, arg_237, arg_238, arg_239) }; if linked_230 == nil { m__12 = ifn_231.Invoke_O_O__O(arg_232, arg_233) } else { m__12 = linked_230.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_229, arg_232, arg_233) } } else {
//line :76:1
							m__12 = G__1839000034__14_ }
//line :42:1
			var tmp10 any; var root_253 any = A_arbace_repr_go_layout_A_const_56.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_255 lang.IFn





































			if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = x_SINGLEQUOTE___11; var arg_257 any = m__12; if linked_254 == nil { tmp10 = ifn_255.Invoke_O_O__O(arg_256, arg_257) } else { tmp10 = linked_254.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_253, arg_256, arg_257) }
//line :42:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp10, cursor__7) } } else {
//line :40:1
				if A_arbace_repr_go_layout_A_const_41 != nil { return lang.Tuple_Create_O_O__IPersistentVector(x__0, cursor__1) } else { return nil
				}
			}
}



func A_arbace_repr_go_layout_prep_fn__1839000020_A_New_O_O_Z(p0, p1 any, p2 bool) *A_arbace_repr_go_layout_prep_fn__1839000020_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000020_A{}; t.Ctor_O_O_Z(p0, p1, p2); return t }
//line :47:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_A) Ctor_O_O_Z(c__cursor, c__x any, c__lines_QMARK_ bool) { t.F_cursor = c__cursor; t.F_x = c__x; t.F_lines_QMARK_ = c__lines_QMARK_ }
//line :47:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var xs__2 any; var root_60 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var t_ any = t.F_x; t.F_x = nil; arg_63 = t_; if linked_61 == nil { xs__2 = ifn_62.Invoke_O__O(arg_63) } else { xs__2 = linked_61.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_60, arg_63) }; var cursor__3 any; var t__2 any = t.F_cursor; t.F_cursor = nil; cursor__3 = t__2; var acc__4 any = lang.PersistentVector_EMPTY.Ref(); var breaks__5 any = lang.PersistentVector_EMPTY.Ref(); var apos__6 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_30.GetRawRoot__O()).Invoke__O(); var afull__7 any = lang.PersistentArrayMap_EMPTY.Ref(); L1: for { var temp__1927000408__auto____8 any; var root_67 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_69 lang.IFn
											if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = xs__2; if linked_68 == nil { temp__1927000408__auto____8 = ifn_69.Invoke_O__O(arg_70) } else { temp__1927000408__auto____8 = linked_68.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_67, arg_70) }; if jrt.J2g_Truth(temp__1927000408__auto____8) { var c__9 any = temp__1927000408__auto____8; var l__10 any; var root_71 any = A_arbace_repr_go_layout_A_const_32.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, A_arbace_repr_go_layout_form_line_A_fn_class); var ifn_73 lang.IFn
												if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = c__9; if linked_72 == nil { l__10 = ifn_73.Invoke_O__O(arg_74) } else { l__10 = linked_72.(*A_arbace_repr_go_layout_form_line_A).Invoke_O_O__O(root_71, arg_74) }
//line :48:1
		var cursor0__11 any = cursor__3; var brk__12 any
		var and__1927000168__auto____12 any = l__10

		if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp1 bool; var na_75 any = l__10; var na_76 any = cursor__3; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_75); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_76) }; tmp2 = tmp3; if tmp2 { var n0_77 int64 = jrt.NN(jrt.Long_Cast(na_75)).LongValue__J(); var n1_78 int64 = jrt.NN(jrt.Long_Cast(na_76)).LongValue__J(); tmp1 = n0_77 > n1_78 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_75); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_76) }; tmp4 = tmp5; if tmp4 { var n0_77_2 float64 = jrt.NN(jrt.Double_Cast(na_75)).DoubleValue__D(); var n1_78_2 float64 = jrt.NN(jrt.Double_Cast(na_76)).DoubleValue__D(); tmp1 = n1_78_2 < n0_77_2 } else { tmp1 = lang.Numbers_Gt_O_O__Z_NoInit(na_75, na_76) } }; brk__12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() } else { brk__12 = and__1927000168__auto____12 }
//line :48:1
		var c__13 any; var tmp6 any; var root_80 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_82 lang.IFn




		if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = c__9; if linked_81 == nil { tmp6 = ifn_82.Invoke_O__O(arg_83) } else { tmp6 = linked_81.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_80, arg_83) }
//line :52:1
		if jrt.J2g_Truth(tmp6) {
			var root_84 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = c__9; var arg_88 any = A_arbace_repr_go_layout_A_const_34; var arg_89 any = brk__12; if linked_85 == nil { c__13 = ifn_86.Invoke_O_O_O__O(arg_87, arg_88, arg_89) } else { c__13 = linked_85.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_84, arg_87, arg_88, arg_89) } } else {
//line :52:1
				var tmp7 any; var root_90 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_92 lang.IFn

				if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = c__9; if linked_91 == nil { tmp7 = ifn_92.Invoke_O__O(arg_93) } else { tmp7 = linked_91.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_90, arg_93) }
//line :52:1
				if jrt.J2g_Truth(tmp7) {


					var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_35.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_New_O_O_O_O_Z(l__10, brk__12, cursor__3, c__9, t.F_lines_QMARK_); var tmp10 *jrt.Class; var fncls__146 *jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_fn_class; if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_fn_class = fncls__146d; tmp10 = fncls__146d } else { tmp10 = fncls__146 }; c__13 = tmp8.Invoke_O_O__O(c__9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)) } else {
//line :52:1
						if A_arbace_repr_go_layout_A_const_41 != nil { c__13 = c__9 } else { c__13 = nil } } }
//line :48:1
		var cursor__14 any













		if jrt.J2g_Truth(brk__12) { cursor__14 = l__10 } else { cursor__14 = cursor__3 }
//line :48:1
		var vec__1839000021__15 any; var root_147 any = A_arbace_repr_go_layout_A_const_42.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, A_arbace_repr_go_layout_prep_A_fn_class); var ifn_149 lang.IFn














		if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = c__13; var arg_151 any = cursor__14; if linked_148 == nil { vec__1839000021__15 = ifn_149.Invoke_O_O__O(arg_150, arg_151) } else { vec__1839000021__15 = linked_148.(*A_arbace_repr_go_layout_prep_A).Invoke_O_O_O__O(root_147, arg_150, arg_151) }
//line :48:1
		var c__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000021__15, lang.RT_IntCast_J__I_NoInit(0), nil); var cursor__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000021__15, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp11 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp12 any; var root_152 any = A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_154 lang.IFn















		if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = xs__2; if linked_153 == nil { tmp12 = ifn_154.Invoke_O__O(arg_155) } else { tmp12 = linked_153.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_152, arg_155) }; var tmp13 any = tmp12; var tmp14 any; var root_156 any = A_arbace_repr_go_layout_A_const_8.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = acc__4; var arg_160 any = c__16; if linked_157 == nil { tmp14 = ifn_158.Invoke_O_O__O(arg_159, arg_160) } else { tmp14 = linked_157.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_156, arg_159, arg_160) }; var tmp15 any = tmp14; var tmp16 any; var tmp17 any
		var and__1927000168__auto____18 any = brk__12

		if jrt.J2g_Truth(and__1927000168__auto____18) { var root_161 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = c__16; if linked_162 == nil { tmp17 = ifn_163.Invoke_O__O(arg_164) } else { tmp17 = linked_162.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_161, arg_164) } } else { tmp17 = and__1927000168__auto____18 }; if jrt.J2g_Truth(tmp17) { var root_165 any = A_arbace_repr_go_layout_A_const_8.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = breaks__5; var arg_169 any; var tmp18 jrt.Number_I; var na_170 any = cursor0__11; if jrt.Long_InstanceOf(na_170) { var n0_171 int64 = jrt.NN(jrt.Long_Cast(na_170)).LongValue__J(); if n0_171 == 9223372036854775807 { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_170) } else { tmp18 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_171 + 1)) } } else { if jrt.Double_InstanceOf(na_170) { var n0_171_2 float64 = jrt.NN(jrt.Double_Cast(na_170)).DoubleValue__D(); tmp18 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_171_2 + 1.0)) } else { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_170) } }; if lang.Util_Equiv_O_O__Z_NoInit(l__10, tmp18) { arg_169 = jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref() } else { arg_169 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref(), l__10) }; if linked_166 == nil { tmp16 = ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { tmp16 = linked_166.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_165, arg_168, arg_169) } } else { tmp16 = breaks__5 }
//line :64:1
		var tmp19 any = tmp16; var tmp20 any; var tmp21 any; var and__1927000168__auto____18_2 any; var root_172 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_174 lang.IFn



		if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = c__16; if linked_173 == nil { and__1927000168__auto____18_2 = ifn_174.Invoke_O__O(arg_175) } else { and__1927000168__auto____18_2 = linked_173.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_172, arg_175) }; if jrt.J2g_Truth(and__1927000168__auto____18_2) { tmp21 = A_arbace_repr_go_layout_A_const_44.Invoke_O__O(c__16) } else { tmp21 = and__1927000168__auto____18_2 }; if jrt.J2g_Truth(tmp21) { var root_176 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = apos__6; var arg_180 any = jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref(); var arg_181 any = A_arbace_repr_go_layout_A_const_44.Invoke_O__O(c__16); if linked_177 == nil { tmp20 = ifn_178.Invoke_O_O_O__O(arg_179, arg_180, arg_181) } else { tmp20 = linked_177.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_176, arg_179, arg_180, arg_181) } } else { tmp20 = apos__6 }
//line :64:1
		var tmp22 any = tmp20; var tmp23 any; var tmp24 any; var root_182 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_184 lang.IFn





		if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = c__16; if linked_183 == nil { tmp24 = ifn_184.Invoke_O__O(arg_185) } else { tmp24 = linked_183.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_182, arg_185) }; if jrt.J2g_Truth(tmp24) {
			var root_186 any = A_arbace_repr_go_layout_A_const_45.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any; var tmp25 any = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_New_J_O(i__1, c__16); var tmp26 *jrt.Class; var fncls__198 *jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_fn_class; if fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_fn_class = fncls__198d; tmp26 = fncls__198d } else { tmp26 = fncls__198 }; arg_189 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); var arg_190 any = afull__7; var arg_191 any = A_arbace_repr_go_layout_A_const_47; if linked_187 == nil { tmp23 = ifn_188.Invoke_O_O_O__O(arg_189, arg_190, arg_191) } else { tmp23 = linked_187.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_186, arg_189, arg_190, arg_191) } } else {
//line :70:1
				tmp23 = afull__7 }
//line :64:1
		i__1, xs__2, cursor__3, acc__4, breaks__5, apos__6, afull__7 = tmp11, tmp13, cursor__17, tmp15, tmp19, tmp22, tmp23; continue L1 } else {
//line :48:1
			return lang.Tuple_Create_O_O_O_O_O__IPersistentVector(acc__4, cursor__3, breaks__5, apos__6, afull__7) } } }; /*line :47:1*/panic("j2g: unreachable") }







func A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_New_O_O_O_O_Z(p0, p1, p2, p3 any, p4 bool) *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A{}; t.Ctor_O_O_O_O_Z(p0, p1, p2, p3, p4); return t }
//line :55:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A) Ctor_O_O_O_O_Z(c__l, c__brk, c__cursor, c__c any, c__lines_QMARK_ bool) { t.F_l = c__l; t.F_brk = c__brk; t.F_cursor = c__cursor; t.F_c = c__c; t.F_lines_QMARK_ = c__lines_QMARK_ }
//line :55:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A) Invoke_O_O__O(self, cm__1 any) any { var G__1839000025__2_ any; var root_99 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_101 lang.IFn; if
														linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = cm__1; var arg_103 any = A_arbace_repr_go_layout_A_const_36; var arg_104 any = t.F_brk; if linked_100 == nil { G__1839000025__2_ = ifn_101.Invoke_O_O_O__O(arg_102, arg_103, arg_104) } else { G__1839000025__2_ = linked_100.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_99, arg_102, arg_103, arg_104) }; var G__1839000025__3_ any; var tmp1 any; var and__1927000168__auto____3 bool = /*line :55:1*/t.F_lines_QMARK_; if and__1927000168__auto____3 {

		var and__1927000168__auto____4 any = t.F_brk; if jrt.J2g_Truth(and__1927000168__auto____4) { var or__1927000174__auto____5 any; var root_105 any = A_arbace_repr_go_layout_A_const_37.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any; var root_109 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = t.F_c; if linked_110 == nil { arg_108 = ifn_111.Invoke_O__O(arg_112) } else { arg_108 = linked_110.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_109, arg_112) }; if linked_106 == nil { or__1927000174__auto____5 = ifn_107.Invoke_O__O(arg_108) } else { or__1927000174__auto____5 = linked_106.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_105, arg_108) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { var root_113 any = A_arbace_repr_go_layout_A_const_38.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, A_arbace_repr_go_layout_deref_form_QMARK__A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = t.F_c; if linked_114 == nil { tmp1 = ifn_115.Invoke_O__O(arg_116) } else { tmp1 = linked_114.(*A_arbace_repr_go_layout_deref_form_QMARK__A).Invoke_O_O__O(root_113, arg_116) } } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if /*line :56:1*/ jrt.J2g_Truth(tmp1) {

			var root_117 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = G__1839000025__2_; var arg_121 any = A_arbace_repr_go_layout_A_const_16; var arg_122 any = t.F_l; if linked_118 == nil { G__1839000025__3_ = ifn_119.Invoke_O_O_O__O(arg_120, arg_121, arg_122) } else { G__1839000025__3_ = linked_118.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_117, arg_120, arg_121, arg_122) } } else {
//line :56:1
				G__1839000025__3_ = G__1839000025__2_ }; var tmp2 any; var and__1927000168__auto____4_2 bool = t.F_lines_QMARK_; if and__1927000168__auto____4_2 {


					var and__1927000168__auto____5 any = t.F_l; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_123 any = A_arbace_repr_go_layout_A_const_37.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = t.F_brk; if linked_124 == nil { and__1927000168__auto____6 = ifn_125.Invoke_O__O(arg_126) } else { and__1927000168__auto____6 = linked_124.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_123, arg_126) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 bool; var na_127 any = t.F_l; var na_128 any = t.F_cursor; var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_127); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_128) }; tmp3 = tmp4; if tmp3 { var n0_129 int64 = jrt.NN(jrt.Long_Cast(na_127)).LongValue__J(); var n1_130 int64 = jrt.NN(jrt.Long_Cast(na_128)).LongValue__J(); and__1927000168__auto____7 = n0_129 < n1_130 } else { var tmp5 bool; var tmp6 bool; tmp6 = jrt.Double_InstanceOf(na_127); if tmp6 { tmp6 = jrt.Double_InstanceOf(na_128) }; tmp5 = tmp6; if tmp5 { var n0_129_2 float64 = jrt.NN(jrt.Double_Cast(na_127)).DoubleValue__D(); var n1_130_2 float64 = jrt.NN(jrt.Double_Cast(na_128)).DoubleValue__D(); and__1927000168__auto____7 = n0_129_2 < n1_130_2 } else { and__1927000168__auto____7 = lang.Numbers_Lt_O_O__Z_NoInit(na_127, na_128) } }; if and__1927000168__auto____7 { var root_132 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = t.F_c; if linked_133 == nil { tmp2 = ifn_134.Invoke_O__O(arg_135) } else { tmp2 = linked_133.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_132, arg_135) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp2 = and__1927000168__auto____6 } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }; if /*line :56:1*/ jrt.J2g_Truth(tmp2) { var cm__4 any = G__1839000025__3_; var root_142 any = A_arbace_repr_go_layout_A_const_39.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, A_arbace_repr_go_layout_note_BANG__A_fn_class); var ifn_144 lang.IFn



						if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = A_arbace_repr_go_layout_A_const_40; if linked_143 == nil { ifn_144.Invoke_O__O(arg_145) } else { linked_143.(*A_arbace_repr_go_layout_note_BANG__A).Invoke_O_O__O(root_142, arg_145) }; var root_136 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = cm__4; var arg_140 any = A_arbace_repr_go_layout_A_const_16; var arg_141 any = t.F_l; if linked_137 == nil { return ifn_138.Invoke_O_O_O__O(arg_139, arg_140, arg_141) } else { return linked_137.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_136, arg_139, arg_140, arg_141) } } else {
//line :56:1
							return G__1839000025__3_ } }














func A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_New_J_O(p0 int64, p1 any) *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A{}; t.Ctor_J_O(p0, p1); return t }
//line :71:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A) Ctor_J_O(c__i int64, c__c any) { t.F_i = c__i; t.F_c = c__c }
//line :71:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A) Invoke_O_O_O__O(self, af__1, p__1839000027__2 any) any { var vec__1839000029__3 any = p__1839000027__2; var k__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000029__3, lang.RT_IntCast_J__I_NoInit(0), nil); var mk__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000029__3, lang.RT_IntCast_J__I_NoInit(1), nil); var temp__1927000408__auto____6 any = lang.RT_Get_O_O__O_NoInit(t.F_c, k__4); if jrt.J2g_Truth(temp__1927000408__auto____6) { var v__7 any = temp__1927000408__auto____6; var root_192 any = A_arbace_repr_go_layout_A_const_46.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = af__1; var arg_196 any = lang.Tuple_Create_O_O__IPersistentVector(mk__5, jrt.Long_ValueOf_J__Long_NoInit(t.F_i).Ref()); var arg_197 any = v__7; if linked_193 == nil { return ifn_194.Invoke_O_O_O__O(arg_195, arg_196, arg_197) } else { return linked_193.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_192, arg_195, arg_196, arg_197) } } else { return af__1 } }







func A_arbace_repr_go_layout_prep_fn__1839000036_A_New() *A_arbace_repr_go_layout_prep_fn__1839000036_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000036_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000036_A) Ctor() {}
//line :79:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000036_A) Invoke_O_O__O(self, p__1839000035__1 any) any { var vec__1839000037__2 any = p__1839000035__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000037__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000037__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_244 any = A_arbace_repr_go_layout_A_const_54.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_30.GetRawRoot__O()).Invoke__O(); var arg_248 any = v__4; if linked_245 == nil { tmp1 = ifn_246.Invoke_O_O__O(arg_247, arg_248) } else { tmp1 = linked_245.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_244, arg_247, arg_248) }; return lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp1) }



func A_arbace_repr_go_layout_prepare_A_New() *A_arbace_repr_go_layout_prepare_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prepare_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repr_go_layout_prepare_A) Ctor() {}
//line :83:1
func (t *A_arbace_repr_go_layout_prepare_A) Invoke_O_O__O(self, forms__0 any) any { { var fs__2 any = forms__0; var cursor__3 any = lang.RT_Box_J__Number_NoInit(1); var acc__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var temp__1927000408__auto____5 any; var root_258 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_260 lang.IFn



	if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = fs__2; if linked_259 == nil { temp__1927000408__auto____5 = ifn_260.Invoke_O__O(arg_261) } else { temp__1927000408__auto____5 = linked_259.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_258, arg_261) }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var f__6 any = temp__1927000408__auto____5; var l__7 any; var root_262 any = A_arbace_repr_go_layout_A_const_32.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, A_arbace_repr_go_layout_form_line_A_fn_class); var ifn_264 lang.IFn
		if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = f__6; if linked_263 == nil { l__7 = ifn_264.Invoke_O__O(arg_265) } else { l__7 = linked_263.(*A_arbace_repr_go_layout_form_line_A).Invoke_O_O__O(root_262, arg_265) }
//line :87:1
		var brk__8 any
		var and__1927000168__auto____8 any = l__7
		if jrt.J2g_Truth(and__1927000168__auto____8) { var tmp1 bool; var na_266 any = l__7; var na_267 any = cursor__3; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_266); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_267) }; tmp2 = tmp3; if tmp2 { var n0_268 int64 = jrt.NN(jrt.Long_Cast(na_266)).LongValue__J(); var n1_269 int64 = jrt.NN(jrt.Long_Cast(na_267)).LongValue__J(); tmp1 = n0_268 > n1_269 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_266); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_267) }; tmp4 = tmp5; if tmp4 { var n0_268_2 float64 = jrt.NN(jrt.Double_Cast(na_266)).DoubleValue__D(); var n1_269_2 float64 = jrt.NN(jrt.Double_Cast(na_267)).DoubleValue__D(); tmp1 = n1_269_2 < n0_268_2 } else { tmp1 = lang.Numbers_Gt_O_O__Z_NoInit(na_266, na_267) } }; brk__8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() } else { brk__8 = and__1927000168__auto____8 }
//line :87:1
		var f__9 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_35.GetRawRoot__O()).Invoke_O_O_O_O__O(f__6, A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(), A_arbace_repr_go_layout_A_const_36, brk__8); var cursor__10 any



		if jrt.J2g_Truth(brk__8) { cursor__10 = l__7 } else { cursor__10 = cursor__3 }
//line :87:1
		var vec__1839000045__11 any; var root_278 any = A_arbace_repr_go_layout_A_const_42.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, A_arbace_repr_go_layout_prep_A_fn_class); var ifn_280 lang.IFn




		if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = f__9; var arg_282 any = cursor__10; if linked_279 == nil { vec__1839000045__11 = ifn_280.Invoke_O_O__O(arg_281, arg_282) } else { vec__1839000045__11 = linked_279.(*A_arbace_repr_go_layout_prep_A).Invoke_O_O_O__O(root_278, arg_281, arg_282) }
//line :87:1
		var f__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000045__11, lang.RT_IntCast_J__I_NoInit(0), nil); var cursor__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000045__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_283 any = A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_285 lang.IFn





		if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = fs__2; if linked_284 == nil { tmp6 = ifn_285.Invoke_O__O(arg_286) } else { tmp6 = linked_284.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_283, arg_286) }; var tmp7 any = tmp6; var tmp8 any; var root_287 any = A_arbace_repr_go_layout_A_const_8.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = acc__4; var arg_291 any = f__12; if linked_288 == nil { tmp8 = ifn_289.Invoke_O_O__O(arg_290, arg_291) } else { tmp8 = linked_288.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_287, arg_290, arg_291) }; fs__2, cursor__3, acc__4 = tmp7, cursor__13, tmp8; continue L1 } else {
//line :87:1
			return acc__4 } } }; /*line :83:1*/panic("j2g: unreachable") }



















func A_arbace_repr_go_layout_key_rank_A_New() *A_arbace_repr_go_layout_key_rank_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_key_rank_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_repr_go_layout_key_rank_A) Ctor() {}
//line :103:1
func (t *A_arbace_repr_go_layout_key_rank_A) Invoke_O_O__O(self, k__0 any) any { var i__2 int32 = jrt.List_Cast(A_arbace_repr_go_layout_A_const_57.GetRawRoot__O()).IndexOf_O__I(k__0); if

	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_layout_A_const_57.GetRawRoot__O())).Ref() } else { return jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref() } }

func A_arbace_repr_go_layout_sort_keys_A_New() *A_arbace_repr_go_layout_sort_keys_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_sort_keys_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_repr_go_layout_sort_keys_A) Ctor() {}
//line :107:1
func (t *A_arbace_repr_go_layout_sort_keys_A) Invoke_O_O__O(self, ks__0 any) any {
	var root_292 any = A_arbace_repr_go_layout_A_const_58.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any; var tmp1 any = A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_New(); var tmp2 *jrt.Class; var fncls__305 *jrt.Class = A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_fn_class; if fncls__305 == nil { var fncls__305d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_fn_class = fncls__305d; tmp2 = fncls__305d } else { tmp2 = fncls__305 }; arg_295 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_296 any = ks__0; if linked_293 == nil { return ifn_294.Invoke_O_O__O(arg_295, arg_296) } else { return linked_293.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_292, arg_295, arg_296) } }
//line :108:1
func A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_New() *A_arbace_repr_go_layout_sort_keys_fn__1839000050_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_sort_keys_fn__1839000050_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_repr_go_layout_sort_keys_fn__1839000050_A) Ctor() {}
//line :108:1
func (t *A_arbace_repr_go_layout_sort_keys_fn__1839000050_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 any; var root_297 any = A_arbace_repr_go_layout_A_const_59.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, A_arbace_repr_go_layout_key_rank_A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = k__1; if linked_298 == nil { tmp1 = ifn_299.Invoke_O__O(arg_300) } else { tmp1 = linked_298.(*A_arbace_repr_go_layout_key_rank_A).Invoke_O_O__O(root_297, arg_300) }; var tmp2 any = tmp1; var tmp3 any; var root_301 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = k__1; if linked_302 == nil { tmp3 = ifn_303.Invoke_O__O(arg_304) } else { tmp3 = linked_302.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_301, arg_304) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }

func A_arbace_repr_go_layout_public_meta_A_New() *A_arbace_repr_go_layout_public_meta_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_public_meta_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_repr_go_layout_public_meta_A) Ctor() {}
//line :110:1
func (t *A_arbace_repr_go_layout_public_meta_A) Invoke_O_O__O(self, x__0 any) any { var m__2 any; var tmp1 any; var root_306 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_308 lang.IFn; if


	linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = x__0; if linked_307 == nil { tmp1 = ifn_308.Invoke_O__O(arg_309) } else { tmp1 = linked_307.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_306, arg_309) }; if jrt.J2g_Truth(tmp1) { m__2 = lang.RT_Meta_O__IPersistentMap_NoInit(x__0) } else { m__2 = nil }; var lines_QMARK___3 bool = /*line :110:1*/lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_28); var pm__4 any; var root_310 any = A_arbace_repr_go_layout_A_const_54.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_312 lang.IFn; if




	linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_314 any; var root_316 any = A_arbace_repr_go_layout_A_const_61.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any; var tmp2 any = A_arbace_repr_go_layout_public_meta_fn__1839000054_A_New(); var tmp3 *jrt.Class; var fncls__324 *jrt.Class = A_arbace_repr_go_layout_public_meta_fn__1839000054_A_fn_class; if fncls__324 == nil { var fncls__324d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_repr_go_layout_public_meta_fn__1839000054_A_fn_class = fncls__324d; tmp3 = fncls__324d } else { tmp3 = fncls__324 }; arg_319 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_317 == nil { arg_314 = ifn_318.Invoke_O__O(arg_319) } else { arg_314 = linked_317.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O__O(root_316, arg_319) }; var arg_315 any = m__2; if linked_311 == nil { pm__4 = ifn_312.Invoke_O_O_O__O(arg_313, arg_314, arg_315) } else { pm__4 = linked_311.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_310, arg_313, arg_314, arg_315) }; var pm__5 any; if lines_QMARK___3 {
		pm__5 = pm__4 } else { var G__1839000059__5_ any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_63.GetRawRoot__O()).Invoke_O_O_O_O__O(pm__4, A_arbace_repr_go_layout_A_const_16, A_arbace_repr_go_layout_A_const_50, A_arbace_repr_go_layout_A_const_64); var G__1839000059__6_ any; var tmp4 any; var root_332 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_334 lang.IFn


			if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = A_arbace_repr_go_layout_A_const_65.Invoke_O__O(m__2); if linked_333 == nil { tmp4 = ifn_334.Invoke_O__O(arg_335) } else { tmp4 = linked_333.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_332, arg_335) }
//line :118:1
			if jrt.J2g_Truth(tmp4) {
				var root_336 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = G__1839000059__5_; var arg_340 any = A_arbace_repr_go_layout_A_const_66; var arg_341 any = A_arbace_repr_go_layout_A_const_65.Invoke_O__O(m__2); if linked_337 == nil { G__1839000059__6_ = ifn_338.Invoke_O_O_O__O(arg_339, arg_340, arg_341) } else { G__1839000059__6_ = linked_337.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_336, arg_339, arg_340, arg_341) } } else {
//line :118:1
					G__1839000059__6_ = G__1839000059__5_ }; var tmp5 any; var root_342 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_344 lang.IFn

			if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = A_arbace_repr_go_layout_A_const_67.Invoke_O__O(m__2); if linked_343 == nil { tmp5 = ifn_344.Invoke_O__O(arg_345) } else { tmp5 = linked_343.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_342, arg_345) }
//line :118:1
			if jrt.J2g_Truth(tmp5) {

				var root_346 any = A_arbace_repr_go_layout_A_const_53.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = G__1839000059__6_; var arg_350 any = A_arbace_repr_go_layout_A_const_67.Invoke_O__O(m__2); if linked_347 == nil { pm__5 = ifn_348.Invoke_O_O__O(arg_349, arg_350) } else { pm__5 = linked_347.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_346, arg_349, arg_350) } } else {
//line :118:1
					pm__5 = G__1839000059__6_ } }; return pm__5 }
//line :115:1
func A_arbace_repr_go_layout_public_meta_fn__1839000054_A_New() *A_arbace_repr_go_layout_public_meta_fn__1839000054_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_public_meta_fn__1839000054_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_repr_go_layout_public_meta_fn__1839000054_A) Ctor() {}
//line :115:1
func (t *A_arbace_repr_go_layout_public_meta_fn__1839000054_A) Invoke_O_O__O(self, p__1839000053__1 any) any { var vec__1839000055__2 any = p__1839000053__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000055__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000055__2, lang.RT_IntCast_J__I_NoInit(1), nil); var or__1927000174__auto____5 any; var root_320 any = A_arbace_repr_go_layout_A_const_62.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, A_arbace_repr_go_layout_private_QMARK__A_fn_class); var ifn_322 lang.IFn; _ = ___4; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = k__3; if linked_321 == nil { or__1927000174__auto____5 = ifn_322.Invoke_O__O(arg_323) } else { or__1927000174__auto____5 = linked_321.(*A_arbace_repr_go_layout_private_QMARK__A).Invoke_O_O__O(root_320, arg_323) }; if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_layout_A_const_36)).Ref() } }







func A_arbace_repr_go_layout_meta_prefix_A_New() *A_arbace_repr_go_layout_meta_prefix_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_repr_go_layout_meta_prefix_A) Ctor() {}
//line :123:1
func (t *A_arbace_repr_go_layout_meta_prefix_A) Invoke_O_O__O(self, x__0 any) any { var pm__2 any; var root_351 any = A_arbace_repr_go_layout_A_const_68.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, A_arbace_repr_go_layout_public_meta_A_fn_class); var ifn_353 lang.IFn; if
											linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = x__0; if linked_352 == nil { pm__2 = ifn_353.Invoke_O__O(arg_354) } else { pm__2 = linked_352.(*A_arbace_repr_go_layout_public_meta_A).Invoke_O_O__O(root_351, arg_354) }; var tmp1 any; var root_355 any =
											A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = pm__2; if linked_356 == nil { tmp1 = ifn_357.Invoke_O__O(arg_358) } else { tmp1 = linked_356.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_355, arg_358) }; if jrt.J2g_Truth(tmp1) { var ks__3 any; var root_359 any = A_arbace_repr_go_layout_A_const_69.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, A_arbace_repr_go_layout_sort_keys_A_fn_class); var ifn_361 lang.IFn
												if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any; var root_363 any = A_arbace_repr_go_layout_A_const_70.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = pm__2; if linked_364 == nil { arg_362 = ifn_365.Invoke_O__O(arg_366) } else { arg_362 = linked_364.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_363, arg_366) }; if linked_360 == nil { ks__3 = ifn_361.Invoke_O__O(arg_362) } else { ks__3 = linked_360.(*A_arbace_repr_go_layout_sort_keys_A).Invoke_O_O__O(root_359, arg_362) }
//line :125:1
		var flags__4 any; var root_367 any = A_arbace_repr_go_layout_A_const_71.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_369 lang.IFn

		if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any; var tmp2 any = A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_New_O(pm__2); var tmp3 *jrt.Class; var fncls__381 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_fn_class; if fncls__381 == nil { var fncls__381d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_fn_class = fncls__381d; tmp3 = fncls__381d } else { tmp3 = fncls__381 }; arg_370 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_371 any = ks__3; if linked_368 == nil { flags__4 = ifn_369.Invoke_O_O__O(arg_370, arg_371) } else { flags__4 = linked_368.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_367, arg_370, arg_371) }
//line :125:1
		var rest_ks__5 any; var root_382 any = A_arbace_repr_go_layout_A_const_61.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_384 lang.IFn


		if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any; var tmp4 any = A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_New_O(pm__2); var tmp5 *jrt.Class; var fncls__396 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_fn_class; if fncls__396 == nil { var fncls__396d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_fn_class = fncls__396d; tmp5 = fncls__396d } else { tmp5 = fncls__396 }; arg_385 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_386 any = ks__3; if linked_383 == nil { rest_ks__5 = ifn_384.Invoke_O_O__O(arg_385, arg_386) } else { rest_ks__5 = linked_383.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_382, arg_385, arg_386) }
//line :125:1
		var sb__6 any = jrt.StringBuilder_New(); var seq_1839000067__7 any; var root_401 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_403 lang.IFn




		if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = flags__4; if linked_402 == nil { seq_1839000067__7 = ifn_403.Invoke_O__O(arg_404) } else { seq_1839000067__7 = linked_402.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_401, arg_404) }
//line :125:1
		var chunk_1839000068__8 any; var count_1839000069__9 int64 = 0; var i_1839000070__10 int64 = 0; L1: for {




			if lang.Numbers_Lt_J_J__Z_NoInit(i_1839000070__10, count_1839000069__9) { var k__11 any = lang.Indexed_Cast(chunk_1839000068__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1839000070__10)); jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, k__11, nil))); seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, i_1839000070__10 = seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1839000070__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_405 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = seq_1839000067__7; if linked_406 == nil { temp__1927000414__auto____11 = ifn_407.Invoke_O__O(arg_408) } else { temp__1927000414__auto____11 = linked_406.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_405, arg_408) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1839000067__12 any = temp__1927000414__auto____11; var tmp6 any; var root_409 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = seq_1839000067__12; if linked_410 == nil { tmp6 = ifn_411.Invoke_O__O(arg_412) } else { tmp6 = linked_410.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_409, arg_412) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____13 any; var root_413 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = seq_1839000067__12; if linked_414 == nil { c__1927000678__auto____13 = ifn_415.Invoke_O__O(arg_416) } else { c__1927000678__auto____13 = linked_414.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_413, arg_416) }; var tmp7 any; var root_437 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = seq_1839000067__12; if linked_438 == nil { tmp7 = ifn_439.Invoke_O__O(arg_440) } else { tmp7 = linked_438.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_437, arg_440) }; seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, i_1839000070__10 = tmp7, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var k__13 any; var root_417 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = seq_1839000067__12; if linked_418 == nil { k__13 = ifn_419.Invoke_O__O(arg_420) } else { k__13 = linked_418.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_417, arg_420) }; jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, k__13, nil))); var tmp8 any; var root_441 any = A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = seq_1839000067__12; if linked_442 == nil { tmp8 = ifn_443.Invoke_O__O(arg_444) } else { tmp8 = linked_442.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_441, arg_444) }; seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, i_1839000070__10 = tmp8, nil, 0, 0; continue L1 } } }
//line :125:1
			break L1
		}




		var tmp9 any; var root_421 any = A_arbace_repr_go_layout_A_const_77.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_423 lang.IFn
		if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = rest_ks__5; if linked_422 == nil { tmp9 = ifn_423.Invoke_O__O(arg_424) } else { tmp9 = linked_422.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_421, arg_424) }
//line :131:1
		if jrt.J2g_Truth(tmp9) { } else { var tmp10 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(rest_ks__5, A_arbace_repr_go_layout_A_const_78)

			if and__1927000168__auto____7 { var and__1927000168__auto____8 any; var root_425 any = A_arbace_repr_go_layout_A_const_79.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = A_arbace_repr_go_layout_A_const_80.Invoke_O__O(pm__2); if linked_426 == nil { and__1927000168__auto____8 = ifn_427.Invoke_O__O(arg_428) } else { and__1927000168__auto____8 = linked_426.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_425, arg_428) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_429 any = A_arbace_repr_go_layout_A_const_77.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any; var root_433 any = A_arbace_repr_go_layout_A_const_68.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, A_arbace_repr_go_layout_public_meta_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = A_arbace_repr_go_layout_A_const_80.Invoke_O__O(pm__2); if linked_434 == nil { arg_432 = ifn_435.Invoke_O__O(arg_436) } else { arg_432 = linked_434.(*A_arbace_repr_go_layout_public_meta_A).Invoke_O_O__O(root_433, arg_436) }; if linked_430 == nil { tmp10 = ifn_431.Invoke_O__O(arg_432) } else { tmp10 = linked_430.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_429, arg_432) } } else { tmp10 = and__1927000168__auto____8 } } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }
//line :131:1
			if jrt.J2g_Truth(tmp10) {


				jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_go_layout_A_const_80.Invoke_O__O(pm__2), nil))) } else {
//line :131:1
					if A_arbace_repr_go_layout_A_const_41 != nil {




						jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(Lit_16)
						var tmp11 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__6); var tmp12 any; var root_445 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = Lit_9; var arg_449 any; var iter__1927001039__auto____7 any; var tmp13 any = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_New_O(pm__2); var tmp14 *jrt.Class; var fncls__516 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_fn_class; if fncls__516 == nil { var fncls__516d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_fn_class = fncls__516d; tmp14 = fncls__516d } else { tmp14 = fncls__516 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); arg_449 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(rest_ks__5); if linked_446 == nil { tmp12 = ifn_447.Invoke_O_O__O(arg_448, arg_449) } else { tmp12 = linked_446.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_445, arg_448, arg_449) }; jrt.NN(tmp11).Append_String__StringBuilder(jrt.String_Cast(tmp12))
						jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(Lit_18) } } }
		var root_397 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = sb__6; if linked_398 == nil { return ifn_399.Invoke_O__O(arg_400) } else { return linked_398.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_397, arg_400) } } else {
//line :125:1
			return nil } }

func A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_New_O(p0 any) *A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A{}; t.Ctor_O(p0); return t }
//line :127:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :127:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A) Invoke_O_O__O(self, p1__1839000061_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_372 any = A_arbace_repr_go_layout_A_const_72.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_true_QMARK__A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = lang.IFn_Cast(t.F_pm).Invoke_O__O(p1__1839000061_SHARP___1); if linked_373 == nil { and__1927000168__auto____2 = ifn_374.Invoke_O__O(arg_375) } else { and__1927000168__auto____2 = linked_373.(*aot_arbace_core.A_arbace_core_true_QMARK__A).Invoke_O_O__O(root_372, arg_375) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_376 any = A_arbace_repr_go_layout_A_const_73.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = p1__1839000061_SHARP___1; var arg_380 any = A_arbace_repr_go_layout_A_const_74; if linked_377 == nil { return ifn_378.Invoke_O_O__O(arg_379, arg_380) } else { return linked_377.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_376, arg_379, arg_380) } } else { return and__1927000168__auto____2 } }
func A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_New_O(p0 any) *A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A{}; t.Ctor_O(p0); return t }
//line :128:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :128:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A) Invoke_O_O__O(self, p1__1839000062_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_387 any = A_arbace_repr_go_layout_A_const_72.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_true_QMARK__A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = lang.IFn_Cast(t.F_pm).Invoke_O__O(p1__1839000062_SHARP___1); if linked_388 == nil { and__1927000168__auto____2 = ifn_389.Invoke_O__O(arg_390) } else { and__1927000168__auto____2 = linked_388.(*aot_arbace_core.A_arbace_core_true_QMARK__A).Invoke_O_O__O(root_387, arg_390) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_391 any = A_arbace_repr_go_layout_A_const_73.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = p1__1839000062_SHARP___1; var arg_395 any = A_arbace_repr_go_layout_A_const_74; if linked_392 == nil { return ifn_393.Invoke_O_O__O(arg_394, arg_395) } else { return linked_392.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_391, arg_394, arg_395) } } else { return and__1927000168__auto____2 } }








func A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_New_O(p0 any) *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A{}; t.Ctor_O(p0); return t }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A) Invoke_O_O__O(self, s__1839000072__1 any) any { var tmp1 any = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_New_O_O_O(s__1839000072__1, t.F_pm, self); var tmp2 *jrt.Class; var fncls__515 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_fn_class; if fncls__515 == nil { var fncls__515d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_fn_class = fncls__515d; tmp2 = fncls__515d } else { tmp2 = fncls__515 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :137:1
func A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A) Ctor_O_O_O(c__s__1839000072, c__pm, c__iter__1839000071 any) { t.F_s__1839000072 = c__s__1839000072; t.F_pm = c__pm; t.F_iter__1839000071 = c__iter__1839000071 }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A) Invoke_O__O(self any) any { { var s__1839000072__1 any; var t_ any = t.F_s__1839000072; t.F_s__1839000072 = nil; s__1839000072__1 = t_; for { var temp__1927000414__auto____2 any; var root_450 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = s__1839000072__1; if linked_451 == nil { temp__1927000414__auto____2 = ifn_452.Invoke_O__O(arg_453) } else { temp__1927000414__auto____2 = linked_451.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_450, arg_453) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000072__3 any = temp__1927000414__auto____2; var tmp1 any; var root_454 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = s__1839000072__3; if linked_455 == nil { tmp1 = ifn_456.Invoke_O__O(arg_457) } else { tmp1 = linked_455.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_454, arg_457) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_458 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = s__1839000072__3; if linked_459 == nil { c__1927001037__auto____4 = ifn_460.Invoke_O__O(arg_461) } else { c__1927001037__auto____4 = linked_459.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_458, arg_461) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000074__6 any; var root_462 any = A_arbace_repr_go_layout_A_const_83.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_463 == nil { b__1839000074__6 = ifn_464.Invoke_O__O(arg_465) } else { b__1839000074__6 = linked_463.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_462, arg_465) }; var tmp2 any = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_New_O_O_I_O(b__1839000074__6, t.F_pm, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__475 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_fn_class; if fncls__475 == nil { var fncls__475d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_fn_class = fncls__475d; tmp3 = fncls__475d } else { tmp3 = fncls__475 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_476 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any; var root_481 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = b__1839000074__6; if linked_482 == nil { arg_479 = ifn_483.Invoke_O__O(arg_484) } else { arg_479 = linked_482.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_481, arg_484) }; var arg_480 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000071); var tmp5 any; var root_485 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = s__1839000072__3; if linked_486 == nil { tmp5 = ifn_487.Invoke_O__O(arg_488) } else { tmp5 = linked_486.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_485, arg_488) }; arg_480 = tmp4.Invoke_O__O(tmp5); if linked_477 == nil { return ifn_478.Invoke_O_O__O(arg_479, arg_480) } else { return linked_477.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_476, arg_479, arg_480) } } else { var root_489 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any; var root_494 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = b__1839000074__6; if linked_495 == nil { arg_492 = ifn_496.Invoke_O__O(arg_497) } else { arg_492 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_494, arg_497) }; var arg_493 any; if linked_490 == nil { return ifn_491.Invoke_O_O__O(arg_492, arg_493) } else { return linked_490.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_489, arg_492, arg_493) } } } else { var k__4 any; var root_498 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = s__1839000072__3; if linked_499 == nil { k__4 = ifn_500.Invoke_O__O(arg_501) } else { k__4 = linked_499.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_498, arg_501) }; var root_502 any = A_arbace_repr_go_layout_A_const_88.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp7 any; var root_507 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, A_arbace_repr_go_layout_text_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = lang.IFn_Cast(t.F_pm).Invoke_O__O(k__4); if linked_508 == nil { tmp7 = ifn_509.Invoke_O__O(arg_510) } else { tmp7 = linked_508.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_507, arg_510) }; arg_505 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, k__4, nil, tmp7)).Ref(); var arg_506 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1839000071); var tmp9 any; var root_511 any = A_arbace_repr_go_layout_A_const_89.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = s__1839000072__3; if linked_512 == nil { tmp9 = ifn_513.Invoke_O__O(arg_514) } else { tmp9 = linked_512.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_511, arg_514) }; arg_506 = tmp8.Invoke_O__O(tmp9); if linked_503 == nil { return ifn_504.Invoke_O_O__O(arg_505, arg_506) } else { return linked_503.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_502, arg_505, arg_506) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :137:1
func A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A) Ctor_O_O_I_O(c__b__1839000074, c__pm any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000074 = c__b__1839000074; t.F_pm = c__pm; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A) Invoke_O__O(self any) any { { var i__1839000073__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000073__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var k__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000073__1)); var root_466 any = A_arbace_repr_go_layout_A_const_84.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = t.F_b__1839000074; var arg_470 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp3 any; var root_471 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, A_arbace_repr_go_layout_text_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = lang.IFn_Cast(t.F_pm).Invoke_O__O(k__2); if linked_472 == nil { tmp3 = ifn_473.Invoke_O__O(arg_474) } else { tmp3 = linked_472.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_471, arg_474) }; arg_470 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, k__2, nil, tmp3)).Ref(); if linked_467 == nil { ifn_468.Invoke_O_O__O(arg_469, arg_470) } else { linked_467.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_466, arg_469, arg_470) }; i__1839000073__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000073__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_repr_go_layout_atom_text_A_New() *A_arbace_repr_go_layout_atom_text_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_atom_text_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_repr_go_layout_atom_text_A) Ctor() {}
//line :141:1
func (t *A_arbace_repr_go_layout_atom_text_A) Invoke_O_O__O(self, x__0 any) any {
	if lang.Util_Identical_O_O__Z_NoInit(x__0, nil) { return Lit_1 } else { var tmp1 any; var root_517 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_519 lang.IFn

		if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = x__0; if linked_518 == nil { tmp1 = ifn_519.Invoke_O__O(arg_520) } else { tmp1 = linked_518.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_517, arg_520) }
//line :142:1
		if jrt.J2g_Truth(tmp1) {

			return A_arbace_repr_go_layout_A_const_90.Invoke_O__O(x__0) } else {
//line :142:1
				var tmp2 any; var root_521 any = A_arbace_repr_go_layout_A_const_79.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_523 lang.IFn


				if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = x__0; if linked_522 == nil { tmp2 = ifn_523.Invoke_O__O(arg_524) } else { tmp2 = linked_522.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_521, arg_524) }
//line :142:1
				if jrt.J2g_Truth(tmp2) {


					var root_525 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = x__0; if linked_526 == nil { return ifn_527.Invoke_O__O(arg_528) } else { return linked_526.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_525, arg_528) } } else {
//line :142:1
						var tmp3 any; var root_529 any = A_arbace_repr_go_layout_A_const_10.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_531 lang.IFn



						if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = x__0; if linked_530 == nil { tmp3 = ifn_531.Invoke_O__O(arg_532) } else { tmp3 = linked_530.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_529, arg_532) }
//line :142:1
						if jrt.J2g_Truth(tmp3) {



							var root_533 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = x__0; if linked_534 == nil { return ifn_535.Invoke_O__O(arg_536) } else { return linked_534.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_533, arg_536) } } else {
//line :142:1
								var tmp4 any; var root_537 any = A_arbace_repr_go_layout_A_const_91.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_539 lang.IFn




								if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = x__0; if linked_538 == nil { tmp4 = ifn_539.Invoke_O__O(arg_540) } else { tmp4 = linked_538.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_537, arg_540) }
//line :142:1
								if jrt.J2g_Truth(tmp4) {




									var root_541 any = A_arbace_repr_go_layout_A_const_92.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = x__0; if linked_542 == nil { return ifn_543.Invoke_O__O(arg_544) } else { return linked_542.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_541, arg_544) } } else {
//line :142:1
										var tmp5 any; var root_545 any = A_arbace_repr_go_layout_A_const_93.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_547 lang.IFn





										if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = x__0; if linked_546 == nil { tmp5 = ifn_547.Invoke_O__O(arg_548) } else { tmp5 = linked_546.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_545, arg_548) }
//line :142:1
										if jrt.J2g_Truth(tmp5) {





											var root_549 any = A_arbace_repr_go_layout_A_const_94.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_char_text_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(x__0)).Ref(); if linked_550 == nil { return ifn_551.Invoke_O__O(arg_552) } else { return linked_550.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_char_text_A).Invoke_O_O__O(root_549, arg_552) } } else {
//line :142:1
												if lang.BigInt_InstanceOf(x__0) {






													return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_2), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :142:1
														if jrt.BigInteger_InstanceOf(x__0) {







															return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_2), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :142:1
																var tmp6 any; var root_553 any = A_arbace_repr_go_layout_A_const_95.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_555 lang.IFn








																if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = x__0; if linked_554 == nil { tmp6 = ifn_555.Invoke_O__O(arg_556) } else { tmp6 = linked_554.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_553, arg_556) }
//line :142:1
																if jrt.J2g_Truth(tmp6) {








																	var root_557 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = x__0; if linked_558 == nil { return ifn_559.Invoke_O__O(arg_560) } else { return linked_558.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_557, arg_560) } } else {
//line :142:1
																		var tmp7 any; var root_561 any = A_arbace_repr_go_layout_A_const_96.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_boolean_QMARK__A_fn_class); var ifn_563 lang.IFn









																		if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = x__0; if linked_562 == nil { tmp7 = ifn_563.Invoke_O__O(arg_564) } else { tmp7 = linked_562.(*aot_arbace_core.A_arbace_core_boolean_QMARK__A).Invoke_O_O__O(root_561, arg_564) }
//line :142:1
																		if jrt.J2g_Truth(tmp7) {









																			var root_565 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = x__0; if linked_566 == nil { return ifn_567.Invoke_O__O(arg_568) } else { return linked_566.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_565, arg_568) } } else {
//line :142:1
																				if jrt.Double_InstanceOf(x__0) { var d__2 float64 = lang.RT_DoubleCast_O__D_NoInit(x__0)











																					if jrt.Double_IsNaN_D__Z_NoInit(d__2) { return Lit_3 } else { if jrt.Double_IsInfinite_D__Z_NoInit(d__2) {
																						if lang.Numbers_IsPos_D__Z_NoInit(d__2) { return Lit_4 } else { return Lit_5 } } else {
//line :154:1
																							if A_arbace_repr_go_layout_A_const_41 != nil {

																								var root_569 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = x__0; if linked_570 == nil { return ifn_571.Invoke_O__O(arg_572) } else { return linked_570.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_569, arg_572) } } else {
//line :154:1
																									return nil } } } } else {
//line :142:1
																										if jrt.BigDecimal_InstanceOf(x__0) {














																											return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :142:1
																												var tmp8 any; var root_573 any = A_arbace_repr_go_layout_A_const_97.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_575 lang.IFn















																												if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = x__0; if linked_574 == nil { tmp8 = ifn_575.Invoke_O__O(arg_576) } else { tmp8 = linked_574.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_573, arg_576) }
//line :142:1
																												if jrt.J2g_Truth(tmp8) {















																													var root_577 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = x__0; if linked_578 == nil { return ifn_579.Invoke_O__O(arg_580) } else { return linked_578.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_577, arg_580) } } else {
//line :142:1
																														if A_arbace_repr_go_layout_A_const_41 != nil { var tmp9 any; var root_581 any = A_arbace_repr_go_layout_A_const_98.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_583 lang.IFn
















																															if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp11 any; var root_586 any = A_arbace_repr_go_layout_A_const_99.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = x__0; if linked_587 == nil { tmp11 = ifn_588.Invoke_O__O(arg_589) } else { tmp11 = linked_587.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_586, arg_589) }; arg_584 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11)).Ref(); var arg_585 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_layout_A_const_100, x__0)); if linked_582 == nil { tmp9 = ifn_583.Invoke_O_O__O(arg_584, arg_585) } else { tmp9 = linked_582.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_581, arg_584, arg_585) }
//line :142:1
																															panic(jrt.Thrown(jrt.Throwable_Cast(tmp9))) } else { return nil
																															}
																													}
																											}
																									}
																			}
																	}
															}
													}
											}
									}
							}
					}
			}
	}
}



func A_arbace_repr_go_layout_lit_children_meta_A_New() *A_arbace_repr_go_layout_lit_children_meta_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_repr_go_layout_lit_children_meta_A) Ctor() {}
//line :161:1
func (t *A_arbace_repr_go_layout_lit_children_meta_A) Invoke_O_O__O(self, x__0 any) any {



	var root_590 any = A_arbace_repr_go_layout_A_const_45.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any; var tmp1 any = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_New(); var tmp2 *jrt.Class; var fncls__623 *jrt.Class = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_fn_class; if fncls__623 == nil { var fncls__623d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_fn_class = fncls__623d; tmp2 = fncls__623d } else { tmp2 = fncls__623 }; arg_593 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_594 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_595 any; var root_624 any = A_arbace_repr_go_layout_A_const_102.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_626 lang.IFn




	if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = A_arbace_repr_go_layout_A_const_103.GetRawRoot__O(); var arg_628 any = x__0; if linked_625 == nil { arg_595 = ifn_626.Invoke_O_O__O(arg_627, arg_628) } else { arg_595 = linked_625.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_624, arg_627, arg_628) }
//line :165:1
	if linked_591 == nil { return ifn_592.Invoke_O_O_O__O(arg_593, arg_594, arg_595) } else { return linked_591.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_590, arg_593, arg_594, arg_595) } }
//line :165:1
func A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_New() *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A) Ctor() {}
//line :165:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A) Invoke_O_O_O__O(self, m__1, p__1839000084__2 any) any { var vec__1839000086__3 any = p__1839000084__2; var i__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000086__3, lang.RT_IntCast_J__I_NoInit(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000086__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_596 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_598 lang.IFn; if
																linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = c__5; if linked_597 == nil { tmp1 = ifn_598.Invoke_O__O(arg_599) } else { tmp1 = linked_597.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_596, arg_599) }; if jrt.J2g_Truth(tmp1) {
																	var root_600 any = A_arbace_repr_go_layout_A_const_45.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any; var tmp2 any = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_New_O_O(i__4, c__5); var tmp3 *jrt.Class; var fncls__622 *jrt.Class = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_fn_class; if fncls__622 == nil { var fncls__622d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_fn_class = fncls__622d; tmp3 = fncls__622d } else { tmp3 = fncls__622 }; arg_603 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_604 any = m__1; var arg_605 any = A_arbace_repr_go_layout_A_const_101; if linked_601 == nil { return ifn_602.Invoke_O_O_O__O(arg_603, arg_604, arg_605) } else { return linked_601.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_600, arg_603, arg_604, arg_605) } } else {
//line :166:1
			return m__1 } }
func A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A{}; t.Ctor_O_O(p0, p1); return t }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A) Ctor_O_O(c__i, c__c any) { t.F_i = c__i; t.F_c = c__c }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A) Invoke_O_O_O__O(self, m__1, p__1839000089__2 any) any { var vec__1839000091__3 any = p__1839000089__2; var k__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000091__3, lang.RT_IntCast_J__I_NoInit(0), nil); var mk__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000091__3, lang.RT_IntCast_J__I_NoInit(1), nil); var temp__1927000408__auto____6 any = lang.RT_Get_O_O__O_NoInit(t.F_c, k__4); if jrt.J2g_Truth(temp__1927000408__auto____6) { var v__7 any = temp__1927000408__auto____6; var root_606 any = A_arbace_repr_go_layout_A_const_21.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = m__1; var arg_610 any = mk__5; var arg_611 any; var tmp1 any = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_New_O_O(t.F_i, v__7); var tmp2 *jrt.Class; var fncls__621 *jrt.Class = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_fn_class; if fncls__621 == nil { var fncls__621d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_fn_class = fncls__621d; tmp2 = fncls__621d } else { tmp2 = fncls__621 }; arg_611 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_607 == nil { return ifn_608.Invoke_O_O_O__O(arg_609, arg_610, arg_611) } else { return linked_607.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_606, arg_609, arg_610, arg_611) } } else { return m__1 } }
//line :167:1
func A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A{}; t.Ctor_O_O(p0, p1); return t }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A) Ctor_O_O(c__i, c__v any) { t.F_i = c__i; t.F_v = c__v }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A) Invoke_O_O__O(self, p1__1839000083_SHARP___1 any) any { var root_612 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any; var or__1927000174__auto____2 any = p1__1839000083_SHARP___1; if jrt.J2g_Truth(or__1927000174__auto____2) { arg_615 = or__1927000174__auto____2 } else { arg_615 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_30.GetRawRoot__O()).Invoke__O() }; var arg_616 any = t.F_i; var arg_617 any = t.F_v; if linked_613 == nil { return ifn_614.Invoke_O_O_O__O(arg_615, arg_616, arg_617) } else { return linked_613.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_612, arg_615, arg_616, arg_617) } }




func A_arbace_repr_go_layout_text_A_New() *A_arbace_repr_go_layout_text_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_repr_go_layout_text_A) Ctor() {}
//line :172:1
func (t *A_arbace_repr_go_layout_text_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_629 any = A_arbace_repr_go_layout_A_const_104.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, A_arbace_repr_go_layout_meta_prefix_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any; var tmp3 any; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_51); if and__1927000168__auto____4 { var and__1927000168__auto____5 any; var or__1927000174__auto____5 any; var root_633 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = x__0; if linked_634 == nil { or__1927000174__auto____5 = ifn_635.Invoke_O__O(arg_636) } else { or__1927000174__auto____5 = linked_634.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_633, arg_636) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else { var root_637 any = A_arbace_repr_go_layout_A_const_25.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = x__0; if linked_638 == nil { and__1927000168__auto____5 = ifn_639.Invoke_O__O(arg_640) } else { and__1927000168__auto____5 = linked_638.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_637, arg_640) } }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_641 any = A_arbace_repr_go_layout_A_const_37.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var tmp4 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; var arg_644 any = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)); if linked_642 == nil { tmp3 = ifn_643.Invoke_O__O(arg_644) } else { tmp3 = linked_642.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_641, arg_644) } } else { tmp3 = and__1927000168__auto____5 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if jrt.J2g_Truth(tmp3) { var lm__4 any; var root_645 any = A_arbace_repr_go_layout_A_const_105.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, A_arbace_repr_go_layout_lit_children_meta_A_fn_class); var ifn_647 lang.IFn
		if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = x__0; if linked_646 == nil { lm__4 = ifn_647.Invoke_O__O(arg_648) } else { lm__4 = linked_646.(*A_arbace_repr_go_layout_lit_children_meta_A).Invoke_O_O__O(root_645, arg_648) }
		var tmp5 any; var root_649 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = lm__4; if linked_650 == nil { tmp5 = ifn_651.Invoke_O__O(arg_652) } else { tmp5 = linked_650.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_649, arg_652) }; if jrt.J2g_Truth(tmp5) { arg_632 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(x__0, A_arbace_repr_go_layout_A_const_53.GetRawRoot__O(), lm__4) } else { arg_632 = x__0 } } else {
//line :175:1
			arg_632 = x__0 }; if linked_630 == nil { tmp2 = ifn_631.Invoke_O__O(arg_632) } else { tmp2 = linked_630.(*A_arbace_repr_go_layout_meta_prefix_A).Invoke_O_O__O(root_629, arg_632) }; var tmp6 any = tmp2; var tmp7 any; var tmp8 any; var root_659 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_661 lang.IFn




	if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = x__0; if linked_660 == nil { tmp8 = ifn_661.Invoke_O__O(arg_662) } else { tmp8 = linked_660.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_659, arg_662) }
//line :179:1
	if jrt.J2g_Truth(tmp8) {
		tmp7 = A_arbace_repr_go_layout_A_const_90.Invoke_O__O(x__0) } else {
//line :179:1
			var tmp9 any; var and__1927000168__auto____4_2 any; var root_663 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_665 lang.IFn

			if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = x__0; if linked_664 == nil { and__1927000168__auto____4_2 = ifn_665.Invoke_O__O(arg_666) } else { and__1927000168__auto____4_2 = linked_664.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_663, arg_666) }; if jrt.J2g_Truth(and__1927000168__auto____4_2) { var tmp10 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; tmp9 = tmp10.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else { tmp9 = and__1927000168__auto____4_2 }
//line :179:1
			if jrt.J2g_Truth(tmp9) {

				var tmp11 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; tmp7 = tmp11.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else {
//line :179:1
					var tmp12 any; var root_667 any = A_arbace_repr_go_layout_A_const_38.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, A_arbace_repr_go_layout_deref_form_QMARK__A_fn_class); var ifn_669 lang.IFn


					if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = x__0; if linked_668 == nil { tmp12 = ifn_669.Invoke_O__O(arg_670) } else { tmp12 = linked_668.(*A_arbace_repr_go_layout_deref_form_QMARK__A).Invoke_O_O__O(root_667, arg_670) }
//line :179:1
					if jrt.J2g_Truth(tmp12) {


						var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_27, nil); var tmp14 any; var root_671 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, A_arbace_repr_go_layout_text_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any; var root_675 any = A_arbace_repr_go_layout_A_const_106.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = x__0; if linked_676 == nil { arg_674 = ifn_677.Invoke_O__O(arg_678) } else { arg_674 = linked_676.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_675, arg_678) }; if linked_672 == nil { tmp14 = ifn_673.Invoke_O__O(arg_674) } else { tmp14 = linked_672.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_671, arg_674) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref() } else {
//line :179:1
							var tmp15 any; var root_679 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_681 lang.IFn



							if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = x__0; if linked_680 == nil { tmp15 = ifn_681.Invoke_O__O(arg_682) } else { tmp15 = linked_680.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_679, arg_682) }
//line :179:1
							if jrt.J2g_Truth(tmp15) {



								var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_28, nil, Lit_29); var tmp17 any; var root_683 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = Lit_9; var arg_687 any; var root_688 any = A_arbace_repr_go_layout_A_const_55.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var arg_692 any = x__0; if linked_689 == nil { arg_687 = ifn_690.Invoke_O_O__O(arg_691, arg_692) } else { arg_687 = linked_689.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_688, arg_691, arg_692) }; if linked_684 == nil { tmp17 = ifn_685.Invoke_O_O__O(arg_686, arg_687) } else { tmp17 = linked_684.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_683, arg_686, arg_687) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, tmp17, nil)).Ref() } else {
//line :179:1
									var tmp18 any; var root_693 any = A_arbace_repr_go_layout_A_const_25.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_695 lang.IFn




									if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = x__0; if linked_694 == nil { tmp18 = ifn_695.Invoke_O__O(arg_696) } else { tmp18 = linked_694.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_693, arg_696) }
//line :179:1
									if jrt.J2g_Truth(tmp18) {




										var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_31); var tmp20 any; var root_697 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = Lit_9; var arg_701 any; var root_702 any = A_arbace_repr_go_layout_A_const_55.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var arg_706 any = x__0; if linked_703 == nil { arg_701 = ifn_704.Invoke_O_O__O(arg_705, arg_706) } else { arg_701 = linked_703.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_702, arg_705, arg_706) }; if linked_698 == nil { tmp20 = ifn_699.Invoke_O_O__O(arg_700, arg_701) } else { tmp20 = linked_698.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_697, arg_700, arg_701) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp19, jrt.RefArrayOf(jrt.Object_class, nil, tmp20, nil)).Ref() } else {
//line :179:1
											var tmp21 any; var root_707 any = A_arbace_repr_go_layout_A_const_107.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_709 lang.IFn





											if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = x__0; if linked_708 == nil { tmp21 = ifn_709.Invoke_O__O(arg_710) } else { tmp21 = linked_708.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_707, arg_710) }
//line :179:1
											if jrt.J2g_Truth(tmp21) {





												var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_32, nil, Lit_33); var tmp23 any; var root_711 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = Lit_9; var arg_715 any; var iter__1927001039__auto____7 any; var tmp24 any = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_New(); var tmp25 *jrt.Class; var fncls__790 *jrt.Class = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_fn_class; if fncls__790 == nil { var fncls__790d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_fn_class = fncls__790d; tmp25 = fncls__790d } else { tmp25 = fncls__790 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); arg_715 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(x__0); if linked_712 == nil { tmp23 = ifn_713.Invoke_O_O__O(arg_714, arg_715) } else { tmp23 = linked_712.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_711, arg_714, arg_715) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23, nil)).Ref() } else {
//line :179:1
													if A_arbace_repr_go_layout_A_const_41 != nil {






														var root_791 any = A_arbace_repr_go_layout_A_const_108.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, A_arbace_repr_go_layout_atom_text_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = x__0; if linked_792 == nil { tmp7 = ifn_793.Invoke_O__O(arg_794) } else { tmp7 = linked_792.(*A_arbace_repr_go_layout_atom_text_A).Invoke_O_O__O(root_791, arg_794) } } else {
//line :179:1
															tmp7 = nil } } } } } } }
//line :175:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7)).Ref()
}








func A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_New() *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A) Ctor() {}
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A) Invoke_O_O__O(self, s__1839000100__1 any) any { var tmp1 any = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_New_O_O(s__1839000100__1, self); var tmp2 *jrt.Class; var fncls__789 *jrt.Class = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_fn_class; if fncls__789 == nil { var fncls__789d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_fn_class = fncls__789d; tmp2 = fncls__789d } else { tmp2 = fncls__789 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :185:1
func A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A{}; t.Ctor_O_O(p0, p1); return t }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A) Ctor_O_O(c__s__1839000100, c__iter__1839000099 any) { t.F_s__1839000100 = c__s__1839000100; t.F_iter__1839000099 = c__iter__1839000099 }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A) Invoke_O__O(self any) any { { var s__1839000100__1 any; var t_ any = t.F_s__1839000100; t.F_s__1839000100 = nil; s__1839000100__1 = t_; for { var temp__1927000414__auto____2 any; var root_716 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = s__1839000100__1; if linked_717 == nil { temp__1927000414__auto____2 = ifn_718.Invoke_O__O(arg_719) } else { temp__1927000414__auto____2 = linked_717.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_716, arg_719) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000100__3 any = temp__1927000414__auto____2; var tmp1 any; var root_720 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = s__1839000100__3; if linked_721 == nil { tmp1 = ifn_722.Invoke_O__O(arg_723) } else { tmp1 = linked_721.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_720, arg_723) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_724 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_726 lang.IFn; if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = s__1839000100__3; if linked_725 == nil { c__1927001037__auto____4 = ifn_726.Invoke_O__O(arg_727) } else { c__1927001037__auto____4 = linked_725.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_724, arg_727) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000102__6 any; var root_728 any = A_arbace_repr_go_layout_A_const_83.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_729 == nil { b__1839000102__6 = ifn_730.Invoke_O__O(arg_731) } else { b__1839000102__6 = linked_729.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_728, arg_731) }; var tmp2 any = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_New_O_I_O(b__1839000102__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__745 *jrt.Class = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_fn_class; if fncls__745 == nil { var fncls__745d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_fn_class = fncls__745d; tmp3 = fncls__745d } else { tmp3 = fncls__745 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_746 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any; var root_751 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = b__1839000102__6; if linked_752 == nil { arg_749 = ifn_753.Invoke_O__O(arg_754) } else { arg_749 = linked_752.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_751, arg_754) }; var arg_750 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000099); var tmp5 any; var root_755 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = s__1839000100__3; if linked_756 == nil { tmp5 = ifn_757.Invoke_O__O(arg_758) } else { tmp5 = linked_756.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_755, arg_758) }; arg_750 = tmp4.Invoke_O__O(tmp5); if linked_747 == nil { return ifn_748.Invoke_O_O__O(arg_749, arg_750) } else { return linked_747.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_746, arg_749, arg_750) } } else { var root_759 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any; var root_764 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = b__1839000102__6; if linked_765 == nil { arg_762 = ifn_766.Invoke_O__O(arg_767) } else { arg_762 = linked_765.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_764, arg_767) }; var arg_763 any; if linked_760 == nil { return ifn_761.Invoke_O_O__O(arg_762, arg_763) } else { return linked_760.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_759, arg_762, arg_763) } } } else { var vec__1839000110__4 any; var root_768 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = s__1839000100__3; if linked_769 == nil { vec__1839000110__4 = ifn_770.Invoke_O__O(arg_771) } else { vec__1839000110__4 = linked_769.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_768, arg_771) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000110__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000110__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_772 any = A_arbace_repr_go_layout_A_const_88.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp7 any; var root_777 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, A_arbace_repr_go_layout_text_A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = k__5; if linked_778 == nil { tmp7 = ifn_779.Invoke_O__O(arg_780) } else { tmp7 = linked_778.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_777, arg_780) }; var tmp8 any = tmp7; var tmp9 any; var root_781 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, A_arbace_repr_go_layout_text_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = v__6; if linked_782 == nil { tmp9 = ifn_783.Invoke_O__O(arg_784) } else { tmp9 = linked_782.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_781, arg_784) }; arg_775 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_776 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__1839000099); var tmp11 any; var root_785 any = A_arbace_repr_go_layout_A_const_89.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = s__1839000100__3; if linked_786 == nil { tmp11 = ifn_787.Invoke_O__O(arg_788) } else { tmp11 = linked_786.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_785, arg_788) }; arg_776 = tmp10.Invoke_O__O(tmp11); if linked_773 == nil { return ifn_774.Invoke_O_O__O(arg_775, arg_776) } else { return linked_773.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_772, arg_775, arg_776) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :185:1
func A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A) Ctor_O_I_O(c__b__1839000102 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000102 = c__b__1839000102; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A) Invoke_O__O(self any) any { { var i__1839000101__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000101__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1839000106__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000101__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000106__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000106__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_732 any = A_arbace_repr_go_layout_A_const_84.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = t.F_b__1839000102; var arg_736 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp3 any; var root_737 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, A_arbace_repr_go_layout_text_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = k__3; if linked_738 == nil { tmp3 = ifn_739.Invoke_O__O(arg_740) } else { tmp3 = linked_738.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_737, arg_740) }; var tmp4 any = tmp3; var tmp5 any; var root_741 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, A_arbace_repr_go_layout_text_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = v__4; if linked_742 == nil { tmp5 = ifn_743.Invoke_O__O(arg_744) } else { tmp5 = linked_742.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_741, arg_744) }; arg_736 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref(); if linked_733 == nil { ifn_734.Invoke_O_O__O(arg_735, arg_736) } else { linked_733.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_732, arg_735, arg_736) }; i__1839000101__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000101__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_repr_go_layout_comment_text_A_New() *A_arbace_repr_go_layout_comment_text_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_comment_text_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_repr_go_layout_comment_text_A) Ctor() {}
//line :188:1
func (t *A_arbace_repr_go_layout_comment_text_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_795 any = A_arbace_repr_go_layout_A_const_109.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_797 lang.IFn
	if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = t__0; var arg_799 any = Lit_8; if linked_796 == nil { tmp1 = ifn_797.Invoke_O_O__O(arg_798, arg_799) } else { tmp1 = linked_796.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_795, arg_798, arg_799) }
//line :191:1
	if jrt.J2g_Truth(tmp1) {
		var root_800 any = A_arbace_repr_go_layout_A_const_110.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = t__0; var arg_804 any = A_arbace_repr_go_layout_A_const_111; if linked_801 == nil { return ifn_802.Invoke_O_O__O(arg_803, arg_804) } else { return linked_801.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_800, arg_803, arg_804) } } else {
//line :191:1
			if A_arbace_repr_go_layout_A_const_41 != nil {

				var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil); var tmp3 any; var root_805 any = A_arbace_repr_go_layout_A_const_112.GetRawRoot__O(); var linked_806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_805, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_807 lang.IFn; if linked_806 == nil { ifn_807 = lang.IFn_Cast(root_805) } else { ifn_807 = nil }; var arg_808 any = t__0; if linked_806 == nil { tmp3 = ifn_807.Invoke_O__O(arg_808) } else { tmp3 = linked_806.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_805, arg_808) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
//line :191:1
					return nil
				}
		}
}
func A_arbace_repr_go_layout_write_file_A_New() *A_arbace_repr_go_layout_write_file_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_file_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_repr_go_layout_write_file_A) Ctor() {}
//line :195:1
func (t *A_arbace_repr_go_layout_write_file_A) Invoke_O_O_O__O(self, forms__0, comments__1 any) any { var forms__3 any; var root_809 any = A_arbace_repr_go_layout_A_const_113.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, A_arbace_repr_go_layout_prepare_A_fn_class); var ifn_811 lang.IFn; if


	linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = forms__0; if linked_810 == nil { forms__3 = ifn_811.Invoke_O__O(arg_812) } else { forms__3 = linked_810.(*A_arbace_repr_go_layout_prepare_A).Invoke_O_O__O(root_809, arg_812) }; var sb__4 any = /*line :195:1*/jrt.StringBuilder_New(); var line__5 any; var root_813 any = A_arbace_repr_go_layout_A_const_114.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_815 lang.IFn; if




	linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = A_arbace_repr_go_layout_A_const_115; if linked_814 == nil { line__5 = ifn_815.Invoke_O__O(arg_816) } else { line__5 = linked_814.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_813, arg_816) }; var code_QMARK___6 any; var root_817 any = /*line :195:1*/A_arbace_repr_go_layout_A_const_114.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_819 lang.IFn; if





	linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = jrt.Boolean_FALSE.Ref(); if linked_818 == nil { code_QMARK___6 = ifn_819.Invoke_O__O(arg_820) } else { code_QMARK___6 = linked_818.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_817, arg_820) }; var depth__7 any; var root_821 any = /*line :195:1*/A_arbace_repr_go_layout_A_const_114.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_823 lang.IFn; if






	linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = A_arbace_repr_go_layout_A_const_24; if linked_822 == nil { depth__7 = ifn_823.Invoke_O__O(arg_824) } else { depth__7 = linked_822.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_821, arg_824) }; var flush_comments_BANG___8 any; var tmp1 any = /*line :195:1*/A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A_New_O_O_O_O_O(sb__4, code_QMARK___6, line__5, comments__1, depth__7); var tmp2 *jrt.Class; var fncls__872 *jrt.Class = A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A_fn_class; if








	fncls__872 == nil { var fncls__872d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A_fn_class = fncls__872d; tmp2 = fncls__872d } else { tmp2 = fncls__872 }; flush_comments_BANG___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var newline_to_BANG___9 any; var tmp3 any = /*line :195:1*/A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A_New_O_O_O_O_O(sb__4, code_QMARK___6, line__5, flush_comments_BANG___8, depth__7); var tmp4 *jrt.Class; var fncls__908 *jrt.Class = A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A_fn_class; if















	fncls__908 == nil { var fncls__908d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A_fn_class = fncls__908d; tmp4 = fncls__908d } else { tmp4 = fncls__908 }; newline_to_BANG___9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var emit__10 any; var tmp5 any = /*line :195:1*/A_arbace_repr_go_layout_write_file_emit__1839000121_A_New_O_O_O_O(newline_to_BANG___9, sb__4, code_QMARK___6, depth__7); var tmp6 *jrt.Class; var fncls__1031 *jrt.Class = A_arbace_repr_go_layout_write_file_emit__1839000121_A_fn_class; if























	fncls__1031 == nil { var fncls__1031d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_repr_go_layout_write_file_emit__1839000121_A_fn_class = fncls__1031d; tmp6 = fncls__1031d } else { tmp6 = fncls__1031 }; emit__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var seq_1839000133__11 any; var root_1036 any = /*line :195:1*/A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1038 lang.IFn; if












































	linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = forms__3; if linked_1037 == nil { seq_1839000133__11 = ifn_1038.Invoke_O__O(arg_1039) } else { seq_1839000133__11 = linked_1037.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1036, arg_1039) }; var chunk_1839000134__12 any; var count_1839000135__13 int64 = 0; var i_1839000136__14 int64 = 0; L1:
//line :195:1
	for {












































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1839000136__14, count_1839000135__13) { var f__15 any = lang.Indexed_Cast(chunk_1839000134__12).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1839000136__14)); var tmp7 *lang.Keyword = A_arbace_repr_go_layout_A_const_36
			if jrt.J2g_Truth(tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__15))) {
				lang.IFn_Cast(emit__10).Invoke_O__O(f__15) } else {
					var tmp8 any; var root_1069 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1071 lang.IFn; if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = code_QMARK___6; if linked_1070 == nil { tmp8 = ifn_1071.Invoke_O__O(arg_1072) } else { tmp8 = linked_1070.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1069, arg_1072) }; if jrt.J2g_Truth(tmp8) { jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(Lit_9) }; lang.IFn_Cast(emit__10).Invoke_O__O(f__15) }
//line :240:1
			seq_1839000133__11, chunk_1839000134__12, count_1839000135__13, i_1839000136__14 = seq_1839000133__11, chunk_1839000134__12, count_1839000135__13, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1839000136__14); continue L1 } else { var temp__1927000414__auto____15 any; var root_1040 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = seq_1839000133__11; if linked_1041 == nil { temp__1927000414__auto____15 = ifn_1042.Invoke_O__O(arg_1043) } else { temp__1927000414__auto____15 = linked_1041.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1040, arg_1043) }; if jrt.J2g_Truth(temp__1927000414__auto____15) { var seq_1839000133__16 any = temp__1927000414__auto____15; var tmp9 any; var root_1044 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1046 lang.IFn; if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = seq_1839000133__16; if linked_1045 == nil { tmp9 = ifn_1046.Invoke_O__O(arg_1047) } else { tmp9 = linked_1045.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1044, arg_1047) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____17 any; var root_1048 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = seq_1839000133__16; if linked_1049 == nil { c__1927000678__auto____17 = ifn_1050.Invoke_O__O(arg_1051) } else { c__1927000678__auto____17 = linked_1049.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1048, arg_1051) }; var tmp10 any; var root_1073 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = seq_1839000133__16; if linked_1074 == nil { tmp10 = ifn_1075.Invoke_O__O(arg_1076) } else { tmp10 = linked_1074.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1073, arg_1076) }; seq_1839000133__11, chunk_1839000134__12, count_1839000135__13, i_1839000136__14 = tmp10, c__1927000678__auto____17, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__17 any; var root_1052 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1054 lang.IFn; if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any = seq_1839000133__16; if linked_1053 == nil { f__17 = ifn_1054.Invoke_O__O(arg_1055) } else { f__17 = linked_1053.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1052, arg_1055) }
				var tmp11 *lang.Keyword = A_arbace_repr_go_layout_A_const_36; if jrt.J2g_Truth(tmp11.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__17))) {
					lang.IFn_Cast(emit__10).Invoke_O__O(f__17) } else {
						var tmp12 any; var root_1077 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1079 lang.IFn; if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = code_QMARK___6; if linked_1078 == nil { tmp12 = ifn_1079.Invoke_O__O(arg_1080) } else { tmp12 = linked_1078.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1077, arg_1080) }; if jrt.J2g_Truth(tmp12) { jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(Lit_9) }; lang.IFn_Cast(emit__10).Invoke_O__O(f__17) }
//line :240:1
				var tmp13 any; var root_1081 any = A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = seq_1839000133__16; if linked_1082 == nil { tmp13 = ifn_1083.Invoke_O__O(arg_1084) } else { tmp13 = linked_1082.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1081, arg_1084) }; seq_1839000133__11, chunk_1839000134__12, count_1839000135__13, i_1839000136__14 = tmp13, nil, 0, 0; continue L1 } } }
//line :195:1
		break L1 }; var last_comment__11 any; var tmp14 any; var root_1056 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1058 lang.IFn; if
















































	linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = comments__1; if linked_1057 == nil { tmp14 = ifn_1058.Invoke_O__O(arg_1059) } else { tmp14 = linked_1057.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1056, arg_1059) }; if jrt.J2g_Truth(tmp14) { var root_1060 any = A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1060, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = A_arbace_repr_go_layout_A_const_119.GetRawRoot__O(); var arg_1064 any; var root_1065 any = A_arbace_repr_go_layout_A_const_70.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = comments__1; if linked_1066 == nil { arg_1064 = ifn_1067.Invoke_O__O(arg_1068) } else { arg_1064 = linked_1066.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1065, arg_1068) }; if linked_1061 == nil { last_comment__11 = ifn_1062.Invoke_O_O__O(arg_1063, arg_1064) } else { last_comment__11 = linked_1061.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1060, arg_1063, arg_1064) } } else { last_comment__11 = A_arbace_repr_go_layout_A_const_24 }; var tmp15 bool; var na_1085 any = last_comment__11; var na_1086 any; var root_1087 any =
	A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = line__5; if linked_1088 == nil { na_1086 = ifn_1089.Invoke_O__O(arg_1090) } else { na_1086 = linked_1088.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1087, arg_1090) }; var tmp16 bool; var tmp17 bool; tmp17 = jrt.Long_InstanceOf(na_1085); if tmp17 { tmp17 = jrt.Long_InstanceOf(na_1086) }; tmp16 = tmp17; if tmp16 { var n0_1091 int64 = jrt.NN(jrt.Long_Cast(na_1085)).LongValue__J(); var n1_1092 int64 = jrt.NN(jrt.Long_Cast(na_1086)).LongValue__J(); tmp15 = n0_1091 > n1_1092 } else { var tmp18 bool; var tmp19 bool; tmp19 = jrt.Double_InstanceOf(na_1085); if tmp19 { tmp19 = jrt.Double_InstanceOf(na_1086) }; tmp18 = tmp19; if tmp18 { var n0_1091_2 float64 = jrt.NN(jrt.Double_Cast(na_1085)).DoubleValue__D(); var n1_1092_2 float64 = jrt.NN(jrt.Double_Cast(na_1086)).DoubleValue__D(); tmp15 = n1_1092_2 < n0_1091_2 } else { tmp15 = lang.Numbers_Gt_O_O__Z_NoInit(na_1085, na_1086) } }; if tmp15 {
		var root_1094 any = A_arbace_repr_go_layout_A_const_118.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1094, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_1096 lang.IFn; if linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any = depth__7; var arg_1098 any = A_arbace_repr_go_layout_A_const_24; if linked_1095 == nil { ifn_1096.Invoke_O_O__O(arg_1097, arg_1098) } else { linked_1095.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_1094, arg_1097, arg_1098) }
		lang.IFn_Cast(newline_to_BANG___9).Invoke_O__O(last_comment__11) };
	lang.IFn_Cast(flush_comments_BANG___8).Invoke__O();
	jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(Lit_40); var root_1032 any =
	A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = sb__4; if linked_1033 == nil { return ifn_1034.Invoke_O__O(arg_1035) } else { return linked_1033.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1032, arg_1035) } }
//line :204:1
func A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :204:1
func (t *A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A) Ctor_O_O_O_O_O(c__sb, c__code_QMARK_, c__line, c__comments, c__depth any) { t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_line = c__line; t.F_comments = c__comments; t.F_depth = c__depth }
//line :204:1
func (t *A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any; var tmp1 any = t.F_comments; var tmp2 any; var root_825 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_827 lang.IFn; if
														linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = t.F_line; if linked_826 == nil { tmp2 = ifn_827.Invoke_O__O(arg_828) } else { tmp2 = linked_826.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_825, arg_828) }; temp__1927000414__auto____1 = lang.RT_Get_O_O__O_NoInit(tmp1, tmp2); if jrt.J2g_Truth(temp__1927000414__auto____1) { var cs__2 any = temp__1927000414__auto____1; var tmp3 any; var root_829 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_831 lang.IFn
															if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = t.F_code_QMARK_; if linked_830 == nil { tmp3 = ifn_831.Invoke_O__O(arg_832) } else { tmp3 = linked_830.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_829, arg_832) }; if jrt.J2g_Truth(tmp3) {
																var tmp4 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_41, nil); var tmp6 any; var root_833 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = Lit_41; var arg_837 any; var root_838 any = A_arbace_repr_go_layout_A_const_55.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = A_arbace_repr_go_layout_A_const_116.GetRawRoot__O(); var arg_842 any = cs__2; if linked_839 == nil { arg_837 = ifn_840.Invoke_O_O__O(arg_841, arg_842) } else { arg_837 = linked_839.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_838, arg_841, arg_842) }; if linked_834 == nil { tmp6 = ifn_835.Invoke_O_O__O(arg_836, arg_837) } else { tmp6 = linked_834.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_833, arg_836, arg_837) }; return jrt.NN(tmp4).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6))).Ref() } else {
																	var tmp7 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp8 any; var root_853 any = A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_853, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var arg_857 any; var root_858 any = A_arbace_repr_go_layout_A_const_117.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_858, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_860 lang.IFn; if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any; var na_863 int64 = 2; var na_864 any; var root_865 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = t.F_depth; if linked_866 == nil { na_864 = ifn_867.Invoke_O__O(arg_868) } else { na_864 = linked_866.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_865, arg_868) }; if jrt.Long_InstanceOf(na_864) { var n0_869 int64 = na_863; var n1_870 int64 = jrt.NN(jrt.Long_Cast(na_864)).LongValue__J(); var nr_871 int64 = n0_869 * n1_870; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; tmp12 = n0_869 == -9223372036854775808; if tmp12 { tmp12 = n1_870 < 0 }; tmp11 = tmp12; tmp10 = !tmp11; if tmp10 { var tmp13 bool; tmp13 = n1_870 == 0; if !tmp13 { tmp13 = nr_871/n1_870 == n0_869 }; tmp10 = tmp13 }; tmp9 = tmp10; if tmp9 { arg_861 = jrt.Long_ValueOf_J__Long_NoInit(nr_871).Ref() } else { arg_861 = lang.Numbers_Multiply_J_O__Number_NoInit(na_863, na_864) } } else { arg_861 = lang.Numbers_Multiply_J_O__Number_NoInit(na_863, na_864) }; var arg_862 any = Lit_9; if linked_859 == nil { arg_857 = ifn_860.Invoke_O_O__O(arg_861, arg_862) } else { arg_857 = linked_859.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_858, arg_861, arg_862) }; if linked_854 == nil { tmp8 = ifn_855.Invoke_O_O__O(arg_856, arg_857) } else { tmp8 = linked_854.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_853, arg_856, arg_857) }; jrt.NN(tmp7).Append_O__StringBuilder(tmp8)
																	var tmp14 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil); var tmp16 any; var root_843 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_843, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_845 lang.IFn; if linked_844 == nil { ifn_845 = lang.IFn_Cast(root_843) } else { ifn_845 = nil }; var arg_846 any = Lit_43; var arg_847 any; var root_848 any = A_arbace_repr_go_layout_A_const_55.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = A_arbace_repr_go_layout_A_const_116.GetRawRoot__O(); var arg_852 any = cs__2; if linked_849 == nil { arg_847 = ifn_850.Invoke_O_O__O(arg_851, arg_852) } else { arg_847 = linked_849.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_848, arg_851, arg_852) }; if linked_844 == nil { tmp16 = ifn_845.Invoke_O_O__O(arg_846, arg_847) } else { tmp16 = linked_844.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_843, arg_846, arg_847) }; return jrt.NN(tmp14).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16))).Ref() } } else {
//line :205:1
					return nil } }





func A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :211:1
func (t *A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A) Ctor_O_O_O_O_O(c__sb, c__code_QMARK_, c__line, c__flush_comments_BANG_, c__depth any) { t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_line = c__line; t.F_flush_comments_BANG_ = c__flush_comments_BANG_; t.F_depth = c__depth }
//line :211:1
func (t *A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A) Invoke_O_O__O(self, l__1 any) any { L1: for {
	var tmp1 bool; var na_892 any; var root_894 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = t.F_line; if linked_895 == nil { na_892 = ifn_896.Invoke_O__O(arg_897) } else { na_892 = linked_895.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_894, arg_897) }; var na_893 any = l__1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_892); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_893) }; tmp2 = tmp3; if tmp2 { var n0_898 int64 = jrt.NN(jrt.Long_Cast(na_892)).LongValue__J(); var n1_899 int64 = jrt.NN(jrt.Long_Cast(na_893)).LongValue__J(); tmp1 = n0_898 < n1_899 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_892); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_893) }; tmp4 = tmp5; if tmp4 { var n0_898_2 float64 = jrt.NN(jrt.Double_Cast(na_892)).DoubleValue__D(); var n1_899_2 float64 = jrt.NN(jrt.Double_Cast(na_893)).DoubleValue__D(); tmp1 = n0_898_2 < n1_899_2 } else { tmp1 = lang.Numbers_Lt_O_O__Z_NoInit(na_892, na_893) } }; if tmp1 {
		lang.IFn_Cast(t.F_flush_comments_BANG_).Invoke__O()
		var tmp6 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp6).Append_String__StringBuilder(Lit_40)
		var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_line); var tmp8 jrt.Number_I; var na_901 any = jrt.NN(lang.Volatile_Cast(t.F_line)).Deref__O(); if jrt.Long_InstanceOf(na_901) { var n0_902 int64 = jrt.NN(jrt.Long_Cast(na_901)).LongValue__J(); if n0_902 == 9223372036854775807 { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_901) } else { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_902 + 1)) } } else { if jrt.Double_InstanceOf(na_901) { var n0_902_2 float64 = jrt.NN(jrt.Double_Cast(na_901)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_902_2 + 1.0)) } else { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_901) } }; jrt.NN(tmp7).Reset_O__O(tmp8)
		var root_903 any = A_arbace_repr_go_layout_A_const_118.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = t.F_code_QMARK_; var arg_907 any = jrt.Boolean_FALSE.Ref(); if linked_904 == nil { ifn_905.Invoke_O_O__O(arg_906, arg_907) } else { linked_904.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_903, arg_906, arg_907) }
//line :212:1
		continue L1 }
//line :211:1
	break L1
}




	var tmp9 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp10 any; var root_873 any = A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var arg_877 any; var root_878 any = A_arbace_repr_go_layout_A_const_117.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any; var na_883 int64 = 2; var na_884 any; var root_885 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = t.F_depth; if linked_886 == nil { na_884 = ifn_887.Invoke_O__O(arg_888) } else { na_884 = linked_886.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_885, arg_888) }; if jrt.Long_InstanceOf(na_884) { var n0_889 int64 = na_883; var n1_890 int64 = jrt.NN(jrt.Long_Cast(na_884)).LongValue__J(); var nr_891 int64 = n0_889 * n1_890; var tmp11 bool; var tmp12 bool; var tmp13 bool; var tmp14 bool; tmp14 = n0_889 == -9223372036854775808; if tmp14 { tmp14 = n1_890 < 0 }; tmp13 = tmp14; tmp12 = !tmp13; if tmp12 { var tmp15 bool; tmp15 = n1_890 == 0; if !tmp15 { tmp15 = nr_891/n1_890 == n0_889 }; tmp12 = tmp15 }; tmp11 = tmp12; if tmp11 { arg_881 = jrt.Long_ValueOf_J__Long_NoInit(nr_891).Ref() } else { arg_881 = lang.Numbers_Multiply_J_O__Number_NoInit(na_883, na_884) } } else { arg_881 = lang.Numbers_Multiply_J_O__Number_NoInit(na_883, na_884) }; var arg_882 any = Lit_9; if linked_879 == nil { arg_877 = ifn_880.Invoke_O_O__O(arg_881, arg_882) } else { arg_877 = linked_879.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_878, arg_881, arg_882) }; if linked_874 == nil { tmp10 = ifn_875.Invoke_O_O__O(arg_876, arg_877) } else { tmp10 = linked_874.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_873, arg_876, arg_877) }; return jrt.NN(tmp9).Append_O__StringBuilder(tmp10).Ref()
}
func A_arbace_repr_go_layout_write_file_emit__1839000121_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_layout_write_file_emit__1839000121_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_file_emit__1839000121_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :219:1
func (t *A_arbace_repr_go_layout_write_file_emit__1839000121_A) Ctor_O_O_O_O(c__newline_to_BANG_, c__sb, c__code_QMARK_, c__depth any) { t.F_newline_to_BANG_ = c__newline_to_BANG_; t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_depth = c__depth }
//line :219:1
func (t *A_arbace_repr_go_layout_write_file_emit__1839000121_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var or__1927000174__auto____2 any; var root_933 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = x__1; if linked_934 == nil { or__1927000174__auto____2 = ifn_935.Invoke_O__O(arg_936) } else { or__1927000174__auto____2 = linked_934.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_933, arg_936) }; if jrt.J2g_Truth(or__1927000174__auto____2) { and__1927000168__auto____2 = or__1927000174__auto____2 } else { var root_937 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = x__1; if linked_938 == nil { and__1927000168__auto____2 = ifn_939.Invoke_O__O(arg_940) } else { and__1927000168__auto____2 = linked_938.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_937, arg_940) } }; if jrt.J2g_Truth(and__1927000168__auto____2) {
		var tmp2 any; var root_941 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = x__1; if linked_942 == nil { tmp2 = ifn_943.Invoke_O__O(arg_944) } else { tmp2 = linked_942.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_941, arg_944) }; if jrt.J2g_Truth(tmp2) { tmp1 = A_arbace_repr_go_layout_A_const_34.Invoke_O__O(x__1) } else { var tmp3 *lang.Keyword = A_arbace_repr_go_layout_A_const_36; tmp1 = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__1)) } } else {
//line :220:1
			tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {

				var tmp4 lang.IFn = lang.IFn_Cast(t.F_newline_to_BANG_); var tmp5 any; var root_954 any = A_arbace_repr_go_layout_A_const_32.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, A_arbace_repr_go_layout_form_line_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = x__1; if linked_955 == nil { tmp5 = ifn_956.Invoke_O__O(arg_957) } else { tmp5 = linked_955.(*A_arbace_repr_go_layout_form_line_A).Invoke_O_O__O(root_954, arg_957) }; tmp4.Invoke_O__O(tmp5) }
	var root_945 any = A_arbace_repr_go_layout_A_const_118.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_945, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_947 lang.IFn; if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any = t.F_code_QMARK_; var arg_949 any = jrt.Boolean_TRUE.Ref(); if linked_946 == nil { ifn_947.Invoke_O_O__O(arg_948, arg_949) } else { linked_946.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_945, arg_948, arg_949) }
//line :219:1
	var p__2 any; var root_950 any = A_arbace_repr_go_layout_A_const_104.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, A_arbace_repr_go_layout_meta_prefix_A_fn_class); var ifn_952 lang.IFn




	if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = x__1; if linked_951 == nil { p__2 = ifn_952.Invoke_O__O(arg_953) } else { p__2 = linked_951.(*A_arbace_repr_go_layout_meta_prefix_A).Invoke_O_O__O(root_950, arg_953) }
	if jrt.J2g_Truth(p__2) { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(p__2) }
	var tmp6 any; var and__1927000168__auto____2_2 any; var root_909 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_911 lang.IFn
	if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = x__1; if linked_910 == nil { and__1927000168__auto____2_2 = ifn_911.Invoke_O__O(arg_912) } else { and__1927000168__auto____2_2 = linked_910.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_909, arg_912) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { var tmp7 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; tmp6 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__1)) } else { tmp6 = and__1927000168__auto____2_2 }
//line :226:1
	if jrt.J2g_Truth(tmp6) {
		var tmp8 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp9 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; return jrt.NN(tmp8).Append_String__StringBuilder(jrt.String_Cast(tmp9.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__1)))).Ref() } else {
//line :226:1
			var tmp10 any; var root_913 any = A_arbace_repr_go_layout_A_const_38.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, A_arbace_repr_go_layout_deref_form_QMARK__A_fn_class); var ifn_915 lang.IFn

			if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = x__1; if linked_914 == nil { tmp10 = ifn_915.Invoke_O__O(arg_916) } else { tmp10 = linked_914.(*A_arbace_repr_go_layout_deref_form_QMARK__A).Invoke_O_O__O(root_913, arg_916) }
//line :226:1
			if jrt.J2g_Truth(tmp10) {

				var tmp11 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp11).Append_String__StringBuilder(Lit_27); var tmp12 lang.IFn = lang.IFn_Cast(self); var tmp13 any; var root_958 any = A_arbace_repr_go_layout_A_const_106.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = x__1; if linked_959 == nil { tmp13 = ifn_960.Invoke_O__O(arg_961) } else { tmp13 = linked_959.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_958, arg_961) }; return tmp12.Invoke_O__O(tmp13) } else {
//line :226:1
					var tmp14 any; var or__1927000174__auto____2_2 any; var root_917 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_919 lang.IFn


					if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = x__1; if linked_918 == nil { or__1927000174__auto____2_2 = ifn_919.Invoke_O__O(arg_920) } else { or__1927000174__auto____2_2 = linked_918.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_917, arg_920) }; if jrt.J2g_Truth(or__1927000174__auto____2_2) { tmp14 = or__1927000174__auto____2_2 } else { var root_921 any = A_arbace_repr_go_layout_A_const_25.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = x__1; if linked_922 == nil { tmp14 = ifn_923.Invoke_O__O(arg_924) } else { tmp14 = linked_922.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_921, arg_924) } }
//line :226:1
					if jrt.J2g_Truth(tmp14) {



						var tmp15 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp16 *jrt.String; var tmp17 any; var root_962 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = x__1; if linked_963 == nil { tmp17 = ifn_964.Invoke_O__O(arg_965) } else { tmp17 = linked_963.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_962, arg_965) }; if jrt.J2g_Truth(tmp17) { tmp16 = Lit_28 } else { tmp16 = Lit_30 }; jrt.NN(tmp15).Append_String__StringBuilder(tmp16)
						var tmp18 *lang.Volatile = lang.Volatile_Cast(t.F_depth); var tmp19 jrt.Number_I; var na_966 any = jrt.NN(lang.Volatile_Cast(t.F_depth)).Deref__O(); if jrt.Long_InstanceOf(na_966) { var n0_967 int64 = jrt.NN(jrt.Long_Cast(na_966)).LongValue__J(); if n0_967 == 9223372036854775807 { tmp19 = lang.Numbers_Inc_O__Number_NoInit(na_966) } else { tmp19 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_967 + 1)) } } else { if jrt.Double_InstanceOf(na_966) { var n0_967_2 float64 = jrt.NN(jrt.Double_Cast(na_966)).DoubleValue__D(); tmp19 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_967_2 + 1.0)) } else { tmp19 = lang.Numbers_Inc_O__Number_NoInit(na_966) } }; jrt.NN(tmp18).Reset_O__O(tmp19)
//line :226:1
						var seq_1839000122__2 any; var root_968 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_970 lang.IFn





						if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any; var root_972 any = A_arbace_repr_go_layout_A_const_102.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_974 lang.IFn; if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any = A_arbace_repr_go_layout_A_const_103.GetRawRoot__O(); var arg_976 any = x__1; if linked_973 == nil { arg_971 = ifn_974.Invoke_O_O__O(arg_975, arg_976) } else { arg_971 = linked_973.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_972, arg_975, arg_976) }; if linked_969 == nil { seq_1839000122__2 = ifn_970.Invoke_O__O(arg_971) } else { seq_1839000122__2 = linked_969.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_968, arg_971) }
//line :226:1
						var chunk_1839000123__3 any; var count_1839000124__4 int64 = 0; var i_1839000125__5 int64 = 0; L1: for {





							if lang.Numbers_Lt_J_J__Z_NoInit(i_1839000125__5, count_1839000124__4) { var vec__1839000126__6 any = lang.Indexed_Cast(chunk_1839000123__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1839000125__5)); var i__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000126__6, lang.RT_IntCast_J__I_NoInit(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000126__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp20 any; var and__1927000168__auto____9 bool; var na_995 any = i__7
								if jrt.Long_InstanceOf(na_995) { var n0_996 int64 = jrt.NN(jrt.Long_Cast(na_995)).LongValue__J(); and__1927000168__auto____9 = n0_996 > 0 } else { if jrt.Double_InstanceOf(na_995) { var n0_996_2 float64 = jrt.NN(jrt.Double_Cast(na_995)).DoubleValue__D(); and__1927000168__auto____9 = n0_996_2 > 0.0 } else { and__1927000168__auto____9 = lang.Numbers_IsPos_O__Z_NoInit(na_995) } }; if and__1927000168__auto____9 {
									var root_997 any = A_arbace_repr_go_layout_A_const_37.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any; var tmp21 any; var root_1001 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1001, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_1003 lang.IFn; if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = c__8; if linked_1002 == nil { tmp21 = ifn_1003.Invoke_O__O(arg_1004) } else { tmp21 = linked_1002.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_1001, arg_1004) }; if jrt.J2g_Truth(tmp21) { arg_1000 = A_arbace_repr_go_layout_A_const_34.Invoke_O__O(c__8) } else { var and__1927000168__auto____10 any; var root_1005 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_1007 lang.IFn; if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any = c__8; if linked_1006 == nil { and__1927000168__auto____10 = ifn_1007.Invoke_O__O(arg_1008) } else { and__1927000168__auto____10 = linked_1006.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_1005, arg_1008) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp22 *lang.Keyword = A_arbace_repr_go_layout_A_const_36; arg_1000 = tmp22.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(c__8)) } else { arg_1000 = and__1927000168__auto____10 } }; if linked_998 == nil { tmp20 = ifn_999.Invoke_O__O(arg_1000) } else { tmp20 = linked_998.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_997, arg_1000) } } else {
//line :233:1
										tmp20 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9).Ref() }; if jrt.J2g_Truth(tmp20) {

											var tmp23 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp23).Append_String__StringBuilder(Lit_9) }
								lang.IFn_Cast(self).Invoke_O__O(c__8)
//line :232:1
								seq_1839000122__2, chunk_1839000123__3, count_1839000124__4, i_1839000125__5 = seq_1839000122__2, chunk_1839000123__3, count_1839000124__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1839000125__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_977 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_977, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_979 lang.IFn; if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any = seq_1839000122__2; if linked_978 == nil { temp__1927000414__auto____6 = ifn_979.Invoke_O__O(arg_980) } else { temp__1927000414__auto____6 = linked_978.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_977, arg_980) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1839000122__7 any = temp__1927000414__auto____6; var tmp24 any; var root_981 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_981, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_983 lang.IFn; if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = seq_1839000122__7; if linked_982 == nil { tmp24 = ifn_983.Invoke_O__O(arg_984) } else { tmp24 = linked_982.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_981, arg_984) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____8 any; var root_985 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = seq_1839000122__7; if linked_986 == nil { c__1927000678__auto____8 = ifn_987.Invoke_O__O(arg_988) } else { c__1927000678__auto____8 = linked_986.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_985, arg_988) }; var tmp25 any; var root_1009 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = seq_1839000122__7; if linked_1010 == nil { tmp25 = ifn_1011.Invoke_O__O(arg_1012) } else { tmp25 = linked_1010.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1009, arg_1012) }; seq_1839000122__2, chunk_1839000123__3, count_1839000124__4, i_1839000125__5 = tmp25, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1839000129__8 any; var root_989 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = seq_1839000122__7; if linked_990 == nil { vec__1839000129__8 = ifn_991.Invoke_O__O(arg_992) } else { vec__1839000129__8 = linked_990.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_989, arg_992) }; var i__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000129__8, lang.RT_IntCast_J__I_NoInit(0), nil); var c__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000129__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp26 any; var and__1927000168__auto____11 bool; var na_1013 any = i__9
									if jrt.Long_InstanceOf(na_1013) { var n0_1014 int64 = jrt.NN(jrt.Long_Cast(na_1013)).LongValue__J(); and__1927000168__auto____11 = n0_1014 > 0 } else { if jrt.Double_InstanceOf(na_1013) { var n0_1014_2 float64 = jrt.NN(jrt.Double_Cast(na_1013)).DoubleValue__D(); and__1927000168__auto____11 = n0_1014_2 > 0.0 } else { and__1927000168__auto____11 = lang.Numbers_IsPos_O__Z_NoInit(na_1013) } }; if and__1927000168__auto____11 {
										var root_1015 any = A_arbace_repr_go_layout_A_const_37.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1017 lang.IFn; if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any; var tmp27 any; var root_1019 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_1021 lang.IFn; if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any = c__10; if linked_1020 == nil { tmp27 = ifn_1021.Invoke_O__O(arg_1022) } else { tmp27 = linked_1020.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_1019, arg_1022) }; if jrt.J2g_Truth(tmp27) { arg_1018 = A_arbace_repr_go_layout_A_const_34.Invoke_O__O(c__10) } else { var and__1927000168__auto____12 any; var root_1023 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1023, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_1025 lang.IFn; if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any = c__10; if linked_1024 == nil { and__1927000168__auto____12 = ifn_1025.Invoke_O__O(arg_1026) } else { and__1927000168__auto____12 = linked_1024.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_1023, arg_1026) }; if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp28 *lang.Keyword = A_arbace_repr_go_layout_A_const_36; arg_1018 = tmp28.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(c__10)) } else { arg_1018 = and__1927000168__auto____12 } }; if linked_1016 == nil { tmp26 = ifn_1017.Invoke_O__O(arg_1018) } else { tmp26 = linked_1016.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1015, arg_1018) } } else {
//line :233:1
											tmp26 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() }; if jrt.J2g_Truth(tmp26) {

												var tmp29 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp29).Append_String__StringBuilder(Lit_9) }
									lang.IFn_Cast(self).Invoke_O__O(c__10)
//line :232:1
									var tmp30 any; var root_1027 any = A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = seq_1839000122__7; if linked_1028 == nil { tmp30 = ifn_1029.Invoke_O__O(arg_1030) } else { tmp30 = linked_1028.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1027, arg_1030) }; seq_1839000122__2, chunk_1839000123__3, count_1839000124__4, i_1839000125__5 = tmp30, nil, 0, 0; continue L1 } } }
//line :226:1
							break L1
						}









						var tmp31 *lang.Volatile = lang.Volatile_Cast(t.F_depth); var tmp32 jrt.Number_I; var na_993 any = jrt.NN(lang.Volatile_Cast(t.F_depth)).Deref__O(); if jrt.Long_InstanceOf(na_993) { var n0_994 int64 = jrt.NN(jrt.Long_Cast(na_993)).LongValue__J(); if n0_994 == -9223372036854775808 { tmp32 = lang.Numbers_Dec_O__Number_NoInit(na_993) } else { tmp32 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_994 - 1)) } } else { if jrt.Double_InstanceOf(na_993) { var n0_994_2 float64 = jrt.NN(jrt.Double_Cast(na_993)).DoubleValue__D(); tmp32 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_994_2 - 1.0)) } else { tmp32 = lang.Numbers_Dec_O__Number_NoInit(na_993) } }; jrt.NN(tmp31).Reset_O__O(tmp32)
						var tmp33 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp34 *jrt.String; var tmp35 any; var root_925 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = x__1; if linked_926 == nil { tmp35 = ifn_927.Invoke_O__O(arg_928) } else { tmp35 = linked_926.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_925, arg_928) }; if jrt.J2g_Truth(tmp35) { tmp34 = Lit_29 } else { tmp34 = Lit_31 }; return jrt.NN(tmp33).Append_String__StringBuilder(tmp34).Ref() } else {
//line :226:1
							if A_arbace_repr_go_layout_A_const_41 != nil {












								var tmp36 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp37 any; var root_929 any = A_arbace_repr_go_layout_A_const_108.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, A_arbace_repr_go_layout_atom_text_A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = x__1; if linked_930 == nil { tmp37 = ifn_931.Invoke_O__O(arg_932) } else { tmp37 = linked_930.(*A_arbace_repr_go_layout_atom_text_A).Invoke_O_O__O(root_929, arg_932) }; return jrt.NN(tmp36).Append_String__StringBuilder(jrt.String_Cast(tmp37)).Ref() } else {
//line :226:1
									return nil
								}
						}
				}
		}
}




















func A_arbace_repr_go_layout_write_package_A_New() *A_arbace_repr_go_layout_write_package_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_repr_go_layout_write_package_A) Ctor() {}
//line :252:1
func (t *A_arbace_repr_go_layout_write_package_A) Invoke_O_O_O_O__O(self, ns_sym__0, pkg_form__1, loads__2 any) any { var vec__1839000138__4 any = pkg_form__1; var seq__1839000139__5 any; var root_1099 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1101 lang.IFn; if


	linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = vec__1839000138__4; if linked_1100 == nil { seq__1839000139__5 = ifn_1101.Invoke_O__O(arg_1102) } else { seq__1839000139__5 = linked_1100.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1099, arg_1102) }; var first__1839000140__6 any; var root_1103 any = /*line :252:1*/A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1105 lang.IFn; if


	linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = seq__1839000139__5; if linked_1104 == nil { first__1839000140__6 = ifn_1105.Invoke_O__O(arg_1106) } else { first__1839000140__6 = linked_1104.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1103, arg_1106) }; var seq__1839000139__7 any; var root_1107 any = /*line :252:1*/A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1109 lang.IFn; if


	linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = seq__1839000139__5; if linked_1108 == nil { seq__1839000139__7 = ifn_1109.Invoke_O__O(arg_1110) } else { seq__1839000139__7 = linked_1108.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1107, arg_1110) }; var head__8 any = first__1839000140__6; var first__1839000140__9 any; var root_1111 any = /*line :252:1*/A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1113 lang.IFn; if


	linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = seq__1839000139__7; if linked_1112 == nil { first__1839000140__9 = ifn_1113.Invoke_O__O(arg_1114) } else { first__1839000140__9 = linked_1112.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1111, arg_1114) }; var seq__1839000139__10 any; var root_1115 any = /*line :252:1*/A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1117 lang.IFn; if


	linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = seq__1839000139__7; if linked_1116 == nil { seq__1839000139__10 = ifn_1117.Invoke_O__O(arg_1118) } else { seq__1839000139__10 = linked_1116.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1115, arg_1118) }; var nm__11 any = first__1839000140__9; var opts__12 any = seq__1839000139__10; var tmp1 /*line :252:1*/*jrt.RefArray = jrt.ConstRefArray("[0,10,s4:(ns ns35:\n  (:require [arbace.go :as go]))\n\ns1:(ns1: nns3:)\n\nn", []*jrt.Class{jrt.String_class}); var tmp2 any; var root_1119 any = A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1121 lang.IFn; if





	linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var arg_1123 any; var iter__1927001039__auto____23 any; var tmp3 any = A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A_New(); var tmp4 *jrt.Class; var fncls__1190 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A_fn_class; if fncls__1190 == nil { var fncls__1190d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A_fn_class = fncls__1190d; tmp4 = fncls__1190d } else { tmp4 = fncls__1190 }; iter__1927001039__auto____23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____23); var tmp6 any; var root_1191 any = A_arbace_repr_go_layout_A_const_120.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any = A_arbace_repr_go_layout_A_const_111; var arg_1195 any = opts__12; if linked_1192 == nil { tmp6 = ifn_1193.Invoke_O_O__O(arg_1194, arg_1195) } else { tmp6 = linked_1192.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_1191, arg_1194, arg_1195) }; arg_1123 = tmp5.Invoke_O__O(tmp6); if linked_1120 == nil { tmp2 = ifn_1121.Invoke_O_O__O(arg_1122, arg_1123) } else { tmp2 = linked_1120.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1119, arg_1122, arg_1123) }; var tmp7 any = tmp2; var tmp8 any; var root_1196 any = /*line :256:1*/A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1198 lang.IFn; if



	linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var arg_1200 any; var iter__1927001039__auto____23_2 any; var tmp9 any = A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A_New(); var tmp10 *jrt.Class; var fncls__1267 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A_fn_class; if fncls__1267 == nil { var fncls__1267d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A_fn_class = fncls__1267d; tmp10 = fncls__1267d } else { tmp10 = fncls__1267 }; iter__1927001039__auto____23_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); arg_1200 = lang.IFn_Cast(iter__1927001039__auto____23_2).Invoke_O__O(loads__2); if linked_1197 == nil { tmp8 = ifn_1198.Invoke_O_O__O(arg_1199, arg_1200) } else { tmp8 = linked_1197.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1196, arg_1199, arg_1200) }; return /*line :256:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, ns_sym__0, nil, nil, head__8, nil, nm__11, tmp7, nil, tmp8)).Ref() }

func A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A_New() *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A) Ctor() {}
//line :258:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A) Invoke_O_O__O(self, s__1839000142__1 any) any { var tmp1 any = A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A_New_O_O(self, s__1839000142__1); var tmp2 *jrt.Class; var fncls__1189 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A_fn_class; if fncls__1189 == nil { var fncls__1189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A_fn_class = fncls__1189d; tmp2 = fncls__1189d } else { tmp2 = fncls__1189 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :258:1
func A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A{}; t.Ctor_O_O(p0, p1); return t }
//line :258:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A) Ctor_O_O(c__iter__1839000141, c__s__1839000142 any) { t.F_iter__1839000141 = c__iter__1839000141; t.F_s__1839000142 = c__s__1839000142 }
//line :258:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A) Invoke_O__O(self any) any { { var s__1839000142__1 any; var t_ any = t.F_s__1839000142; t.F_s__1839000142 = nil; s__1839000142__1 = t_; for { var temp__1927000414__auto____2 any; var root_1124 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1126 lang.IFn; if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any = s__1839000142__1; if linked_1125 == nil { temp__1927000414__auto____2 = ifn_1126.Invoke_O__O(arg_1127) } else { temp__1927000414__auto____2 = linked_1125.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1124, arg_1127) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000142__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1128 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1130 lang.IFn; if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = s__1839000142__3; if linked_1129 == nil { tmp1 = ifn_1130.Invoke_O__O(arg_1131) } else { tmp1 = linked_1129.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1128, arg_1131) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1132 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_1133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1132, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1134 lang.IFn; if linked_1133 == nil { ifn_1134 = lang.IFn_Cast(root_1132) } else { ifn_1134 = nil }; var arg_1135 any = s__1839000142__3; if linked_1133 == nil { c__1927001037__auto____4 = ifn_1134.Invoke_O__O(arg_1135) } else { c__1927001037__auto____4 = linked_1133.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1132, arg_1135) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000144__6 any; var root_1136 any = A_arbace_repr_go_layout_A_const_83.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1136, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1138 lang.IFn; if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1137 == nil { b__1839000144__6 = ifn_1138.Invoke_O__O(arg_1139) } else { b__1839000144__6 = linked_1137.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1136, arg_1139) }; var tmp2 any = A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A_New_O_I_O(b__1839000144__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1149 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A_fn_class; if fncls__1149 == nil { var fncls__1149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A_fn_class = fncls__1149d; tmp3 = fncls__1149d } else { tmp3 = fncls__1149 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1150 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any; var root_1155 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1157 lang.IFn; if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any = b__1839000144__6; if linked_1156 == nil { arg_1153 = ifn_1157.Invoke_O__O(arg_1158) } else { arg_1153 = linked_1156.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1155, arg_1158) }; var arg_1154 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000141); var tmp5 any; var root_1159 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1161 lang.IFn; if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = s__1839000142__3; if linked_1160 == nil { tmp5 = ifn_1161.Invoke_O__O(arg_1162) } else { tmp5 = linked_1160.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1159, arg_1162) }; arg_1154 = tmp4.Invoke_O__O(tmp5); if linked_1151 == nil { return ifn_1152.Invoke_O_O__O(arg_1153, arg_1154) } else { return linked_1151.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1150, arg_1153, arg_1154) } } else { var root_1163 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any; var root_1168 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1170 lang.IFn; if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var arg_1171 any = b__1839000144__6; if linked_1169 == nil { arg_1166 = ifn_1170.Invoke_O__O(arg_1171) } else { arg_1166 = linked_1169.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1168, arg_1171) }; var arg_1167 any; if linked_1164 == nil { return ifn_1165.Invoke_O_O__O(arg_1166, arg_1167) } else { return linked_1164.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1163, arg_1166, arg_1167) } } } else { var vec__1839000152__4 any; var root_1172 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1174 lang.IFn; if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any = s__1839000142__3; if linked_1173 == nil { vec__1839000152__4 = ifn_1174.Invoke_O__O(arg_1175) } else { vec__1839000152__4 = linked_1173.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1172, arg_1175) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000152__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000152__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1176 any = A_arbace_repr_go_layout_A_const_88.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1178 lang.IFn; if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_48, nil, Lit_9, nil); var tmp7 any; var root_1181 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, A_arbace_repr_go_layout_text_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = v__6; if linked_1182 == nil { tmp7 = ifn_1183.Invoke_O__O(arg_1184) } else { tmp7 = linked_1182.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_1181, arg_1184) }; arg_1179 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, k__5, nil, tmp7)).Ref(); var arg_1180 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1839000141); var tmp9 any; var root_1185 any = A_arbace_repr_go_layout_A_const_89.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = s__1839000142__3; if linked_1186 == nil { tmp9 = ifn_1187.Invoke_O__O(arg_1188) } else { tmp9 = linked_1186.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1185, arg_1188) }; arg_1180 = tmp8.Invoke_O__O(tmp9); if linked_1177 == nil { return ifn_1178.Invoke_O_O__O(arg_1179, arg_1180) } else { return linked_1177.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1176, arg_1179, arg_1180) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :258:1
func A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :258:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A) Ctor_O_I_O(c__b__1839000144 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000144 = c__b__1839000144; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :258:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A) Invoke_O__O(self any) any { { var i__1839000143__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000143__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1839000148__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000143__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000148__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000148__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1140 any = A_arbace_repr_go_layout_A_const_84.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1140, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = t.F_b__1839000144; var arg_1144 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_48, nil, Lit_9, nil); var tmp3 any; var root_1145 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_1146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1145, A_arbace_repr_go_layout_text_A_fn_class); var ifn_1147 lang.IFn; if linked_1146 == nil { ifn_1147 = lang.IFn_Cast(root_1145) } else { ifn_1147 = nil }; var arg_1148 any = v__4; if linked_1146 == nil { tmp3 = ifn_1147.Invoke_O__O(arg_1148) } else { tmp3 = linked_1146.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_1145, arg_1148) }; arg_1144 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, k__3, nil, tmp3)).Ref(); if linked_1141 == nil { ifn_1142.Invoke_O_O__O(arg_1143, arg_1144) } else { linked_1141.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1140, arg_1143, arg_1144) }; i__1839000143__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000143__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A_New() *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A) Ctor() {}
//line :260:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A) Invoke_O_O__O(self, s__1839000158__1 any) any { var tmp1 any = A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A_New_O_O(s__1839000158__1, self); var tmp2 *jrt.Class; var fncls__1266 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A_fn_class; if fncls__1266 == nil { var fncls__1266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A_fn_class = fncls__1266d; tmp2 = fncls__1266d } else { tmp2 = fncls__1266 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :260:1
func A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A{}; t.Ctor_O_O(p0, p1); return t }
//line :260:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A) Ctor_O_O(c__s__1839000158, c__iter__1839000157 any) { t.F_s__1839000158 = c__s__1839000158; t.F_iter__1839000157 = c__iter__1839000157 }
//line :260:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A) Invoke_O__O(self any) any { { var s__1839000158__1 any; var t_ any = t.F_s__1839000158; t.F_s__1839000158 = nil; s__1839000158__1 = t_; for { var temp__1927000414__auto____2 any; var root_1201 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1203 lang.IFn; if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = s__1839000158__1; if linked_1202 == nil { temp__1927000414__auto____2 = ifn_1203.Invoke_O__O(arg_1204) } else { temp__1927000414__auto____2 = linked_1202.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1201, arg_1204) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000158__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1205 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = s__1839000158__3; if linked_1206 == nil { tmp1 = ifn_1207.Invoke_O__O(arg_1208) } else { tmp1 = linked_1206.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1205, arg_1208) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1209 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = s__1839000158__3; if linked_1210 == nil { c__1927001037__auto____4 = ifn_1211.Invoke_O__O(arg_1212) } else { c__1927001037__auto____4 = linked_1210.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1209, arg_1212) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000160__6 any; var root_1213 any = A_arbace_repr_go_layout_A_const_83.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1214 == nil { b__1839000160__6 = ifn_1215.Invoke_O__O(arg_1216) } else { b__1839000160__6 = linked_1214.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1213, arg_1216) }; var tmp2 any = A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A_New_O_I_O(b__1839000160__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1226 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A_fn_class; if fncls__1226 == nil { var fncls__1226d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A_fn_class = fncls__1226d; tmp3 = fncls__1226d } else { tmp3 = fncls__1226 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1227 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1227, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1229 lang.IFn; if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any; var root_1232 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = b__1839000160__6; if linked_1233 == nil { arg_1230 = ifn_1234.Invoke_O__O(arg_1235) } else { arg_1230 = linked_1233.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1232, arg_1235) }; var arg_1231 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000157); var tmp5 any; var root_1236 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = s__1839000158__3; if linked_1237 == nil { tmp5 = ifn_1238.Invoke_O__O(arg_1239) } else { tmp5 = linked_1237.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1236, arg_1239) }; arg_1231 = tmp4.Invoke_O__O(tmp5); if linked_1228 == nil { return ifn_1229.Invoke_O_O__O(arg_1230, arg_1231) } else { return linked_1228.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1227, arg_1230, arg_1231) } } else { var root_1240 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any; var root_1245 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = b__1839000160__6; if linked_1246 == nil { arg_1243 = ifn_1247.Invoke_O__O(arg_1248) } else { arg_1243 = linked_1246.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1245, arg_1248) }; var arg_1244 any; if linked_1241 == nil { return ifn_1242.Invoke_O_O__O(arg_1243, arg_1244) } else { return linked_1241.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1240, arg_1243, arg_1244) } } } else { var l__4 any; var root_1249 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1251 lang.IFn; if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any = s__1839000158__3; if linked_1250 == nil { l__4 = ifn_1251.Invoke_O__O(arg_1252) } else { l__4 = linked_1250.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1249, arg_1252) }; var root_1253 any = A_arbace_repr_go_layout_A_const_88.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1255 lang.IFn; if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_51, nil, Lit_52); var tmp7 any; var root_1258 any = A_arbace_repr_go_layout_A_const_92.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1258, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any = l__4; if linked_1259 == nil { tmp7 = ifn_1260.Invoke_O__O(arg_1261) } else { tmp7 = linked_1259.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_1258, arg_1261) }; arg_1256 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil)).Ref(); var arg_1257 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1839000157); var tmp9 any; var root_1262 any = A_arbace_repr_go_layout_A_const_89.GetRawRoot__O(); var linked_1263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1262, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1264 lang.IFn; if linked_1263 == nil { ifn_1264 = lang.IFn_Cast(root_1262) } else { ifn_1264 = nil }; var arg_1265 any = s__1839000158__3; if linked_1263 == nil { tmp9 = ifn_1264.Invoke_O__O(arg_1265) } else { tmp9 = linked_1263.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1262, arg_1265) }; arg_1257 = tmp8.Invoke_O__O(tmp9); if linked_1254 == nil { return ifn_1255.Invoke_O_O__O(arg_1256, arg_1257) } else { return linked_1254.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1253, arg_1256, arg_1257) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :260:1
func A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :260:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A) Ctor_O_I_O(c__b__1839000160 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000160 = c__b__1839000160; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :260:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A) Invoke_O__O(self any) any { { var i__1839000159__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000159__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000159__1)); var root_1217 any = A_arbace_repr_go_layout_A_const_84.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = t.F_b__1839000160; var arg_1221 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_51, nil, Lit_52); var tmp3 any; var root_1222 any = A_arbace_repr_go_layout_A_const_92.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1222, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_1224 lang.IFn; if linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 any = l__2; if linked_1223 == nil { tmp3 = ifn_1224.Invoke_O__O(arg_1225) } else { tmp3 = linked_1223.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_1222, arg_1225) }; arg_1221 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref(); if linked_1218 == nil { ifn_1219.Invoke_O_O__O(arg_1220, arg_1221) } else { linked_1218.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1217, arg_1220, arg_1221) }; i__1839000159__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000159__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



































type A_arbace_repr_go_layout_A struct{ jrt.Object }

var A_arbace_repr_go_layout_A_const_pool *jrt.RefArray

var A_arbace_repr_go_layout_A_const_0 *lang.Var

var A_arbace_repr_go_layout_A_const_1 any

var A_arbace_repr_go_layout_A_const_2 any

var A_arbace_repr_go_layout_A_const_3 *lang.Var

var A_arbace_repr_go_layout_A_const_4 any

var A_arbace_repr_go_layout_A_const_5 *lang.Var

var A_arbace_repr_go_layout_A_const_6 *lang.Var

var A_arbace_repr_go_layout_A_const_7 *lang.Var

var A_arbace_repr_go_layout_A_const_8 *lang.Var

var A_arbace_repr_go_layout_A_const_9 any

var A_arbace_repr_go_layout_A_const_10 *lang.Var

var A_arbace_repr_go_layout_A_const_11 *lang.Var

var A_arbace_repr_go_layout_A_const_12 *lang.Var

var A_arbace_repr_go_layout_A_const_13 *lang.Var

var A_arbace_repr_go_layout_A_const_14 *lang.Keyword

var A_arbace_repr_go_layout_A_const_15 *lang.Var

var A_arbace_repr_go_layout_A_const_16 *lang.Keyword

var A_arbace_repr_go_layout_A_const_17 *lang.Var

var A_arbace_repr_go_layout_A_const_18 *lang.Keyword

var A_arbace_repr_go_layout_A_const_19 *lang.Var

var A_arbace_repr_go_layout_A_const_20 *lang.Var

var A_arbace_repr_go_layout_A_const_21 *lang.Var

var A_arbace_repr_go_layout_A_const_22 *lang.Var

var A_arbace_repr_go_layout_A_const_23 *lang.Var

var A_arbace_repr_go_layout_A_const_24 any

var A_arbace_repr_go_layout_A_const_25 *lang.Var

var A_arbace_repr_go_layout_A_const_26 *lang.Keyword

var A_arbace_repr_go_layout_A_const_27 *lang.Var

var A_arbace_repr_go_layout_A_const_28 *lang.Keyword

var A_arbace_repr_go_layout_A_const_29 *lang.Var

var A_arbace_repr_go_layout_A_const_30 *lang.Var

var A_arbace_repr_go_layout_A_const_31 *lang.Var

var A_arbace_repr_go_layout_A_const_32 *lang.Var

var A_arbace_repr_go_layout_A_const_33 *lang.Var

var A_arbace_repr_go_layout_A_const_34 *lang.Keyword

var A_arbace_repr_go_layout_A_const_35 *lang.Var

var A_arbace_repr_go_layout_A_const_36 *lang.Keyword

var A_arbace_repr_go_layout_A_const_37 *lang.Var

var A_arbace_repr_go_layout_A_const_38 *lang.Var

var A_arbace_repr_go_layout_A_const_39 *lang.Var

var A_arbace_repr_go_layout_A_const_40 *lang.Keyword

var A_arbace_repr_go_layout_A_const_41 *lang.Keyword

var A_arbace_repr_go_layout_A_const_42 *lang.Var

var A_arbace_repr_go_layout_A_const_43 *lang.Var

var A_arbace_repr_go_layout_A_const_44 *lang.Keyword

var A_arbace_repr_go_layout_A_const_45 *lang.Var

var A_arbace_repr_go_layout_A_const_46 *lang.Var

var A_arbace_repr_go_layout_A_const_47 any

var A_arbace_repr_go_layout_A_const_48 *lang.Var

var A_arbace_repr_go_layout_A_const_49 *lang.Var

var A_arbace_repr_go_layout_A_const_50 *lang.Keyword

var A_arbace_repr_go_layout_A_const_51 *lang.Keyword

var A_arbace_repr_go_layout_A_const_52 *lang.Keyword

var A_arbace_repr_go_layout_A_const_53 *lang.Var

var A_arbace_repr_go_layout_A_const_54 *lang.Var

var A_arbace_repr_go_layout_A_const_55 *lang.Var

var A_arbace_repr_go_layout_A_const_56 *lang.Var

var A_arbace_repr_go_layout_A_const_57 *lang.Var

var A_arbace_repr_go_layout_A_const_58 *lang.Var

var A_arbace_repr_go_layout_A_const_59 *lang.Var

var A_arbace_repr_go_layout_A_const_60 *lang.Var

var A_arbace_repr_go_layout_A_const_61 *lang.Var

var A_arbace_repr_go_layout_A_const_62 *lang.Var

var A_arbace_repr_go_layout_A_const_63 *lang.Var

var A_arbace_repr_go_layout_A_const_64 *lang.Keyword

var A_arbace_repr_go_layout_A_const_65 *lang.Keyword

var A_arbace_repr_go_layout_A_const_66 *lang.Keyword

var A_arbace_repr_go_layout_A_const_67 *lang.Keyword

var A_arbace_repr_go_layout_A_const_68 *lang.Var

var A_arbace_repr_go_layout_A_const_69 *lang.Var

var A_arbace_repr_go_layout_A_const_70 *lang.Var

var A_arbace_repr_go_layout_A_const_71 *lang.Var

var A_arbace_repr_go_layout_A_const_72 *lang.Var

var A_arbace_repr_go_layout_A_const_73 *lang.Var

var A_arbace_repr_go_layout_A_const_74 *lang.Keyword

var A_arbace_repr_go_layout_A_const_75 *lang.Var

var A_arbace_repr_go_layout_A_const_76 *lang.Var

var A_arbace_repr_go_layout_A_const_77 *lang.Var

var A_arbace_repr_go_layout_A_const_78 any

var A_arbace_repr_go_layout_A_const_79 *lang.Var

var A_arbace_repr_go_layout_A_const_80 *lang.Keyword

var A_arbace_repr_go_layout_A_const_81 *lang.Var

var A_arbace_repr_go_layout_A_const_82 *lang.Var

var A_arbace_repr_go_layout_A_const_83 *lang.Var

var A_arbace_repr_go_layout_A_const_84 *lang.Var

var A_arbace_repr_go_layout_A_const_85 *lang.Var

var A_arbace_repr_go_layout_A_const_86 *lang.Var

var A_arbace_repr_go_layout_A_const_87 *lang.Var

var A_arbace_repr_go_layout_A_const_88 *lang.Var

var A_arbace_repr_go_layout_A_const_89 *lang.Var

var A_arbace_repr_go_layout_A_const_90 *lang.Keyword

var A_arbace_repr_go_layout_A_const_91 *lang.Var

var A_arbace_repr_go_layout_A_const_92 *lang.Var

var A_arbace_repr_go_layout_A_const_93 *lang.Var

var A_arbace_repr_go_layout_A_const_94 *lang.Var

var A_arbace_repr_go_layout_A_const_95 *lang.Var

var A_arbace_repr_go_layout_A_const_96 *lang.Var

var A_arbace_repr_go_layout_A_const_97 *lang.Var

var A_arbace_repr_go_layout_A_const_98 *lang.Var

var A_arbace_repr_go_layout_A_const_99 *lang.Var

var A_arbace_repr_go_layout_A_const_100 *lang.Keyword

var A_arbace_repr_go_layout_A_const_101 any

var A_arbace_repr_go_layout_A_const_102 *lang.Var

var A_arbace_repr_go_layout_A_const_103 *lang.Var

var A_arbace_repr_go_layout_A_const_104 *lang.Var

var A_arbace_repr_go_layout_A_const_105 *lang.Var

var A_arbace_repr_go_layout_A_const_106 *lang.Var

var A_arbace_repr_go_layout_A_const_107 *lang.Var

var A_arbace_repr_go_layout_A_const_108 *lang.Var

var A_arbace_repr_go_layout_A_const_109 *lang.Var

var A_arbace_repr_go_layout_A_const_110 *lang.Var

var A_arbace_repr_go_layout_A_const_111 any

var A_arbace_repr_go_layout_A_const_112 *lang.Var

var A_arbace_repr_go_layout_A_const_113 *lang.Var

var A_arbace_repr_go_layout_A_const_114 *lang.Var

var A_arbace_repr_go_layout_A_const_115 any

var A_arbace_repr_go_layout_A_const_116 *lang.Var

var A_arbace_repr_go_layout_A_const_117 *lang.Var

var A_arbace_repr_go_layout_A_const_118 *lang.Var

var A_arbace_repr_go_layout_A_const_119 *lang.Var

var A_arbace_repr_go_layout_A_const_120 *lang.Var

var A_arbace_repr_go_layout_A_init jrt.ClassInit

func A_arbace_repr_go_layout_A_Init() { if !A_arbace_repr_go_layout_A_init.Done() { A_arbace_repr_go_layout_A_init.Run(A_arbace_repr_go_layout_A_clinit) } }

func A_arbace_repr_go_layout_A_clinit() { A_arbace_repr_go_layout_A_clinit_p0(); A_arbace_repr_go_layout_A_clinit_p1(); A_arbace_repr_go_layout_A_clinit_p2(); A_arbace_repr_go_layout_A_clinit_p3(); A_arbace_repr_go_layout_A_clinit_p4(); A_arbace_repr_go_layout_A_clinit_p5(); A_arbace_repr_go_layout_A_clinit_p6(); A_arbace_repr_go_layout_A_clinit_p7(); A_arbace_repr_go_layout_A_clinit_p8(); A_arbace_repr_go_layout_A_clinit_p9(); A_arbace_repr_go_layout_A_clinit_p10() }

func A_arbace_repr_go_layout_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_layout_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 155); A_arbace_repr_go_layout_A_const_0 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[34]); A_arbace_repr_go_layout_A_const_1 = A_arbace_repr_go_layout_A_const_pool.A[35]; A_arbace_repr_go_layout_A_const_2 = A_arbace_repr_go_layout_A_const_pool.A[36]; A_arbace_repr_go_layout_A_const_3 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[37]); A_arbace_repr_go_layout_A_const_4 = A_arbace_repr_go_layout_A_const_pool.A[38]; A_arbace_repr_go_layout_A_const_5 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[39]); A_arbace_repr_go_layout_A_const_6 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[40]); A_arbace_repr_go_layout_A_const_7 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[41]); A_arbace_repr_go_layout_A_const_8 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[42]); A_arbace_repr_go_layout_A_const_9 = A_arbace_repr_go_layout_A_const_pool.A[43]; A_arbace_repr_go_layout_A_const_10 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[44]); A_arbace_repr_go_layout_A_const_11 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[45]) }

func A_arbace_repr_go_layout_A_clinit_p1() { A_arbace_repr_go_layout_A_const_12 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[46]); A_arbace_repr_go_layout_A_const_13 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[47]); A_arbace_repr_go_layout_A_const_14 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[48]); A_arbace_repr_go_layout_A_const_15 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[49]); A_arbace_repr_go_layout_A_const_16 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[50]); A_arbace_repr_go_layout_A_const_17 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[51]); A_arbace_repr_go_layout_A_const_18 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[52]); A_arbace_repr_go_layout_A_const_19 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[53]); A_arbace_repr_go_layout_A_const_20 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[54]); A_arbace_repr_go_layout_A_const_21 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[55]); A_arbace_repr_go_layout_A_const_22 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[56]); A_arbace_repr_go_layout_A_const_23 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[57]) }

func A_arbace_repr_go_layout_A_clinit_p2() { A_arbace_repr_go_layout_A_const_24 = A_arbace_repr_go_layout_A_const_pool.A[58]; A_arbace_repr_go_layout_A_const_25 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[59]); A_arbace_repr_go_layout_A_const_26 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[60]); A_arbace_repr_go_layout_A_const_27 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[61]); A_arbace_repr_go_layout_A_const_28 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[62]); A_arbace_repr_go_layout_A_const_29 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[63]); A_arbace_repr_go_layout_A_const_30 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[64]); A_arbace_repr_go_layout_A_const_31 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[65]); A_arbace_repr_go_layout_A_const_32 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[66]); A_arbace_repr_go_layout_A_const_33 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[67]); A_arbace_repr_go_layout_A_const_34 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[68]); A_arbace_repr_go_layout_A_const_35 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[69]) }

func A_arbace_repr_go_layout_A_clinit_p3() { A_arbace_repr_go_layout_A_const_36 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[70]); A_arbace_repr_go_layout_A_const_37 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[71]); A_arbace_repr_go_layout_A_const_38 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[72]); A_arbace_repr_go_layout_A_const_39 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[73]); A_arbace_repr_go_layout_A_const_40 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[74]); A_arbace_repr_go_layout_A_const_41 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[75]); A_arbace_repr_go_layout_A_const_42 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[76]); A_arbace_repr_go_layout_A_const_43 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[77]); A_arbace_repr_go_layout_A_const_44 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[78]); A_arbace_repr_go_layout_A_const_45 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[79]); A_arbace_repr_go_layout_A_const_46 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[80]); A_arbace_repr_go_layout_A_const_47 = A_arbace_repr_go_layout_A_const_pool.A[81] }

func A_arbace_repr_go_layout_A_clinit_p4() { A_arbace_repr_go_layout_A_const_48 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[82]); A_arbace_repr_go_layout_A_const_49 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[83]); A_arbace_repr_go_layout_A_const_50 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[84]); A_arbace_repr_go_layout_A_const_51 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[85]); A_arbace_repr_go_layout_A_const_52 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[86]); A_arbace_repr_go_layout_A_const_53 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[87]); A_arbace_repr_go_layout_A_const_54 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[88]); A_arbace_repr_go_layout_A_const_55 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[89]); A_arbace_repr_go_layout_A_const_56 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[90]); A_arbace_repr_go_layout_A_const_57 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[91]); A_arbace_repr_go_layout_A_const_58 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[92]); A_arbace_repr_go_layout_A_const_59 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[93]) }

func A_arbace_repr_go_layout_A_clinit_p5() { A_arbace_repr_go_layout_A_const_60 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[94]); A_arbace_repr_go_layout_A_const_61 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[95]); A_arbace_repr_go_layout_A_const_62 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[96]); A_arbace_repr_go_layout_A_const_63 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[97]); A_arbace_repr_go_layout_A_const_64 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[98]); A_arbace_repr_go_layout_A_const_65 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[99]); A_arbace_repr_go_layout_A_const_66 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[100]); A_arbace_repr_go_layout_A_const_67 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[101]); A_arbace_repr_go_layout_A_const_68 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[102]); A_arbace_repr_go_layout_A_const_69 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[103]); A_arbace_repr_go_layout_A_const_70 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[104]); A_arbace_repr_go_layout_A_const_71 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[105]) }

func A_arbace_repr_go_layout_A_clinit_p6() { A_arbace_repr_go_layout_A_const_72 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[106]); A_arbace_repr_go_layout_A_const_73 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[107]); A_arbace_repr_go_layout_A_const_74 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[108]); A_arbace_repr_go_layout_A_const_75 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[109]); A_arbace_repr_go_layout_A_const_76 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[110]); A_arbace_repr_go_layout_A_const_77 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[111]); A_arbace_repr_go_layout_A_const_78 = A_arbace_repr_go_layout_A_const_pool.A[112]; A_arbace_repr_go_layout_A_const_79 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[113]); A_arbace_repr_go_layout_A_const_80 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[114]); A_arbace_repr_go_layout_A_const_81 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[115]); A_arbace_repr_go_layout_A_const_82 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[116]); A_arbace_repr_go_layout_A_const_83 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[117]) }

func A_arbace_repr_go_layout_A_clinit_p7() { A_arbace_repr_go_layout_A_const_84 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[118]); A_arbace_repr_go_layout_A_const_85 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[119]); A_arbace_repr_go_layout_A_const_86 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[120]); A_arbace_repr_go_layout_A_const_87 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[121]); A_arbace_repr_go_layout_A_const_88 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[122]); A_arbace_repr_go_layout_A_const_89 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[123]); A_arbace_repr_go_layout_A_const_90 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[124]); A_arbace_repr_go_layout_A_const_91 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[125]); A_arbace_repr_go_layout_A_const_92 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[126]); A_arbace_repr_go_layout_A_const_93 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[127]); A_arbace_repr_go_layout_A_const_94 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[128]); A_arbace_repr_go_layout_A_const_95 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[129]) }

func A_arbace_repr_go_layout_A_clinit_p8() { A_arbace_repr_go_layout_A_const_96 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[130]); A_arbace_repr_go_layout_A_const_97 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[131]); A_arbace_repr_go_layout_A_const_98 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[132]); A_arbace_repr_go_layout_A_const_99 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[133]); A_arbace_repr_go_layout_A_const_100 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[134]); A_arbace_repr_go_layout_A_const_101 = A_arbace_repr_go_layout_A_const_pool.A[135]; A_arbace_repr_go_layout_A_const_102 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[136]); A_arbace_repr_go_layout_A_const_103 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[137]); A_arbace_repr_go_layout_A_const_104 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[138]); A_arbace_repr_go_layout_A_const_105 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[139]); A_arbace_repr_go_layout_A_const_106 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[140]); A_arbace_repr_go_layout_A_const_107 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[141]) }

func A_arbace_repr_go_layout_A_clinit_p9() { A_arbace_repr_go_layout_A_const_108 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[142]); A_arbace_repr_go_layout_A_const_109 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[143]); A_arbace_repr_go_layout_A_const_110 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[144]); A_arbace_repr_go_layout_A_const_111 = A_arbace_repr_go_layout_A_const_pool.A[145]; A_arbace_repr_go_layout_A_const_112 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[146]); A_arbace_repr_go_layout_A_const_113 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[147]); A_arbace_repr_go_layout_A_const_114 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[148]); A_arbace_repr_go_layout_A_const_115 = A_arbace_repr_go_layout_A_const_pool.A[149]; A_arbace_repr_go_layout_A_const_116 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[150]); A_arbace_repr_go_layout_A_const_117 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[151]); A_arbace_repr_go_layout_A_const_118 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[152]); A_arbace_repr_go_layout_A_const_119 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[153]) }

func A_arbace_repr_go_layout_A_clinit_p10() { A_arbace_repr_go_layout_A_const_120 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[154]) }

func A_arbace_repr_go_layout_A_New() *A_arbace_repr_go_layout_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_layout_A) Ctor() {}

func (t *A_arbace_repr_go_layout_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_layout_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_layout_A_class }

func (t *A_arbace_repr_go_layout_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_layout_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_layout_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_layout_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_layout_A); return ok }

func A_arbace_repr_go_layout_A_Cast(x any) *A_arbace_repr_go_layout_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_layout_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_layout_A_class)) }; return v }



type A_arbace_repr_go_layout_atom_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_atom_text_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_comment_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_comment_text_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_deref_form_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_deref_form_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_eval1839000004_A struct{ jrt.Object }

func A_arbace_repr_go_layout_eval1839000004_A_New() *A_arbace_repr_go_layout_eval1839000004_A { t := &A_arbace_repr_go_layout_eval1839000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_layout_eval1839000004_A) Ctor() {}

func (t *A_arbace_repr_go_layout_eval1839000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_layout_eval1839000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_layout_eval1839000004_A_class }

func (t *A_arbace_repr_go_layout_eval1839000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_layout_eval1839000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_layout_eval1839000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_layout_eval1839000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_layout_eval1839000004_A); return ok }

func A_arbace_repr_go_layout_eval1839000004_A_Cast(x any) *A_arbace_repr_go_layout_eval1839000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_layout_eval1839000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_layout_eval1839000004_A_class)) }; return v }



type A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_eval1839000008_A struct{ jrt.Object }

func A_arbace_repr_go_layout_eval1839000008_A_New() *A_arbace_repr_go_layout_eval1839000008_A { t := &A_arbace_repr_go_layout_eval1839000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_layout_eval1839000008_A) Ctor() {}

func (t *A_arbace_repr_go_layout_eval1839000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_layout_eval1839000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_layout_eval1839000008_A_class }

func (t *A_arbace_repr_go_layout_eval1839000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_layout_eval1839000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_layout_eval1839000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_layout_eval1839000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_layout_eval1839000008_A); return ok }

func A_arbace_repr_go_layout_eval1839000008_A_Cast(x any) *A_arbace_repr_go_layout_eval1839000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_layout_eval1839000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_layout_eval1839000008_A_class)) }; return v }



type A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_form_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_form_line_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_iobj_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_iobj_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_key_rank_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_key_rank_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_lit_children_meta_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A struct{ j2g_header uint64; F_i, F_c any }

var A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A struct{ j2g_header uint64; F_i, F_v any }

var A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_meta_prefix_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A struct{ j2g_header uint64; F_pm any }

var A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A struct{ j2g_header uint64; F_pm any }

var A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A struct{ j2g_header uint64; F_pm any }

var A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A struct{ j2g_header uint64; F_s__1839000072, F_pm, F_iter__1839000071 any }

var A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A struct{ j2g_header uint64; F_b__1839000074, F_pm any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_note_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_note_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_prep_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000020_A struct{ j2g_header uint64; F_cursor, F_x any; F_lines_QMARK_ bool }

var A_arbace_repr_go_layout_prep_fn__1839000020_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A struct{ j2g_header uint64; F_l, F_brk, F_cursor, F_c any; F_lines_QMARK_ bool }

var A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A struct{ j2g_header uint64; F_i int64; F_c any }

var A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000036_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_prep_fn__1839000036_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prepare_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_prepare_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_private_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_private_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_public_meta_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_public_meta_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_public_meta_fn__1839000054_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_public_meta_fn__1839000054_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_sort_keys_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_sort_keys_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_sort_keys_fn__1839000050_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_text_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A struct{ j2g_header uint64; F_s__1839000100, F_iter__1839000099 any }

var A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A struct{ j2g_header uint64; F_b__1839000102 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_file_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_file_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_file_emit__1839000121_A struct{ j2g_header uint64; F_newline_to_BANG_, F_sb, F_code_QMARK_, F_depth any }

var A_arbace_repr_go_layout_write_file_emit__1839000121_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A struct{ j2g_header uint64; F_sb, F_code_QMARK_, F_line, F_comments, F_depth any }

var A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A struct{ j2g_header uint64; F_sb, F_code_QMARK_, F_line, F_flush_comments_BANG_, F_depth any }

var A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_package_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A struct{ j2g_header uint64; F_iter__1839000141, F_s__1839000142 any }

var A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A struct{ j2g_header uint64; F_b__1839000144 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A struct{ j2g_header uint64; F_s__1839000158, F_iter__1839000157 any }

var A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A struct{ j2g_header uint64; F_b__1839000160 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A_fn_class *jrt.Class
