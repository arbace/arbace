//line aot_arbace_repr_go_layout.ae:1
package aot_arbace_repr_go_layout

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A_New() *A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_layout_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_layout_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_layout_A_const_3, A_arbace_repr_go_layout_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A_New() *A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_layout_A_const_9), A_arbace_repr_go_layout_A_const_7.GetRawRoot__O(), A_arbace_repr_go_layout_A_const_8) }















func A_arbace_repr_go_layout_private_QMARK__A_New() *A_arbace_repr_go_layout_private_QMARK__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_private_QMARK__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_repr_go_layout_private_QMARK__A) Ctor() {}
//line :17:1
func (t *A_arbace_repr_go_layout_private_QMARK__A) Invoke_O_O__O(self, k__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_10.GetRawRoot__O()).Invoke_O__O(k__0); if jrt.J2g_Truth(and__1927000168__auto____2) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_11.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_layout_A_const_12.GetRawRoot__O()).Invoke_O__O(k__0))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_layout_iobj_QMARK__A_New() *A_arbace_repr_go_layout_iobj_QMARK__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_iobj_QMARK__A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_repr_go_layout_iobj_QMARK__A) Ctor() {}
//line :19:1
func (t *A_arbace_repr_go_layout_iobj_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.IObj_InstanceOf(x__0)).Ref() }

func A_arbace_repr_go_layout_deref_form_QMARK__A_New() *A_arbace_repr_go_layout_deref_form_QMARK__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_deref_form_QMARK__A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_repr_go_layout_deref_form_QMARK__A) Ctor() {}
//line :21:1
func (t *A_arbace_repr_go_layout_deref_form_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 *lang.Keyword = A_arbace_repr_go_layout_A_const_14; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_layout_form_line_A_New() *A_arbace_repr_go_layout_form_line_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_form_line_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_repr_go_layout_form_line_A) Ctor() {}
//line :23:1
func (t *A_arbace_repr_go_layout_form_line_A) Invoke_O_O__O(self, x__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(x__0)) {
		return A_arbace_repr_go_layout_A_const_16.Invoke_O__O(x__0) } else {
//line :26:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_17.GetRawRoot__O()).Invoke_O__O(x__0)) {

				var tmp1 *lang.Keyword = A_arbace_repr_go_layout_A_const_18; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else {
//line :26:1
					return nil
				}
		}
}



func A_arbace_repr_go_layout_note_BANG__A_New() *A_arbace_repr_go_layout_note_BANG__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_note_BANG__A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_repr_go_layout_note_BANG__A) Ctor() {}
//line :33:1
func (t *A_arbace_repr_go_layout_note_BANG__A) Invoke_O_O__O(self, k__0 any) any { if jrt.J2g_Truth(A_arbace_repr_go_layout_A_const_19.Get__O()) { return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_20.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_repr_go_layout_A_const_19.Get__O(), A_arbace_repr_go_layout_A_const_21.GetRawRoot__O(), k__0, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_layout_A_const_23.GetRawRoot__O(), A_arbace_repr_go_layout_A_const_24)) } else { return nil } }



func A_arbace_repr_go_layout_prep_A_New() *A_arbace_repr_go_layout_prep_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_repr_go_layout_prep_A) Ctor() {}
//line :37:1
func (t *A_arbace_repr_go_layout_prep_A) Invoke_O_O_O__O(self, x__0, cursor__1 any) any {


	var tmp1 any; var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__0)
	if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_25.GetRawRoot__O()).Invoke_O__O(x__0) }
//line :40:1
	if jrt.J2g_Truth(tmp1) {

		var tmp2 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; if jrt.J2g_Truth(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0))) { return lang.Tuple_Create_O_O__IPersistentVector(x__0, cursor__1) } else { var lines_QMARK___3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_28); var m__4 any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); var vec__1839000017__5 any; var tmp3 any = A_arbace_repr_go_layout_prep_fn__1839000020_A_New_O_O_Z(cursor__1, x__0, lines_QMARK___3); var tmp4 *jrt.Class
			var fncls__15 /*line :42:1*/*jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000020_A_fn_class




			if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_repr_go_layout_prep_fn__1839000020_A_fn_class = fncls__15d; tmp4 = fncls__15d } else { tmp4 = fncls__15 }; vec__1839000017__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
//line :42:1
			var kids__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(0), nil); var cursor__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(1), nil); var breaks__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(2), nil); var apos__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(3), nil); var afull__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(4), nil); var x_SINGLEQUOTE___11 any
































			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__0)) { x_SINGLEQUOTE___11 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_48.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_layout_A_const_51.GetRawRoot__O(), kids__6) } else { x_SINGLEQUOTE___11 = kids__6 }
//line :42:1
			var m__12 any; var G__1839000034__12_ any = m__4; var G__1839000034__13_ any; var tmp5 any
			var and__1927000168__auto____13 bool = lines_QMARK___3

































			if and__1927000168__auto____13 { tmp5 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(breaks__8) } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____13).Ref() }
//line :76:1
			if jrt.J2g_Truth(tmp5) {
				G__1839000034__13_ = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(G__1839000034__12_, A_arbace_repr_go_layout_A_const_52, breaks__8) } else {
//line :76:1
					G__1839000034__13_ = G__1839000034__12_ }
//line :42:1
			var G__1839000034__14_ any; var tmp6 any; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_49)



































			if and__1927000168__auto____14 { tmp6 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(apos__9) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }
//line :76:1
			if jrt.J2g_Truth(tmp6) {

				G__1839000034__14_ = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(G__1839000034__13_, A_arbace_repr_go_layout_A_const_53, apos__9) } else {
//line :76:1
					G__1839000034__14_ = G__1839000034__13_ }; if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_49) {


						var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_50.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_54.GetRawRoot__O()); var tmp9 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_55.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_layout_prep_fn__1839000036_A_New(); var tmp12 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000036_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_repr_go_layout_prep_fn__1839000036_A_fn_class = fncls__16d; tmp12 = fncls__16d } else { tmp12 = fncls__16 }; m__12 = tmp7.Invoke_O_O__O(G__1839000034__14_, tmp8.Invoke_O_O_O__O(tmp9, tmp10.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil)), afull__10)) } else {
//line :76:1
							m__12 = G__1839000034__14_ }
//line :42:1
			return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_56.GetRawRoot__O()).Invoke_O_O__O(x_SINGLEQUOTE___11, m__12), cursor__7) } } else {
//line :40:1
				if A_arbace_repr_go_layout_A_const_35 != nil { return lang.Tuple_Create_O_O__IPersistentVector(x__0, cursor__1) } else { return nil
				}
			}
}



func A_arbace_repr_go_layout_prep_fn__1839000020_A_New_O_O_Z(p0, p1 any, p2 bool) *A_arbace_repr_go_layout_prep_fn__1839000020_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000020_A{}; t.Ctor_O_O_Z(p0, p1, p2); return t }
//line :47:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_A) Ctor_O_O_Z(c__cursor, c__x any, c__lines_QMARK_ bool) { t.F_cursor = c__cursor; t.F_x = c__x; t.F_lines_QMARK_ = c__lines_QMARK_ }
//line :47:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var xs__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_x; t.F_x = nil; tmp2 = t_; xs__2 = tmp1.Invoke_O__O(tmp2); var cursor__3 any; var t__2 any = t.F_cursor; t.F_cursor = nil; cursor__3 = t__2; var acc__4 any = lang.PersistentVector_EMPTY.Ref(); var breaks__5 any = lang.PersistentVector_EMPTY.Ref(); var apos__6 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_30.GetRawRoot__O()).Invoke__O(); var afull__7 any = lang.PersistentArrayMap_EMPTY.Ref(); L1: for { var temp__1927000408__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__2)
											if jrt.J2g_Truth(temp__1927000408__auto____8) { var c__9 any = temp__1927000408__auto____8; var l__10 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_32.GetRawRoot__O()).Invoke_O__O(c__9); var cursor0__11 any = cursor__3; var brk__12 any
												var and__1927000168__auto____12 any = l__10

		if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp3 bool; var na_1 any = l__10; var na_2 any = cursor__3; var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_1); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_2) }; tmp4 = tmp5; if tmp4 { var n0_3 int64 = jrt.NN(jrt.Long_Cast(na_1)).LongValue__J(); var n1_4 int64 = jrt.NN(jrt.Long_Cast(na_2)).LongValue__J(); tmp3 = n0_3 > n1_4 } else { var tmp6 bool; var tmp7 bool; tmp7 = jrt.Double_InstanceOf(na_1); if tmp7 { tmp7 = jrt.Double_InstanceOf(na_2) }; tmp6 = tmp7; if tmp6 { var n0_3_2 float64 = jrt.NN(jrt.Double_Cast(na_1)).DoubleValue__D(); var n1_4_2 float64 = jrt.NN(jrt.Double_Cast(na_2)).DoubleValue__D(); tmp3 = n1_4_2 < n0_3_2 } else { tmp3 = lang.Numbers_Gt_O_O__Z_NoInit(na_1, na_2) } }; brk__12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp3).Ref() } else { brk__12 = and__1927000168__auto____12 }
//line :48:1
		var c__13 any



		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(c__9)) {
			c__13 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(c__9, A_arbace_repr_go_layout_A_const_37, brk__12) } else {
//line :52:1
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_17.GetRawRoot__O()).Invoke_O__O(c__9)) {


					var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_34.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_New_O_O_O_O_Z(l__10, brk__12, cursor__3, c__9, t.F_lines_QMARK_); var tmp10 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_fn_class = fncls__11d; tmp10 = fncls__11d } else { tmp10 = fncls__11 }; c__13 = tmp8.Invoke_O_O__O(c__9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)) } else {
//line :52:1
						if A_arbace_repr_go_layout_A_const_35 != nil { c__13 = c__9 } else { c__13 = nil } } }
//line :48:1
		var cursor__14 any













		if jrt.J2g_Truth(brk__12) { cursor__14 = l__10 } else { cursor__14 = cursor__3 }
//line :48:1
		var vec__1839000021__15 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_36.GetRawRoot__O()).Invoke_O_O__O(c__13, cursor__14); var c__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000021__15, lang.RT_IntCast_J__I_NoInit(0), nil); var cursor__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000021__15, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp11 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp12 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_43.GetRawRoot__O()).Invoke_O__O(xs__2); var tmp13 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_7.GetRawRoot__O()).Invoke_O_O__O(acc__4, c__16); var tmp14 any; var tmp15 any
		var and__1927000168__auto____18 any = brk__12

















		if jrt.J2g_Truth(and__1927000168__auto____18) { tmp15 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(c__16) } else { tmp15 = and__1927000168__auto____18 }; if jrt.J2g_Truth(tmp15) { var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_7.GetRawRoot__O()); var tmp17 any; var tmp18 jrt.Number_I; var na_12 any = cursor0__11; if jrt.Long_InstanceOf(na_12) { var n0_13 int64 = jrt.NN(jrt.Long_Cast(na_12)).LongValue__J(); if n0_13 == 9223372036854775807 { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_12) } else { tmp18 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_13 + 1)) } } else { if jrt.Double_InstanceOf(na_12) { var n0_13_2 float64 = jrt.NN(jrt.Double_Cast(na_12)).DoubleValue__D(); tmp18 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_13_2 + 1.0)) } else { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_12) } }; if lang.Util_Equiv_O_O__Z_NoInit(l__10, tmp18) { tmp17 = jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref() } else { tmp17 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref(), l__10) }; tmp14 = tmp16.Invoke_O_O__O(breaks__5, tmp17) } else { tmp14 = breaks__5 }
//line :64:1
		var tmp19 any = tmp14; var tmp20 any; var tmp21 any; var and__1927000168__auto____18_2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(c__16)



		if jrt.J2g_Truth(and__1927000168__auto____18_2) { tmp21 = A_arbace_repr_go_layout_A_const_44.Invoke_O__O(c__16) } else { tmp21 = and__1927000168__auto____18_2 }; if jrt.J2g_Truth(tmp21) { tmp20 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(apos__6, jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref(), A_arbace_repr_go_layout_A_const_44.Invoke_O__O(c__16)) } else { tmp20 = apos__6 }
//line :64:1
		var tmp22 any = tmp20; var tmp23 any





		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(c__16)) {
			var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_45.GetRawRoot__O()); var tmp25 any = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_New_J_O(i__1, c__16); var tmp26 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_fn_class = fncls__14d; tmp26 = fncls__14d } else { tmp26 = fncls__14 }; tmp23 = tmp24.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil), afull__7, A_arbace_repr_go_layout_A_const_47) } else {
//line :70:1
				tmp23 = afull__7 }
//line :64:1
		i__1, xs__2, cursor__3, acc__4, breaks__5, apos__6, afull__7 = tmp11, tmp12, cursor__17, tmp13, tmp19, tmp22, tmp23; continue L1 } else {
//line :48:1
			return lang.Tuple_Create_O_O_O_O_O__IPersistentVector(acc__4, cursor__3, breaks__5, apos__6, afull__7) } } }; /*line :47:1*/panic("j2g: unreachable") }







func A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_New_O_O_O_O_Z(p0, p1, p2, p3 any, p4 bool) *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A{}; t.Ctor_O_O_O_O_Z(p0, p1, p2, p3, p4); return t }
//line :55:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A) Ctor_O_O_O_O_Z(c__l, c__brk, c__cursor, c__c any, c__lines_QMARK_ bool) { t.F_l = c__l; t.F_brk = c__brk; t.F_cursor = c__cursor; t.F_c = c__c; t.F_lines_QMARK_ = c__lines_QMARK_ }
//line :55:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A) Invoke_O_O__O(self, cm__1 any) any { var G__1839000025__2_ any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(cm__1, A_arbace_repr_go_layout_A_const_40, t.F_brk); var G__1839000025__3_ any; var tmp1 any; var and__1927000168__auto____3 bool = t.F_lines_QMARK_; if and__1927000168__auto____3 {

	var and__1927000168__auto____4 any = t.F_brk; if jrt.J2g_Truth(and__1927000168__auto____4) { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(t.F_c)); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { tmp1 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_39.GetRawRoot__O()).Invoke_O__O(t.F_c) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if /*line :56:1*/ jrt.J2g_Truth(tmp1) {

		G__1839000025__3_ = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(G__1839000025__2_, A_arbace_repr_go_layout_A_const_16, t.F_l) } else {
//line :56:1
			G__1839000025__3_ = G__1839000025__2_ }; var tmp2 any; var and__1927000168__auto____4_2 bool = t.F_lines_QMARK_; if and__1927000168__auto____4_2 {


				var and__1927000168__auto____5 any = t.F_l; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_38.GetRawRoot__O()).Invoke_O__O(t.F_brk); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 bool; var na_6 any = t.F_l; var na_7 any = t.F_cursor; var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_6); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_7) }; tmp3 = tmp4; if tmp3 { var n0_8 int64 = jrt.NN(jrt.Long_Cast(na_6)).LongValue__J(); var n1_9 int64 = jrt.NN(jrt.Long_Cast(na_7)).LongValue__J(); and__1927000168__auto____7 = n0_8 < n1_9 } else { var tmp5 bool; var tmp6 bool; tmp6 = jrt.Double_InstanceOf(na_6); if tmp6 { tmp6 = jrt.Double_InstanceOf(na_7) }; tmp5 = tmp6; if tmp5 { var n0_8_2 float64 = jrt.NN(jrt.Double_Cast(na_6)).DoubleValue__D(); var n1_9_2 float64 = jrt.NN(jrt.Double_Cast(na_7)).DoubleValue__D(); and__1927000168__auto____7 = n0_8_2 < n1_9_2 } else { and__1927000168__auto____7 = lang.Numbers_Lt_O_O__Z_NoInit(na_6, na_7) } }; if and__1927000168__auto____7 { tmp2 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(t.F_c) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp2 = and__1927000168__auto____6 } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }; if /*line :56:1*/ jrt.J2g_Truth(tmp2) { var cm__4 any = G__1839000025__3_



					lang.IFn_Cast(A_arbace_repr_go_layout_A_const_41.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_layout_A_const_42); return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(cm__4, A_arbace_repr_go_layout_A_const_16, t.F_l) } else {
//line :56:1
						return G__1839000025__3_ } }














func A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_New_J_O(p0 int64, p1 any) *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A{}; t.Ctor_J_O(p0, p1); return t }
//line :71:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A) Ctor_J_O(c__i int64, c__c any) { t.F_i = c__i; t.F_c = c__c }
//line :71:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A) Invoke_O_O_O__O(self, af__1, p__1839000027__2 any) any { var vec__1839000029__3 any = p__1839000027__2; var k__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000029__3, lang.RT_IntCast_J__I_NoInit(0), nil); var mk__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000029__3, lang.RT_IntCast_J__I_NoInit(1), nil); var temp__1927000408__auto____6 any = lang.RT_Get_O_O__O_NoInit(t.F_c, k__4); if jrt.J2g_Truth(temp__1927000408__auto____6) { var v__7 any = temp__1927000408__auto____6; return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_46.GetRawRoot__O()).Invoke_O_O_O__O(af__1, lang.Tuple_Create_O_O__IPersistentVector(mk__5, jrt.Long_ValueOf_J__Long_NoInit(t.F_i).Ref()), v__7) } else { return af__1 } }







func A_arbace_repr_go_layout_prep_fn__1839000036_A_New() *A_arbace_repr_go_layout_prep_fn__1839000036_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000036_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000036_A) Ctor() {}
//line :79:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000036_A) Invoke_O_O__O(self, p__1839000035__1 any) any { var vec__1839000037__2 any = p__1839000035__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000037__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000037__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(k__3, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_54.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_30.GetRawRoot__O()).Invoke__O(), v__4)) }



func A_arbace_repr_go_layout_prepare_A_New() *A_arbace_repr_go_layout_prepare_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prepare_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repr_go_layout_prepare_A) Ctor() {}
//line :83:1
func (t *A_arbace_repr_go_layout_prepare_A) Invoke_O_O__O(self, forms__0 any) any { { var fs__2 any = forms__0; var cursor__3 any = lang.RT_Box_J__Number_NoInit(1); var acc__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var temp__1927000408__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(fs__2)



	if jrt.J2g_Truth(temp__1927000408__auto____5) { var f__6 any = temp__1927000408__auto____5; var l__7 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_32.GetRawRoot__O()).Invoke_O__O(f__6); var brk__8 any
		var and__1927000168__auto____8 any = l__7
		if jrt.J2g_Truth(and__1927000168__auto____8) { var tmp1 bool; var na_17 any = l__7; var na_18 any = cursor__3; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_17); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_18) }; tmp2 = tmp3; if tmp2 { var n0_19 int64 = jrt.NN(jrt.Long_Cast(na_17)).LongValue__J(); var n1_20 int64 = jrt.NN(jrt.Long_Cast(na_18)).LongValue__J(); tmp1 = n0_19 > n1_20 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_17); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_18) }; tmp4 = tmp5; if tmp4 { var n0_19_2 float64 = jrt.NN(jrt.Double_Cast(na_17)).DoubleValue__D(); var n1_20_2 float64 = jrt.NN(jrt.Double_Cast(na_18)).DoubleValue__D(); tmp1 = n1_20_2 < n0_19_2 } else { tmp1 = lang.Numbers_Gt_O_O__Z_NoInit(na_17, na_18) } }; brk__8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() } else { brk__8 = and__1927000168__auto____8 }
//line :87:1
		var f__9 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_34.GetRawRoot__O()).Invoke_O_O_O_O__O(f__6, A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(), A_arbace_repr_go_layout_A_const_40, brk__8); var cursor__10 any



		if jrt.J2g_Truth(brk__8) { cursor__10 = l__7 } else { cursor__10 = cursor__3 }
//line :87:1
		var vec__1839000045__11 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_36.GetRawRoot__O()).Invoke_O_O__O(f__9, cursor__10); var f__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000045__11, lang.RT_IntCast_J__I_NoInit(0), nil); var cursor__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000045__11, lang.RT_IntCast_J__I_NoInit(1), nil)





		fs__2, cursor__3, acc__4 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_43.GetRawRoot__O()).Invoke_O__O(fs__2), cursor__13, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_7.GetRawRoot__O()).Invoke_O_O__O(acc__4, f__12); continue L1 } else {
//line :87:1
			return acc__4 } } }; /*line :83:1*/panic("j2g: unreachable") }



















func A_arbace_repr_go_layout_key_rank_A_New() *A_arbace_repr_go_layout_key_rank_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_key_rank_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_repr_go_layout_key_rank_A) Ctor() {}
//line :103:1
func (t *A_arbace_repr_go_layout_key_rank_A) Invoke_O_O__O(self, k__0 any) any { var i__2 int32 = jrt.List_Cast(A_arbace_repr_go_layout_A_const_57.GetRawRoot__O()).IndexOf_O__I(k__0); if

	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_layout_A_const_57.GetRawRoot__O())).Ref() } else { return jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref() } }

func A_arbace_repr_go_layout_sort_keys_A_New() *A_arbace_repr_go_layout_sort_keys_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_sort_keys_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_repr_go_layout_sort_keys_A) Ctor() {}
//line :107:1
func (t *A_arbace_repr_go_layout_sort_keys_A) Invoke_O_O__O(self, ks__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ks__0) }
//line :108:1
func A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_New() *A_arbace_repr_go_layout_sort_keys_fn__1839000050_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_sort_keys_fn__1839000050_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_repr_go_layout_sort_keys_fn__1839000050_A) Ctor() {}
//line :108:1
func (t *A_arbace_repr_go_layout_sort_keys_fn__1839000050_A) Invoke_O_O__O(self, k__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_59.GetRawRoot__O()).Invoke_O__O(k__1), lang.IFn_Cast(A_arbace_repr_go_layout_A_const_60.GetRawRoot__O()).Invoke_O__O(k__1)) }

func A_arbace_repr_go_layout_public_meta_A_New() *A_arbace_repr_go_layout_public_meta_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_public_meta_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_repr_go_layout_public_meta_A) Ctor() {}
//line :110:1
func (t *A_arbace_repr_go_layout_public_meta_A) Invoke_O_O__O(self, x__0 any) any { var m__2 any; if


	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_17.GetRawRoot__O()).Invoke_O__O(x__0)) { m__2 = lang.RT_Meta_O__IPersistentMap_NoInit(x__0) } else { m__2 = nil }; var lines_QMARK___3 bool = /*line :110:1*/lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_28); var pm__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_54.GetRawRoot__O()); var tmp2 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_62.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_layout_public_meta_fn__1839000054_A_New(); var tmp5 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_repr_go_layout_public_meta_fn__1839000054_A_fn_class; if




	fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_repr_go_layout_public_meta_fn__1839000054_A_fn_class = fncls__23d; tmp5 = fncls__23d } else { tmp5 = fncls__23 }; pm__4 = tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)), m__2); var pm__5 any; if lines_QMARK___3 {
		pm__5 = pm__4 } else { var G__1839000059__5_ any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_61.GetRawRoot__O()).Invoke_O_O_O_O__O(pm__4, A_arbace_repr_go_layout_A_const_16, A_arbace_repr_go_layout_A_const_52, A_arbace_repr_go_layout_A_const_64); var G__1839000059__6_ any

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_layout_A_const_65.Invoke_O__O(m__2))) {
				var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_33.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_layout_A_const_66; G__1839000059__6_ = tmp6.Invoke_O_O_O__O(G__1839000059__5_, tmp7, A_arbace_repr_go_layout_A_const_65.Invoke_O__O(m__2)) } else {
//line :118:1
					G__1839000059__6_ = G__1839000059__5_ }; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_layout_A_const_67.Invoke_O__O(m__2))) {

						pm__5 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_50.GetRawRoot__O()).Invoke_O_O__O(G__1839000059__6_, A_arbace_repr_go_layout_A_const_67.Invoke_O__O(m__2)) } else {
//line :118:1
							pm__5 = G__1839000059__6_ } }; return pm__5 }
//line :115:1
func A_arbace_repr_go_layout_public_meta_fn__1839000054_A_New() *A_arbace_repr_go_layout_public_meta_fn__1839000054_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_public_meta_fn__1839000054_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_repr_go_layout_public_meta_fn__1839000054_A) Ctor() {}
//line :115:1
func (t *A_arbace_repr_go_layout_public_meta_fn__1839000054_A) Invoke_O_O__O(self, p__1839000053__1 any) any { var vec__1839000055__2 any = p__1839000053__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000055__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000055__2, lang.RT_IntCast_J__I_NoInit(1), nil); var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_63.GetRawRoot__O()).Invoke_O__O(k__3); _ = ___4; if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_layout_A_const_40)).Ref() } }







func A_arbace_repr_go_layout_meta_prefix_A_New() *A_arbace_repr_go_layout_meta_prefix_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_repr_go_layout_meta_prefix_A) Ctor() {}
//line :123:1
func (t *A_arbace_repr_go_layout_meta_prefix_A) Invoke_O_O__O(self, x__0 any) any { var pm__2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_68.GetRawRoot__O()).Invoke_O__O(x__0); if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(pm__2)) { var ks__3 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_71.GetRawRoot__O()).Invoke_O__O(pm__2)); var flags__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_70.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_New_O(pm__2); var tmp3 *jrt.Class
		var fncls__24 /*line :125:1*/*jrt.Class = A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_fn_class

		if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; flags__4 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ks__3)
//line :125:1
		var rest_ks__5 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_62.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_New_O(pm__2); var tmp6 *jrt.Class
		var fncls__25 /*line :125:1*/*jrt.Class = A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_fn_class


		if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_fn_class = fncls__25d; tmp6 = fncls__25d } else { tmp6 = fncls__25 }; rest_ks__5 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), ks__3)
//line :125:1
		var sb__6 any = jrt.StringBuilder_New(); var seq_1839000067__7 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(flags__4); var chunk_1839000068__8 any; var count_1839000069__9 int64 = 0; var i_1839000070__10 int64 = 0; L1: for {




			if lang.Numbers_Lt_J_J__Z_NoInit(i_1839000070__10, count_1839000069__9) { var k__11 any = lang.Indexed_Cast(chunk_1839000068__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1839000070__10)); jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, k__11, nil))); seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, i_1839000070__10 = seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1839000070__10); continue L1 } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_1839000067__7); if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1839000067__12 any = temp__1927000414__auto____11; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1839000067__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_1839000067__12); seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, i_1839000070__10 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_81.GetRawRoot__O()).Invoke_O__O(seq_1839000067__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var k__13 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1839000067__12); jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, k__13, nil))); seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, i_1839000070__10 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_43.GetRawRoot__O()).Invoke_O__O(seq_1839000067__12), nil, 0, 0; continue L1 } } }
//line :125:1
			break L1
		}




		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_77.GetRawRoot__O()).Invoke_O__O(rest_ks__5)) { } else { var tmp7 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(rest_ks__5, A_arbace_repr_go_layout_A_const_78)

			if and__1927000168__auto____7 { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_79.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_layout_A_const_80.Invoke_O__O(pm__2)); if jrt.J2g_Truth(and__1927000168__auto____8) { tmp7 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_77.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_68.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_layout_A_const_80.Invoke_O__O(pm__2))) } else { tmp7 = and__1927000168__auto____8 } } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }
//line :131:1
			if jrt.J2g_Truth(tmp7) {


				jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_go_layout_A_const_80.Invoke_O__O(pm__2), nil))) } else {
//line :131:1
					if A_arbace_repr_go_layout_A_const_35 != nil {




						jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(Lit_16)
						var tmp8 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__6); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_82.GetRawRoot__O()); var tmp10 any; var iter__1927001039__auto____7 any; var tmp11 any = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_New_O(pm__2); var tmp12 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_fn_class = fncls__28d; tmp12 = fncls__28d } else { tmp12 = fncls__28 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(rest_ks__5); jrt.NN(tmp8).Append_String__StringBuilder(jrt.String_Cast(tmp9.Invoke_O_O__O(Lit_9, tmp10)))
						jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(Lit_18) } } }
		return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_60.GetRawRoot__O()).Invoke_O__O(sb__6) } else {
//line :125:1
			return nil } }

func A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_New_O(p0 any) *A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A{}; t.Ctor_O(p0); return t }
//line :127:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :127:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A) Invoke_O_O__O(self, p1__1839000061_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_pm).Invoke_O__O(p1__1839000061_SHARP___1)); if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_73.GetRawRoot__O()).Invoke_O_O__O(p1__1839000061_SHARP___1, A_arbace_repr_go_layout_A_const_74) } else { return and__1927000168__auto____2 } }
func A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_New_O(p0 any) *A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A{}; t.Ctor_O(p0); return t }
//line :128:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :128:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A) Invoke_O_O__O(self, p1__1839000062_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_pm).Invoke_O__O(p1__1839000062_SHARP___1)); if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_73.GetRawRoot__O()).Invoke_O_O__O(p1__1839000062_SHARP___1, A_arbace_repr_go_layout_A_const_74) } else { return and__1927000168__auto____2 } }








func A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_New_O(p0 any) *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A{}; t.Ctor_O(p0); return t }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A) Invoke_O_O__O(self, s__1839000072__1 any) any { var tmp1 any = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_New_O_O_O(s__1839000072__1, t.F_pm, self); var tmp2 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_fn_class = fncls__27d; tmp2 = fncls__27d } else { tmp2 = fncls__27 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :137:1
func A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A) Ctor_O_O_O(c__s__1839000072, c__pm, c__iter__1839000071 any) { t.F_s__1839000072 = c__s__1839000072; t.F_pm = c__pm; t.F_iter__1839000071 = c__iter__1839000071 }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A) Invoke_O__O(self any) any { { var s__1839000072__1 any; var t_ any = t.F_s__1839000072; t.F_s__1839000072 = nil; s__1839000072__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1839000072__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000072__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_75.GetRawRoot__O()).Invoke_O__O(s__1839000072__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_76.GetRawRoot__O()).Invoke_O__O(s__1839000072__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000074__6 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_83.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_New_O_O_I_O(b__1839000074__6, t.F_pm, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_fn_class = fncls__26d; tmp2 = fncls__26d } else { tmp2 = fncls__26 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1839000071); return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_88.GetRawRoot__O()).Invoke_O__O(b__1839000074__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_81.GetRawRoot__O()).Invoke_O__O(s__1839000072__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_88.GetRawRoot__O()).Invoke_O__O(b__1839000074__6), nil) } } else { var k__4 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1839000072__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000071); return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_87.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, k__4, nil, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_85.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_pm).Invoke_O__O(k__4)))).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_89.GetRawRoot__O()).Invoke_O__O(s__1839000072__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :137:1
func A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A) Ctor_O_O_I_O(c__b__1839000074, c__pm any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000074 = c__b__1839000074; t.F_pm = c__pm; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A) Invoke_O__O(self any) any { { var i__1839000073__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000073__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var k__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000073__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_84.GetRawRoot__O()); var tmp3 any = t.F_b__1839000074; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, k__2, nil, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_85.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_pm).Invoke_O__O(k__2)))).Ref()); i__1839000073__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000073__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_repr_go_layout_atom_text_A_New() *A_arbace_repr_go_layout_atom_text_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_atom_text_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_repr_go_layout_atom_text_A) Ctor() {}
//line :141:1
func (t *A_arbace_repr_go_layout_atom_text_A) Invoke_O_O__O(self, x__0 any) any {
	if lang.Util_Identical_O_O__Z_NoInit(x__0, nil) { return Lit_1 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(x__0)) {

		return A_arbace_repr_go_layout_A_const_90.Invoke_O__O(x__0) } else {
//line :142:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_79.GetRawRoot__O()).Invoke_O__O(x__0)) {


				return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_60.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :142:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_10.GetRawRoot__O()).Invoke_O__O(x__0)) {



						return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_60.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :142:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_91.GetRawRoot__O()).Invoke_O__O(x__0)) {




								return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_92.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :142:1
									if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_93.GetRawRoot__O()).Invoke_O__O(x__0)) {





										return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_94.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(x__0)).Ref()) } else {
//line :142:1
											if lang.BigInt_InstanceOf(x__0) {






												return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_2), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :142:1
													if jrt.BigInteger_InstanceOf(x__0) {







														return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_2), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :142:1
															if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_95.GetRawRoot__O()).Invoke_O__O(x__0)) {








																return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_60.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :142:1
																	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_96.GetRawRoot__O()).Invoke_O__O(x__0)) {









																		return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_60.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :142:1
																			if jrt.Double_InstanceOf(x__0) { var d__2 float64 = lang.RT_DoubleCast_O__D_NoInit(x__0)











																				if jrt.Double_IsNaN_D__Z_NoInit(d__2) { return Lit_3 } else { if jrt.Double_IsInfinite_D__Z_NoInit(d__2) {
																					if lang.Numbers_IsPos_D__Z_NoInit(d__2) { return Lit_4 } else { return Lit_5 } } else {
//line :154:1
																						if A_arbace_repr_go_layout_A_const_35 != nil {

																							return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_60.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :154:1
																								return nil } } } } else {
//line :142:1
																									if jrt.BigDecimal_InstanceOf(x__0) {














																										return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :142:1
																											if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_97.GetRawRoot__O()).Invoke_O__O(x__0)) {















																												return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_60.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :142:1
																													if A_arbace_repr_go_layout_A_const_35 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_7, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_99.GetRawRoot__O()).Invoke_O__O(x__0))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_layout_A_const_100, x__0)))))) } else { return nil
																													}
																												}
																										}
																								}
																		}
																}
														}
												}
										}
								}
						}
				}
		}
	}
}



func A_arbace_repr_go_layout_lit_children_meta_A_New() *A_arbace_repr_go_layout_lit_children_meta_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_repr_go_layout_lit_children_meta_A) Ctor() {}
//line :161:1
func (t *A_arbace_repr_go_layout_lit_children_meta_A) Invoke_O_O__O(self, x__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_45.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any = lang.PersistentArrayMap_EMPTY.Ref(); return tmp1.Invoke_O_O_O__O(tmp4, tmp5, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_layout_A_const_103.GetRawRoot__O(), x__0)) }
//line :165:1
func A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_New() *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A) Ctor() {}
//line :165:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A) Invoke_O_O_O__O(self, m__1, p__1839000084__2 any) any { var vec__1839000086__3 any = p__1839000084__2; var i__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000086__3, lang.RT_IntCast_J__I_NoInit(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000086__3, lang.RT_IntCast_J__I_NoInit(1), nil); if
																jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(c__5)) {
																	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_45.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_New_O_O(i__4, c__5); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), m__1, A_arbace_repr_go_layout_A_const_101) } else {
//line :166:1
			return m__1 } }
func A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A{}; t.Ctor_O_O(p0, p1); return t }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A) Ctor_O_O(c__i, c__c any) { t.F_i = c__i; t.F_c = c__c }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A) Invoke_O_O_O__O(self, m__1, p__1839000089__2 any) any { var vec__1839000091__3 any = p__1839000089__2; var k__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000091__3, lang.RT_IntCast_J__I_NoInit(0), nil); var mk__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000091__3, lang.RT_IntCast_J__I_NoInit(1), nil); var temp__1927000408__auto____6 any = lang.RT_Get_O_O__O_NoInit(t.F_c, k__4); if jrt.J2g_Truth(temp__1927000408__auto____6) { var v__7 any = temp__1927000408__auto____6; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_New_O_O(t.F_i, v__7); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; return tmp1.Invoke_O_O_O__O(m__1, mk__5, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) } else { return m__1 } }
//line :167:1
func A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A{}; t.Ctor_O_O(p0, p1); return t }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A) Ctor_O_O(c__i, c__v any) { t.F_i = c__i; t.F_v = c__v }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A) Invoke_O_O__O(self, p1__1839000083_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_33.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____2 any = p1__1839000083_SHARP___1; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_30.GetRawRoot__O()).Invoke__O() }; return tmp1.Invoke_O_O_O__O(tmp2, t.F_i, t.F_v) }




func A_arbace_repr_go_layout_text_A_New() *A_arbace_repr_go_layout_text_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_repr_go_layout_text_A) Ctor() {}
//line :172:1
func (t *A_arbace_repr_go_layout_text_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_104.GetRawRoot__O()); var tmp3 any; var tmp4 any; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_49); if and__1927000168__auto____4 { var and__1927000168__auto____5 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__0); if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else { and__1927000168__auto____5 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_25.GetRawRoot__O()).Invoke_O__O(x__0) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp5 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; tmp4 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_38.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0))) } else { tmp4 = and__1927000168__auto____5 } } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if jrt.J2g_Truth(tmp4) { var lm__4 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_107.GetRawRoot__O()).Invoke_O__O(x__0)

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(lm__4)) { tmp3 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_34.GetRawRoot__O()).Invoke_O_O_O__O(x__0, A_arbace_repr_go_layout_A_const_50.GetRawRoot__O(), lm__4) } else { tmp3 = x__0 } } else {
//line :175:1
			tmp3 = x__0 }; var tmp6 any = tmp2.Invoke_O__O(tmp3); var tmp7 any



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(x__0)) {
		tmp7 = A_arbace_repr_go_layout_A_const_90.Invoke_O__O(x__0) } else {
//line :179:1
			var tmp8 any; var and__1927000168__auto____4_2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__0)

			if jrt.J2g_Truth(and__1927000168__auto____4_2) { var tmp9 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; tmp8 = tmp9.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else { tmp8 = and__1927000168__auto____4_2 }
//line :179:1
			if jrt.J2g_Truth(tmp8) {

				var tmp10 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; tmp7 = tmp10.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else {
//line :179:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_39.GetRawRoot__O()).Invoke_O__O(x__0)) {


						tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_27, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_85.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_108.GetRawRoot__O()).Invoke_O__O(x__0)))).Ref() } else {
//line :179:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__0)) {



								tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_82.GetRawRoot__O()).Invoke_O_O__O(Lit_9, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_55.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(), x__0)), nil)).Ref() } else {
//line :179:1
									if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_25.GetRawRoot__O()).Invoke_O__O(x__0)) {




										tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_31), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_82.GetRawRoot__O()).Invoke_O_O__O(Lit_9, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_55.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(), x__0)), nil)).Ref() } else {
//line :179:1
											if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_105.GetRawRoot__O()).Invoke_O__O(x__0)) {





												var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_32, nil, Lit_33); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_82.GetRawRoot__O()); var tmp13 any; var iter__1927001039__auto____7 any; var tmp14 any = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_New(); var tmp15 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_fn_class = fncls__34d; tmp15 = fncls__34d } else { tmp15 = fncls__34 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); tmp13 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(x__0); tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12.Invoke_O_O__O(Lit_9, tmp13), nil)).Ref() } else {
//line :179:1
													if A_arbace_repr_go_layout_A_const_35 != nil {






														tmp7 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_106.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :179:1
															tmp7 = nil } } } } } } }
//line :175:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7)).Ref()
}








func A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_New() *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A) Ctor() {}
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A) Invoke_O_O__O(self, s__1839000100__1 any) any { var tmp1 any = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_New_O_O(s__1839000100__1, self); var tmp2 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_fn_class = fncls__33d; tmp2 = fncls__33d } else { tmp2 = fncls__33 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :185:1
func A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A{}; t.Ctor_O_O(p0, p1); return t }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A) Ctor_O_O(c__s__1839000100, c__iter__1839000099 any) { t.F_s__1839000100 = c__s__1839000100; t.F_iter__1839000099 = c__iter__1839000099 }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A) Invoke_O__O(self any) any { { var s__1839000100__1 any; var t_ any = t.F_s__1839000100; t.F_s__1839000100 = nil; s__1839000100__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1839000100__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000100__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_75.GetRawRoot__O()).Invoke_O__O(s__1839000100__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_76.GetRawRoot__O()).Invoke_O__O(s__1839000100__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000102__6 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_83.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_New_O_I_O(b__1839000102__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_fn_class = fncls__32d; tmp2 = fncls__32d } else { tmp2 = fncls__32 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1839000099); return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_88.GetRawRoot__O()).Invoke_O__O(b__1839000102__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_81.GetRawRoot__O()).Invoke_O__O(s__1839000100__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_88.GetRawRoot__O()).Invoke_O__O(b__1839000102__6), nil) } } else { var vec__1839000110__4 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1839000100__3); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000110__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000110__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000099); return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_87.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_85.GetRawRoot__O()).Invoke_O__O(k__5), nil, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_85.GetRawRoot__O()).Invoke_O__O(v__6))).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_89.GetRawRoot__O()).Invoke_O__O(s__1839000100__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :185:1
func A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A) Ctor_O_I_O(c__b__1839000102 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000102 = c__b__1839000102; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A) Invoke_O__O(self any) any { { var i__1839000101__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000101__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1839000106__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000101__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000106__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000106__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_84.GetRawRoot__O()); var tmp3 any = t.F_b__1839000102; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_85.GetRawRoot__O()).Invoke_O__O(k__3), nil, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_85.GetRawRoot__O()).Invoke_O__O(v__4))).Ref()); i__1839000101__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000101__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_repr_go_layout_comment_text_A_New() *A_arbace_repr_go_layout_comment_text_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_comment_text_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_repr_go_layout_comment_text_A) Ctor() {}
//line :188:1
func (t *A_arbace_repr_go_layout_comment_text_A) Invoke_O_O__O(self, t__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_109.GetRawRoot__O()).Invoke_O_O__O(t__0, Lit_8)) {
		return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_110.GetRawRoot__O()).Invoke_O_O__O(t__0, A_arbace_repr_go_layout_A_const_112) } else {
//line :191:1
			if A_arbace_repr_go_layout_A_const_35 != nil {

				return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_111.GetRawRoot__O()).Invoke_O__O(t__0))).Ref() } else {
//line :191:1
					return nil
				}
		}
}
func A_arbace_repr_go_layout_write_file_A_New() *A_arbace_repr_go_layout_write_file_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_file_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_repr_go_layout_write_file_A) Ctor() {}
//line :195:1
func (t *A_arbace_repr_go_layout_write_file_A) Invoke_O_O_O__O(self, forms__0, comments__1 any) any { var forms__3 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_113.GetRawRoot__O()).Invoke_O__O(forms__0); var sb__4 any = jrt.StringBuilder_New(); var line__5 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_114.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_layout_A_const_118); var code_QMARK___6 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_114.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_FALSE.Ref()); var depth__7 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_114.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_layout_A_const_24); var flush_comments_BANG___8 any; var tmp1 any = A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A_New_O_O_O_O_O(sb__4, code_QMARK___6, line__5, comments__1, depth__7); var tmp2 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A_fn_class; if








	fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A_fn_class = fncls__40d; tmp2 = fncls__40d } else { tmp2 = fncls__40 }; flush_comments_BANG___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var newline_to_BANG___9 any; var tmp3 any = /*line :195:1*/A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A_New_O_O_O_O_O(sb__4, code_QMARK___6, line__5, flush_comments_BANG___8, depth__7); var tmp4 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A_fn_class; if















	fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A_fn_class = fncls__53d; tmp4 = fncls__53d } else { tmp4 = fncls__53 }; newline_to_BANG___9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var emit__10 any; var tmp5 any = /*line :195:1*/A_arbace_repr_go_layout_write_file_emit__1839000121_A_New_O_O_O_O(newline_to_BANG___9, sb__4, code_QMARK___6, depth__7); var tmp6 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_repr_go_layout_write_file_emit__1839000121_A_fn_class; if























	fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_repr_go_layout_write_file_emit__1839000121_A_fn_class = fncls__62d; tmp6 = fncls__62d } else { tmp6 = fncls__62 }; emit__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var seq_1839000133__11 any = /*line :195:1*/lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(forms__3); var chunk_1839000134__12 any; var count_1839000135__13 int64 = 0; var i_1839000136__14 int64 = 0; L1: for {












































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1839000136__14, count_1839000135__13) { var f__15 any = lang.Indexed_Cast(chunk_1839000134__12).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1839000136__14)); var tmp7 *lang.Keyword = A_arbace_repr_go_layout_A_const_40
			if jrt.J2g_Truth(tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__15))) {
				lang.IFn_Cast(emit__10).Invoke_O__O(f__15) } else {
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(code_QMARK___6)) { jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(Lit_9) }; lang.IFn_Cast(emit__10).Invoke_O__O(f__15) }
//line :240:1
			seq_1839000133__11, chunk_1839000134__12, count_1839000135__13, i_1839000136__14 = seq_1839000133__11, chunk_1839000134__12, count_1839000135__13, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1839000136__14); continue L1 } else { var temp__1927000414__auto____15 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_1839000133__11); if jrt.J2g_Truth(temp__1927000414__auto____15) { var seq_1839000133__16 any = temp__1927000414__auto____15; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1839000133__16)) { var c__1927000678__auto____17 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_1839000133__16); seq_1839000133__11, chunk_1839000134__12, count_1839000135__13, i_1839000136__14 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_81.GetRawRoot__O()).Invoke_O__O(seq_1839000133__16), c__1927000678__auto____17, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__17 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1839000133__16); var tmp8 *lang.Keyword = A_arbace_repr_go_layout_A_const_40
				if jrt.J2g_Truth(tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__17))) {
					lang.IFn_Cast(emit__10).Invoke_O__O(f__17) } else {
						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(code_QMARK___6)) { jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(Lit_9) }; lang.IFn_Cast(emit__10).Invoke_O__O(f__17) }
//line :240:1
				seq_1839000133__11, chunk_1839000134__12, count_1839000135__13, i_1839000136__14 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_43.GetRawRoot__O()).Invoke_O__O(seq_1839000133__16), nil, 0, 0; continue L1 } } }
//line :195:1
		break L1 }; var last_comment__11 any; if
















































	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(comments__1)) { last_comment__11 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_48.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_layout_A_const_119.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_layout_A_const_71.GetRawRoot__O()).Invoke_O__O(comments__1)) } else { last_comment__11 = A_arbace_repr_go_layout_A_const_24 }; var tmp9 bool; var na_63 any = last_comment__11; var na_64 any =
	lang.IFn_Cast(A_arbace_repr_go_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(line__5); var tmp10 bool; var tmp11 bool; tmp11 = jrt.Long_InstanceOf(na_63); if tmp11 { tmp11 = jrt.Long_InstanceOf(na_64) }; tmp10 = tmp11; if tmp10 { var n0_65 int64 = jrt.NN(jrt.Long_Cast(na_63)).LongValue__J(); var n1_66 int64 = jrt.NN(jrt.Long_Cast(na_64)).LongValue__J(); tmp9 = n0_65 > n1_66 } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_63); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_64) }; tmp12 = tmp13; if tmp12 { var n0_65_2 float64 = jrt.NN(jrt.Double_Cast(na_63)).DoubleValue__D(); var n1_66_2 float64 = jrt.NN(jrt.Double_Cast(na_64)).DoubleValue__D(); tmp9 = n1_66_2 < n0_65_2 } else { tmp9 = lang.Numbers_Gt_O_O__Z_NoInit(na_63, na_64) } }; if tmp9 {
		lang.IFn_Cast(A_arbace_repr_go_layout_A_const_117.GetRawRoot__O()).Invoke_O_O__O(depth__7, A_arbace_repr_go_layout_A_const_24)
		lang.IFn_Cast(newline_to_BANG___9).Invoke_O__O(last_comment__11) };
	lang.IFn_Cast(flush_comments_BANG___8).Invoke__O();
	jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(Lit_40); return /*line :250:1*/ lang.IFn_Cast(A_arbace_repr_go_layout_A_const_60.GetRawRoot__O()).Invoke_O__O(sb__4) }
//line :204:1
func A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :204:1
func (t *A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A) Ctor_O_O_O_O_O(c__sb, c__code_QMARK_, c__line, c__comments, c__depth any) { t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_line = c__line; t.F_comments = c__comments; t.F_depth = c__depth }
//line :204:1
func (t *A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A) Invoke_O__O(self any) any { var tmp1 any = t.F_comments; var temp__1927000414__auto____1 any = lang.RT_Get_O_O__O_NoInit(tmp1, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_line)); if
														jrt.J2g_Truth(temp__1927000414__auto____1) { var cs__2 any = temp__1927000414__auto____1
															if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_code_QMARK_)) {
																var tmp2 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); return jrt.NN(tmp2).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_82.GetRawRoot__O()).Invoke_O_O__O(Lit_41, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_55.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_layout_A_const_115.GetRawRoot__O(), cs__2))))).Ref() } else {
																	var tmp3 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_48.GetRawRoot__O()); var tmp5 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_116.GetRawRoot__O()); var tmp7 jrt.Number_I; var na_35 int64 = 2; var na_36 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_depth); if jrt.Long_InstanceOf(na_36) { var n0_37 int64 = na_35; var n1_38 int64 = jrt.NN(jrt.Long_Cast(na_36)).LongValue__J(); var nr_39 int64 = n0_37 * n1_38; var tmp8 bool; var tmp9 bool; var tmp10 bool; var tmp11 bool; tmp11 = n0_37 == -9223372036854775808; if tmp11 { tmp11 = n1_38 < 0 }; tmp10 = tmp11; tmp9 = !tmp10; if tmp9 { var tmp12 bool; tmp12 = n1_38 == 0; if !tmp12 { tmp12 = nr_39/n1_38 == n0_37 }; tmp9 = tmp12 }; tmp8 = tmp9; if tmp8 { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_39)) } else { tmp7 = lang.Numbers_Multiply_J_O__Number_NoInit(na_35, na_36) } } else { tmp7 = lang.Numbers_Multiply_J_O__Number_NoInit(na_35, na_36) }; jrt.NN(tmp3).Append_O__StringBuilder(tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O_O__O(tmp7, Lit_9)))
																	var tmp13 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); return jrt.NN(tmp13).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_82.GetRawRoot__O()).Invoke_O_O__O(Lit_43, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_55.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_layout_A_const_115.GetRawRoot__O(), cs__2))))).Ref() } } else {
//line :205:1
					return nil } }





func A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :211:1
func (t *A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A) Ctor_O_O_O_O_O(c__sb, c__code_QMARK_, c__line, c__flush_comments_BANG_, c__depth any) { t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_line = c__line; t.F_flush_comments_BANG_ = c__flush_comments_BANG_; t.F_depth = c__depth }
//line :211:1
func (t *A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A) Invoke_O_O__O(self, l__1 any) any { L1: for {
	var tmp1 bool; var na_41 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_line); var na_42 any = l__1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_41); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_42) }; tmp2 = tmp3; if tmp2 { var n0_43 int64 = jrt.NN(jrt.Long_Cast(na_41)).LongValue__J(); var n1_44 int64 = jrt.NN(jrt.Long_Cast(na_42)).LongValue__J(); tmp1 = n0_43 < n1_44 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_41); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_42) }; tmp4 = tmp5; if tmp4 { var n0_43_2 float64 = jrt.NN(jrt.Double_Cast(na_41)).DoubleValue__D(); var n1_44_2 float64 = jrt.NN(jrt.Double_Cast(na_42)).DoubleValue__D(); tmp1 = n0_43_2 < n1_44_2 } else { tmp1 = lang.Numbers_Lt_O_O__Z_NoInit(na_41, na_42) } }; if tmp1 {
		lang.IFn_Cast(t.F_flush_comments_BANG_).Invoke__O()
		var tmp6 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp6).Append_String__StringBuilder(Lit_40)
		var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_line); var tmp8 jrt.Number_I; var na_46 any = jrt.NN(lang.Volatile_Cast(t.F_line)).Deref__O(); if jrt.Long_InstanceOf(na_46) { var n0_47 int64 = jrt.NN(jrt.Long_Cast(na_46)).LongValue__J(); if n0_47 == 9223372036854775807 { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_46) } else { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_47 + 1)) } } else { if jrt.Double_InstanceOf(na_46) { var n0_47_2 float64 = jrt.NN(jrt.Double_Cast(na_46)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_47_2 + 1.0)) } else { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_46) } }; jrt.NN(tmp7).Reset_O__O(tmp8)
		lang.IFn_Cast(A_arbace_repr_go_layout_A_const_117.GetRawRoot__O()).Invoke_O_O__O(t.F_code_QMARK_, jrt.Boolean_FALSE.Ref())
//line :212:1
		continue L1 }
//line :211:1
	break L1
}




	var tmp9 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_48.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_116.GetRawRoot__O()); var tmp13 jrt.Number_I; var na_48 int64 = 2; var na_49 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_depth); if jrt.Long_InstanceOf(na_49) { var n0_50 int64 = na_48; var n1_51 int64 = jrt.NN(jrt.Long_Cast(na_49)).LongValue__J(); var nr_52 int64 = n0_50 * n1_51; var tmp14 bool; var tmp15 bool; var tmp16 bool; var tmp17 bool; tmp17 = n0_50 == -9223372036854775808; if tmp17 { tmp17 = n1_51 < 0 }; tmp16 = tmp17; tmp15 = !tmp16; if tmp15 { var tmp18 bool; tmp18 = n1_51 == 0; if !tmp18 { tmp18 = nr_52/n1_51 == n0_50 }; tmp15 = tmp18 }; tmp14 = tmp15; if tmp14 { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_52)) } else { tmp13 = lang.Numbers_Multiply_J_O__Number_NoInit(na_48, na_49) } } else { tmp13 = lang.Numbers_Multiply_J_O__Number_NoInit(na_48, na_49) }; return jrt.NN(tmp9).Append_O__StringBuilder(tmp10.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O__O(tmp13, Lit_9))).Ref()
}
func A_arbace_repr_go_layout_write_file_emit__1839000121_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_layout_write_file_emit__1839000121_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_file_emit__1839000121_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :219:1
func (t *A_arbace_repr_go_layout_write_file_emit__1839000121_A) Ctor_O_O_O_O(c__newline_to_BANG_, c__sb, c__code_QMARK_, c__depth any) { t.F_newline_to_BANG_ = c__newline_to_BANG_; t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_depth = c__depth }
//line :219:1
func (t *A_arbace_repr_go_layout_write_file_emit__1839000121_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_17.GetRawRoot__O()).Invoke_O__O(x__1); if jrt.J2g_Truth(or__1927000174__auto____2) { and__1927000168__auto____2 = or__1927000174__auto____2 } else { and__1927000168__auto____2 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(x__1) }; if jrt.J2g_Truth(and__1927000168__auto____2) {
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(x__1)) { tmp1 = A_arbace_repr_go_layout_A_const_37.Invoke_O__O(x__1) } else { var tmp2 *lang.Keyword = A_arbace_repr_go_layout_A_const_40; tmp1 = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__1)) } } else {
//line :220:1
			tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {

				var tmp3 lang.IFn = lang.IFn_Cast(t.F_newline_to_BANG_); tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_32.GetRawRoot__O()).Invoke_O__O(x__1)) }
	lang.IFn_Cast(A_arbace_repr_go_layout_A_const_117.GetRawRoot__O()).Invoke_O_O__O(t.F_code_QMARK_, jrt.Boolean_TRUE.Ref())
//line :219:1
	var p__2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_104.GetRawRoot__O()).Invoke_O__O(x__1)





	if jrt.J2g_Truth(p__2) { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(p__2) }
	var tmp4 any; var and__1927000168__auto____2_2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1)
	if jrt.J2g_Truth(and__1927000168__auto____2_2) { var tmp5 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; tmp4 = tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__1)) } else { tmp4 = and__1927000168__auto____2_2 }
//line :226:1
	if jrt.J2g_Truth(tmp4) {
		var tmp6 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp7 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; return jrt.NN(tmp6).Append_String__StringBuilder(jrt.String_Cast(tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__1)))).Ref() } else {
//line :226:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_39.GetRawRoot__O()).Invoke_O__O(x__1)) {

				var tmp8 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp8).Append_String__StringBuilder(Lit_27); return lang.IFn_Cast(self).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_108.GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :226:1
					var tmp9 any; var or__1927000174__auto____2_2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1)


					if jrt.J2g_Truth(or__1927000174__auto____2_2) { tmp9 = or__1927000174__auto____2_2 } else { tmp9 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_25.GetRawRoot__O()).Invoke_O__O(x__1) }
//line :226:1
					if jrt.J2g_Truth(tmp9) {



						var tmp10 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp11 *jrt.String; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1)) { tmp11 = Lit_28 } else { tmp11 = Lit_30 }; jrt.NN(tmp10).Append_String__StringBuilder(tmp11)
						var tmp12 *lang.Volatile = lang.Volatile_Cast(t.F_depth); var tmp13 jrt.Number_I; var na_54 any = jrt.NN(lang.Volatile_Cast(t.F_depth)).Deref__O(); if jrt.Long_InstanceOf(na_54) { var n0_55 int64 = jrt.NN(jrt.Long_Cast(na_54)).LongValue__J(); if n0_55 == 9223372036854775807 { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_54) } else { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_55 + 1)) } } else { if jrt.Double_InstanceOf(na_54) { var n0_55_2 float64 = jrt.NN(jrt.Double_Cast(na_54)).DoubleValue__D(); tmp13 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_55_2 + 1.0)) } else { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_54) } }; jrt.NN(tmp12).Reset_O__O(tmp13)
//line :226:1
						var seq_1839000122__2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_layout_A_const_103.GetRawRoot__O(), x__1)); var chunk_1839000123__3 any; var count_1839000124__4 int64 = 0; var i_1839000125__5 int64 = 0; L1: for {





							if lang.Numbers_Lt_J_J__Z_NoInit(i_1839000125__5, count_1839000124__4) { var vec__1839000126__6 any = lang.Indexed_Cast(chunk_1839000123__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1839000125__5)); var i__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000126__6, lang.RT_IntCast_J__I_NoInit(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000126__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp14 any; var and__1927000168__auto____9 bool; var na_58 any = i__7
								if jrt.Long_InstanceOf(na_58) { var n0_59 int64 = jrt.NN(jrt.Long_Cast(na_58)).LongValue__J(); and__1927000168__auto____9 = n0_59 > 0 } else { if jrt.Double_InstanceOf(na_58) { var n0_59_2 float64 = jrt.NN(jrt.Double_Cast(na_58)).DoubleValue__D(); and__1927000168__auto____9 = n0_59_2 > 0.0 } else { and__1927000168__auto____9 = lang.Numbers_IsPos_O__Z_NoInit(na_58) } }; if and__1927000168__auto____9 {
									var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_38.GetRawRoot__O()); var tmp16 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(c__8)) { tmp16 = A_arbace_repr_go_layout_A_const_37.Invoke_O__O(c__8) } else { var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_17.GetRawRoot__O()).Invoke_O__O(c__8); if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp17 *lang.Keyword = A_arbace_repr_go_layout_A_const_40; tmp16 = tmp17.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(c__8)) } else { tmp16 = and__1927000168__auto____10 } }; tmp14 = tmp15.Invoke_O__O(tmp16) } else {
//line :233:1
										tmp14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9).Ref() }; if jrt.J2g_Truth(tmp14) {

											var tmp18 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp18).Append_String__StringBuilder(Lit_9) }
								lang.IFn_Cast(self).Invoke_O__O(c__8)
//line :232:1
								seq_1839000122__2, chunk_1839000123__3, count_1839000124__4, i_1839000125__5 = seq_1839000122__2, chunk_1839000123__3, count_1839000124__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1839000125__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_1839000122__2); if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1839000122__7 any = temp__1927000414__auto____6; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1839000122__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_76.GetRawRoot__O()).Invoke_O__O(seq_1839000122__7); seq_1839000122__2, chunk_1839000123__3, count_1839000124__4, i_1839000125__5 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_81.GetRawRoot__O()).Invoke_O__O(seq_1839000122__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1839000129__8 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1839000122__7); var i__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000129__8, lang.RT_IntCast_J__I_NoInit(0), nil); var c__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000129__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp19 any; var and__1927000168__auto____11 bool; var na_60 any = i__9
									if jrt.Long_InstanceOf(na_60) { var n0_61 int64 = jrt.NN(jrt.Long_Cast(na_60)).LongValue__J(); and__1927000168__auto____11 = n0_61 > 0 } else { if jrt.Double_InstanceOf(na_60) { var n0_61_2 float64 = jrt.NN(jrt.Double_Cast(na_60)).DoubleValue__D(); and__1927000168__auto____11 = n0_61_2 > 0.0 } else { and__1927000168__auto____11 = lang.Numbers_IsPos_O__Z_NoInit(na_60) } }; if and__1927000168__auto____11 {
										var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_38.GetRawRoot__O()); var tmp21 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(c__10)) { tmp21 = A_arbace_repr_go_layout_A_const_37.Invoke_O__O(c__10) } else { var and__1927000168__auto____12 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_17.GetRawRoot__O()).Invoke_O__O(c__10); if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp22 *lang.Keyword = A_arbace_repr_go_layout_A_const_40; tmp21 = tmp22.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(c__10)) } else { tmp21 = and__1927000168__auto____12 } }; tmp19 = tmp20.Invoke_O__O(tmp21) } else {
//line :233:1
											tmp19 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() }; if jrt.J2g_Truth(tmp19) {

												var tmp23 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp23).Append_String__StringBuilder(Lit_9) }
									lang.IFn_Cast(self).Invoke_O__O(c__10)
//line :232:1
									seq_1839000122__2, chunk_1839000123__3, count_1839000124__4, i_1839000125__5 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_43.GetRawRoot__O()).Invoke_O__O(seq_1839000122__7), nil, 0, 0; continue L1 } } }
//line :226:1
							break L1
						}









						var tmp24 *lang.Volatile = lang.Volatile_Cast(t.F_depth); var tmp25 jrt.Number_I; var na_56 any = jrt.NN(lang.Volatile_Cast(t.F_depth)).Deref__O(); if jrt.Long_InstanceOf(na_56) { var n0_57 int64 = jrt.NN(jrt.Long_Cast(na_56)).LongValue__J(); if n0_57 == -9223372036854775808 { tmp25 = lang.Numbers_Dec_O__Number_NoInit(na_56) } else { tmp25 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_57 - 1)) } } else { if jrt.Double_InstanceOf(na_56) { var n0_57_2 float64 = jrt.NN(jrt.Double_Cast(na_56)).DoubleValue__D(); tmp25 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_57_2 - 1.0)) } else { tmp25 = lang.Numbers_Dec_O__Number_NoInit(na_56) } }; jrt.NN(tmp24).Reset_O__O(tmp25)
						var tmp26 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp27 *jrt.String; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1)) { tmp27 = Lit_29 } else { tmp27 = Lit_31 }; return jrt.NN(tmp26).Append_String__StringBuilder(tmp27).Ref() } else {
//line :226:1
							if A_arbace_repr_go_layout_A_const_35 != nil {












								var tmp28 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); return jrt.NN(tmp28).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_106.GetRawRoot__O()).Invoke_O__O(x__1))).Ref() } else {
//line :226:1
									return nil
								}
						}
				}
		}
}




















func A_arbace_repr_go_layout_write_package_A_New() *A_arbace_repr_go_layout_write_package_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_repr_go_layout_write_package_A) Ctor() {}
//line :252:1
func (t *A_arbace_repr_go_layout_write_package_A) Invoke_O_O_O_O__O(self, ns_sym__0, pkg_form__1, loads__2 any) any { var vec__1839000138__4 any = pkg_form__1; var seq__1839000139__5 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(vec__1839000138__4); var first__1839000140__6 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1839000139__5); var seq__1839000139__7 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_43.GetRawRoot__O()).Invoke_O__O(seq__1839000139__5); var head__8 any = first__1839000140__6; var first__1839000140__9 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1839000139__7); var seq__1839000139__10 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_43.GetRawRoot__O()).Invoke_O__O(seq__1839000139__7); var nm__11 any = first__1839000140__9; var opts__12 any = seq__1839000139__10; var tmp1 *jrt.RefArray = jrt.ConstRefArray("[0,10,s4:(ns ns35:\n  (:require [arbace.go :as go]))\n\ns1:(ns1: nns3:)\n\nn", []*jrt.Class{jrt.String_class}); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_48.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var tmp4 any; var iter__1927001039__auto____23 any; var tmp5 any = A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A_New(); var tmp6 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A_fn_class; if





	fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A_fn_class = fncls__70d; tmp6 = fncls__70d } else { tmp6 = fncls__70 }; iter__1927001039__auto____23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____23).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_120.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_layout_A_const_112, opts__12)); var tmp7 any = /*line :256:1*/tmp2.Invoke_O_O__O(tmp3, tmp4); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_48.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var tmp10 any; var iter__1927001039__auto____23_2 any; var tmp11 any = A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A_New(); var tmp12 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A_fn_class; if



	fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A_fn_class = fncls__73d; tmp12 = fncls__73d } else { tmp12 = fncls__73 }; iter__1927001039__auto____23_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____23_2).Invoke_O__O(loads__2); return /*line :256:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, ns_sym__0, nil, nil, head__8, nil, nm__11, tmp7, nil, tmp8.Invoke_O_O__O(tmp9, tmp10))).Ref() }

func A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A_New() *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A) Ctor() {}
//line :258:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A) Invoke_O_O__O(self, s__1839000142__1 any) any { var tmp1 any = A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A_New_O_O(self, s__1839000142__1); var tmp2 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A_fn_class = fncls__69d; tmp2 = fncls__69d } else { tmp2 = fncls__69 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :258:1
func A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A{}; t.Ctor_O_O(p0, p1); return t }
//line :258:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A) Ctor_O_O(c__iter__1839000141, c__s__1839000142 any) { t.F_iter__1839000141 = c__iter__1839000141; t.F_s__1839000142 = c__s__1839000142 }
//line :258:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A) Invoke_O__O(self any) any { { var s__1839000142__1 any; var t_ any = t.F_s__1839000142; t.F_s__1839000142 = nil; s__1839000142__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1839000142__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000142__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_75.GetRawRoot__O()).Invoke_O__O(s__1839000142__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_76.GetRawRoot__O()).Invoke_O__O(s__1839000142__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000144__6 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_83.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A_New_O_I_O(b__1839000144__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A_fn_class = fncls__68d; tmp2 = fncls__68d } else { tmp2 = fncls__68 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1839000141); return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_88.GetRawRoot__O()).Invoke_O__O(b__1839000144__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_81.GetRawRoot__O()).Invoke_O__O(s__1839000142__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_88.GetRawRoot__O()).Invoke_O__O(b__1839000144__6), nil) } } else { var vec__1839000152__4 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1839000142__3); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000152__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000152__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000141); return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_87.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__5, nil, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_85.GetRawRoot__O()).Invoke_O__O(v__6))).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_89.GetRawRoot__O()).Invoke_O__O(s__1839000142__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :258:1
func A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :258:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A) Ctor_O_I_O(c__b__1839000144 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000144 = c__b__1839000144; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :258:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A) Invoke_O__O(self any) any { { var i__1839000143__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000143__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1839000148__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000143__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000148__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000148__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_84.GetRawRoot__O()); var tmp3 any = t.F_b__1839000144; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__3, nil, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_85.GetRawRoot__O()).Invoke_O__O(v__4))).Ref()); i__1839000143__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000143__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A_New() *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A) Ctor() {}
//line :260:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A) Invoke_O_O__O(self, s__1839000158__1 any) any { var tmp1 any = A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A_New_O_O(s__1839000158__1, self); var tmp2 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A_fn_class = fncls__72d; tmp2 = fncls__72d } else { tmp2 = fncls__72 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :260:1
func A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A{}; t.Ctor_O_O(p0, p1); return t }
//line :260:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A) Ctor_O_O(c__s__1839000158, c__iter__1839000157 any) { t.F_s__1839000158 = c__s__1839000158; t.F_iter__1839000157 = c__iter__1839000157 }
//line :260:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A) Invoke_O__O(self any) any { { var s__1839000158__1 any; var t_ any = t.F_s__1839000158; t.F_s__1839000158 = nil; s__1839000158__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1839000158__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000158__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_75.GetRawRoot__O()).Invoke_O__O(s__1839000158__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_76.GetRawRoot__O()).Invoke_O__O(s__1839000158__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000160__6 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_83.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A_New_O_I_O(b__1839000160__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A_fn_class = fncls__71d; tmp2 = fncls__71d } else { tmp2 = fncls__71 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1839000157); return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_88.GetRawRoot__O()).Invoke_O__O(b__1839000160__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_81.GetRawRoot__O()).Invoke_O__O(s__1839000158__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_88.GetRawRoot__O()).Invoke_O__O(b__1839000160__6), nil) } } else { var l__4 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1839000158__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000157); return lang.IFn_Cast(A_arbace_repr_go_layout_A_const_87.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil, Lit_52), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_92.GetRawRoot__O()).Invoke_O__O(l__4), nil)).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_layout_A_const_89.GetRawRoot__O()).Invoke_O__O(s__1839000158__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :260:1
func A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :260:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A) Ctor_O_I_O(c__b__1839000160 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000160 = c__b__1839000160; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :260:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A) Invoke_O__O(self any) any { { var i__1839000159__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000159__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000159__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_84.GetRawRoot__O()); var tmp3 any = t.F_b__1839000160; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil, Lit_52), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_layout_A_const_92.GetRawRoot__O()).Invoke_O__O(l__2), nil)).Ref()); i__1839000159__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000159__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



































type A_arbace_repr_go_layout_A struct{ jrt.Object }

var A_arbace_repr_go_layout_A_const_pool *jrt.RefArray

var A_arbace_repr_go_layout_A_const_0 *lang.Var

var A_arbace_repr_go_layout_A_const_1 *lang.Var

var A_arbace_repr_go_layout_A_const_2 any

var A_arbace_repr_go_layout_A_const_3 any

var A_arbace_repr_go_layout_A_const_4 any

var A_arbace_repr_go_layout_A_const_5 *lang.Var

var A_arbace_repr_go_layout_A_const_6 *lang.Var

var A_arbace_repr_go_layout_A_const_7 *lang.Var

var A_arbace_repr_go_layout_A_const_8 any

var A_arbace_repr_go_layout_A_const_9 *lang.Var

var A_arbace_repr_go_layout_A_const_10 *lang.Var

var A_arbace_repr_go_layout_A_const_11 *lang.Var

var A_arbace_repr_go_layout_A_const_12 *lang.Var

var A_arbace_repr_go_layout_A_const_13 *lang.Var

var A_arbace_repr_go_layout_A_const_14 *lang.Keyword

var A_arbace_repr_go_layout_A_const_15 *lang.Var

var A_arbace_repr_go_layout_A_const_16 *lang.Keyword

var A_arbace_repr_go_layout_A_const_17 *lang.Var

var A_arbace_repr_go_layout_A_const_18 *lang.Keyword

var A_arbace_repr_go_layout_A_const_19 *lang.Var

var A_arbace_repr_go_layout_A_const_20 *lang.Var

var A_arbace_repr_go_layout_A_const_21 *lang.Var

var A_arbace_repr_go_layout_A_const_22 *lang.Var

var A_arbace_repr_go_layout_A_const_23 *lang.Var

var A_arbace_repr_go_layout_A_const_24 any

var A_arbace_repr_go_layout_A_const_25 *lang.Var

var A_arbace_repr_go_layout_A_const_26 *lang.Keyword

var A_arbace_repr_go_layout_A_const_27 *lang.Var

var A_arbace_repr_go_layout_A_const_28 *lang.Keyword

var A_arbace_repr_go_layout_A_const_29 *lang.Var

var A_arbace_repr_go_layout_A_const_30 *lang.Var

var A_arbace_repr_go_layout_A_const_31 *lang.Var

var A_arbace_repr_go_layout_A_const_32 *lang.Var

var A_arbace_repr_go_layout_A_const_33 *lang.Var

var A_arbace_repr_go_layout_A_const_34 *lang.Var

var A_arbace_repr_go_layout_A_const_35 *lang.Keyword

var A_arbace_repr_go_layout_A_const_36 *lang.Var

var A_arbace_repr_go_layout_A_const_37 *lang.Keyword

var A_arbace_repr_go_layout_A_const_38 *lang.Var

var A_arbace_repr_go_layout_A_const_39 *lang.Var

var A_arbace_repr_go_layout_A_const_40 *lang.Keyword

var A_arbace_repr_go_layout_A_const_41 *lang.Var

var A_arbace_repr_go_layout_A_const_42 *lang.Keyword

var A_arbace_repr_go_layout_A_const_43 *lang.Var

var A_arbace_repr_go_layout_A_const_44 *lang.Keyword

var A_arbace_repr_go_layout_A_const_45 *lang.Var

var A_arbace_repr_go_layout_A_const_46 *lang.Var

var A_arbace_repr_go_layout_A_const_47 any

var A_arbace_repr_go_layout_A_const_48 *lang.Var

var A_arbace_repr_go_layout_A_const_49 *lang.Keyword

var A_arbace_repr_go_layout_A_const_50 *lang.Var

var A_arbace_repr_go_layout_A_const_51 *lang.Var

var A_arbace_repr_go_layout_A_const_52 *lang.Keyword

var A_arbace_repr_go_layout_A_const_53 *lang.Keyword

var A_arbace_repr_go_layout_A_const_54 *lang.Var

var A_arbace_repr_go_layout_A_const_55 *lang.Var

var A_arbace_repr_go_layout_A_const_56 *lang.Var

var A_arbace_repr_go_layout_A_const_57 *lang.Var

var A_arbace_repr_go_layout_A_const_58 *lang.Var

var A_arbace_repr_go_layout_A_const_59 *lang.Var

var A_arbace_repr_go_layout_A_const_60 *lang.Var

var A_arbace_repr_go_layout_A_const_61 *lang.Var

var A_arbace_repr_go_layout_A_const_62 *lang.Var

var A_arbace_repr_go_layout_A_const_63 *lang.Var

var A_arbace_repr_go_layout_A_const_64 *lang.Keyword

var A_arbace_repr_go_layout_A_const_65 *lang.Keyword

var A_arbace_repr_go_layout_A_const_66 *lang.Keyword

var A_arbace_repr_go_layout_A_const_67 *lang.Keyword

var A_arbace_repr_go_layout_A_const_68 *lang.Var

var A_arbace_repr_go_layout_A_const_69 *lang.Var

var A_arbace_repr_go_layout_A_const_70 *lang.Var

var A_arbace_repr_go_layout_A_const_71 *lang.Var

var A_arbace_repr_go_layout_A_const_72 *lang.Var

var A_arbace_repr_go_layout_A_const_73 *lang.Var

var A_arbace_repr_go_layout_A_const_74 *lang.Keyword

var A_arbace_repr_go_layout_A_const_75 *lang.Var

var A_arbace_repr_go_layout_A_const_76 *lang.Var

var A_arbace_repr_go_layout_A_const_77 *lang.Var

var A_arbace_repr_go_layout_A_const_78 any

var A_arbace_repr_go_layout_A_const_79 *lang.Var

var A_arbace_repr_go_layout_A_const_80 *lang.Keyword

var A_arbace_repr_go_layout_A_const_81 *lang.Var

var A_arbace_repr_go_layout_A_const_82 *lang.Var

var A_arbace_repr_go_layout_A_const_83 *lang.Var

var A_arbace_repr_go_layout_A_const_84 *lang.Var

var A_arbace_repr_go_layout_A_const_85 *lang.Var

var A_arbace_repr_go_layout_A_const_86 *lang.Var

var A_arbace_repr_go_layout_A_const_87 *lang.Var

var A_arbace_repr_go_layout_A_const_88 *lang.Var

var A_arbace_repr_go_layout_A_const_89 *lang.Var

var A_arbace_repr_go_layout_A_const_90 *lang.Keyword

var A_arbace_repr_go_layout_A_const_91 *lang.Var

var A_arbace_repr_go_layout_A_const_92 *lang.Var

var A_arbace_repr_go_layout_A_const_93 *lang.Var

var A_arbace_repr_go_layout_A_const_94 *lang.Var

var A_arbace_repr_go_layout_A_const_95 *lang.Var

var A_arbace_repr_go_layout_A_const_96 *lang.Var

var A_arbace_repr_go_layout_A_const_97 *lang.Var

var A_arbace_repr_go_layout_A_const_98 *lang.Var

var A_arbace_repr_go_layout_A_const_99 *lang.Var

var A_arbace_repr_go_layout_A_const_100 *lang.Keyword

var A_arbace_repr_go_layout_A_const_101 any

var A_arbace_repr_go_layout_A_const_102 *lang.Var

var A_arbace_repr_go_layout_A_const_103 *lang.Var

var A_arbace_repr_go_layout_A_const_104 *lang.Var

var A_arbace_repr_go_layout_A_const_105 *lang.Var

var A_arbace_repr_go_layout_A_const_106 *lang.Var

var A_arbace_repr_go_layout_A_const_107 *lang.Var

var A_arbace_repr_go_layout_A_const_108 *lang.Var

var A_arbace_repr_go_layout_A_const_109 *lang.Var

var A_arbace_repr_go_layout_A_const_110 *lang.Var

var A_arbace_repr_go_layout_A_const_111 *lang.Var

var A_arbace_repr_go_layout_A_const_112 any

var A_arbace_repr_go_layout_A_const_113 *lang.Var

var A_arbace_repr_go_layout_A_const_114 *lang.Var

var A_arbace_repr_go_layout_A_const_115 *lang.Var

var A_arbace_repr_go_layout_A_const_116 *lang.Var

var A_arbace_repr_go_layout_A_const_117 *lang.Var

var A_arbace_repr_go_layout_A_const_118 any

var A_arbace_repr_go_layout_A_const_119 *lang.Var

var A_arbace_repr_go_layout_A_const_120 *lang.Var

var A_arbace_repr_go_layout_A_init jrt.ClassInit

func A_arbace_repr_go_layout_A_Init() { if !A_arbace_repr_go_layout_A_init.Done() { A_arbace_repr_go_layout_A_init.Run(A_arbace_repr_go_layout_A_clinit) } }

func A_arbace_repr_go_layout_A_clinit() { A_arbace_repr_go_layout_A_clinit_p0(); A_arbace_repr_go_layout_A_clinit_p1(); A_arbace_repr_go_layout_A_clinit_p2(); A_arbace_repr_go_layout_A_clinit_p3(); A_arbace_repr_go_layout_A_clinit_p4(); A_arbace_repr_go_layout_A_clinit_p5(); A_arbace_repr_go_layout_A_clinit_p6(); A_arbace_repr_go_layout_A_clinit_p7(); A_arbace_repr_go_layout_A_clinit_p8(); A_arbace_repr_go_layout_A_clinit_p9(); A_arbace_repr_go_layout_A_clinit_p10() }

func A_arbace_repr_go_layout_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_layout_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 155); A_arbace_repr_go_layout_A_const_0 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[34]); A_arbace_repr_go_layout_A_const_1 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[35]); A_arbace_repr_go_layout_A_const_2 = A_arbace_repr_go_layout_A_const_pool.A[36]; A_arbace_repr_go_layout_A_const_3 = A_arbace_repr_go_layout_A_const_pool.A[37]; A_arbace_repr_go_layout_A_const_4 = A_arbace_repr_go_layout_A_const_pool.A[38]; A_arbace_repr_go_layout_A_const_5 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[39]); A_arbace_repr_go_layout_A_const_6 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[40]); A_arbace_repr_go_layout_A_const_7 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[41]); A_arbace_repr_go_layout_A_const_8 = A_arbace_repr_go_layout_A_const_pool.A[42]; A_arbace_repr_go_layout_A_const_9 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[43]); A_arbace_repr_go_layout_A_const_10 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[44]); A_arbace_repr_go_layout_A_const_11 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[45]) }

func A_arbace_repr_go_layout_A_clinit_p1() { A_arbace_repr_go_layout_A_const_12 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[46]); A_arbace_repr_go_layout_A_const_13 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[47]); A_arbace_repr_go_layout_A_const_14 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[48]); A_arbace_repr_go_layout_A_const_15 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[49]); A_arbace_repr_go_layout_A_const_16 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[50]); A_arbace_repr_go_layout_A_const_17 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[51]); A_arbace_repr_go_layout_A_const_18 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[52]); A_arbace_repr_go_layout_A_const_19 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[53]); A_arbace_repr_go_layout_A_const_20 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[54]); A_arbace_repr_go_layout_A_const_21 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[55]); A_arbace_repr_go_layout_A_const_22 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[56]); A_arbace_repr_go_layout_A_const_23 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[57]) }

func A_arbace_repr_go_layout_A_clinit_p2() { A_arbace_repr_go_layout_A_const_24 = A_arbace_repr_go_layout_A_const_pool.A[58]; A_arbace_repr_go_layout_A_const_25 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[59]); A_arbace_repr_go_layout_A_const_26 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[60]); A_arbace_repr_go_layout_A_const_27 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[61]); A_arbace_repr_go_layout_A_const_28 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[62]); A_arbace_repr_go_layout_A_const_29 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[63]); A_arbace_repr_go_layout_A_const_30 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[64]); A_arbace_repr_go_layout_A_const_31 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[65]); A_arbace_repr_go_layout_A_const_32 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[66]); A_arbace_repr_go_layout_A_const_33 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[67]); A_arbace_repr_go_layout_A_const_34 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[68]); A_arbace_repr_go_layout_A_const_35 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[69]) }

func A_arbace_repr_go_layout_A_clinit_p3() { A_arbace_repr_go_layout_A_const_36 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[70]); A_arbace_repr_go_layout_A_const_37 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[71]); A_arbace_repr_go_layout_A_const_38 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[72]); A_arbace_repr_go_layout_A_const_39 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[73]); A_arbace_repr_go_layout_A_const_40 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[74]); A_arbace_repr_go_layout_A_const_41 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[75]); A_arbace_repr_go_layout_A_const_42 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[76]); A_arbace_repr_go_layout_A_const_43 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[77]); A_arbace_repr_go_layout_A_const_44 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[78]); A_arbace_repr_go_layout_A_const_45 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[79]); A_arbace_repr_go_layout_A_const_46 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[80]); A_arbace_repr_go_layout_A_const_47 = A_arbace_repr_go_layout_A_const_pool.A[81] }

func A_arbace_repr_go_layout_A_clinit_p4() { A_arbace_repr_go_layout_A_const_48 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[82]); A_arbace_repr_go_layout_A_const_49 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[83]); A_arbace_repr_go_layout_A_const_50 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[84]); A_arbace_repr_go_layout_A_const_51 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[85]); A_arbace_repr_go_layout_A_const_52 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[86]); A_arbace_repr_go_layout_A_const_53 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[87]); A_arbace_repr_go_layout_A_const_54 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[88]); A_arbace_repr_go_layout_A_const_55 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[89]); A_arbace_repr_go_layout_A_const_56 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[90]); A_arbace_repr_go_layout_A_const_57 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[91]); A_arbace_repr_go_layout_A_const_58 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[92]); A_arbace_repr_go_layout_A_const_59 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[93]) }

func A_arbace_repr_go_layout_A_clinit_p5() { A_arbace_repr_go_layout_A_const_60 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[94]); A_arbace_repr_go_layout_A_const_61 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[95]); A_arbace_repr_go_layout_A_const_62 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[96]); A_arbace_repr_go_layout_A_const_63 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[97]); A_arbace_repr_go_layout_A_const_64 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[98]); A_arbace_repr_go_layout_A_const_65 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[99]); A_arbace_repr_go_layout_A_const_66 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[100]); A_arbace_repr_go_layout_A_const_67 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[101]); A_arbace_repr_go_layout_A_const_68 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[102]); A_arbace_repr_go_layout_A_const_69 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[103]); A_arbace_repr_go_layout_A_const_70 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[104]); A_arbace_repr_go_layout_A_const_71 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[105]) }

func A_arbace_repr_go_layout_A_clinit_p6() { A_arbace_repr_go_layout_A_const_72 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[106]); A_arbace_repr_go_layout_A_const_73 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[107]); A_arbace_repr_go_layout_A_const_74 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[108]); A_arbace_repr_go_layout_A_const_75 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[109]); A_arbace_repr_go_layout_A_const_76 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[110]); A_arbace_repr_go_layout_A_const_77 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[111]); A_arbace_repr_go_layout_A_const_78 = A_arbace_repr_go_layout_A_const_pool.A[112]; A_arbace_repr_go_layout_A_const_79 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[113]); A_arbace_repr_go_layout_A_const_80 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[114]); A_arbace_repr_go_layout_A_const_81 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[115]); A_arbace_repr_go_layout_A_const_82 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[116]); A_arbace_repr_go_layout_A_const_83 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[117]) }

func A_arbace_repr_go_layout_A_clinit_p7() { A_arbace_repr_go_layout_A_const_84 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[118]); A_arbace_repr_go_layout_A_const_85 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[119]); A_arbace_repr_go_layout_A_const_86 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[120]); A_arbace_repr_go_layout_A_const_87 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[121]); A_arbace_repr_go_layout_A_const_88 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[122]); A_arbace_repr_go_layout_A_const_89 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[123]); A_arbace_repr_go_layout_A_const_90 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[124]); A_arbace_repr_go_layout_A_const_91 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[125]); A_arbace_repr_go_layout_A_const_92 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[126]); A_arbace_repr_go_layout_A_const_93 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[127]); A_arbace_repr_go_layout_A_const_94 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[128]); A_arbace_repr_go_layout_A_const_95 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[129]) }

func A_arbace_repr_go_layout_A_clinit_p8() { A_arbace_repr_go_layout_A_const_96 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[130]); A_arbace_repr_go_layout_A_const_97 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[131]); A_arbace_repr_go_layout_A_const_98 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[132]); A_arbace_repr_go_layout_A_const_99 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[133]); A_arbace_repr_go_layout_A_const_100 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[134]); A_arbace_repr_go_layout_A_const_101 = A_arbace_repr_go_layout_A_const_pool.A[135]; A_arbace_repr_go_layout_A_const_102 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[136]); A_arbace_repr_go_layout_A_const_103 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[137]); A_arbace_repr_go_layout_A_const_104 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[138]); A_arbace_repr_go_layout_A_const_105 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[139]); A_arbace_repr_go_layout_A_const_106 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[140]); A_arbace_repr_go_layout_A_const_107 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[141]) }

func A_arbace_repr_go_layout_A_clinit_p9() { A_arbace_repr_go_layout_A_const_108 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[142]); A_arbace_repr_go_layout_A_const_109 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[143]); A_arbace_repr_go_layout_A_const_110 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[144]); A_arbace_repr_go_layout_A_const_111 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[145]); A_arbace_repr_go_layout_A_const_112 = A_arbace_repr_go_layout_A_const_pool.A[146]; A_arbace_repr_go_layout_A_const_113 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[147]); A_arbace_repr_go_layout_A_const_114 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[148]); A_arbace_repr_go_layout_A_const_115 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[149]); A_arbace_repr_go_layout_A_const_116 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[150]); A_arbace_repr_go_layout_A_const_117 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[151]); A_arbace_repr_go_layout_A_const_118 = A_arbace_repr_go_layout_A_const_pool.A[152]; A_arbace_repr_go_layout_A_const_119 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[153]) }

func A_arbace_repr_go_layout_A_clinit_p10() { A_arbace_repr_go_layout_A_const_120 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[154]) }

func A_arbace_repr_go_layout_A_New() *A_arbace_repr_go_layout_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_layout_A) Ctor() {}

func (t *A_arbace_repr_go_layout_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_layout_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_layout_A_class }

func (t *A_arbace_repr_go_layout_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_layout_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_layout_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_layout_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_layout_A); return ok }

func A_arbace_repr_go_layout_A_Cast(x any) *A_arbace_repr_go_layout_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_layout_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_layout_A_class)) }; return v }



type A_arbace_repr_go_layout_atom_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_atom_text_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_comment_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_comment_text_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_deref_form_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_deref_form_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_eval1839000004_A struct{ jrt.Object }

func A_arbace_repr_go_layout_eval1839000004_A_New() *A_arbace_repr_go_layout_eval1839000004_A { t := &A_arbace_repr_go_layout_eval1839000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_layout_eval1839000004_A) Ctor() {}

func (t *A_arbace_repr_go_layout_eval1839000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_layout_eval1839000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_layout_eval1839000004_A_class }

func (t *A_arbace_repr_go_layout_eval1839000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_layout_eval1839000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_layout_eval1839000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_layout_eval1839000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_layout_eval1839000004_A); return ok }

func A_arbace_repr_go_layout_eval1839000004_A_Cast(x any) *A_arbace_repr_go_layout_eval1839000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_layout_eval1839000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_layout_eval1839000004_A_class)) }; return v }



type A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_eval1839000008_A struct{ jrt.Object }

func A_arbace_repr_go_layout_eval1839000008_A_New() *A_arbace_repr_go_layout_eval1839000008_A { t := &A_arbace_repr_go_layout_eval1839000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_layout_eval1839000008_A) Ctor() {}

func (t *A_arbace_repr_go_layout_eval1839000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_layout_eval1839000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_layout_eval1839000008_A_class }

func (t *A_arbace_repr_go_layout_eval1839000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_layout_eval1839000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_layout_eval1839000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_layout_eval1839000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_layout_eval1839000008_A); return ok }

func A_arbace_repr_go_layout_eval1839000008_A_Cast(x any) *A_arbace_repr_go_layout_eval1839000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_layout_eval1839000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_layout_eval1839000008_A_class)) }; return v }



type A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_form_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_form_line_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_iobj_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_iobj_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_key_rank_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_key_rank_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_lit_children_meta_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A struct{ j2g_header uint64; F_i, F_c any }

var A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A struct{ j2g_header uint64; F_i, F_v any }

var A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_meta_prefix_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A struct{ j2g_header uint64; F_pm any }

var A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A struct{ j2g_header uint64; F_pm any }

var A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A struct{ j2g_header uint64; F_pm any }

var A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A struct{ j2g_header uint64; F_s__1839000072, F_pm, F_iter__1839000071 any }

var A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A struct{ j2g_header uint64; F_b__1839000074, F_pm any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_note_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_note_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_prep_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000020_A struct{ j2g_header uint64; F_cursor, F_x any; F_lines_QMARK_ bool }

var A_arbace_repr_go_layout_prep_fn__1839000020_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A struct{ j2g_header uint64; F_l, F_brk, F_cursor, F_c any; F_lines_QMARK_ bool }

var A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A struct{ j2g_header uint64; F_i int64; F_c any }

var A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000036_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_prep_fn__1839000036_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prepare_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_prepare_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_private_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_private_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_public_meta_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_public_meta_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_public_meta_fn__1839000054_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_public_meta_fn__1839000054_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_sort_keys_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_sort_keys_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_sort_keys_fn__1839000050_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_text_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A struct{ j2g_header uint64; F_s__1839000100, F_iter__1839000099 any }

var A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A struct{ j2g_header uint64; F_b__1839000102 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_file_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_file_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_file_emit__1839000121_A struct{ j2g_header uint64; F_newline_to_BANG_, F_sb, F_code_QMARK_, F_depth any }

var A_arbace_repr_go_layout_write_file_emit__1839000121_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A struct{ j2g_header uint64; F_sb, F_code_QMARK_, F_line, F_comments, F_depth any }

var A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A struct{ j2g_header uint64; F_sb, F_code_QMARK_, F_line, F_flush_comments_BANG_, F_depth any }

var A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_package_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A struct{ j2g_header uint64; F_iter__1839000141, F_s__1839000142 any }

var A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A struct{ j2g_header uint64; F_b__1839000144 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A struct{ j2g_header uint64; F_s__1839000158, F_iter__1839000157 any }

var A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A struct{ j2g_header uint64; F_b__1839000160 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A_fn_class *jrt.Class
