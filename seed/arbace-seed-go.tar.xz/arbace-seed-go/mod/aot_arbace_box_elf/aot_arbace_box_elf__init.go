//line aot_arbace_box_elf__init.ae:1
package aot_arbace_box_elf

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :3:1
func A_arbace_box_elf__init_A_Unit0__O() any { A_arbace_box_elf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3, 1); return lang.IFn_Cast(jrt.NN(A_arbace_box_elf__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_box_elf__init_A_const_1) }
//line :3:1
func A_arbace_box_elf__init_A_Unit1__O() any { A_arbace_box_elf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_box_elf__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_box_elf__init_A_const_2)) }
//line :3:1
func A_arbace_box_elf__init_A_Unit2__O() any { A_arbace_box_elf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3, 1); var tmp1 any = A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_New(); var tmp2 *jrt.Class; A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_Init(); tmp2 = A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :3:1
func A_arbace_box_elf__init_A_Unit3__O() any { A_arbace_box_elf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_box_elf__init_A_const_1)).Equals_O__Z(A_arbace_box_elf__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_box_elf_eval581000008_fn__581000009_A_New(); var tmp2 *jrt.Class; A_arbace_box_elf_eval581000008_fn__581000009_A_Init(); tmp2 = A_arbace_box_elf_eval581000008_fn__581000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }

func A_arbace_box_elf__init_A_Load__O() any { A_arbace_box_elf__init_A_Init(); A_arbace_box_elf__init_A_Unit0__O(); A_arbace_box_elf__init_A_Unit1__O(); A_arbace_box_elf__init_A_Unit2__O(); A_arbace_box_elf__init_A_Unit3__O(); A_arbace_box_elf__init_A_Unit4__O(); A_arbace_box_elf__init_A_Unit5__O(); A_arbace_box_elf__init_A_Unit6__O(); A_arbace_box_elf__init_A_Unit7__O(); A_arbace_box_elf__init_A_Unit8__O(); A_arbace_box_elf__init_A_Unit9__O(); A_arbace_box_elf__init_A_Unit10__O(); A_arbace_box_elf__init_A_Unit11__O(); A_arbace_box_elf__init_A_Unit12__O(); return nil }









func A_arbace_box_elf__init_A_Unit4__O() any { A_arbace_box_elf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); var tmp1 *lang.Var = A_arbace_box_elf__init_A_const_4; var tmp2 any = A_arbace_box_elf_fail_A_New(); var tmp3 *jrt.Class; A_arbace_box_elf_fail_A_Init(); tmp3 = A_arbace_box_elf_fail_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_elf__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_elf__init_A_const_5)); return A_arbace_box_elf__init_A_const_4.Ref() }


func A_arbace_box_elf__init_A_Unit5__O() any { A_arbace_box_elf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); jrt.NN(A_arbace_box_elf__init_A_const_6).BindRoot_O__V(A_arbace_box_elf__init_A_const_7); var tmp1 *lang.Var = A_arbace_box_elf__init_A_const_6; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_elf__init_A_const_8)); return A_arbace_box_elf__init_A_const_6.Ref() }
func A_arbace_box_elf__init_A_Unit6__O() any { A_arbace_box_elf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); jrt.NN(A_arbace_box_elf__init_A_const_9).BindRoot_O__V(A_arbace_box_elf__init_A_const_10); var tmp1 *lang.Var = A_arbace_box_elf__init_A_const_9; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_elf__init_A_const_11)); return A_arbace_box_elf__init_A_const_9.Ref() }
func A_arbace_box_elf__init_A_Unit7__O() any { A_arbace_box_elf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); jrt.NN(A_arbace_box_elf__init_A_const_12).BindRoot_O__V(A_arbace_box_elf__init_A_const_13); var tmp1 *lang.Var = A_arbace_box_elf__init_A_const_12; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_elf__init_A_const_14)); return A_arbace_box_elf__init_A_const_12.Ref() }
func A_arbace_box_elf__init_A_Unit8__O() any { A_arbace_box_elf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); jrt.NN(A_arbace_box_elf__init_A_const_15).BindRoot_O__V(A_arbace_box_elf__init_A_const_7); var tmp1 *lang.Var = A_arbace_box_elf__init_A_const_15; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_elf__init_A_const_16)); return A_arbace_box_elf__init_A_const_15.Ref() }

func A_arbace_box_elf__init_A_Unit9__O() any { A_arbace_box_elf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); var tmp1 *lang.Var = A_arbace_box_elf__init_A_const_17; var tmp2 any = A_arbace_box_elf_le_A_New(); var tmp3 *jrt.Class; A_arbace_box_elf_le_A_Init(); tmp3 = A_arbace_box_elf_le_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_elf__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_elf__init_A_const_18)); return A_arbace_box_elf__init_A_const_17.Ref() }


func A_arbace_box_elf__init_A_Unit10__O() any { A_arbace_box_elf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var = A_arbace_box_elf__init_A_const_19; var tmp2 any = A_arbace_box_elf_c_string_A_New(); var tmp3 *jrt.Class; A_arbace_box_elf_c_string_A_Init(); tmp3 = A_arbace_box_elf_c_string_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_elf__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_elf__init_A_const_20)); return A_arbace_box_elf__init_A_const_19.Ref() }





func A_arbace_box_elf__init_A_Unit11__O() any { A_arbace_box_elf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); var tmp1 *lang.Var = A_arbace_box_elf__init_A_const_21; var tmp2 any = A_arbace_box_elf_align_A_New(); var tmp3 *jrt.Class; A_arbace_box_elf_align_A_Init(); tmp3 = A_arbace_box_elf_align_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_elf__init_A_const_21; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_elf__init_A_const_22)); return A_arbace_box_elf__init_A_const_21.Ref() }





func A_arbace_box_elf__init_A_Unit12__O() any { A_arbace_box_elf__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); var tmp1 *lang.Var = A_arbace_box_elf__init_A_const_23; var tmp2 any = A_arbace_box_elf_cut_symbols_A_New(); var tmp3 *jrt.Class; A_arbace_box_elf_cut_symbols_A_Init(); tmp3 = A_arbace_box_elf_cut_symbols_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_elf__init_A_const_23; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_elf__init_A_const_24)); return A_arbace_box_elf__init_A_const_23.Ref() }



type A_arbace_box_elf__init_A struct{ jrt.Object }

var A_arbace_box_elf__init_A_const_0 *lang.Var

var A_arbace_box_elf__init_A_const_1 any

var A_arbace_box_elf__init_A_const_2 any

var A_arbace_box_elf__init_A_const_3 any

var A_arbace_box_elf__init_A_const_4 *lang.Var

var A_arbace_box_elf__init_A_const_5 any

var A_arbace_box_elf__init_A_const_6 *lang.Var

var A_arbace_box_elf__init_A_const_7 any

var A_arbace_box_elf__init_A_const_8 any

var A_arbace_box_elf__init_A_const_9 *lang.Var

var A_arbace_box_elf__init_A_const_10 any

var A_arbace_box_elf__init_A_const_11 any

var A_arbace_box_elf__init_A_const_12 *lang.Var

var A_arbace_box_elf__init_A_const_13 any

var A_arbace_box_elf__init_A_const_14 any

var A_arbace_box_elf__init_A_const_15 *lang.Var

var A_arbace_box_elf__init_A_const_16 any

var A_arbace_box_elf__init_A_const_17 *lang.Var

var A_arbace_box_elf__init_A_const_18 any

var A_arbace_box_elf__init_A_const_19 *lang.Var

var A_arbace_box_elf__init_A_const_20 any

var A_arbace_box_elf__init_A_const_21 *lang.Var

var A_arbace_box_elf__init_A_const_22 any

var A_arbace_box_elf__init_A_const_23 *lang.Var

var A_arbace_box_elf__init_A_const_24 any

var A_arbace_box_elf__init_A_init jrt.ClassInit

func A_arbace_box_elf__init_A_Init() { if !A_arbace_box_elf__init_A_init.Done() { A_arbace_box_elf__init_A_init.Run(A_arbace_box_elf__init_A_clinit) } }

func A_arbace_box_elf__init_A_clinit() { A_arbace_box_elf__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_89); A_arbace_box_elf__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7))); A_arbace_box_elf__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7)); A_arbace_box_elf__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_box_elf__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_5, Lit_33); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_box_elf__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), jrt.Integer_ValueOf_I__Integer(15).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_94).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_95).Ref(), Lit_96)); A_arbace_box_elf__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_5, Lit_46); A_arbace_box_elf__init_A_const_7 = jrt.Long_ValueOf_J__Long(0).Ref(); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_box_elf__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), jrt.Integer_ValueOf_I__Integer(18).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_94).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_95).Ref(), Lit_96)); A_arbace_box_elf__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_5, Lit_42); A_arbace_box_elf__init_A_const_10 = jrt.Long_ValueOf_J__Long(2).Ref(); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_box_elf__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_94).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_95).Ref(), Lit_96)); A_arbace_box_elf__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_5, Lit_45); A_arbace_box_elf__init_A_const_13 = jrt.Long_ValueOf_J__Long(8).Ref(); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_box_elf__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), jrt.Integer_ValueOf_I__Integer(20).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_94).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_95).Ref(), Lit_96)); A_arbace_box_elf__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_5, Lit_32); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_box_elf__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), jrt.Integer_ValueOf_I__Integer(21).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_94).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_95).Ref(), Lit_96)); A_arbace_box_elf__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_5, Lit_13); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_box_elf__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_97)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_82).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), jrt.Integer_ValueOf_I__Integer(23).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_94).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_95).Ref(), Lit_96)); A_arbace_box_elf__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_5, Lit_49); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_box_elf__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_97)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_100)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), jrt.Integer_ValueOf_I__Integer(26).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_94).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_95).Ref(), Lit_96)); A_arbace_box_elf__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_5, Lit_18); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_box_elf__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_102)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_104)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_81).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), jrt.Integer_ValueOf_I__Integer(32).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_94).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_95).Ref(), Lit_96)); A_arbace_box_elf__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_5, Lit_105); A_arbace_box_elf__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref())).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_108, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), jrt.Integer_ValueOf_I__Integer(38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_94).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_95).Ref(), Lit_96)) }

func A_arbace_box_elf__init_A_New() *A_arbace_box_elf__init_A { A_arbace_box_elf__init_A_Init(); t := &A_arbace_box_elf__init_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf__init_A) Ctor() {}

func (t *A_arbace_box_elf__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf__init_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf__init_A_class }

func (t *A_arbace_box_elf__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf__init_A); return ok }

func A_arbace_box_elf__init_A_Cast(x any) *A_arbace_box_elf__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf__init_A_class)) }; return v }
