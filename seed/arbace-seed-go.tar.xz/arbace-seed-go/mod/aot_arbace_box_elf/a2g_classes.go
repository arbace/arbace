//line a2g_classes.ae:1
package aot_arbace_box_elf

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_box_elf_align_A_class, Name: "arbace.box.elf$align", Modifiers: 25, Simple: "align", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_align_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_c_string_A_class, Name: "arbace.box.elf$c_string", Modifiers: 25, Simple: "c_string", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_c_string_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_cut_symbols_A_class, Name: "arbace.box.elf$cut_symbols", Modifiers: 25, Simple: "cut_symbols", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_cut_symbols_fn__581000020_A_class, Name: "arbace.box.elf$cut_symbols$fn__581000020", Modifiers: 25, Simple: "fn__581000020", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_fn__581000020_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_cut_symbols_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_cut_symbols_fn__581000022_A_class, Name: "arbace.box.elf$cut_symbols$fn__581000022", Modifiers: 25, Simple: "fn__581000022", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_fn__581000022_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_cut_symbols_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_cut_symbols_fn__581000052_A_class, Name: "arbace.box.elf$cut_symbols$fn__581000052", Modifiers: 25, Simple: "fn__581000052", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_fn__581000052_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_cut_symbols_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_cut_symbols_fn__581000058_A_class, Name: "arbace.box.elf$cut_symbols$fn__581000058", Modifiers: 25, Simple: "fn__581000058", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_fn__581000058_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_cut_symbols_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_class, Name: "arbace.box.elf$cut_symbols$fn__581000058$fn__581000059", Modifiers: 25, Simple: "fn__581000059", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_cut_symbols_fn__581000058_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_class, Name: "arbace.box.elf$cut_symbols$iter__581000038__581000042", Modifiers: 25, Simple: "iter__581000038__581000042", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_cut_symbols_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_class, Name: "arbace.box.elf$cut_symbols$iter__581000038__581000042$fn__581000043", Modifiers: 25, Simple: "fn__581000043", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_class, Name: "arbace.box.elf$cut_symbols$iter__581000038__581000042$fn__581000043$fn__581000044", Modifiers: 25, Simple: "fn__581000044", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_cut_symbols_place__581000070_A_class, Name: "arbace.box.elf$cut_symbols$place__581000070", Modifiers: 25, Simple: "place__581000070", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_place__581000070_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_cut_symbols_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_cut_symbols_sec__581000018_A_class, Name: "arbace.box.elf$cut_symbols$sec__581000018", Modifiers: 25, Simple: "sec__581000018", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_sec__581000018_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_cut_symbols_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_class, Name: "arbace.box.elf$eval581000004$loading__1927001464__auto____581000005", Modifiers: 25, Simple: "loading__1927001464__auto____581000005", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_eval581000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_eval581000008_fn__581000009_A_class, Name: "arbace.box.elf$eval581000008$fn__581000009", Modifiers: 25, Simple: "fn__581000009", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_eval581000008_fn__581000009_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_eval581000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_fail_A_class, Name: "arbace.box.elf$fail", Modifiers: 25, Simple: "fail", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_fail_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_elf_le_A_class, Name: "arbace.box.elf$le", Modifiers: 25, Simple: "le", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_le_A", Source: "elf.ae", Declaring: &A_arbace_box_elf_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_box_elf_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_A_New()}; return nil }

var A_arbace_box_elf_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_elf_A_new}

var A_arbace_box_elf_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_A"})

func init() { i := A_arbace_box_elf_A_class.Info(); i.IsInstance = A_arbace_box_elf_A_InstanceOf; i.Init = A_arbace_box_elf_A_Init; i.Table = A_arbace_box_elf_A_members }

var A_arbace_box_elf_align_A_class *jrt.Class

var A_arbace_box_elf_c_string_A_class *jrt.Class

var A_arbace_box_elf_cut_symbols_A_class *jrt.Class

var A_arbace_box_elf_cut_symbols_fn__581000020_A_class *jrt.Class

var A_arbace_box_elf_cut_symbols_fn__581000022_A_class *jrt.Class

var A_arbace_box_elf_cut_symbols_fn__581000052_A_class *jrt.Class

var A_arbace_box_elf_cut_symbols_fn__581000058_A_class *jrt.Class

var A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_class *jrt.Class

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_class *jrt.Class

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_class *jrt.Class

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_class *jrt.Class

var A_arbace_box_elf_cut_symbols_place__581000070_A_class *jrt.Class

var A_arbace_box_elf_cut_symbols_sec__581000018_A_class *jrt.Class

func A_arbace_box_elf_eval581000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_eval581000004_A_New()}; return nil }

var A_arbace_box_elf_eval581000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_elf_eval581000004_A_new}

var A_arbace_box_elf_eval581000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$eval581000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_elf_A_class, Simple: "eval581000004", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_eval581000004_A"})

func init() { i := A_arbace_box_elf_eval581000004_A_class.Info(); i.IsInstance = A_arbace_box_elf_eval581000004_A_InstanceOf; i.Table = A_arbace_box_elf_eval581000004_A_members }

var A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_class *jrt.Class

func A_arbace_box_elf_eval581000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_eval581000008_A_New()}; return nil }

var A_arbace_box_elf_eval581000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_elf_eval581000008_A_new}

var A_arbace_box_elf_eval581000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$eval581000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_elf_A_class, Simple: "eval581000008", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_eval581000008_A"})

func init() { i := A_arbace_box_elf_eval581000008_A_class.Info(); i.IsInstance = A_arbace_box_elf_eval581000008_A_InstanceOf; i.Table = A_arbace_box_elf_eval581000008_A_members }

var A_arbace_box_elf_eval581000008_fn__581000009_A_class *jrt.Class

var A_arbace_box_elf_fail_A_class *jrt.Class

var A_arbace_box_elf_le_A_class *jrt.Class

func A_arbace_box_elf__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_box_elf__init_A_Load__O()}; return nil }

func A_arbace_box_elf__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf__init_A_New()}; return nil }

var A_arbace_box_elf__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_box_elf__init_A_invoke, New: A_arbace_box_elf__init_A_new}

var A_arbace_box_elf__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf__init_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf__init_A_class.Info(); i.IsInstance = A_arbace_box_elf__init_A_InstanceOf; i.Init = A_arbace_box_elf__init_A_Init; i.Table = A_arbace_box_elf__init_A_members }
