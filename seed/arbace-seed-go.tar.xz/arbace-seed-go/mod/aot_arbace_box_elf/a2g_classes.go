//line a2g_classes.ae:1
package aot_arbace_box_elf

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_box_elf_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_A_New()}; return nil }

var A_arbace_box_elf_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_elf_A_new}

var A_arbace_box_elf_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_A"})

func init() { i := A_arbace_box_elf_A_class.Info(); i.IsInstance = A_arbace_box_elf_A_InstanceOf; i.Init = A_arbace_box_elf_A_Init; i.Table = A_arbace_box_elf_A_members; jrt.RegisterGoType(A_arbace_box_elf_A_class, reflect.TypeFor[A_arbace_box_elf_A]()) }

func A_arbace_box_elf_align_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_align_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_elf_align_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_align_A_New()}; return nil }

func A_arbace_box_elf_align_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_align_A_fn_class)}; return nil }

var A_arbace_box_elf_align_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_align_A_invoke, New: A_arbace_box_elf_align_A_new, Get: A_arbace_box_elf_align_A_get}

var A_arbace_box_elf_align_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$align", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_elf_A_class, Simple: "align", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_align_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_align_A_class.Info(); i.IsInstance = A_arbace_box_elf_align_A_InstanceOf; i.Init = A_arbace_box_elf_align_A_Init; i.Table = A_arbace_box_elf_align_A_members; jrt.RegisterGoType(A_arbace_box_elf_align_A_class, reflect.TypeFor[A_arbace_box_elf_align_A]()) }

func A_arbace_box_elf_c_string_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_c_string_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_elf_c_string_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_c_string_A_New()}; return nil }

func A_arbace_box_elf_c_string_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_c_string_A_fn_class)}; return nil }

var A_arbace_box_elf_c_string_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_c_string_A_invoke, New: A_arbace_box_elf_c_string_A_new, Get: A_arbace_box_elf_c_string_A_get}

var A_arbace_box_elf_c_string_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$c_string", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_elf_A_class, Simple: "c_string", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_c_string_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_c_string_A_class.Info(); i.IsInstance = A_arbace_box_elf_c_string_A_InstanceOf; i.Init = A_arbace_box_elf_c_string_A_Init; i.Table = A_arbace_box_elf_c_string_A_members; jrt.RegisterGoType(A_arbace_box_elf_c_string_A_class, reflect.TypeFor[A_arbace_box_elf_c_string_A]()) }

func A_arbace_box_elf_cut_symbols_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_cut_symbols_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_elf_cut_symbols_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_cut_symbols_A_New()}; return nil }

func A_arbace_box_elf_cut_symbols_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_cut_symbols_A_fn_class)}; return nil }

var A_arbace_box_elf_cut_symbols_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_cut_symbols_A_invoke, New: A_arbace_box_elf_cut_symbols_A_new, Get: A_arbace_box_elf_cut_symbols_A_get}

var A_arbace_box_elf_cut_symbols_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$cut_symbols", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_elf_A_class, Simple: "cut_symbols", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_cut_symbols_A_class.Info(); i.IsInstance = A_arbace_box_elf_cut_symbols_A_InstanceOf; i.Init = A_arbace_box_elf_cut_symbols_A_Init; i.Table = A_arbace_box_elf_cut_symbols_A_members; jrt.RegisterGoType(A_arbace_box_elf_cut_symbols_A_class, reflect.TypeFor[A_arbace_box_elf_cut_symbols_A]()) }

func A_arbace_box_elf_cut_symbols_fn__581000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_cut_symbols_fn__581000020_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_elf_cut_symbols_fn__581000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_cut_symbols_fn__581000020_A_New()}; return nil }

func A_arbace_box_elf_cut_symbols_fn__581000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class)}; return nil }

var A_arbace_box_elf_cut_symbols_fn__581000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_cut_symbols_fn__581000020_A_invoke, New: A_arbace_box_elf_cut_symbols_fn__581000020_A_new, Get: A_arbace_box_elf_cut_symbols_fn__581000020_A_get}

var A_arbace_box_elf_cut_symbols_fn__581000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$cut_symbols$fn__581000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_elf_cut_symbols_A_class, Simple: "fn__581000020", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_fn__581000020_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_cut_symbols_fn__581000020_A_class.Info(); i.IsInstance = A_arbace_box_elf_cut_symbols_fn__581000020_A_InstanceOf; i.Init = A_arbace_box_elf_cut_symbols_fn__581000020_A_Init; i.Table = A_arbace_box_elf_cut_symbols_fn__581000020_A_members; jrt.RegisterGoType(A_arbace_box_elf_cut_symbols_fn__581000020_A_class, reflect.TypeFor[A_arbace_box_elf_cut_symbols_fn__581000020_A]()) }

func A_arbace_box_elf_cut_symbols_fn__581000022_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_cut_symbols_fn__581000022_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_elf_cut_symbols_fn__581000022_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_cut_symbols_fn__581000022_A_New_O(args[0])}; return nil }

func A_arbace_box_elf_cut_symbols_fn__581000022_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class)}; return nil }

var A_arbace_box_elf_cut_symbols_fn__581000022_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_cut_symbols_fn__581000022_A_invoke, New: A_arbace_box_elf_cut_symbols_fn__581000022_A_new, Get: A_arbace_box_elf_cut_symbols_fn__581000022_A_get}

var A_arbace_box_elf_cut_symbols_fn__581000022_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$cut_symbols$fn__581000022", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_elf_cut_symbols_A_class, Simple: "fn__581000022", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_fn__581000022_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_cut_symbols_fn__581000022_A_class.Info(); i.IsInstance = A_arbace_box_elf_cut_symbols_fn__581000022_A_InstanceOf; i.Init = A_arbace_box_elf_cut_symbols_fn__581000022_A_Init; i.Table = A_arbace_box_elf_cut_symbols_fn__581000022_A_members; jrt.RegisterGoType(A_arbace_box_elf_cut_symbols_fn__581000022_A_class, reflect.TypeFor[A_arbace_box_elf_cut_symbols_fn__581000022_A]()) }

func A_arbace_box_elf_cut_symbols_fn__581000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_cut_symbols_fn__581000052_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_elf_cut_symbols_fn__581000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_cut_symbols_fn__581000052_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_elf_cut_symbols_fn__581000052_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class)}; return nil }

var A_arbace_box_elf_cut_symbols_fn__581000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_cut_symbols_fn__581000052_A_invoke, New: A_arbace_box_elf_cut_symbols_fn__581000052_A_new, Get: A_arbace_box_elf_cut_symbols_fn__581000052_A_get}

var A_arbace_box_elf_cut_symbols_fn__581000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$cut_symbols$fn__581000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_elf_cut_symbols_A_class, Simple: "fn__581000052", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_fn__581000052_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_cut_symbols_fn__581000052_A_class.Info(); i.IsInstance = A_arbace_box_elf_cut_symbols_fn__581000052_A_InstanceOf; i.Init = A_arbace_box_elf_cut_symbols_fn__581000052_A_Init; i.Table = A_arbace_box_elf_cut_symbols_fn__581000052_A_members; jrt.RegisterGoType(A_arbace_box_elf_cut_symbols_fn__581000052_A_class, reflect.TypeFor[A_arbace_box_elf_cut_symbols_fn__581000052_A]()) }

func A_arbace_box_elf_cut_symbols_fn__581000058_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_cut_symbols_fn__581000058_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_elf_cut_symbols_fn__581000058_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_cut_symbols_fn__581000058_A_New()}; return nil }

func A_arbace_box_elf_cut_symbols_fn__581000058_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class)}; return nil }

var A_arbace_box_elf_cut_symbols_fn__581000058_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_cut_symbols_fn__581000058_A_invoke, New: A_arbace_box_elf_cut_symbols_fn__581000058_A_new, Get: A_arbace_box_elf_cut_symbols_fn__581000058_A_get}

var A_arbace_box_elf_cut_symbols_fn__581000058_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$cut_symbols$fn__581000058", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_elf_cut_symbols_A_class, Simple: "fn__581000058", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_fn__581000058_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_cut_symbols_fn__581000058_A_class.Info(); i.IsInstance = A_arbace_box_elf_cut_symbols_fn__581000058_A_InstanceOf; i.Init = A_arbace_box_elf_cut_symbols_fn__581000058_A_Init; i.Table = A_arbace_box_elf_cut_symbols_fn__581000058_A_members; jrt.RegisterGoType(A_arbace_box_elf_cut_symbols_fn__581000058_A_class, reflect.TypeFor[A_arbace_box_elf_cut_symbols_fn__581000058_A]()) }

func A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_New_O(args[0])}; return nil }

func A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class)}; return nil }

var A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_invoke, New: A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_new, Get: A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_get}

var A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$cut_symbols$fn__581000058$fn__581000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_elf_cut_symbols_fn__581000058_A_class, Simple: "fn__581000059", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_class.Info(); i.IsInstance = A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_InstanceOf; i.Init = A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_Init; i.Table = A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_members; jrt.RegisterGoType(A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_class, reflect.TypeFor[A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A]()) }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class)}; return nil }

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_invoke, New: A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_new, Get: A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_get}

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$cut_symbols$iter__581000038__581000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_elf_cut_symbols_A_class, Simple: "iter__581000038__581000042", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_class.Info(); i.IsInstance = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_InstanceOf; i.Init = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_Init; i.Table = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_members; jrt.RegisterGoType(A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_class, reflect.TypeFor[A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A]()) }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_New_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class)}; return nil }

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_invoke, New: A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_new, Get: A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_get}

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$cut_symbols$iter__581000038__581000042$fn__581000043", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_class, Simple: "fn__581000043", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_class.Info(); i.IsInstance = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_InstanceOf; i.Init = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_Init; i.Table = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_members; jrt.RegisterGoType(A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_class, reflect.TypeFor[A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A]()) }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_New_O_O_O_O_O_I_O_O(args[0], args[1], args[2], args[3], args[4], args[5].(int32), args[6], args[7])}; return nil }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class)}; return nil }

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_invoke, New: A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_new, Get: A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_get}

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$cut_symbols$iter__581000038__581000042$fn__581000043$fn__581000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_class, Simple: "fn__581000044", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_class.Info(); i.IsInstance = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_InstanceOf; i.Init = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_Init; i.Table = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_members; jrt.RegisterGoType(A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_class, reflect.TypeFor[A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A]()) }

func A_arbace_box_elf_cut_symbols_place__581000070_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_cut_symbols_place__581000070_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_elf_cut_symbols_place__581000070_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_cut_symbols_place__581000070_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_elf_cut_symbols_place__581000070_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class)}; return nil }

var A_arbace_box_elf_cut_symbols_place__581000070_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_cut_symbols_place__581000070_A_invoke, New: A_arbace_box_elf_cut_symbols_place__581000070_A_new, Get: A_arbace_box_elf_cut_symbols_place__581000070_A_get}

var A_arbace_box_elf_cut_symbols_place__581000070_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$cut_symbols$place__581000070", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_elf_cut_symbols_A_class, Simple: "place__581000070", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_place__581000070_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_cut_symbols_place__581000070_A_class.Info(); i.IsInstance = A_arbace_box_elf_cut_symbols_place__581000070_A_InstanceOf; i.Init = A_arbace_box_elf_cut_symbols_place__581000070_A_Init; i.Table = A_arbace_box_elf_cut_symbols_place__581000070_A_members; jrt.RegisterGoType(A_arbace_box_elf_cut_symbols_place__581000070_A_class, reflect.TypeFor[A_arbace_box_elf_cut_symbols_place__581000070_A]()) }

func A_arbace_box_elf_cut_symbols_sec__581000018_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_cut_symbols_sec__581000018_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_elf_cut_symbols_sec__581000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_cut_symbols_sec__581000018_A_New_J_J_O(args[0].(int64), args[1].(int64), args[2])}; return nil }

func A_arbace_box_elf_cut_symbols_sec__581000018_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class)}; return nil }

var A_arbace_box_elf_cut_symbols_sec__581000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (JJLjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_cut_symbols_sec__581000018_A_invoke, New: A_arbace_box_elf_cut_symbols_sec__581000018_A_new, Get: A_arbace_box_elf_cut_symbols_sec__581000018_A_get}

var A_arbace_box_elf_cut_symbols_sec__581000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$cut_symbols$sec__581000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_elf_cut_symbols_A_class, Simple: "sec__581000018", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_cut_symbols_sec__581000018_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_cut_symbols_sec__581000018_A_class.Info(); i.IsInstance = A_arbace_box_elf_cut_symbols_sec__581000018_A_InstanceOf; i.Init = A_arbace_box_elf_cut_symbols_sec__581000018_A_Init; i.Table = A_arbace_box_elf_cut_symbols_sec__581000018_A_members; jrt.RegisterGoType(A_arbace_box_elf_cut_symbols_sec__581000018_A_class, reflect.TypeFor[A_arbace_box_elf_cut_symbols_sec__581000018_A]()) }

func A_arbace_box_elf_eval581000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_eval581000004_A_New()}; return nil }

var A_arbace_box_elf_eval581000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_elf_eval581000004_A_new}

var A_arbace_box_elf_eval581000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$eval581000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_elf_A_class, Simple: "eval581000004", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_eval581000004_A"})

func init() { i := A_arbace_box_elf_eval581000004_A_class.Info(); i.IsInstance = A_arbace_box_elf_eval581000004_A_InstanceOf; i.Table = A_arbace_box_elf_eval581000004_A_members; jrt.RegisterGoType(A_arbace_box_elf_eval581000004_A_class, reflect.TypeFor[A_arbace_box_elf_eval581000004_A]()) }

func A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_New()}; return nil }

func A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_fn_class)}; return nil }

var A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_invoke, New: A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_new, Get: A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_get}

var A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$eval581000004$loading__1927001464__auto____581000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_elf_eval581000004_A_class, Simple: "loading__1927001464__auto____581000005", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_class.Info(); i.IsInstance = A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_InstanceOf; i.Init = A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_Init; i.Table = A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_members; jrt.RegisterGoType(A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_class, reflect.TypeFor[A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A]()) }

func A_arbace_box_elf_eval581000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_eval581000008_A_New()}; return nil }

var A_arbace_box_elf_eval581000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_elf_eval581000008_A_new}

var A_arbace_box_elf_eval581000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$eval581000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_elf_A_class, Simple: "eval581000008", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_eval581000008_A"})

func init() { i := A_arbace_box_elf_eval581000008_A_class.Info(); i.IsInstance = A_arbace_box_elf_eval581000008_A_InstanceOf; i.Table = A_arbace_box_elf_eval581000008_A_members; jrt.RegisterGoType(A_arbace_box_elf_eval581000008_A_class, reflect.TypeFor[A_arbace_box_elf_eval581000008_A]()) }

func A_arbace_box_elf_eval581000008_fn__581000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_eval581000008_fn__581000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_elf_eval581000008_fn__581000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_eval581000008_fn__581000009_A_New()}; return nil }

func A_arbace_box_elf_eval581000008_fn__581000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_eval581000008_fn__581000009_A_fn_class)}; return nil }

var A_arbace_box_elf_eval581000008_fn__581000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_eval581000008_fn__581000009_A_invoke, New: A_arbace_box_elf_eval581000008_fn__581000009_A_new, Get: A_arbace_box_elf_eval581000008_fn__581000009_A_get}

var A_arbace_box_elf_eval581000008_fn__581000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$eval581000008$fn__581000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_elf_eval581000008_A_class, Simple: "fn__581000009", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_eval581000008_fn__581000009_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_eval581000008_fn__581000009_A_class.Info(); i.IsInstance = A_arbace_box_elf_eval581000008_fn__581000009_A_InstanceOf; i.Init = A_arbace_box_elf_eval581000008_fn__581000009_A_Init; i.Table = A_arbace_box_elf_eval581000008_fn__581000009_A_members; jrt.RegisterGoType(A_arbace_box_elf_eval581000008_fn__581000009_A_class, reflect.TypeFor[A_arbace_box_elf_eval581000008_fn__581000009_A]()) }

func A_arbace_box_elf_fail_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_elf_fail_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_fail_A_New()}; return nil }

func A_arbace_box_elf_fail_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_fail_A_fn_class)}; return nil }

var A_arbace_box_elf_fail_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_fail_A_invoke, New: A_arbace_box_elf_fail_A_new, Get: A_arbace_box_elf_fail_A_get}

var A_arbace_box_elf_fail_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$fail", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_elf_A_class, Simple: "fail", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_fail_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_fail_A_class.Info(); i.IsInstance = A_arbace_box_elf_fail_A_InstanceOf; i.Init = A_arbace_box_elf_fail_A_Init; i.Table = A_arbace_box_elf_fail_A_members; jrt.RegisterGoType(A_arbace_box_elf_fail_A_class, reflect.TypeFor[A_arbace_box_elf_fail_A]()) }

func A_arbace_box_elf_le_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_elf_le_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_elf_le_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf_le_A_New()}; return nil }

func A_arbace_box_elf_le_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_elf_le_A_fn_class)}; return nil }

var A_arbace_box_elf_le_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_elf_le_A_invoke, New: A_arbace_box_elf_le_A_new, Get: A_arbace_box_elf_le_A_get}

var A_arbace_box_elf_le_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf$le", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_elf_A_class, Simple: "le", Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf_le_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf_le_A_class.Info(); i.IsInstance = A_arbace_box_elf_le_A_InstanceOf; i.Init = A_arbace_box_elf_le_A_Init; i.Table = A_arbace_box_elf_le_A_members; jrt.RegisterGoType(A_arbace_box_elf_le_A_class, reflect.TypeFor[A_arbace_box_elf_le_A]()) }

func A_arbace_box_elf__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_box_elf__init_A_Load__O(); case 1: return A_arbace_box_elf__init_A_Unit0__O(); case 2: return A_arbace_box_elf__init_A_Unit1__O(); case 3: return A_arbace_box_elf__init_A_Unit10__O(); case 4: return A_arbace_box_elf__init_A_Unit11__O(); case 5: return A_arbace_box_elf__init_A_Unit12__O(); case 6: return A_arbace_box_elf__init_A_Unit2__O(); case 7: return A_arbace_box_elf__init_A_Unit3__O(); case 8: return A_arbace_box_elf__init_A_Unit4__O(); case 9: return A_arbace_box_elf__init_A_Unit5__O(); case 10: return A_arbace_box_elf__init_A_Unit6__O(); case 11: return A_arbace_box_elf__init_A_Unit7__O(); case 12: return A_arbace_box_elf__init_A_Unit8__O(); case 13: return A_arbace_box_elf__init_A_Unit9__O()}; return nil }

func A_arbace_box_elf__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_elf__init_A_New()}; return nil }

var A_arbace_box_elf__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_box_elf__init_A_invoke, New: A_arbace_box_elf__init_A_new}

var A_arbace_box_elf__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.elf__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_elf.A_arbace_box_elf__init_A", Source: "elf.ae"})

func init() { i := A_arbace_box_elf__init_A_class.Info(); i.IsInstance = A_arbace_box_elf__init_A_InstanceOf; i.Init = A_arbace_box_elf__init_A_Init; i.Table = A_arbace_box_elf__init_A_members; jrt.RegisterGoType(A_arbace_box_elf__init_A_class, reflect.TypeFor[A_arbace_box_elf__init_A]()) }
