//line aot_arbace_box_elf.ae:1
package aot_arbace_box_elf

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :3:1
func A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_New() *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) Ctor() {}
//line :3:1
func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_elf_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_box_elf_A_const_1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_20)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_21)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_22)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_23)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :3:1
func A_arbace_box_elf_eval581000008_fn__581000009_A_New() *A_arbace_box_elf_eval581000008_fn__581000009_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_eval581000008_fn__581000009_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) Ctor() {}
//line :3:1
func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_box_elf_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_box_elf_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_box_elf_A_const_5.GetRawRoot__O(), A_arbace_box_elf_A_const_6) }











func A_arbace_box_elf_fail_A_New() *A_arbace_box_elf_fail_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_fail_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_box_elf_fail_A) Ctor() {}
//line :15:1
func (t *A_arbace_box_elf_fail_A) Invoke_O_O__O(self, msg__0 any) any { var tmp1 any; var root_15 any = A_arbace_box_elf_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_17 lang.IFn; if
									linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, msg__0)).Ref(); var arg_19 any = A_arbace_box_elf_A_const_8; if linked_16 == nil { tmp1 = ifn_17.Invoke_O_O__O(arg_18, arg_19) } else { tmp1 = linked_16.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_15, arg_18, arg_19) }; /*line :15:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }







func A_arbace_box_elf_le_A_New() *A_arbace_box_elf_le_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_le_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_box_elf_le_A) Ctor() {}
//line :23:1
func (t *A_arbace_box_elf_le_A) Invoke_O_O__O(self, b__0 any) any {
	var tmp1 jrt.ByteBuffer_I = jrt.ByteBuffer_Wrap_B1__ByteBuffer(jrt.ByteArray_Cast(b__0)); var tmp2 *jrt.ByteOrder; jrt.ByteOrder_Init(); tmp2 = jrt.ByteOrder_LITTLE_ENDIAN; return tmp1.Order_ByteOrder__ByteBuffer(tmp2)
}
func A_arbace_box_elf_c_string_A_New() *A_arbace_box_elf_c_string_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_c_string_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_box_elf_c_string_A) Ctor() {}
//line :26:1
func (t *A_arbace_box_elf_c_string_A) InvokePrim_O_O_J__O(self, b__0 any, off__1 int64) any { { var e__3 int64 = off__1; L1: for {

	if lang.Numbers_IsZero_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(e__3))).Ref())) { return jrt.String_New_B1_I_I_Charset(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(off__1), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(e__3, off__1)), jrt.StandardCharsets_UTF_8) } else {

		e__3 = lang.Numbers_Inc_J__J_NoInit(e__3); continue L1 } } }; /*line :26:1*/panic("j2g: unreachable") }
//line :26:1
func (t *A_arbace_box_elf_c_string_A) Invoke_O_O_O__O(self, b__0, p_off__1 any) any { return t.InvokePrim_O_O_J__O(self, b__0, lang.RT_LongCast_O__J_NoInit(p_off__1)) }





func A_arbace_box_elf_align_A_New() *A_arbace_box_elf_align_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_align_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_box_elf_align_A) Ctor() {}
//line :32:1
func (t *A_arbace_box_elf_align_A) InvokePrim_O_O_J__O(self, o__0 any, a__1 int64) any {
	if lang.Numbers_Gt_J_J__Z_NoInit(a__1, 1) { L1: for {
		var tmp1 any; var root_20 any = A_arbace_box_elf_A_const_9.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any; var tmp2 bool; var na_24 any; var root_25 any = A_arbace_box_elf_A_const_10.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_mod_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.ByteArrayOutputStream_Cast(o__0).Size__I()).Ref(); var arg_29 any = jrt.Long_ValueOf_J__Long_NoInit(a__1).Ref(); if linked_26 == nil { na_24 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { na_24 = linked_26.(*aot_arbace_core.A_arbace_core_mod_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; if jrt.Long_InstanceOf(na_24) { var n0_30 int64 = jrt.NN(jrt.Long_Cast(na_24)).LongValue__J(); tmp2 = n0_30 == 0 } else { if jrt.Double_InstanceOf(na_24) { var n0_30_2 float64 = jrt.NN(jrt.Double_Cast(na_24)).DoubleValue__D(); tmp2 = n0_30_2 == 0.0 } else { tmp2 = lang.Numbers_IsZero_O__Z_NoInit(na_24) } }; arg_23 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref(); if linked_21 == nil { tmp1 = ifn_22.Invoke_O__O(arg_23) } else { tmp1 = linked_21.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_20, arg_23) }; if jrt.J2g_Truth(tmp1) {
			jrt.ByteArrayOutputStream_Cast(o__0).Write_I__V(lang.RT_IntCast_J__I_NoInit(0))
//line :34:1
			continue L1 }
//line :33:1
		break L1 } }
//line :32:1
	return o__0 }
//line :32:1
func (t *A_arbace_box_elf_align_A) Invoke_O_O_O__O(self, o__0, p_a__1 any) any { return t.InvokePrim_O_O_J__O(self, o__0, lang.RT_LongCast_O__J_NoInit(p_a__1)) }





func A_arbace_box_elf_cut_symbols_A_New() *A_arbace_box_elf_cut_symbols_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_box_elf_cut_symbols_A) Ctor() {}
//line :38:1
func (t *A_arbace_box_elf_cut_symbols_A) Invoke_O_O_O__O(self, data__0, names__1 any) any { var b__3 any; var root_31 any = A_arbace_box_elf_A_const_11.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, A_arbace_box_elf_le_A_fn_class); var ifn_33 lang.IFn; if


	linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = data__0; if linked_32 == nil { b__3 = ifn_33.Invoke_O__O(arg_34) } else { b__3 = linked_32.(*A_arbace_box_elf_le_A).Invoke_O_O__O(root_31, arg_34) }; var tmp1 bool; var and__1927000168__auto____4 bool =
	lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(data__0))), 64); if and__1927000168__auto____4 { var and__1927000168__auto____5 bool = lang.Util_Equiv_J_J__Z_NoInit(127, lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(data__0), lang.RT_IntCast_J__I_NoInit(0))).Ref())); if and__1927000168__auto____5 { var and__1927000168__auto____6 bool = lang.Util_Equiv_J_J__Z_NoInit(2, lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(data__0), lang.RT_IntCast_J__I_NoInit(4))).Ref())); if and__1927000168__auto____6 { tmp1 = lang.Util_Equiv_J_J__Z_NoInit(1, lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(data__0), lang.RT_IntCast_J__I_NoInit(5))).Ref())) } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if tmp1 { } else {
		var root_385 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, A_arbace_box_elf_fail_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = Lit_1; if linked_386 == nil { ifn_387.Invoke_O__O(arg_388) } else { linked_386.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_385, arg_388) } }; var phoff__4 int64 = /*line :38:1*/jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_J__I_NoInit(32)); var shoff__5 int64 = jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_J__I_NoInit(40)); var phentsize__6 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Short_ValueOf_S__Short_NoInit(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I_NoInit(54))).Ref()), 65535); var phnum__7 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Short_ValueOf_S__Short_NoInit(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I_NoInit(56))).Ref()), 65535); var shentsize__8 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Short_ValueOf_S__Short_NoInit(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I_NoInit(58))).Ref()), 65535); var shnum__9 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Short_ValueOf_S__Short_NoInit(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I_NoInit(60))).Ref()), 65535); var shstrndx__10 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Short_ValueOf_S__Short_NoInit(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I_NoInit(62))).Ref()), 65535); var sec__11 any; var fnbody__76 any = A_arbace_box_elf_cut_symbols_sec__581000018_A_New_J_J_O(shentsize__8, shoff__5, b__3); var tmp2 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class; if









	fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__76); A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class = fncls__75d; tmp2 = fncls__75d } else { tmp2 = fncls__75 }; sec__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp2, nil); var secs__12 any; var root_77 any = /*line :38:1*/A_arbace_box_elf_A_const_18.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_79 lang.IFn; if













	linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = sec__11; var arg_81 any; var root_82 any = A_arbace_box_elf_A_const_19.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = jrt.Long_ValueOf_J__Long_NoInit(shnum__9).Ref(); if linked_83 == nil { arg_81 = ifn_84.Invoke_O__O(arg_85) } else { arg_81 = linked_83.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_82, arg_85) }; if linked_78 == nil { secs__12 = ifn_79.Invoke_O_O__O(arg_80, arg_81) } else { secs__12 = linked_78.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_77, arg_80, arg_81) }; var symtab__13 any; var root_86 any = /*line :38:1*/A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_88 lang.IFn; if














	linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any; var root_90 any = A_arbace_box_elf_A_const_21.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any; var fnbody__96 any = A_arbace_box_elf_cut_symbols_fn__581000020_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; arg_93 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); var arg_94 any = secs__12; if linked_91 == nil { arg_89 = ifn_92.Invoke_O_O__O(arg_93, arg_94) } else { arg_89 = linked_91.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_90, arg_93, arg_94) }; if linked_87 == nil { symtab__13 = ifn_88.Invoke_O__O(arg_89) } else { symtab__13 = linked_87.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_86, arg_89) }; var strtab__14 any; if
	jrt.J2g_Truth(symtab__13) { var tmp4 *lang.Keyword = A_arbace_box_elf_A_const_15; strtab__14 = tmp4.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(symtab__13)) } else { strtab__14 = nil }; var tmp5 bool; var or__1927000174__auto____15 bool =
	lang.Util_Identical_O_O__Z_NoInit(symtab__13, nil); if or__1927000174__auto____15 { tmp5 = or__1927000174__auto____15 } else { var or__1927000174__auto____16 bool; var na_389 any = strtab__14; var na_390 int64 = 0; if jrt.Long_InstanceOf(na_389) { var n0_391 int64 = jrt.NN(jrt.Long_Cast(na_389)).LongValue__J(); var n1_392 int64 = na_390; or__1927000174__auto____16 = n0_391 <= n1_392 } else { or__1927000174__auto____16 = lang.Numbers_Lte_O_J__Z_NoInit(na_389, na_390) }; if or__1927000174__auto____16 { tmp5 = or__1927000174__auto____16 } else { var or__1927000174__auto____17 bool; var na_394 any = strtab__14; var na_395 int64 = shnum__9; if jrt.Long_InstanceOf(na_394) { var n0_396 int64 = jrt.NN(jrt.Long_Cast(na_394)).LongValue__J(); var n1_397 int64 = na_395; or__1927000174__auto____17 = n0_396 >= n1_397 } else { or__1927000174__auto____17 = lang.Numbers_Gte_O_J__Z_NoInit(na_394, na_395) }; if or__1927000174__auto____17 { tmp5 = or__1927000174__auto____17 } else { var or__1927000174__auto____18 bool = lang.Numbers_Lte_J_J__Z_NoInit(shstrndx__10, 0); if or__1927000174__auto____18 { tmp5 = or__1927000174__auto____18 } else { tmp5 = lang.Numbers_Gte_J_J__Z_NoInit(shstrndx__10, shnum__9) } } } }; if tmp5 {
		var root_399 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, A_arbace_box_elf_fail_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = Lit_4; if linked_400 == nil { ifn_401.Invoke_O__O(arg_402) } else { linked_400.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_399, arg_402) } }; var tail__15 any; var root_97 any = /*line :38:1*/A_arbace_box_elf_A_const_23.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_99 lang.IFn; if


















	linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any; var fnbody__103 any = A_arbace_box_elf_cut_symbols_fn__581000022_A_New_O(secs__12); var tmp6 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class; if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__103); A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class = fncls__102d; tmp6 = fncls__102d } else { tmp6 = fncls__102 }; arg_100 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__103, tmp6, nil); var arg_101 any = lang.Tuple_Create_O_O_O__IPersistentVector(symtab__13, strtab__14, jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref()); if linked_98 == nil { tail__15 = ifn_99.Invoke_O_O__O(arg_100, arg_101) } else { tail__15 = linked_98.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_97, arg_100, arg_101) }; var start__16 any; var tmp7 /*line :38:1*/*lang.Keyword = A_arbace_box_elf_A_const_13; var tmp8 lang.IFn = lang.IFn_Cast(secs__12); var tmp9 any; var root_403 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_405 lang.IFn; if



















	linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = tail__15; if linked_404 == nil { tmp9 = ifn_405.Invoke_O__O(arg_406) } else { tmp9 = linked_404.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_403, arg_406) }; start__16 = tmp7.Invoke_O__O(tmp8.Invoke_O__O(tmp9)); var tmp10 bool; var na_407 int64 =
	lang.Numbers_Add_J_J__J_NoInit(shoff__5, lang.Numbers_Multiply_J_J__J_NoInit(shnum__9, shentsize__8)); var na_408 any = start__16; if jrt.Long_InstanceOf(na_408) { var n0_409 int64 = na_407; var n1_410 int64 = jrt.NN(jrt.Long_Cast(na_408)).LongValue__J(); tmp10 = n0_409 > n1_410 } else { tmp10 = lang.Numbers_Gt_J_O__Z_NoInit(na_407, na_408) }; if tmp10 {
		var root_412 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, A_arbace_box_elf_fail_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = Lit_6; if linked_413 == nil { ifn_414.Invoke_O__O(arg_415) } else { linked_413.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_412, arg_415) } }; var seq_581000024__17 any; var root_416 any = /*line :38:1*/A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_418 lang.IFn; if






















	linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any; var root_420 any = A_arbace_box_elf_A_const_53.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = A_arbace_box_elf_A_const_54.GetRawRoot__O(); var arg_424 any = secs__12; if linked_421 == nil { arg_419 = ifn_422.Invoke_O_O__O(arg_423, arg_424) } else { arg_419 = linked_421.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_420, arg_423, arg_424) }; if linked_417 == nil { seq_581000024__17 = ifn_418.Invoke_O__O(arg_419) } else { seq_581000024__17 = linked_417.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_416, arg_419) }; var chunk_581000025__18 any; var count_581000026__19 int64 = 0; var i_581000027__20 int64 = 0; L1:
//line :38:1
	for {






















		if lang.Numbers_Lt_J_J__Z_NoInit(i_581000027__20, count_581000026__19) { var vec__581000028__21 any = lang.Indexed_Cast(chunk_581000025__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_581000027__20)); var i__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000028__21, lang.RT_IntCast_J__I_NoInit(0), nil); var s__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000028__21, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp11 any; var root_425 any = A_arbace_box_elf_A_const_9.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_427 lang.IFn
			if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any; var or__1927000174__auto____24 any = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, strtab__14, symtab__13, jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref()))).Invoke_O__O(i__22); if jrt.J2g_Truth(or__1927000174__auto____24) { arg_428 = or__1927000174__auto____24 } else { arg_428 = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_55.GetRawRoot__O(), A_arbace_box_elf_A_const_56.GetRawRoot__O()))).Invoke_O__O(A_arbace_box_elf_A_const_12.Invoke_O__O(s__23)) }; if linked_426 == nil { tmp11 = ifn_427.Invoke_O__O(arg_428) } else { tmp11 = linked_426.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_425, arg_428) }
//line :61:1
			if jrt.J2g_Truth(tmp11) {

				var tmp12 bool; var na_482 any; var na_484 any = A_arbace_box_elf_A_const_13.Invoke_O__O(s__23); var na_485 any = A_arbace_box_elf_A_const_14.Invoke_O__O(s__23); var tmp13 bool; var tmp14 bool; tmp14 = jrt.Long_InstanceOf(na_484); if tmp14 { tmp14 = jrt.Long_InstanceOf(na_485) }; tmp13 = tmp14; if tmp13 { var n0_486 int64 = jrt.NN(jrt.Long_Cast(na_484)).LongValue__J(); var n1_487 int64 = jrt.NN(jrt.Long_Cast(na_485)).LongValue__J(); var nr_488 int64 = n0_486 + n1_487; if (n0_486^nr_488)&(n1_487^nr_488) >= 0 { na_482 = jrt.Long_ValueOf_J__Long_NoInit(nr_488).Ref() } else { na_482 = lang.Numbers_Add_O_O__Number_NoInit(na_484, na_485) } } else { var tmp15 bool; var tmp16 bool; tmp16 = jrt.Double_InstanceOf(na_484); if tmp16 { tmp16 = jrt.Double_InstanceOf(na_485) }; tmp15 = tmp16; if tmp15 { var n0_486_2 float64 = jrt.NN(jrt.Double_Cast(na_484)).DoubleValue__D(); var n1_487_2 float64 = jrt.NN(jrt.Double_Cast(na_485)).DoubleValue__D(); na_482 = jrt.Double_ValueOf_D__Double_NoInit(n0_486_2 + n1_487_2).Ref() } else { na_482 = lang.Numbers_Add_O_O__Number_NoInit(na_484, na_485) } }; var na_483 any = start__16; var tmp17 bool; var tmp18 bool; tmp18 = jrt.Long_InstanceOf(na_482); if tmp18 { tmp18 = jrt.Long_InstanceOf(na_483) }; tmp17 = tmp18; if tmp17 { var n0_489 int64 = jrt.NN(jrt.Long_Cast(na_482)).LongValue__J(); var n1_490 int64 = jrt.NN(jrt.Long_Cast(na_483)).LongValue__J(); tmp12 = n0_489 > n1_490 } else { var tmp19 bool; var tmp20 bool; tmp20 = jrt.Double_InstanceOf(na_482); if tmp20 { tmp20 = jrt.Double_InstanceOf(na_483) }; tmp19 = tmp20; if tmp19 { var n0_489_2 float64 = jrt.NN(jrt.Double_Cast(na_482)).DoubleValue__D(); var n1_490_2 float64 = jrt.NN(jrt.Double_Cast(na_483)).DoubleValue__D(); tmp12 = n1_490_2 < n0_489_2 } else { tmp12 = lang.Numbers_Gt_O_O__Z_NoInit(na_482, na_483) } }; if tmp12 {
					var root_492 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, A_arbace_box_elf_fail_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = Lit_7; if linked_493 == nil { ifn_494.Invoke_O__O(arg_495) } else { linked_493.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_492, arg_495) } }
//line :61:1
				seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = seq_581000024__17, chunk_581000025__18, count_581000026__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000027__20); continue L1 } else { seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = seq_581000024__17, chunk_581000025__18, count_581000026__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000027__20); continue L1 } } else { var temp__1927000414__auto____21 any; var root_429 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = seq_581000024__17; if linked_430 == nil { temp__1927000414__auto____21 = ifn_431.Invoke_O__O(arg_432) } else { temp__1927000414__auto____21 = linked_430.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_429, arg_432) }; if jrt.J2g_Truth(temp__1927000414__auto____21) { var seq_581000024__22 any = temp__1927000414__auto____21; var tmp21 any; var root_433 any = A_arbace_box_elf_A_const_27.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = seq_581000024__22; if linked_434 == nil { tmp21 = ifn_435.Invoke_O__O(arg_436) } else { tmp21 = linked_434.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_433, arg_436) }; if jrt.J2g_Truth(tmp21) { var c__1927000678__auto____23 any; var root_437 any = A_arbace_box_elf_A_const_28.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = seq_581000024__22; if linked_438 == nil { c__1927000678__auto____23 = ifn_439.Invoke_O__O(arg_440) } else { c__1927000678__auto____23 = linked_438.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_437, arg_440) }; var tmp22 any; var root_496 any = A_arbace_box_elf_A_const_36.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = seq_581000024__22; if linked_497 == nil { tmp22 = ifn_498.Invoke_O__O(arg_499) } else { tmp22 = linked_497.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_496, arg_499) }; seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = tmp22, c__1927000678__auto____23, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__581000031__23 any; var root_441 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = seq_581000024__22; if linked_442 == nil { vec__581000031__23 = ifn_443.Invoke_O__O(arg_444) } else { vec__581000031__23 = linked_442.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_441, arg_444) }; var i__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000031__23, lang.RT_IntCast_J__I_NoInit(0), nil); var s__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000031__23, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp23 any; var root_445 any = A_arbace_box_elf_A_const_9.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_447 lang.IFn
					if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any; var or__1927000174__auto____26 any = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, strtab__14, symtab__13, jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref()))).Invoke_O__O(i__24); if jrt.J2g_Truth(or__1927000174__auto____26) { arg_448 = or__1927000174__auto____26 } else { arg_448 = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_55.GetRawRoot__O(), A_arbace_box_elf_A_const_56.GetRawRoot__O()))).Invoke_O__O(A_arbace_box_elf_A_const_12.Invoke_O__O(s__25)) }; if linked_446 == nil { tmp23 = ifn_447.Invoke_O__O(arg_448) } else { tmp23 = linked_446.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_445, arg_448) }
//line :61:1
					if jrt.J2g_Truth(tmp23) {

						var tmp24 bool; var na_500 any; var na_502 any = A_arbace_box_elf_A_const_13.Invoke_O__O(s__25); var na_503 any = A_arbace_box_elf_A_const_14.Invoke_O__O(s__25); var tmp25 bool; var tmp26 bool; tmp26 = jrt.Long_InstanceOf(na_502); if tmp26 { tmp26 = jrt.Long_InstanceOf(na_503) }; tmp25 = tmp26; if tmp25 { var n0_504 int64 = jrt.NN(jrt.Long_Cast(na_502)).LongValue__J(); var n1_505 int64 = jrt.NN(jrt.Long_Cast(na_503)).LongValue__J(); var nr_506 int64 = n0_504 + n1_505; if (n0_504^nr_506)&(n1_505^nr_506) >= 0 { na_500 = jrt.Long_ValueOf_J__Long_NoInit(nr_506).Ref() } else { na_500 = lang.Numbers_Add_O_O__Number_NoInit(na_502, na_503) } } else { var tmp27 bool; var tmp28 bool; tmp28 = jrt.Double_InstanceOf(na_502); if tmp28 { tmp28 = jrt.Double_InstanceOf(na_503) }; tmp27 = tmp28; if tmp27 { var n0_504_2 float64 = jrt.NN(jrt.Double_Cast(na_502)).DoubleValue__D(); var n1_505_2 float64 = jrt.NN(jrt.Double_Cast(na_503)).DoubleValue__D(); na_500 = jrt.Double_ValueOf_D__Double_NoInit(n0_504_2 + n1_505_2).Ref() } else { na_500 = lang.Numbers_Add_O_O__Number_NoInit(na_502, na_503) } }; var na_501 any = start__16; var tmp29 bool; var tmp30 bool; tmp30 = jrt.Long_InstanceOf(na_500); if tmp30 { tmp30 = jrt.Long_InstanceOf(na_501) }; tmp29 = tmp30; if tmp29 { var n0_507 int64 = jrt.NN(jrt.Long_Cast(na_500)).LongValue__J(); var n1_508 int64 = jrt.NN(jrt.Long_Cast(na_501)).LongValue__J(); tmp24 = n0_507 > n1_508 } else { var tmp31 bool; var tmp32 bool; tmp32 = jrt.Double_InstanceOf(na_500); if tmp32 { tmp32 = jrt.Double_InstanceOf(na_501) }; tmp31 = tmp32; if tmp31 { var n0_507_2 float64 = jrt.NN(jrt.Double_Cast(na_500)).DoubleValue__D(); var n1_508_2 float64 = jrt.NN(jrt.Double_Cast(na_501)).DoubleValue__D(); tmp24 = n1_508_2 < n0_507_2 } else { tmp24 = lang.Numbers_Gt_O_O__Z_NoInit(na_500, na_501) } }; if tmp24 {
							var root_510 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, A_arbace_box_elf_fail_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = Lit_7; if linked_511 == nil { ifn_512.Invoke_O__O(arg_513) } else { linked_511.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_510, arg_513) } }
//line :61:1
						var tmp33 any; var root_514 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = seq_581000024__22; if linked_515 == nil { tmp33 = ifn_516.Invoke_O__O(arg_517) } else { tmp33 = linked_515.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_514, arg_517) }; seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = tmp33, nil, 0, 0; continue L1 } else { var tmp34 any; var root_518 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = seq_581000024__22; if linked_519 == nil { tmp34 = ifn_520.Invoke_O__O(arg_521) } else { tmp34 = linked_519.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_518, arg_521) }; seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = tmp34, nil, 0, 0; continue L1 } } } }
//line :38:1
		break L1 }; var seq_581000034__17 any; var root_449 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_451 lang.IFn; if


























	linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any; var root_453 any = A_arbace_box_elf_A_const_19.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = jrt.Long_ValueOf_J__Long_NoInit(phnum__7).Ref(); if linked_454 == nil { arg_452 = ifn_455.Invoke_O__O(arg_456) } else { arg_452 = linked_454.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_453, arg_456) }; if linked_450 == nil { seq_581000034__17 = ifn_451.Invoke_O__O(arg_452) } else { seq_581000034__17 = linked_450.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_449, arg_452) }; var chunk_581000035__18 any; var count_581000036__19 int64 = 0; var i_581000037__20 int64 = 0; L2:
//line :38:1
	for {


























		if lang.Numbers_Lt_J_J__Z_NoInit(i_581000037__20, count_581000036__19) { var i__21 any = lang.Indexed_Cast(chunk_581000035__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_581000037__20)); var h__22 any; var na_522 int64 = phoff__4; var na_523 any; var na_524 any = i__21; var na_525 int64 = phentsize__6
			if jrt.Long_InstanceOf(na_524) { var n0_526 int64 = jrt.NN(jrt.Long_Cast(na_524)).LongValue__J(); var n1_527 int64 = na_525; var nr_528 int64 = n0_526 * n1_527; var tmp35 bool; var tmp36 bool; var tmp37 bool; var tmp38 bool; tmp38 = n0_526 == -9223372036854775808; if tmp38 { tmp38 = n1_527 < 0 }; tmp37 = tmp38; tmp36 = !tmp37; if tmp36 { var tmp39 bool; tmp39 = n1_527 == 0; if !tmp39 { tmp39 = nr_528/n1_527 == n0_526 }; tmp36 = tmp39 }; tmp35 = tmp36; if tmp35 { na_523 = jrt.Long_ValueOf_J__Long_NoInit(nr_528).Ref() } else { na_523 = lang.Numbers_Multiply_O_J__Number_NoInit(na_524, na_525) } } else { na_523 = lang.Numbers_Multiply_O_J__Number_NoInit(na_524, na_525) }; if jrt.Long_InstanceOf(na_523) { var n0_529 int64 = na_522; var n1_530 int64 = jrt.NN(jrt.Long_Cast(na_523)).LongValue__J(); var nr_531 int64 = n0_529 + n1_530; if (n0_529^nr_531)&(n1_530^nr_531) >= 0 { h__22 = jrt.Long_ValueOf_J__Long_NoInit(nr_531).Ref() } else { h__22 = lang.Numbers_Add_J_O__Number_NoInit(na_522, na_523) } } else { h__22 = lang.Numbers_Add_J_O__Number_NoInit(na_522, na_523) }
			var tmp40 bool; var na_532 int64; var tmp41 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(b__3); var tmp42 jrt.Number_I; var na_534 any = h__22; var na_535 int64 = 8; if jrt.Long_InstanceOf(na_534) { var n0_536 int64 = jrt.NN(jrt.Long_Cast(na_534)).LongValue__J(); var n1_537 int64 = na_535; var nr_538 int64 = n0_536 + n1_537; if (n0_536^nr_538)&(n1_537^nr_538) >= 0 { tmp42 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_538)) } else { tmp42 = lang.Numbers_Add_O_J__Number_NoInit(na_534, na_535) } } else { tmp42 = lang.Numbers_Add_O_J__Number_NoInit(na_534, na_535) }; var tmp43 int64 = tmp41.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp42)); var tmp44 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(b__3); var tmp45 jrt.Number_I; var na_539 any = h__22; var na_540 int64 = 32; if jrt.Long_InstanceOf(na_539) { var n0_541 int64 = jrt.NN(jrt.Long_Cast(na_539)).LongValue__J(); var n1_542 int64 = na_540; var nr_543 int64 = n0_541 + n1_542; if (n0_541^nr_543)&(n1_542^nr_543) >= 0 { tmp45 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_543)) } else { tmp45 = lang.Numbers_Add_O_J__Number_NoInit(na_539, na_540) } } else { tmp45 = lang.Numbers_Add_O_J__Number_NoInit(na_539, na_540) }; na_532 = lang.Numbers_Add_J_J__J_NoInit(tmp43, tmp44.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp45))); var na_533 any = start__16; if jrt.Long_InstanceOf(na_533) { var n0_544 int64 = na_532; var n1_545 int64 = jrt.NN(jrt.Long_Cast(na_533)).LongValue__J(); tmp40 = n0_544 > n1_545 } else { tmp40 = lang.Numbers_Gt_J_O__Z_NoInit(na_532, na_533) }; if tmp40 {
				var root_547 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, A_arbace_box_elf_fail_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = Lit_8; if linked_548 == nil { ifn_549.Invoke_O__O(arg_550) } else { linked_548.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_547, arg_550) } }
//line :65:1
			seq_581000034__17, chunk_581000035__18, count_581000036__19, i_581000037__20 = seq_581000034__17, chunk_581000035__18, count_581000036__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000037__20); continue L2 } else { var temp__1927000414__auto____21_2 any; var root_457 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = seq_581000034__17; if linked_458 == nil { temp__1927000414__auto____21_2 = ifn_459.Invoke_O__O(arg_460) } else { temp__1927000414__auto____21_2 = linked_458.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_457, arg_460) }; if jrt.J2g_Truth(temp__1927000414__auto____21_2) { var seq_581000034__22 any = temp__1927000414__auto____21_2; var tmp46 any; var root_461 any = A_arbace_box_elf_A_const_27.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_463 lang.IFn; if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any = seq_581000034__22; if linked_462 == nil { tmp46 = ifn_463.Invoke_O__O(arg_464) } else { tmp46 = linked_462.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_461, arg_464) }; if jrt.J2g_Truth(tmp46) { var c__1927000678__auto____23_2 any; var root_465 any = A_arbace_box_elf_A_const_28.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = seq_581000034__22; if linked_466 == nil { c__1927000678__auto____23_2 = ifn_467.Invoke_O__O(arg_468) } else { c__1927000678__auto____23_2 = linked_466.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_465, arg_468) }; var tmp47 any; var root_551 any = A_arbace_box_elf_A_const_36.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = seq_581000034__22; if linked_552 == nil { tmp47 = ifn_553.Invoke_O__O(arg_554) } else { tmp47 = linked_552.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_551, arg_554) }; seq_581000034__17, chunk_581000035__18, count_581000036__19, i_581000037__20 = tmp47, c__1927000678__auto____23_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var i__23 any; var root_469 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = seq_581000034__22; if linked_470 == nil { i__23 = ifn_471.Invoke_O__O(arg_472) } else { i__23 = linked_470.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_469, arg_472) }; var h__24 any; var na_555 int64 = phoff__4; var na_556 any; var na_557 any = i__23; var na_558 int64 = phentsize__6
				if jrt.Long_InstanceOf(na_557) { var n0_559 int64 = jrt.NN(jrt.Long_Cast(na_557)).LongValue__J(); var n1_560 int64 = na_558; var nr_561 int64 = n0_559 * n1_560; var tmp48 bool; var tmp49 bool; var tmp50 bool; var tmp51 bool; tmp51 = n0_559 == -9223372036854775808; if tmp51 { tmp51 = n1_560 < 0 }; tmp50 = tmp51; tmp49 = !tmp50; if tmp49 { var tmp52 bool; tmp52 = n1_560 == 0; if !tmp52 { tmp52 = nr_561/n1_560 == n0_559 }; tmp49 = tmp52 }; tmp48 = tmp49; if tmp48 { na_556 = jrt.Long_ValueOf_J__Long_NoInit(nr_561).Ref() } else { na_556 = lang.Numbers_Multiply_O_J__Number_NoInit(na_557, na_558) } } else { na_556 = lang.Numbers_Multiply_O_J__Number_NoInit(na_557, na_558) }; if jrt.Long_InstanceOf(na_556) { var n0_562 int64 = na_555; var n1_563 int64 = jrt.NN(jrt.Long_Cast(na_556)).LongValue__J(); var nr_564 int64 = n0_562 + n1_563; if (n0_562^nr_564)&(n1_563^nr_564) >= 0 { h__24 = jrt.Long_ValueOf_J__Long_NoInit(nr_564).Ref() } else { h__24 = lang.Numbers_Add_J_O__Number_NoInit(na_555, na_556) } } else { h__24 = lang.Numbers_Add_J_O__Number_NoInit(na_555, na_556) }
				var tmp53 bool; var na_565 int64; var tmp54 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(b__3); var tmp55 jrt.Number_I; var na_567 any = h__24; var na_568 int64 = 8; if jrt.Long_InstanceOf(na_567) { var n0_569 int64 = jrt.NN(jrt.Long_Cast(na_567)).LongValue__J(); var n1_570 int64 = na_568; var nr_571 int64 = n0_569 + n1_570; if (n0_569^nr_571)&(n1_570^nr_571) >= 0 { tmp55 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_571)) } else { tmp55 = lang.Numbers_Add_O_J__Number_NoInit(na_567, na_568) } } else { tmp55 = lang.Numbers_Add_O_J__Number_NoInit(na_567, na_568) }; var tmp56 int64 = tmp54.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp55)); var tmp57 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(b__3); var tmp58 jrt.Number_I; var na_572 any = h__24; var na_573 int64 = 32; if jrt.Long_InstanceOf(na_572) { var n0_574 int64 = jrt.NN(jrt.Long_Cast(na_572)).LongValue__J(); var n1_575 int64 = na_573; var nr_576 int64 = n0_574 + n1_575; if (n0_574^nr_576)&(n1_575^nr_576) >= 0 { tmp58 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_576)) } else { tmp58 = lang.Numbers_Add_O_J__Number_NoInit(na_572, na_573) } } else { tmp58 = lang.Numbers_Add_O_J__Number_NoInit(na_572, na_573) }; na_565 = lang.Numbers_Add_J_J__J_NoInit(tmp56, tmp57.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp58))); var na_566 any = start__16; if jrt.Long_InstanceOf(na_566) { var n0_577 int64 = na_565; var n1_578 int64 = jrt.NN(jrt.Long_Cast(na_566)).LongValue__J(); tmp53 = n0_577 > n1_578 } else { tmp53 = lang.Numbers_Gt_J_O__Z_NoInit(na_565, na_566) }; if tmp53 {
					var root_580 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, A_arbace_box_elf_fail_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = Lit_8; if linked_581 == nil { ifn_582.Invoke_O__O(arg_583) } else { linked_581.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_580, arg_583) } }
//line :65:1
				var tmp59 any; var root_584 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = seq_581000034__22; if linked_585 == nil { tmp59 = ifn_586.Invoke_O__O(arg_587) } else { tmp59 = linked_585.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_584, arg_587) }; seq_581000034__17, chunk_581000035__18, count_581000036__19, i_581000037__20 = tmp59, nil, 0, 0; continue L2 } } }
//line :38:1
		break L2 }; var l__17 any; var tmp60 lang.IFn = lang.IFn_Cast(secs__12); var tmp61 any; var root_588 any = A_arbace_box_elf_A_const_57.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_590 lang.IFn; if






























	linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = tail__15; if linked_589 == nil { tmp61 = ifn_590.Invoke_O__O(arg_591) } else { tmp61 = linked_589.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_588, arg_591) }; l__17 = tmp60.Invoke_O__O(tmp61); var tmp62 jrt.Number_I; var na_473 any =
	A_arbace_box_elf_A_const_13.Invoke_O__O(l__17); var na_474 any = A_arbace_box_elf_A_const_14.Invoke_O__O(l__17); var tmp63 bool; var tmp64 bool; tmp64 = jrt.Long_InstanceOf(na_473); if tmp64 { tmp64 = jrt.Long_InstanceOf(na_474) }; tmp63 = tmp64; if tmp63 { var n0_475 int64 = jrt.NN(jrt.Long_Cast(na_473)).LongValue__J(); var n1_476 int64 = jrt.NN(jrt.Long_Cast(na_474)).LongValue__J(); var nr_477 int64 = n0_475 + n1_476; if (n0_475^nr_477)&(n1_476^nr_477) >= 0 { tmp62 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_477)) } else { tmp62 = lang.Numbers_Add_O_O__Number_NoInit(na_473, na_474) } } else { var tmp65 bool; var tmp66 bool; tmp66 = jrt.Double_InstanceOf(na_473); if tmp66 { tmp66 = jrt.Double_InstanceOf(na_474) }; tmp65 = tmp66; if tmp65 { var n0_475_2 float64 = jrt.NN(jrt.Double_Cast(na_473)).DoubleValue__D(); var n1_476_2 float64 = jrt.NN(jrt.Double_Cast(na_474)).DoubleValue__D(); tmp62 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_475_2 + n1_476_2)) } else { tmp62 = lang.Numbers_Add_O_O__Number_NoInit(na_473, na_474) } }; if lang.Util_Equiv_O_J__Z_NoInit(tmp62, int64(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(data__0)))) { } else {
		var root_478 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, A_arbace_box_elf_fail_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = Lit_9; if linked_479 == nil { ifn_480.Invoke_O__O(arg_481) } else { linked_479.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_478, arg_481) } }; var st__17 any = /*line :38:1*/lang.IFn_Cast(secs__12).Invoke_O__O(symtab__13); var tmp67 *lang.Keyword = A_arbace_box_elf_A_const_13; var strs__18 any = tmp67.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(strtab__14)); var n__19 any; var na_104 any = A_arbace_box_elf_A_const_14.Invoke_O__O(st__17); var na_105 int64 = 24; if



































	jrt.Long_InstanceOf(na_104) { var n0_106 int64 = jrt.NN(jrt.Long_Cast(na_104)).LongValue__J(); var n1_107 int64 = na_105; if n1_107 == 0 { n__19 = lang.Numbers_Quotient_O_J__Number_NoInit(na_104, na_105) } else { n__19 = jrt.Long_ValueOf_J__Long_NoInit(n0_106 / n1_107).Ref() } } else { n__19 = lang.Numbers_Quotient_O_J__Number_NoInit(na_104, na_105) }; var want__20 any; var root_109 any = /*line :38:1*/A_arbace_box_elf_A_const_24.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_111 lang.IFn; if




































	linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = names__1; if linked_110 == nil { want__20 = ifn_111.Invoke_O__O(arg_112) } else { want__20 = linked_110.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_109, arg_112) }; var kept__21 any; var root_113 any = /*line :38:1*/A_arbace_box_elf_A_const_25.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_115 lang.IFn; if





































	linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any; var iter__1927001039__auto____21 any; var fnbody__222 any = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_New_O_O_O_O_O(data__0, st__17, strs__18, want__20, b__3); var tmp68 *jrt.Class; var fncls__221 *jrt.Class = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class; if fncls__221 == nil { var fncls__221d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__222); A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class = fncls__221d; tmp68 = fncls__221d } else { tmp68 = fncls__221 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__222, tmp68, nil); var tmp69 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____21); var tmp70 any; var root_223 any = A_arbace_box_elf_A_const_19.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = A_arbace_box_elf_A_const_39; var arg_227 any = n__19; if linked_224 == nil { tmp70 = ifn_225.Invoke_O_O__O(arg_226, arg_227) } else { tmp70 = linked_224.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_223, arg_226, arg_227) }; arg_116 = tmp69.Invoke_O__O(tmp70); if linked_114 == nil { kept__21 = ifn_115.Invoke_O__O(arg_116) } else { kept__21 = linked_114.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_113, arg_116) }; var ___22 any; var tmp71 /*line :38:1*/*lang.Compiler_AOTFn; var fnbody__307 any = A_arbace_box_elf_cut_symbols_fn__581000052_A_New_O_O(kept__21, data__0); var tmp72 *jrt.Class; var fncls__306 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class; _ = ___22; if










































	fncls__306 == nil { var fncls__306d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__307); A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class = fncls__306d; tmp72 = fncls__306d } else { tmp72 = fncls__306 }; tmp71 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__307, tmp72, nil); ___22 = Up_Compiler_AOTFn_IFn(tmp71).Invoke__O(); var missing__23 any; var root_308 any = /*line :38:1*/A_arbace_box_elf_A_const_44.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_310 lang.IFn; if













































	linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any; var root_312 any = A_arbace_box_elf_A_const_45.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any; var root_317 any = A_arbace_box_elf_A_const_24.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any; var root_321 any = A_arbace_box_elf_A_const_46.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = A_arbace_box_elf_A_const_32; var arg_325 any = kept__21; if linked_322 == nil { arg_320 = ifn_323.Invoke_O_O__O(arg_324, arg_325) } else { arg_320 = linked_322.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_321, arg_324, arg_325) }; if linked_318 == nil { arg_315 = ifn_319.Invoke_O__O(arg_320) } else { arg_315 = linked_318.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_317, arg_320) }; var arg_316 any = want__20; if linked_313 == nil { arg_311 = ifn_314.Invoke_O_O__O(arg_315, arg_316) } else { arg_311 = linked_313.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_312, arg_315, arg_316) }; if linked_309 == nil { missing__23 = ifn_310.Invoke_O__O(arg_311) } else { missing__23 = linked_309.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_308, arg_311) }; var ___24 any; var tmp73 any; var root_326 any = /*line :38:1*/A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_328 lang.IFn; _ = ___24; if














































	linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = missing__23; if linked_327 == nil { tmp73 = ifn_328.Invoke_O__O(arg_329) } else { tmp73 = linked_327.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_326, arg_329) }; if jrt.J2g_Truth(tmp73) { var root_330 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, A_arbace_box_elf_fail_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any; var tmp74 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp75 any; var root_334 any = A_arbace_box_elf_A_const_25.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = missing__23; if linked_335 == nil { tmp75 = ifn_336.Invoke_O__O(arg_337) } else { tmp75 = linked_335.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_334, arg_337) }; arg_333 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp74, jrt.RefArrayOf(jrt.Object_class, nil, tmp75)).Ref(); if linked_331 == nil { ___24 = ifn_332.Invoke_O__O(arg_333) } else { ___24 = linked_331.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_330, arg_333) } } else { ___24 = nil }; var kept__25 any; var root_338 any = /*line :38:1*/A_arbace_box_elf_A_const_47.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_340 lang.IFn; if
















































	linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any; var fnbody__357 any = A_arbace_box_elf_cut_symbols_fn__581000058_A_New(); var tmp76 *jrt.Class; var fncls__356 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class; if fncls__356 == nil { var fncls__356d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class = fncls__356d; tmp76 = fncls__356d } else { tmp76 = fncls__356 }; arg_341 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__357, tmp76, nil); var arg_342 any = lang.PersistentVector_EMPTY.Ref(); var arg_343 any = kept__21; if linked_339 == nil { kept__25 = ifn_340.Invoke_O_O_O__O(arg_341, arg_342, arg_343) } else { kept__25 = linked_339.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_338, arg_341, arg_342, arg_343) }; var strb__26 any = /*line :38:1*/jrt.ByteArrayOutputStream_New(); var symb__27 any = jrt.ByteArrayOutputStream_New();



















































	jrt.ByteArrayOutputStream_Cast(strb__26).Write_I__V(lang.RT_IntCast_J__I_NoInit(0));
	jrt.OutputStream_Cast(symb__27).Write_B1__V(lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_elf_A_const_58)); var seq_581000062__28 any; var root_592 any = /*line :38:1*/A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_594 lang.IFn; if





















































	linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = kept__25; if linked_593 == nil { seq_581000062__28 = ifn_594.Invoke_O__O(arg_595) } else { seq_581000062__28 = linked_593.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_592, arg_595) }; var chunk_581000063__29 any; var count_581000064__30 int64 = 0; var i_581000065__31 int64 = 0; L3:
//line :38:1
	for {





















































		if lang.Numbers_Lt_J_J__Z_NoInit(i_581000065__31, count_581000064__30) { var map__581000066__32 any = lang.Indexed_Cast(chunk_581000063__29).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_581000065__31)); var map__581000066__33 any; if lang.ISeq_InstanceOf(map__581000066__32) { var tmp77 any; var root_596 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = map__581000066__32; if linked_597 == nil { tmp77 = ifn_598.Invoke_O__O(arg_599) } else { tmp77 = linked_597.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_596, arg_599) }; if jrt.J2g_Truth(tmp77) { var tmp78 any; var root_600 any = A_arbace_box_elf_A_const_41.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = map__581000066__32; if linked_601 == nil { tmp78 = ifn_602.Invoke_O__O(arg_603) } else { tmp78 = linked_601.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_600, arg_603) }; map__581000066__33 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp78)).Ref() } else { var tmp79 any; var root_604 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = map__581000066__32; if linked_605 == nil { tmp79 = ifn_606.Invoke_O__O(arg_607) } else { tmp79 = linked_605.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_604, arg_607) }; if jrt.J2g_Truth(tmp79) { var root_608 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_610 lang.IFn; if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = map__581000066__32; if linked_609 == nil { map__581000066__33 = ifn_610.Invoke_O__O(arg_611) } else { map__581000066__33 = linked_609.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_608, arg_611) } } else { map__581000066__33 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000066__33 = map__581000066__32 }; var name__34 any = lang.RT_Get_O_O__O_NoInit(map__581000066__33, A_arbace_box_elf_A_const_32); var entry__35 any = lang.RT_Get_O_O__O_NoInit(map__581000066__33, A_arbace_box_elf_A_const_33); var e__36 any = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_elf_A_const_58).Ref(); var eb__37 any; var root_644 any = A_arbace_box_elf_A_const_11.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, A_arbace_box_elf_le_A_fn_class); var ifn_646 lang.IFn

			if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = e__36; if linked_645 == nil { eb__37 = ifn_646.Invoke_O__O(arg_647) } else { eb__37 = linked_645.(*A_arbace_box_elf_le_A).Invoke_O_O__O(root_644, arg_647) }
			jrt.System_Arraycopy_O_I_O_I_I__V(data__0, lang.RT_IntCast_O__I_NoInit(entry__35), e__36, lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_J__I_NoInit(24))
			jrt.ByteBuffer_Cast(eb__37).PutInt_I_I__ByteBuffer(lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_I__I_NoInit(jrt.ByteArrayOutputStream_Cast(strb__26).Size__I()))
			jrt.OutputStream_Cast(symb__27).Write_B1__V(jrt.ByteArray_Cast(e__36))
			jrt.OutputStream_Cast(strb__26).Write_B1__V(jrt.NN(jrt.String_Cast(name__34)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8))
			jrt.ByteArrayOutputStream_Cast(strb__26).Write_I__V(lang.RT_IntCast_J__I_NoInit(0))
//line :92:1
			seq_581000062__28, chunk_581000063__29, count_581000064__30, i_581000065__31 = seq_581000062__28, chunk_581000063__29, count_581000064__30, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000065__31); continue L3 } else { var temp__1927000414__auto____32 any; var root_612 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = seq_581000062__28; if linked_613 == nil { temp__1927000414__auto____32 = ifn_614.Invoke_O__O(arg_615) } else { temp__1927000414__auto____32 = linked_613.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_612, arg_615) }; if jrt.J2g_Truth(temp__1927000414__auto____32) { var seq_581000062__33 any = temp__1927000414__auto____32; var tmp80 any; var root_616 any = A_arbace_box_elf_A_const_27.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = seq_581000062__33; if linked_617 == nil { tmp80 = ifn_618.Invoke_O__O(arg_619) } else { tmp80 = linked_617.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_616, arg_619) }; if jrt.J2g_Truth(tmp80) { var c__1927000678__auto____34 any; var root_620 any = A_arbace_box_elf_A_const_28.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = seq_581000062__33; if linked_621 == nil { c__1927000678__auto____34 = ifn_622.Invoke_O__O(arg_623) } else { c__1927000678__auto____34 = linked_621.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_620, arg_623) }; var tmp81 any; var root_648 any = A_arbace_box_elf_A_const_36.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = seq_581000062__33; if linked_649 == nil { tmp81 = ifn_650.Invoke_O__O(arg_651) } else { tmp81 = linked_649.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_648, arg_651) }; seq_581000062__28, chunk_581000063__29, count_581000064__30, i_581000065__31 = tmp81, c__1927000678__auto____34, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____34))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var map__581000068__34 any; var root_624 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = seq_581000062__33; if linked_625 == nil { map__581000068__34 = ifn_626.Invoke_O__O(arg_627) } else { map__581000068__34 = linked_625.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_624, arg_627) }; var map__581000068__35 any; if lang.ISeq_InstanceOf(map__581000068__34) { var tmp82 any; var root_628 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = map__581000068__34; if linked_629 == nil { tmp82 = ifn_630.Invoke_O__O(arg_631) } else { tmp82 = linked_629.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_628, arg_631) }; if jrt.J2g_Truth(tmp82) { var tmp83 any; var root_632 any = A_arbace_box_elf_A_const_41.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_634 lang.IFn; if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = map__581000068__34; if linked_633 == nil { tmp83 = ifn_634.Invoke_O__O(arg_635) } else { tmp83 = linked_633.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_632, arg_635) }; map__581000068__35 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp83)).Ref() } else { var tmp84 any; var root_636 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_638 lang.IFn; if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any = map__581000068__34; if linked_637 == nil { tmp84 = ifn_638.Invoke_O__O(arg_639) } else { tmp84 = linked_637.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_636, arg_639) }; if jrt.J2g_Truth(tmp84) { var root_640 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = map__581000068__34; if linked_641 == nil { map__581000068__35 = ifn_642.Invoke_O__O(arg_643) } else { map__581000068__35 = linked_641.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_640, arg_643) } } else { map__581000068__35 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000068__35 = map__581000068__34 }; var name__36 any = lang.RT_Get_O_O__O_NoInit(map__581000068__35, A_arbace_box_elf_A_const_32); var entry__37 any = lang.RT_Get_O_O__O_NoInit(map__581000068__35, A_arbace_box_elf_A_const_33); var e__38 any = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_elf_A_const_58).Ref(); var eb__39 any; var root_652 any = A_arbace_box_elf_A_const_11.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, A_arbace_box_elf_le_A_fn_class); var ifn_654 lang.IFn

				if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = e__38; if linked_653 == nil { eb__39 = ifn_654.Invoke_O__O(arg_655) } else { eb__39 = linked_653.(*A_arbace_box_elf_le_A).Invoke_O_O__O(root_652, arg_655) }
				jrt.System_Arraycopy_O_I_O_I_I__V(data__0, lang.RT_IntCast_O__I_NoInit(entry__37), e__38, lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_J__I_NoInit(24))
				jrt.ByteBuffer_Cast(eb__39).PutInt_I_I__ByteBuffer(lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_I__I_NoInit(jrt.ByteArrayOutputStream_Cast(strb__26).Size__I()))
				jrt.OutputStream_Cast(symb__27).Write_B1__V(jrt.ByteArray_Cast(e__38))
				jrt.OutputStream_Cast(strb__26).Write_B1__V(jrt.NN(jrt.String_Cast(name__36)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8))
				jrt.ByteArrayOutputStream_Cast(strb__26).Write_I__V(lang.RT_IntCast_J__I_NoInit(0))
//line :92:1
				var tmp85 any; var root_656 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = seq_581000062__33; if linked_657 == nil { tmp85 = ifn_658.Invoke_O__O(arg_659) } else { tmp85 = linked_657.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_656, arg_659) }; seq_581000062__28, chunk_581000063__29, count_581000064__30, i_581000065__31 = tmp85, nil, 0, 0; continue L3 } } }
//line :38:1
		break L3 }; var o__28 any = jrt.ByteArrayOutputStream_New(); var ___29 any; _ = ___29;






























































	jrt.ByteArrayOutputStream_Cast(o__28).Write_B1_I_I__V(jrt.ByteArray_Cast(data__0), lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_O__I_NoInit(start__16)); ___29 = nil; var shstr__30 any; var tmp86 /*line :38:1*/*jrt.ByteArray = jrt.ByteArray_Cast(data__0); var tmp87 *lang.Keyword = A_arbace_box_elf_A_const_13; var tmp88 int32 = lang.RT_IntCast_O__I_NoInit(tmp87.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref()))); var tmp89 jrt.Number_I; var tmp90 *lang.Keyword = A_arbace_box_elf_A_const_13; var na_358 any = tmp90.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref())); var tmp91 *lang.Keyword = A_arbace_box_elf_A_const_14; var na_359 any = tmp91.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref())); var tmp92 bool; var tmp93 bool; tmp93 =































































	jrt.Long_InstanceOf(na_358); if tmp93 { tmp93 = jrt.Long_InstanceOf(na_359) }; tmp92 = tmp93; if tmp92 { var n0_360 int64 = jrt.NN(jrt.Long_Cast(na_358)).LongValue__J(); var n1_361 int64 = jrt.NN(jrt.Long_Cast(na_359)).LongValue__J(); var nr_362 int64 = n0_360 + n1_361; if (n0_360^nr_362)&(n1_361^nr_362) >= 0 { tmp89 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_362)) } else { tmp89 = lang.Numbers_Add_O_O__Number_NoInit(na_358, na_359) } } else { var tmp94 bool; var tmp95 bool; tmp95 = jrt.Double_InstanceOf(na_358); if tmp95 { tmp95 = jrt.Double_InstanceOf(na_359) }; tmp94 = tmp95; if tmp94 { var n0_360_2 float64 = jrt.NN(jrt.Double_Cast(na_358)).DoubleValue__D(); var n1_361_2 float64 = jrt.NN(jrt.Double_Cast(na_359)).DoubleValue__D(); tmp89 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_360_2 + n1_361_2)) } else { tmp89 = lang.Numbers_Add_O_O__Number_NoInit(na_358, na_359) } }; shstr__30 = jrt.Arrays_CopyOfRange_B1_I_I__B1_NoInit(tmp86, tmp88, lang.RT_IntCast_O__I_NoInit(tmp89)).Ref(); var places__31 any; var root_363 any = /*line :38:1*/A_arbace_box_elf_A_const_49.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_365 lang.IFn; if
































































	linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_364 == nil { places__31 = ifn_365.Invoke_O__O(arg_366) } else { places__31 = linked_364.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_363, arg_366) }; var place__32 any; var fnbody__380 any = /*line :38:1*/A_arbace_box_elf_cut_symbols_place__581000070_A_New_O_O_O(places__31, o__28, secs__12); var tmp96 *jrt.Class; var fncls__379 *jrt.Class = A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class; if

































































	fncls__379 == nil { var fncls__379d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__380); A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class = fncls__379d; tmp96 = fncls__379d } else { tmp96 = fncls__379 }; place__32 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__380, tmp96, nil);



	lang.IFn_Cast(place__32).Invoke_O_O__O(symtab__13, jrt.ByteArrayOutputStream_Cast(symb__27).ToByteArray__B1().Ref());
	lang.IFn_Cast(place__32).Invoke_O_O__O(strtab__14, jrt.ByteArrayOutputStream_Cast(strb__26).ToByteArray__B1().Ref());
	lang.IFn_Cast(place__32).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref(), shstr__30); var out__33 any = /*line :38:1*/jrt.ByteArrayOutputStream_Cast(o__28).ToByteArray__B1().Ref(); var ob__34 any; var root_381 any = A_arbace_box_elf_A_const_11.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, A_arbace_box_elf_le_A_fn_class); var ifn_383 lang.IFn; if









































































	linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = out__33; if linked_382 == nil { ob__34 = ifn_383.Invoke_O__O(arg_384) } else { ob__34 = linked_382.(*A_arbace_box_elf_le_A).Invoke_O_O__O(root_381, arg_384) }; var seq_581000072__35 any; var root_660 any = /*line :38:1*/A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_662 lang.IFn; if










































































	linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any; var root_664 any = A_arbace_box_elf_A_const_3.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = places__31; if linked_665 == nil { arg_663 = ifn_666.Invoke_O__O(arg_667) } else { arg_663 = linked_665.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_664, arg_667) }; if linked_661 == nil { seq_581000072__35 = ifn_662.Invoke_O__O(arg_663) } else { seq_581000072__35 = linked_661.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_660, arg_663) }; var chunk_581000073__36 any; var count_581000074__37 int64 = 0; var i_581000075__38 int64 = 0; L4:
//line :38:1
	for {










































































		if lang.Numbers_Lt_J_J__Z_NoInit(i_581000075__38, count_581000074__37) { var vec__581000076__39 any = lang.Indexed_Cast(chunk_581000073__36).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_581000075__38)); var i__40 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000076__39, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__581000079__41 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000076__39, lang.RT_IntCast_J__I_NoInit(1), nil); var off__42 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000079__41, lang.RT_IntCast_J__I_NoInit(0), nil); var size__43 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000079__41, lang.RT_IntCast_J__I_NoInit(1), nil); var h__44 any; var na_699 int64 = shoff__5; var na_700 any; var na_701 any = i__40; var na_702 int64 = shentsize__8
			if jrt.Long_InstanceOf(na_701) { var n0_703 int64 = jrt.NN(jrt.Long_Cast(na_701)).LongValue__J(); var n1_704 int64 = na_702; var nr_705 int64 = n0_703 * n1_704; var tmp97 bool; var tmp98 bool; var tmp99 bool; var tmp100 bool; tmp100 = n0_703 == -9223372036854775808; if tmp100 { tmp100 = n1_704 < 0 }; tmp99 = tmp100; tmp98 = !tmp99; if tmp98 { var tmp101 bool; tmp101 = n1_704 == 0; if !tmp101 { tmp101 = nr_705/n1_704 == n0_703 }; tmp98 = tmp101 }; tmp97 = tmp98; if tmp97 { na_700 = jrt.Long_ValueOf_J__Long_NoInit(nr_705).Ref() } else { na_700 = lang.Numbers_Multiply_O_J__Number_NoInit(na_701, na_702) } } else { na_700 = lang.Numbers_Multiply_O_J__Number_NoInit(na_701, na_702) }; if jrt.Long_InstanceOf(na_700) { var n0_706 int64 = na_699; var n1_707 int64 = jrt.NN(jrt.Long_Cast(na_700)).LongValue__J(); var nr_708 int64 = n0_706 + n1_707; if (n0_706^nr_708)&(n1_707^nr_708) >= 0 { h__44 = jrt.Long_ValueOf_J__Long_NoInit(nr_708).Ref() } else { h__44 = lang.Numbers_Add_J_O__Number_NoInit(na_699, na_700) } } else { h__44 = lang.Numbers_Add_J_O__Number_NoInit(na_699, na_700) }
			var tmp102 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(ob__34); var tmp103 jrt.Number_I; var na_714 any = h__44; var na_715 int64 = 24; if jrt.Long_InstanceOf(na_714) { var n0_716 int64 = jrt.NN(jrt.Long_Cast(na_714)).LongValue__J(); var n1_717 int64 = na_715; var nr_718 int64 = n0_716 + n1_717; if (n0_716^nr_718)&(n1_717^nr_718) >= 0 { tmp103 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_718)) } else { tmp103 = lang.Numbers_Add_O_J__Number_NoInit(na_714, na_715) } } else { tmp103 = lang.Numbers_Add_O_J__Number_NoInit(na_714, na_715) }; tmp102.PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I_NoInit(tmp103), lang.RT_LongCast_O__J_NoInit(off__42))
			var tmp104 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(ob__34); var tmp105 jrt.Number_I; var na_709 any = h__44; var na_710 int64 = 32; if jrt.Long_InstanceOf(na_709) { var n0_711 int64 = jrt.NN(jrt.Long_Cast(na_709)).LongValue__J(); var n1_712 int64 = na_710; var nr_713 int64 = n0_711 + n1_712; if (n0_711^nr_713)&(n1_712^nr_713) >= 0 { tmp105 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_713)) } else { tmp105 = lang.Numbers_Add_O_J__Number_NoInit(na_709, na_710) } } else { tmp105 = lang.Numbers_Add_O_J__Number_NoInit(na_709, na_710) }; tmp104.PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I_NoInit(tmp105), lang.RT_LongCast_O__J_NoInit(size__43))
//line :113:1
			seq_581000072__35, chunk_581000073__36, count_581000074__37, i_581000075__38 = seq_581000072__35, chunk_581000073__36, count_581000074__37, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000075__38); continue L4 } else { var temp__1927000414__auto____39 any; var root_668 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = seq_581000072__35; if linked_669 == nil { temp__1927000414__auto____39 = ifn_670.Invoke_O__O(arg_671) } else { temp__1927000414__auto____39 = linked_669.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_668, arg_671) }; if jrt.J2g_Truth(temp__1927000414__auto____39) { var seq_581000072__40 any = temp__1927000414__auto____39; var tmp106 any; var root_672 any = A_arbace_box_elf_A_const_27.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = seq_581000072__40; if linked_673 == nil { tmp106 = ifn_674.Invoke_O__O(arg_675) } else { tmp106 = linked_673.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_672, arg_675) }; if jrt.J2g_Truth(tmp106) { var c__1927000678__auto____41 any; var root_676 any = A_arbace_box_elf_A_const_28.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = seq_581000072__40; if linked_677 == nil { c__1927000678__auto____41 = ifn_678.Invoke_O__O(arg_679) } else { c__1927000678__auto____41 = linked_677.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_676, arg_679) }; var tmp107 any; var root_719 any = A_arbace_box_elf_A_const_36.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = seq_581000072__40; if linked_720 == nil { tmp107 = ifn_721.Invoke_O__O(arg_722) } else { tmp107 = linked_720.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_719, arg_722) }; seq_581000072__35, chunk_581000073__36, count_581000074__37, i_581000075__38 = tmp107, c__1927000678__auto____41, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____41))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var vec__581000082__41 any; var root_680 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = seq_581000072__40; if linked_681 == nil { vec__581000082__41 = ifn_682.Invoke_O__O(arg_683) } else { vec__581000082__41 = linked_681.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_680, arg_683) }; var i__42 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000082__41, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__581000085__43 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000082__41, lang.RT_IntCast_J__I_NoInit(1), nil); var off__44 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000085__43, lang.RT_IntCast_J__I_NoInit(0), nil); var size__45 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000085__43, lang.RT_IntCast_J__I_NoInit(1), nil); var h__46 any; var na_723 int64 = shoff__5; var na_724 any; var na_725 any = i__42; var na_726 int64 = shentsize__8
				if jrt.Long_InstanceOf(na_725) { var n0_727 int64 = jrt.NN(jrt.Long_Cast(na_725)).LongValue__J(); var n1_728 int64 = na_726; var nr_729 int64 = n0_727 * n1_728; var tmp108 bool; var tmp109 bool; var tmp110 bool; var tmp111 bool; tmp111 = n0_727 == -9223372036854775808; if tmp111 { tmp111 = n1_728 < 0 }; tmp110 = tmp111; tmp109 = !tmp110; if tmp109 { var tmp112 bool; tmp112 = n1_728 == 0; if !tmp112 { tmp112 = nr_729/n1_728 == n0_727 }; tmp109 = tmp112 }; tmp108 = tmp109; if tmp108 { na_724 = jrt.Long_ValueOf_J__Long_NoInit(nr_729).Ref() } else { na_724 = lang.Numbers_Multiply_O_J__Number_NoInit(na_725, na_726) } } else { na_724 = lang.Numbers_Multiply_O_J__Number_NoInit(na_725, na_726) }; if jrt.Long_InstanceOf(na_724) { var n0_730 int64 = na_723; var n1_731 int64 = jrt.NN(jrt.Long_Cast(na_724)).LongValue__J(); var nr_732 int64 = n0_730 + n1_731; if (n0_730^nr_732)&(n1_731^nr_732) >= 0 { h__46 = jrt.Long_ValueOf_J__Long_NoInit(nr_732).Ref() } else { h__46 = lang.Numbers_Add_J_O__Number_NoInit(na_723, na_724) } } else { h__46 = lang.Numbers_Add_J_O__Number_NoInit(na_723, na_724) }
				var tmp113 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(ob__34); var tmp114 jrt.Number_I; var na_738 any = h__46; var na_739 int64 = 24; if jrt.Long_InstanceOf(na_738) { var n0_740 int64 = jrt.NN(jrt.Long_Cast(na_738)).LongValue__J(); var n1_741 int64 = na_739; var nr_742 int64 = n0_740 + n1_741; if (n0_740^nr_742)&(n1_741^nr_742) >= 0 { tmp114 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_742)) } else { tmp114 = lang.Numbers_Add_O_J__Number_NoInit(na_738, na_739) } } else { tmp114 = lang.Numbers_Add_O_J__Number_NoInit(na_738, na_739) }; tmp113.PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I_NoInit(tmp114), lang.RT_LongCast_O__J_NoInit(off__44))
				var tmp115 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(ob__34); var tmp116 jrt.Number_I; var na_733 any = h__46; var na_734 int64 = 32; if jrt.Long_InstanceOf(na_733) { var n0_735 int64 = jrt.NN(jrt.Long_Cast(na_733)).LongValue__J(); var n1_736 int64 = na_734; var nr_737 int64 = n0_735 + n1_736; if (n0_735^nr_737)&(n1_736^nr_737) >= 0 { tmp116 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_737)) } else { tmp116 = lang.Numbers_Add_O_J__Number_NoInit(na_733, na_734) } } else { tmp116 = lang.Numbers_Add_O_J__Number_NoInit(na_733, na_734) }; tmp115.PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I_NoInit(tmp116), lang.RT_LongCast_O__J_NoInit(size__45))
//line :113:1
				var tmp117 any; var root_743 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = seq_581000072__40; if linked_744 == nil { tmp117 = ifn_745.Invoke_O__O(arg_746) } else { tmp117 = linked_744.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_743, arg_746) }; seq_581000072__35, chunk_581000073__36, count_581000074__37, i_581000075__38 = tmp117, nil, 0, 0; continue L4 } } }
//line :38:1
		break L4 }; var tmp118 jrt.ByteBuffer_I =















































































	jrt.ByteBuffer_Cast(ob__34); var tmp119 jrt.Number_I; var na_684 any; var na_686 int64 = shoff__5; var na_687 any; var na_688 any = symtab__13; var na_689 int64 = shentsize__8; if jrt.Long_InstanceOf(na_688) { var n0_690 int64 = jrt.NN(jrt.Long_Cast(na_688)).LongValue__J(); var n1_691 int64 = na_689; var nr_692 int64 = n0_690 * n1_691; var tmp120 bool; var tmp121 bool; var tmp122 bool; var tmp123 bool; tmp123 = n0_690 == -9223372036854775808; if tmp123 { tmp123 = n1_691 < 0 }; tmp122 = tmp123; tmp121 = !tmp122; if tmp121 { var tmp124 bool; tmp124 = n1_691 == 0; if !tmp124 { tmp124 = nr_692/n1_691 == n0_690 }; tmp121 = tmp124 }; tmp120 = tmp121; if tmp120 { na_687 = jrt.Long_ValueOf_J__Long_NoInit(nr_692).Ref() } else { na_687 = lang.Numbers_Multiply_O_J__Number_NoInit(na_688, na_689) } } else { na_687 = lang.Numbers_Multiply_O_J__Number_NoInit(na_688, na_689) }; if jrt.Long_InstanceOf(na_687) { var n0_693 int64 = na_686; var n1_694 int64 = jrt.NN(jrt.Long_Cast(na_687)).LongValue__J(); var nr_695 int64 = n0_693 + n1_694; if (n0_693^nr_695)&(n1_694^nr_695) >= 0 { na_684 = jrt.Long_ValueOf_J__Long_NoInit(nr_695).Ref() } else { na_684 = lang.Numbers_Add_J_O__Number_NoInit(na_686, na_687) } } else { na_684 = lang.Numbers_Add_J_O__Number_NoInit(na_686, na_687) }; var na_685 int64 = 44; if jrt.Long_InstanceOf(na_684) { var n0_696 int64 = jrt.NN(jrt.Long_Cast(na_684)).LongValue__J(); var n1_697 int64 = na_685; var nr_698 int64 = n0_696 + n1_697; if (n0_696^nr_698)&(n1_697^nr_698) >= 0 { tmp119 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_698)) } else { tmp119 = lang.Numbers_Add_O_J__Number_NoInit(na_684, na_685) } } else { tmp119 = lang.Numbers_Add_O_J__Number_NoInit(na_684, na_685) }; tmp118.PutInt_I_I__ByteBuffer(lang.RT_IntCast_O__I_NoInit(tmp119), lang.RT_IntCast_J__I_NoInit(1)); return out__33 }
//line :48:1
func A_arbace_box_elf_cut_symbols_sec__581000018_A_New_J_J_O(p0, p1 int64, p2 any) *A_arbace_box_elf_cut_symbols_sec__581000018_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_sec__581000018_A{}; t.Ctor_J_J_O(p0, p1, p2); return t }
//line :48:1
func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) Ctor_J_J_O(c__shentsize, c__shoff int64, c__b any) { t.F_shentsize = c__shentsize; t.F_shoff = c__shoff; t.F_b = c__b }
//line :48:1
func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) Invoke_O_O__O(self, i__1 any) any { var h__2 any; var na_35 int64 = t.F_shoff; var na_36 any; var na_37 any = i__1; var na_38 int64 = t.F_shentsize; if jrt.Long_InstanceOf(na_37) { var n0_39 int64 = jrt.NN(jrt.Long_Cast(na_37)).LongValue__J(); var n1_40 int64 = na_38; var nr_41 int64 = n0_39 * n1_40; var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = n0_39 == -9223372036854775808; if tmp4 { tmp4 = n1_40 < 0 }; tmp3 = tmp4; tmp2 = !tmp3; if tmp2 { var tmp5 bool; tmp5 = n1_40 == 0; if !tmp5 { tmp5 = nr_41/n1_40 == n0_39 }; tmp2 = tmp5 }; tmp1 = tmp2; if tmp1 { na_36 = jrt.Long_ValueOf_J__Long_NoInit(nr_41).Ref() } else { na_36 = lang.Numbers_Multiply_O_J__Number_NoInit(na_37, na_38) } } else { na_36 = lang.Numbers_Multiply_O_J__Number_NoInit(na_37, na_38) }; if jrt.Long_InstanceOf(na_36) { var n0_42 int64 = na_35; var n1_43 int64 = jrt.NN(jrt.Long_Cast(na_36)).LongValue__J(); var nr_44 int64 = n0_42 + n1_43; if (n0_42^nr_44)&(n1_43^nr_44) >= 0 { h__2 = jrt.Long_ValueOf_J__Long_NoInit(nr_44).Ref() } else { h__2 = lang.Numbers_Add_J_O__Number_NoInit(na_35, na_36) } } else { h__2 = lang.Numbers_Add_J_O__Number_NoInit(na_35, na_36) }; var tmp6 any = A_arbace_box_elf_A_const_12; var tmp7 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp8 jrt.Number_I; var na_45 any = h__2; var na_46 int64 = 4; if
												jrt.Long_InstanceOf(na_45) { var n0_47 int64 = jrt.NN(jrt.Long_Cast(na_45)).LongValue__J(); var n1_48 int64 = na_46; var nr_49 int64 = n0_47 + n1_48; if (n0_47^nr_49)&(n1_48^nr_49) >= 0 { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_49)) } else { tmp8 = lang.Numbers_Add_O_J__Number_NoInit(na_45, na_46) } } else { tmp8 = lang.Numbers_Add_O_J__Number_NoInit(na_45, na_46) }; var tmp9 any = /*line :48:1*/jrt.Integer_ValueOf_I__Integer_NoInit(tmp7.GetInt_I__I(lang.RT_IntCast_O__I_NoInit(tmp8))).Ref(); var tmp10 any = A_arbace_box_elf_A_const_13; var tmp11 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp12 jrt.Number_I; var na_50 any = h__2; var na_51 int64 = 24; if
												jrt.Long_InstanceOf(na_50) { var n0_52 int64 = jrt.NN(jrt.Long_Cast(na_50)).LongValue__J(); var n1_53 int64 = na_51; var nr_54 int64 = n0_52 + n1_53; if (n0_52^nr_54)&(n1_53^nr_54) >= 0 { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_54)) } else { tmp12 = lang.Numbers_Add_O_J__Number_NoInit(na_50, na_51) } } else { tmp12 = lang.Numbers_Add_O_J__Number_NoInit(na_50, na_51) }; var tmp13 any = /*line :48:1*/jrt.Long_ValueOf_J__Long_NoInit(tmp11.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp12))).Ref(); var tmp14 any = A_arbace_box_elf_A_const_14; var tmp15 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp16 jrt.Number_I; var na_55 any = h__2; var na_56 int64 = 32; if

	jrt.Long_InstanceOf(na_55) { var n0_57 int64 = jrt.NN(jrt.Long_Cast(na_55)).LongValue__J(); var n1_58 int64 = na_56; var nr_59 int64 = n0_57 + n1_58; if (n0_57^nr_59)&(n1_58^nr_59) >= 0 { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_59)) } else { tmp16 = lang.Numbers_Add_O_J__Number_NoInit(na_55, na_56) } } else { tmp16 = lang.Numbers_Add_O_J__Number_NoInit(na_55, na_56) }; var tmp17 any = /*line :48:1*/jrt.Long_ValueOf_J__Long_NoInit(tmp15.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp16))).Ref(); var tmp18 any = A_arbace_box_elf_A_const_15; var tmp19 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp20 jrt.Number_I; var na_60 any = h__2; var na_61 int64 = 40; if

	jrt.Long_InstanceOf(na_60) { var n0_62 int64 = jrt.NN(jrt.Long_Cast(na_60)).LongValue__J(); var n1_63 int64 = na_61; var nr_64 int64 = n0_62 + n1_63; if (n0_62^nr_64)&(n1_63^nr_64) >= 0 { tmp20 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_64)) } else { tmp20 = lang.Numbers_Add_O_J__Number_NoInit(na_60, na_61) } } else { tmp20 = lang.Numbers_Add_O_J__Number_NoInit(na_60, na_61) }; var tmp21 any = /*line :48:1*/jrt.Integer_ValueOf_I__Integer_NoInit(tmp19.GetInt_I__I(lang.RT_IntCast_O__I_NoInit(tmp20))).Ref(); var tmp22 any = A_arbace_box_elf_A_const_16; var tmp23 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp24 jrt.Number_I; var na_65 any = h__2; var na_66 int64 = 48; if


	jrt.Long_InstanceOf(na_65) { var n0_67 int64 = jrt.NN(jrt.Long_Cast(na_65)).LongValue__J(); var n1_68 int64 = na_66; var nr_69 int64 = n0_67 + n1_68; if (n0_67^nr_69)&(n1_68^nr_69) >= 0 { tmp24 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_69)) } else { tmp24 = lang.Numbers_Add_O_J__Number_NoInit(na_65, na_66) } } else { tmp24 = lang.Numbers_Add_O_J__Number_NoInit(na_65, na_66) }; var tmp25 any = /*line :48:1*/jrt.Long_ValueOf_J__Long_NoInit(tmp23.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp24))).Ref(); var tmp26 any = A_arbace_box_elf_A_const_17; var tmp27 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp28 jrt.Number_I; var na_70 any = h__2; var na_71 int64 = 56; if


	jrt.Long_InstanceOf(na_70) { var n0_72 int64 = jrt.NN(jrt.Long_Cast(na_70)).LongValue__J(); var n1_73 int64 = na_71; var nr_74 int64 = n0_72 + n1_73; if (n0_72^nr_74)&(n1_73^nr_74) >= 0 { tmp28 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_74)) } else { tmp28 = lang.Numbers_Add_O_J__Number_NoInit(na_70, na_71) } } else { tmp28 = lang.Numbers_Add_O_J__Number_NoInit(na_70, na_71) }; return /*line :48:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp9, tmp10, tmp13, tmp14, tmp17, tmp18, tmp21, tmp22, tmp25, tmp26, jrt.Long_ValueOf_J__Long_NoInit(tmp27.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp28))).Ref())) }




func A_arbace_box_elf_cut_symbols_fn__581000020_A_New() *A_arbace_box_elf_cut_symbols_fn__581000020_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000020_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) Ctor() {}
//line :53:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) Invoke_O_O_O__O(self, i__1, s__2 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_box_elf_A_const_22.GetRawRoot__O(), A_arbace_box_elf_A_const_12.Invoke_O__O(s__2)) { return i__1 } else { return nil } }



func A_arbace_box_elf_cut_symbols_fn__581000022_A_New_O(p0 any) *A_arbace_box_elf_cut_symbols_fn__581000022_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000022_A{}; t.Ctor_O(p0); return t }
//line :57:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) Ctor_O(c__secs any) { t.F_secs = c__secs }
//line :57:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) Invoke_O_O__O(self, p1__581000016_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_box_elf_A_const_13; return tmp1.Invoke_O__O(lang.IFn_Cast(t.F_secs).Invoke_O__O(p1__581000016_SHARP___1)) }


















func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) Ctor_O_O_O_O_O(c__data, c__st, c__strs, c__want, c__b any) { t.F_data = c__data; t.F_st = c__st; t.F_strs = c__strs; t.F_want = c__want; t.F_b = c__b }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) Invoke_O_O__O(self, s__581000039__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__220 any = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_New_O_O_O_O_O_O_O(s__581000039__1, t.F_data, t.F_st, t.F_strs, self, t.F_want, t.F_b); var tmp2 *jrt.Class; var fncls__219 *jrt.Class = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class; if fncls__219 == nil { var fncls__219d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, fnbody__220); A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class = fncls__219d; tmp2 = fncls__219d } else { tmp2 = fncls__219 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__220, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :76:1
func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) Ctor_O_O_O_O_O_O_O(c__s__581000039, c__data, c__st, c__strs, c__iter__581000038, c__want, c__b any) { t.F_s__581000039 = c__s__581000039; t.F_data = c__data; t.F_st = c__st; t.F_strs = c__strs; t.F_iter__581000038 = c__iter__581000038; t.F_want = c__want; t.F_b = c__b }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) Invoke_O__O(self any) any { { var s__581000039__1 any; var t_ any = t.F_s__581000039; t.F_s__581000039 = nil; s__581000039__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_117 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = s__581000039__1; if linked_118 == nil { temp__1927000414__auto____2 = ifn_119.Invoke_O__O(arg_120) } else { temp__1927000414__auto____2 = linked_118.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_117, arg_120) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__581000039__3 any = temp__1927000414__auto____2; var tmp1 any; var root_121 any = A_arbace_box_elf_A_const_27.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = s__581000039__3; if linked_122 == nil { tmp1 = ifn_123.Invoke_O__O(arg_124) } else { tmp1 = linked_122.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_121, arg_124) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_125 any = A_arbace_box_elf_A_const_28.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = s__581000039__3; if linked_126 == nil { c__1927001037__auto____4 = ifn_127.Invoke_O__O(arg_128) } else { c__1927001037__auto____4 = linked_126.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_125, arg_128) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__581000041__6 any; var root_129 any = A_arbace_box_elf_A_const_29.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_130 == nil { b__581000041__6 = ifn_131.Invoke_O__O(arg_132) } else { b__581000041__6 = linked_130.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_129, arg_132) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__159 any = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_New_O_O_O_O_O_I_O_O(b__581000041__6, t.F_data, t.F_st, t.F_strs, t.F_want, size__1927001038__auto____5, c__1927001037__auto____4, t.F_b); var tmp3 *jrt.Class; var fncls__158 *jrt.Class = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class; if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__159); A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class = fncls__158d; tmp3 = fncls__158d } else { tmp3 = fncls__158 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__159, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_160 any = A_arbace_box_elf_A_const_34.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any; var root_165 any = A_arbace_box_elf_A_const_35.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = b__581000041__6; if linked_166 == nil { arg_163 = ifn_167.Invoke_O__O(arg_168) } else { arg_163 = linked_166.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_165, arg_168) }; var arg_164 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__581000038); var tmp5 any; var root_169 any = A_arbace_box_elf_A_const_36.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = s__581000039__3; if linked_170 == nil { tmp5 = ifn_171.Invoke_O__O(arg_172) } else { tmp5 = linked_170.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_169, arg_172) }; arg_164 = tmp4.Invoke_O__O(tmp5); if linked_161 == nil { return ifn_162.Invoke_O_O__O(arg_163, arg_164) } else { return linked_161.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_160, arg_163, arg_164) } } else { var root_173 any = A_arbace_box_elf_A_const_34.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any; var root_178 any = A_arbace_box_elf_A_const_35.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = b__581000041__6; if linked_179 == nil { arg_176 = ifn_180.Invoke_O__O(arg_181) } else { arg_176 = linked_179.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_178, arg_181) }; var arg_177 any; if linked_174 == nil { return ifn_175.Invoke_O_O__O(arg_176, arg_177) } else { return linked_174.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_173, arg_176, arg_177) } } } else { var i__4 any; var root_182 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = s__581000039__3; if linked_183 == nil { i__4 = ifn_184.Invoke_O__O(arg_185) } else { i__4 = linked_183.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_182, arg_185) }; var e__5 any; var na_186 any = A_arbace_box_elf_A_const_13.Invoke_O__O(t.F_st); var na_187 any; var na_188 int64 = 24; var na_189 any = i__4
														if jrt.Long_InstanceOf(na_189) { var n0_190 int64 = na_188; var n1_191 int64 = jrt.NN(jrt.Long_Cast(na_189)).LongValue__J(); var nr_192 int64 = n0_190 * n1_191; var tmp6 bool; var tmp7 bool; var tmp8 bool; var tmp9 bool; tmp9 = n0_190 == -9223372036854775808; if tmp9 { tmp9 = n1_191 < 0 }; tmp8 = tmp9; tmp7 = !tmp8; if tmp7 { var tmp10 bool; tmp10 = n1_191 == 0; if !tmp10 { tmp10 = nr_192/n1_191 == n0_190 }; tmp7 = tmp10 }; tmp6 = tmp7; if tmp6 { na_187 = jrt.Long_ValueOf_J__Long_NoInit(nr_192).Ref() } else { na_187 = lang.Numbers_Multiply_J_O__Number_NoInit(na_188, na_189) } } else { na_187 = lang.Numbers_Multiply_J_O__Number_NoInit(na_188, na_189) }; var tmp11 bool; var tmp12 bool; tmp12 = jrt.Long_InstanceOf(na_186); if tmp12 { tmp12 = jrt.Long_InstanceOf(na_187) }; tmp11 = tmp12; if tmp11 { var n0_193 int64 = jrt.NN(jrt.Long_Cast(na_186)).LongValue__J(); var n1_194 int64 = jrt.NN(jrt.Long_Cast(na_187)).LongValue__J(); var nr_195 int64 = n0_193 + n1_194; if (n0_193^nr_195)&(n1_194^nr_195) >= 0 { e__5 = jrt.Long_ValueOf_J__Long_NoInit(nr_195).Ref() } else { e__5 = lang.Numbers_Add_O_O__Number_NoInit(na_186, na_187) } } else { var tmp13 bool; var tmp14 bool; tmp14 = jrt.Double_InstanceOf(na_186); if tmp14 { tmp14 = jrt.Double_InstanceOf(na_187) }; tmp13 = tmp14; if tmp13 { var n0_193_2 float64 = jrt.NN(jrt.Double_Cast(na_186)).DoubleValue__D(); var n1_194_2 float64 = jrt.NN(jrt.Double_Cast(na_187)).DoubleValue__D(); e__5 = jrt.Double_ValueOf_D__Double_NoInit(n0_193_2 + n1_194_2).Ref() } else { e__5 = lang.Numbers_Add_O_O__Number_NoInit(na_186, na_187) } }
//line :76:1
	var nm__6 any; var root_196 any = A_arbace_box_elf_A_const_30.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_196, A_arbace_box_elf_c_string_A_fn_class); var ifn_198 lang.IFn

	if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = t.F_data; var arg_200 any; var na_201 any = t.F_strs; var tmp15 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var na_202 int64 = lang.Numbers_And_J_J__J_NoInit(int64(tmp15.GetInt_I__I(lang.RT_IntCast_O__I_NoInit(e__5))), 4294967295); if jrt.Long_InstanceOf(na_201) { var n0_203 int64 = jrt.NN(jrt.Long_Cast(na_201)).LongValue__J(); var n1_204 int64 = na_202; var nr_205 int64 = n0_203 + n1_204; if (n0_203^nr_205)&(n1_204^nr_205) >= 0 { arg_200 = jrt.Long_ValueOf_J__Long_NoInit(nr_205).Ref() } else { arg_200 = lang.Numbers_Add_O_J__Number_NoInit(na_201, na_202) } } else { arg_200 = lang.Numbers_Add_O_J__Number_NoInit(na_201, na_202) }; if linked_197 == nil { nm__6 = ifn_198.Invoke_O_O__O(arg_199, arg_200) } else { nm__6 = linked_197.(*A_arbace_box_elf_c_string_A).InvokePrim_O_O_J__O(root_196, arg_199, lang.RT_LongCast_O__J_NoInit(arg_200)) }
//line :76:1
	if jrt.J2g_Truth(lang.IFn_Cast(t.F_want).Invoke_O__O(nm__6)) { var root_206 any = A_arbace_box_elf_A_const_37.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_32, nm__6, A_arbace_box_elf_A_const_33, e__5)); var arg_210 any; var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__581000038); var tmp17 any; var root_211 any = A_arbace_box_elf_A_const_38.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = s__581000039__3; if linked_212 == nil { tmp17 = ifn_213.Invoke_O__O(arg_214) } else { tmp17 = linked_212.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_211, arg_214) }; arg_210 = tmp16.Invoke_O__O(tmp17); if linked_207 == nil { return ifn_208.Invoke_O_O__O(arg_209, arg_210) } else { return linked_207.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_206, arg_209, arg_210) } } else { var tmp18 any; var root_215 any = A_arbace_box_elf_A_const_38.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = s__581000039__3; if linked_216 == nil { tmp18 = ifn_217.Invoke_O__O(arg_218) } else { tmp18 = linked_216.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_215, arg_218) }; s__581000039__1 = tmp18; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :76:1
func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_New_O_O_O_O_O_I_O_O(p0, p1, p2, p3, p4 any, p5 int32, p6, p7 any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A{}; t.Ctor_O_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) Ctor_O_O_O_O_O_I_O_O(c__b__581000041, c__data, c__st, c__strs, c__want any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b any) { t.F_b__581000041 = c__b__581000041; t.F_data = c__data; t.F_st = c__st; t.F_strs = c__strs; t.F_want = c__want; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b = c__b }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) Invoke_O__O(self any) any { { var i__581000040__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__581000040__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__581000040__1)); var e__3 any; var na_133 any = A_arbace_box_elf_A_const_13.Invoke_O__O(t.F_st); var na_134 any; var na_135 int64 = 24; var na_136 any = i__2
																if jrt.Long_InstanceOf(na_136) { var n0_137 int64 = na_135; var n1_138 int64 = jrt.NN(jrt.Long_Cast(na_136)).LongValue__J(); var nr_139 int64 = n0_137 * n1_138; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = n0_137 == -9223372036854775808; if tmp5 { tmp5 = n1_138 < 0 }; tmp4 = tmp5; tmp3 = !tmp4; if tmp3 { var tmp6 bool; tmp6 = n1_138 == 0; if !tmp6 { tmp6 = nr_139/n1_138 == n0_137 }; tmp3 = tmp6 }; tmp2 = tmp3; if tmp2 { na_134 = jrt.Long_ValueOf_J__Long_NoInit(nr_139).Ref() } else { na_134 = lang.Numbers_Multiply_J_O__Number_NoInit(na_135, na_136) } } else { na_134 = lang.Numbers_Multiply_J_O__Number_NoInit(na_135, na_136) }; var tmp7 bool; var tmp8 bool; tmp8 = jrt.Long_InstanceOf(na_133); if tmp8 { tmp8 = jrt.Long_InstanceOf(na_134) }; tmp7 = tmp8; if tmp7 { var n0_140 int64 = jrt.NN(jrt.Long_Cast(na_133)).LongValue__J(); var n1_141 int64 = jrt.NN(jrt.Long_Cast(na_134)).LongValue__J(); var nr_142 int64 = n0_140 + n1_141; if (n0_140^nr_142)&(n1_141^nr_142) >= 0 { e__3 = jrt.Long_ValueOf_J__Long_NoInit(nr_142).Ref() } else { e__3 = lang.Numbers_Add_O_O__Number_NoInit(na_133, na_134) } } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_133); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_134) }; tmp9 = tmp10; if tmp9 { var n0_140_2 float64 = jrt.NN(jrt.Double_Cast(na_133)).DoubleValue__D(); var n1_141_2 float64 = jrt.NN(jrt.Double_Cast(na_134)).DoubleValue__D(); e__3 = jrt.Double_ValueOf_D__Double_NoInit(n0_140_2 + n1_141_2).Ref() } else { e__3 = lang.Numbers_Add_O_O__Number_NoInit(na_133, na_134) } }
//line :76:1
	var nm__4 any; var root_143 any = A_arbace_box_elf_A_const_30.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_143, A_arbace_box_elf_c_string_A_fn_class); var ifn_145 lang.IFn

	if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = t.F_data; var arg_147 any; var na_148 any = t.F_strs; var tmp11 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var na_149 int64 = lang.Numbers_And_J_J__J_NoInit(int64(tmp11.GetInt_I__I(lang.RT_IntCast_O__I_NoInit(e__3))), 4294967295); if jrt.Long_InstanceOf(na_148) { var n0_150 int64 = jrt.NN(jrt.Long_Cast(na_148)).LongValue__J(); var n1_151 int64 = na_149; var nr_152 int64 = n0_150 + n1_151; if (n0_150^nr_152)&(n1_151^nr_152) >= 0 { arg_147 = jrt.Long_ValueOf_J__Long_NoInit(nr_152).Ref() } else { arg_147 = lang.Numbers_Add_O_J__Number_NoInit(na_148, na_149) } } else { arg_147 = lang.Numbers_Add_O_J__Number_NoInit(na_148, na_149) }; if linked_144 == nil { nm__4 = ifn_145.Invoke_O_O__O(arg_146, arg_147) } else { nm__4 = linked_144.(*A_arbace_box_elf_c_string_A).InvokePrim_O_O_J__O(root_143, arg_146, lang.RT_LongCast_O__J_NoInit(arg_147)) }
//line :76:1
	if jrt.J2g_Truth(lang.IFn_Cast(t.F_want).Invoke_O__O(nm__4)) { var root_153 any = A_arbace_box_elf_A_const_31.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = t.F_b__581000041; var arg_157 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_32, nm__4, A_arbace_box_elf_A_const_33, e__3)); if linked_154 == nil { ifn_155.Invoke_O_O__O(arg_156, arg_157) } else { linked_154.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_153, arg_156, arg_157) }; i__581000040__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__581000040__1); continue L1 } else { i__581000040__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__581000040__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_box_elf_cut_symbols_fn__581000052_A_New_O_O(p0, p1 any) *A_arbace_box_elf_cut_symbols_fn__581000052_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000052_A{}; t.Ctor_O_O(p0, p1); return t }
//line :81:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) Ctor_O_O(c__kept, c__data any) { t.F_kept = c__kept; t.F_data = c__data }
//line :81:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) Invoke_O__O(self any) any { { var seq_581000048__1 any; var root_228 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any; var t_ any = t.F_kept; t.F_kept = nil; arg_231 = t_; if linked_229 == nil { seq_581000048__1 = ifn_230.Invoke_O__O(arg_231) } else { seq_581000048__1 = linked_229.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_228, arg_231) }; var chunk_581000049__2 any; var count_581000050__3 int64 = 0; var i_581000051__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_581000051__4, count_581000050__3) { var map__581000053__5 any = lang.Indexed_Cast(chunk_581000049__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_581000051__4)); var map__581000053__6 any; if lang.ISeq_InstanceOf(map__581000053__5) { var tmp1 any; var root_232 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = map__581000053__5; if linked_233 == nil { tmp1 = ifn_234.Invoke_O__O(arg_235) } else { tmp1 = linked_233.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_232, arg_235) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_236 any = A_arbace_box_elf_A_const_41.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = map__581000053__5; if linked_237 == nil { tmp2 = ifn_238.Invoke_O__O(arg_239) } else { tmp2 = linked_237.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_236, arg_239) }; map__581000053__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_240 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = map__581000053__5; if linked_241 == nil { tmp3 = ifn_242.Invoke_O__O(arg_243) } else { tmp3 = linked_241.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_240, arg_243) }; if jrt.J2g_Truth(tmp3) { var root_244 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = map__581000053__5; if linked_245 == nil { map__581000053__6 = ifn_246.Invoke_O__O(arg_247) } else { map__581000053__6 = linked_245.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_244, arg_247) } } else { map__581000053__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000053__6 = map__581000053__5 }; var name__7 any = lang.RT_Get_O_O__O_NoInit(map__581000053__6, A_arbace_box_elf_A_const_32); var entry__8 any = lang.RT_Get_O_O__O_NoInit(map__581000053__6, A_arbace_box_elf_A_const_33); var tmp4 any = A_arbace_box_elf_A_const_42.GetRawRoot__O(); var tmp5 *jrt.ByteArray = jrt.ByteArray_Cast(t.F_data); var tmp6 jrt.Number_I; var na_280 any = entry__8; var na_281 int64 = 4
											if jrt.Long_InstanceOf(na_280) { var n0_282 int64 = jrt.NN(jrt.Long_Cast(na_280)).LongValue__J(); var n1_283 int64 = na_281; var nr_284 int64 = n0_282 + n1_283; if (n0_282^nr_284)&(n1_283^nr_284) >= 0 { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_284)) } else { tmp6 = lang.Numbers_Add_O_J__Number_NoInit(na_280, na_281) } } else { tmp6 = lang.Numbers_Add_O_J__Number_NoInit(na_280, na_281) }; if lang.Util_Equiv_O_J__Z_NoInit(tmp4, lang.Numbers_ShiftRight_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(tmp5, lang.RT_IntCast_O__I_NoInit(tmp6))).Ref()), 255), 4)) {
												var root_285 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, A_arbace_box_elf_fail_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16), jrt.RefArrayOf(jrt.Object_class, nil, name__7, nil)).Ref(); if linked_286 == nil { ifn_287.Invoke_O__O(arg_288) } else { linked_286.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_285, arg_288) } }
//line :81:1
	seq_581000048__1, chunk_581000049__2, count_581000050__3, i_581000051__4 = seq_581000048__1, chunk_581000049__2, count_581000050__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000051__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_248 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = seq_581000048__1; if linked_249 == nil { temp__1927000414__auto____5 = ifn_250.Invoke_O__O(arg_251) } else { temp__1927000414__auto____5 = linked_249.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_248, arg_251) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_581000048__6 any = temp__1927000414__auto____5; var tmp7 any; var root_252 any = A_arbace_box_elf_A_const_27.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = seq_581000048__6; if linked_253 == nil { tmp7 = ifn_254.Invoke_O__O(arg_255) } else { tmp7 = linked_253.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_252, arg_255) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____7 any; var root_256 any = A_arbace_box_elf_A_const_28.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = seq_581000048__6; if linked_257 == nil { c__1927000678__auto____7 = ifn_258.Invoke_O__O(arg_259) } else { c__1927000678__auto____7 = linked_257.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_256, arg_259) }; var tmp8 any; var root_289 any = A_arbace_box_elf_A_const_36.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = seq_581000048__6; if linked_290 == nil { tmp8 = ifn_291.Invoke_O__O(arg_292) } else { tmp8 = linked_290.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_289, arg_292) }; seq_581000048__1, chunk_581000049__2, count_581000050__3, i_581000051__4 = tmp8, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var map__581000055__7 any; var root_260 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = seq_581000048__6; if linked_261 == nil { map__581000055__7 = ifn_262.Invoke_O__O(arg_263) } else { map__581000055__7 = linked_261.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_260, arg_263) }; var map__581000055__8 any; if lang.ISeq_InstanceOf(map__581000055__7) { var tmp9 any; var root_264 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = map__581000055__7; if linked_265 == nil { tmp9 = ifn_266.Invoke_O__O(arg_267) } else { tmp9 = linked_265.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_264, arg_267) }; if jrt.J2g_Truth(tmp9) { var tmp10 any; var root_268 any = A_arbace_box_elf_A_const_41.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = map__581000055__7; if linked_269 == nil { tmp10 = ifn_270.Invoke_O__O(arg_271) } else { tmp10 = linked_269.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_268, arg_271) }; map__581000055__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp10)).Ref() } else { var tmp11 any; var root_272 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = map__581000055__7; if linked_273 == nil { tmp11 = ifn_274.Invoke_O__O(arg_275) } else { tmp11 = linked_273.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_272, arg_275) }; if jrt.J2g_Truth(tmp11) { var root_276 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = map__581000055__7; if linked_277 == nil { map__581000055__8 = ifn_278.Invoke_O__O(arg_279) } else { map__581000055__8 = linked_277.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_276, arg_279) } } else { map__581000055__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000055__8 = map__581000055__7 }; var name__9 any = lang.RT_Get_O_O__O_NoInit(map__581000055__8, A_arbace_box_elf_A_const_32); var entry__10 any = lang.RT_Get_O_O__O_NoInit(map__581000055__8, A_arbace_box_elf_A_const_33); var tmp12 any = A_arbace_box_elf_A_const_42.GetRawRoot__O(); var tmp13 *jrt.ByteArray = jrt.ByteArray_Cast(t.F_data); var tmp14 jrt.Number_I; var na_293 any = entry__10; var na_294 int64 = 4
		if jrt.Long_InstanceOf(na_293) { var n0_295 int64 = jrt.NN(jrt.Long_Cast(na_293)).LongValue__J(); var n1_296 int64 = na_294; var nr_297 int64 = n0_295 + n1_296; if (n0_295^nr_297)&(n1_296^nr_297) >= 0 { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_297)) } else { tmp14 = lang.Numbers_Add_O_J__Number_NoInit(na_293, na_294) } } else { tmp14 = lang.Numbers_Add_O_J__Number_NoInit(na_293, na_294) }; if lang.Util_Equiv_O_J__Z_NoInit(tmp12, lang.Numbers_ShiftRight_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(tmp13, lang.RT_IntCast_O__I_NoInit(tmp14))).Ref()), 255), 4)) {
			var root_298 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, A_arbace_box_elf_fail_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16), jrt.RefArrayOf(jrt.Object_class, nil, name__9, nil)).Ref(); if linked_299 == nil { ifn_300.Invoke_O__O(arg_301) } else { linked_299.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_298, arg_301) } }
//line :81:1
		var tmp15 any; var root_302 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = seq_581000048__6; if linked_303 == nil { tmp15 = ifn_304.Invoke_O__O(arg_305) } else { tmp15 = linked_303.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_302, arg_305) }; seq_581000048__1, chunk_581000049__2, count_581000050__3, i_581000051__4 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }





func A_arbace_box_elf_cut_symbols_fn__581000058_A_New() *A_arbace_box_elf_cut_symbols_fn__581000058_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000058_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) Ctor() {}
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) Invoke_O_O_O__O(self, acc__1, k__2 any) any { var tmp1 any; var root_344 any = A_arbace_box_elf_A_const_48.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any; var fnbody__350 any = A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_New_O(k__2); var tmp2 *jrt.Class; var fncls__349 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class; if fncls__349 == nil { var fncls__349d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, fnbody__350); A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class = fncls__349d; tmp2 = fncls__349d } else { tmp2 = fncls__349 }; arg_347 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__350, tmp2, nil); var arg_348 any = acc__1; if linked_345 == nil { tmp1 = ifn_346.Invoke_O_O__O(arg_347, arg_348) } else { tmp1 = linked_345.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_344, arg_347, arg_348) }; if jrt.J2g_Truth(tmp1) { return acc__1 } else { var root_351 any = A_arbace_box_elf_A_const_5.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_353 lang.IFn; if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = acc__1; var arg_355 any = k__2; if linked_352 == nil { return ifn_353.Invoke_O_O__O(arg_354, arg_355) } else { return linked_352.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_351, arg_354, arg_355) } } }
//line :87:1
func A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_New_O(p0 any) *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A{}; t.Ctor_O(p0); return t }
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) Invoke_O_O__O(self, p1__581000017_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_box_elf_A_const_32.Invoke_O__O(t.F_k), A_arbace_box_elf_A_const_32.Invoke_O__O(p1__581000017_SHARP___1))).Ref() }
















func A_arbace_box_elf_cut_symbols_place__581000070_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_elf_cut_symbols_place__581000070_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_place__581000070_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :104:1
func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) Ctor_O_O_O(c__places, c__o, c__secs any) { t.F_places = c__places; t.F_o = c__o; t.F_secs = c__secs }
//line :104:1
func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) Invoke_O_O_O__O(self, i__1, bs__2 any) any {
	var root_367 any = A_arbace_box_elf_A_const_50.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_367, A_arbace_box_elf_align_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = t.F_o; var tmp1 *lang.Keyword = A_arbace_box_elf_A_const_16; var arg_371 any = tmp1.Invoke_O__O(lang.IFn_Cast(t.F_secs).Invoke_O__O(i__1)); if linked_368 == nil { ifn_369.Invoke_O_O__O(arg_370, arg_371) } else { linked_368.(*A_arbace_box_elf_align_A).InvokePrim_O_O_J__O(root_367, arg_370, lang.RT_LongCast_O__J_NoInit(arg_371)) }
	var root_372 any = A_arbace_box_elf_A_const_51.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = t.F_places; var arg_376 any = A_arbace_box_elf_A_const_52.GetRawRoot__O(); var arg_377 any = i__1; var arg_378 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.ByteArrayOutputStream_Cast(t.F_o).Size__I()).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(bs__2))).Ref()); if linked_373 == nil { ifn_374.Invoke_O_O_O_O__O(arg_375, arg_376, arg_377, arg_378) } else { linked_373.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_372, arg_375, arg_376, arg_377, arg_378) }
	var tmp2 jrt.OutputStream_I = jrt.OutputStream_Cast(t.F_o); tmp2.Write_B1__V(jrt.ByteArray_Cast(bs__2)); return nil
}











type A_arbace_box_elf_A struct{ jrt.Object }

var A_arbace_box_elf_A_const_pool *jrt.RefArray

var A_arbace_box_elf_A_const_0 *lang.Var

var A_arbace_box_elf_A_const_1 any

var A_arbace_box_elf_A_const_2 *lang.Var

var A_arbace_box_elf_A_const_3 *lang.Var

var A_arbace_box_elf_A_const_4 *lang.Var

var A_arbace_box_elf_A_const_5 *lang.Var

var A_arbace_box_elf_A_const_6 any

var A_arbace_box_elf_A_const_7 *lang.Var

var A_arbace_box_elf_A_const_8 any

var A_arbace_box_elf_A_const_9 *lang.Var

var A_arbace_box_elf_A_const_10 *lang.Var

var A_arbace_box_elf_A_const_11 *lang.Var

var A_arbace_box_elf_A_const_12 *lang.Keyword

var A_arbace_box_elf_A_const_13 *lang.Keyword

var A_arbace_box_elf_A_const_14 *lang.Keyword

var A_arbace_box_elf_A_const_15 *lang.Keyword

var A_arbace_box_elf_A_const_16 *lang.Keyword

var A_arbace_box_elf_A_const_17 *lang.Keyword

var A_arbace_box_elf_A_const_18 *lang.Var

var A_arbace_box_elf_A_const_19 *lang.Var

var A_arbace_box_elf_A_const_20 *lang.Var

var A_arbace_box_elf_A_const_21 *lang.Var

var A_arbace_box_elf_A_const_22 *lang.Var

var A_arbace_box_elf_A_const_23 *lang.Var

var A_arbace_box_elf_A_const_24 *lang.Var

var A_arbace_box_elf_A_const_25 *lang.Var

var A_arbace_box_elf_A_const_26 *lang.Var

var A_arbace_box_elf_A_const_27 *lang.Var

var A_arbace_box_elf_A_const_28 *lang.Var

var A_arbace_box_elf_A_const_29 *lang.Var

var A_arbace_box_elf_A_const_30 *lang.Var

var A_arbace_box_elf_A_const_31 *lang.Var

var A_arbace_box_elf_A_const_32 *lang.Keyword

var A_arbace_box_elf_A_const_33 *lang.Keyword

var A_arbace_box_elf_A_const_34 *lang.Var

var A_arbace_box_elf_A_const_35 *lang.Var

var A_arbace_box_elf_A_const_36 *lang.Var

var A_arbace_box_elf_A_const_37 *lang.Var

var A_arbace_box_elf_A_const_38 *lang.Var

var A_arbace_box_elf_A_const_39 any

var A_arbace_box_elf_A_const_40 *lang.Var

var A_arbace_box_elf_A_const_41 *lang.Var

var A_arbace_box_elf_A_const_42 *lang.Var

var A_arbace_box_elf_A_const_43 *lang.Var

var A_arbace_box_elf_A_const_44 *lang.Var

var A_arbace_box_elf_A_const_45 *lang.Var

var A_arbace_box_elf_A_const_46 *lang.Var

var A_arbace_box_elf_A_const_47 *lang.Var

var A_arbace_box_elf_A_const_48 *lang.Var

var A_arbace_box_elf_A_const_49 *lang.Var

var A_arbace_box_elf_A_const_50 *lang.Var

var A_arbace_box_elf_A_const_51 *lang.Var

var A_arbace_box_elf_A_const_52 *lang.Var

var A_arbace_box_elf_A_const_53 *lang.Var

var A_arbace_box_elf_A_const_54 *lang.Var

var A_arbace_box_elf_A_const_55 *lang.Var

var A_arbace_box_elf_A_const_56 *lang.Var

var A_arbace_box_elf_A_const_57 *lang.Var

var A_arbace_box_elf_A_const_58 any

var A_arbace_box_elf_A_init jrt.ClassInit

func A_arbace_box_elf_A_Init() { if !A_arbace_box_elf_A_init.Done() { A_arbace_box_elf_A_init.Run(A_arbace_box_elf_A_clinit) } }

func A_arbace_box_elf_A_clinit() { A_arbace_box_elf_A_clinit_p0(); A_arbace_box_elf_A_clinit_p1(); A_arbace_box_elf_A_clinit_p2(); A_arbace_box_elf_A_clinit_p3(); A_arbace_box_elf_A_clinit_p4() }

func A_arbace_box_elf_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_elf_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 70); A_arbace_box_elf_A_const_0 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[11]); A_arbace_box_elf_A_const_1 = A_arbace_box_elf_A_const_pool.A[12]; A_arbace_box_elf_A_const_2 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[13]); A_arbace_box_elf_A_const_3 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[14]); A_arbace_box_elf_A_const_4 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[15]); A_arbace_box_elf_A_const_5 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[16]); A_arbace_box_elf_A_const_6 = A_arbace_box_elf_A_const_pool.A[17]; A_arbace_box_elf_A_const_7 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[18]); A_arbace_box_elf_A_const_8 = A_arbace_box_elf_A_const_pool.A[19]; A_arbace_box_elf_A_const_9 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[20]); A_arbace_box_elf_A_const_10 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[21]); A_arbace_box_elf_A_const_11 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[22]) }

func A_arbace_box_elf_A_clinit_p1() { A_arbace_box_elf_A_const_12 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[23]); A_arbace_box_elf_A_const_13 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[24]); A_arbace_box_elf_A_const_14 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[25]); A_arbace_box_elf_A_const_15 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[26]); A_arbace_box_elf_A_const_16 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[27]); A_arbace_box_elf_A_const_17 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[28]); A_arbace_box_elf_A_const_18 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[29]); A_arbace_box_elf_A_const_19 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[30]); A_arbace_box_elf_A_const_20 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[31]); A_arbace_box_elf_A_const_21 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[32]); A_arbace_box_elf_A_const_22 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[33]); A_arbace_box_elf_A_const_23 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[34]) }

func A_arbace_box_elf_A_clinit_p2() { A_arbace_box_elf_A_const_24 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[35]); A_arbace_box_elf_A_const_25 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[36]); A_arbace_box_elf_A_const_26 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[37]); A_arbace_box_elf_A_const_27 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[38]); A_arbace_box_elf_A_const_28 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[39]); A_arbace_box_elf_A_const_29 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[40]); A_arbace_box_elf_A_const_30 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[41]); A_arbace_box_elf_A_const_31 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[42]); A_arbace_box_elf_A_const_32 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[43]); A_arbace_box_elf_A_const_33 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[44]); A_arbace_box_elf_A_const_34 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[45]); A_arbace_box_elf_A_const_35 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[46]) }

func A_arbace_box_elf_A_clinit_p3() { A_arbace_box_elf_A_const_36 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[47]); A_arbace_box_elf_A_const_37 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[48]); A_arbace_box_elf_A_const_38 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[49]); A_arbace_box_elf_A_const_39 = A_arbace_box_elf_A_const_pool.A[50]; A_arbace_box_elf_A_const_40 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[51]); A_arbace_box_elf_A_const_41 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[52]); A_arbace_box_elf_A_const_42 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[53]); A_arbace_box_elf_A_const_43 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[54]); A_arbace_box_elf_A_const_44 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[55]); A_arbace_box_elf_A_const_45 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[56]); A_arbace_box_elf_A_const_46 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[57]); A_arbace_box_elf_A_const_47 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[58]) }

func A_arbace_box_elf_A_clinit_p4() { A_arbace_box_elf_A_const_48 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[59]); A_arbace_box_elf_A_const_49 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[60]); A_arbace_box_elf_A_const_50 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[61]); A_arbace_box_elf_A_const_51 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[62]); A_arbace_box_elf_A_const_52 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[63]); A_arbace_box_elf_A_const_53 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[64]); A_arbace_box_elf_A_const_54 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[65]); A_arbace_box_elf_A_const_55 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[66]); A_arbace_box_elf_A_const_56 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[67]); A_arbace_box_elf_A_const_57 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[68]); A_arbace_box_elf_A_const_58 = A_arbace_box_elf_A_const_pool.A[69] }

func A_arbace_box_elf_A_New() *A_arbace_box_elf_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf_A) Ctor() {}

func (t *A_arbace_box_elf_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_A_class }

func (t *A_arbace_box_elf_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_elf_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_A); return ok }

func A_arbace_box_elf_A_Cast(x any) *A_arbace_box_elf_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_A_class)) }; return v }



type A_arbace_box_elf_align_A struct{ j2g_header uint64 }

var A_arbace_box_elf_align_A_fn_class *jrt.Class



type A_arbace_box_elf_c_string_A struct{ j2g_header uint64 }

var A_arbace_box_elf_c_string_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_A struct{ j2g_header uint64 }

var A_arbace_box_elf_cut_symbols_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000020_A struct{ j2g_header uint64 }

var A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000022_A struct{ j2g_header uint64; F_secs any }

var A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000052_A struct{ j2g_header uint64; F_kept, F_data any }

var A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000058_A struct{ j2g_header uint64 }

var A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A struct{ j2g_header uint64; F_k any }

var A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A struct{ j2g_header uint64; F_data, F_st, F_strs, F_want, F_b any }

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A struct{ j2g_header uint64; F_s__581000039, F_data, F_st, F_strs, F_iter__581000038, F_want, F_b any }

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A struct{ j2g_header uint64; F_b__581000041, F_data, F_st, F_strs, F_want any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b any }

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_place__581000070_A struct{ j2g_header uint64; F_places, F_o, F_secs any }

var A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_sec__581000018_A struct{ j2g_header uint64; F_shentsize, F_shoff int64; F_b any }

var A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class *jrt.Class



type A_arbace_box_elf_eval581000004_A struct{ jrt.Object }

func A_arbace_box_elf_eval581000004_A_New() *A_arbace_box_elf_eval581000004_A { t := &A_arbace_box_elf_eval581000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf_eval581000004_A) Ctor() {}

func (t *A_arbace_box_elf_eval581000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_eval581000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_eval581000004_A_class }

func (t *A_arbace_box_elf_eval581000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_eval581000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_elf_eval581000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_eval581000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_eval581000004_A); return ok }

func A_arbace_box_elf_eval581000004_A_Cast(x any) *A_arbace_box_elf_eval581000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_eval581000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_eval581000004_A_class)) }; return v }



type A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A struct{ j2g_header uint64 }

var A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_fn_class *jrt.Class



type A_arbace_box_elf_eval581000008_A struct{ jrt.Object }

func A_arbace_box_elf_eval581000008_A_New() *A_arbace_box_elf_eval581000008_A { t := &A_arbace_box_elf_eval581000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf_eval581000008_A) Ctor() {}

func (t *A_arbace_box_elf_eval581000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_eval581000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_eval581000008_A_class }

func (t *A_arbace_box_elf_eval581000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_eval581000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_elf_eval581000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_eval581000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_eval581000008_A); return ok }

func A_arbace_box_elf_eval581000008_A_Cast(x any) *A_arbace_box_elf_eval581000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_eval581000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_eval581000008_A_class)) }; return v }



type A_arbace_box_elf_eval581000008_fn__581000009_A struct{ j2g_header uint64 }

var A_arbace_box_elf_eval581000008_fn__581000009_A_fn_class *jrt.Class



type A_arbace_box_elf_fail_A struct{ j2g_header uint64 }

var A_arbace_box_elf_fail_A_fn_class *jrt.Class



type A_arbace_box_elf_le_A struct{ j2g_header uint64 }

var A_arbace_box_elf_le_A_fn_class *jrt.Class
