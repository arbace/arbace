//line aot_arbace_box_elf.ae:1
package aot_arbace_box_elf

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :3:1
func A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_New() *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) Ctor() {}
//line :3:1
func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_elf_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_box_elf_A_const_1); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_20)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_21)); var tmp6 *lang.Var; lang.RT_Init(); tmp6 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp6).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_22)); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_23)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp8 != nil { panic(tmp8) }; return tmp3 }
//line :3:1
func A_arbace_box_elf_eval581000008_fn__581000009_A_New() *A_arbace_box_elf_eval581000008_fn__581000009_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_eval581000008_fn__581000009_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) Ctor() {}
//line :3:1
func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_box_elf_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_box_elf_A_const_6), A_arbace_box_elf_A_const_4.GetRawRoot__O(), A_arbace_box_elf_A_const_5) }











func A_arbace_box_elf_fail_A_New() *A_arbace_box_elf_fail_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_fail_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_box_elf_fail_A) Ctor() {}
//line :15:1
func (t *A_arbace_box_elf_fail_A) Invoke_O_O__O(self, msg__0 any) any { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_box_elf_A_const_7.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, msg__0)).Ref(), A_arbace_box_elf_A_const_8)))) }







func A_arbace_box_elf_le_A_New() *A_arbace_box_elf_le_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_le_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_box_elf_le_A) Ctor() {}
//line :23:1
func (t *A_arbace_box_elf_le_A) Invoke_O_O__O(self, b__0 any) any {
	var tmp1 jrt.ByteBuffer_I = jrt.ByteBuffer_Wrap_B1__ByteBuffer(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())); var tmp2 *jrt.ByteOrder; jrt.ByteOrder_Init(); tmp2 = jrt.ByteOrder_LITTLE_ENDIAN; return tmp1.Order_ByteOrder__ByteBuffer(tmp2)
}
func A_arbace_box_elf_c_string_A_New() *A_arbace_box_elf_c_string_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_c_string_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_box_elf_c_string_A) Ctor() {}
//line :26:1
func (t *A_arbace_box_elf_c_string_A) Invoke_O_O_O__O(self, b__0, p_off__1 any) any { { var off__1 int64 = lang.RT_LongCast_O__J(p_off__1); var e__3 int64 = off__1; L1: for {

	if lang.Numbers_IsZero_J__Z(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(e__3))).Ref())) { return jrt.String_New_B1_I_I_Charset(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(off__1), lang.RT_IntCast_J__I(lang.Numbers_Minus_J_J__J(e__3, off__1)), jrt.StandardCharsets_UTF_8) } else {

		e__3 = lang.Numbers_Inc_J__J(e__3); continue L1 } } }; /*line :26:1*/panic("j2g: unreachable") }





func A_arbace_box_elf_align_A_New() *A_arbace_box_elf_align_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_align_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_box_elf_align_A) Ctor() {}
//line :32:1
func (t *A_arbace_box_elf_align_A) Invoke_O_O_O__O(self, o__0, p_a__1 any) any { var a__1 int64 = lang.RT_LongCast_O__J(p_a__1); if
										lang.Numbers_Gt_J_J__Z(a__1, 1) { L1: for {
											if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_9.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_O__Z(lang.IFn_Cast(A_arbace_box_elf_A_const_10.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.ByteArrayOutputStream_Cast(o__0)).Size__I()).Ref(), jrt.Long_ValueOf_J__Long(a__1).Ref()))).Ref())) {
												jrt.NN(jrt.ByteArrayOutputStream_Cast(o__0)).Write_I__V(lang.RT_IntCast_J__I(0))
//line :34:1
			continue L1 }
//line :33:1
		break L1 } }; return o__0 }




func A_arbace_box_elf_cut_symbols_A_New() *A_arbace_box_elf_cut_symbols_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_box_elf_cut_symbols_A) Ctor() {}
//line :38:1
func (t *A_arbace_box_elf_cut_symbols_A) Invoke_O_O_O__O(self, data__0, names__1 any) any { var b__3 any = lang.IFn_Cast(A_arbace_box_elf_A_const_11.GetRawRoot__O()).Invoke_O__O(data__0); var tmp1 bool; var and__1927000168__auto____4 bool = lang.Numbers_Gt_J_J__Z(int64(lang.RT_Alength_B1__I(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()))), 64); if and__1927000168__auto____4 {



	var and__1927000168__auto____5 bool = lang.Util_Equiv_J_J__Z(127, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(0))).Ref())); if and__1927000168__auto____5 { var and__1927000168__auto____6 bool = lang.Util_Equiv_J_J__Z(2, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(4))).Ref())); if and__1927000168__auto____6 { tmp1 = lang.Util_Equiv_J_J__Z(1, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(5))).Ref())) } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if tmp1 { } else {
		lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_1) }; var phoff__4 int64 = /*line :38:1*/jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_J__I(32)); var shoff__5 int64 = jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_J__I(40)); var phentsize__6 int64 = lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Short_ValueOf_S__Short(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I(54))).Ref()), 65535); var phnum__7 int64 = lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Short_ValueOf_S__Short(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I(56))).Ref()), 65535); var shentsize__8 int64 = lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Short_ValueOf_S__Short(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I(58))).Ref()), 65535); var shnum__9 int64 = lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Short_ValueOf_S__Short(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I(60))).Ref()), 65535); var shstrndx__10 int64 = lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Short_ValueOf_S__Short(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I(62))).Ref()), 65535); var sec__11 any; var tmp2 any = A_arbace_box_elf_cut_symbols_sec__581000018_A_New_J_J_O(shentsize__8, shoff__5, b__3); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class; if









	fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; sec__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var secs__12 any = /*line :38:1*/lang.IFn_Cast(A_arbace_box_elf_A_const_18.GetRawRoot__O()).Invoke_O_O__O(sec__11, lang.IFn_Cast(A_arbace_box_elf_A_const_39.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(shnum__9).Ref())); var symtab__13 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_40.GetRawRoot__O()); var tmp6 any = A_arbace_box_elf_cut_symbols_fn__581000020_A_New(); var tmp7 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class; if














	fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class = fncls__4d; tmp7 = fncls__4d } else { tmp7 = fncls__4 }; symtab__13 = tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), secs__12)); var strtab__14 any; if
	jrt.J2g_Truth(symtab__13) { var tmp8 *lang.Keyword = A_arbace_box_elf_A_const_15; strtab__14 = tmp8.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(symtab__13)) } else { strtab__14 = nil }; var tmp9 bool; var or__1927000174__auto____15 bool =
	lang.Util_Identical_O_O__Z(symtab__13, nil); if or__1927000174__auto____15 { tmp9 = or__1927000174__auto____15 } else { var or__1927000174__auto____16 bool = lang.Numbers_Lte_O_J__Z(strtab__14, 0); if or__1927000174__auto____16 { tmp9 = or__1927000174__auto____16 } else { var or__1927000174__auto____17 bool = lang.Numbers_Gte_O_J__Z(strtab__14, shnum__9); if or__1927000174__auto____17 { tmp9 = or__1927000174__auto____17 } else { var or__1927000174__auto____18 bool = lang.Numbers_Lte_J_J__Z(shstrndx__10, 0); if or__1927000174__auto____18 { tmp9 = or__1927000174__auto____18 } else { tmp9 = lang.Numbers_Gte_J_J__Z(shstrndx__10, shnum__9) } } } }; if tmp9 {
		lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_4) }; var tail__15 any; var tmp10 lang.IFn = /*line :38:1*/lang.IFn_Cast(A_arbace_box_elf_A_const_20.GetRawRoot__O()); var tmp11 any = A_arbace_box_elf_cut_symbols_fn__581000022_A_New_O(secs__12); var tmp12 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class; if


















	fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class = fncls__5d; tmp12 = fncls__5d } else { tmp12 = fncls__5 }; tail__15 = tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), lang.Tuple_Create_O_O_O__IPersistentVector(symtab__13, strtab__14, jrt.Long_ValueOf_J__Long(shstrndx__10).Ref())); var tmp13 /*line :38:1*/*lang.Keyword = A_arbace_box_elf_A_const_13; var start__16 any = tmp13.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(tail__15))); if




















	lang.Numbers_Gt_J_O__Z(lang.Numbers_Add_J_J__J(shoff__5, lang.Numbers_Multiply_J_J__J(shnum__9, shentsize__8)), start__16) {
		lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_6) }; var seq_581000024__17 any = /*line :38:1*/lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_elf_A_const_43.GetRawRoot__O(), secs__12)); var chunk_581000025__18 any; var count_581000026__19 int64 = 0; var i_581000027__20 int64 = 0; L1: for {






















			if lang.Numbers_Lt_J_J__Z(i_581000027__20, count_581000026__19) { var vec__581000028__21 any = lang.Indexed_Cast(chunk_581000025__18).Nth_I__O(lang.RT_IntCast_J__I(i_581000027__20)); var i__22 any = lang.RT_Nth_O_I_O__O(vec__581000028__21, lang.RT_IntCast_J__I(0), nil); var s__23 any = lang.RT_Nth_O_I_O__O(vec__581000028__21, lang.RT_IntCast_J__I(1), nil); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_9.GetRawRoot__O()); var tmp15 any; var or__1927000174__auto____24 any = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, strtab__14, symtab__13, jrt.Long_ValueOf_J__Long(shstrndx__10).Ref()))).Invoke_O__O(i__22)
				if jrt.J2g_Truth(or__1927000174__auto____24) { tmp15 = or__1927000174__auto____24 } else { tmp15 = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_44.GetRawRoot__O(), A_arbace_box_elf_A_const_45.GetRawRoot__O()))).Invoke_O__O(A_arbace_box_elf_A_const_12.Invoke_O__O(s__23)) }
//line :61:1
				if jrt.J2g_Truth(tmp14.Invoke_O__O(tmp15)) {

					if lang.Numbers_Gt_O_O__Z(lang.Numbers_Add_O_O__Number(A_arbace_box_elf_A_const_13.Invoke_O__O(s__23), A_arbace_box_elf_A_const_14.Invoke_O__O(s__23)), start__16) {
						lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_7) }
//line :61:1
					seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = seq_581000024__17, chunk_581000025__18, count_581000026__19, lang.Numbers_Unchecked_inc_J__J(i_581000027__20); continue L1 } else { seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = seq_581000024__17, chunk_581000025__18, count_581000026__19, lang.Numbers_Unchecked_inc_J__J(i_581000027__20); continue L1 } } else { var temp__1927000414__auto____21 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_581000024__17); if jrt.J2g_Truth(temp__1927000414__auto____21) { var seq_581000024__22 any = temp__1927000414__auto____21; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_581000024__22)) { var c__1927000678__auto____23 any = lang.IFn_Cast(A_arbace_box_elf_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_581000024__22); seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = lang.IFn_Cast(A_arbace_box_elf_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_581000024__22), c__1927000678__auto____23, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__581000031__23 any = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_581000024__22); var i__24 any = lang.RT_Nth_O_I_O__O(vec__581000031__23, lang.RT_IntCast_J__I(0), nil); var s__25 any = lang.RT_Nth_O_I_O__O(vec__581000031__23, lang.RT_IntCast_J__I(1), nil); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_9.GetRawRoot__O()); var tmp17 any; var or__1927000174__auto____26 any = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, strtab__14, symtab__13, jrt.Long_ValueOf_J__Long(shstrndx__10).Ref()))).Invoke_O__O(i__24)
						if jrt.J2g_Truth(or__1927000174__auto____26) { tmp17 = or__1927000174__auto____26 } else { tmp17 = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_44.GetRawRoot__O(), A_arbace_box_elf_A_const_45.GetRawRoot__O()))).Invoke_O__O(A_arbace_box_elf_A_const_12.Invoke_O__O(s__25)) }
//line :61:1
						if jrt.J2g_Truth(tmp16.Invoke_O__O(tmp17)) {

							if lang.Numbers_Gt_O_O__Z(lang.Numbers_Add_O_O__Number(A_arbace_box_elf_A_const_13.Invoke_O__O(s__25), A_arbace_box_elf_A_const_14.Invoke_O__O(s__25)), start__16) {
								lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_7) }
//line :61:1
							seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_581000024__22), nil, 0, 0; continue L1 } else { seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_581000024__22), nil, 0, 0; continue L1 } } } }
//line :38:1
			break L1 }; var seq_581000034__17 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_39.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(phnum__7).Ref())); var chunk_581000035__18 any; var count_581000036__19 int64 = 0; var i_581000037__20 int64 = 0; L2: for {


























				if lang.Numbers_Lt_J_J__Z(i_581000037__20, count_581000036__19) { var i__21 any = lang.Indexed_Cast(chunk_581000035__18).Nth_I__O(lang.RT_IntCast_J__I(i_581000037__20)); var h__22 any = lang.Numbers_Add_J_O__Number(phoff__4, lang.Numbers_Multiply_O_J__Number(i__21, phentsize__6))

					if lang.Numbers_Gt_J_O__Z(lang.Numbers_Add_J_J__J(jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__22, 8))), jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__22, 32)))), start__16) {
						lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_8) }
//line :65:1
					seq_581000034__17, chunk_581000035__18, count_581000036__19, i_581000037__20 = seq_581000034__17, chunk_581000035__18, count_581000036__19, lang.Numbers_Unchecked_inc_J__J(i_581000037__20); continue L2 } else { var temp__1927000414__auto____21_2 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_581000034__17); if jrt.J2g_Truth(temp__1927000414__auto____21_2) { var seq_581000034__22 any = temp__1927000414__auto____21_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_581000034__22)) { var c__1927000678__auto____23_2 any = lang.IFn_Cast(A_arbace_box_elf_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_581000034__22); seq_581000034__17, chunk_581000035__18, count_581000036__19, i_581000037__20 = lang.IFn_Cast(A_arbace_box_elf_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_581000034__22), c__1927000678__auto____23_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____23_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var i__23 any = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_581000034__22); var h__24 any = lang.Numbers_Add_J_O__Number(phoff__4, lang.Numbers_Multiply_O_J__Number(i__23, phentsize__6))

						if lang.Numbers_Gt_J_O__Z(lang.Numbers_Add_J_J__J(jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__24, 8))), jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__24, 32)))), start__16) {
							lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_8) }
//line :65:1
						seq_581000034__17, chunk_581000035__18, count_581000036__19, i_581000037__20 = lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_581000034__22), nil, 0, 0; continue L2 } } }
//line :38:1
				break L2 }; var l__17 any = lang.IFn_Cast(secs__12).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_46.GetRawRoot__O()).Invoke_O__O(tail__15)); if































	lang.Util_Equiv_O_J__Z(lang.Numbers_Add_O_O__Number(A_arbace_box_elf_A_const_13.Invoke_O__O(l__17), A_arbace_box_elf_A_const_14.Invoke_O__O(l__17)), int64(lang.RT_Alength_B1__I(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass())))) { } else {
		lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_9) }; var st__17 any = /*line :38:1*/lang.IFn_Cast(secs__12).Invoke_O__O(symtab__13); var tmp18 *lang.Keyword = A_arbace_box_elf_A_const_13; var strs__18 any = tmp18.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(strtab__14)); var n__19 any = lang.Numbers_Quotient_O_J__Number(A_arbace_box_elf_A_const_14.Invoke_O__O(st__17), 24); var want__20 any = lang.IFn_Cast(A_arbace_box_elf_A_const_21.GetRawRoot__O()).Invoke_O__O(names__1); var kept__21 any; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_22.GetRawRoot__O()); var tmp20 any; var iter__1927001039__auto____21 any; var tmp21 any = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_New_O_O_O_O_O(data__0, st__17, strs__18, want__20, b__3); var tmp22 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class; if





































	fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class = fncls__8d; tmp22 = fncls__8d } else { tmp22 = fncls__8 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); tmp20 = lang.IFn_Cast(iter__1927001039__auto____21).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_elf_A_const_54, n__19)); kept__21 = tmp19.Invoke_O__O(tmp20); var ___22 any; var tmp23 any = /*line :38:1*/A_arbace_box_elf_cut_symbols_fn__581000052_A_New_O_O(kept__21, data__0); var tmp24 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class; _ = ___22; if










































	fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class = fncls__2d; tmp24 = fncls__2d } else { tmp24 = fncls__2 }; ___22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil).Invoke__O(); var missing__23 any = /*line :38:1*/lang.IFn_Cast(A_arbace_box_elf_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_55.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_56.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_elf_A_const_26, kept__21)), want__20)); var ___24 any; _ = ___24; if














































	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(missing__23)) { ___24 = lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_elf_A_const_22.GetRawRoot__O()).Invoke_O__O(missing__23))).Ref()) } else { ___24 = nil }; var kept__25 any; var tmp25 lang.IFn = /*line :38:1*/lang.IFn_Cast(A_arbace_box_elf_A_const_34.GetRawRoot__O()); var tmp26 any = A_arbace_box_elf_cut_symbols_fn__581000058_A_New(); var tmp27 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class; if
















































	fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_13, false); A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class = fncls__10d; tmp27 = fncls__10d } else { tmp27 = fncls__10 }; var tmp28 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); var tmp29 *lang.PersistentVector; lang.PersistentVector_Init(); tmp29 = lang.PersistentVector_EMPTY; kept__25 = tmp25.Invoke_O_O_O__O(tmp28, tmp29.Ref(), kept__21); var strb__26 any = /*line :38:1*/jrt.ByteArrayOutputStream_New(); var symb__27 any = jrt.ByteArrayOutputStream_New();



















































	jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Write_I__V(lang.RT_IntCast_J__I(0));
	jrt.OutputStream_Cast(symb__27).Write_B1__V(lang.Numbers_Byte_array_O__B1(A_arbace_box_elf_A_const_58)); var seq_581000062__28 any = /*line :38:1*/lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(kept__25); var chunk_581000063__29 any; var count_581000064__30 int64 = 0; var i_581000065__31 int64 = 0; L3: for {





















































		if lang.Numbers_Lt_J_J__Z(i_581000065__31, count_581000064__30) { var map__581000066__32 any = lang.Indexed_Cast(chunk_581000063__29).Nth_I__O(lang.RT_IntCast_J__I(i_581000065__31)); var map__581000066__33 any; if lang.ISeq_InstanceOf(map__581000066__32) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(map__581000066__32)) { map__581000066__33 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_box_elf_A_const_25.GetRawRoot__O()).Invoke_O__O(map__581000066__32), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(map__581000066__32)) { map__581000066__33 = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(map__581000066__32) } else { lang.PersistentArrayMap_Init(); map__581000066__33 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000066__33 = map__581000066__32 }; var name__34 any = lang.RT_Get_O_O__O(map__581000066__33, A_arbace_box_elf_A_const_26); var entry__35 any = lang.RT_Get_O_O__O(map__581000066__33, A_arbace_box_elf_A_const_27); var e__36 any = lang.Numbers_Byte_array_O__B1(A_arbace_box_elf_A_const_58).Ref(); var eb__37 any = lang.IFn_Cast(A_arbace_box_elf_A_const_11.GetRawRoot__O()).Invoke_O__O(e__36)


			jrt.System_Arraycopy_O_I_O_I_I__V(data__0, lang.RT_IntCast_O__I(entry__35), e__36, lang.RT_IntCast_J__I(0), lang.RT_IntCast_J__I(24))
			jrt.ByteBuffer_Cast(eb__37).PutInt_I_I__ByteBuffer(lang.RT_IntCast_J__I(0), lang.RT_IntCast_I__I(jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Size__I()))
			jrt.OutputStream_Cast(symb__27).Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](e__36, jrt.Prim_byte.ArrayClass()))
			jrt.OutputStream_Cast(strb__26).Write_B1__V(jrt.NN(jrt.String_Cast(name__34)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8))
			jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Write_I__V(lang.RT_IntCast_J__I(0))
//line :92:1
			seq_581000062__28, chunk_581000063__29, count_581000064__30, i_581000065__31 = seq_581000062__28, chunk_581000063__29, count_581000064__30, lang.Numbers_Unchecked_inc_J__J(i_581000065__31); continue L3 } else { var temp__1927000414__auto____32 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_581000062__28); if jrt.J2g_Truth(temp__1927000414__auto____32) { var seq_581000062__33 any = temp__1927000414__auto____32; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_581000062__33)) { var c__1927000678__auto____34 any = lang.IFn_Cast(A_arbace_box_elf_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_581000062__33); seq_581000062__28, chunk_581000063__29, count_581000064__30, i_581000065__31 = lang.IFn_Cast(A_arbace_box_elf_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_581000062__33), c__1927000678__auto____34, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____34))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var map__581000068__34 any = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_581000062__33); var map__581000068__35 any; if lang.ISeq_InstanceOf(map__581000068__34) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(map__581000068__34)) { map__581000068__35 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_box_elf_A_const_25.GetRawRoot__O()).Invoke_O__O(map__581000068__34), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(map__581000068__34)) { map__581000068__35 = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(map__581000068__34) } else { lang.PersistentArrayMap_Init(); map__581000068__35 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000068__35 = map__581000068__34 }; var name__36 any = lang.RT_Get_O_O__O(map__581000068__35, A_arbace_box_elf_A_const_26); var entry__37 any = lang.RT_Get_O_O__O(map__581000068__35, A_arbace_box_elf_A_const_27); var e__38 any = lang.Numbers_Byte_array_O__B1(A_arbace_box_elf_A_const_58).Ref(); var eb__39 any = lang.IFn_Cast(A_arbace_box_elf_A_const_11.GetRawRoot__O()).Invoke_O__O(e__38)


				jrt.System_Arraycopy_O_I_O_I_I__V(data__0, lang.RT_IntCast_O__I(entry__37), e__38, lang.RT_IntCast_J__I(0), lang.RT_IntCast_J__I(24))
				jrt.ByteBuffer_Cast(eb__39).PutInt_I_I__ByteBuffer(lang.RT_IntCast_J__I(0), lang.RT_IntCast_I__I(jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Size__I()))
				jrt.OutputStream_Cast(symb__27).Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](e__38, jrt.Prim_byte.ArrayClass()))
				jrt.OutputStream_Cast(strb__26).Write_B1__V(jrt.NN(jrt.String_Cast(name__36)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8))
				jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Write_I__V(lang.RT_IntCast_J__I(0))
//line :92:1
				seq_581000062__28, chunk_581000063__29, count_581000064__30, i_581000065__31 = lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_581000062__33), nil, 0, 0; continue L3 } } }
//line :38:1
		break L3 }; var o__28 any = jrt.ByteArrayOutputStream_New(); var ___29 any; _ = ___29;






























































	jrt.NN(jrt.ByteArrayOutputStream_Cast(o__28)).Write_B1_I_I__V(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(0), lang.RT_IntCast_O__I(start__16)); ___29 = nil; var tmp30 /*line :38:1*/*lang.Keyword = A_arbace_box_elf_A_const_13; var tmp31 *lang.Keyword = A_arbace_box_elf_A_const_13; var tmp32 *lang.Keyword = A_arbace_box_elf_A_const_14; var shstr__30 any = jrt.Arrays_CopyOfRange_B1_I_I__B1(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_O__I(tmp30.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long(shstrndx__10).Ref()))), lang.RT_IntCast_O__I(lang.Numbers_Add_O_O__Number(tmp31.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long(shstrndx__10).Ref())), tmp32.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long(shstrndx__10).Ref()))))).Ref(); var places__31 any; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_35.GetRawRoot__O()); var tmp34 *lang.PersistentArrayMap;
































































	lang.PersistentArrayMap_Init(); tmp34 = lang.PersistentArrayMap_EMPTY; places__31 = tmp33.Invoke_O__O(tmp34.Ref()); var place__32 any; var tmp35 any = /*line :38:1*/A_arbace_box_elf_cut_symbols_place__581000070_A_New_O_O_O(places__31, o__28, secs__12); var tmp36 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class; if

































































	fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class = fncls__3d; tmp36 = fncls__3d } else { tmp36 = fncls__3 }; place__32 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil);



	lang.IFn_Cast(place__32).Invoke_O_O__O(symtab__13, jrt.NN(jrt.ByteArrayOutputStream_Cast(symb__27)).ToByteArray__B1().Ref());
	lang.IFn_Cast(place__32).Invoke_O_O__O(strtab__14, jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).ToByteArray__B1().Ref());
	lang.IFn_Cast(place__32).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(shstrndx__10).Ref(), shstr__30); var out__33 any = /*line :38:1*/jrt.NN(jrt.ByteArrayOutputStream_Cast(o__28)).ToByteArray__B1().Ref(); var ob__34 any = lang.IFn_Cast(A_arbace_box_elf_A_const_11.GetRawRoot__O()).Invoke_O__O(out__33); var seq_581000072__35 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_3.GetRawRoot__O()).Invoke_O__O(places__31)); var chunk_581000073__36 any; var count_581000074__37 int64 = 0; var i_581000075__38 int64 = 0; L4: for {










































































		if lang.Numbers_Lt_J_J__Z(i_581000075__38, count_581000074__37) { var vec__581000076__39 any = lang.Indexed_Cast(chunk_581000073__36).Nth_I__O(lang.RT_IntCast_J__I(i_581000075__38)); var i__40 any = lang.RT_Nth_O_I_O__O(vec__581000076__39, lang.RT_IntCast_J__I(0), nil); var vec__581000079__41 any = lang.RT_Nth_O_I_O__O(vec__581000076__39, lang.RT_IntCast_J__I(1), nil); var off__42 any = lang.RT_Nth_O_I_O__O(vec__581000079__41, lang.RT_IntCast_J__I(0), nil); var size__43 any = lang.RT_Nth_O_I_O__O(vec__581000079__41, lang.RT_IntCast_J__I(1), nil); var h__44 any = lang.Numbers_Add_J_O__Number(shoff__5, lang.Numbers_Multiply_O_J__Number(i__40, shentsize__8))

			jrt.ByteBuffer_Cast(ob__34).PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__44, 24)), lang.RT_LongCast_O__J(off__42))
			jrt.ByteBuffer_Cast(ob__34).PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__44, 32)), lang.RT_LongCast_O__J(size__43))
//line :113:1
			seq_581000072__35, chunk_581000073__36, count_581000074__37, i_581000075__38 = seq_581000072__35, chunk_581000073__36, count_581000074__37, lang.Numbers_Unchecked_inc_J__J(i_581000075__38); continue L4 } else { var temp__1927000414__auto____39 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_581000072__35); if jrt.J2g_Truth(temp__1927000414__auto____39) { var seq_581000072__40 any = temp__1927000414__auto____39; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_581000072__40)) { var c__1927000678__auto____41 any = lang.IFn_Cast(A_arbace_box_elf_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_581000072__40); seq_581000072__35, chunk_581000073__36, count_581000074__37, i_581000075__38 = lang.IFn_Cast(A_arbace_box_elf_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_581000072__40), c__1927000678__auto____41, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____41))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var vec__581000082__41 any = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_581000072__40); var i__42 any = lang.RT_Nth_O_I_O__O(vec__581000082__41, lang.RT_IntCast_J__I(0), nil); var vec__581000085__43 any = lang.RT_Nth_O_I_O__O(vec__581000082__41, lang.RT_IntCast_J__I(1), nil); var off__44 any = lang.RT_Nth_O_I_O__O(vec__581000085__43, lang.RT_IntCast_J__I(0), nil); var size__45 any = lang.RT_Nth_O_I_O__O(vec__581000085__43, lang.RT_IntCast_J__I(1), nil); var h__46 any = lang.Numbers_Add_J_O__Number(shoff__5, lang.Numbers_Multiply_O_J__Number(i__42, shentsize__8))

				jrt.ByteBuffer_Cast(ob__34).PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__46, 24)), lang.RT_LongCast_O__J(off__44))
				jrt.ByteBuffer_Cast(ob__34).PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__46, 32)), lang.RT_LongCast_O__J(size__45))
//line :113:1
				seq_581000072__35, chunk_581000073__36, count_581000074__37, i_581000075__38 = lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_581000072__40), nil, 0, 0; continue L4 } } }
//line :38:1
		break L4 };















































































	jrt.ByteBuffer_Cast(ob__34).PutInt_I_I__ByteBuffer(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(lang.Numbers_Add_J_O__Number(shoff__5, lang.Numbers_Multiply_O_J__Number(symtab__13, shentsize__8)), 44)), lang.RT_IntCast_J__I(1)); return out__33 }
//line :48:1
func A_arbace_box_elf_cut_symbols_sec__581000018_A_New_J_J_O(p0, p1 int64, p2 any) *A_arbace_box_elf_cut_symbols_sec__581000018_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_sec__581000018_A{}; t.Ctor_J_J_O(p0, p1, p2); return t }
//line :48:1
func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) Ctor_J_J_O(c__shentsize, c__shoff int64, c__b any) { t.F_shentsize = c__shentsize; t.F_shoff = c__shoff; t.F_b = c__b }
//line :48:1
func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 int64 = t.F_shoff; var h__2 any = lang.Numbers_Add_J_O__Number(tmp1, lang.Numbers_Multiply_O_J__Number(i__1, t.F_shentsize)); var tmp2 any = A_arbace_box_elf_A_const_12; var tmp3 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp4 any = jrt.Integer_ValueOf_I__Integer(tmp3.GetInt_I__I(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__2, 4)))).Ref(); var tmp5 any = A_arbace_box_elf_A_const_13; var tmp6 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp7 any = jrt.Long_ValueOf_J__Long(tmp6.GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__2, 24)))).Ref(); var tmp8 any = A_arbace_box_elf_A_const_14; var tmp9 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp10 any = jrt.Long_ValueOf_J__Long(tmp9.GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__2, 32)))).Ref(); var tmp11 any = A_arbace_box_elf_A_const_15; var tmp12 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp13 any = jrt.Integer_ValueOf_I__Integer(tmp12.GetInt_I__I(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__2, 40)))).Ref(); var tmp14 any = A_arbace_box_elf_A_const_16; var tmp15 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp16 any = jrt.Long_ValueOf_J__Long(tmp15.GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__2, 48)))).Ref(); var tmp17 any = A_arbace_box_elf_A_const_17; var tmp18 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp4, tmp5, tmp7, tmp8, tmp10, tmp11, tmp13, tmp14, tmp16, tmp17, jrt.Long_ValueOf_J__Long(tmp18.GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__2, 56)))).Ref())) }




func A_arbace_box_elf_cut_symbols_fn__581000020_A_New() *A_arbace_box_elf_cut_symbols_fn__581000020_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000020_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) Ctor() {}
//line :53:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) Invoke_O_O_O__O(self, i__1, s__2 any) any { if lang.Util_Equiv_O_O__Z(A_arbace_box_elf_A_const_41.GetRawRoot__O(), A_arbace_box_elf_A_const_12.Invoke_O__O(s__2)) { return i__1 } else { return nil } }



func A_arbace_box_elf_cut_symbols_fn__581000022_A_New_O(p0 any) *A_arbace_box_elf_cut_symbols_fn__581000022_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000022_A{}; t.Ctor_O(p0); return t }
//line :57:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) Ctor_O(c__secs any) { t.F_secs = c__secs }
//line :57:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) Invoke_O_O__O(self, p1__581000016_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_box_elf_A_const_13; return tmp1.Invoke_O__O(lang.IFn_Cast(t.F_secs).Invoke_O__O(p1__581000016_SHARP___1)) }


















func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) Ctor_O_O_O_O_O(c__data, c__st, c__strs, c__want, c__b any) { t.F_data = c__data; t.F_st = c__st; t.F_strs = c__strs; t.F_want = c__want; t.F_b = c__b }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) Invoke_O_O__O(self, s__581000039__1 any) any { var tmp1 any = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_New_O_O_O_O_O_O_O(s__581000039__1, t.F_data, t.F_st, t.F_strs, self, t.F_want, t.F_b); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :76:1
func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) Ctor_O_O_O_O_O_O_O(c__s__581000039, c__data, c__st, c__strs, c__iter__581000038, c__want, c__b any) { t.F_s__581000039 = c__s__581000039; t.F_data = c__data; t.F_st = c__st; t.F_strs = c__strs; t.F_iter__581000038 = c__iter__581000038; t.F_want = c__want; t.F_b = c__b }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) Invoke_O__O(self any) any { { var s__581000039__1 any; var t_ any = t.F_s__581000039; t.F_s__581000039 = nil; s__581000039__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(s__581000039__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__581000039__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_28.GetRawRoot__O()).Invoke_O__O(s__581000039__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_elf_A_const_29.GetRawRoot__O()).Invoke_O__O(s__581000039__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__581000041__6 any = lang.IFn_Cast(A_arbace_box_elf_A_const_47.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_New_O_O_O_O_O_I_O_O(b__581000041__6, t.F_data, t.F_st, t.F_strs, t.F_want, size__1927001038__auto____5, c__1927001037__auto____4, t.F_b); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__581000038); return lang.IFn_Cast(A_arbace_box_elf_A_const_50.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_52.GetRawRoot__O()).Invoke_O__O(b__581000041__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_32.GetRawRoot__O()).Invoke_O__O(s__581000039__3))) } else { return lang.IFn_Cast(A_arbace_box_elf_A_const_50.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_52.GetRawRoot__O()).Invoke_O__O(b__581000041__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(s__581000039__3); var e__5 any = lang.Numbers_Add_O_O__Number(A_arbace_box_elf_A_const_13.Invoke_O__O(t.F_st), lang.Numbers_Multiply_J_O__Number(24, i__4)); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_48.GetRawRoot__O()); var tmp5 any = t.F_data; var tmp6 any = t.F_strs; var tmp7 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var nm__6 any = tmp4.Invoke_O_O__O(tmp5, lang.Numbers_Add_O_J__Number(tmp6, lang.Numbers_And_J_J__J(int64(tmp7.GetInt_I__I(lang.RT_IntCast_O__I(e__5))), 4294967295))); if jrt.J2g_Truth(lang.IFn_Cast(t.F_want).Invoke_O__O(nm__6)) { var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__581000038); return lang.IFn_Cast(A_arbace_box_elf_A_const_51.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_26, nm__6, A_arbace_box_elf_A_const_27, e__5)), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_53.GetRawRoot__O()).Invoke_O__O(s__581000039__3))) } else { s__581000039__1 = lang.IFn_Cast(A_arbace_box_elf_A_const_53.GetRawRoot__O()).Invoke_O__O(s__581000039__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :76:1
func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_New_O_O_O_O_O_I_O_O(p0, p1, p2, p3, p4 any, p5 int32, p6, p7 any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A{}; t.Ctor_O_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) Ctor_O_O_O_O_O_I_O_O(c__b__581000041, c__data, c__st, c__strs, c__want any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b any) { t.F_b__581000041 = c__b__581000041; t.F_data = c__data; t.F_st = c__st; t.F_strs = c__strs; t.F_want = c__want; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b = c__b }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) Invoke_O__O(self any) any { { var i__581000040__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__581000040__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__581000040__1)); var e__3 any = lang.Numbers_Add_O_O__Number(A_arbace_box_elf_A_const_13.Invoke_O__O(t.F_st), lang.Numbers_Multiply_J_O__Number(24, i__2)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_48.GetRawRoot__O()); var tmp3 any = t.F_data; var tmp4 any = t.F_strs; var tmp5 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var nm__4 any = tmp2.Invoke_O_O__O(tmp3, lang.Numbers_Add_O_J__Number(tmp4, lang.Numbers_And_J_J__J(int64(tmp5.GetInt_I__I(lang.RT_IntCast_O__I(e__3))), 4294967295))); if jrt.J2g_Truth(lang.IFn_Cast(t.F_want).Invoke_O__O(nm__4)) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_49.GetRawRoot__O()); var tmp7 any = t.F_b__581000041; tmp6.Invoke_O_O__O(tmp7, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_26, nm__4, A_arbace_box_elf_A_const_27, e__3))); i__581000040__1 = lang.Numbers_Unchecked_inc_J__J(i__581000040__1); continue L1 } else { i__581000040__1 = lang.Numbers_Unchecked_inc_J__J(i__581000040__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_box_elf_cut_symbols_fn__581000052_A_New_O_O(p0, p1 any) *A_arbace_box_elf_cut_symbols_fn__581000052_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000052_A{}; t.Ctor_O_O(p0, p1); return t }
//line :81:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) Ctor_O_O(c__kept, c__data any) { t.F_kept = c__kept; t.F_data = c__data }
//line :81:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) Invoke_O__O(self any) any { { var seq_581000048__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_kept; t.F_kept = nil; tmp2 = t_; seq_581000048__1 = tmp1.Invoke_O__O(tmp2); var chunk_581000049__2 any; var count_581000050__3 int64 = 0; var i_581000051__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z(i_581000051__4, count_581000050__3) { var map__581000053__5 any = lang.Indexed_Cast(chunk_581000049__2).Nth_I__O(lang.RT_IntCast_J__I(i_581000051__4)); var map__581000053__6 any; if lang.ISeq_InstanceOf(map__581000053__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(map__581000053__5)) { map__581000053__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_box_elf_A_const_25.GetRawRoot__O()).Invoke_O__O(map__581000053__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(map__581000053__5)) { map__581000053__6 = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(map__581000053__5) } else { lang.PersistentArrayMap_Init(); map__581000053__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000053__6 = map__581000053__5 }; var name__7 any = lang.RT_Get_O_O__O(map__581000053__6, A_arbace_box_elf_A_const_26); var entry__8 any = lang.RT_Get_O_O__O(map__581000053__6, A_arbace_box_elf_A_const_27); var tmp3 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_data, jrt.Prim_byte.ArrayClass())
											if lang.Util_Equiv_O_J__Z(A_arbace_box_elf_A_const_30.GetRawRoot__O(), lang.Numbers_ShiftRight_J_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp3, lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(entry__8, 4)))).Ref()), 255), 4)) {
												lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16), jrt.RefArrayOf(jrt.Object_class, nil, name__7, nil)).Ref()) }
//line :81:1
	seq_581000048__1, chunk_581000049__2, count_581000050__3, i_581000051__4 = seq_581000048__1, chunk_581000049__2, count_581000050__3, lang.Numbers_Unchecked_inc_J__J(i_581000051__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_581000048__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_581000048__6 any = temp__1927000414__auto____5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_581000048__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_box_elf_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_581000048__6); seq_581000048__1, chunk_581000049__2, count_581000050__3, i_581000051__4 = lang.IFn_Cast(A_arbace_box_elf_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_581000048__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var map__581000055__7 any = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_581000048__6); var map__581000055__8 any; if lang.ISeq_InstanceOf(map__581000055__7) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(map__581000055__7)) { map__581000055__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_box_elf_A_const_25.GetRawRoot__O()).Invoke_O__O(map__581000055__7), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(map__581000055__7)) { map__581000055__8 = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(map__581000055__7) } else { lang.PersistentArrayMap_Init(); map__581000055__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000055__8 = map__581000055__7 }; var name__9 any = lang.RT_Get_O_O__O(map__581000055__8, A_arbace_box_elf_A_const_26); var entry__10 any = lang.RT_Get_O_O__O(map__581000055__8, A_arbace_box_elf_A_const_27); var tmp4 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_data, jrt.Prim_byte.ArrayClass())
		if lang.Util_Equiv_O_J__Z(A_arbace_box_elf_A_const_30.GetRawRoot__O(), lang.Numbers_ShiftRight_J_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp4, lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(entry__10, 4)))).Ref()), 255), 4)) {
			lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16), jrt.RefArrayOf(jrt.Object_class, nil, name__9, nil)).Ref()) }
//line :81:1
		seq_581000048__1, chunk_581000049__2, count_581000050__3, i_581000051__4 = lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_581000048__6), nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }





func A_arbace_box_elf_cut_symbols_fn__581000058_A_New() *A_arbace_box_elf_cut_symbols_fn__581000058_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000058_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) Ctor() {}
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) Invoke_O_O_O__O(self, acc__1, k__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_57.GetRawRoot__O()); var tmp2 any = A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_New_O(k__2); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; if jrt.J2g_Truth(tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), acc__1)) { return acc__1 } else { return lang.IFn_Cast(A_arbace_box_elf_A_const_4.GetRawRoot__O()).Invoke_O_O__O(acc__1, k__2) } }
//line :87:1
func A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_New_O(p0 any) *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A{}; t.Ctor_O(p0); return t }
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) Invoke_O_O__O(self, p1__581000017_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(A_arbace_box_elf_A_const_26.Invoke_O__O(t.F_k), A_arbace_box_elf_A_const_26.Invoke_O__O(p1__581000017_SHARP___1))).Ref() }
















func A_arbace_box_elf_cut_symbols_place__581000070_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_elf_cut_symbols_place__581000070_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_place__581000070_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :104:1
func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) Ctor_O_O_O(c__places, c__o, c__secs any) { t.F_places = c__places; t.F_o = c__o; t.F_secs = c__secs }
//line :104:1
func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) Invoke_O_O_O__O(self, i__1, bs__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_36.GetRawRoot__O()); var tmp2 any = t.F_o; var tmp3 *lang.Keyword = A_arbace_box_elf_A_const_16; tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O__O(lang.IFn_Cast(t.F_secs).Invoke_O__O(i__1)))
	var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_37.GetRawRoot__O()); var tmp5 any = t.F_places; tmp4.Invoke_O_O_O_O__O(tmp5, A_arbace_box_elf_A_const_38.GetRawRoot__O(), i__1, lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.ByteArrayOutputStream_Cast(t.F_o)).Size__I()).Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_Alength_B1__I(jrt.J2g_CastArray[*jrt.ByteArray](bs__2, jrt.Prim_byte.ArrayClass()))).Ref()))
	var tmp6 jrt.OutputStream_I = jrt.OutputStream_Cast(t.F_o); tmp6.Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](bs__2, jrt.Prim_byte.ArrayClass())); return nil
}











type A_arbace_box_elf_A struct{ jrt.Object }

var A_arbace_box_elf_A_const_pool *jrt.RefArray

var A_arbace_box_elf_A_const_0 *lang.Var

var A_arbace_box_elf_A_const_1 any

var A_arbace_box_elf_A_const_2 *lang.Var

var A_arbace_box_elf_A_const_3 *lang.Var

var A_arbace_box_elf_A_const_4 *lang.Var

var A_arbace_box_elf_A_const_5 any

var A_arbace_box_elf_A_const_6 *lang.Var

var A_arbace_box_elf_A_const_7 *lang.Var

var A_arbace_box_elf_A_const_8 any

var A_arbace_box_elf_A_const_9 *lang.Var

var A_arbace_box_elf_A_const_10 *lang.Var

var A_arbace_box_elf_A_const_11 *lang.Var

var A_arbace_box_elf_A_const_12 *lang.Keyword

var A_arbace_box_elf_A_const_13 *lang.Keyword

var A_arbace_box_elf_A_const_14 *lang.Keyword

var A_arbace_box_elf_A_const_15 *lang.Keyword

var A_arbace_box_elf_A_const_16 *lang.Keyword

var A_arbace_box_elf_A_const_17 *lang.Keyword

var A_arbace_box_elf_A_const_18 *lang.Var

var A_arbace_box_elf_A_const_19 *lang.Var

var A_arbace_box_elf_A_const_20 *lang.Var

var A_arbace_box_elf_A_const_21 *lang.Var

var A_arbace_box_elf_A_const_22 *lang.Var

var A_arbace_box_elf_A_const_23 *lang.Var

var A_arbace_box_elf_A_const_24 *lang.Var

var A_arbace_box_elf_A_const_25 *lang.Var

var A_arbace_box_elf_A_const_26 *lang.Keyword

var A_arbace_box_elf_A_const_27 *lang.Keyword

var A_arbace_box_elf_A_const_28 *lang.Var

var A_arbace_box_elf_A_const_29 *lang.Var

var A_arbace_box_elf_A_const_30 *lang.Var

var A_arbace_box_elf_A_const_31 *lang.Var

var A_arbace_box_elf_A_const_32 *lang.Var

var A_arbace_box_elf_A_const_33 *lang.Var

var A_arbace_box_elf_A_const_34 *lang.Var

var A_arbace_box_elf_A_const_35 *lang.Var

var A_arbace_box_elf_A_const_36 *lang.Var

var A_arbace_box_elf_A_const_37 *lang.Var

var A_arbace_box_elf_A_const_38 *lang.Var

var A_arbace_box_elf_A_const_39 *lang.Var

var A_arbace_box_elf_A_const_40 *lang.Var

var A_arbace_box_elf_A_const_41 *lang.Var

var A_arbace_box_elf_A_const_42 *lang.Var

var A_arbace_box_elf_A_const_43 *lang.Var

var A_arbace_box_elf_A_const_44 *lang.Var

var A_arbace_box_elf_A_const_45 *lang.Var

var A_arbace_box_elf_A_const_46 *lang.Var

var A_arbace_box_elf_A_const_47 *lang.Var

var A_arbace_box_elf_A_const_48 *lang.Var

var A_arbace_box_elf_A_const_49 *lang.Var

var A_arbace_box_elf_A_const_50 *lang.Var

var A_arbace_box_elf_A_const_51 *lang.Var

var A_arbace_box_elf_A_const_52 *lang.Var

var A_arbace_box_elf_A_const_53 *lang.Var

var A_arbace_box_elf_A_const_54 any

var A_arbace_box_elf_A_const_55 *lang.Var

var A_arbace_box_elf_A_const_56 *lang.Var

var A_arbace_box_elf_A_const_57 *lang.Var

var A_arbace_box_elf_A_const_58 any

var A_arbace_box_elf_A_init jrt.ClassInit

func A_arbace_box_elf_A_Init() { if !A_arbace_box_elf_A_init.Done() { A_arbace_box_elf_A_init.Run(A_arbace_box_elf_A_clinit) } }

func A_arbace_box_elf_A_clinit() { A_arbace_box_elf_A_clinit_p0(); A_arbace_box_elf_A_clinit_p1(); A_arbace_box_elf_A_clinit_p2(); A_arbace_box_elf_A_clinit_p3(); A_arbace_box_elf_A_clinit_p4() }

func A_arbace_box_elf_A_clinit_p0() { A_arbace_box_elf_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 70); A_arbace_box_elf_A_const_0 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[11]); A_arbace_box_elf_A_const_1 = A_arbace_box_elf_A_const_pool.A[12]; A_arbace_box_elf_A_const_2 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[13]); A_arbace_box_elf_A_const_3 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[14]); A_arbace_box_elf_A_const_4 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[15]); A_arbace_box_elf_A_const_5 = A_arbace_box_elf_A_const_pool.A[16]; A_arbace_box_elf_A_const_6 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[17]); A_arbace_box_elf_A_const_7 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[18]); A_arbace_box_elf_A_const_8 = A_arbace_box_elf_A_const_pool.A[19]; A_arbace_box_elf_A_const_9 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[20]); A_arbace_box_elf_A_const_10 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[21]); A_arbace_box_elf_A_const_11 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[22]) }

func A_arbace_box_elf_A_clinit_p1() { A_arbace_box_elf_A_const_12 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[23]); A_arbace_box_elf_A_const_13 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[24]); A_arbace_box_elf_A_const_14 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[25]); A_arbace_box_elf_A_const_15 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[26]); A_arbace_box_elf_A_const_16 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[27]); A_arbace_box_elf_A_const_17 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[28]); A_arbace_box_elf_A_const_18 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[29]); A_arbace_box_elf_A_const_19 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[30]); A_arbace_box_elf_A_const_20 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[31]); A_arbace_box_elf_A_const_21 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[32]); A_arbace_box_elf_A_const_22 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[33]); A_arbace_box_elf_A_const_23 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[34]) }

func A_arbace_box_elf_A_clinit_p2() { A_arbace_box_elf_A_const_24 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[35]); A_arbace_box_elf_A_const_25 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[36]); A_arbace_box_elf_A_const_26 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[37]); A_arbace_box_elf_A_const_27 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[38]); A_arbace_box_elf_A_const_28 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[39]); A_arbace_box_elf_A_const_29 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[40]); A_arbace_box_elf_A_const_30 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[41]); A_arbace_box_elf_A_const_31 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[42]); A_arbace_box_elf_A_const_32 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[43]); A_arbace_box_elf_A_const_33 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[44]); A_arbace_box_elf_A_const_34 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[45]); A_arbace_box_elf_A_const_35 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[46]) }

func A_arbace_box_elf_A_clinit_p3() { A_arbace_box_elf_A_const_36 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[47]); A_arbace_box_elf_A_const_37 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[48]); A_arbace_box_elf_A_const_38 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[49]); A_arbace_box_elf_A_const_39 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[50]); A_arbace_box_elf_A_const_40 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[51]); A_arbace_box_elf_A_const_41 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[52]); A_arbace_box_elf_A_const_42 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[53]); A_arbace_box_elf_A_const_43 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[54]); A_arbace_box_elf_A_const_44 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[55]); A_arbace_box_elf_A_const_45 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[56]); A_arbace_box_elf_A_const_46 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[57]); A_arbace_box_elf_A_const_47 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[58]) }

func A_arbace_box_elf_A_clinit_p4() { A_arbace_box_elf_A_const_48 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[59]); A_arbace_box_elf_A_const_49 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[60]); A_arbace_box_elf_A_const_50 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[61]); A_arbace_box_elf_A_const_51 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[62]); A_arbace_box_elf_A_const_52 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[63]); A_arbace_box_elf_A_const_53 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[64]); A_arbace_box_elf_A_const_54 = A_arbace_box_elf_A_const_pool.A[65]; A_arbace_box_elf_A_const_55 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[66]); A_arbace_box_elf_A_const_56 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[67]); A_arbace_box_elf_A_const_57 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[68]); A_arbace_box_elf_A_const_58 = A_arbace_box_elf_A_const_pool.A[69] }

func A_arbace_box_elf_A_New() *A_arbace_box_elf_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf_A) Ctor() {}

func (t *A_arbace_box_elf_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_A_class }

func (t *A_arbace_box_elf_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_elf_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_A); return ok }

func A_arbace_box_elf_A_Cast(x any) *A_arbace_box_elf_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_A_class)) }; return v }



type A_arbace_box_elf_align_A struct{ j2g_header uint64 }

var A_arbace_box_elf_align_A_fn_class *jrt.Class



type A_arbace_box_elf_c_string_A struct{ j2g_header uint64 }

var A_arbace_box_elf_c_string_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_A struct{ j2g_header uint64 }

var A_arbace_box_elf_cut_symbols_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000020_A struct{ j2g_header uint64 }

var A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000022_A struct{ j2g_header uint64; F_secs any }

var A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000052_A struct{ j2g_header uint64; F_kept, F_data any }

var A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000058_A struct{ j2g_header uint64 }

var A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A struct{ j2g_header uint64; F_k any }

var A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A struct{ j2g_header uint64; F_data, F_st, F_strs, F_want, F_b any }

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A struct{ j2g_header uint64; F_s__581000039, F_data, F_st, F_strs, F_iter__581000038, F_want, F_b any }

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A struct{ j2g_header uint64; F_b__581000041, F_data, F_st, F_strs, F_want any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b any }

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_place__581000070_A struct{ j2g_header uint64; F_places, F_o, F_secs any }

var A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_sec__581000018_A struct{ j2g_header uint64; F_shentsize, F_shoff int64; F_b any }

var A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class *jrt.Class



type A_arbace_box_elf_eval581000004_A struct{ jrt.Object }

func A_arbace_box_elf_eval581000004_A_New() *A_arbace_box_elf_eval581000004_A { t := &A_arbace_box_elf_eval581000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf_eval581000004_A) Ctor() {}

func (t *A_arbace_box_elf_eval581000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_eval581000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_eval581000004_A_class }

func (t *A_arbace_box_elf_eval581000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_eval581000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_elf_eval581000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_eval581000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_eval581000004_A); return ok }

func A_arbace_box_elf_eval581000004_A_Cast(x any) *A_arbace_box_elf_eval581000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_eval581000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_eval581000004_A_class)) }; return v }



type A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A struct{ j2g_header uint64 }

var A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_fn_class *jrt.Class



type A_arbace_box_elf_eval581000008_A struct{ jrt.Object }

func A_arbace_box_elf_eval581000008_A_New() *A_arbace_box_elf_eval581000008_A { t := &A_arbace_box_elf_eval581000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf_eval581000008_A) Ctor() {}

func (t *A_arbace_box_elf_eval581000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_eval581000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_eval581000008_A_class }

func (t *A_arbace_box_elf_eval581000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_eval581000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_elf_eval581000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_eval581000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_eval581000008_A); return ok }

func A_arbace_box_elf_eval581000008_A_Cast(x any) *A_arbace_box_elf_eval581000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_eval581000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_eval581000008_A_class)) }; return v }



type A_arbace_box_elf_eval581000008_fn__581000009_A struct{ j2g_header uint64 }

var A_arbace_box_elf_eval581000008_fn__581000009_A_fn_class *jrt.Class



type A_arbace_box_elf_fail_A struct{ j2g_header uint64 }

var A_arbace_box_elf_fail_A_fn_class *jrt.Class



type A_arbace_box_elf_le_A struct{ j2g_header uint64 }

var A_arbace_box_elf_le_A_fn_class *jrt.Class
