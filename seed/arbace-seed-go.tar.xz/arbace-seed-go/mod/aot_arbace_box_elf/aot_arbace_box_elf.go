//line aot_arbace_box_elf.ae:1
package aot_arbace_box_elf

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :3:1
func A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_New() *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) Ctor() {}
//line :3:1
func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_elf_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_box_elf_A_const_1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_20)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_21)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_22)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_23)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :3:1
func A_arbace_box_elf_eval581000008_fn__581000009_A_New() *A_arbace_box_elf_eval581000008_fn__581000009_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_eval581000008_fn__581000009_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) Ctor() {}
//line :3:1
func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_box_elf_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_box_elf_A_const_6), A_arbace_box_elf_A_const_4.GetRawRoot__O(), A_arbace_box_elf_A_const_5) }











func A_arbace_box_elf_fail_A_New() *A_arbace_box_elf_fail_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_fail_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_box_elf_fail_A) Ctor() {}
//line :15:1
func (t *A_arbace_box_elf_fail_A) Invoke_O_O__O(self, msg__0 any) any { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_box_elf_A_const_7.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, msg__0)).Ref(), A_arbace_box_elf_A_const_8)))) }







func A_arbace_box_elf_le_A_New() *A_arbace_box_elf_le_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_le_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_box_elf_le_A) Ctor() {}
//line :23:1
func (t *A_arbace_box_elf_le_A) Invoke_O_O__O(self, b__0 any) any {
	var tmp1 jrt.ByteBuffer_I = jrt.ByteBuffer_Wrap_B1__ByteBuffer(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())); var tmp2 *jrt.ByteOrder; jrt.ByteOrder_Init(); tmp2 = jrt.ByteOrder_LITTLE_ENDIAN; return tmp1.Order_ByteOrder__ByteBuffer(tmp2)
}
func A_arbace_box_elf_c_string_A_New() *A_arbace_box_elf_c_string_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_c_string_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_box_elf_c_string_A) Ctor() {}
//line :26:1
func (t *A_arbace_box_elf_c_string_A) Invoke_O_O_O__O(self, b__0, p_off__1 any) any { { var off__1 int64 = lang.RT_LongCast_O__J_NoInit(p_off__1); var e__3 int64 = off__1; L1: for {

	if lang.Numbers_IsZero_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(e__3))).Ref())) { return jrt.String_New_B1_I_I_Charset(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(off__1), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(e__3, off__1)), jrt.StandardCharsets_UTF_8) } else {

		e__3 = lang.Numbers_Inc_J__J_NoInit(e__3); continue L1 } } }; /*line :26:1*/panic("j2g: unreachable") }





func A_arbace_box_elf_align_A_New() *A_arbace_box_elf_align_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_align_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_box_elf_align_A) Ctor() {}
//line :32:1
func (t *A_arbace_box_elf_align_A) Invoke_O_O_O__O(self, o__0, p_a__1 any) any { var a__1 int64 = lang.RT_LongCast_O__J_NoInit(p_a__1); if
										lang.Numbers_Gt_J_J__Z_NoInit(a__1, 1) { L1: for {
											var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_9.GetRawRoot__O()); var tmp2 bool; var na_1 any = lang.IFn_Cast(A_arbace_box_elf_A_const_10.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.ByteArrayOutputStream_Cast(o__0)).Size__I()).Ref(), jrt.Long_ValueOf_J__Long_NoInit(a__1).Ref()); if jrt.Long_InstanceOf(na_1) { var n0_2 int64 = jrt.NN(jrt.Long_Cast(na_1)).LongValue__J(); tmp2 = n0_2 == 0 } else { if jrt.Double_InstanceOf(na_1) { var n0_2_2 float64 = jrt.NN(jrt.Double_Cast(na_1)).DoubleValue__D(); tmp2 = n0_2_2 == 0.0 } else { tmp2 = lang.Numbers_IsZero_O__Z_NoInit(na_1) } }; if jrt.J2g_Truth(tmp1.Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref())) {
												jrt.NN(jrt.ByteArrayOutputStream_Cast(o__0)).Write_I__V(lang.RT_IntCast_J__I_NoInit(0))
//line :34:1
			continue L1 }
//line :33:1
		break L1 } }; return o__0 }




func A_arbace_box_elf_cut_symbols_A_New() *A_arbace_box_elf_cut_symbols_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_box_elf_cut_symbols_A) Ctor() {}
//line :38:1
func (t *A_arbace_box_elf_cut_symbols_A) Invoke_O_O_O__O(self, data__0, names__1 any) any { var b__3 any = lang.IFn_Cast(A_arbace_box_elf_A_const_11.GetRawRoot__O()).Invoke_O__O(data__0); var tmp1 bool; var and__1927000168__auto____4 bool = lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()))), 64); if and__1927000168__auto____4 {



	var and__1927000168__auto____5 bool = lang.Util_Equiv_J_J__Z_NoInit(127, lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0))).Ref())); if and__1927000168__auto____5 { var and__1927000168__auto____6 bool = lang.Util_Equiv_J_J__Z_NoInit(2, lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(4))).Ref())); if and__1927000168__auto____6 { tmp1 = lang.Util_Equiv_J_J__Z_NoInit(1, lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(5))).Ref())) } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if tmp1 { } else {
		lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_1) }; var phoff__4 int64 = /*line :38:1*/jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_J__I_NoInit(32)); var shoff__5 int64 = jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_J__I_NoInit(40)); var phentsize__6 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Short_ValueOf_S__Short_NoInit(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I_NoInit(54))).Ref()), 65535); var phnum__7 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Short_ValueOf_S__Short_NoInit(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I_NoInit(56))).Ref()), 65535); var shentsize__8 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Short_ValueOf_S__Short_NoInit(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I_NoInit(58))).Ref()), 65535); var shnum__9 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Short_ValueOf_S__Short_NoInit(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I_NoInit(60))).Ref()), 65535); var shstrndx__10 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Short_ValueOf_S__Short_NoInit(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I_NoInit(62))).Ref()), 65535); var sec__11 any; var tmp2 any = A_arbace_box_elf_cut_symbols_sec__581000018_A_New_J_J_O(shentsize__8, shoff__5, b__3); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class; if









	fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; sec__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var secs__12 any = /*line :38:1*/lang.IFn_Cast(A_arbace_box_elf_A_const_18.GetRawRoot__O()).Invoke_O_O__O(sec__11, lang.IFn_Cast(A_arbace_box_elf_A_const_39.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(shnum__9).Ref())); var symtab__13 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_40.GetRawRoot__O()); var tmp6 any = A_arbace_box_elf_cut_symbols_fn__581000020_A_New(); var tmp7 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class; if














	fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class = fncls__66d; tmp7 = fncls__66d } else { tmp7 = fncls__66 }; symtab__13 = tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), secs__12)); var strtab__14 any; if
	jrt.J2g_Truth(symtab__13) { var tmp8 *lang.Keyword = A_arbace_box_elf_A_const_15; strtab__14 = tmp8.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(symtab__13)) } else { strtab__14 = nil }; var tmp9 bool; var or__1927000174__auto____15 bool =
	lang.Util_Identical_O_O__Z_NoInit(symtab__13, nil); if or__1927000174__auto____15 { tmp9 = or__1927000174__auto____15 } else { var or__1927000174__auto____16 bool; var na_67 any = strtab__14; var na_68 int64 = 0; if jrt.Long_InstanceOf(na_67) { var n0_69 int64 = jrt.NN(jrt.Long_Cast(na_67)).LongValue__J(); var n1_70 int64 = na_68; or__1927000174__auto____16 = n0_69 <= n1_70 } else { or__1927000174__auto____16 = lang.Numbers_Lte_O_J__Z_NoInit(na_67, na_68) }; if or__1927000174__auto____16 { tmp9 = or__1927000174__auto____16 } else { var or__1927000174__auto____17 bool; var na_72 any = strtab__14; var na_73 int64 = shnum__9; if jrt.Long_InstanceOf(na_72) { var n0_74 int64 = jrt.NN(jrt.Long_Cast(na_72)).LongValue__J(); var n1_75 int64 = na_73; or__1927000174__auto____17 = n0_74 >= n1_75 } else { or__1927000174__auto____17 = lang.Numbers_Gte_O_J__Z_NoInit(na_72, na_73) }; if or__1927000174__auto____17 { tmp9 = or__1927000174__auto____17 } else { var or__1927000174__auto____18 bool = lang.Numbers_Lte_J_J__Z_NoInit(shstrndx__10, 0); if or__1927000174__auto____18 { tmp9 = or__1927000174__auto____18 } else { tmp9 = lang.Numbers_Gte_J_J__Z_NoInit(shstrndx__10, shnum__9) } } } }; if tmp9 {
		lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_4) }; var tail__15 any; var tmp10 lang.IFn = /*line :38:1*/lang.IFn_Cast(A_arbace_box_elf_A_const_20.GetRawRoot__O()); var tmp11 any = A_arbace_box_elf_cut_symbols_fn__581000022_A_New_O(secs__12); var tmp12 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class; if


















	fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class = fncls__77d; tmp12 = fncls__77d } else { tmp12 = fncls__77 }; tail__15 = tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), lang.Tuple_Create_O_O_O__IPersistentVector(symtab__13, strtab__14, jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref())); var tmp13 /*line :38:1*/*lang.Keyword = A_arbace_box_elf_A_const_13; var start__16 any = tmp13.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(tail__15))); var tmp14 bool; var na_78 int64 = lang.Numbers_Add_J_J__J_NoInit(shoff__5, lang.Numbers_Multiply_J_J__J_NoInit(shnum__9, shentsize__8)); var na_79 any = start__16; if




















	jrt.Long_InstanceOf(na_79) { var n0_80 int64 = na_78; var n1_81 int64 = jrt.NN(jrt.Long_Cast(na_79)).LongValue__J(); tmp14 = n0_80 > n1_81 } else { tmp14 = lang.Numbers_Gt_J_O__Z_NoInit(na_78, na_79) }; if tmp14 {
		lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_6) }; var seq_581000024__17 any = /*line :38:1*/lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_elf_A_const_43.GetRawRoot__O(), secs__12)); var chunk_581000025__18 any; var count_581000026__19 int64 = 0; var i_581000027__20 int64 = 0; L1: for {






















			if lang.Numbers_Lt_J_J__Z_NoInit(i_581000027__20, count_581000026__19) { var vec__581000028__21 any = lang.Indexed_Cast(chunk_581000025__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_581000027__20)); var i__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000028__21, lang.RT_IntCast_J__I_NoInit(0), nil); var s__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000028__21, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_9.GetRawRoot__O()); var tmp16 any; var or__1927000174__auto____24 any = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, strtab__14, symtab__13, jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref()))).Invoke_O__O(i__22)
				if jrt.J2g_Truth(or__1927000174__auto____24) { tmp16 = or__1927000174__auto____24 } else { tmp16 = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_44.GetRawRoot__O(), A_arbace_box_elf_A_const_45.GetRawRoot__O()))).Invoke_O__O(A_arbace_box_elf_A_const_12.Invoke_O__O(s__23)) }
//line :61:1
				if jrt.J2g_Truth(tmp15.Invoke_O__O(tmp16)) {

					var tmp17 bool; var na_88 any; var na_90 any = A_arbace_box_elf_A_const_13.Invoke_O__O(s__23); var na_91 any = A_arbace_box_elf_A_const_14.Invoke_O__O(s__23); var tmp18 bool; var tmp19 bool; tmp19 = jrt.Long_InstanceOf(na_90); if tmp19 { tmp19 = jrt.Long_InstanceOf(na_91) }; tmp18 = tmp19; if tmp18 { var n0_92 int64 = jrt.NN(jrt.Long_Cast(na_90)).LongValue__J(); var n1_93 int64 = jrt.NN(jrt.Long_Cast(na_91)).LongValue__J(); var nr_94 int64 = n0_92 + n1_93; if (n0_92^nr_94)&(n1_93^nr_94) >= 0 { na_88 = jrt.Long_ValueOf_J__Long_NoInit(nr_94).Ref() } else { na_88 = lang.Numbers_Add_O_O__Number_NoInit(na_90, na_91) } } else { var tmp20 bool; var tmp21 bool; tmp21 = jrt.Double_InstanceOf(na_90); if tmp21 { tmp21 = jrt.Double_InstanceOf(na_91) }; tmp20 = tmp21; if tmp20 { var n0_92_2 float64 = jrt.NN(jrt.Double_Cast(na_90)).DoubleValue__D(); var n1_93_2 float64 = jrt.NN(jrt.Double_Cast(na_91)).DoubleValue__D(); na_88 = jrt.Double_ValueOf_D__Double_NoInit(n0_92_2 + n1_93_2).Ref() } else { na_88 = lang.Numbers_Add_O_O__Number_NoInit(na_90, na_91) } }; var na_89 any = start__16; var tmp22 bool; var tmp23 bool; tmp23 = jrt.Long_InstanceOf(na_88); if tmp23 { tmp23 = jrt.Long_InstanceOf(na_89) }; tmp22 = tmp23; if tmp22 { var n0_95 int64 = jrt.NN(jrt.Long_Cast(na_88)).LongValue__J(); var n1_96 int64 = jrt.NN(jrt.Long_Cast(na_89)).LongValue__J(); tmp17 = n0_95 > n1_96 } else { var tmp24 bool; var tmp25 bool; tmp25 = jrt.Double_InstanceOf(na_88); if tmp25 { tmp25 = jrt.Double_InstanceOf(na_89) }; tmp24 = tmp25; if tmp24 { var n0_95_2 float64 = jrt.NN(jrt.Double_Cast(na_88)).DoubleValue__D(); var n1_96_2 float64 = jrt.NN(jrt.Double_Cast(na_89)).DoubleValue__D(); tmp17 = n1_96_2 < n0_95_2 } else { tmp17 = lang.Numbers_Gt_O_O__Z_NoInit(na_88, na_89) } }; if tmp17 {
						lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_7) }
//line :61:1
					seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = seq_581000024__17, chunk_581000025__18, count_581000026__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000027__20); continue L1 } else { seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = seq_581000024__17, chunk_581000025__18, count_581000026__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000027__20); continue L1 } } else { var temp__1927000414__auto____21 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_581000024__17); if jrt.J2g_Truth(temp__1927000414__auto____21) { var seq_581000024__22 any = temp__1927000414__auto____21; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_581000024__22)) { var c__1927000678__auto____23 any = lang.IFn_Cast(A_arbace_box_elf_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_581000024__22); seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = lang.IFn_Cast(A_arbace_box_elf_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_581000024__22), c__1927000678__auto____23, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__581000031__23 any = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_581000024__22); var i__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000031__23, lang.RT_IntCast_J__I_NoInit(0), nil); var s__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000031__23, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_9.GetRawRoot__O()); var tmp27 any; var or__1927000174__auto____26 any = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, strtab__14, symtab__13, jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref()))).Invoke_O__O(i__24)
						if jrt.J2g_Truth(or__1927000174__auto____26) { tmp27 = or__1927000174__auto____26 } else { tmp27 = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_44.GetRawRoot__O(), A_arbace_box_elf_A_const_45.GetRawRoot__O()))).Invoke_O__O(A_arbace_box_elf_A_const_12.Invoke_O__O(s__25)) }
//line :61:1
						if jrt.J2g_Truth(tmp26.Invoke_O__O(tmp27)) {

							var tmp28 bool; var na_98 any; var na_100 any = A_arbace_box_elf_A_const_13.Invoke_O__O(s__25); var na_101 any = A_arbace_box_elf_A_const_14.Invoke_O__O(s__25); var tmp29 bool; var tmp30 bool; tmp30 = jrt.Long_InstanceOf(na_100); if tmp30 { tmp30 = jrt.Long_InstanceOf(na_101) }; tmp29 = tmp30; if tmp29 { var n0_102 int64 = jrt.NN(jrt.Long_Cast(na_100)).LongValue__J(); var n1_103 int64 = jrt.NN(jrt.Long_Cast(na_101)).LongValue__J(); var nr_104 int64 = n0_102 + n1_103; if (n0_102^nr_104)&(n1_103^nr_104) >= 0 { na_98 = jrt.Long_ValueOf_J__Long_NoInit(nr_104).Ref() } else { na_98 = lang.Numbers_Add_O_O__Number_NoInit(na_100, na_101) } } else { var tmp31 bool; var tmp32 bool; tmp32 = jrt.Double_InstanceOf(na_100); if tmp32 { tmp32 = jrt.Double_InstanceOf(na_101) }; tmp31 = tmp32; if tmp31 { var n0_102_2 float64 = jrt.NN(jrt.Double_Cast(na_100)).DoubleValue__D(); var n1_103_2 float64 = jrt.NN(jrt.Double_Cast(na_101)).DoubleValue__D(); na_98 = jrt.Double_ValueOf_D__Double_NoInit(n0_102_2 + n1_103_2).Ref() } else { na_98 = lang.Numbers_Add_O_O__Number_NoInit(na_100, na_101) } }; var na_99 any = start__16; var tmp33 bool; var tmp34 bool; tmp34 = jrt.Long_InstanceOf(na_98); if tmp34 { tmp34 = jrt.Long_InstanceOf(na_99) }; tmp33 = tmp34; if tmp33 { var n0_105 int64 = jrt.NN(jrt.Long_Cast(na_98)).LongValue__J(); var n1_106 int64 = jrt.NN(jrt.Long_Cast(na_99)).LongValue__J(); tmp28 = n0_105 > n1_106 } else { var tmp35 bool; var tmp36 bool; tmp36 = jrt.Double_InstanceOf(na_98); if tmp36 { tmp36 = jrt.Double_InstanceOf(na_99) }; tmp35 = tmp36; if tmp35 { var n0_105_2 float64 = jrt.NN(jrt.Double_Cast(na_98)).DoubleValue__D(); var n1_106_2 float64 = jrt.NN(jrt.Double_Cast(na_99)).DoubleValue__D(); tmp28 = n1_106_2 < n0_105_2 } else { tmp28 = lang.Numbers_Gt_O_O__Z_NoInit(na_98, na_99) } }; if tmp28 {
								lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_7) }
//line :61:1
							seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_581000024__22), nil, 0, 0; continue L1 } else { seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_581000024__22), nil, 0, 0; continue L1 } } } }
//line :38:1
			break L1 }; var seq_581000034__17 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_39.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(phnum__7).Ref())); var chunk_581000035__18 any; var count_581000036__19 int64 = 0; var i_581000037__20 int64 = 0; L2: for {


























				if lang.Numbers_Lt_J_J__Z_NoInit(i_581000037__20, count_581000036__19) { var i__21 any = lang.Indexed_Cast(chunk_581000035__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_581000037__20)); var h__22 any; var na_108 int64 = phoff__4; var na_109 any; var na_110 any = i__21; var na_111 int64 = phentsize__6
					if jrt.Long_InstanceOf(na_110) { var n0_112 int64 = jrt.NN(jrt.Long_Cast(na_110)).LongValue__J(); var n1_113 int64 = na_111; var nr_114 int64 = n0_112 * n1_113; var tmp37 bool; var tmp38 bool; var tmp39 bool; var tmp40 bool; tmp40 = n0_112 == -9223372036854775808; if tmp40 { tmp40 = n1_113 < 0 }; tmp39 = tmp40; tmp38 = !tmp39; if tmp38 { var tmp41 bool; tmp41 = n1_113 == 0; if !tmp41 { tmp41 = nr_114/n1_113 == n0_112 }; tmp38 = tmp41 }; tmp37 = tmp38; if tmp37 { na_109 = jrt.Long_ValueOf_J__Long_NoInit(nr_114).Ref() } else { na_109 = lang.Numbers_Multiply_O_J__Number_NoInit(na_110, na_111) } } else { na_109 = lang.Numbers_Multiply_O_J__Number_NoInit(na_110, na_111) }; if jrt.Long_InstanceOf(na_109) { var n0_115 int64 = na_108; var n1_116 int64 = jrt.NN(jrt.Long_Cast(na_109)).LongValue__J(); var nr_117 int64 = n0_115 + n1_116; if (n0_115^nr_117)&(n1_116^nr_117) >= 0 { h__22 = jrt.Long_ValueOf_J__Long_NoInit(nr_117).Ref() } else { h__22 = lang.Numbers_Add_J_O__Number_NoInit(na_108, na_109) } } else { h__22 = lang.Numbers_Add_J_O__Number_NoInit(na_108, na_109) }
					var tmp42 bool; var na_118 int64; var tmp43 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(b__3); var tmp44 jrt.Number_I; var na_120 any = h__22; var na_121 int64 = 8; if jrt.Long_InstanceOf(na_120) { var n0_122 int64 = jrt.NN(jrt.Long_Cast(na_120)).LongValue__J(); var n1_123 int64 = na_121; var nr_124 int64 = n0_122 + n1_123; if (n0_122^nr_124)&(n1_123^nr_124) >= 0 { tmp44 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_124)) } else { tmp44 = lang.Numbers_Add_O_J__Number_NoInit(na_120, na_121) } } else { tmp44 = lang.Numbers_Add_O_J__Number_NoInit(na_120, na_121) }; var tmp45 int64 = tmp43.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp44)); var tmp46 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(b__3); var tmp47 jrt.Number_I; var na_125 any = h__22; var na_126 int64 = 32; if jrt.Long_InstanceOf(na_125) { var n0_127 int64 = jrt.NN(jrt.Long_Cast(na_125)).LongValue__J(); var n1_128 int64 = na_126; var nr_129 int64 = n0_127 + n1_128; if (n0_127^nr_129)&(n1_128^nr_129) >= 0 { tmp47 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_129)) } else { tmp47 = lang.Numbers_Add_O_J__Number_NoInit(na_125, na_126) } } else { tmp47 = lang.Numbers_Add_O_J__Number_NoInit(na_125, na_126) }; na_118 = lang.Numbers_Add_J_J__J_NoInit(tmp45, tmp46.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp47))); var na_119 any = start__16; if jrt.Long_InstanceOf(na_119) { var n0_130 int64 = na_118; var n1_131 int64 = jrt.NN(jrt.Long_Cast(na_119)).LongValue__J(); tmp42 = n0_130 > n1_131 } else { tmp42 = lang.Numbers_Gt_J_O__Z_NoInit(na_118, na_119) }; if tmp42 {
						lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_8) }
//line :65:1
					seq_581000034__17, chunk_581000035__18, count_581000036__19, i_581000037__20 = seq_581000034__17, chunk_581000035__18, count_581000036__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000037__20); continue L2 } else { var temp__1927000414__auto____21_2 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_581000034__17); if jrt.J2g_Truth(temp__1927000414__auto____21_2) { var seq_581000034__22 any = temp__1927000414__auto____21_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_581000034__22)) { var c__1927000678__auto____23_2 any = lang.IFn_Cast(A_arbace_box_elf_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_581000034__22); seq_581000034__17, chunk_581000035__18, count_581000036__19, i_581000037__20 = lang.IFn_Cast(A_arbace_box_elf_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_581000034__22), c__1927000678__auto____23_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var i__23 any = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_581000034__22); var h__24 any; var na_133 int64 = phoff__4; var na_134 any; var na_135 any = i__23; var na_136 int64 = phentsize__6
						if jrt.Long_InstanceOf(na_135) { var n0_137 int64 = jrt.NN(jrt.Long_Cast(na_135)).LongValue__J(); var n1_138 int64 = na_136; var nr_139 int64 = n0_137 * n1_138; var tmp48 bool; var tmp49 bool; var tmp50 bool; var tmp51 bool; tmp51 = n0_137 == -9223372036854775808; if tmp51 { tmp51 = n1_138 < 0 }; tmp50 = tmp51; tmp49 = !tmp50; if tmp49 { var tmp52 bool; tmp52 = n1_138 == 0; if !tmp52 { tmp52 = nr_139/n1_138 == n0_137 }; tmp49 = tmp52 }; tmp48 = tmp49; if tmp48 { na_134 = jrt.Long_ValueOf_J__Long_NoInit(nr_139).Ref() } else { na_134 = lang.Numbers_Multiply_O_J__Number_NoInit(na_135, na_136) } } else { na_134 = lang.Numbers_Multiply_O_J__Number_NoInit(na_135, na_136) }; if jrt.Long_InstanceOf(na_134) { var n0_140 int64 = na_133; var n1_141 int64 = jrt.NN(jrt.Long_Cast(na_134)).LongValue__J(); var nr_142 int64 = n0_140 + n1_141; if (n0_140^nr_142)&(n1_141^nr_142) >= 0 { h__24 = jrt.Long_ValueOf_J__Long_NoInit(nr_142).Ref() } else { h__24 = lang.Numbers_Add_J_O__Number_NoInit(na_133, na_134) } } else { h__24 = lang.Numbers_Add_J_O__Number_NoInit(na_133, na_134) }
						var tmp53 bool; var na_143 int64; var tmp54 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(b__3); var tmp55 jrt.Number_I; var na_145 any = h__24; var na_146 int64 = 8; if jrt.Long_InstanceOf(na_145) { var n0_147 int64 = jrt.NN(jrt.Long_Cast(na_145)).LongValue__J(); var n1_148 int64 = na_146; var nr_149 int64 = n0_147 + n1_148; if (n0_147^nr_149)&(n1_148^nr_149) >= 0 { tmp55 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_149)) } else { tmp55 = lang.Numbers_Add_O_J__Number_NoInit(na_145, na_146) } } else { tmp55 = lang.Numbers_Add_O_J__Number_NoInit(na_145, na_146) }; var tmp56 int64 = tmp54.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp55)); var tmp57 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(b__3); var tmp58 jrt.Number_I; var na_150 any = h__24; var na_151 int64 = 32; if jrt.Long_InstanceOf(na_150) { var n0_152 int64 = jrt.NN(jrt.Long_Cast(na_150)).LongValue__J(); var n1_153 int64 = na_151; var nr_154 int64 = n0_152 + n1_153; if (n0_152^nr_154)&(n1_153^nr_154) >= 0 { tmp58 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_154)) } else { tmp58 = lang.Numbers_Add_O_J__Number_NoInit(na_150, na_151) } } else { tmp58 = lang.Numbers_Add_O_J__Number_NoInit(na_150, na_151) }; na_143 = lang.Numbers_Add_J_J__J_NoInit(tmp56, tmp57.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp58))); var na_144 any = start__16; if jrt.Long_InstanceOf(na_144) { var n0_155 int64 = na_143; var n1_156 int64 = jrt.NN(jrt.Long_Cast(na_144)).LongValue__J(); tmp53 = n0_155 > n1_156 } else { tmp53 = lang.Numbers_Gt_J_O__Z_NoInit(na_143, na_144) }; if tmp53 {
							lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_8) }
//line :65:1
						seq_581000034__17, chunk_581000035__18, count_581000036__19, i_581000037__20 = lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_581000034__22), nil, 0, 0; continue L2 } } }
//line :38:1
				break L2 }; var l__17 any = lang.IFn_Cast(secs__12).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_46.GetRawRoot__O()).Invoke_O__O(tail__15)); var tmp59 jrt.Number_I; var na_83 any = A_arbace_box_elf_A_const_13.Invoke_O__O(l__17); var na_84 any = A_arbace_box_elf_A_const_14.Invoke_O__O(l__17); var tmp60 bool; var tmp61 bool; tmp61 =































	jrt.Long_InstanceOf(na_83); if tmp61 { tmp61 = jrt.Long_InstanceOf(na_84) }; tmp60 = tmp61; if tmp60 { var n0_85 int64 = jrt.NN(jrt.Long_Cast(na_83)).LongValue__J(); var n1_86 int64 = jrt.NN(jrt.Long_Cast(na_84)).LongValue__J(); var nr_87 int64 = n0_85 + n1_86; if (n0_85^nr_87)&(n1_86^nr_87) >= 0 { tmp59 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_87)) } else { tmp59 = lang.Numbers_Add_O_O__Number_NoInit(na_83, na_84) } } else { var tmp62 bool; var tmp63 bool; tmp63 = jrt.Double_InstanceOf(na_83); if tmp63 { tmp63 = jrt.Double_InstanceOf(na_84) }; tmp62 = tmp63; if tmp62 { var n0_85_2 float64 = jrt.NN(jrt.Double_Cast(na_83)).DoubleValue__D(); var n1_86_2 float64 = jrt.NN(jrt.Double_Cast(na_84)).DoubleValue__D(); tmp59 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_85_2 + n1_86_2)) } else { tmp59 = lang.Numbers_Add_O_O__Number_NoInit(na_83, na_84) } }; if lang.Util_Equiv_O_J__Z_NoInit(tmp59, int64(lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass())))) { } else {
		lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(Lit_9) }; var st__17 any = /*line :38:1*/lang.IFn_Cast(secs__12).Invoke_O__O(symtab__13); var tmp64 *lang.Keyword = A_arbace_box_elf_A_const_13; var strs__18 any = tmp64.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(strtab__14)); var n__19 any; var na_44 any = A_arbace_box_elf_A_const_14.Invoke_O__O(st__17); var na_45 int64 = 24; if



































	jrt.Long_InstanceOf(na_44) { var n0_46 int64 = jrt.NN(jrt.Long_Cast(na_44)).LongValue__J(); var n1_47 int64 = na_45; if n1_47 == 0 { n__19 = lang.Numbers_Quotient_O_J__Number_NoInit(na_44, na_45) } else { n__19 = jrt.Long_ValueOf_J__Long_NoInit(n0_46 / n1_47).Ref() } } else { n__19 = lang.Numbers_Quotient_O_J__Number_NoInit(na_44, na_45) }; var want__20 any = /*line :38:1*/lang.IFn_Cast(A_arbace_box_elf_A_const_21.GetRawRoot__O()).Invoke_O__O(names__1); var kept__21 any; var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_22.GetRawRoot__O()); var tmp66 any; var iter__1927001039__auto____21 any; var tmp67 any = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_New_O_O_O_O_O(data__0, st__17, strs__18, want__20, b__3); var tmp68 *jrt.Class; var fncls__190 *jrt.Class = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class; if





































	fncls__190 == nil { var fncls__190d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class = fncls__190d; tmp68 = fncls__190d } else { tmp68 = fncls__190 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp67, tmp68, nil); tmp66 = lang.IFn_Cast(iter__1927001039__auto____21).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_elf_A_const_54, n__19)); kept__21 = tmp65.Invoke_O__O(tmp66); var ___22 any; var tmp69 any = /*line :38:1*/A_arbace_box_elf_cut_symbols_fn__581000052_A_New_O_O(kept__21, data__0); var tmp70 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class; _ = ___22; if










































	fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class = fncls__59d; tmp70 = fncls__59d } else { tmp70 = fncls__59 }; ___22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp69, tmp70, nil).Invoke__O(); var missing__23 any = /*line :38:1*/lang.IFn_Cast(A_arbace_box_elf_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_55.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_56.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_elf_A_const_26, kept__21)), want__20)); var ___24 any; _ = ___24; if














































	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(missing__23)) { ___24 = lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_elf_A_const_22.GetRawRoot__O()).Invoke_O__O(missing__23))).Ref()) } else { ___24 = nil }; var kept__25 any; var tmp71 lang.IFn = /*line :38:1*/lang.IFn_Cast(A_arbace_box_elf_A_const_34.GetRawRoot__O()); var tmp72 any = A_arbace_box_elf_cut_symbols_fn__581000058_A_New(); var tmp73 *jrt.Class; var fncls__192 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class; if
















































	fncls__192 == nil { var fncls__192d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class = fncls__192d; tmp73 = fncls__192d } else { tmp73 = fncls__192 }; kept__25 = tmp71.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp72, tmp73, nil), lang.PersistentVector_EMPTY.Ref(), kept__21); var strb__26 any = /*line :38:1*/jrt.ByteArrayOutputStream_New(); var symb__27 any = jrt.ByteArrayOutputStream_New();



















































	jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Write_I__V(lang.RT_IntCast_J__I_NoInit(0));
	jrt.OutputStream_Cast(symb__27).Write_B1__V(lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_elf_A_const_58)); var seq_581000062__28 any = /*line :38:1*/lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(kept__25); var chunk_581000063__29 any; var count_581000064__30 int64 = 0; var i_581000065__31 int64 = 0; L3: for {





















































		if lang.Numbers_Lt_J_J__Z_NoInit(i_581000065__31, count_581000064__30) { var map__581000066__32 any = lang.Indexed_Cast(chunk_581000063__29).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_581000065__31)); var map__581000066__33 any; if lang.ISeq_InstanceOf(map__581000066__32) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(map__581000066__32)) { map__581000066__33 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_box_elf_A_const_25.GetRawRoot__O()).Invoke_O__O(map__581000066__32), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(map__581000066__32)) { map__581000066__33 = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(map__581000066__32) } else { map__581000066__33 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000066__33 = map__581000066__32 }; var name__34 any = lang.RT_Get_O_O__O_NoInit(map__581000066__33, A_arbace_box_elf_A_const_26); var entry__35 any = lang.RT_Get_O_O__O_NoInit(map__581000066__33, A_arbace_box_elf_A_const_27); var e__36 any = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_elf_A_const_58).Ref(); var eb__37 any = lang.IFn_Cast(A_arbace_box_elf_A_const_11.GetRawRoot__O()).Invoke_O__O(e__36)


			jrt.System_Arraycopy_O_I_O_I_I__V(data__0, lang.RT_IntCast_O__I_NoInit(entry__35), e__36, lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_J__I_NoInit(24))
			jrt.ByteBuffer_Cast(eb__37).PutInt_I_I__ByteBuffer(lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_I__I_NoInit(jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Size__I()))
			jrt.OutputStream_Cast(symb__27).Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](e__36, jrt.Prim_byte.ArrayClass()))
			jrt.OutputStream_Cast(strb__26).Write_B1__V(jrt.NN(jrt.String_Cast(name__34)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8))
			jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Write_I__V(lang.RT_IntCast_J__I_NoInit(0))
//line :92:1
			seq_581000062__28, chunk_581000063__29, count_581000064__30, i_581000065__31 = seq_581000062__28, chunk_581000063__29, count_581000064__30, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000065__31); continue L3 } else { var temp__1927000414__auto____32 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_581000062__28); if jrt.J2g_Truth(temp__1927000414__auto____32) { var seq_581000062__33 any = temp__1927000414__auto____32; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_581000062__33)) { var c__1927000678__auto____34 any = lang.IFn_Cast(A_arbace_box_elf_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_581000062__33); seq_581000062__28, chunk_581000063__29, count_581000064__30, i_581000065__31 = lang.IFn_Cast(A_arbace_box_elf_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_581000062__33), c__1927000678__auto____34, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____34))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var map__581000068__34 any = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_581000062__33); var map__581000068__35 any; if lang.ISeq_InstanceOf(map__581000068__34) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(map__581000068__34)) { map__581000068__35 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_box_elf_A_const_25.GetRawRoot__O()).Invoke_O__O(map__581000068__34), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(map__581000068__34)) { map__581000068__35 = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(map__581000068__34) } else { map__581000068__35 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000068__35 = map__581000068__34 }; var name__36 any = lang.RT_Get_O_O__O_NoInit(map__581000068__35, A_arbace_box_elf_A_const_26); var entry__37 any = lang.RT_Get_O_O__O_NoInit(map__581000068__35, A_arbace_box_elf_A_const_27); var e__38 any = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_elf_A_const_58).Ref(); var eb__39 any = lang.IFn_Cast(A_arbace_box_elf_A_const_11.GetRawRoot__O()).Invoke_O__O(e__38)


				jrt.System_Arraycopy_O_I_O_I_I__V(data__0, lang.RT_IntCast_O__I_NoInit(entry__37), e__38, lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_J__I_NoInit(24))
				jrt.ByteBuffer_Cast(eb__39).PutInt_I_I__ByteBuffer(lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_I__I_NoInit(jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Size__I()))
				jrt.OutputStream_Cast(symb__27).Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](e__38, jrt.Prim_byte.ArrayClass()))
				jrt.OutputStream_Cast(strb__26).Write_B1__V(jrt.NN(jrt.String_Cast(name__36)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8))
				jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Write_I__V(lang.RT_IntCast_J__I_NoInit(0))
//line :92:1
				seq_581000062__28, chunk_581000063__29, count_581000064__30, i_581000065__31 = lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_581000062__33), nil, 0, 0; continue L3 } } }
//line :38:1
		break L3 }; var o__28 any = jrt.ByteArrayOutputStream_New(); var ___29 any; _ = ___29;






























































	jrt.NN(jrt.ByteArrayOutputStream_Cast(o__28)).Write_B1_I_I__V(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_O__I_NoInit(start__16)); ___29 = nil; var shstr__30 any; var tmp74 /*line :38:1*/*jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()); var tmp75 *lang.Keyword = A_arbace_box_elf_A_const_13; var tmp76 int32 = lang.RT_IntCast_O__I_NoInit(tmp75.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref()))); var tmp77 jrt.Number_I; var tmp78 *lang.Keyword = A_arbace_box_elf_A_const_13; var na_60 any = tmp78.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref())); var tmp79 *lang.Keyword = A_arbace_box_elf_A_const_14; var na_61 any = tmp79.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref())); var tmp80 bool; var tmp81 bool; tmp81 =































































	jrt.Long_InstanceOf(na_60); if tmp81 { tmp81 = jrt.Long_InstanceOf(na_61) }; tmp80 = tmp81; if tmp80 { var n0_62 int64 = jrt.NN(jrt.Long_Cast(na_60)).LongValue__J(); var n1_63 int64 = jrt.NN(jrt.Long_Cast(na_61)).LongValue__J(); var nr_64 int64 = n0_62 + n1_63; if (n0_62^nr_64)&(n1_63^nr_64) >= 0 { tmp77 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_64)) } else { tmp77 = lang.Numbers_Add_O_O__Number_NoInit(na_60, na_61) } } else { var tmp82 bool; var tmp83 bool; tmp83 = jrt.Double_InstanceOf(na_60); if tmp83 { tmp83 = jrt.Double_InstanceOf(na_61) }; tmp82 = tmp83; if tmp82 { var n0_62_2 float64 = jrt.NN(jrt.Double_Cast(na_60)).DoubleValue__D(); var n1_63_2 float64 = jrt.NN(jrt.Double_Cast(na_61)).DoubleValue__D(); tmp77 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_62_2 + n1_63_2)) } else { tmp77 = lang.Numbers_Add_O_O__Number_NoInit(na_60, na_61) } }; shstr__30 = jrt.Arrays_CopyOfRange_B1_I_I__B1_NoInit(tmp74, tmp76, lang.RT_IntCast_O__I_NoInit(tmp77)).Ref(); var places__31 any = /*line :38:1*/lang.IFn_Cast(A_arbace_box_elf_A_const_35.GetRawRoot__O()).Invoke_O__O(lang.PersistentArrayMap_EMPTY.Ref()); var place__32 any; var tmp84 any = A_arbace_box_elf_cut_symbols_place__581000070_A_New_O_O_O(places__31, o__28, secs__12); var tmp85 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class; if

































































	fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class = fncls__65d; tmp85 = fncls__65d } else { tmp85 = fncls__65 }; place__32 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp84, tmp85, nil);



	lang.IFn_Cast(place__32).Invoke_O_O__O(symtab__13, jrt.NN(jrt.ByteArrayOutputStream_Cast(symb__27)).ToByteArray__B1().Ref());
	lang.IFn_Cast(place__32).Invoke_O_O__O(strtab__14, jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).ToByteArray__B1().Ref());
	lang.IFn_Cast(place__32).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref(), shstr__30); var out__33 any = /*line :38:1*/jrt.NN(jrt.ByteArrayOutputStream_Cast(o__28)).ToByteArray__B1().Ref(); var ob__34 any = lang.IFn_Cast(A_arbace_box_elf_A_const_11.GetRawRoot__O()).Invoke_O__O(out__33); var seq_581000072__35 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_3.GetRawRoot__O()).Invoke_O__O(places__31)); var chunk_581000073__36 any; var count_581000074__37 int64 = 0; var i_581000075__38 int64 = 0; L4: for {










































































		if lang.Numbers_Lt_J_J__Z_NoInit(i_581000075__38, count_581000074__37) { var vec__581000076__39 any = lang.Indexed_Cast(chunk_581000073__36).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_581000075__38)); var i__40 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000076__39, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__581000079__41 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000076__39, lang.RT_IntCast_J__I_NoInit(1), nil); var off__42 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000079__41, lang.RT_IntCast_J__I_NoInit(0), nil); var size__43 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000079__41, lang.RT_IntCast_J__I_NoInit(1), nil); var h__44 any; var na_208 int64 = shoff__5; var na_209 any; var na_210 any = i__40; var na_211 int64 = shentsize__8
			if jrt.Long_InstanceOf(na_210) { var n0_212 int64 = jrt.NN(jrt.Long_Cast(na_210)).LongValue__J(); var n1_213 int64 = na_211; var nr_214 int64 = n0_212 * n1_213; var tmp86 bool; var tmp87 bool; var tmp88 bool; var tmp89 bool; tmp89 = n0_212 == -9223372036854775808; if tmp89 { tmp89 = n1_213 < 0 }; tmp88 = tmp89; tmp87 = !tmp88; if tmp87 { var tmp90 bool; tmp90 = n1_213 == 0; if !tmp90 { tmp90 = nr_214/n1_213 == n0_212 }; tmp87 = tmp90 }; tmp86 = tmp87; if tmp86 { na_209 = jrt.Long_ValueOf_J__Long_NoInit(nr_214).Ref() } else { na_209 = lang.Numbers_Multiply_O_J__Number_NoInit(na_210, na_211) } } else { na_209 = lang.Numbers_Multiply_O_J__Number_NoInit(na_210, na_211) }; if jrt.Long_InstanceOf(na_209) { var n0_215 int64 = na_208; var n1_216 int64 = jrt.NN(jrt.Long_Cast(na_209)).LongValue__J(); var nr_217 int64 = n0_215 + n1_216; if (n0_215^nr_217)&(n1_216^nr_217) >= 0 { h__44 = jrt.Long_ValueOf_J__Long_NoInit(nr_217).Ref() } else { h__44 = lang.Numbers_Add_J_O__Number_NoInit(na_208, na_209) } } else { h__44 = lang.Numbers_Add_J_O__Number_NoInit(na_208, na_209) }
			var tmp91 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(ob__34); var tmp92 jrt.Number_I; var na_223 any = h__44; var na_224 int64 = 24; if jrt.Long_InstanceOf(na_223) { var n0_225 int64 = jrt.NN(jrt.Long_Cast(na_223)).LongValue__J(); var n1_226 int64 = na_224; var nr_227 int64 = n0_225 + n1_226; if (n0_225^nr_227)&(n1_226^nr_227) >= 0 { tmp92 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_227)) } else { tmp92 = lang.Numbers_Add_O_J__Number_NoInit(na_223, na_224) } } else { tmp92 = lang.Numbers_Add_O_J__Number_NoInit(na_223, na_224) }; tmp91.PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I_NoInit(tmp92), lang.RT_LongCast_O__J_NoInit(off__42))
			var tmp93 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(ob__34); var tmp94 jrt.Number_I; var na_218 any = h__44; var na_219 int64 = 32; if jrt.Long_InstanceOf(na_218) { var n0_220 int64 = jrt.NN(jrt.Long_Cast(na_218)).LongValue__J(); var n1_221 int64 = na_219; var nr_222 int64 = n0_220 + n1_221; if (n0_220^nr_222)&(n1_221^nr_222) >= 0 { tmp94 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_222)) } else { tmp94 = lang.Numbers_Add_O_J__Number_NoInit(na_218, na_219) } } else { tmp94 = lang.Numbers_Add_O_J__Number_NoInit(na_218, na_219) }; tmp93.PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I_NoInit(tmp94), lang.RT_LongCast_O__J_NoInit(size__43))
//line :113:1
			seq_581000072__35, chunk_581000073__36, count_581000074__37, i_581000075__38 = seq_581000072__35, chunk_581000073__36, count_581000074__37, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000075__38); continue L4 } else { var temp__1927000414__auto____39 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_581000072__35); if jrt.J2g_Truth(temp__1927000414__auto____39) { var seq_581000072__40 any = temp__1927000414__auto____39; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_581000072__40)) { var c__1927000678__auto____41 any = lang.IFn_Cast(A_arbace_box_elf_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_581000072__40); seq_581000072__35, chunk_581000073__36, count_581000074__37, i_581000075__38 = lang.IFn_Cast(A_arbace_box_elf_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_581000072__40), c__1927000678__auto____41, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____41))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var vec__581000082__41 any = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_581000072__40); var i__42 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000082__41, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__581000085__43 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000082__41, lang.RT_IntCast_J__I_NoInit(1), nil); var off__44 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000085__43, lang.RT_IntCast_J__I_NoInit(0), nil); var size__45 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000085__43, lang.RT_IntCast_J__I_NoInit(1), nil); var h__46 any; var na_228 int64 = shoff__5; var na_229 any; var na_230 any = i__42; var na_231 int64 = shentsize__8
				if jrt.Long_InstanceOf(na_230) { var n0_232 int64 = jrt.NN(jrt.Long_Cast(na_230)).LongValue__J(); var n1_233 int64 = na_231; var nr_234 int64 = n0_232 * n1_233; var tmp95 bool; var tmp96 bool; var tmp97 bool; var tmp98 bool; tmp98 = n0_232 == -9223372036854775808; if tmp98 { tmp98 = n1_233 < 0 }; tmp97 = tmp98; tmp96 = !tmp97; if tmp96 { var tmp99 bool; tmp99 = n1_233 == 0; if !tmp99 { tmp99 = nr_234/n1_233 == n0_232 }; tmp96 = tmp99 }; tmp95 = tmp96; if tmp95 { na_229 = jrt.Long_ValueOf_J__Long_NoInit(nr_234).Ref() } else { na_229 = lang.Numbers_Multiply_O_J__Number_NoInit(na_230, na_231) } } else { na_229 = lang.Numbers_Multiply_O_J__Number_NoInit(na_230, na_231) }; if jrt.Long_InstanceOf(na_229) { var n0_235 int64 = na_228; var n1_236 int64 = jrt.NN(jrt.Long_Cast(na_229)).LongValue__J(); var nr_237 int64 = n0_235 + n1_236; if (n0_235^nr_237)&(n1_236^nr_237) >= 0 { h__46 = jrt.Long_ValueOf_J__Long_NoInit(nr_237).Ref() } else { h__46 = lang.Numbers_Add_J_O__Number_NoInit(na_228, na_229) } } else { h__46 = lang.Numbers_Add_J_O__Number_NoInit(na_228, na_229) }
				var tmp100 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(ob__34); var tmp101 jrt.Number_I; var na_243 any = h__46; var na_244 int64 = 24; if jrt.Long_InstanceOf(na_243) { var n0_245 int64 = jrt.NN(jrt.Long_Cast(na_243)).LongValue__J(); var n1_246 int64 = na_244; var nr_247 int64 = n0_245 + n1_246; if (n0_245^nr_247)&(n1_246^nr_247) >= 0 { tmp101 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_247)) } else { tmp101 = lang.Numbers_Add_O_J__Number_NoInit(na_243, na_244) } } else { tmp101 = lang.Numbers_Add_O_J__Number_NoInit(na_243, na_244) }; tmp100.PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I_NoInit(tmp101), lang.RT_LongCast_O__J_NoInit(off__44))
				var tmp102 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(ob__34); var tmp103 jrt.Number_I; var na_238 any = h__46; var na_239 int64 = 32; if jrt.Long_InstanceOf(na_238) { var n0_240 int64 = jrt.NN(jrt.Long_Cast(na_238)).LongValue__J(); var n1_241 int64 = na_239; var nr_242 int64 = n0_240 + n1_241; if (n0_240^nr_242)&(n1_241^nr_242) >= 0 { tmp103 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_242)) } else { tmp103 = lang.Numbers_Add_O_J__Number_NoInit(na_238, na_239) } } else { tmp103 = lang.Numbers_Add_O_J__Number_NoInit(na_238, na_239) }; tmp102.PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I_NoInit(tmp103), lang.RT_LongCast_O__J_NoInit(size__45))
//line :113:1
				seq_581000072__35, chunk_581000073__36, count_581000074__37, i_581000075__38 = lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_581000072__40), nil, 0, 0; continue L4 } } }
//line :38:1
		break L4 }; var tmp104 jrt.ByteBuffer_I =















































































	jrt.ByteBuffer_Cast(ob__34); var tmp105 jrt.Number_I; var na_193 any; var na_195 int64 = shoff__5; var na_196 any; var na_197 any = symtab__13; var na_198 int64 = shentsize__8; if jrt.Long_InstanceOf(na_197) { var n0_199 int64 = jrt.NN(jrt.Long_Cast(na_197)).LongValue__J(); var n1_200 int64 = na_198; var nr_201 int64 = n0_199 * n1_200; var tmp106 bool; var tmp107 bool; var tmp108 bool; var tmp109 bool; tmp109 = n0_199 == -9223372036854775808; if tmp109 { tmp109 = n1_200 < 0 }; tmp108 = tmp109; tmp107 = !tmp108; if tmp107 { var tmp110 bool; tmp110 = n1_200 == 0; if !tmp110 { tmp110 = nr_201/n1_200 == n0_199 }; tmp107 = tmp110 }; tmp106 = tmp107; if tmp106 { na_196 = jrt.Long_ValueOf_J__Long_NoInit(nr_201).Ref() } else { na_196 = lang.Numbers_Multiply_O_J__Number_NoInit(na_197, na_198) } } else { na_196 = lang.Numbers_Multiply_O_J__Number_NoInit(na_197, na_198) }; if jrt.Long_InstanceOf(na_196) { var n0_202 int64 = na_195; var n1_203 int64 = jrt.NN(jrt.Long_Cast(na_196)).LongValue__J(); var nr_204 int64 = n0_202 + n1_203; if (n0_202^nr_204)&(n1_203^nr_204) >= 0 { na_193 = jrt.Long_ValueOf_J__Long_NoInit(nr_204).Ref() } else { na_193 = lang.Numbers_Add_J_O__Number_NoInit(na_195, na_196) } } else { na_193 = lang.Numbers_Add_J_O__Number_NoInit(na_195, na_196) }; var na_194 int64 = 44; if jrt.Long_InstanceOf(na_193) { var n0_205 int64 = jrt.NN(jrt.Long_Cast(na_193)).LongValue__J(); var n1_206 int64 = na_194; var nr_207 int64 = n0_205 + n1_206; if (n0_205^nr_207)&(n1_206^nr_207) >= 0 { tmp105 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_207)) } else { tmp105 = lang.Numbers_Add_O_J__Number_NoInit(na_193, na_194) } } else { tmp105 = lang.Numbers_Add_O_J__Number_NoInit(na_193, na_194) }; tmp104.PutInt_I_I__ByteBuffer(lang.RT_IntCast_O__I_NoInit(tmp105), lang.RT_IntCast_J__I_NoInit(1)); return out__33 }
//line :48:1
func A_arbace_box_elf_cut_symbols_sec__581000018_A_New_J_J_O(p0, p1 int64, p2 any) *A_arbace_box_elf_cut_symbols_sec__581000018_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_sec__581000018_A{}; t.Ctor_J_J_O(p0, p1, p2); return t }
//line :48:1
func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) Ctor_J_J_O(c__shentsize, c__shoff int64, c__b any) { t.F_shentsize = c__shentsize; t.F_shoff = c__shoff; t.F_b = c__b }
//line :48:1
func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) Invoke_O_O__O(self, i__1 any) any { var h__2 any; var na_3 int64 = t.F_shoff; var na_4 any; var na_5 any = i__1; var na_6 int64 = t.F_shentsize; if jrt.Long_InstanceOf(na_5) { var n0_7 int64 = jrt.NN(jrt.Long_Cast(na_5)).LongValue__J(); var n1_8 int64 = na_6; var nr_9 int64 = n0_7 * n1_8; var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = n0_7 == -9223372036854775808; if tmp4 { tmp4 = n1_8 < 0 }; tmp3 = tmp4; tmp2 = !tmp3; if tmp2 { var tmp5 bool; tmp5 = n1_8 == 0; if !tmp5 { tmp5 = nr_9/n1_8 == n0_7 }; tmp2 = tmp5 }; tmp1 = tmp2; if tmp1 { na_4 = jrt.Long_ValueOf_J__Long_NoInit(nr_9).Ref() } else { na_4 = lang.Numbers_Multiply_O_J__Number_NoInit(na_5, na_6) } } else { na_4 = lang.Numbers_Multiply_O_J__Number_NoInit(na_5, na_6) }; if jrt.Long_InstanceOf(na_4) { var n0_10 int64 = na_3; var n1_11 int64 = jrt.NN(jrt.Long_Cast(na_4)).LongValue__J(); var nr_12 int64 = n0_10 + n1_11; if (n0_10^nr_12)&(n1_11^nr_12) >= 0 { h__2 = jrt.Long_ValueOf_J__Long_NoInit(nr_12).Ref() } else { h__2 = lang.Numbers_Add_J_O__Number_NoInit(na_3, na_4) } } else { h__2 = lang.Numbers_Add_J_O__Number_NoInit(na_3, na_4) }; var tmp6 any = A_arbace_box_elf_A_const_12; var tmp7 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp8 jrt.Number_I; var na_13 any = h__2; var na_14 int64 = 4; if
												jrt.Long_InstanceOf(na_13) { var n0_15 int64 = jrt.NN(jrt.Long_Cast(na_13)).LongValue__J(); var n1_16 int64 = na_14; var nr_17 int64 = n0_15 + n1_16; if (n0_15^nr_17)&(n1_16^nr_17) >= 0 { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_17)) } else { tmp8 = lang.Numbers_Add_O_J__Number_NoInit(na_13, na_14) } } else { tmp8 = lang.Numbers_Add_O_J__Number_NoInit(na_13, na_14) }; var tmp9 any = /*line :48:1*/jrt.Integer_ValueOf_I__Integer_NoInit(tmp7.GetInt_I__I(lang.RT_IntCast_O__I_NoInit(tmp8))).Ref(); var tmp10 any = A_arbace_box_elf_A_const_13; var tmp11 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp12 jrt.Number_I; var na_18 any = h__2; var na_19 int64 = 24; if
												jrt.Long_InstanceOf(na_18) { var n0_20 int64 = jrt.NN(jrt.Long_Cast(na_18)).LongValue__J(); var n1_21 int64 = na_19; var nr_22 int64 = n0_20 + n1_21; if (n0_20^nr_22)&(n1_21^nr_22) >= 0 { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_22)) } else { tmp12 = lang.Numbers_Add_O_J__Number_NoInit(na_18, na_19) } } else { tmp12 = lang.Numbers_Add_O_J__Number_NoInit(na_18, na_19) }; var tmp13 any = /*line :48:1*/jrt.Long_ValueOf_J__Long_NoInit(tmp11.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp12))).Ref(); var tmp14 any = A_arbace_box_elf_A_const_14; var tmp15 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp16 jrt.Number_I; var na_23 any = h__2; var na_24 int64 = 32; if

	jrt.Long_InstanceOf(na_23) { var n0_25 int64 = jrt.NN(jrt.Long_Cast(na_23)).LongValue__J(); var n1_26 int64 = na_24; var nr_27 int64 = n0_25 + n1_26; if (n0_25^nr_27)&(n1_26^nr_27) >= 0 { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_27)) } else { tmp16 = lang.Numbers_Add_O_J__Number_NoInit(na_23, na_24) } } else { tmp16 = lang.Numbers_Add_O_J__Number_NoInit(na_23, na_24) }; var tmp17 any = /*line :48:1*/jrt.Long_ValueOf_J__Long_NoInit(tmp15.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp16))).Ref(); var tmp18 any = A_arbace_box_elf_A_const_15; var tmp19 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp20 jrt.Number_I; var na_28 any = h__2; var na_29 int64 = 40; if

	jrt.Long_InstanceOf(na_28) { var n0_30 int64 = jrt.NN(jrt.Long_Cast(na_28)).LongValue__J(); var n1_31 int64 = na_29; var nr_32 int64 = n0_30 + n1_31; if (n0_30^nr_32)&(n1_31^nr_32) >= 0 { tmp20 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_32)) } else { tmp20 = lang.Numbers_Add_O_J__Number_NoInit(na_28, na_29) } } else { tmp20 = lang.Numbers_Add_O_J__Number_NoInit(na_28, na_29) }; var tmp21 any = /*line :48:1*/jrt.Integer_ValueOf_I__Integer_NoInit(tmp19.GetInt_I__I(lang.RT_IntCast_O__I_NoInit(tmp20))).Ref(); var tmp22 any = A_arbace_box_elf_A_const_16; var tmp23 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp24 jrt.Number_I; var na_33 any = h__2; var na_34 int64 = 48; if


	jrt.Long_InstanceOf(na_33) { var n0_35 int64 = jrt.NN(jrt.Long_Cast(na_33)).LongValue__J(); var n1_36 int64 = na_34; var nr_37 int64 = n0_35 + n1_36; if (n0_35^nr_37)&(n1_36^nr_37) >= 0 { tmp24 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_37)) } else { tmp24 = lang.Numbers_Add_O_J__Number_NoInit(na_33, na_34) } } else { tmp24 = lang.Numbers_Add_O_J__Number_NoInit(na_33, na_34) }; var tmp25 any = /*line :48:1*/jrt.Long_ValueOf_J__Long_NoInit(tmp23.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp24))).Ref(); var tmp26 any = A_arbace_box_elf_A_const_17; var tmp27 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp28 jrt.Number_I; var na_38 any = h__2; var na_39 int64 = 56; if


	jrt.Long_InstanceOf(na_38) { var n0_40 int64 = jrt.NN(jrt.Long_Cast(na_38)).LongValue__J(); var n1_41 int64 = na_39; var nr_42 int64 = n0_40 + n1_41; if (n0_40^nr_42)&(n1_41^nr_42) >= 0 { tmp28 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_42)) } else { tmp28 = lang.Numbers_Add_O_J__Number_NoInit(na_38, na_39) } } else { tmp28 = lang.Numbers_Add_O_J__Number_NoInit(na_38, na_39) }; return /*line :48:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp9, tmp10, tmp13, tmp14, tmp17, tmp18, tmp21, tmp22, tmp25, tmp26, jrt.Long_ValueOf_J__Long_NoInit(tmp27.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp28))).Ref())) }




func A_arbace_box_elf_cut_symbols_fn__581000020_A_New() *A_arbace_box_elf_cut_symbols_fn__581000020_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000020_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) Ctor() {}
//line :53:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) Invoke_O_O_O__O(self, i__1, s__2 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_box_elf_A_const_41.GetRawRoot__O(), A_arbace_box_elf_A_const_12.Invoke_O__O(s__2)) { return i__1 } else { return nil } }



func A_arbace_box_elf_cut_symbols_fn__581000022_A_New_O(p0 any) *A_arbace_box_elf_cut_symbols_fn__581000022_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000022_A{}; t.Ctor_O(p0); return t }
//line :57:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) Ctor_O(c__secs any) { t.F_secs = c__secs }
//line :57:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) Invoke_O_O__O(self, p1__581000016_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_box_elf_A_const_13; return tmp1.Invoke_O__O(lang.IFn_Cast(t.F_secs).Invoke_O__O(p1__581000016_SHARP___1)) }


















func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) Ctor_O_O_O_O_O(c__data, c__st, c__strs, c__want, c__b any) { t.F_data = c__data; t.F_st = c__st; t.F_strs = c__strs; t.F_want = c__want; t.F_b = c__b }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) Invoke_O_O__O(self, s__581000039__1 any) any { var tmp1 any = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_New_O_O_O_O_O_O_O(s__581000039__1, t.F_data, t.F_st, t.F_strs, self, t.F_want, t.F_b); var tmp2 *jrt.Class; var fncls__189 *jrt.Class = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class; if fncls__189 == nil { var fncls__189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class = fncls__189d; tmp2 = fncls__189d } else { tmp2 = fncls__189 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :76:1
func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) Ctor_O_O_O_O_O_O_O(c__s__581000039, c__data, c__st, c__strs, c__iter__581000038, c__want, c__b any) { t.F_s__581000039 = c__s__581000039; t.F_data = c__data; t.F_st = c__st; t.F_strs = c__strs; t.F_iter__581000038 = c__iter__581000038; t.F_want = c__want; t.F_b = c__b }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) Invoke_O__O(self any) any { { var s__581000039__1 any; var t_ any = t.F_s__581000039; t.F_s__581000039 = nil; s__581000039__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(s__581000039__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__581000039__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_28.GetRawRoot__O()).Invoke_O__O(s__581000039__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_elf_A_const_29.GetRawRoot__O()).Invoke_O__O(s__581000039__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__581000041__6 any = lang.IFn_Cast(A_arbace_box_elf_A_const_47.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_New_O_O_O_O_O_I_O_O(b__581000041__6, t.F_data, t.F_st, t.F_strs, t.F_want, size__1927001038__auto____5, c__1927001037__auto____4, t.F_b); var tmp2 *jrt.Class; var fncls__173 *jrt.Class = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class; if fncls__173 == nil { var fncls__173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class = fncls__173d; tmp2 = fncls__173d } else { tmp2 = fncls__173 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__581000038); return lang.IFn_Cast(A_arbace_box_elf_A_const_50.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_52.GetRawRoot__O()).Invoke_O__O(b__581000041__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_32.GetRawRoot__O()).Invoke_O__O(s__581000039__3))) } else { return lang.IFn_Cast(A_arbace_box_elf_A_const_50.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_52.GetRawRoot__O()).Invoke_O__O(b__581000041__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(s__581000039__3); var e__5 any; var na_174 any = A_arbace_box_elf_A_const_13.Invoke_O__O(t.F_st); var na_175 any; var na_176 int64 = 24; var na_177 any = i__4
														if jrt.Long_InstanceOf(na_177) { var n0_178 int64 = na_176; var n1_179 int64 = jrt.NN(jrt.Long_Cast(na_177)).LongValue__J(); var nr_180 int64 = n0_178 * n1_179; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool; tmp7 = n0_178 == -9223372036854775808; if tmp7 { tmp7 = n1_179 < 0 }; tmp6 = tmp7; tmp5 = !tmp6; if tmp5 { var tmp8 bool; tmp8 = n1_179 == 0; if !tmp8 { tmp8 = nr_180/n1_179 == n0_178 }; tmp5 = tmp8 }; tmp4 = tmp5; if tmp4 { na_175 = jrt.Long_ValueOf_J__Long_NoInit(nr_180).Ref() } else { na_175 = lang.Numbers_Multiply_J_O__Number_NoInit(na_176, na_177) } } else { na_175 = lang.Numbers_Multiply_J_O__Number_NoInit(na_176, na_177) }; var tmp9 bool; var tmp10 bool; tmp10 = jrt.Long_InstanceOf(na_174); if tmp10 { tmp10 = jrt.Long_InstanceOf(na_175) }; tmp9 = tmp10; if tmp9 { var n0_181 int64 = jrt.NN(jrt.Long_Cast(na_174)).LongValue__J(); var n1_182 int64 = jrt.NN(jrt.Long_Cast(na_175)).LongValue__J(); var nr_183 int64 = n0_181 + n1_182; if (n0_181^nr_183)&(n1_182^nr_183) >= 0 { e__5 = jrt.Long_ValueOf_J__Long_NoInit(nr_183).Ref() } else { e__5 = lang.Numbers_Add_O_O__Number_NoInit(na_174, na_175) } } else { var tmp11 bool; var tmp12 bool; tmp12 = jrt.Double_InstanceOf(na_174); if tmp12 { tmp12 = jrt.Double_InstanceOf(na_175) }; tmp11 = tmp12; if tmp11 { var n0_181_2 float64 = jrt.NN(jrt.Double_Cast(na_174)).DoubleValue__D(); var n1_182_2 float64 = jrt.NN(jrt.Double_Cast(na_175)).DoubleValue__D(); e__5 = jrt.Double_ValueOf_D__Double_NoInit(n0_181_2 + n1_182_2).Ref() } else { e__5 = lang.Numbers_Add_O_O__Number_NoInit(na_174, na_175) } }
//line :76:1
	var nm__6 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_48.GetRawRoot__O()); var tmp14 any = t.F_data; var tmp15 jrt.Number_I; var na_184 any = t.F_strs; var tmp16 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var na_185 int64 = lang.Numbers_And_J_J__J_NoInit(int64(tmp16.GetInt_I__I(lang.RT_IntCast_O__I_NoInit(e__5))), 4294967295)

	if jrt.Long_InstanceOf(na_184) { var n0_186 int64 = jrt.NN(jrt.Long_Cast(na_184)).LongValue__J(); var n1_187 int64 = na_185; var nr_188 int64 = n0_186 + n1_187; if (n0_186^nr_188)&(n1_187^nr_188) >= 0 { tmp15 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_188)) } else { tmp15 = lang.Numbers_Add_O_J__Number_NoInit(na_184, na_185) } } else { tmp15 = lang.Numbers_Add_O_J__Number_NoInit(na_184, na_185) }; nm__6 = tmp13.Invoke_O_O__O(tmp14, tmp15)
//line :76:1
	if jrt.J2g_Truth(lang.IFn_Cast(t.F_want).Invoke_O__O(nm__6)) { var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__581000038); return lang.IFn_Cast(A_arbace_box_elf_A_const_51.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_26, nm__6, A_arbace_box_elf_A_const_27, e__5)), tmp17.Invoke_O__O(lang.IFn_Cast(A_arbace_box_elf_A_const_53.GetRawRoot__O()).Invoke_O__O(s__581000039__3))) } else { s__581000039__1 = lang.IFn_Cast(A_arbace_box_elf_A_const_53.GetRawRoot__O()).Invoke_O__O(s__581000039__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :76:1
func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_New_O_O_O_O_O_I_O_O(p0, p1, p2, p3, p4 any, p5 int32, p6, p7 any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A{}; t.Ctor_O_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) Ctor_O_O_O_O_O_I_O_O(c__b__581000041, c__data, c__st, c__strs, c__want any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b any) { t.F_b__581000041 = c__b__581000041; t.F_data = c__data; t.F_st = c__st; t.F_strs = c__strs; t.F_want = c__want; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b = c__b }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) Invoke_O__O(self any) any { { var i__581000040__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__581000040__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__581000040__1)); var e__3 any; var na_158 any = A_arbace_box_elf_A_const_13.Invoke_O__O(t.F_st); var na_159 any; var na_160 int64 = 24; var na_161 any = i__2
																if jrt.Long_InstanceOf(na_161) { var n0_162 int64 = na_160; var n1_163 int64 = jrt.NN(jrt.Long_Cast(na_161)).LongValue__J(); var nr_164 int64 = n0_162 * n1_163; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = n0_162 == -9223372036854775808; if tmp5 { tmp5 = n1_163 < 0 }; tmp4 = tmp5; tmp3 = !tmp4; if tmp3 { var tmp6 bool; tmp6 = n1_163 == 0; if !tmp6 { tmp6 = nr_164/n1_163 == n0_162 }; tmp3 = tmp6 }; tmp2 = tmp3; if tmp2 { na_159 = jrt.Long_ValueOf_J__Long_NoInit(nr_164).Ref() } else { na_159 = lang.Numbers_Multiply_J_O__Number_NoInit(na_160, na_161) } } else { na_159 = lang.Numbers_Multiply_J_O__Number_NoInit(na_160, na_161) }; var tmp7 bool; var tmp8 bool; tmp8 = jrt.Long_InstanceOf(na_158); if tmp8 { tmp8 = jrt.Long_InstanceOf(na_159) }; tmp7 = tmp8; if tmp7 { var n0_165 int64 = jrt.NN(jrt.Long_Cast(na_158)).LongValue__J(); var n1_166 int64 = jrt.NN(jrt.Long_Cast(na_159)).LongValue__J(); var nr_167 int64 = n0_165 + n1_166; if (n0_165^nr_167)&(n1_166^nr_167) >= 0 { e__3 = jrt.Long_ValueOf_J__Long_NoInit(nr_167).Ref() } else { e__3 = lang.Numbers_Add_O_O__Number_NoInit(na_158, na_159) } } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_158); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_159) }; tmp9 = tmp10; if tmp9 { var n0_165_2 float64 = jrt.NN(jrt.Double_Cast(na_158)).DoubleValue__D(); var n1_166_2 float64 = jrt.NN(jrt.Double_Cast(na_159)).DoubleValue__D(); e__3 = jrt.Double_ValueOf_D__Double_NoInit(n0_165_2 + n1_166_2).Ref() } else { e__3 = lang.Numbers_Add_O_O__Number_NoInit(na_158, na_159) } }
//line :76:1
	var nm__4 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_48.GetRawRoot__O()); var tmp12 any = t.F_data; var tmp13 jrt.Number_I; var na_168 any = t.F_strs; var tmp14 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var na_169 int64 = lang.Numbers_And_J_J__J_NoInit(int64(tmp14.GetInt_I__I(lang.RT_IntCast_O__I_NoInit(e__3))), 4294967295)

	if jrt.Long_InstanceOf(na_168) { var n0_170 int64 = jrt.NN(jrt.Long_Cast(na_168)).LongValue__J(); var n1_171 int64 = na_169; var nr_172 int64 = n0_170 + n1_171; if (n0_170^nr_172)&(n1_171^nr_172) >= 0 { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_172)) } else { tmp13 = lang.Numbers_Add_O_J__Number_NoInit(na_168, na_169) } } else { tmp13 = lang.Numbers_Add_O_J__Number_NoInit(na_168, na_169) }; nm__4 = tmp11.Invoke_O_O__O(tmp12, tmp13)
//line :76:1
	if jrt.J2g_Truth(lang.IFn_Cast(t.F_want).Invoke_O__O(nm__4)) { var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_49.GetRawRoot__O()); var tmp16 any = t.F_b__581000041; tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_26, nm__4, A_arbace_box_elf_A_const_27, e__3))); i__581000040__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__581000040__1); continue L1 } else { i__581000040__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__581000040__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_box_elf_cut_symbols_fn__581000052_A_New_O_O(p0, p1 any) *A_arbace_box_elf_cut_symbols_fn__581000052_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000052_A{}; t.Ctor_O_O(p0, p1); return t }
//line :81:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) Ctor_O_O(c__kept, c__data any) { t.F_kept = c__kept; t.F_data = c__data }
//line :81:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) Invoke_O__O(self any) any { { var seq_581000048__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_kept; t.F_kept = nil; tmp2 = t_; seq_581000048__1 = tmp1.Invoke_O__O(tmp2); var chunk_581000049__2 any; var count_581000050__3 int64 = 0; var i_581000051__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_581000051__4, count_581000050__3) { var map__581000053__5 any = lang.Indexed_Cast(chunk_581000049__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_581000051__4)); var map__581000053__6 any; if lang.ISeq_InstanceOf(map__581000053__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(map__581000053__5)) { map__581000053__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_box_elf_A_const_25.GetRawRoot__O()).Invoke_O__O(map__581000053__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(map__581000053__5)) { map__581000053__6 = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(map__581000053__5) } else { map__581000053__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000053__6 = map__581000053__5 }; var name__7 any = lang.RT_Get_O_O__O_NoInit(map__581000053__6, A_arbace_box_elf_A_const_26); var entry__8 any = lang.RT_Get_O_O__O_NoInit(map__581000053__6, A_arbace_box_elf_A_const_27); var tmp3 any = A_arbace_box_elf_A_const_30.GetRawRoot__O(); var tmp4 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_data, jrt.Prim_byte.ArrayClass()); var tmp5 jrt.Number_I; var na_49 any = entry__8; var na_50 int64 = 4
											if jrt.Long_InstanceOf(na_49) { var n0_51 int64 = jrt.NN(jrt.Long_Cast(na_49)).LongValue__J(); var n1_52 int64 = na_50; var nr_53 int64 = n0_51 + n1_52; if (n0_51^nr_53)&(n1_52^nr_53) >= 0 { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_53)) } else { tmp5 = lang.Numbers_Add_O_J__Number_NoInit(na_49, na_50) } } else { tmp5 = lang.Numbers_Add_O_J__Number_NoInit(na_49, na_50) }; if lang.Util_Equiv_O_J__Z_NoInit(tmp3, lang.Numbers_ShiftRight_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(tmp4, lang.RT_IntCast_O__I_NoInit(tmp5))).Ref()), 255), 4)) {
												lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16), jrt.RefArrayOf(jrt.Object_class, nil, name__7, nil)).Ref()) }
//line :81:1
	seq_581000048__1, chunk_581000049__2, count_581000050__3, i_581000051__4 = seq_581000048__1, chunk_581000049__2, count_581000050__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000051__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_581000048__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_581000048__6 any = temp__1927000414__auto____5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_581000048__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_box_elf_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_581000048__6); seq_581000048__1, chunk_581000049__2, count_581000050__3, i_581000051__4 = lang.IFn_Cast(A_arbace_box_elf_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_581000048__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var map__581000055__7 any = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_581000048__6); var map__581000055__8 any; if lang.ISeq_InstanceOf(map__581000055__7) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(map__581000055__7)) { map__581000055__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_box_elf_A_const_25.GetRawRoot__O()).Invoke_O__O(map__581000055__7), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_box_elf_A_const_23.GetRawRoot__O()).Invoke_O__O(map__581000055__7)) { map__581000055__8 = lang.IFn_Cast(A_arbace_box_elf_A_const_19.GetRawRoot__O()).Invoke_O__O(map__581000055__7) } else { map__581000055__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000055__8 = map__581000055__7 }; var name__9 any = lang.RT_Get_O_O__O_NoInit(map__581000055__8, A_arbace_box_elf_A_const_26); var entry__10 any = lang.RT_Get_O_O__O_NoInit(map__581000055__8, A_arbace_box_elf_A_const_27); var tmp6 any = A_arbace_box_elf_A_const_30.GetRawRoot__O(); var tmp7 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_data, jrt.Prim_byte.ArrayClass()); var tmp8 jrt.Number_I; var na_54 any = entry__10; var na_55 int64 = 4
		if jrt.Long_InstanceOf(na_54) { var n0_56 int64 = jrt.NN(jrt.Long_Cast(na_54)).LongValue__J(); var n1_57 int64 = na_55; var nr_58 int64 = n0_56 + n1_57; if (n0_56^nr_58)&(n1_57^nr_58) >= 0 { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_58)) } else { tmp8 = lang.Numbers_Add_O_J__Number_NoInit(na_54, na_55) } } else { tmp8 = lang.Numbers_Add_O_J__Number_NoInit(na_54, na_55) }; if lang.Util_Equiv_O_J__Z_NoInit(tmp6, lang.Numbers_ShiftRight_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(tmp7, lang.RT_IntCast_O__I_NoInit(tmp8))).Ref()), 255), 4)) {
			lang.IFn_Cast(A_arbace_box_elf_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16), jrt.RefArrayOf(jrt.Object_class, nil, name__9, nil)).Ref()) }
//line :81:1
		seq_581000048__1, chunk_581000049__2, count_581000050__3, i_581000051__4 = lang.IFn_Cast(A_arbace_box_elf_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_581000048__6), nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }





func A_arbace_box_elf_cut_symbols_fn__581000058_A_New() *A_arbace_box_elf_cut_symbols_fn__581000058_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000058_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) Ctor() {}
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) Invoke_O_O_O__O(self, acc__1, k__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_57.GetRawRoot__O()); var tmp2 any = A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_New_O(k__2); var tmp3 *jrt.Class; var fncls__191 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class; if fncls__191 == nil { var fncls__191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class = fncls__191d; tmp3 = fncls__191d } else { tmp3 = fncls__191 }; if jrt.J2g_Truth(tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), acc__1)) { return acc__1 } else { return lang.IFn_Cast(A_arbace_box_elf_A_const_4.GetRawRoot__O()).Invoke_O_O__O(acc__1, k__2) } }
//line :87:1
func A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_New_O(p0 any) *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A{}; t.Ctor_O(p0); return t }
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) Invoke_O_O__O(self, p1__581000017_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_box_elf_A_const_26.Invoke_O__O(t.F_k), A_arbace_box_elf_A_const_26.Invoke_O__O(p1__581000017_SHARP___1))).Ref() }
















func A_arbace_box_elf_cut_symbols_place__581000070_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_elf_cut_symbols_place__581000070_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_place__581000070_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :104:1
func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) Ctor_O_O_O(c__places, c__o, c__secs any) { t.F_places = c__places; t.F_o = c__o; t.F_secs = c__secs }
//line :104:1
func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) Invoke_O_O_O__O(self, i__1, bs__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_36.GetRawRoot__O()); var tmp2 any = t.F_o; var tmp3 *lang.Keyword = A_arbace_box_elf_A_const_16; tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O__O(lang.IFn_Cast(t.F_secs).Invoke_O__O(i__1)))
	var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_37.GetRawRoot__O()); var tmp5 any = t.F_places; tmp4.Invoke_O_O_O_O__O(tmp5, A_arbace_box_elf_A_const_38.GetRawRoot__O(), i__1, lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.ByteArrayOutputStream_Cast(t.F_o)).Size__I()).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](bs__2, jrt.Prim_byte.ArrayClass()))).Ref()))
	var tmp6 jrt.OutputStream_I = jrt.OutputStream_Cast(t.F_o); tmp6.Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](bs__2, jrt.Prim_byte.ArrayClass())); return nil
}











type A_arbace_box_elf_A struct{ jrt.Object }

var A_arbace_box_elf_A_const_pool *jrt.RefArray

var A_arbace_box_elf_A_const_0 *lang.Var

var A_arbace_box_elf_A_const_1 any

var A_arbace_box_elf_A_const_2 *lang.Var

var A_arbace_box_elf_A_const_3 *lang.Var

var A_arbace_box_elf_A_const_4 *lang.Var

var A_arbace_box_elf_A_const_5 any

var A_arbace_box_elf_A_const_6 *lang.Var

var A_arbace_box_elf_A_const_7 *lang.Var

var A_arbace_box_elf_A_const_8 any

var A_arbace_box_elf_A_const_9 *lang.Var

var A_arbace_box_elf_A_const_10 *lang.Var

var A_arbace_box_elf_A_const_11 *lang.Var

var A_arbace_box_elf_A_const_12 *lang.Keyword

var A_arbace_box_elf_A_const_13 *lang.Keyword

var A_arbace_box_elf_A_const_14 *lang.Keyword

var A_arbace_box_elf_A_const_15 *lang.Keyword

var A_arbace_box_elf_A_const_16 *lang.Keyword

var A_arbace_box_elf_A_const_17 *lang.Keyword

var A_arbace_box_elf_A_const_18 *lang.Var

var A_arbace_box_elf_A_const_19 *lang.Var

var A_arbace_box_elf_A_const_20 *lang.Var

var A_arbace_box_elf_A_const_21 *lang.Var

var A_arbace_box_elf_A_const_22 *lang.Var

var A_arbace_box_elf_A_const_23 *lang.Var

var A_arbace_box_elf_A_const_24 *lang.Var

var A_arbace_box_elf_A_const_25 *lang.Var

var A_arbace_box_elf_A_const_26 *lang.Keyword

var A_arbace_box_elf_A_const_27 *lang.Keyword

var A_arbace_box_elf_A_const_28 *lang.Var

var A_arbace_box_elf_A_const_29 *lang.Var

var A_arbace_box_elf_A_const_30 *lang.Var

var A_arbace_box_elf_A_const_31 *lang.Var

var A_arbace_box_elf_A_const_32 *lang.Var

var A_arbace_box_elf_A_const_33 *lang.Var

var A_arbace_box_elf_A_const_34 *lang.Var

var A_arbace_box_elf_A_const_35 *lang.Var

var A_arbace_box_elf_A_const_36 *lang.Var

var A_arbace_box_elf_A_const_37 *lang.Var

var A_arbace_box_elf_A_const_38 *lang.Var

var A_arbace_box_elf_A_const_39 *lang.Var

var A_arbace_box_elf_A_const_40 *lang.Var

var A_arbace_box_elf_A_const_41 *lang.Var

var A_arbace_box_elf_A_const_42 *lang.Var

var A_arbace_box_elf_A_const_43 *lang.Var

var A_arbace_box_elf_A_const_44 *lang.Var

var A_arbace_box_elf_A_const_45 *lang.Var

var A_arbace_box_elf_A_const_46 *lang.Var

var A_arbace_box_elf_A_const_47 *lang.Var

var A_arbace_box_elf_A_const_48 *lang.Var

var A_arbace_box_elf_A_const_49 *lang.Var

var A_arbace_box_elf_A_const_50 *lang.Var

var A_arbace_box_elf_A_const_51 *lang.Var

var A_arbace_box_elf_A_const_52 *lang.Var

var A_arbace_box_elf_A_const_53 *lang.Var

var A_arbace_box_elf_A_const_54 any

var A_arbace_box_elf_A_const_55 *lang.Var

var A_arbace_box_elf_A_const_56 *lang.Var

var A_arbace_box_elf_A_const_57 *lang.Var

var A_arbace_box_elf_A_const_58 any

var A_arbace_box_elf_A_init jrt.ClassInit

func A_arbace_box_elf_A_Init() { if !A_arbace_box_elf_A_init.Done() { A_arbace_box_elf_A_init.Run(A_arbace_box_elf_A_clinit) } }

func A_arbace_box_elf_A_clinit() { A_arbace_box_elf_A_clinit_p0(); A_arbace_box_elf_A_clinit_p1(); A_arbace_box_elf_A_clinit_p2(); A_arbace_box_elf_A_clinit_p3(); A_arbace_box_elf_A_clinit_p4() }

func A_arbace_box_elf_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_elf_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 70); A_arbace_box_elf_A_const_0 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[11]); A_arbace_box_elf_A_const_1 = A_arbace_box_elf_A_const_pool.A[12]; A_arbace_box_elf_A_const_2 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[13]); A_arbace_box_elf_A_const_3 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[14]); A_arbace_box_elf_A_const_4 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[15]); A_arbace_box_elf_A_const_5 = A_arbace_box_elf_A_const_pool.A[16]; A_arbace_box_elf_A_const_6 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[17]); A_arbace_box_elf_A_const_7 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[18]); A_arbace_box_elf_A_const_8 = A_arbace_box_elf_A_const_pool.A[19]; A_arbace_box_elf_A_const_9 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[20]); A_arbace_box_elf_A_const_10 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[21]); A_arbace_box_elf_A_const_11 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[22]) }

func A_arbace_box_elf_A_clinit_p1() { A_arbace_box_elf_A_const_12 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[23]); A_arbace_box_elf_A_const_13 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[24]); A_arbace_box_elf_A_const_14 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[25]); A_arbace_box_elf_A_const_15 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[26]); A_arbace_box_elf_A_const_16 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[27]); A_arbace_box_elf_A_const_17 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[28]); A_arbace_box_elf_A_const_18 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[29]); A_arbace_box_elf_A_const_19 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[30]); A_arbace_box_elf_A_const_20 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[31]); A_arbace_box_elf_A_const_21 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[32]); A_arbace_box_elf_A_const_22 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[33]); A_arbace_box_elf_A_const_23 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[34]) }

func A_arbace_box_elf_A_clinit_p2() { A_arbace_box_elf_A_const_24 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[35]); A_arbace_box_elf_A_const_25 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[36]); A_arbace_box_elf_A_const_26 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[37]); A_arbace_box_elf_A_const_27 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[38]); A_arbace_box_elf_A_const_28 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[39]); A_arbace_box_elf_A_const_29 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[40]); A_arbace_box_elf_A_const_30 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[41]); A_arbace_box_elf_A_const_31 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[42]); A_arbace_box_elf_A_const_32 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[43]); A_arbace_box_elf_A_const_33 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[44]); A_arbace_box_elf_A_const_34 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[45]); A_arbace_box_elf_A_const_35 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[46]) }

func A_arbace_box_elf_A_clinit_p3() { A_arbace_box_elf_A_const_36 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[47]); A_arbace_box_elf_A_const_37 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[48]); A_arbace_box_elf_A_const_38 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[49]); A_arbace_box_elf_A_const_39 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[50]); A_arbace_box_elf_A_const_40 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[51]); A_arbace_box_elf_A_const_41 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[52]); A_arbace_box_elf_A_const_42 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[53]); A_arbace_box_elf_A_const_43 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[54]); A_arbace_box_elf_A_const_44 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[55]); A_arbace_box_elf_A_const_45 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[56]); A_arbace_box_elf_A_const_46 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[57]); A_arbace_box_elf_A_const_47 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[58]) }

func A_arbace_box_elf_A_clinit_p4() { A_arbace_box_elf_A_const_48 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[59]); A_arbace_box_elf_A_const_49 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[60]); A_arbace_box_elf_A_const_50 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[61]); A_arbace_box_elf_A_const_51 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[62]); A_arbace_box_elf_A_const_52 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[63]); A_arbace_box_elf_A_const_53 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[64]); A_arbace_box_elf_A_const_54 = A_arbace_box_elf_A_const_pool.A[65]; A_arbace_box_elf_A_const_55 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[66]); A_arbace_box_elf_A_const_56 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[67]); A_arbace_box_elf_A_const_57 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[68]); A_arbace_box_elf_A_const_58 = A_arbace_box_elf_A_const_pool.A[69] }

func A_arbace_box_elf_A_New() *A_arbace_box_elf_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf_A) Ctor() {}

func (t *A_arbace_box_elf_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_A_class }

func (t *A_arbace_box_elf_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_elf_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_A); return ok }

func A_arbace_box_elf_A_Cast(x any) *A_arbace_box_elf_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_A_class)) }; return v }



type A_arbace_box_elf_align_A struct{ j2g_header uint64 }

var A_arbace_box_elf_align_A_fn_class *jrt.Class



type A_arbace_box_elf_c_string_A struct{ j2g_header uint64 }

var A_arbace_box_elf_c_string_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_A struct{ j2g_header uint64 }

var A_arbace_box_elf_cut_symbols_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000020_A struct{ j2g_header uint64 }

var A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000022_A struct{ j2g_header uint64; F_secs any }

var A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000052_A struct{ j2g_header uint64; F_kept, F_data any }

var A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000058_A struct{ j2g_header uint64 }

var A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A struct{ j2g_header uint64; F_k any }

var A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A struct{ j2g_header uint64; F_data, F_st, F_strs, F_want, F_b any }

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A struct{ j2g_header uint64; F_s__581000039, F_data, F_st, F_strs, F_iter__581000038, F_want, F_b any }

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A struct{ j2g_header uint64; F_b__581000041, F_data, F_st, F_strs, F_want any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b any }

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_place__581000070_A struct{ j2g_header uint64; F_places, F_o, F_secs any }

var A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_sec__581000018_A struct{ j2g_header uint64; F_shentsize, F_shoff int64; F_b any }

var A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class *jrt.Class



type A_arbace_box_elf_eval581000004_A struct{ jrt.Object }

func A_arbace_box_elf_eval581000004_A_New() *A_arbace_box_elf_eval581000004_A { t := &A_arbace_box_elf_eval581000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf_eval581000004_A) Ctor() {}

func (t *A_arbace_box_elf_eval581000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_eval581000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_eval581000004_A_class }

func (t *A_arbace_box_elf_eval581000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_eval581000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_elf_eval581000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_eval581000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_eval581000004_A); return ok }

func A_arbace_box_elf_eval581000004_A_Cast(x any) *A_arbace_box_elf_eval581000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_eval581000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_eval581000004_A_class)) }; return v }



type A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A struct{ j2g_header uint64 }

var A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_fn_class *jrt.Class



type A_arbace_box_elf_eval581000008_A struct{ jrt.Object }

func A_arbace_box_elf_eval581000008_A_New() *A_arbace_box_elf_eval581000008_A { t := &A_arbace_box_elf_eval581000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf_eval581000008_A) Ctor() {}

func (t *A_arbace_box_elf_eval581000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_eval581000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_eval581000008_A_class }

func (t *A_arbace_box_elf_eval581000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_eval581000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_elf_eval581000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_eval581000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_eval581000008_A); return ok }

func A_arbace_box_elf_eval581000008_A_Cast(x any) *A_arbace_box_elf_eval581000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_eval581000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_eval581000008_A_class)) }; return v }



type A_arbace_box_elf_eval581000008_fn__581000009_A struct{ j2g_header uint64 }

var A_arbace_box_elf_eval581000008_fn__581000009_A_fn_class *jrt.Class



type A_arbace_box_elf_fail_A struct{ j2g_header uint64 }

var A_arbace_box_elf_fail_A_fn_class *jrt.Class



type A_arbace_box_elf_le_A struct{ j2g_header uint64 }

var A_arbace_box_elf_le_A_fn_class *jrt.Class
