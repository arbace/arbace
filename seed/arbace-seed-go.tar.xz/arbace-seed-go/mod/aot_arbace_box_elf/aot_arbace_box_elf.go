//line aot_arbace_box_elf.ae:1
package aot_arbace_box_elf

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :3:1
func A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_New() *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) Ctor() {}
//line :3:1
func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_elf_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_box_elf_A_const_1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_20)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_21)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_22)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_23)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :3:1
func A_arbace_box_elf_eval581000008_fn__581000009_A_New() *A_arbace_box_elf_eval581000008_fn__581000009_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_eval581000008_fn__581000009_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) Ctor() {}
//line :3:1
func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_elf_A_const_2.GetRawRoot__O()); var tmp2 any; var root_5 any = A_arbace_box_elf_A_const_3.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_7 lang.IFn; if linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = A_arbace_box_elf_A_const_4; if linked_6 == nil { tmp2 = ifn_7.Invoke_O__O(arg_8) } else { tmp2 = linked_6.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_5, arg_8) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_box_elf_A_const_5.GetRawRoot__O(), A_arbace_box_elf_A_const_6) }











func A_arbace_box_elf_fail_A_New() *A_arbace_box_elf_fail_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_fail_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_box_elf_fail_A) Ctor() {}
//line :15:1
func (t *A_arbace_box_elf_fail_A) Invoke_O_O__O(self, msg__0 any) any { var tmp1 any; var root_15 any = A_arbace_box_elf_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_17 lang.IFn; if
									linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, msg__0)).Ref(); var arg_19 any = A_arbace_box_elf_A_const_8; if linked_16 == nil { tmp1 = ifn_17.Invoke_O_O__O(arg_18, arg_19) } else { tmp1 = linked_16.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_15, arg_18, arg_19) }; /*line :15:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }







func A_arbace_box_elf_le_A_New() *A_arbace_box_elf_le_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_le_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_box_elf_le_A) Ctor() {}
//line :23:1
func (t *A_arbace_box_elf_le_A) Invoke_O_O__O(self, b__0 any) any {
	var tmp1 jrt.ByteBuffer_I = jrt.ByteBuffer_Wrap_B1__ByteBuffer(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())); var tmp2 *jrt.ByteOrder; jrt.ByteOrder_Init(); tmp2 = jrt.ByteOrder_LITTLE_ENDIAN; return tmp1.Order_ByteOrder__ByteBuffer(tmp2)
}
func A_arbace_box_elf_c_string_A_New() *A_arbace_box_elf_c_string_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_c_string_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_box_elf_c_string_A) Ctor() {}
//line :26:1
func (t *A_arbace_box_elf_c_string_A) Invoke_O_O_O__O(self, b__0, p_off__1 any) any { { var off__1 int64 = lang.RT_LongCast_O__J_NoInit(p_off__1); var e__3 int64 = off__1; L1: for {

	if lang.Numbers_IsZero_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(e__3))).Ref())) { return jrt.String_New_B1_I_I_Charset(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(off__1), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(e__3, off__1)), jrt.StandardCharsets_UTF_8) } else {

		e__3 = lang.Numbers_Inc_J__J_NoInit(e__3); continue L1 } } }; /*line :26:1*/panic("j2g: unreachable") }





func A_arbace_box_elf_align_A_New() *A_arbace_box_elf_align_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_align_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_box_elf_align_A) Ctor() {}
//line :32:1
func (t *A_arbace_box_elf_align_A) Invoke_O_O_O__O(self, o__0, p_a__1 any) any { var a__1 int64 = lang.RT_LongCast_O__J_NoInit(p_a__1); if
										lang.Numbers_Gt_J_J__Z_NoInit(a__1, 1) { L1: for {
											var tmp1 any; var root_27 any = A_arbace_box_elf_A_const_9.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any; var tmp2 bool; var na_20 any; var root_21 any = A_arbace_box_elf_A_const_10.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_mod_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.ByteArrayOutputStream_Cast(o__0)).Size__I()).Ref(); var arg_25 any = jrt.Long_ValueOf_J__Long_NoInit(a__1).Ref(); if linked_22 == nil { na_20 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { na_20 = linked_22.(*aot_arbace_core.A_arbace_core_mod_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; if jrt.Long_InstanceOf(na_20) { var n0_26 int64 = jrt.NN(jrt.Long_Cast(na_20)).LongValue__J(); tmp2 = n0_26 == 0 } else { if jrt.Double_InstanceOf(na_20) { var n0_26_2 float64 = jrt.NN(jrt.Double_Cast(na_20)).DoubleValue__D(); tmp2 = n0_26_2 == 0.0 } else { tmp2 = lang.Numbers_IsZero_O__Z_NoInit(na_20) } }; arg_30 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref(); if linked_28 == nil { tmp1 = ifn_29.Invoke_O__O(arg_30) } else { tmp1 = linked_28.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_27, arg_30) }; if jrt.J2g_Truth(tmp1) {
												jrt.NN(jrt.ByteArrayOutputStream_Cast(o__0)).Write_I__V(lang.RT_IntCast_J__I_NoInit(0))
//line :34:1
			continue L1 }
//line :33:1
		break L1 } }; return o__0 }




func A_arbace_box_elf_cut_symbols_A_New() *A_arbace_box_elf_cut_symbols_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_box_elf_cut_symbols_A) Ctor() {}
//line :38:1
func (t *A_arbace_box_elf_cut_symbols_A) Invoke_O_O_O__O(self, data__0, names__1 any) any { var b__3 any; var root_31 any = A_arbace_box_elf_A_const_11.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, A_arbace_box_elf_le_A_fn_class); var ifn_33 lang.IFn; if


	linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = data__0; if linked_32 == nil { b__3 = ifn_33.Invoke_O__O(arg_34) } else { b__3 = linked_32.(*A_arbace_box_elf_le_A).Invoke_O_O__O(root_31, arg_34) }; var tmp1 bool; var and__1927000168__auto____4 bool =
	lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()))), 64); if and__1927000168__auto____4 { var and__1927000168__auto____5 bool = lang.Util_Equiv_J_J__Z_NoInit(127, lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0))).Ref())); if and__1927000168__auto____5 { var and__1927000168__auto____6 bool = lang.Util_Equiv_J_J__Z_NoInit(2, lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(4))).Ref())); if and__1927000168__auto____6 { tmp1 = lang.Util_Equiv_J_J__Z_NoInit(1, lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(5))).Ref())) } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if tmp1 { } else {
		var root_375 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, A_arbace_box_elf_fail_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = Lit_1; if linked_376 == nil { ifn_377.Invoke_O__O(arg_378) } else { linked_376.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_375, arg_378) } }; var phoff__4 int64 = /*line :38:1*/jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_J__I_NoInit(32)); var shoff__5 int64 = jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_J__I_NoInit(40)); var phentsize__6 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Short_ValueOf_S__Short_NoInit(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I_NoInit(54))).Ref()), 65535); var phnum__7 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Short_ValueOf_S__Short_NoInit(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I_NoInit(56))).Ref()), 65535); var shentsize__8 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Short_ValueOf_S__Short_NoInit(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I_NoInit(58))).Ref()), 65535); var shnum__9 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Short_ValueOf_S__Short_NoInit(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I_NoInit(60))).Ref()), 65535); var shstrndx__10 int64 = lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Short_ValueOf_S__Short_NoInit(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I_NoInit(62))).Ref()), 65535); var sec__11 any; var tmp2 any = A_arbace_box_elf_cut_symbols_sec__581000018_A_New_J_J_O(shentsize__8, shoff__5, b__3); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class; if









	fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; sec__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var secs__12 any; var root_80 any = /*line :38:1*/A_arbace_box_elf_A_const_18.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_82 lang.IFn; if













	linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = sec__11; var arg_84 any; var root_76 any = A_arbace_box_elf_A_const_19.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = jrt.Long_ValueOf_J__Long_NoInit(shnum__9).Ref(); if linked_77 == nil { arg_84 = ifn_78.Invoke_O__O(arg_79) } else { arg_84 = linked_77.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_76, arg_79) }; if linked_81 == nil { secs__12 = ifn_82.Invoke_O_O__O(arg_83, arg_84) } else { secs__12 = linked_81.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_80, arg_83, arg_84) }; var symtab__13 any; var root_91 any = /*line :38:1*/A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_93 lang.IFn; if














	linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any; var root_86 any = A_arbace_box_elf_A_const_21.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any; var tmp4 any = A_arbace_box_elf_cut_symbols_fn__581000020_A_New(); var tmp5 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class = fncls__85d; tmp5 = fncls__85d } else { tmp5 = fncls__85 }; arg_89 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_90 any = secs__12; if linked_87 == nil { arg_94 = ifn_88.Invoke_O_O__O(arg_89, arg_90) } else { arg_94 = linked_87.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_86, arg_89, arg_90) }; if linked_92 == nil { symtab__13 = ifn_93.Invoke_O__O(arg_94) } else { symtab__13 = linked_92.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_91, arg_94) }; var strtab__14 any; if
	jrt.J2g_Truth(symtab__13) { var tmp6 *lang.Keyword = A_arbace_box_elf_A_const_15; strtab__14 = tmp6.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(symtab__13)) } else { strtab__14 = nil }; var tmp7 bool; var or__1927000174__auto____15 bool =
	lang.Util_Identical_O_O__Z_NoInit(symtab__13, nil); if or__1927000174__auto____15 { tmp7 = or__1927000174__auto____15 } else { var or__1927000174__auto____16 bool; var na_379 any = strtab__14; var na_380 int64 = 0; if jrt.Long_InstanceOf(na_379) { var n0_381 int64 = jrt.NN(jrt.Long_Cast(na_379)).LongValue__J(); var n1_382 int64 = na_380; or__1927000174__auto____16 = n0_381 <= n1_382 } else { or__1927000174__auto____16 = lang.Numbers_Lte_O_J__Z_NoInit(na_379, na_380) }; if or__1927000174__auto____16 { tmp7 = or__1927000174__auto____16 } else { var or__1927000174__auto____17 bool; var na_384 any = strtab__14; var na_385 int64 = shnum__9; if jrt.Long_InstanceOf(na_384) { var n0_386 int64 = jrt.NN(jrt.Long_Cast(na_384)).LongValue__J(); var n1_387 int64 = na_385; or__1927000174__auto____17 = n0_386 >= n1_387 } else { or__1927000174__auto____17 = lang.Numbers_Gte_O_J__Z_NoInit(na_384, na_385) }; if or__1927000174__auto____17 { tmp7 = or__1927000174__auto____17 } else { var or__1927000174__auto____18 bool = lang.Numbers_Lte_J_J__Z_NoInit(shstrndx__10, 0); if or__1927000174__auto____18 { tmp7 = or__1927000174__auto____18 } else { tmp7 = lang.Numbers_Gte_J_J__Z_NoInit(shstrndx__10, shnum__9) } } } }; if tmp7 {
		var root_389 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, A_arbace_box_elf_fail_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = Lit_4; if linked_390 == nil { ifn_391.Invoke_O__O(arg_392) } else { linked_390.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_389, arg_392) } }; var tail__15 any; var root_96 any = /*line :38:1*/A_arbace_box_elf_A_const_23.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_98 lang.IFn; if


















	linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any; var tmp8 any = A_arbace_box_elf_cut_symbols_fn__581000022_A_New_O(secs__12); var tmp9 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class = fncls__95d; tmp9 = fncls__95d } else { tmp9 = fncls__95 }; arg_99 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_100 any = lang.Tuple_Create_O_O_O__IPersistentVector(symtab__13, strtab__14, jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref()); if linked_97 == nil { tail__15 = ifn_98.Invoke_O_O__O(arg_99, arg_100) } else { tail__15 = linked_97.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_96, arg_99, arg_100) }; var start__16 any; var tmp10 /*line :38:1*/*lang.Keyword = A_arbace_box_elf_A_const_13; var tmp11 lang.IFn = lang.IFn_Cast(secs__12); var tmp12 any; var root_393 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_395 lang.IFn; if



















	linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = tail__15; if linked_394 == nil { tmp12 = ifn_395.Invoke_O__O(arg_396) } else { tmp12 = linked_394.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_393, arg_396) }; start__16 = tmp10.Invoke_O__O(tmp11.Invoke_O__O(tmp12)); var tmp13 bool; var na_397 int64 =
	lang.Numbers_Add_J_J__J_NoInit(shoff__5, lang.Numbers_Multiply_J_J__J_NoInit(shnum__9, shentsize__8)); var na_398 any = start__16; if jrt.Long_InstanceOf(na_398) { var n0_399 int64 = na_397; var n1_400 int64 = jrt.NN(jrt.Long_Cast(na_398)).LongValue__J(); tmp13 = n0_399 > n1_400 } else { tmp13 = lang.Numbers_Gt_J_O__Z_NoInit(na_397, na_398) }; if tmp13 {
		var root_402 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, A_arbace_box_elf_fail_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = Lit_6; if linked_403 == nil { ifn_404.Invoke_O__O(arg_405) } else { linked_403.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_402, arg_405) } }; var seq_581000024__17 any; var root_411 any = /*line :38:1*/A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_413 lang.IFn; if






















	linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any; var root_406 any = A_arbace_box_elf_A_const_53.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = A_arbace_box_elf_A_const_54.GetRawRoot__O(); var arg_410 any = secs__12; if linked_407 == nil { arg_414 = ifn_408.Invoke_O_O__O(arg_409, arg_410) } else { arg_414 = linked_407.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_406, arg_409, arg_410) }; if linked_412 == nil { seq_581000024__17 = ifn_413.Invoke_O__O(arg_414) } else { seq_581000024__17 = linked_412.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_411, arg_414) }; var chunk_581000025__18 any; var count_581000026__19 int64 = 0; var i_581000027__20 int64 = 0; L1:
//line :38:1
	for {






















		if lang.Numbers_Lt_J_J__Z_NoInit(i_581000027__20, count_581000026__19) { var vec__581000028__21 any = lang.Indexed_Cast(chunk_581000025__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_581000027__20)); var i__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000028__21, lang.RT_IntCast_J__I_NoInit(0), nil); var s__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000028__21, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp14 any; var root_415 any = A_arbace_box_elf_A_const_9.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_417 lang.IFn
			if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any; var or__1927000174__auto____24 any = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, strtab__14, symtab__13, jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref()))).Invoke_O__O(i__22); if jrt.J2g_Truth(or__1927000174__auto____24) { arg_418 = or__1927000174__auto____24 } else { arg_418 = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_55.GetRawRoot__O(), A_arbace_box_elf_A_const_56.GetRawRoot__O()))).Invoke_O__O(A_arbace_box_elf_A_const_12.Invoke_O__O(s__23)) }; if linked_416 == nil { tmp14 = ifn_417.Invoke_O__O(arg_418) } else { tmp14 = linked_416.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_415, arg_418) }
//line :61:1
			if jrt.J2g_Truth(tmp14) {

				var tmp15 bool; var na_472 any; var na_474 any = A_arbace_box_elf_A_const_13.Invoke_O__O(s__23); var na_475 any = A_arbace_box_elf_A_const_14.Invoke_O__O(s__23); var tmp16 bool; var tmp17 bool; tmp17 = jrt.Long_InstanceOf(na_474); if tmp17 { tmp17 = jrt.Long_InstanceOf(na_475) }; tmp16 = tmp17; if tmp16 { var n0_476 int64 = jrt.NN(jrt.Long_Cast(na_474)).LongValue__J(); var n1_477 int64 = jrt.NN(jrt.Long_Cast(na_475)).LongValue__J(); var nr_478 int64 = n0_476 + n1_477; if (n0_476^nr_478)&(n1_477^nr_478) >= 0 { na_472 = jrt.Long_ValueOf_J__Long_NoInit(nr_478).Ref() } else { na_472 = lang.Numbers_Add_O_O__Number_NoInit(na_474, na_475) } } else { var tmp18 bool; var tmp19 bool; tmp19 = jrt.Double_InstanceOf(na_474); if tmp19 { tmp19 = jrt.Double_InstanceOf(na_475) }; tmp18 = tmp19; if tmp18 { var n0_476_2 float64 = jrt.NN(jrt.Double_Cast(na_474)).DoubleValue__D(); var n1_477_2 float64 = jrt.NN(jrt.Double_Cast(na_475)).DoubleValue__D(); na_472 = jrt.Double_ValueOf_D__Double_NoInit(n0_476_2 + n1_477_2).Ref() } else { na_472 = lang.Numbers_Add_O_O__Number_NoInit(na_474, na_475) } }; var na_473 any = start__16; var tmp20 bool; var tmp21 bool; tmp21 = jrt.Long_InstanceOf(na_472); if tmp21 { tmp21 = jrt.Long_InstanceOf(na_473) }; tmp20 = tmp21; if tmp20 { var n0_479 int64 = jrt.NN(jrt.Long_Cast(na_472)).LongValue__J(); var n1_480 int64 = jrt.NN(jrt.Long_Cast(na_473)).LongValue__J(); tmp15 = n0_479 > n1_480 } else { var tmp22 bool; var tmp23 bool; tmp23 = jrt.Double_InstanceOf(na_472); if tmp23 { tmp23 = jrt.Double_InstanceOf(na_473) }; tmp22 = tmp23; if tmp22 { var n0_479_2 float64 = jrt.NN(jrt.Double_Cast(na_472)).DoubleValue__D(); var n1_480_2 float64 = jrt.NN(jrt.Double_Cast(na_473)).DoubleValue__D(); tmp15 = n1_480_2 < n0_479_2 } else { tmp15 = lang.Numbers_Gt_O_O__Z_NoInit(na_472, na_473) } }; if tmp15 {
					var root_482 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, A_arbace_box_elf_fail_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = Lit_7; if linked_483 == nil { ifn_484.Invoke_O__O(arg_485) } else { linked_483.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_482, arg_485) } }
//line :61:1
				seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = seq_581000024__17, chunk_581000025__18, count_581000026__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000027__20); continue L1 } else { seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = seq_581000024__17, chunk_581000025__18, count_581000026__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000027__20); continue L1 } } else { var temp__1927000414__auto____21 any; var root_419 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = seq_581000024__17; if linked_420 == nil { temp__1927000414__auto____21 = ifn_421.Invoke_O__O(arg_422) } else { temp__1927000414__auto____21 = linked_420.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_419, arg_422) }; if jrt.J2g_Truth(temp__1927000414__auto____21) { var seq_581000024__22 any = temp__1927000414__auto____21; var tmp24 any; var root_423 any = A_arbace_box_elf_A_const_27.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any = seq_581000024__22; if linked_424 == nil { tmp24 = ifn_425.Invoke_O__O(arg_426) } else { tmp24 = linked_424.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_423, arg_426) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____23 any; var root_427 any = A_arbace_box_elf_A_const_28.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = seq_581000024__22; if linked_428 == nil { c__1927000678__auto____23 = ifn_429.Invoke_O__O(arg_430) } else { c__1927000678__auto____23 = linked_428.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_427, arg_430) }; var tmp25 any; var root_486 any = A_arbace_box_elf_A_const_36.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = seq_581000024__22; if linked_487 == nil { tmp25 = ifn_488.Invoke_O__O(arg_489) } else { tmp25 = linked_487.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_486, arg_489) }; seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = tmp25, c__1927000678__auto____23, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__581000031__23 any; var root_431 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = seq_581000024__22; if linked_432 == nil { vec__581000031__23 = ifn_433.Invoke_O__O(arg_434) } else { vec__581000031__23 = linked_432.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_431, arg_434) }; var i__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000031__23, lang.RT_IntCast_J__I_NoInit(0), nil); var s__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000031__23, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp26 any; var root_435 any = A_arbace_box_elf_A_const_9.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_437 lang.IFn
					if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any; var or__1927000174__auto____26 any = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, strtab__14, symtab__13, jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref()))).Invoke_O__O(i__24); if jrt.J2g_Truth(or__1927000174__auto____26) { arg_438 = or__1927000174__auto____26 } else { arg_438 = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_55.GetRawRoot__O(), A_arbace_box_elf_A_const_56.GetRawRoot__O()))).Invoke_O__O(A_arbace_box_elf_A_const_12.Invoke_O__O(s__25)) }; if linked_436 == nil { tmp26 = ifn_437.Invoke_O__O(arg_438) } else { tmp26 = linked_436.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_435, arg_438) }
//line :61:1
					if jrt.J2g_Truth(tmp26) {

						var tmp27 bool; var na_490 any; var na_492 any = A_arbace_box_elf_A_const_13.Invoke_O__O(s__25); var na_493 any = A_arbace_box_elf_A_const_14.Invoke_O__O(s__25); var tmp28 bool; var tmp29 bool; tmp29 = jrt.Long_InstanceOf(na_492); if tmp29 { tmp29 = jrt.Long_InstanceOf(na_493) }; tmp28 = tmp29; if tmp28 { var n0_494 int64 = jrt.NN(jrt.Long_Cast(na_492)).LongValue__J(); var n1_495 int64 = jrt.NN(jrt.Long_Cast(na_493)).LongValue__J(); var nr_496 int64 = n0_494 + n1_495; if (n0_494^nr_496)&(n1_495^nr_496) >= 0 { na_490 = jrt.Long_ValueOf_J__Long_NoInit(nr_496).Ref() } else { na_490 = lang.Numbers_Add_O_O__Number_NoInit(na_492, na_493) } } else { var tmp30 bool; var tmp31 bool; tmp31 = jrt.Double_InstanceOf(na_492); if tmp31 { tmp31 = jrt.Double_InstanceOf(na_493) }; tmp30 = tmp31; if tmp30 { var n0_494_2 float64 = jrt.NN(jrt.Double_Cast(na_492)).DoubleValue__D(); var n1_495_2 float64 = jrt.NN(jrt.Double_Cast(na_493)).DoubleValue__D(); na_490 = jrt.Double_ValueOf_D__Double_NoInit(n0_494_2 + n1_495_2).Ref() } else { na_490 = lang.Numbers_Add_O_O__Number_NoInit(na_492, na_493) } }; var na_491 any = start__16; var tmp32 bool; var tmp33 bool; tmp33 = jrt.Long_InstanceOf(na_490); if tmp33 { tmp33 = jrt.Long_InstanceOf(na_491) }; tmp32 = tmp33; if tmp32 { var n0_497 int64 = jrt.NN(jrt.Long_Cast(na_490)).LongValue__J(); var n1_498 int64 = jrt.NN(jrt.Long_Cast(na_491)).LongValue__J(); tmp27 = n0_497 > n1_498 } else { var tmp34 bool; var tmp35 bool; tmp35 = jrt.Double_InstanceOf(na_490); if tmp35 { tmp35 = jrt.Double_InstanceOf(na_491) }; tmp34 = tmp35; if tmp34 { var n0_497_2 float64 = jrt.NN(jrt.Double_Cast(na_490)).DoubleValue__D(); var n1_498_2 float64 = jrt.NN(jrt.Double_Cast(na_491)).DoubleValue__D(); tmp27 = n1_498_2 < n0_497_2 } else { tmp27 = lang.Numbers_Gt_O_O__Z_NoInit(na_490, na_491) } }; if tmp27 {
							var root_500 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, A_arbace_box_elf_fail_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = Lit_7; if linked_501 == nil { ifn_502.Invoke_O__O(arg_503) } else { linked_501.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_500, arg_503) } }
//line :61:1
						var tmp36 any; var root_504 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = seq_581000024__22; if linked_505 == nil { tmp36 = ifn_506.Invoke_O__O(arg_507) } else { tmp36 = linked_505.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_504, arg_507) }; seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = tmp36, nil, 0, 0; continue L1 } else { var tmp37 any; var root_508 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = seq_581000024__22; if linked_509 == nil { tmp37 = ifn_510.Invoke_O__O(arg_511) } else { tmp37 = linked_509.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_508, arg_511) }; seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = tmp37, nil, 0, 0; continue L1 } } } }
//line :38:1
		break L1 }; var seq_581000034__17 any; var root_443 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_445 lang.IFn; if


























	linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any; var root_439 any = A_arbace_box_elf_A_const_19.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = jrt.Long_ValueOf_J__Long_NoInit(phnum__7).Ref(); if linked_440 == nil { arg_446 = ifn_441.Invoke_O__O(arg_442) } else { arg_446 = linked_440.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_439, arg_442) }; if linked_444 == nil { seq_581000034__17 = ifn_445.Invoke_O__O(arg_446) } else { seq_581000034__17 = linked_444.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_443, arg_446) }; var chunk_581000035__18 any; var count_581000036__19 int64 = 0; var i_581000037__20 int64 = 0; L2:
//line :38:1
	for {


























		if lang.Numbers_Lt_J_J__Z_NoInit(i_581000037__20, count_581000036__19) { var i__21 any = lang.Indexed_Cast(chunk_581000035__18).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_581000037__20)); var h__22 any; var na_512 int64 = phoff__4; var na_513 any; var na_514 any = i__21; var na_515 int64 = phentsize__6
			if jrt.Long_InstanceOf(na_514) { var n0_516 int64 = jrt.NN(jrt.Long_Cast(na_514)).LongValue__J(); var n1_517 int64 = na_515; var nr_518 int64 = n0_516 * n1_517; var tmp38 bool; var tmp39 bool; var tmp40 bool; var tmp41 bool; tmp41 = n0_516 == -9223372036854775808; if tmp41 { tmp41 = n1_517 < 0 }; tmp40 = tmp41; tmp39 = !tmp40; if tmp39 { var tmp42 bool; tmp42 = n1_517 == 0; if !tmp42 { tmp42 = nr_518/n1_517 == n0_516 }; tmp39 = tmp42 }; tmp38 = tmp39; if tmp38 { na_513 = jrt.Long_ValueOf_J__Long_NoInit(nr_518).Ref() } else { na_513 = lang.Numbers_Multiply_O_J__Number_NoInit(na_514, na_515) } } else { na_513 = lang.Numbers_Multiply_O_J__Number_NoInit(na_514, na_515) }; if jrt.Long_InstanceOf(na_513) { var n0_519 int64 = na_512; var n1_520 int64 = jrt.NN(jrt.Long_Cast(na_513)).LongValue__J(); var nr_521 int64 = n0_519 + n1_520; if (n0_519^nr_521)&(n1_520^nr_521) >= 0 { h__22 = jrt.Long_ValueOf_J__Long_NoInit(nr_521).Ref() } else { h__22 = lang.Numbers_Add_J_O__Number_NoInit(na_512, na_513) } } else { h__22 = lang.Numbers_Add_J_O__Number_NoInit(na_512, na_513) }
			var tmp43 bool; var na_522 int64; var tmp44 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(b__3); var tmp45 jrt.Number_I; var na_524 any = h__22; var na_525 int64 = 8; if jrt.Long_InstanceOf(na_524) { var n0_526 int64 = jrt.NN(jrt.Long_Cast(na_524)).LongValue__J(); var n1_527 int64 = na_525; var nr_528 int64 = n0_526 + n1_527; if (n0_526^nr_528)&(n1_527^nr_528) >= 0 { tmp45 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_528)) } else { tmp45 = lang.Numbers_Add_O_J__Number_NoInit(na_524, na_525) } } else { tmp45 = lang.Numbers_Add_O_J__Number_NoInit(na_524, na_525) }; var tmp46 int64 = tmp44.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp45)); var tmp47 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(b__3); var tmp48 jrt.Number_I; var na_529 any = h__22; var na_530 int64 = 32; if jrt.Long_InstanceOf(na_529) { var n0_531 int64 = jrt.NN(jrt.Long_Cast(na_529)).LongValue__J(); var n1_532 int64 = na_530; var nr_533 int64 = n0_531 + n1_532; if (n0_531^nr_533)&(n1_532^nr_533) >= 0 { tmp48 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_533)) } else { tmp48 = lang.Numbers_Add_O_J__Number_NoInit(na_529, na_530) } } else { tmp48 = lang.Numbers_Add_O_J__Number_NoInit(na_529, na_530) }; na_522 = lang.Numbers_Add_J_J__J_NoInit(tmp46, tmp47.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp48))); var na_523 any = start__16; if jrt.Long_InstanceOf(na_523) { var n0_534 int64 = na_522; var n1_535 int64 = jrt.NN(jrt.Long_Cast(na_523)).LongValue__J(); tmp43 = n0_534 > n1_535 } else { tmp43 = lang.Numbers_Gt_J_O__Z_NoInit(na_522, na_523) }; if tmp43 {
				var root_537 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, A_arbace_box_elf_fail_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = Lit_8; if linked_538 == nil { ifn_539.Invoke_O__O(arg_540) } else { linked_538.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_537, arg_540) } }
//line :65:1
			seq_581000034__17, chunk_581000035__18, count_581000036__19, i_581000037__20 = seq_581000034__17, chunk_581000035__18, count_581000036__19, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000037__20); continue L2 } else { var temp__1927000414__auto____21_2 any; var root_447 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = seq_581000034__17; if linked_448 == nil { temp__1927000414__auto____21_2 = ifn_449.Invoke_O__O(arg_450) } else { temp__1927000414__auto____21_2 = linked_448.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_447, arg_450) }; if jrt.J2g_Truth(temp__1927000414__auto____21_2) { var seq_581000034__22 any = temp__1927000414__auto____21_2; var tmp49 any; var root_451 any = A_arbace_box_elf_A_const_27.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = seq_581000034__22; if linked_452 == nil { tmp49 = ifn_453.Invoke_O__O(arg_454) } else { tmp49 = linked_452.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_451, arg_454) }; if jrt.J2g_Truth(tmp49) { var c__1927000678__auto____23_2 any; var root_455 any = A_arbace_box_elf_A_const_28.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = seq_581000034__22; if linked_456 == nil { c__1927000678__auto____23_2 = ifn_457.Invoke_O__O(arg_458) } else { c__1927000678__auto____23_2 = linked_456.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_455, arg_458) }; var tmp50 any; var root_541 any = A_arbace_box_elf_A_const_36.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = seq_581000034__22; if linked_542 == nil { tmp50 = ifn_543.Invoke_O__O(arg_544) } else { tmp50 = linked_542.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_541, arg_544) }; seq_581000034__17, chunk_581000035__18, count_581000036__19, i_581000037__20 = tmp50, c__1927000678__auto____23_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____23_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var i__23 any; var root_459 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = seq_581000034__22; if linked_460 == nil { i__23 = ifn_461.Invoke_O__O(arg_462) } else { i__23 = linked_460.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_459, arg_462) }; var h__24 any; var na_545 int64 = phoff__4; var na_546 any; var na_547 any = i__23; var na_548 int64 = phentsize__6
				if jrt.Long_InstanceOf(na_547) { var n0_549 int64 = jrt.NN(jrt.Long_Cast(na_547)).LongValue__J(); var n1_550 int64 = na_548; var nr_551 int64 = n0_549 * n1_550; var tmp51 bool; var tmp52 bool; var tmp53 bool; var tmp54 bool; tmp54 = n0_549 == -9223372036854775808; if tmp54 { tmp54 = n1_550 < 0 }; tmp53 = tmp54; tmp52 = !tmp53; if tmp52 { var tmp55 bool; tmp55 = n1_550 == 0; if !tmp55 { tmp55 = nr_551/n1_550 == n0_549 }; tmp52 = tmp55 }; tmp51 = tmp52; if tmp51 { na_546 = jrt.Long_ValueOf_J__Long_NoInit(nr_551).Ref() } else { na_546 = lang.Numbers_Multiply_O_J__Number_NoInit(na_547, na_548) } } else { na_546 = lang.Numbers_Multiply_O_J__Number_NoInit(na_547, na_548) }; if jrt.Long_InstanceOf(na_546) { var n0_552 int64 = na_545; var n1_553 int64 = jrt.NN(jrt.Long_Cast(na_546)).LongValue__J(); var nr_554 int64 = n0_552 + n1_553; if (n0_552^nr_554)&(n1_553^nr_554) >= 0 { h__24 = jrt.Long_ValueOf_J__Long_NoInit(nr_554).Ref() } else { h__24 = lang.Numbers_Add_J_O__Number_NoInit(na_545, na_546) } } else { h__24 = lang.Numbers_Add_J_O__Number_NoInit(na_545, na_546) }
				var tmp56 bool; var na_555 int64; var tmp57 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(b__3); var tmp58 jrt.Number_I; var na_557 any = h__24; var na_558 int64 = 8; if jrt.Long_InstanceOf(na_557) { var n0_559 int64 = jrt.NN(jrt.Long_Cast(na_557)).LongValue__J(); var n1_560 int64 = na_558; var nr_561 int64 = n0_559 + n1_560; if (n0_559^nr_561)&(n1_560^nr_561) >= 0 { tmp58 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_561)) } else { tmp58 = lang.Numbers_Add_O_J__Number_NoInit(na_557, na_558) } } else { tmp58 = lang.Numbers_Add_O_J__Number_NoInit(na_557, na_558) }; var tmp59 int64 = tmp57.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp58)); var tmp60 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(b__3); var tmp61 jrt.Number_I; var na_562 any = h__24; var na_563 int64 = 32; if jrt.Long_InstanceOf(na_562) { var n0_564 int64 = jrt.NN(jrt.Long_Cast(na_562)).LongValue__J(); var n1_565 int64 = na_563; var nr_566 int64 = n0_564 + n1_565; if (n0_564^nr_566)&(n1_565^nr_566) >= 0 { tmp61 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_566)) } else { tmp61 = lang.Numbers_Add_O_J__Number_NoInit(na_562, na_563) } } else { tmp61 = lang.Numbers_Add_O_J__Number_NoInit(na_562, na_563) }; na_555 = lang.Numbers_Add_J_J__J_NoInit(tmp59, tmp60.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp61))); var na_556 any = start__16; if jrt.Long_InstanceOf(na_556) { var n0_567 int64 = na_555; var n1_568 int64 = jrt.NN(jrt.Long_Cast(na_556)).LongValue__J(); tmp56 = n0_567 > n1_568 } else { tmp56 = lang.Numbers_Gt_J_O__Z_NoInit(na_555, na_556) }; if tmp56 {
					var root_570 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, A_arbace_box_elf_fail_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = Lit_8; if linked_571 == nil { ifn_572.Invoke_O__O(arg_573) } else { linked_571.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_570, arg_573) } }
//line :65:1
				var tmp62 any; var root_574 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = seq_581000034__22; if linked_575 == nil { tmp62 = ifn_576.Invoke_O__O(arg_577) } else { tmp62 = linked_575.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_574, arg_577) }; seq_581000034__17, chunk_581000035__18, count_581000036__19, i_581000037__20 = tmp62, nil, 0, 0; continue L2 } } }
//line :38:1
		break L2 }; var l__17 any; var tmp63 lang.IFn = lang.IFn_Cast(secs__12); var tmp64 any; var root_578 any = A_arbace_box_elf_A_const_57.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_580 lang.IFn; if






























	linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = tail__15; if linked_579 == nil { tmp64 = ifn_580.Invoke_O__O(arg_581) } else { tmp64 = linked_579.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_578, arg_581) }; l__17 = tmp63.Invoke_O__O(tmp64); var tmp65 jrt.Number_I; var na_463 any =
	A_arbace_box_elf_A_const_13.Invoke_O__O(l__17); var na_464 any = A_arbace_box_elf_A_const_14.Invoke_O__O(l__17); var tmp66 bool; var tmp67 bool; tmp67 = jrt.Long_InstanceOf(na_463); if tmp67 { tmp67 = jrt.Long_InstanceOf(na_464) }; tmp66 = tmp67; if tmp66 { var n0_465 int64 = jrt.NN(jrt.Long_Cast(na_463)).LongValue__J(); var n1_466 int64 = jrt.NN(jrt.Long_Cast(na_464)).LongValue__J(); var nr_467 int64 = n0_465 + n1_466; if (n0_465^nr_467)&(n1_466^nr_467) >= 0 { tmp65 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_467)) } else { tmp65 = lang.Numbers_Add_O_O__Number_NoInit(na_463, na_464) } } else { var tmp68 bool; var tmp69 bool; tmp69 = jrt.Double_InstanceOf(na_463); if tmp69 { tmp69 = jrt.Double_InstanceOf(na_464) }; tmp68 = tmp69; if tmp68 { var n0_465_2 float64 = jrt.NN(jrt.Double_Cast(na_463)).DoubleValue__D(); var n1_466_2 float64 = jrt.NN(jrt.Double_Cast(na_464)).DoubleValue__D(); tmp65 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_465_2 + n1_466_2)) } else { tmp65 = lang.Numbers_Add_O_O__Number_NoInit(na_463, na_464) } }; if lang.Util_Equiv_O_J__Z_NoInit(tmp65, int64(lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass())))) { } else {
		var root_468 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, A_arbace_box_elf_fail_A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = Lit_9; if linked_469 == nil { ifn_470.Invoke_O__O(arg_471) } else { linked_469.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_468, arg_471) } }; var st__17 any = /*line :38:1*/lang.IFn_Cast(secs__12).Invoke_O__O(symtab__13); var tmp70 *lang.Keyword = A_arbace_box_elf_A_const_13; var strs__18 any = tmp70.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(strtab__14)); var n__19 any; var na_101 any = A_arbace_box_elf_A_const_14.Invoke_O__O(st__17); var na_102 int64 = 24; if



































	jrt.Long_InstanceOf(na_101) { var n0_103 int64 = jrt.NN(jrt.Long_Cast(na_101)).LongValue__J(); var n1_104 int64 = na_102; if n1_104 == 0 { n__19 = lang.Numbers_Quotient_O_J__Number_NoInit(na_101, na_102) } else { n__19 = jrt.Long_ValueOf_J__Long_NoInit(n0_103 / n1_104).Ref() } } else { n__19 = lang.Numbers_Quotient_O_J__Number_NoInit(na_101, na_102) }; var want__20 any; var root_106 any = /*line :38:1*/A_arbace_box_elf_A_const_24.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_108 lang.IFn; if




































	linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = names__1; if linked_107 == nil { want__20 = ifn_108.Invoke_O__O(arg_109) } else { want__20 = linked_107.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_106, arg_109) }; var kept__21 any; var root_218 any = /*line :38:1*/A_arbace_box_elf_A_const_25.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_220 lang.IFn; if





































	linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any; var iter__1927001039__auto____21 any; var tmp71 any = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_New_O_O_O_O_O(data__0, st__17, strs__18, want__20, b__3); var tmp72 *jrt.Class; var fncls__212 *jrt.Class = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class; if fncls__212 == nil { var fncls__212d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class = fncls__212d; tmp72 = fncls__212d } else { tmp72 = fncls__212 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp71, tmp72, nil); var tmp73 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____21); var tmp74 any; var root_213 any = A_arbace_box_elf_A_const_19.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = A_arbace_box_elf_A_const_39; var arg_217 any = n__19; if linked_214 == nil { tmp74 = ifn_215.Invoke_O_O__O(arg_216, arg_217) } else { tmp74 = linked_214.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_213, arg_216, arg_217) }; arg_221 = tmp73.Invoke_O__O(tmp74); if linked_219 == nil { kept__21 = ifn_220.Invoke_O__O(arg_221) } else { kept__21 = linked_219.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_218, arg_221) }; var ___22 any; var tmp75 any = /*line :38:1*/A_arbace_box_elf_cut_symbols_fn__581000052_A_New_O_O(kept__21, data__0); var tmp76 *jrt.Class; var fncls__300 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class; _ = ___22; if










































	fncls__300 == nil { var fncls__300d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class = fncls__300d; tmp76 = fncls__300d } else { tmp76 = fncls__300 }; ___22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp75, tmp76, nil).Invoke__O(); var missing__23 any; var root_315 any = /*line :38:1*/A_arbace_box_elf_A_const_44.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_317 lang.IFn; if













































	linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any; var root_310 any = A_arbace_box_elf_A_const_45.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any; var root_306 any = A_arbace_box_elf_A_const_24.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any; var root_301 any = A_arbace_box_elf_A_const_46.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = A_arbace_box_elf_A_const_32; var arg_305 any = kept__21; if linked_302 == nil { arg_309 = ifn_303.Invoke_O_O__O(arg_304, arg_305) } else { arg_309 = linked_302.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_301, arg_304, arg_305) }; if linked_307 == nil { arg_313 = ifn_308.Invoke_O__O(arg_309) } else { arg_313 = linked_307.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_306, arg_309) }; var arg_314 any = want__20; if linked_311 == nil { arg_318 = ifn_312.Invoke_O_O__O(arg_313, arg_314) } else { arg_318 = linked_311.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_310, arg_313, arg_314) }; if linked_316 == nil { missing__23 = ifn_317.Invoke_O__O(arg_318) } else { missing__23 = linked_316.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_315, arg_318) }; var ___24 any; var tmp77 any; var root_319 any = /*line :38:1*/A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_321 lang.IFn; _ = ___24; if














































	linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = missing__23; if linked_320 == nil { tmp77 = ifn_321.Invoke_O__O(arg_322) } else { tmp77 = linked_320.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_319, arg_322) }; if jrt.J2g_Truth(tmp77) { var root_327 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, A_arbace_box_elf_fail_A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any; var tmp78 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp79 any; var root_323 any = A_arbace_box_elf_A_const_25.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = missing__23; if linked_324 == nil { tmp79 = ifn_325.Invoke_O__O(arg_326) } else { tmp79 = linked_324.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_323, arg_326) }; arg_330 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp78, jrt.RefArrayOf(jrt.Object_class, nil, tmp79)).Ref(); if linked_328 == nil { ___24 = ifn_329.Invoke_O__O(arg_330) } else { ___24 = linked_328.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_327, arg_330) } } else { ___24 = nil }; var kept__25 any; var root_343 any = /*line :38:1*/A_arbace_box_elf_A_const_47.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_345 lang.IFn; if
















































	linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any; var tmp80 any = A_arbace_box_elf_cut_symbols_fn__581000058_A_New(); var tmp81 *jrt.Class; var fncls__342 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class; if fncls__342 == nil { var fncls__342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class = fncls__342d; tmp81 = fncls__342d } else { tmp81 = fncls__342 }; arg_346 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp80, tmp81, nil); var arg_347 any = lang.PersistentVector_EMPTY.Ref(); var arg_348 any = kept__21; if linked_344 == nil { kept__25 = ifn_345.Invoke_O_O_O__O(arg_346, arg_347, arg_348) } else { kept__25 = linked_344.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_343, arg_346, arg_347, arg_348) }; var strb__26 any = /*line :38:1*/jrt.ByteArrayOutputStream_New(); var symb__27 any = jrt.ByteArrayOutputStream_New();



















































	jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Write_I__V(lang.RT_IntCast_J__I_NoInit(0));
	jrt.OutputStream_Cast(symb__27).Write_B1__V(lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_elf_A_const_58)); var seq_581000062__28 any; var root_582 any = /*line :38:1*/A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_584 lang.IFn; if





















































	linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = kept__25; if linked_583 == nil { seq_581000062__28 = ifn_584.Invoke_O__O(arg_585) } else { seq_581000062__28 = linked_583.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_582, arg_585) }; var chunk_581000063__29 any; var count_581000064__30 int64 = 0; var i_581000065__31 int64 = 0; L3:
//line :38:1
	for {





















































		if lang.Numbers_Lt_J_J__Z_NoInit(i_581000065__31, count_581000064__30) { var map__581000066__32 any = lang.Indexed_Cast(chunk_581000063__29).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_581000065__31)); var map__581000066__33 any; if lang.ISeq_InstanceOf(map__581000066__32) { var tmp82 any; var root_586 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = map__581000066__32; if linked_587 == nil { tmp82 = ifn_588.Invoke_O__O(arg_589) } else { tmp82 = linked_587.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_586, arg_589) }; if jrt.J2g_Truth(tmp82) { var tmp83 any; var root_590 any = A_arbace_box_elf_A_const_41.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = map__581000066__32; if linked_591 == nil { tmp83 = ifn_592.Invoke_O__O(arg_593) } else { tmp83 = linked_591.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_590, arg_593) }; map__581000066__33 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp83, jrt.Object_class.ArrayClass())).Ref() } else { var tmp84 any; var root_594 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = map__581000066__32; if linked_595 == nil { tmp84 = ifn_596.Invoke_O__O(arg_597) } else { tmp84 = linked_595.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_594, arg_597) }; if jrt.J2g_Truth(tmp84) { var root_598 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = map__581000066__32; if linked_599 == nil { map__581000066__33 = ifn_600.Invoke_O__O(arg_601) } else { map__581000066__33 = linked_599.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_598, arg_601) } } else { map__581000066__33 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000066__33 = map__581000066__32 }; var name__34 any = lang.RT_Get_O_O__O_NoInit(map__581000066__33, A_arbace_box_elf_A_const_32); var entry__35 any = lang.RT_Get_O_O__O_NoInit(map__581000066__33, A_arbace_box_elf_A_const_33); var e__36 any = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_elf_A_const_58).Ref(); var eb__37 any; var root_634 any = A_arbace_box_elf_A_const_11.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, A_arbace_box_elf_le_A_fn_class); var ifn_636 lang.IFn

			if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = e__36; if linked_635 == nil { eb__37 = ifn_636.Invoke_O__O(arg_637) } else { eb__37 = linked_635.(*A_arbace_box_elf_le_A).Invoke_O_O__O(root_634, arg_637) }
			jrt.System_Arraycopy_O_I_O_I_I__V(data__0, lang.RT_IntCast_O__I_NoInit(entry__35), e__36, lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_J__I_NoInit(24))
			jrt.ByteBuffer_Cast(eb__37).PutInt_I_I__ByteBuffer(lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_I__I_NoInit(jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Size__I()))
			jrt.OutputStream_Cast(symb__27).Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](e__36, jrt.Prim_byte.ArrayClass()))
			jrt.OutputStream_Cast(strb__26).Write_B1__V(jrt.NN(jrt.String_Cast(name__34)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8))
			jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Write_I__V(lang.RT_IntCast_J__I_NoInit(0))
//line :92:1
			seq_581000062__28, chunk_581000063__29, count_581000064__30, i_581000065__31 = seq_581000062__28, chunk_581000063__29, count_581000064__30, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000065__31); continue L3 } else { var temp__1927000414__auto____32 any; var root_602 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = seq_581000062__28; if linked_603 == nil { temp__1927000414__auto____32 = ifn_604.Invoke_O__O(arg_605) } else { temp__1927000414__auto____32 = linked_603.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_602, arg_605) }; if jrt.J2g_Truth(temp__1927000414__auto____32) { var seq_581000062__33 any = temp__1927000414__auto____32; var tmp85 any; var root_606 any = A_arbace_box_elf_A_const_27.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = seq_581000062__33; if linked_607 == nil { tmp85 = ifn_608.Invoke_O__O(arg_609) } else { tmp85 = linked_607.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_606, arg_609) }; if jrt.J2g_Truth(tmp85) { var c__1927000678__auto____34 any; var root_610 any = A_arbace_box_elf_A_const_28.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = seq_581000062__33; if linked_611 == nil { c__1927000678__auto____34 = ifn_612.Invoke_O__O(arg_613) } else { c__1927000678__auto____34 = linked_611.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_610, arg_613) }; var tmp86 any; var root_638 any = A_arbace_box_elf_A_const_36.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = seq_581000062__33; if linked_639 == nil { tmp86 = ifn_640.Invoke_O__O(arg_641) } else { tmp86 = linked_639.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_638, arg_641) }; seq_581000062__28, chunk_581000063__29, count_581000064__30, i_581000065__31 = tmp86, c__1927000678__auto____34, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____34))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var map__581000068__34 any; var root_614 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = seq_581000062__33; if linked_615 == nil { map__581000068__34 = ifn_616.Invoke_O__O(arg_617) } else { map__581000068__34 = linked_615.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_614, arg_617) }; var map__581000068__35 any; if lang.ISeq_InstanceOf(map__581000068__34) { var tmp87 any; var root_618 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = map__581000068__34; if linked_619 == nil { tmp87 = ifn_620.Invoke_O__O(arg_621) } else { tmp87 = linked_619.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_618, arg_621) }; if jrt.J2g_Truth(tmp87) { var tmp88 any; var root_622 any = A_arbace_box_elf_A_const_41.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = map__581000068__34; if linked_623 == nil { tmp88 = ifn_624.Invoke_O__O(arg_625) } else { tmp88 = linked_623.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_622, arg_625) }; map__581000068__35 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp88, jrt.Object_class.ArrayClass())).Ref() } else { var tmp89 any; var root_626 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = map__581000068__34; if linked_627 == nil { tmp89 = ifn_628.Invoke_O__O(arg_629) } else { tmp89 = linked_627.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_626, arg_629) }; if jrt.J2g_Truth(tmp89) { var root_630 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = map__581000068__34; if linked_631 == nil { map__581000068__35 = ifn_632.Invoke_O__O(arg_633) } else { map__581000068__35 = linked_631.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_630, arg_633) } } else { map__581000068__35 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000068__35 = map__581000068__34 }; var name__36 any = lang.RT_Get_O_O__O_NoInit(map__581000068__35, A_arbace_box_elf_A_const_32); var entry__37 any = lang.RT_Get_O_O__O_NoInit(map__581000068__35, A_arbace_box_elf_A_const_33); var e__38 any = lang.Numbers_Byte_array_O__B1_NoInit(A_arbace_box_elf_A_const_58).Ref(); var eb__39 any; var root_642 any = A_arbace_box_elf_A_const_11.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, A_arbace_box_elf_le_A_fn_class); var ifn_644 lang.IFn

				if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = e__38; if linked_643 == nil { eb__39 = ifn_644.Invoke_O__O(arg_645) } else { eb__39 = linked_643.(*A_arbace_box_elf_le_A).Invoke_O_O__O(root_642, arg_645) }
				jrt.System_Arraycopy_O_I_O_I_I__V(data__0, lang.RT_IntCast_O__I_NoInit(entry__37), e__38, lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_J__I_NoInit(24))
				jrt.ByteBuffer_Cast(eb__39).PutInt_I_I__ByteBuffer(lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_I__I_NoInit(jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Size__I()))
				jrt.OutputStream_Cast(symb__27).Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](e__38, jrt.Prim_byte.ArrayClass()))
				jrt.OutputStream_Cast(strb__26).Write_B1__V(jrt.NN(jrt.String_Cast(name__36)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8))
				jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Write_I__V(lang.RT_IntCast_J__I_NoInit(0))
//line :92:1
				var tmp90 any; var root_646 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = seq_581000062__33; if linked_647 == nil { tmp90 = ifn_648.Invoke_O__O(arg_649) } else { tmp90 = linked_647.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_646, arg_649) }; seq_581000062__28, chunk_581000063__29, count_581000064__30, i_581000065__31 = tmp90, nil, 0, 0; continue L3 } } }
//line :38:1
		break L3 }; var o__28 any = jrt.ByteArrayOutputStream_New(); var ___29 any; _ = ___29;






























































	jrt.NN(jrt.ByteArrayOutputStream_Cast(o__28)).Write_B1_I_I__V(jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0), lang.RT_IntCast_O__I_NoInit(start__16)); ___29 = nil; var shstr__30 any; var tmp91 /*line :38:1*/*jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()); var tmp92 *lang.Keyword = A_arbace_box_elf_A_const_13; var tmp93 int32 = lang.RT_IntCast_O__I_NoInit(tmp92.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref()))); var tmp94 jrt.Number_I; var tmp95 *lang.Keyword = A_arbace_box_elf_A_const_13; var na_349 any = tmp95.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref())); var tmp96 *lang.Keyword = A_arbace_box_elf_A_const_14; var na_350 any = tmp96.Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref())); var tmp97 bool; var tmp98 bool; tmp98 =































































	jrt.Long_InstanceOf(na_349); if tmp98 { tmp98 = jrt.Long_InstanceOf(na_350) }; tmp97 = tmp98; if tmp97 { var n0_351 int64 = jrt.NN(jrt.Long_Cast(na_349)).LongValue__J(); var n1_352 int64 = jrt.NN(jrt.Long_Cast(na_350)).LongValue__J(); var nr_353 int64 = n0_351 + n1_352; if (n0_351^nr_353)&(n1_352^nr_353) >= 0 { tmp94 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_353)) } else { tmp94 = lang.Numbers_Add_O_O__Number_NoInit(na_349, na_350) } } else { var tmp99 bool; var tmp100 bool; tmp100 = jrt.Double_InstanceOf(na_349); if tmp100 { tmp100 = jrt.Double_InstanceOf(na_350) }; tmp99 = tmp100; if tmp99 { var n0_351_2 float64 = jrt.NN(jrt.Double_Cast(na_349)).DoubleValue__D(); var n1_352_2 float64 = jrt.NN(jrt.Double_Cast(na_350)).DoubleValue__D(); tmp94 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_351_2 + n1_352_2)) } else { tmp94 = lang.Numbers_Add_O_O__Number_NoInit(na_349, na_350) } }; shstr__30 = jrt.Arrays_CopyOfRange_B1_I_I__B1_NoInit(tmp91, tmp93, lang.RT_IntCast_O__I_NoInit(tmp94)).Ref(); var places__31 any; var root_354 any = /*line :38:1*/A_arbace_box_elf_A_const_49.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_356 lang.IFn; if
































































	linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_355 == nil { places__31 = ifn_356.Invoke_O__O(arg_357) } else { places__31 = linked_355.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_354, arg_357) }; var place__32 any; var tmp101 any = /*line :38:1*/A_arbace_box_elf_cut_symbols_place__581000070_A_New_O_O_O(places__31, o__28, secs__12); var tmp102 *jrt.Class; var fncls__370 *jrt.Class = A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class; if

































































	fncls__370 == nil { var fncls__370d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class = fncls__370d; tmp102 = fncls__370d } else { tmp102 = fncls__370 }; place__32 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp101, tmp102, nil);



	lang.IFn_Cast(place__32).Invoke_O_O__O(symtab__13, jrt.NN(jrt.ByteArrayOutputStream_Cast(symb__27)).ToByteArray__B1().Ref());
	lang.IFn_Cast(place__32).Invoke_O_O__O(strtab__14, jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).ToByteArray__B1().Ref());
	lang.IFn_Cast(place__32).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(shstrndx__10).Ref(), shstr__30); var out__33 any = /*line :38:1*/jrt.NN(jrt.ByteArrayOutputStream_Cast(o__28)).ToByteArray__B1().Ref(); var ob__34 any; var root_371 any = A_arbace_box_elf_A_const_11.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, A_arbace_box_elf_le_A_fn_class); var ifn_373 lang.IFn; if









































































	linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = out__33; if linked_372 == nil { ob__34 = ifn_373.Invoke_O__O(arg_374) } else { ob__34 = linked_372.(*A_arbace_box_elf_le_A).Invoke_O_O__O(root_371, arg_374) }; var seq_581000072__35 any; var root_654 any = /*line :38:1*/A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_656 lang.IFn; if










































































	linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any; var root_650 any = A_arbace_box_elf_A_const_3.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = places__31; if linked_651 == nil { arg_657 = ifn_652.Invoke_O__O(arg_653) } else { arg_657 = linked_651.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_650, arg_653) }; if linked_655 == nil { seq_581000072__35 = ifn_656.Invoke_O__O(arg_657) } else { seq_581000072__35 = linked_655.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_654, arg_657) }; var chunk_581000073__36 any; var count_581000074__37 int64 = 0; var i_581000075__38 int64 = 0; L4:
//line :38:1
	for {










































































		if lang.Numbers_Lt_J_J__Z_NoInit(i_581000075__38, count_581000074__37) { var vec__581000076__39 any = lang.Indexed_Cast(chunk_581000073__36).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_581000075__38)); var i__40 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000076__39, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__581000079__41 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000076__39, lang.RT_IntCast_J__I_NoInit(1), nil); var off__42 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000079__41, lang.RT_IntCast_J__I_NoInit(0), nil); var size__43 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000079__41, lang.RT_IntCast_J__I_NoInit(1), nil); var h__44 any; var na_689 int64 = shoff__5; var na_690 any; var na_691 any = i__40; var na_692 int64 = shentsize__8
			if jrt.Long_InstanceOf(na_691) { var n0_693 int64 = jrt.NN(jrt.Long_Cast(na_691)).LongValue__J(); var n1_694 int64 = na_692; var nr_695 int64 = n0_693 * n1_694; var tmp103 bool; var tmp104 bool; var tmp105 bool; var tmp106 bool; tmp106 = n0_693 == -9223372036854775808; if tmp106 { tmp106 = n1_694 < 0 }; tmp105 = tmp106; tmp104 = !tmp105; if tmp104 { var tmp107 bool; tmp107 = n1_694 == 0; if !tmp107 { tmp107 = nr_695/n1_694 == n0_693 }; tmp104 = tmp107 }; tmp103 = tmp104; if tmp103 { na_690 = jrt.Long_ValueOf_J__Long_NoInit(nr_695).Ref() } else { na_690 = lang.Numbers_Multiply_O_J__Number_NoInit(na_691, na_692) } } else { na_690 = lang.Numbers_Multiply_O_J__Number_NoInit(na_691, na_692) }; if jrt.Long_InstanceOf(na_690) { var n0_696 int64 = na_689; var n1_697 int64 = jrt.NN(jrt.Long_Cast(na_690)).LongValue__J(); var nr_698 int64 = n0_696 + n1_697; if (n0_696^nr_698)&(n1_697^nr_698) >= 0 { h__44 = jrt.Long_ValueOf_J__Long_NoInit(nr_698).Ref() } else { h__44 = lang.Numbers_Add_J_O__Number_NoInit(na_689, na_690) } } else { h__44 = lang.Numbers_Add_J_O__Number_NoInit(na_689, na_690) }
			var tmp108 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(ob__34); var tmp109 jrt.Number_I; var na_704 any = h__44; var na_705 int64 = 24; if jrt.Long_InstanceOf(na_704) { var n0_706 int64 = jrt.NN(jrt.Long_Cast(na_704)).LongValue__J(); var n1_707 int64 = na_705; var nr_708 int64 = n0_706 + n1_707; if (n0_706^nr_708)&(n1_707^nr_708) >= 0 { tmp109 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_708)) } else { tmp109 = lang.Numbers_Add_O_J__Number_NoInit(na_704, na_705) } } else { tmp109 = lang.Numbers_Add_O_J__Number_NoInit(na_704, na_705) }; tmp108.PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I_NoInit(tmp109), lang.RT_LongCast_O__J_NoInit(off__42))
			var tmp110 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(ob__34); var tmp111 jrt.Number_I; var na_699 any = h__44; var na_700 int64 = 32; if jrt.Long_InstanceOf(na_699) { var n0_701 int64 = jrt.NN(jrt.Long_Cast(na_699)).LongValue__J(); var n1_702 int64 = na_700; var nr_703 int64 = n0_701 + n1_702; if (n0_701^nr_703)&(n1_702^nr_703) >= 0 { tmp111 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_703)) } else { tmp111 = lang.Numbers_Add_O_J__Number_NoInit(na_699, na_700) } } else { tmp111 = lang.Numbers_Add_O_J__Number_NoInit(na_699, na_700) }; tmp110.PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I_NoInit(tmp111), lang.RT_LongCast_O__J_NoInit(size__43))
//line :113:1
			seq_581000072__35, chunk_581000073__36, count_581000074__37, i_581000075__38 = seq_581000072__35, chunk_581000073__36, count_581000074__37, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000075__38); continue L4 } else { var temp__1927000414__auto____39 any; var root_658 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = seq_581000072__35; if linked_659 == nil { temp__1927000414__auto____39 = ifn_660.Invoke_O__O(arg_661) } else { temp__1927000414__auto____39 = linked_659.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_658, arg_661) }; if jrt.J2g_Truth(temp__1927000414__auto____39) { var seq_581000072__40 any = temp__1927000414__auto____39; var tmp112 any; var root_662 any = A_arbace_box_elf_A_const_27.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_662, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_664 lang.IFn; if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = seq_581000072__40; if linked_663 == nil { tmp112 = ifn_664.Invoke_O__O(arg_665) } else { tmp112 = linked_663.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_662, arg_665) }; if jrt.J2g_Truth(tmp112) { var c__1927000678__auto____41 any; var root_666 any = A_arbace_box_elf_A_const_28.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = seq_581000072__40; if linked_667 == nil { c__1927000678__auto____41 = ifn_668.Invoke_O__O(arg_669) } else { c__1927000678__auto____41 = linked_667.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_666, arg_669) }; var tmp113 any; var root_709 any = A_arbace_box_elf_A_const_36.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = seq_581000072__40; if linked_710 == nil { tmp113 = ifn_711.Invoke_O__O(arg_712) } else { tmp113 = linked_710.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_709, arg_712) }; seq_581000072__35, chunk_581000073__36, count_581000074__37, i_581000075__38 = tmp113, c__1927000678__auto____41, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____41))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var vec__581000082__41 any; var root_670 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = seq_581000072__40; if linked_671 == nil { vec__581000082__41 = ifn_672.Invoke_O__O(arg_673) } else { vec__581000082__41 = linked_671.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_670, arg_673) }; var i__42 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000082__41, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__581000085__43 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000082__41, lang.RT_IntCast_J__I_NoInit(1), nil); var off__44 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000085__43, lang.RT_IntCast_J__I_NoInit(0), nil); var size__45 any = lang.RT_Nth_O_I_O__O_NoInit(vec__581000085__43, lang.RT_IntCast_J__I_NoInit(1), nil); var h__46 any; var na_713 int64 = shoff__5; var na_714 any; var na_715 any = i__42; var na_716 int64 = shentsize__8
				if jrt.Long_InstanceOf(na_715) { var n0_717 int64 = jrt.NN(jrt.Long_Cast(na_715)).LongValue__J(); var n1_718 int64 = na_716; var nr_719 int64 = n0_717 * n1_718; var tmp114 bool; var tmp115 bool; var tmp116 bool; var tmp117 bool; tmp117 = n0_717 == -9223372036854775808; if tmp117 { tmp117 = n1_718 < 0 }; tmp116 = tmp117; tmp115 = !tmp116; if tmp115 { var tmp118 bool; tmp118 = n1_718 == 0; if !tmp118 { tmp118 = nr_719/n1_718 == n0_717 }; tmp115 = tmp118 }; tmp114 = tmp115; if tmp114 { na_714 = jrt.Long_ValueOf_J__Long_NoInit(nr_719).Ref() } else { na_714 = lang.Numbers_Multiply_O_J__Number_NoInit(na_715, na_716) } } else { na_714 = lang.Numbers_Multiply_O_J__Number_NoInit(na_715, na_716) }; if jrt.Long_InstanceOf(na_714) { var n0_720 int64 = na_713; var n1_721 int64 = jrt.NN(jrt.Long_Cast(na_714)).LongValue__J(); var nr_722 int64 = n0_720 + n1_721; if (n0_720^nr_722)&(n1_721^nr_722) >= 0 { h__46 = jrt.Long_ValueOf_J__Long_NoInit(nr_722).Ref() } else { h__46 = lang.Numbers_Add_J_O__Number_NoInit(na_713, na_714) } } else { h__46 = lang.Numbers_Add_J_O__Number_NoInit(na_713, na_714) }
				var tmp119 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(ob__34); var tmp120 jrt.Number_I; var na_728 any = h__46; var na_729 int64 = 24; if jrt.Long_InstanceOf(na_728) { var n0_730 int64 = jrt.NN(jrt.Long_Cast(na_728)).LongValue__J(); var n1_731 int64 = na_729; var nr_732 int64 = n0_730 + n1_731; if (n0_730^nr_732)&(n1_731^nr_732) >= 0 { tmp120 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_732)) } else { tmp120 = lang.Numbers_Add_O_J__Number_NoInit(na_728, na_729) } } else { tmp120 = lang.Numbers_Add_O_J__Number_NoInit(na_728, na_729) }; tmp119.PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I_NoInit(tmp120), lang.RT_LongCast_O__J_NoInit(off__44))
				var tmp121 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(ob__34); var tmp122 jrt.Number_I; var na_723 any = h__46; var na_724 int64 = 32; if jrt.Long_InstanceOf(na_723) { var n0_725 int64 = jrt.NN(jrt.Long_Cast(na_723)).LongValue__J(); var n1_726 int64 = na_724; var nr_727 int64 = n0_725 + n1_726; if (n0_725^nr_727)&(n1_726^nr_727) >= 0 { tmp122 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_727)) } else { tmp122 = lang.Numbers_Add_O_J__Number_NoInit(na_723, na_724) } } else { tmp122 = lang.Numbers_Add_O_J__Number_NoInit(na_723, na_724) }; tmp121.PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I_NoInit(tmp122), lang.RT_LongCast_O__J_NoInit(size__45))
//line :113:1
				var tmp123 any; var root_733 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = seq_581000072__40; if linked_734 == nil { tmp123 = ifn_735.Invoke_O__O(arg_736) } else { tmp123 = linked_734.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_733, arg_736) }; seq_581000072__35, chunk_581000073__36, count_581000074__37, i_581000075__38 = tmp123, nil, 0, 0; continue L4 } } }
//line :38:1
		break L4 }; var tmp124 jrt.ByteBuffer_I =















































































	jrt.ByteBuffer_Cast(ob__34); var tmp125 jrt.Number_I; var na_674 any; var na_676 int64 = shoff__5; var na_677 any; var na_678 any = symtab__13; var na_679 int64 = shentsize__8; if jrt.Long_InstanceOf(na_678) { var n0_680 int64 = jrt.NN(jrt.Long_Cast(na_678)).LongValue__J(); var n1_681 int64 = na_679; var nr_682 int64 = n0_680 * n1_681; var tmp126 bool; var tmp127 bool; var tmp128 bool; var tmp129 bool; tmp129 = n0_680 == -9223372036854775808; if tmp129 { tmp129 = n1_681 < 0 }; tmp128 = tmp129; tmp127 = !tmp128; if tmp127 { var tmp130 bool; tmp130 = n1_681 == 0; if !tmp130 { tmp130 = nr_682/n1_681 == n0_680 }; tmp127 = tmp130 }; tmp126 = tmp127; if tmp126 { na_677 = jrt.Long_ValueOf_J__Long_NoInit(nr_682).Ref() } else { na_677 = lang.Numbers_Multiply_O_J__Number_NoInit(na_678, na_679) } } else { na_677 = lang.Numbers_Multiply_O_J__Number_NoInit(na_678, na_679) }; if jrt.Long_InstanceOf(na_677) { var n0_683 int64 = na_676; var n1_684 int64 = jrt.NN(jrt.Long_Cast(na_677)).LongValue__J(); var nr_685 int64 = n0_683 + n1_684; if (n0_683^nr_685)&(n1_684^nr_685) >= 0 { na_674 = jrt.Long_ValueOf_J__Long_NoInit(nr_685).Ref() } else { na_674 = lang.Numbers_Add_J_O__Number_NoInit(na_676, na_677) } } else { na_674 = lang.Numbers_Add_J_O__Number_NoInit(na_676, na_677) }; var na_675 int64 = 44; if jrt.Long_InstanceOf(na_674) { var n0_686 int64 = jrt.NN(jrt.Long_Cast(na_674)).LongValue__J(); var n1_687 int64 = na_675; var nr_688 int64 = n0_686 + n1_687; if (n0_686^nr_688)&(n1_687^nr_688) >= 0 { tmp125 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_688)) } else { tmp125 = lang.Numbers_Add_O_J__Number_NoInit(na_674, na_675) } } else { tmp125 = lang.Numbers_Add_O_J__Number_NoInit(na_674, na_675) }; tmp124.PutInt_I_I__ByteBuffer(lang.RT_IntCast_O__I_NoInit(tmp125), lang.RT_IntCast_J__I_NoInit(1)); return out__33 }
//line :48:1
func A_arbace_box_elf_cut_symbols_sec__581000018_A_New_J_J_O(p0, p1 int64, p2 any) *A_arbace_box_elf_cut_symbols_sec__581000018_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_sec__581000018_A{}; t.Ctor_J_J_O(p0, p1, p2); return t }
//line :48:1
func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) Ctor_J_J_O(c__shentsize, c__shoff int64, c__b any) { t.F_shentsize = c__shentsize; t.F_shoff = c__shoff; t.F_b = c__b }
//line :48:1
func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) Invoke_O_O__O(self, i__1 any) any { var h__2 any; var na_35 int64 = t.F_shoff; var na_36 any; var na_37 any = i__1; var na_38 int64 = t.F_shentsize; if jrt.Long_InstanceOf(na_37) { var n0_39 int64 = jrt.NN(jrt.Long_Cast(na_37)).LongValue__J(); var n1_40 int64 = na_38; var nr_41 int64 = n0_39 * n1_40; var tmp1 bool; var tmp2 bool; var tmp3 bool; var tmp4 bool; tmp4 = n0_39 == -9223372036854775808; if tmp4 { tmp4 = n1_40 < 0 }; tmp3 = tmp4; tmp2 = !tmp3; if tmp2 { var tmp5 bool; tmp5 = n1_40 == 0; if !tmp5 { tmp5 = nr_41/n1_40 == n0_39 }; tmp2 = tmp5 }; tmp1 = tmp2; if tmp1 { na_36 = jrt.Long_ValueOf_J__Long_NoInit(nr_41).Ref() } else { na_36 = lang.Numbers_Multiply_O_J__Number_NoInit(na_37, na_38) } } else { na_36 = lang.Numbers_Multiply_O_J__Number_NoInit(na_37, na_38) }; if jrt.Long_InstanceOf(na_36) { var n0_42 int64 = na_35; var n1_43 int64 = jrt.NN(jrt.Long_Cast(na_36)).LongValue__J(); var nr_44 int64 = n0_42 + n1_43; if (n0_42^nr_44)&(n1_43^nr_44) >= 0 { h__2 = jrt.Long_ValueOf_J__Long_NoInit(nr_44).Ref() } else { h__2 = lang.Numbers_Add_J_O__Number_NoInit(na_35, na_36) } } else { h__2 = lang.Numbers_Add_J_O__Number_NoInit(na_35, na_36) }; var tmp6 any = A_arbace_box_elf_A_const_12; var tmp7 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp8 jrt.Number_I; var na_45 any = h__2; var na_46 int64 = 4; if
												jrt.Long_InstanceOf(na_45) { var n0_47 int64 = jrt.NN(jrt.Long_Cast(na_45)).LongValue__J(); var n1_48 int64 = na_46; var nr_49 int64 = n0_47 + n1_48; if (n0_47^nr_49)&(n1_48^nr_49) >= 0 { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_49)) } else { tmp8 = lang.Numbers_Add_O_J__Number_NoInit(na_45, na_46) } } else { tmp8 = lang.Numbers_Add_O_J__Number_NoInit(na_45, na_46) }; var tmp9 any = /*line :48:1*/jrt.Integer_ValueOf_I__Integer_NoInit(tmp7.GetInt_I__I(lang.RT_IntCast_O__I_NoInit(tmp8))).Ref(); var tmp10 any = A_arbace_box_elf_A_const_13; var tmp11 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp12 jrt.Number_I; var na_50 any = h__2; var na_51 int64 = 24; if
												jrt.Long_InstanceOf(na_50) { var n0_52 int64 = jrt.NN(jrt.Long_Cast(na_50)).LongValue__J(); var n1_53 int64 = na_51; var nr_54 int64 = n0_52 + n1_53; if (n0_52^nr_54)&(n1_53^nr_54) >= 0 { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_54)) } else { tmp12 = lang.Numbers_Add_O_J__Number_NoInit(na_50, na_51) } } else { tmp12 = lang.Numbers_Add_O_J__Number_NoInit(na_50, na_51) }; var tmp13 any = /*line :48:1*/jrt.Long_ValueOf_J__Long_NoInit(tmp11.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp12))).Ref(); var tmp14 any = A_arbace_box_elf_A_const_14; var tmp15 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp16 jrt.Number_I; var na_55 any = h__2; var na_56 int64 = 32; if

	jrt.Long_InstanceOf(na_55) { var n0_57 int64 = jrt.NN(jrt.Long_Cast(na_55)).LongValue__J(); var n1_58 int64 = na_56; var nr_59 int64 = n0_57 + n1_58; if (n0_57^nr_59)&(n1_58^nr_59) >= 0 { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_59)) } else { tmp16 = lang.Numbers_Add_O_J__Number_NoInit(na_55, na_56) } } else { tmp16 = lang.Numbers_Add_O_J__Number_NoInit(na_55, na_56) }; var tmp17 any = /*line :48:1*/jrt.Long_ValueOf_J__Long_NoInit(tmp15.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp16))).Ref(); var tmp18 any = A_arbace_box_elf_A_const_15; var tmp19 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp20 jrt.Number_I; var na_60 any = h__2; var na_61 int64 = 40; if

	jrt.Long_InstanceOf(na_60) { var n0_62 int64 = jrt.NN(jrt.Long_Cast(na_60)).LongValue__J(); var n1_63 int64 = na_61; var nr_64 int64 = n0_62 + n1_63; if (n0_62^nr_64)&(n1_63^nr_64) >= 0 { tmp20 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_64)) } else { tmp20 = lang.Numbers_Add_O_J__Number_NoInit(na_60, na_61) } } else { tmp20 = lang.Numbers_Add_O_J__Number_NoInit(na_60, na_61) }; var tmp21 any = /*line :48:1*/jrt.Integer_ValueOf_I__Integer_NoInit(tmp19.GetInt_I__I(lang.RT_IntCast_O__I_NoInit(tmp20))).Ref(); var tmp22 any = A_arbace_box_elf_A_const_16; var tmp23 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp24 jrt.Number_I; var na_65 any = h__2; var na_66 int64 = 48; if


	jrt.Long_InstanceOf(na_65) { var n0_67 int64 = jrt.NN(jrt.Long_Cast(na_65)).LongValue__J(); var n1_68 int64 = na_66; var nr_69 int64 = n0_67 + n1_68; if (n0_67^nr_69)&(n1_68^nr_69) >= 0 { tmp24 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_69)) } else { tmp24 = lang.Numbers_Add_O_J__Number_NoInit(na_65, na_66) } } else { tmp24 = lang.Numbers_Add_O_J__Number_NoInit(na_65, na_66) }; var tmp25 any = /*line :48:1*/jrt.Long_ValueOf_J__Long_NoInit(tmp23.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp24))).Ref(); var tmp26 any = A_arbace_box_elf_A_const_17; var tmp27 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp28 jrt.Number_I; var na_70 any = h__2; var na_71 int64 = 56; if


	jrt.Long_InstanceOf(na_70) { var n0_72 int64 = jrt.NN(jrt.Long_Cast(na_70)).LongValue__J(); var n1_73 int64 = na_71; var nr_74 int64 = n0_72 + n1_73; if (n0_72^nr_74)&(n1_73^nr_74) >= 0 { tmp28 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_74)) } else { tmp28 = lang.Numbers_Add_O_J__Number_NoInit(na_70, na_71) } } else { tmp28 = lang.Numbers_Add_O_J__Number_NoInit(na_70, na_71) }; return /*line :48:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp9, tmp10, tmp13, tmp14, tmp17, tmp18, tmp21, tmp22, tmp25, tmp26, jrt.Long_ValueOf_J__Long_NoInit(tmp27.GetLong_I__J(lang.RT_IntCast_O__I_NoInit(tmp28))).Ref())) }




func A_arbace_box_elf_cut_symbols_fn__581000020_A_New() *A_arbace_box_elf_cut_symbols_fn__581000020_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000020_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) Ctor() {}
//line :53:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) Invoke_O_O_O__O(self, i__1, s__2 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_box_elf_A_const_22.GetRawRoot__O(), A_arbace_box_elf_A_const_12.Invoke_O__O(s__2)) { return i__1 } else { return nil } }



func A_arbace_box_elf_cut_symbols_fn__581000022_A_New_O(p0 any) *A_arbace_box_elf_cut_symbols_fn__581000022_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000022_A{}; t.Ctor_O(p0); return t }
//line :57:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) Ctor_O(c__secs any) { t.F_secs = c__secs }
//line :57:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) Invoke_O_O__O(self, p1__581000016_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_box_elf_A_const_13; return tmp1.Invoke_O__O(lang.IFn_Cast(t.F_secs).Invoke_O__O(p1__581000016_SHARP___1)) }


















func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) Ctor_O_O_O_O_O(c__data, c__st, c__strs, c__want, c__b any) { t.F_data = c__data; t.F_st = c__st; t.F_strs = c__strs; t.F_want = c__want; t.F_b = c__b }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) Invoke_O_O__O(self, s__581000039__1 any) any { var tmp1 any = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_New_O_O_O_O_O_O_O(s__581000039__1, t.F_data, t.F_st, t.F_strs, self, t.F_want, t.F_b); var tmp2 *jrt.Class; var fncls__211 *jrt.Class = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class; if fncls__211 == nil { var fncls__211d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class = fncls__211d; tmp2 = fncls__211d } else { tmp2 = fncls__211 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :76:1
func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) Ctor_O_O_O_O_O_O_O(c__s__581000039, c__data, c__st, c__strs, c__iter__581000038, c__want, c__b any) { t.F_s__581000039 = c__s__581000039; t.F_data = c__data; t.F_st = c__st; t.F_strs = c__strs; t.F_iter__581000038 = c__iter__581000038; t.F_want = c__want; t.F_b = c__b }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) Invoke_O__O(self any) any { { var s__581000039__1 any; var t_ any = t.F_s__581000039; t.F_s__581000039 = nil; s__581000039__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_110 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = s__581000039__1; if linked_111 == nil { temp__1927000414__auto____2 = ifn_112.Invoke_O__O(arg_113) } else { temp__1927000414__auto____2 = linked_111.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_110, arg_113) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__581000039__3 any = temp__1927000414__auto____2; var tmp1 any; var root_114 any = A_arbace_box_elf_A_const_27.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = s__581000039__3; if linked_115 == nil { tmp1 = ifn_116.Invoke_O__O(arg_117) } else { tmp1 = linked_115.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_114, arg_117) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_118 any = A_arbace_box_elf_A_const_28.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = s__581000039__3; if linked_119 == nil { c__1927001037__auto____4 = ifn_120.Invoke_O__O(arg_121) } else { c__1927001037__auto____4 = linked_119.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_118, arg_121) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__581000041__6 any; var root_122 any = A_arbace_box_elf_A_const_29.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_123 == nil { b__581000041__6 = ifn_124.Invoke_O__O(arg_125) } else { b__581000041__6 = linked_123.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_122, arg_125) }; var tmp2 any = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_New_O_O_O_O_O_I_O_O(b__581000041__6, t.F_data, t.F_st, t.F_strs, t.F_want, size__1927001038__auto____5, c__1927001037__auto____4, t.F_b); var tmp3 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class = fncls__151d; tmp3 = fncls__151d } else { tmp3 = fncls__151 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_160 any = A_arbace_box_elf_A_const_34.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any; var root_152 any = A_arbace_box_elf_A_const_35.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = b__581000041__6; if linked_153 == nil { arg_163 = ifn_154.Invoke_O__O(arg_155) } else { arg_163 = linked_153.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_152, arg_155) }; var arg_164 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__581000038); var tmp5 any; var root_156 any = A_arbace_box_elf_A_const_36.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = s__581000039__3; if linked_157 == nil { tmp5 = ifn_158.Invoke_O__O(arg_159) } else { tmp5 = linked_157.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_156, arg_159) }; arg_164 = tmp4.Invoke_O__O(tmp5); if linked_161 == nil { return ifn_162.Invoke_O_O__O(arg_163, arg_164) } else { return linked_161.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_160, arg_163, arg_164) } } else { var root_169 any = A_arbace_box_elf_A_const_34.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any; var root_165 any = A_arbace_box_elf_A_const_35.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = b__581000041__6; if linked_166 == nil { arg_172 = ifn_167.Invoke_O__O(arg_168) } else { arg_172 = linked_166.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_165, arg_168) }; var arg_173 any; if linked_170 == nil { return ifn_171.Invoke_O_O__O(arg_172, arg_173) } else { return linked_170.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_169, arg_172, arg_173) } } } else { var i__4 any; var root_174 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = s__581000039__3; if linked_175 == nil { i__4 = ifn_176.Invoke_O__O(arg_177) } else { i__4 = linked_175.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_174, arg_177) }; var e__5 any; var na_178 any = A_arbace_box_elf_A_const_13.Invoke_O__O(t.F_st); var na_179 any; var na_180 int64 = 24; var na_181 any = i__4
														if jrt.Long_InstanceOf(na_181) { var n0_182 int64 = na_180; var n1_183 int64 = jrt.NN(jrt.Long_Cast(na_181)).LongValue__J(); var nr_184 int64 = n0_182 * n1_183; var tmp6 bool; var tmp7 bool; var tmp8 bool; var tmp9 bool; tmp9 = n0_182 == -9223372036854775808; if tmp9 { tmp9 = n1_183 < 0 }; tmp8 = tmp9; tmp7 = !tmp8; if tmp7 { var tmp10 bool; tmp10 = n1_183 == 0; if !tmp10 { tmp10 = nr_184/n1_183 == n0_182 }; tmp7 = tmp10 }; tmp6 = tmp7; if tmp6 { na_179 = jrt.Long_ValueOf_J__Long_NoInit(nr_184).Ref() } else { na_179 = lang.Numbers_Multiply_J_O__Number_NoInit(na_180, na_181) } } else { na_179 = lang.Numbers_Multiply_J_O__Number_NoInit(na_180, na_181) }; var tmp11 bool; var tmp12 bool; tmp12 = jrt.Long_InstanceOf(na_178); if tmp12 { tmp12 = jrt.Long_InstanceOf(na_179) }; tmp11 = tmp12; if tmp11 { var n0_185 int64 = jrt.NN(jrt.Long_Cast(na_178)).LongValue__J(); var n1_186 int64 = jrt.NN(jrt.Long_Cast(na_179)).LongValue__J(); var nr_187 int64 = n0_185 + n1_186; if (n0_185^nr_187)&(n1_186^nr_187) >= 0 { e__5 = jrt.Long_ValueOf_J__Long_NoInit(nr_187).Ref() } else { e__5 = lang.Numbers_Add_O_O__Number_NoInit(na_178, na_179) } } else { var tmp13 bool; var tmp14 bool; tmp14 = jrt.Double_InstanceOf(na_178); if tmp14 { tmp14 = jrt.Double_InstanceOf(na_179) }; tmp13 = tmp14; if tmp13 { var n0_185_2 float64 = jrt.NN(jrt.Double_Cast(na_178)).DoubleValue__D(); var n1_186_2 float64 = jrt.NN(jrt.Double_Cast(na_179)).DoubleValue__D(); e__5 = jrt.Double_ValueOf_D__Double_NoInit(n0_185_2 + n1_186_2).Ref() } else { e__5 = lang.Numbers_Add_O_O__Number_NoInit(na_178, na_179) } }
//line :76:1
	var nm__6 any; var root_193 any = A_arbace_box_elf_A_const_30.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, A_arbace_box_elf_c_string_A_fn_class); var ifn_195 lang.IFn

	if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = t.F_data; var arg_197 any; var na_188 any = t.F_strs; var tmp15 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var na_189 int64 = lang.Numbers_And_J_J__J_NoInit(int64(tmp15.GetInt_I__I(lang.RT_IntCast_O__I_NoInit(e__5))), 4294967295); if jrt.Long_InstanceOf(na_188) { var n0_190 int64 = jrt.NN(jrt.Long_Cast(na_188)).LongValue__J(); var n1_191 int64 = na_189; var nr_192 int64 = n0_190 + n1_191; if (n0_190^nr_192)&(n1_191^nr_192) >= 0 { arg_197 = jrt.Long_ValueOf_J__Long_NoInit(nr_192).Ref() } else { arg_197 = lang.Numbers_Add_O_J__Number_NoInit(na_188, na_189) } } else { arg_197 = lang.Numbers_Add_O_J__Number_NoInit(na_188, na_189) }; if linked_194 == nil { nm__6 = ifn_195.Invoke_O_O__O(arg_196, arg_197) } else { nm__6 = linked_194.(*A_arbace_box_elf_c_string_A).Invoke_O_O_O__O(root_193, arg_196, arg_197) }
//line :76:1
	if jrt.J2g_Truth(lang.IFn_Cast(t.F_want).Invoke_O__O(nm__6)) { var root_202 any = A_arbace_box_elf_A_const_37.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_32, nm__6, A_arbace_box_elf_A_const_33, e__5)); var arg_206 any; var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__581000038); var tmp17 any; var root_198 any = A_arbace_box_elf_A_const_38.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = s__581000039__3; if linked_199 == nil { tmp17 = ifn_200.Invoke_O__O(arg_201) } else { tmp17 = linked_199.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_198, arg_201) }; arg_206 = tmp16.Invoke_O__O(tmp17); if linked_203 == nil { return ifn_204.Invoke_O_O__O(arg_205, arg_206) } else { return linked_203.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_202, arg_205, arg_206) } } else { var tmp18 any; var root_207 any = A_arbace_box_elf_A_const_38.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = s__581000039__3; if linked_208 == nil { tmp18 = ifn_209.Invoke_O__O(arg_210) } else { tmp18 = linked_208.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_207, arg_210) }; s__581000039__1 = tmp18; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :76:1
func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_New_O_O_O_O_O_I_O_O(p0, p1, p2, p3, p4 any, p5 int32, p6, p7 any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A{}; t.Ctor_O_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) Ctor_O_O_O_O_O_I_O_O(c__b__581000041, c__data, c__st, c__strs, c__want any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b any) { t.F_b__581000041 = c__b__581000041; t.F_data = c__data; t.F_st = c__st; t.F_strs = c__strs; t.F_want = c__want; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b = c__b }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) Invoke_O__O(self any) any { { var i__581000040__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__581000040__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__581000040__1)); var e__3 any; var na_126 any = A_arbace_box_elf_A_const_13.Invoke_O__O(t.F_st); var na_127 any; var na_128 int64 = 24; var na_129 any = i__2
																if jrt.Long_InstanceOf(na_129) { var n0_130 int64 = na_128; var n1_131 int64 = jrt.NN(jrt.Long_Cast(na_129)).LongValue__J(); var nr_132 int64 = n0_130 * n1_131; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = n0_130 == -9223372036854775808; if tmp5 { tmp5 = n1_131 < 0 }; tmp4 = tmp5; tmp3 = !tmp4; if tmp3 { var tmp6 bool; tmp6 = n1_131 == 0; if !tmp6 { tmp6 = nr_132/n1_131 == n0_130 }; tmp3 = tmp6 }; tmp2 = tmp3; if tmp2 { na_127 = jrt.Long_ValueOf_J__Long_NoInit(nr_132).Ref() } else { na_127 = lang.Numbers_Multiply_J_O__Number_NoInit(na_128, na_129) } } else { na_127 = lang.Numbers_Multiply_J_O__Number_NoInit(na_128, na_129) }; var tmp7 bool; var tmp8 bool; tmp8 = jrt.Long_InstanceOf(na_126); if tmp8 { tmp8 = jrt.Long_InstanceOf(na_127) }; tmp7 = tmp8; if tmp7 { var n0_133 int64 = jrt.NN(jrt.Long_Cast(na_126)).LongValue__J(); var n1_134 int64 = jrt.NN(jrt.Long_Cast(na_127)).LongValue__J(); var nr_135 int64 = n0_133 + n1_134; if (n0_133^nr_135)&(n1_134^nr_135) >= 0 { e__3 = jrt.Long_ValueOf_J__Long_NoInit(nr_135).Ref() } else { e__3 = lang.Numbers_Add_O_O__Number_NoInit(na_126, na_127) } } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_126); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_127) }; tmp9 = tmp10; if tmp9 { var n0_133_2 float64 = jrt.NN(jrt.Double_Cast(na_126)).DoubleValue__D(); var n1_134_2 float64 = jrt.NN(jrt.Double_Cast(na_127)).DoubleValue__D(); e__3 = jrt.Double_ValueOf_D__Double_NoInit(n0_133_2 + n1_134_2).Ref() } else { e__3 = lang.Numbers_Add_O_O__Number_NoInit(na_126, na_127) } }
//line :76:1
	var nm__4 any; var root_141 any = A_arbace_box_elf_A_const_30.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, A_arbace_box_elf_c_string_A_fn_class); var ifn_143 lang.IFn

	if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = t.F_data; var arg_145 any; var na_136 any = t.F_strs; var tmp11 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var na_137 int64 = lang.Numbers_And_J_J__J_NoInit(int64(tmp11.GetInt_I__I(lang.RT_IntCast_O__I_NoInit(e__3))), 4294967295); if jrt.Long_InstanceOf(na_136) { var n0_138 int64 = jrt.NN(jrt.Long_Cast(na_136)).LongValue__J(); var n1_139 int64 = na_137; var nr_140 int64 = n0_138 + n1_139; if (n0_138^nr_140)&(n1_139^nr_140) >= 0 { arg_145 = jrt.Long_ValueOf_J__Long_NoInit(nr_140).Ref() } else { arg_145 = lang.Numbers_Add_O_J__Number_NoInit(na_136, na_137) } } else { arg_145 = lang.Numbers_Add_O_J__Number_NoInit(na_136, na_137) }; if linked_142 == nil { nm__4 = ifn_143.Invoke_O_O__O(arg_144, arg_145) } else { nm__4 = linked_142.(*A_arbace_box_elf_c_string_A).Invoke_O_O_O__O(root_141, arg_144, arg_145) }
//line :76:1
	if jrt.J2g_Truth(lang.IFn_Cast(t.F_want).Invoke_O__O(nm__4)) { var root_146 any = A_arbace_box_elf_A_const_31.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = t.F_b__581000041; var arg_150 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_elf_A_const_32, nm__4, A_arbace_box_elf_A_const_33, e__3)); if linked_147 == nil { ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { linked_147.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) }; i__581000040__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__581000040__1); continue L1 } else { i__581000040__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__581000040__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_box_elf_cut_symbols_fn__581000052_A_New_O_O(p0, p1 any) *A_arbace_box_elf_cut_symbols_fn__581000052_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000052_A{}; t.Ctor_O_O(p0, p1); return t }
//line :81:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) Ctor_O_O(c__kept, c__data any) { t.F_kept = c__kept; t.F_data = c__data }
//line :81:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) Invoke_O__O(self any) any { { var seq_581000048__1 any; var root_222 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any; var t_ any = t.F_kept; t.F_kept = nil; arg_225 = t_; if linked_223 == nil { seq_581000048__1 = ifn_224.Invoke_O__O(arg_225) } else { seq_581000048__1 = linked_223.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_222, arg_225) }; var chunk_581000049__2 any; var count_581000050__3 int64 = 0; var i_581000051__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_581000051__4, count_581000050__3) { var map__581000053__5 any = lang.Indexed_Cast(chunk_581000049__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_581000051__4)); var map__581000053__6 any; if lang.ISeq_InstanceOf(map__581000053__5) { var tmp1 any; var root_226 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = map__581000053__5; if linked_227 == nil { tmp1 = ifn_228.Invoke_O__O(arg_229) } else { tmp1 = linked_227.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_226, arg_229) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_230 any = A_arbace_box_elf_A_const_41.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = map__581000053__5; if linked_231 == nil { tmp2 = ifn_232.Invoke_O__O(arg_233) } else { tmp2 = linked_231.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_230, arg_233) }; map__581000053__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_234 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = map__581000053__5; if linked_235 == nil { tmp3 = ifn_236.Invoke_O__O(arg_237) } else { tmp3 = linked_235.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_234, arg_237) }; if jrt.J2g_Truth(tmp3) { var root_238 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = map__581000053__5; if linked_239 == nil { map__581000053__6 = ifn_240.Invoke_O__O(arg_241) } else { map__581000053__6 = linked_239.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_238, arg_241) } } else { map__581000053__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000053__6 = map__581000053__5 }; var name__7 any = lang.RT_Get_O_O__O_NoInit(map__581000053__6, A_arbace_box_elf_A_const_32); var entry__8 any = lang.RT_Get_O_O__O_NoInit(map__581000053__6, A_arbace_box_elf_A_const_33); var tmp4 any = A_arbace_box_elf_A_const_42.GetRawRoot__O(); var tmp5 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_data, jrt.Prim_byte.ArrayClass()); var tmp6 jrt.Number_I; var na_274 any = entry__8; var na_275 int64 = 4
											if jrt.Long_InstanceOf(na_274) { var n0_276 int64 = jrt.NN(jrt.Long_Cast(na_274)).LongValue__J(); var n1_277 int64 = na_275; var nr_278 int64 = n0_276 + n1_277; if (n0_276^nr_278)&(n1_277^nr_278) >= 0 { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_278)) } else { tmp6 = lang.Numbers_Add_O_J__Number_NoInit(na_274, na_275) } } else { tmp6 = lang.Numbers_Add_O_J__Number_NoInit(na_274, na_275) }; if lang.Util_Equiv_O_J__Z_NoInit(tmp4, lang.Numbers_ShiftRight_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(tmp5, lang.RT_IntCast_O__I_NoInit(tmp6))).Ref()), 255), 4)) {
												var root_279 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, A_arbace_box_elf_fail_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16), jrt.RefArrayOf(jrt.Object_class, nil, name__7, nil)).Ref(); if linked_280 == nil { ifn_281.Invoke_O__O(arg_282) } else { linked_280.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_279, arg_282) } }
//line :81:1
	seq_581000048__1, chunk_581000049__2, count_581000050__3, i_581000051__4 = seq_581000048__1, chunk_581000049__2, count_581000050__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_581000051__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_242 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = seq_581000048__1; if linked_243 == nil { temp__1927000414__auto____5 = ifn_244.Invoke_O__O(arg_245) } else { temp__1927000414__auto____5 = linked_243.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_242, arg_245) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_581000048__6 any = temp__1927000414__auto____5; var tmp7 any; var root_246 any = A_arbace_box_elf_A_const_27.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = seq_581000048__6; if linked_247 == nil { tmp7 = ifn_248.Invoke_O__O(arg_249) } else { tmp7 = linked_247.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_246, arg_249) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____7 any; var root_250 any = A_arbace_box_elf_A_const_28.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = seq_581000048__6; if linked_251 == nil { c__1927000678__auto____7 = ifn_252.Invoke_O__O(arg_253) } else { c__1927000678__auto____7 = linked_251.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_250, arg_253) }; var tmp8 any; var root_283 any = A_arbace_box_elf_A_const_36.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = seq_581000048__6; if linked_284 == nil { tmp8 = ifn_285.Invoke_O__O(arg_286) } else { tmp8 = linked_284.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_283, arg_286) }; seq_581000048__1, chunk_581000049__2, count_581000050__3, i_581000051__4 = tmp8, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var map__581000055__7 any; var root_254 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = seq_581000048__6; if linked_255 == nil { map__581000055__7 = ifn_256.Invoke_O__O(arg_257) } else { map__581000055__7 = linked_255.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_254, arg_257) }; var map__581000055__8 any; if lang.ISeq_InstanceOf(map__581000055__7) { var tmp9 any; var root_258 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = map__581000055__7; if linked_259 == nil { tmp9 = ifn_260.Invoke_O__O(arg_261) } else { tmp9 = linked_259.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_258, arg_261) }; if jrt.J2g_Truth(tmp9) { var tmp10 any; var root_262 any = A_arbace_box_elf_A_const_41.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = map__581000055__7; if linked_263 == nil { tmp10 = ifn_264.Invoke_O__O(arg_265) } else { tmp10 = linked_263.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_262, arg_265) }; map__581000055__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp10, jrt.Object_class.ArrayClass())).Ref() } else { var tmp11 any; var root_266 any = A_arbace_box_elf_A_const_26.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = map__581000055__7; if linked_267 == nil { tmp11 = ifn_268.Invoke_O__O(arg_269) } else { tmp11 = linked_267.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_266, arg_269) }; if jrt.J2g_Truth(tmp11) { var root_270 any = A_arbace_box_elf_A_const_20.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = map__581000055__7; if linked_271 == nil { map__581000055__8 = ifn_272.Invoke_O__O(arg_273) } else { map__581000055__8 = linked_271.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_270, arg_273) } } else { map__581000055__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000055__8 = map__581000055__7 }; var name__9 any = lang.RT_Get_O_O__O_NoInit(map__581000055__8, A_arbace_box_elf_A_const_32); var entry__10 any = lang.RT_Get_O_O__O_NoInit(map__581000055__8, A_arbace_box_elf_A_const_33); var tmp12 any = A_arbace_box_elf_A_const_42.GetRawRoot__O(); var tmp13 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](t.F_data, jrt.Prim_byte.ArrayClass()); var tmp14 jrt.Number_I; var na_287 any = entry__10; var na_288 int64 = 4
		if jrt.Long_InstanceOf(na_287) { var n0_289 int64 = jrt.NN(jrt.Long_Cast(na_287)).LongValue__J(); var n1_290 int64 = na_288; var nr_291 int64 = n0_289 + n1_290; if (n0_289^nr_291)&(n1_290^nr_291) >= 0 { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_291)) } else { tmp14 = lang.Numbers_Add_O_J__Number_NoInit(na_287, na_288) } } else { tmp14 = lang.Numbers_Add_O_J__Number_NoInit(na_287, na_288) }; if lang.Util_Equiv_O_J__Z_NoInit(tmp12, lang.Numbers_ShiftRight_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(tmp13, lang.RT_IntCast_O__I_NoInit(tmp14))).Ref()), 255), 4)) {
			var root_292 any = A_arbace_box_elf_A_const_43.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, A_arbace_box_elf_fail_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16), jrt.RefArrayOf(jrt.Object_class, nil, name__9, nil)).Ref(); if linked_293 == nil { ifn_294.Invoke_O__O(arg_295) } else { linked_293.(*A_arbace_box_elf_fail_A).Invoke_O_O__O(root_292, arg_295) } }
//line :81:1
		var tmp15 any; var root_296 any = A_arbace_box_elf_A_const_40.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = seq_581000048__6; if linked_297 == nil { tmp15 = ifn_298.Invoke_O__O(arg_299) } else { tmp15 = linked_297.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_296, arg_299) }; seq_581000048__1, chunk_581000049__2, count_581000050__3, i_581000051__4 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }





func A_arbace_box_elf_cut_symbols_fn__581000058_A_New() *A_arbace_box_elf_cut_symbols_fn__581000058_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000058_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) Ctor() {}
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) Invoke_O_O_O__O(self, acc__1, k__2 any) any { var tmp1 any; var root_332 any = A_arbace_box_elf_A_const_48.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any; var tmp2 any = A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_New_O(k__2); var tmp3 *jrt.Class; var fncls__331 *jrt.Class = A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class; if fncls__331 == nil { var fncls__331d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class = fncls__331d; tmp3 = fncls__331d } else { tmp3 = fncls__331 }; arg_335 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_336 any = acc__1; if linked_333 == nil { tmp1 = ifn_334.Invoke_O_O__O(arg_335, arg_336) } else { tmp1 = linked_333.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_332, arg_335, arg_336) }; if jrt.J2g_Truth(tmp1) { return acc__1 } else { var root_337 any = A_arbace_box_elf_A_const_5.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = acc__1; var arg_341 any = k__2; if linked_338 == nil { return ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { return linked_338.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) } } }
//line :87:1
func A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_New_O(p0 any) *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A{}; t.Ctor_O(p0); return t }
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) Invoke_O_O__O(self, p1__581000017_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_box_elf_A_const_32.Invoke_O__O(t.F_k), A_arbace_box_elf_A_const_32.Invoke_O__O(p1__581000017_SHARP___1))).Ref() }
















func A_arbace_box_elf_cut_symbols_place__581000070_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_elf_cut_symbols_place__581000070_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_cut_symbols_place__581000070_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :104:1
func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) Ctor_O_O_O(c__places, c__o, c__secs any) { t.F_places = c__places; t.F_o = c__o; t.F_secs = c__secs }
//line :104:1
func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) Invoke_O_O_O__O(self, i__1, bs__2 any) any {
	var root_358 any = A_arbace_box_elf_A_const_50.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, A_arbace_box_elf_align_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = t.F_o; var tmp1 *lang.Keyword = A_arbace_box_elf_A_const_16; var arg_362 any = tmp1.Invoke_O__O(lang.IFn_Cast(t.F_secs).Invoke_O__O(i__1)); if linked_359 == nil { ifn_360.Invoke_O_O__O(arg_361, arg_362) } else { linked_359.(*A_arbace_box_elf_align_A).Invoke_O_O_O__O(root_358, arg_361, arg_362) }
	var root_363 any = A_arbace_box_elf_A_const_51.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = t.F_places; var arg_367 any = A_arbace_box_elf_A_const_52.GetRawRoot__O(); var arg_368 any = i__1; var arg_369 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.ByteArrayOutputStream_Cast(t.F_o)).Size__I()).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](bs__2, jrt.Prim_byte.ArrayClass()))).Ref()); if linked_364 == nil { ifn_365.Invoke_O_O_O_O__O(arg_366, arg_367, arg_368, arg_369) } else { linked_364.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_363, arg_366, arg_367, arg_368, arg_369) }
	var tmp2 jrt.OutputStream_I = jrt.OutputStream_Cast(t.F_o); tmp2.Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](bs__2, jrt.Prim_byte.ArrayClass())); return nil
}











type A_arbace_box_elf_A struct{ jrt.Object }

var A_arbace_box_elf_A_const_pool *jrt.RefArray

var A_arbace_box_elf_A_const_0 *lang.Var

var A_arbace_box_elf_A_const_1 any

var A_arbace_box_elf_A_const_2 *lang.Var

var A_arbace_box_elf_A_const_3 *lang.Var

var A_arbace_box_elf_A_const_4 *lang.Var

var A_arbace_box_elf_A_const_5 *lang.Var

var A_arbace_box_elf_A_const_6 any

var A_arbace_box_elf_A_const_7 *lang.Var

var A_arbace_box_elf_A_const_8 any

var A_arbace_box_elf_A_const_9 *lang.Var

var A_arbace_box_elf_A_const_10 *lang.Var

var A_arbace_box_elf_A_const_11 *lang.Var

var A_arbace_box_elf_A_const_12 *lang.Keyword

var A_arbace_box_elf_A_const_13 *lang.Keyword

var A_arbace_box_elf_A_const_14 *lang.Keyword

var A_arbace_box_elf_A_const_15 *lang.Keyword

var A_arbace_box_elf_A_const_16 *lang.Keyword

var A_arbace_box_elf_A_const_17 *lang.Keyword

var A_arbace_box_elf_A_const_18 *lang.Var

var A_arbace_box_elf_A_const_19 *lang.Var

var A_arbace_box_elf_A_const_20 *lang.Var

var A_arbace_box_elf_A_const_21 *lang.Var

var A_arbace_box_elf_A_const_22 *lang.Var

var A_arbace_box_elf_A_const_23 *lang.Var

var A_arbace_box_elf_A_const_24 *lang.Var

var A_arbace_box_elf_A_const_25 *lang.Var

var A_arbace_box_elf_A_const_26 *lang.Var

var A_arbace_box_elf_A_const_27 *lang.Var

var A_arbace_box_elf_A_const_28 *lang.Var

var A_arbace_box_elf_A_const_29 *lang.Var

var A_arbace_box_elf_A_const_30 *lang.Var

var A_arbace_box_elf_A_const_31 *lang.Var

var A_arbace_box_elf_A_const_32 *lang.Keyword

var A_arbace_box_elf_A_const_33 *lang.Keyword

var A_arbace_box_elf_A_const_34 *lang.Var

var A_arbace_box_elf_A_const_35 *lang.Var

var A_arbace_box_elf_A_const_36 *lang.Var

var A_arbace_box_elf_A_const_37 *lang.Var

var A_arbace_box_elf_A_const_38 *lang.Var

var A_arbace_box_elf_A_const_39 any

var A_arbace_box_elf_A_const_40 *lang.Var

var A_arbace_box_elf_A_const_41 *lang.Var

var A_arbace_box_elf_A_const_42 *lang.Var

var A_arbace_box_elf_A_const_43 *lang.Var

var A_arbace_box_elf_A_const_44 *lang.Var

var A_arbace_box_elf_A_const_45 *lang.Var

var A_arbace_box_elf_A_const_46 *lang.Var

var A_arbace_box_elf_A_const_47 *lang.Var

var A_arbace_box_elf_A_const_48 *lang.Var

var A_arbace_box_elf_A_const_49 *lang.Var

var A_arbace_box_elf_A_const_50 *lang.Var

var A_arbace_box_elf_A_const_51 *lang.Var

var A_arbace_box_elf_A_const_52 *lang.Var

var A_arbace_box_elf_A_const_53 *lang.Var

var A_arbace_box_elf_A_const_54 *lang.Var

var A_arbace_box_elf_A_const_55 *lang.Var

var A_arbace_box_elf_A_const_56 *lang.Var

var A_arbace_box_elf_A_const_57 *lang.Var

var A_arbace_box_elf_A_const_58 any

var A_arbace_box_elf_A_init jrt.ClassInit

func A_arbace_box_elf_A_Init() { if !A_arbace_box_elf_A_init.Done() { A_arbace_box_elf_A_init.Run(A_arbace_box_elf_A_clinit) } }

func A_arbace_box_elf_A_clinit() { A_arbace_box_elf_A_clinit_p0(); A_arbace_box_elf_A_clinit_p1(); A_arbace_box_elf_A_clinit_p2(); A_arbace_box_elf_A_clinit_p3(); A_arbace_box_elf_A_clinit_p4() }

func A_arbace_box_elf_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_elf_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 70); A_arbace_box_elf_A_const_0 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[11]); A_arbace_box_elf_A_const_1 = A_arbace_box_elf_A_const_pool.A[12]; A_arbace_box_elf_A_const_2 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[13]); A_arbace_box_elf_A_const_3 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[14]); A_arbace_box_elf_A_const_4 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[15]); A_arbace_box_elf_A_const_5 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[16]); A_arbace_box_elf_A_const_6 = A_arbace_box_elf_A_const_pool.A[17]; A_arbace_box_elf_A_const_7 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[18]); A_arbace_box_elf_A_const_8 = A_arbace_box_elf_A_const_pool.A[19]; A_arbace_box_elf_A_const_9 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[20]); A_arbace_box_elf_A_const_10 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[21]); A_arbace_box_elf_A_const_11 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[22]) }

func A_arbace_box_elf_A_clinit_p1() { A_arbace_box_elf_A_const_12 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[23]); A_arbace_box_elf_A_const_13 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[24]); A_arbace_box_elf_A_const_14 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[25]); A_arbace_box_elf_A_const_15 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[26]); A_arbace_box_elf_A_const_16 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[27]); A_arbace_box_elf_A_const_17 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[28]); A_arbace_box_elf_A_const_18 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[29]); A_arbace_box_elf_A_const_19 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[30]); A_arbace_box_elf_A_const_20 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[31]); A_arbace_box_elf_A_const_21 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[32]); A_arbace_box_elf_A_const_22 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[33]); A_arbace_box_elf_A_const_23 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[34]) }

func A_arbace_box_elf_A_clinit_p2() { A_arbace_box_elf_A_const_24 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[35]); A_arbace_box_elf_A_const_25 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[36]); A_arbace_box_elf_A_const_26 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[37]); A_arbace_box_elf_A_const_27 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[38]); A_arbace_box_elf_A_const_28 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[39]); A_arbace_box_elf_A_const_29 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[40]); A_arbace_box_elf_A_const_30 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[41]); A_arbace_box_elf_A_const_31 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[42]); A_arbace_box_elf_A_const_32 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[43]); A_arbace_box_elf_A_const_33 = lang.Keyword_Cast(A_arbace_box_elf_A_const_pool.A[44]); A_arbace_box_elf_A_const_34 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[45]); A_arbace_box_elf_A_const_35 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[46]) }

func A_arbace_box_elf_A_clinit_p3() { A_arbace_box_elf_A_const_36 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[47]); A_arbace_box_elf_A_const_37 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[48]); A_arbace_box_elf_A_const_38 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[49]); A_arbace_box_elf_A_const_39 = A_arbace_box_elf_A_const_pool.A[50]; A_arbace_box_elf_A_const_40 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[51]); A_arbace_box_elf_A_const_41 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[52]); A_arbace_box_elf_A_const_42 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[53]); A_arbace_box_elf_A_const_43 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[54]); A_arbace_box_elf_A_const_44 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[55]); A_arbace_box_elf_A_const_45 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[56]); A_arbace_box_elf_A_const_46 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[57]); A_arbace_box_elf_A_const_47 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[58]) }

func A_arbace_box_elf_A_clinit_p4() { A_arbace_box_elf_A_const_48 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[59]); A_arbace_box_elf_A_const_49 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[60]); A_arbace_box_elf_A_const_50 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[61]); A_arbace_box_elf_A_const_51 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[62]); A_arbace_box_elf_A_const_52 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[63]); A_arbace_box_elf_A_const_53 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[64]); A_arbace_box_elf_A_const_54 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[65]); A_arbace_box_elf_A_const_55 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[66]); A_arbace_box_elf_A_const_56 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[67]); A_arbace_box_elf_A_const_57 = lang.Var_Cast(A_arbace_box_elf_A_const_pool.A[68]); A_arbace_box_elf_A_const_58 = A_arbace_box_elf_A_const_pool.A[69] }

func A_arbace_box_elf_A_New() *A_arbace_box_elf_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf_A) Ctor() {}

func (t *A_arbace_box_elf_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_A_class }

func (t *A_arbace_box_elf_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_elf_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_A); return ok }

func A_arbace_box_elf_A_Cast(x any) *A_arbace_box_elf_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_A_class)) }; return v }



type A_arbace_box_elf_align_A struct{ j2g_header uint64 }

var A_arbace_box_elf_align_A_fn_class *jrt.Class



type A_arbace_box_elf_c_string_A struct{ j2g_header uint64 }

var A_arbace_box_elf_c_string_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_A struct{ j2g_header uint64 }

var A_arbace_box_elf_cut_symbols_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000020_A struct{ j2g_header uint64 }

var A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000022_A struct{ j2g_header uint64; F_secs any }

var A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000052_A struct{ j2g_header uint64; F_kept, F_data any }

var A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000058_A struct{ j2g_header uint64 }

var A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A struct{ j2g_header uint64; F_k any }

var A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A struct{ j2g_header uint64; F_data, F_st, F_strs, F_want, F_b any }

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A struct{ j2g_header uint64; F_s__581000039, F_data, F_st, F_strs, F_iter__581000038, F_want, F_b any }

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A struct{ j2g_header uint64; F_b__581000041, F_data, F_st, F_strs, F_want any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b any }

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_place__581000070_A struct{ j2g_header uint64; F_places, F_o, F_secs any }

var A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class *jrt.Class



type A_arbace_box_elf_cut_symbols_sec__581000018_A struct{ j2g_header uint64; F_shentsize, F_shoff int64; F_b any }

var A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class *jrt.Class



type A_arbace_box_elf_eval581000004_A struct{ jrt.Object }

func A_arbace_box_elf_eval581000004_A_New() *A_arbace_box_elf_eval581000004_A { t := &A_arbace_box_elf_eval581000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf_eval581000004_A) Ctor() {}

func (t *A_arbace_box_elf_eval581000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_eval581000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_eval581000004_A_class }

func (t *A_arbace_box_elf_eval581000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_eval581000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_elf_eval581000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_eval581000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_eval581000004_A); return ok }

func A_arbace_box_elf_eval581000004_A_Cast(x any) *A_arbace_box_elf_eval581000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_eval581000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_eval581000004_A_class)) }; return v }



type A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A struct{ j2g_header uint64 }

var A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_fn_class *jrt.Class



type A_arbace_box_elf_eval581000008_A struct{ jrt.Object }

func A_arbace_box_elf_eval581000008_A_New() *A_arbace_box_elf_eval581000008_A { t := &A_arbace_box_elf_eval581000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf_eval581000008_A) Ctor() {}

func (t *A_arbace_box_elf_eval581000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_eval581000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_eval581000008_A_class }

func (t *A_arbace_box_elf_eval581000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_eval581000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_elf_eval581000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_eval581000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_eval581000008_A); return ok }

func A_arbace_box_elf_eval581000008_A_Cast(x any) *A_arbace_box_elf_eval581000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_eval581000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_eval581000008_A_class)) }; return v }



type A_arbace_box_elf_eval581000008_fn__581000009_A struct{ j2g_header uint64 }

var A_arbace_box_elf_eval581000008_fn__581000009_A_fn_class *jrt.Class



type A_arbace_box_elf_fail_A struct{ j2g_header uint64 }

var A_arbace_box_elf_fail_A_fn_class *jrt.Class



type A_arbace_box_elf_le_A struct{ j2g_header uint64 }

var A_arbace_box_elf_le_A_fn_class *jrt.Class
