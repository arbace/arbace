//line aot_arbace_box_elf.ae:1
package aot_arbace_box_elf

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :3:1
func A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_New() *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A { A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_Init(); t := &A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) Ctor() {}
//line :3:1
func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_box_elf_A_Init(); tmp4 = A_arbace_box_elf_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_box_elf_A_Init(); tmp6 = A_arbace_box_elf_A_const_1; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_81)); var tmp8 *lang.Var; lang.RT_Init(); tmp8 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp8).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_82)); var tmp9 *lang.Var; lang.RT_Init(); tmp9 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp9).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_83)); var tmp10 *lang.Var; lang.RT_Init(); tmp10 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp10).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_84)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp11 != nil { panic(tmp11) }; return tmp3 }
//line :3:1
func A_arbace_box_elf_eval581000008_fn__581000009_A_New() *A_arbace_box_elf_eval581000008_fn__581000009_A { A_arbace_box_elf_eval581000008_fn__581000009_A_Init(); t := &A_arbace_box_elf_eval581000008_fn__581000009_A{}; t.Ctor(); return t }
//line :3:1
func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) Ctor() {}
//line :3:1
func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_box_elf_A_Init(); tmp1 = A_arbace_box_elf_A_const_2; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_elf_A_Init(); tmp3 = A_arbace_box_elf_A_const_3; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_box_elf_A_Init(); tmp5 = A_arbace_box_elf_A_const_6; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_box_elf_A_Init(); tmp7 = A_arbace_box_elf_A_const_4; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_box_elf_A_Init(); tmp9 = A_arbace_box_elf_A_const_5; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }











func A_arbace_box_elf_fail_A_New() *A_arbace_box_elf_fail_A { A_arbace_box_elf_fail_A_Init(); t := &A_arbace_box_elf_fail_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_box_elf_fail_A) Ctor() {}
//line :15:1
func (t *A_arbace_box_elf_fail_A) Invoke_O_O__O(self, msg__0 any) any { var tmp1 *lang.Var; A_arbace_box_elf_A_Init(); tmp1 = A_arbace_box_elf_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_87, nil), jrt.RefArrayOf(jrt.Object_class, nil, msg__0)).Ref(); var tmp4 any; A_arbace_box_elf_A_Init(); tmp4 = A_arbace_box_elf_A_const_8; panic(jrt.Thrown(jrt.Throwable_Cast(tmp2.Invoke_O_O__O(tmp3, tmp4)))) }







func A_arbace_box_elf_le_A_New() *A_arbace_box_elf_le_A { A_arbace_box_elf_le_A_Init(); t := &A_arbace_box_elf_le_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_box_elf_le_A) Ctor() {}
//line :23:1
func (t *A_arbace_box_elf_le_A) Invoke_O_O__O(self, b__0 any) any {
	var tmp1 jrt.ByteBuffer_I = jrt.ByteBuffer_Wrap_B1__ByteBuffer(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())); var tmp2 *jrt.ByteOrder; jrt.ByteOrder_Init(); tmp2 = jrt.ByteOrder_LITTLE_ENDIAN; return tmp1.Order_ByteOrder__ByteBuffer(tmp2)
}
func A_arbace_box_elf_c_string_A_New() *A_arbace_box_elf_c_string_A { A_arbace_box_elf_c_string_A_Init(); t := &A_arbace_box_elf_c_string_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_box_elf_c_string_A) Ctor() {}
//line :26:1
func (t *A_arbace_box_elf_c_string_A) Invoke_O_O_O__O(self, b__0, p_off__1 any) any { { var off__1 int64 = lang.RT_LongCast_O__J(p_off__1); var e__3 int64 = off__1; L1: for {

	if lang.Numbers_IsZero_J__Z(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(e__3))).Ref())) { return jrt.String_New_B1_I_I_Charset(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(off__1), lang.RT_IntCast_J__I(lang.Numbers_Minus_J_J__J(e__3, off__1)), jrt.StandardCharsets_UTF_8) } else {

		e__3 = lang.Numbers_Inc_J__J(e__3); continue L1 } } }; /*line :26:1*/panic("a2g: unreachable") }





func A_arbace_box_elf_align_A_New() *A_arbace_box_elf_align_A { A_arbace_box_elf_align_A_Init(); t := &A_arbace_box_elf_align_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_box_elf_align_A) Ctor() {}
//line :32:1
func (t *A_arbace_box_elf_align_A) Invoke_O_O_O__O(self, o__0, p_a__1 any) any { var a__1 int64 = lang.RT_LongCast_O__J(p_a__1); if
										lang.Numbers_Gt_J_J__Z(a__1, 1) { L1: for {
											var tmp1 *lang.Var; A_arbace_box_elf_A_Init(); tmp1 = A_arbace_box_elf_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_elf_A_Init(); tmp3 = A_arbace_box_elf_A_const_10; if jrt.A2g_Truth(tmp2.Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_O__Z(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.ByteArrayOutputStream_Cast(o__0)).Size__I()).Ref(), jrt.Long_ValueOf_J__Long(a__1).Ref()))).Ref())) {
												jrt.NN(jrt.ByteArrayOutputStream_Cast(o__0)).Write_I__V(lang.RT_IntCast_J__I(0))
//line :34:1
			continue L1 }
//line :33:1
		break L1 } }; return o__0 }




func A_arbace_box_elf_cut_symbols_A_New() *A_arbace_box_elf_cut_symbols_A { A_arbace_box_elf_cut_symbols_A_Init(); t := &A_arbace_box_elf_cut_symbols_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_box_elf_cut_symbols_A) Ctor() {}
//line :38:1
func (t *A_arbace_box_elf_cut_symbols_A) Invoke_O_O_O__O(self, data__0, names__1 any) any { var b__3 any; var tmp1 *lang.Var;


	A_arbace_box_elf_A_Init(); tmp1 = A_arbace_box_elf_A_const_11; b__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(data__0); var tmp2 bool; var and__1927000168__auto____4 bool =
	lang.Numbers_Gt_J_J__Z(int64(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()))), 64); if and__1927000168__auto____4 { var and__1927000168__auto____5 bool = lang.Util_Equiv_J_J__Z(127, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(0))).Ref())); if and__1927000168__auto____5 { var and__1927000168__auto____6 bool = lang.Util_Equiv_J_J__Z(2, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(4))).Ref())); if and__1927000168__auto____6 { tmp2 = lang.Util_Equiv_J_J__Z(1, lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(5))).Ref())) } else { tmp2 = and__1927000168__auto____6 } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = and__1927000168__auto____4 }; if tmp2 { } else {
		var tmp3 *lang.Var; A_arbace_box_elf_A_Init(); tmp3 = A_arbace_box_elf_A_const_31; lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(Lit_61) }; var phoff__4 int64 = /*line :38:1*/jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_J__I(32)); var shoff__5 int64 = jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_J__I(40)); var phentsize__6 int64 = lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Short_ValueOf_S__Short(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I(54))).Ref()), 65535); var phnum__7 int64 = lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Short_ValueOf_S__Short(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I(56))).Ref()), 65535); var shentsize__8 int64 = lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Short_ValueOf_S__Short(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I(58))).Ref()), 65535); var shnum__9 int64 = lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Short_ValueOf_S__Short(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I(60))).Ref()), 65535); var shstrndx__10 int64 = lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Short_ValueOf_S__Short(jrt.ByteBuffer_Cast(b__3).GetShort_I__S(lang.RT_IntCast_J__I(62))).Ref()), 65535); var sec__11 any; var tmp4 any = A_arbace_box_elf_cut_symbols_sec__581000018_A_New_J_J_O(shentsize__8, shoff__5, b__3); var tmp5 *jrt.Class;









	A_arbace_box_elf_cut_symbols_sec__581000018_A_Init(); tmp5 = A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class; sec__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var secs__12 any; var tmp6 /*line :38:1*/*lang.Var;













	A_arbace_box_elf_A_Init(); tmp6 = A_arbace_box_elf_A_const_18; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_box_elf_A_Init(); tmp8 = A_arbace_box_elf_A_const_39; secs__12 = tmp7.Invoke_O_O__O(sec__11, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(shnum__9).Ref())); var symtab__13 any; var tmp9 /*line :38:1*/*lang.Var;














	A_arbace_box_elf_A_Init(); tmp9 = A_arbace_box_elf_A_const_19; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_box_elf_A_Init(); tmp11 = A_arbace_box_elf_A_const_40; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any = A_arbace_box_elf_cut_symbols_fn__581000020_A_New(); var tmp14 *jrt.Class; A_arbace_box_elf_cut_symbols_fn__581000020_A_Init(); tmp14 = A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class; symtab__13 = tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), secs__12)); var strtab__14 any; if
	jrt.A2g_Truth(symtab__13) { var tmp15 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp15 = A_arbace_box_elf_A_const_15; var tmp16 *lang.Keyword = tmp15; strtab__14 = jrt.NN(tmp16).Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(symtab__13)) } else { strtab__14 = nil }; var tmp17 bool; var or__1927000174__auto____15 bool =
	lang.Util_Identical_O_O__Z(symtab__13, nil); if or__1927000174__auto____15 { tmp17 = or__1927000174__auto____15 } else { var or__1927000174__auto____16 bool = lang.Numbers_Lte_O_J__Z(strtab__14, 0); if or__1927000174__auto____16 { tmp17 = or__1927000174__auto____16 } else { var or__1927000174__auto____17 bool = lang.Numbers_Gte_O_J__Z(strtab__14, shnum__9); if or__1927000174__auto____17 { tmp17 = or__1927000174__auto____17 } else { var or__1927000174__auto____18 bool = lang.Numbers_Lte_J_J__Z(shstrndx__10, 0); if or__1927000174__auto____18 { tmp17 = or__1927000174__auto____18 } else { tmp17 = lang.Numbers_Gte_J_J__Z(shstrndx__10, shnum__9) } } } }; if tmp17 {
		var tmp18 *lang.Var; A_arbace_box_elf_A_Init(); tmp18 = A_arbace_box_elf_A_const_31; lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(Lit_62) }; var tail__15 any; var tmp19 /*line :38:1*/*lang.Var;


















	A_arbace_box_elf_A_Init(); tmp19 = A_arbace_box_elf_A_const_20; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any = A_arbace_box_elf_cut_symbols_fn__581000022_A_New_O(secs__12); var tmp22 *jrt.Class; A_arbace_box_elf_cut_symbols_fn__581000022_A_Init(); tmp22 = A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class; tail__15 = tmp20.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil), lang.Tuple_Create_O_O_O__IPersistentVector(symtab__13, strtab__14, jrt.Long_ValueOf_J__Long(shstrndx__10).Ref())); var start__16 any; var tmp23 /*line :38:1*/*lang.Keyword;



















	A_arbace_box_elf_A_Init(); tmp23 = A_arbace_box_elf_A_const_13; var tmp24 *lang.Keyword = tmp23; var tmp25 lang.IFn = lang.IFn_Cast(secs__12); var tmp26 *lang.Var; A_arbace_box_elf_A_Init(); tmp26 = A_arbace_box_elf_A_const_19; start__16 = jrt.NN(tmp24).Invoke_O__O(tmp25.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(tail__15))); if
	lang.Numbers_Gt_J_O__Z(lang.Numbers_Add_J_J__J(shoff__5, lang.Numbers_Multiply_J_J__J(shnum__9, shentsize__8)), start__16) {
		var tmp27 *lang.Var; A_arbace_box_elf_A_Init(); tmp27 = A_arbace_box_elf_A_const_31; lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(Lit_63) }; var seq_581000024__17 any; var tmp28 /*line :38:1*/*lang.Var;






















	A_arbace_box_elf_A_Init(); tmp28 = A_arbace_box_elf_A_const_23; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_box_elf_A_Init(); tmp30 = A_arbace_box_elf_A_const_42; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_box_elf_A_Init(); tmp32 = A_arbace_box_elf_A_const_43; seq_581000024__17 = tmp29.Invoke_O__O(tmp31.Invoke_O_O__O(jrt.NN(tmp32).GetRawRoot__O(), secs__12)); var chunk_581000025__18 any; var count_581000026__19 int64 = 0; var i_581000027__20 int64 = 0; L1:
//line :38:1
	for {






















		if lang.Numbers_Lt_J_J__Z(i_581000027__20, count_581000026__19) { var vec__581000028__21 any = lang.Indexed_Cast(chunk_581000025__18).Nth_I__O(lang.RT_IntCast_J__I(i_581000027__20)); var i__22 any = lang.RT_Nth_O_I_O__O(vec__581000028__21, lang.RT_IntCast_J__I(0), nil); var s__23 any = lang.RT_Nth_O_I_O__O(vec__581000028__21, lang.RT_IntCast_J__I(1), nil); var tmp33 *lang.Var; A_arbace_box_elf_A_Init(); tmp33 = A_arbace_box_elf_A_const_9; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 any; var or__1927000174__auto____24 any = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, strtab__14, symtab__13, jrt.Long_ValueOf_J__Long(shstrndx__10).Ref()))).Invoke_O__O(i__22)
			if jrt.A2g_Truth(or__1927000174__auto____24) { tmp35 = or__1927000174__auto____24 } else { var tmp36 *lang.Var; A_arbace_box_elf_A_Init(); tmp36 = A_arbace_box_elf_A_const_44; var tmp37 any = jrt.NN(tmp36).GetRawRoot__O(); var tmp38 *lang.Var; A_arbace_box_elf_A_Init(); tmp38 = A_arbace_box_elf_A_const_45; var tmp39 lang.IFn = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, tmp37, jrt.NN(tmp38).GetRawRoot__O()))); var tmp40 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp40 = A_arbace_box_elf_A_const_12; tmp35 = tmp39.Invoke_O__O(jrt.NN(tmp40).Invoke_O__O(s__23)) }
//line :61:1
			if jrt.A2g_Truth(tmp34.Invoke_O__O(tmp35)) {

				var tmp41 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp41 = A_arbace_box_elf_A_const_13; var tmp42 any = jrt.NN(tmp41).Invoke_O__O(s__23); var tmp43 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp43 = A_arbace_box_elf_A_const_14; if lang.Numbers_Gt_O_O__Z(lang.Numbers_Add_O_O__Number(tmp42, jrt.NN(tmp43).Invoke_O__O(s__23)), start__16) {
					var tmp44 *lang.Var; A_arbace_box_elf_A_Init(); tmp44 = A_arbace_box_elf_A_const_31; lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(Lit_64) }
//line :61:1
				seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = seq_581000024__17, chunk_581000025__18, count_581000026__19, lang.Numbers_Unchecked_inc_J__J(i_581000027__20); continue L1 } else { seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = seq_581000024__17, chunk_581000025__18, count_581000026__19, lang.Numbers_Unchecked_inc_J__J(i_581000027__20); continue L1 } } else { var temp__1927000414__auto____21 any; var tmp45 *lang.Var; A_arbace_box_elf_A_Init(); tmp45 = A_arbace_box_elf_A_const_23; temp__1927000414__auto____21 = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()).Invoke_O__O(seq_581000024__17); if jrt.A2g_Truth(temp__1927000414__auto____21) { var seq_581000024__22 any = temp__1927000414__auto____21; var tmp46 *lang.Var; A_arbace_box_elf_A_Init(); tmp46 = A_arbace_box_elf_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()).Invoke_O__O(seq_581000024__22)) { var c__1927000678__auto____23 any; var tmp47 *lang.Var; A_arbace_box_elf_A_Init(); tmp47 = A_arbace_box_elf_A_const_29; c__1927000678__auto____23 = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O__O(seq_581000024__22); var tmp48 *lang.Var; A_arbace_box_elf_A_Init(); tmp48 = A_arbace_box_elf_A_const_32; seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()).Invoke_O__O(seq_581000024__22), c__1927000678__auto____23, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____23))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__581000031__23 any; var tmp49 *lang.Var; A_arbace_box_elf_A_Init(); tmp49 = A_arbace_box_elf_A_const_19; vec__581000031__23 = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()).Invoke_O__O(seq_581000024__22); var i__24 any = lang.RT_Nth_O_I_O__O(vec__581000031__23, lang.RT_IntCast_J__I(0), nil); var s__25 any = lang.RT_Nth_O_I_O__O(vec__581000031__23, lang.RT_IntCast_J__I(1), nil); var tmp50 *lang.Var; A_arbace_box_elf_A_Init(); tmp50 = A_arbace_box_elf_A_const_9; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 any; var or__1927000174__auto____26 any = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, strtab__14, symtab__13, jrt.Long_ValueOf_J__Long(shstrndx__10).Ref()))).Invoke_O__O(i__24)
					if jrt.A2g_Truth(or__1927000174__auto____26) { tmp52 = or__1927000174__auto____26 } else { var tmp53 *lang.Var; A_arbace_box_elf_A_Init(); tmp53 = A_arbace_box_elf_A_const_44; var tmp54 any = jrt.NN(tmp53).GetRawRoot__O(); var tmp55 *lang.Var; A_arbace_box_elf_A_Init(); tmp55 = A_arbace_box_elf_A_const_45; var tmp56 lang.IFn = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, tmp54, jrt.NN(tmp55).GetRawRoot__O()))); var tmp57 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp57 = A_arbace_box_elf_A_const_12; tmp52 = tmp56.Invoke_O__O(jrt.NN(tmp57).Invoke_O__O(s__25)) }
//line :61:1
					if jrt.A2g_Truth(tmp51.Invoke_O__O(tmp52)) {

						var tmp58 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp58 = A_arbace_box_elf_A_const_13; var tmp59 any = jrt.NN(tmp58).Invoke_O__O(s__25); var tmp60 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp60 = A_arbace_box_elf_A_const_14; if lang.Numbers_Gt_O_O__Z(lang.Numbers_Add_O_O__Number(tmp59, jrt.NN(tmp60).Invoke_O__O(s__25)), start__16) {
							var tmp61 *lang.Var; A_arbace_box_elf_A_Init(); tmp61 = A_arbace_box_elf_A_const_31; lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()).Invoke_O__O(Lit_64) }
//line :61:1
						var tmp62 *lang.Var; A_arbace_box_elf_A_Init(); tmp62 = A_arbace_box_elf_A_const_24; seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()).Invoke_O__O(seq_581000024__22), nil, 0, 0; continue L1 } else { var tmp63 *lang.Var; A_arbace_box_elf_A_Init(); tmp63 = A_arbace_box_elf_A_const_24; seq_581000024__17, chunk_581000025__18, count_581000026__19, i_581000027__20 = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()).Invoke_O__O(seq_581000024__22), nil, 0, 0; continue L1 } } } }
//line :38:1
		break L1 }; var seq_581000034__17 any; var tmp64 *lang.Var;


























	A_arbace_box_elf_A_Init(); tmp64 = A_arbace_box_elf_A_const_23; var tmp65 lang.IFn = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()); var tmp66 *lang.Var; A_arbace_box_elf_A_Init(); tmp66 = A_arbace_box_elf_A_const_39; seq_581000034__17 = tmp65.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(phnum__7).Ref())); var chunk_581000035__18 any; var count_581000036__19 int64 = 0; var i_581000037__20 int64 = 0; L2:
//line :38:1
	for {


























		if lang.Numbers_Lt_J_J__Z(i_581000037__20, count_581000036__19) { var i__21 any = lang.Indexed_Cast(chunk_581000035__18).Nth_I__O(lang.RT_IntCast_J__I(i_581000037__20)); var h__22 any = lang.Numbers_Add_J_O__Number(phoff__4, lang.Numbers_Multiply_O_J__Number(i__21, phentsize__6))

			if lang.Numbers_Gt_J_O__Z(lang.Numbers_Add_J_J__J(jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__22, 8))), jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__22, 32)))), start__16) {
				var tmp67 *lang.Var; A_arbace_box_elf_A_Init(); tmp67 = A_arbace_box_elf_A_const_31; lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()).Invoke_O__O(Lit_65) }
//line :65:1
			seq_581000034__17, chunk_581000035__18, count_581000036__19, i_581000037__20 = seq_581000034__17, chunk_581000035__18, count_581000036__19, lang.Numbers_Unchecked_inc_J__J(i_581000037__20); continue L2 } else { var temp__1927000414__auto____21_2 any; var tmp68 *lang.Var; A_arbace_box_elf_A_Init(); tmp68 = A_arbace_box_elf_A_const_23; temp__1927000414__auto____21_2 = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O__O(seq_581000034__17); if jrt.A2g_Truth(temp__1927000414__auto____21_2) { var seq_581000034__22 any = temp__1927000414__auto____21_2; var tmp69 *lang.Var; A_arbace_box_elf_A_Init(); tmp69 = A_arbace_box_elf_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()).Invoke_O__O(seq_581000034__22)) { var c__1927000678__auto____23_2 any; var tmp70 *lang.Var; A_arbace_box_elf_A_Init(); tmp70 = A_arbace_box_elf_A_const_29; c__1927000678__auto____23_2 = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke_O__O(seq_581000034__22); var tmp71 *lang.Var; A_arbace_box_elf_A_Init(); tmp71 = A_arbace_box_elf_A_const_32; seq_581000034__17, chunk_581000035__18, count_581000036__19, i_581000037__20 = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()).Invoke_O__O(seq_581000034__22), c__1927000678__auto____23_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____23_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var i__23 any; var tmp72 *lang.Var; A_arbace_box_elf_A_Init(); tmp72 = A_arbace_box_elf_A_const_19; i__23 = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()).Invoke_O__O(seq_581000034__22); var h__24 any = lang.Numbers_Add_J_O__Number(phoff__4, lang.Numbers_Multiply_O_J__Number(i__23, phentsize__6))

				if lang.Numbers_Gt_J_O__Z(lang.Numbers_Add_J_J__J(jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__24, 8))), jrt.ByteBuffer_Cast(b__3).GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__24, 32)))), start__16) {
					var tmp73 *lang.Var; A_arbace_box_elf_A_Init(); tmp73 = A_arbace_box_elf_A_const_31; lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()).Invoke_O__O(Lit_65) }
//line :65:1
				var tmp74 *lang.Var; A_arbace_box_elf_A_Init(); tmp74 = A_arbace_box_elf_A_const_24; seq_581000034__17, chunk_581000035__18, count_581000036__19, i_581000037__20 = lang.IFn_Cast(jrt.NN(tmp74).GetRawRoot__O()).Invoke_O__O(seq_581000034__22), nil, 0, 0; continue L2 } } }
//line :38:1
		break L2 }; var l__17 any; var tmp75 lang.IFn = lang.IFn_Cast(secs__12); var tmp76 *lang.Var;






























	A_arbace_box_elf_A_Init(); tmp76 = A_arbace_box_elf_A_const_46; l__17 = tmp75.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()).Invoke_O__O(tail__15)); var tmp77 /*line :70:1*/*lang.Keyword; A_arbace_box_elf_A_Init(); tmp77 = A_arbace_box_elf_A_const_13; var tmp78 any = jrt.NN(tmp77).Invoke_O__O(l__17); var tmp79 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp79 = A_arbace_box_elf_A_const_14; if lang.Util_Equiv_O_J__Z(lang.Numbers_Add_O_O__Number(tmp78, jrt.NN(tmp79).Invoke_O__O(l__17)), int64(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass())))) { } else {
		var tmp80 *lang.Var; A_arbace_box_elf_A_Init(); tmp80 = A_arbace_box_elf_A_const_31; lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke_O__O(Lit_66) }; var st__17 any = /*line :38:1*/lang.IFn_Cast(secs__12).Invoke_O__O(symtab__13); var strs__18 any; var tmp81 *lang.Keyword;


































	A_arbace_box_elf_A_Init(); tmp81 = A_arbace_box_elf_A_const_13; var tmp82 *lang.Keyword = tmp81; strs__18 = jrt.NN(tmp82).Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(strtab__14)); var n__19 any; var tmp83 /*line :38:1*/*lang.Keyword;



































	A_arbace_box_elf_A_Init(); tmp83 = A_arbace_box_elf_A_const_14; n__19 = lang.Numbers_Quotient_O_J__Number(jrt.NN(tmp83).Invoke_O__O(st__17), 24); var want__20 any; var tmp84 /*line :38:1*/*lang.Var;




































	A_arbace_box_elf_A_Init(); tmp84 = A_arbace_box_elf_A_const_21; want__20 = lang.IFn_Cast(jrt.NN(tmp84).GetRawRoot__O()).Invoke_O__O(names__1); var kept__21 any; var tmp85 /*line :38:1*/*lang.Var;





































	A_arbace_box_elf_A_Init(); tmp85 = A_arbace_box_elf_A_const_22; var tmp86 lang.IFn = lang.IFn_Cast(jrt.NN(tmp85).GetRawRoot__O()); var tmp87 any; var iter__1927001039__auto____21 any; var tmp88 any = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_New_O_O_O_O_O(data__0, st__17, strs__18, want__20, b__3); var tmp89 *jrt.Class; A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_Init(); tmp89 = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp88, tmp89, nil); var tmp90 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____21); var tmp91 *lang.Var; A_arbace_box_elf_A_Init(); tmp91 = A_arbace_box_elf_A_const_39; var tmp92 lang.IFn = lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()); var tmp93 any; A_arbace_box_elf_A_Init(); tmp93 = A_arbace_box_elf_A_const_54; tmp87 = tmp90.Invoke_O__O(tmp92.Invoke_O_O__O(tmp93, n__19)); kept__21 = tmp86.Invoke_O__O(tmp87); var ___22 any; var tmp94 any = /*line :38:1*/A_arbace_box_elf_cut_symbols_fn__581000052_A_New_O_O(kept__21, data__0); var tmp95 *jrt.Class; _ = ___22;










































	A_arbace_box_elf_cut_symbols_fn__581000052_A_Init(); tmp95 = A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class; ___22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp94, tmp95, nil).Invoke__O(); var missing__23 any; var tmp96 /*line :38:1*/*lang.Var;













































	A_arbace_box_elf_A_Init(); tmp96 = A_arbace_box_elf_A_const_33; var tmp97 lang.IFn = lang.IFn_Cast(jrt.NN(tmp96).GetRawRoot__O()); var tmp98 *lang.Var; A_arbace_box_elf_A_Init(); tmp98 = A_arbace_box_elf_A_const_55; var tmp99 lang.IFn = lang.IFn_Cast(jrt.NN(tmp98).GetRawRoot__O()); var tmp100 *lang.Var; A_arbace_box_elf_A_Init(); tmp100 = A_arbace_box_elf_A_const_21; var tmp101 lang.IFn = lang.IFn_Cast(jrt.NN(tmp100).GetRawRoot__O()); var tmp102 *lang.Var; A_arbace_box_elf_A_Init(); tmp102 = A_arbace_box_elf_A_const_56; var tmp103 lang.IFn = lang.IFn_Cast(jrt.NN(tmp102).GetRawRoot__O()); var tmp104 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp104 = A_arbace_box_elf_A_const_26; missing__23 = tmp97.Invoke_O__O(tmp99.Invoke_O_O__O(tmp101.Invoke_O__O(tmp103.Invoke_O_O__O(tmp104.Ref(), kept__21)), want__20)); var ___24 any; var tmp105 /*line :38:1*/*lang.Var; _ = ___24;














































	A_arbace_box_elf_A_Init(); tmp105 = A_arbace_box_elf_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp105).GetRawRoot__O()).Invoke_O__O(missing__23)) { var tmp106 *lang.Var; A_arbace_box_elf_A_Init(); tmp106 = A_arbace_box_elf_A_const_31; var tmp107 lang.IFn = lang.IFn_Cast(jrt.NN(tmp106).GetRawRoot__O()); var tmp108 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil); var tmp109 *lang.Var; A_arbace_box_elf_A_Init(); tmp109 = A_arbace_box_elf_A_const_22; ___24 = tmp107.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp108, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp109).GetRawRoot__O()).Invoke_O__O(missing__23))).Ref()) } else { ___24 = nil }; var kept__25 any; var tmp110 /*line :38:1*/*lang.Var;
















































	A_arbace_box_elf_A_Init(); tmp110 = A_arbace_box_elf_A_const_34; var tmp111 lang.IFn = lang.IFn_Cast(jrt.NN(tmp110).GetRawRoot__O()); var tmp112 any = A_arbace_box_elf_cut_symbols_fn__581000058_A_New(); var tmp113 *jrt.Class; A_arbace_box_elf_cut_symbols_fn__581000058_A_Init(); tmp113 = A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class; var tmp114 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp112, tmp113, nil); var tmp115 *lang.PersistentVector; lang.PersistentVector_Init(); tmp115 = lang.PersistentVector_EMPTY; kept__25 = tmp111.Invoke_O_O_O__O(tmp114, tmp115.Ref(), kept__21); var strb__26 any = /*line :38:1*/jrt.ByteArrayOutputStream_New(); var symb__27 any = jrt.ByteArrayOutputStream_New();



















































	jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Write_I__V(lang.RT_IntCast_J__I(0)); var tmp116 jrt.OutputStream_I =
	jrt.OutputStream_Cast(symb__27); var tmp117 any; A_arbace_box_elf_A_Init(); tmp117 = A_arbace_box_elf_A_const_58; tmp116.Write_B1__V(lang.Numbers_Byte_array_O__B1(tmp117)); var seq_581000062__28 any; var tmp118 /*line :38:1*/*lang.Var;





















































	A_arbace_box_elf_A_Init(); tmp118 = A_arbace_box_elf_A_const_23; seq_581000062__28 = lang.IFn_Cast(jrt.NN(tmp118).GetRawRoot__O()).Invoke_O__O(kept__25); var chunk_581000063__29 any; var count_581000064__30 int64 = 0; var i_581000065__31 int64 = 0; L3:
//line :38:1
	for {





















































		if lang.Numbers_Lt_J_J__Z(i_581000065__31, count_581000064__30) { var map__581000066__32 any = lang.Indexed_Cast(chunk_581000063__29).Nth_I__O(lang.RT_IntCast_J__I(i_581000065__31)); var map__581000066__33 any; if lang.ISeq_InstanceOf(map__581000066__32) { var tmp119 *lang.Var; A_arbace_box_elf_A_Init(); tmp119 = A_arbace_box_elf_A_const_24; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp119).GetRawRoot__O()).Invoke_O__O(map__581000066__32)) { var tmp120 *lang.Var; A_arbace_box_elf_A_Init(); tmp120 = A_arbace_box_elf_A_const_25; map__581000066__33 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp120).GetRawRoot__O()).Invoke_O__O(map__581000066__32), jrt.Object_class.ArrayClass())).Ref() } else { var tmp121 *lang.Var; A_arbace_box_elf_A_Init(); tmp121 = A_arbace_box_elf_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp121).GetRawRoot__O()).Invoke_O__O(map__581000066__32)) { var tmp122 *lang.Var; A_arbace_box_elf_A_Init(); tmp122 = A_arbace_box_elf_A_const_19; map__581000066__33 = lang.IFn_Cast(jrt.NN(tmp122).GetRawRoot__O()).Invoke_O__O(map__581000066__32) } else { lang.PersistentArrayMap_Init(); map__581000066__33 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000066__33 = map__581000066__32 }; var name__34 any; var tmp123 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp123 = A_arbace_box_elf_A_const_26; name__34 = lang.RT_Get_O_O__O(map__581000066__33, tmp123.Ref()); var entry__35 any; var tmp124 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp124 = A_arbace_box_elf_A_const_27; entry__35 = lang.RT_Get_O_O__O(map__581000066__33, tmp124.Ref()); var e__36 any; var tmp125 any
			A_arbace_box_elf_A_Init(); tmp125 = A_arbace_box_elf_A_const_58; e__36 = lang.Numbers_Byte_array_O__B1(tmp125).Ref()
//line :92:1
			var eb__37 any; var tmp126 *lang.Var

			A_arbace_box_elf_A_Init(); tmp126 = A_arbace_box_elf_A_const_11; eb__37 = lang.IFn_Cast(jrt.NN(tmp126).GetRawRoot__O()).Invoke_O__O(e__36)
			jrt.System_Arraycopy_O_I_O_I_I__V(data__0, lang.RT_IntCast_O__I(entry__35), e__36, lang.RT_IntCast_J__I(0), lang.RT_IntCast_J__I(24))
			jrt.ByteBuffer_Cast(eb__37).PutInt_I_I__ByteBuffer(lang.RT_IntCast_J__I(0), lang.RT_IntCast_I__I(jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Size__I()))
			jrt.OutputStream_Cast(symb__27).Write_B1__V(jrt.A2g_CastArray[*jrt.ByteArray](e__36, jrt.Prim_byte.ArrayClass()))
			jrt.OutputStream_Cast(strb__26).Write_B1__V(jrt.NN(jrt.String_Cast(name__34)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8))
			jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Write_I__V(lang.RT_IntCast_J__I(0))
//line :92:1
			seq_581000062__28, chunk_581000063__29, count_581000064__30, i_581000065__31 = seq_581000062__28, chunk_581000063__29, count_581000064__30, lang.Numbers_Unchecked_inc_J__J(i_581000065__31); continue L3 } else { var temp__1927000414__auto____32 any; var tmp127 *lang.Var; A_arbace_box_elf_A_Init(); tmp127 = A_arbace_box_elf_A_const_23; temp__1927000414__auto____32 = lang.IFn_Cast(jrt.NN(tmp127).GetRawRoot__O()).Invoke_O__O(seq_581000062__28); if jrt.A2g_Truth(temp__1927000414__auto____32) { var seq_581000062__33 any = temp__1927000414__auto____32; var tmp128 *lang.Var; A_arbace_box_elf_A_Init(); tmp128 = A_arbace_box_elf_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp128).GetRawRoot__O()).Invoke_O__O(seq_581000062__33)) { var c__1927000678__auto____34 any; var tmp129 *lang.Var; A_arbace_box_elf_A_Init(); tmp129 = A_arbace_box_elf_A_const_29; c__1927000678__auto____34 = lang.IFn_Cast(jrt.NN(tmp129).GetRawRoot__O()).Invoke_O__O(seq_581000062__33); var tmp130 *lang.Var; A_arbace_box_elf_A_Init(); tmp130 = A_arbace_box_elf_A_const_32; seq_581000062__28, chunk_581000063__29, count_581000064__30, i_581000065__31 = lang.IFn_Cast(jrt.NN(tmp130).GetRawRoot__O()).Invoke_O__O(seq_581000062__33), c__1927000678__auto____34, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____34))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var map__581000068__34 any; var tmp131 *lang.Var; A_arbace_box_elf_A_Init(); tmp131 = A_arbace_box_elf_A_const_19; map__581000068__34 = lang.IFn_Cast(jrt.NN(tmp131).GetRawRoot__O()).Invoke_O__O(seq_581000062__33); var map__581000068__35 any; if lang.ISeq_InstanceOf(map__581000068__34) { var tmp132 *lang.Var; A_arbace_box_elf_A_Init(); tmp132 = A_arbace_box_elf_A_const_24; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp132).GetRawRoot__O()).Invoke_O__O(map__581000068__34)) { var tmp133 *lang.Var; A_arbace_box_elf_A_Init(); tmp133 = A_arbace_box_elf_A_const_25; map__581000068__35 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp133).GetRawRoot__O()).Invoke_O__O(map__581000068__34), jrt.Object_class.ArrayClass())).Ref() } else { var tmp134 *lang.Var; A_arbace_box_elf_A_Init(); tmp134 = A_arbace_box_elf_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp134).GetRawRoot__O()).Invoke_O__O(map__581000068__34)) { var tmp135 *lang.Var; A_arbace_box_elf_A_Init(); tmp135 = A_arbace_box_elf_A_const_19; map__581000068__35 = lang.IFn_Cast(jrt.NN(tmp135).GetRawRoot__O()).Invoke_O__O(map__581000068__34) } else { lang.PersistentArrayMap_Init(); map__581000068__35 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000068__35 = map__581000068__34 }; var name__36 any; var tmp136 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp136 = A_arbace_box_elf_A_const_26; name__36 = lang.RT_Get_O_O__O(map__581000068__35, tmp136.Ref()); var entry__37 any; var tmp137 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp137 = A_arbace_box_elf_A_const_27; entry__37 = lang.RT_Get_O_O__O(map__581000068__35, tmp137.Ref()); var e__38 any; var tmp138 any
				A_arbace_box_elf_A_Init(); tmp138 = A_arbace_box_elf_A_const_58; e__38 = lang.Numbers_Byte_array_O__B1(tmp138).Ref()
//line :92:1
				var eb__39 any; var tmp139 *lang.Var

				A_arbace_box_elf_A_Init(); tmp139 = A_arbace_box_elf_A_const_11; eb__39 = lang.IFn_Cast(jrt.NN(tmp139).GetRawRoot__O()).Invoke_O__O(e__38)
				jrt.System_Arraycopy_O_I_O_I_I__V(data__0, lang.RT_IntCast_O__I(entry__37), e__38, lang.RT_IntCast_J__I(0), lang.RT_IntCast_J__I(24))
				jrt.ByteBuffer_Cast(eb__39).PutInt_I_I__ByteBuffer(lang.RT_IntCast_J__I(0), lang.RT_IntCast_I__I(jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Size__I()))
				jrt.OutputStream_Cast(symb__27).Write_B1__V(jrt.A2g_CastArray[*jrt.ByteArray](e__38, jrt.Prim_byte.ArrayClass()))
				jrt.OutputStream_Cast(strb__26).Write_B1__V(jrt.NN(jrt.String_Cast(name__36)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8))
				jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).Write_I__V(lang.RT_IntCast_J__I(0))
//line :92:1
				var tmp140 *lang.Var; A_arbace_box_elf_A_Init(); tmp140 = A_arbace_box_elf_A_const_24; seq_581000062__28, chunk_581000063__29, count_581000064__30, i_581000065__31 = lang.IFn_Cast(jrt.NN(tmp140).GetRawRoot__O()).Invoke_O__O(seq_581000062__33), nil, 0, 0; continue L3 } } }
//line :38:1
		break L3 }; var o__28 any = jrt.ByteArrayOutputStream_New(); var ___29 any; _ = ___29;






























































	jrt.NN(jrt.ByteArrayOutputStream_Cast(o__28)).Write_B1_I_I__V(jrt.A2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(0), lang.RT_IntCast_O__I(start__16)); ___29 = nil; var shstr__30 any; var tmp141 /*line :38:1*/*jrt.ByteArray = jrt.A2g_CastArray[*jrt.ByteArray](data__0, jrt.Prim_byte.ArrayClass()); var tmp142 *lang.Keyword;































































	A_arbace_box_elf_A_Init(); tmp142 = A_arbace_box_elf_A_const_13; var tmp143 *lang.Keyword = tmp142; var tmp144 int32 = lang.RT_IntCast_O__I(jrt.NN(tmp143).Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long(shstrndx__10).Ref()))); var tmp145 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp145 = A_arbace_box_elf_A_const_13; var tmp146 *lang.Keyword = tmp145; var tmp147 any = jrt.NN(tmp146).Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long(shstrndx__10).Ref())); var tmp148 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp148 = A_arbace_box_elf_A_const_14; var tmp149 *lang.Keyword = tmp148; shstr__30 = jrt.Arrays_CopyOfRange_B1_I_I__B1(tmp141, tmp144, lang.RT_IntCast_O__I(lang.Numbers_Add_O_O__Number(tmp147, jrt.NN(tmp149).Invoke_O__O(lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long(shstrndx__10).Ref()))))).Ref(); var places__31 any; var tmp150 /*line :38:1*/*lang.Var;
































































	A_arbace_box_elf_A_Init(); tmp150 = A_arbace_box_elf_A_const_35; var tmp151 lang.IFn = lang.IFn_Cast(jrt.NN(tmp150).GetRawRoot__O()); var tmp152 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp152 = lang.PersistentArrayMap_EMPTY; places__31 = tmp151.Invoke_O__O(tmp152.Ref()); var place__32 any; var tmp153 any = /*line :38:1*/A_arbace_box_elf_cut_symbols_place__581000070_A_New_O_O_O(places__31, o__28, secs__12); var tmp154 *jrt.Class;

































































	A_arbace_box_elf_cut_symbols_place__581000070_A_Init(); tmp154 = A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class; place__32 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp153, tmp154, nil);



	lang.IFn_Cast(place__32).Invoke_O_O__O(symtab__13, jrt.NN(jrt.ByteArrayOutputStream_Cast(symb__27)).ToByteArray__B1().Ref());
	lang.IFn_Cast(place__32).Invoke_O_O__O(strtab__14, jrt.NN(jrt.ByteArrayOutputStream_Cast(strb__26)).ToByteArray__B1().Ref());
	lang.IFn_Cast(place__32).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(shstrndx__10).Ref(), shstr__30); var out__33 any = /*line :38:1*/jrt.NN(jrt.ByteArrayOutputStream_Cast(o__28)).ToByteArray__B1().Ref(); var ob__34 any; var tmp155 *lang.Var;









































































	A_arbace_box_elf_A_Init(); tmp155 = A_arbace_box_elf_A_const_11; ob__34 = lang.IFn_Cast(jrt.NN(tmp155).GetRawRoot__O()).Invoke_O__O(out__33); var seq_581000072__35 any; var tmp156 /*line :38:1*/*lang.Var;










































































	A_arbace_box_elf_A_Init(); tmp156 = A_arbace_box_elf_A_const_23; var tmp157 lang.IFn = lang.IFn_Cast(jrt.NN(tmp156).GetRawRoot__O()); var tmp158 *lang.Var; A_arbace_box_elf_A_Init(); tmp158 = A_arbace_box_elf_A_const_3; seq_581000072__35 = tmp157.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp158).GetRawRoot__O()).Invoke_O__O(places__31)); var chunk_581000073__36 any; var count_581000074__37 int64 = 0; var i_581000075__38 int64 = 0; L4:
//line :38:1
	for {










































































		if lang.Numbers_Lt_J_J__Z(i_581000075__38, count_581000074__37) { var vec__581000076__39 any = lang.Indexed_Cast(chunk_581000073__36).Nth_I__O(lang.RT_IntCast_J__I(i_581000075__38)); var i__40 any = lang.RT_Nth_O_I_O__O(vec__581000076__39, lang.RT_IntCast_J__I(0), nil); var vec__581000079__41 any = lang.RT_Nth_O_I_O__O(vec__581000076__39, lang.RT_IntCast_J__I(1), nil); var off__42 any = lang.RT_Nth_O_I_O__O(vec__581000079__41, lang.RT_IntCast_J__I(0), nil); var size__43 any = lang.RT_Nth_O_I_O__O(vec__581000079__41, lang.RT_IntCast_J__I(1), nil); var h__44 any = lang.Numbers_Add_J_O__Number(shoff__5, lang.Numbers_Multiply_O_J__Number(i__40, shentsize__8))

			jrt.ByteBuffer_Cast(ob__34).PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__44, 24)), lang.RT_LongCast_O__J(off__42))
			jrt.ByteBuffer_Cast(ob__34).PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__44, 32)), lang.RT_LongCast_O__J(size__43))
//line :113:1
			seq_581000072__35, chunk_581000073__36, count_581000074__37, i_581000075__38 = seq_581000072__35, chunk_581000073__36, count_581000074__37, lang.Numbers_Unchecked_inc_J__J(i_581000075__38); continue L4 } else { var temp__1927000414__auto____39 any; var tmp159 *lang.Var; A_arbace_box_elf_A_Init(); tmp159 = A_arbace_box_elf_A_const_23; temp__1927000414__auto____39 = lang.IFn_Cast(jrt.NN(tmp159).GetRawRoot__O()).Invoke_O__O(seq_581000072__35); if jrt.A2g_Truth(temp__1927000414__auto____39) { var seq_581000072__40 any = temp__1927000414__auto____39; var tmp160 *lang.Var; A_arbace_box_elf_A_Init(); tmp160 = A_arbace_box_elf_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp160).GetRawRoot__O()).Invoke_O__O(seq_581000072__40)) { var c__1927000678__auto____41 any; var tmp161 *lang.Var; A_arbace_box_elf_A_Init(); tmp161 = A_arbace_box_elf_A_const_29; c__1927000678__auto____41 = lang.IFn_Cast(jrt.NN(tmp161).GetRawRoot__O()).Invoke_O__O(seq_581000072__40); var tmp162 *lang.Var; A_arbace_box_elf_A_Init(); tmp162 = A_arbace_box_elf_A_const_32; seq_581000072__35, chunk_581000073__36, count_581000074__37, i_581000075__38 = lang.IFn_Cast(jrt.NN(tmp162).GetRawRoot__O()).Invoke_O__O(seq_581000072__40), c__1927000678__auto____41, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____41))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var vec__581000082__41 any; var tmp163 *lang.Var; A_arbace_box_elf_A_Init(); tmp163 = A_arbace_box_elf_A_const_19; vec__581000082__41 = lang.IFn_Cast(jrt.NN(tmp163).GetRawRoot__O()).Invoke_O__O(seq_581000072__40); var i__42 any = lang.RT_Nth_O_I_O__O(vec__581000082__41, lang.RT_IntCast_J__I(0), nil); var vec__581000085__43 any = lang.RT_Nth_O_I_O__O(vec__581000082__41, lang.RT_IntCast_J__I(1), nil); var off__44 any = lang.RT_Nth_O_I_O__O(vec__581000085__43, lang.RT_IntCast_J__I(0), nil); var size__45 any = lang.RT_Nth_O_I_O__O(vec__581000085__43, lang.RT_IntCast_J__I(1), nil); var h__46 any = lang.Numbers_Add_J_O__Number(shoff__5, lang.Numbers_Multiply_O_J__Number(i__42, shentsize__8))

				jrt.ByteBuffer_Cast(ob__34).PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__46, 24)), lang.RT_LongCast_O__J(off__44))
				jrt.ByteBuffer_Cast(ob__34).PutLong_I_J__ByteBuffer(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__46, 32)), lang.RT_LongCast_O__J(size__45))
//line :113:1
				var tmp164 *lang.Var; A_arbace_box_elf_A_Init(); tmp164 = A_arbace_box_elf_A_const_24; seq_581000072__35, chunk_581000073__36, count_581000074__37, i_581000075__38 = lang.IFn_Cast(jrt.NN(tmp164).GetRawRoot__O()).Invoke_O__O(seq_581000072__40), nil, 0, 0; continue L4 } } }
//line :38:1
		break L4 };















































































	jrt.ByteBuffer_Cast(ob__34).PutInt_I_I__ByteBuffer(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(lang.Numbers_Add_J_O__Number(shoff__5, lang.Numbers_Multiply_O_J__Number(symtab__13, shentsize__8)), 44)), lang.RT_IntCast_J__I(1)); return out__33 }
//line :48:1
func A_arbace_box_elf_cut_symbols_sec__581000018_A_New_J_J_O(p0, p1 int64, p2 any) *A_arbace_box_elf_cut_symbols_sec__581000018_A { A_arbace_box_elf_cut_symbols_sec__581000018_A_Init(); t := &A_arbace_box_elf_cut_symbols_sec__581000018_A{}; t.Ctor_J_J_O(p0, p1, p2); return t }
//line :48:1
func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) Ctor_J_J_O(c__shentsize, c__shoff int64, c__b any) { t.F_shentsize = c__shentsize; t.F_shoff = c__shoff; t.F_b = c__b }
//line :48:1
func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 int64 = t.F_shoff; var h__2 any = lang.Numbers_Add_J_O__Number(tmp1, lang.Numbers_Multiply_O_J__Number(i__1, t.F_shentsize)); var tmp2 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp2 = A_arbace_box_elf_A_const_12; var tmp3 any = tmp2.Ref(); var tmp4 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp5 any = jrt.Integer_ValueOf_I__Integer(tmp4.GetInt_I__I(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__2, 4)))).Ref(); var tmp6 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp6 = A_arbace_box_elf_A_const_13; var tmp7 any = tmp6.Ref(); var tmp8 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp9 any = jrt.Long_ValueOf_J__Long(tmp8.GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__2, 24)))).Ref(); var tmp10 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp10 = A_arbace_box_elf_A_const_14; var tmp11 any = tmp10.Ref(); var tmp12 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp13 any = jrt.Long_ValueOf_J__Long(tmp12.GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__2, 32)))).Ref(); var tmp14 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp14 = A_arbace_box_elf_A_const_15; var tmp15 any = tmp14.Ref(); var tmp16 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp17 any = jrt.Integer_ValueOf_I__Integer(tmp16.GetInt_I__I(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__2, 40)))).Ref(); var tmp18 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp18 = A_arbace_box_elf_A_const_16; var tmp19 any = tmp18.Ref(); var tmp20 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); var tmp21 any = jrt.Long_ValueOf_J__Long(tmp20.GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__2, 48)))).Ref(); var tmp22 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp22 = A_arbace_box_elf_A_const_17; var tmp23 any = tmp22.Ref(); var tmp24 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp7, tmp9, tmp11, tmp13, tmp15, tmp17, tmp19, tmp21, tmp23, jrt.Long_ValueOf_J__Long(tmp24.GetLong_I__J(lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(h__2, 56)))).Ref())) }




func A_arbace_box_elf_cut_symbols_fn__581000020_A_New() *A_arbace_box_elf_cut_symbols_fn__581000020_A { A_arbace_box_elf_cut_symbols_fn__581000020_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000020_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) Ctor() {}
//line :53:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) Invoke_O_O_O__O(self, i__1, s__2 any) any { var tmp1 *lang.Var; A_arbace_box_elf_A_Init(); tmp1 = A_arbace_box_elf_A_const_41; var tmp2 any = jrt.NN(tmp1).GetRawRoot__O(); var tmp3 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp3 = A_arbace_box_elf_A_const_12; if lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Invoke_O__O(s__2)) { return i__1 } else { return nil } }



func A_arbace_box_elf_cut_symbols_fn__581000022_A_New_O(p0 any) *A_arbace_box_elf_cut_symbols_fn__581000022_A { A_arbace_box_elf_cut_symbols_fn__581000022_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000022_A{}; t.Ctor_O(p0); return t }
//line :57:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) Ctor_O(c__secs any) { t.F_secs = c__secs }
//line :57:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) Invoke_O_O__O(self, p1__581000016_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp1 = A_arbace_box_elf_A_const_13; var tmp2 *lang.Keyword = tmp1; return jrt.NN(tmp2).Invoke_O__O(lang.IFn_Cast(t.F_secs).Invoke_O__O(p1__581000016_SHARP___1)) }


















func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A { A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_Init(); t := &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) Ctor_O_O_O_O_O(c__data, c__st, c__strs, c__want, c__b any) { t.F_data = c__data; t.F_st = c__st; t.F_strs = c__strs; t.F_want = c__want; t.F_b = c__b }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) Invoke_O_O__O(self, s__581000039__1 any) any { var tmp1 any = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_New_O_O_O_O_O_O_O(s__581000039__1, t.F_data, t.F_st, t.F_strs, self, t.F_want, t.F_b); var tmp2 *jrt.Class; A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_Init(); tmp2 = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :76:1
func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A { A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_Init(); t := &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) Ctor_O_O_O_O_O_O_O(c__s__581000039, c__data, c__st, c__strs, c__iter__581000038, c__want, c__b any) { t.F_s__581000039 = c__s__581000039; t.F_data = c__data; t.F_st = c__st; t.F_strs = c__strs; t.F_iter__581000038 = c__iter__581000038; t.F_want = c__want; t.F_b = c__b }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) Invoke_O__O(self any) any { { var s__581000039__1 any; var t_ any = t.F_s__581000039; t.F_s__581000039 = nil; s__581000039__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_box_elf_A_Init(); tmp1 = A_arbace_box_elf_A_const_23; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__581000039__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__581000039__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_box_elf_A_Init(); tmp2 = A_arbace_box_elf_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__581000039__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_box_elf_A_Init(); tmp3 = A_arbace_box_elf_A_const_29; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__581000039__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__581000041__6 any; var tmp4 *lang.Var; A_arbace_box_elf_A_Init(); tmp4 = A_arbace_box_elf_A_const_47; b__581000041__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_New_O_O_O_O_O_I_O_O(b__581000041__6, t.F_data, t.F_st, t.F_strs, t.F_want, size__1927001038__auto____5, c__1927001037__auto____4, t.F_b); var tmp6 *jrt.Class; A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_Init(); tmp6 = A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_box_elf_A_Init(); tmp7 = A_arbace_box_elf_A_const_50; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_elf_A_Init(); tmp9 = A_arbace_box_elf_A_const_52; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__581000041__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__581000038); var tmp12 *lang.Var; A_arbace_box_elf_A_Init(); tmp12 = A_arbace_box_elf_A_const_32; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__581000039__3))) } else { var tmp13 *lang.Var; A_arbace_box_elf_A_Init(); tmp13 = A_arbace_box_elf_A_const_50; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_box_elf_A_Init(); tmp15 = A_arbace_box_elf_A_const_52; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__581000041__6), nil) } } else { var i__4 any; var tmp16 *lang.Var; A_arbace_box_elf_A_Init(); tmp16 = A_arbace_box_elf_A_const_19; i__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__581000039__3); var e__5 any; var tmp17 *lang.Keyword
														A_arbace_box_elf_A_Init(); tmp17 = A_arbace_box_elf_A_const_13; e__5 = lang.Numbers_Add_O_O__Number(jrt.NN(tmp17).Invoke_O__O(t.F_st), lang.Numbers_Multiply_J_O__Number(24, i__4))
//line :76:1
	var nm__6 any; var tmp18 *lang.Var

	A_arbace_box_elf_A_Init(); tmp18 = A_arbace_box_elf_A_const_48; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any = t.F_data; var tmp21 any = t.F_strs; var tmp22 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); nm__6 = tmp19.Invoke_O_O__O(tmp20, lang.Numbers_Add_O_J__Number(tmp21, lang.Numbers_And_J_J__J(int64(tmp22.GetInt_I__I(lang.RT_IntCast_O__I(e__5))), 4294967295)))
//line :76:1
	if jrt.A2g_Truth(lang.IFn_Cast(t.F_want).Invoke_O__O(nm__6)) { var tmp23 *lang.Var; A_arbace_box_elf_A_Init(); tmp23 = A_arbace_box_elf_A_const_51; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp25 = A_arbace_box_elf_A_const_26; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp27 = A_arbace_box_elf_A_const_27; var tmp28 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp26, nm__6, tmp27.Ref(), e__5)); var tmp29 lang.IFn = lang.IFn_Cast(t.F_iter__581000038); var tmp30 *lang.Var; A_arbace_box_elf_A_Init(); tmp30 = A_arbace_box_elf_A_const_53; return tmp24.Invoke_O_O__O(tmp28, tmp29.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(s__581000039__3))) } else { var tmp31 *lang.Var; A_arbace_box_elf_A_Init(); tmp31 = A_arbace_box_elf_A_const_53; s__581000039__1 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(s__581000039__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :76:1
func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_New_O_O_O_O_O_I_O_O(p0, p1, p2, p3, p4 any, p5 int32, p6, p7 any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A { A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_Init(); t := &A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A{}; t.Ctor_O_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) Ctor_O_O_O_O_O_I_O_O(c__b__581000041, c__data, c__st, c__strs, c__want any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b any) { t.F_b__581000041 = c__b__581000041; t.F_data = c__data; t.F_st = c__st; t.F_strs = c__strs; t.F_want = c__want; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b = c__b }
//line :76:1
func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) Invoke_O__O(self any) any { { var i__581000040__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__581000040__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__581000040__1)); var e__3 any; var tmp2 *lang.Keyword
																A_arbace_box_elf_A_Init(); tmp2 = A_arbace_box_elf_A_const_13; e__3 = lang.Numbers_Add_O_O__Number(jrt.NN(tmp2).Invoke_O__O(t.F_st), lang.Numbers_Multiply_J_O__Number(24, i__2))
//line :76:1
	var nm__4 any; var tmp3 *lang.Var

	A_arbace_box_elf_A_Init(); tmp3 = A_arbace_box_elf_A_const_48; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = t.F_data; var tmp6 any = t.F_strs; var tmp7 jrt.ByteBuffer_I = jrt.ByteBuffer_Cast(t.F_b); nm__4 = tmp4.Invoke_O_O__O(tmp5, lang.Numbers_Add_O_J__Number(tmp6, lang.Numbers_And_J_J__J(int64(tmp7.GetInt_I__I(lang.RT_IntCast_O__I(e__3))), 4294967295)))
//line :76:1
	if jrt.A2g_Truth(lang.IFn_Cast(t.F_want).Invoke_O__O(nm__4)) { var tmp8 *lang.Var; A_arbace_box_elf_A_Init(); tmp8 = A_arbace_box_elf_A_const_49; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any = t.F_b__581000041; var tmp11 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp11 = A_arbace_box_elf_A_const_26; var tmp12 any = tmp11.Ref(); var tmp13 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp13 = A_arbace_box_elf_A_const_27; tmp9.Invoke_O_O__O(tmp10, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, nm__4, tmp13.Ref(), e__3))); i__581000040__1 = lang.Numbers_Unchecked_inc_J__J(i__581000040__1); continue L1 } else { i__581000040__1 = lang.Numbers_Unchecked_inc_J__J(i__581000040__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_box_elf_cut_symbols_fn__581000052_A_New_O_O(p0, p1 any) *A_arbace_box_elf_cut_symbols_fn__581000052_A { A_arbace_box_elf_cut_symbols_fn__581000052_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000052_A{}; t.Ctor_O_O(p0, p1); return t }
//line :81:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) Ctor_O_O(c__kept, c__data any) { t.F_kept = c__kept; t.F_data = c__data }
//line :81:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) Invoke_O__O(self any) any { { var seq_581000048__1 any; var tmp1 *lang.Var; A_arbace_box_elf_A_Init(); tmp1 = A_arbace_box_elf_A_const_23; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var t_ any = t.F_kept; t.F_kept = nil; tmp3 = t_; seq_581000048__1 = tmp2.Invoke_O__O(tmp3); var chunk_581000049__2 any; var count_581000050__3 int64 = 0; var i_581000051__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z(i_581000051__4, count_581000050__3) { var map__581000053__5 any = lang.Indexed_Cast(chunk_581000049__2).Nth_I__O(lang.RT_IntCast_J__I(i_581000051__4)); var map__581000053__6 any; if lang.ISeq_InstanceOf(map__581000053__5) { var tmp4 *lang.Var; A_arbace_box_elf_A_Init(); tmp4 = A_arbace_box_elf_A_const_24; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__581000053__5)) { var tmp5 *lang.Var; A_arbace_box_elf_A_Init(); tmp5 = A_arbace_box_elf_A_const_25; map__581000053__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__581000053__5), jrt.Object_class.ArrayClass())).Ref() } else { var tmp6 *lang.Var; A_arbace_box_elf_A_Init(); tmp6 = A_arbace_box_elf_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(map__581000053__5)) { var tmp7 *lang.Var; A_arbace_box_elf_A_Init(); tmp7 = A_arbace_box_elf_A_const_19; map__581000053__6 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(map__581000053__5) } else { lang.PersistentArrayMap_Init(); map__581000053__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000053__6 = map__581000053__5 }; var name__7 any; var tmp8 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp8 = A_arbace_box_elf_A_const_26; name__7 = lang.RT_Get_O_O__O(map__581000053__6, tmp8.Ref()); var entry__8 any; var tmp9 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp9 = A_arbace_box_elf_A_const_27; entry__8 = lang.RT_Get_O_O__O(map__581000053__6, tmp9.Ref())
											var tmp10 *lang.Var; A_arbace_box_elf_A_Init(); tmp10 = A_arbace_box_elf_A_const_30; var tmp11 *jrt.ByteArray = jrt.A2g_CastArray[*jrt.ByteArray](t.F_data, jrt.Prim_byte.ArrayClass()); if lang.Util_Equiv_O_J__Z(jrt.NN(tmp10).GetRawRoot__O(), lang.Numbers_ShiftRight_J_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp11, lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(entry__8, 4)))).Ref()), 255), 4)) {
												var tmp12 *lang.Var; A_arbace_box_elf_A_Init(); tmp12 = A_arbace_box_elf_A_const_31; lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_71, nil, Lit_72), jrt.RefArrayOf(jrt.Object_class, nil, name__7, nil)).Ref()) }
//line :81:1
	seq_581000048__1, chunk_581000049__2, count_581000050__3, i_581000051__4 = seq_581000048__1, chunk_581000049__2, count_581000050__3, lang.Numbers_Unchecked_inc_J__J(i_581000051__4); continue L1 } else { var temp__1927000414__auto____5 any; var tmp13 *lang.Var; A_arbace_box_elf_A_Init(); tmp13 = A_arbace_box_elf_A_const_23; temp__1927000414__auto____5 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(seq_581000048__1); if jrt.A2g_Truth(temp__1927000414__auto____5) { var seq_581000048__6 any = temp__1927000414__auto____5; var tmp14 *lang.Var; A_arbace_box_elf_A_Init(); tmp14 = A_arbace_box_elf_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(seq_581000048__6)) { var c__1927000678__auto____7 any; var tmp15 *lang.Var; A_arbace_box_elf_A_Init(); tmp15 = A_arbace_box_elf_A_const_29; c__1927000678__auto____7 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(seq_581000048__6); var tmp16 *lang.Var; A_arbace_box_elf_A_Init(); tmp16 = A_arbace_box_elf_A_const_32; seq_581000048__1, chunk_581000049__2, count_581000050__3, i_581000051__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(seq_581000048__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var map__581000055__7 any; var tmp17 *lang.Var; A_arbace_box_elf_A_Init(); tmp17 = A_arbace_box_elf_A_const_19; map__581000055__7 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(seq_581000048__6); var map__581000055__8 any; if lang.ISeq_InstanceOf(map__581000055__7) { var tmp18 *lang.Var; A_arbace_box_elf_A_Init(); tmp18 = A_arbace_box_elf_A_const_24; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(map__581000055__7)) { var tmp19 *lang.Var; A_arbace_box_elf_A_Init(); tmp19 = A_arbace_box_elf_A_const_25; map__581000055__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(map__581000055__7), jrt.Object_class.ArrayClass())).Ref() } else { var tmp20 *lang.Var; A_arbace_box_elf_A_Init(); tmp20 = A_arbace_box_elf_A_const_23; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(map__581000055__7)) { var tmp21 *lang.Var; A_arbace_box_elf_A_Init(); tmp21 = A_arbace_box_elf_A_const_19; map__581000055__8 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(map__581000055__7) } else { lang.PersistentArrayMap_Init(); map__581000055__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__581000055__8 = map__581000055__7 }; var name__9 any; var tmp22 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp22 = A_arbace_box_elf_A_const_26; name__9 = lang.RT_Get_O_O__O(map__581000055__8, tmp22.Ref()); var entry__10 any; var tmp23 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp23 = A_arbace_box_elf_A_const_27; entry__10 = lang.RT_Get_O_O__O(map__581000055__8, tmp23.Ref())
		var tmp24 *lang.Var; A_arbace_box_elf_A_Init(); tmp24 = A_arbace_box_elf_A_const_30; var tmp25 *jrt.ByteArray = jrt.A2g_CastArray[*jrt.ByteArray](t.F_data, jrt.Prim_byte.ArrayClass()); if lang.Util_Equiv_O_J__Z(jrt.NN(tmp24).GetRawRoot__O(), lang.Numbers_ShiftRight_J_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(tmp25, lang.RT_IntCast_O__I(lang.Numbers_Add_O_J__Number(entry__10, 4)))).Ref()), 255), 4)) {
			var tmp26 *lang.Var; A_arbace_box_elf_A_Init(); tmp26 = A_arbace_box_elf_A_const_31; lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_71, nil, Lit_72), jrt.RefArrayOf(jrt.Object_class, nil, name__9, nil)).Ref()) }
//line :81:1
		var tmp27 *lang.Var; A_arbace_box_elf_A_Init(); tmp27 = A_arbace_box_elf_A_const_24; seq_581000048__1, chunk_581000049__2, count_581000050__3, i_581000051__4 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(seq_581000048__6), nil, 0, 0; continue L1 } } else { return nil } } } }; panic("a2g: unreachable") }





func A_arbace_box_elf_cut_symbols_fn__581000058_A_New() *A_arbace_box_elf_cut_symbols_fn__581000058_A { A_arbace_box_elf_cut_symbols_fn__581000058_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000058_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) Ctor() {}
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) Invoke_O_O_O__O(self, acc__1, k__2 any) any { var tmp1 *lang.Var; A_arbace_box_elf_A_Init(); tmp1 = A_arbace_box_elf_A_const_57; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_New_O(k__2); var tmp4 *jrt.Class; A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_Init(); tmp4 = A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class; if jrt.A2g_Truth(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), acc__1)) { return acc__1 } else { var tmp5 *lang.Var; A_arbace_box_elf_A_Init(); tmp5 = A_arbace_box_elf_A_const_4; return lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(acc__1, k__2) } }
//line :87:1
func A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_New_O(p0 any) *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A { A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_Init(); t := &A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A{}; t.Ctor_O(p0); return t }
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :87:1
func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) Invoke_O_O__O(self, p1__581000017_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp1 = A_arbace_box_elf_A_const_26; var tmp2 any = jrt.NN(tmp1).Invoke_O__O(t.F_k); var tmp3 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp3 = A_arbace_box_elf_A_const_26; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Invoke_O__O(p1__581000017_SHARP___1))).Ref() }
















func A_arbace_box_elf_cut_symbols_place__581000070_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_elf_cut_symbols_place__581000070_A { A_arbace_box_elf_cut_symbols_place__581000070_A_Init(); t := &A_arbace_box_elf_cut_symbols_place__581000070_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :104:1
func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) Ctor_O_O_O(c__places, c__o, c__secs any) { t.F_places = c__places; t.F_o = c__o; t.F_secs = c__secs }
//line :104:1
func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) Invoke_O_O_O__O(self, i__1, bs__2 any) any {
	var tmp1 *lang.Var; A_arbace_box_elf_A_Init(); tmp1 = A_arbace_box_elf_A_const_36; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_o; var tmp4 *lang.Keyword; A_arbace_box_elf_A_Init(); tmp4 = A_arbace_box_elf_A_const_16; var tmp5 *lang.Keyword = tmp4; tmp2.Invoke_O_O__O(tmp3, jrt.NN(tmp5).Invoke_O__O(lang.IFn_Cast(t.F_secs).Invoke_O__O(i__1)))
	var tmp6 *lang.Var; A_arbace_box_elf_A_Init(); tmp6 = A_arbace_box_elf_A_const_37; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any = t.F_places; var tmp9 *lang.Var; A_arbace_box_elf_A_Init(); tmp9 = A_arbace_box_elf_A_const_38; tmp7.Invoke_O_O_O_O__O(tmp8, jrt.NN(tmp9).GetRawRoot__O(), i__1, lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.ByteArrayOutputStream_Cast(t.F_o)).Size__I()).Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](bs__2, jrt.Prim_byte.ArrayClass()))).Ref()))
	var tmp10 jrt.OutputStream_I = jrt.OutputStream_Cast(t.F_o); tmp10.Write_B1__V(jrt.A2g_CastArray[*jrt.ByteArray](bs__2, jrt.Prim_byte.ArrayClass())); return nil
}











type A_arbace_box_elf_A struct{ jrt.Object }

var A_arbace_box_elf_A_const_0 *lang.Var

var A_arbace_box_elf_A_const_1 any

var A_arbace_box_elf_A_const_2 *lang.Var

var A_arbace_box_elf_A_const_3 *lang.Var

var A_arbace_box_elf_A_const_4 *lang.Var

var A_arbace_box_elf_A_const_5 any

var A_arbace_box_elf_A_const_6 *lang.Var

var A_arbace_box_elf_A_const_7 *lang.Var

var A_arbace_box_elf_A_const_8 any

var A_arbace_box_elf_A_const_9 *lang.Var

var A_arbace_box_elf_A_const_10 *lang.Var

var A_arbace_box_elf_A_const_11 *lang.Var

var A_arbace_box_elf_A_const_12 *lang.Keyword

var A_arbace_box_elf_A_const_13 *lang.Keyword

var A_arbace_box_elf_A_const_14 *lang.Keyword

var A_arbace_box_elf_A_const_15 *lang.Keyword

var A_arbace_box_elf_A_const_16 *lang.Keyword

var A_arbace_box_elf_A_const_17 *lang.Keyword

var A_arbace_box_elf_A_const_18 *lang.Var

var A_arbace_box_elf_A_const_19 *lang.Var

var A_arbace_box_elf_A_const_20 *lang.Var

var A_arbace_box_elf_A_const_21 *lang.Var

var A_arbace_box_elf_A_const_22 *lang.Var

var A_arbace_box_elf_A_const_23 *lang.Var

var A_arbace_box_elf_A_const_24 *lang.Var

var A_arbace_box_elf_A_const_25 *lang.Var

var A_arbace_box_elf_A_const_26 *lang.Keyword

var A_arbace_box_elf_A_const_27 *lang.Keyword

var A_arbace_box_elf_A_const_28 *lang.Var

var A_arbace_box_elf_A_const_29 *lang.Var

var A_arbace_box_elf_A_const_30 *lang.Var

var A_arbace_box_elf_A_const_31 *lang.Var

var A_arbace_box_elf_A_const_32 *lang.Var

var A_arbace_box_elf_A_const_33 *lang.Var

var A_arbace_box_elf_A_const_34 *lang.Var

var A_arbace_box_elf_A_const_35 *lang.Var

var A_arbace_box_elf_A_const_36 *lang.Var

var A_arbace_box_elf_A_const_37 *lang.Var

var A_arbace_box_elf_A_const_38 *lang.Var

var A_arbace_box_elf_A_const_39 *lang.Var

var A_arbace_box_elf_A_const_40 *lang.Var

var A_arbace_box_elf_A_const_41 *lang.Var

var A_arbace_box_elf_A_const_42 *lang.Var

var A_arbace_box_elf_A_const_43 *lang.Var

var A_arbace_box_elf_A_const_44 *lang.Var

var A_arbace_box_elf_A_const_45 *lang.Var

var A_arbace_box_elf_A_const_46 *lang.Var

var A_arbace_box_elf_A_const_47 *lang.Var

var A_arbace_box_elf_A_const_48 *lang.Var

var A_arbace_box_elf_A_const_49 *lang.Var

var A_arbace_box_elf_A_const_50 *lang.Var

var A_arbace_box_elf_A_const_51 *lang.Var

var A_arbace_box_elf_A_const_52 *lang.Var

var A_arbace_box_elf_A_const_53 *lang.Var

var A_arbace_box_elf_A_const_54 any

var A_arbace_box_elf_A_const_55 *lang.Var

var A_arbace_box_elf_A_const_56 *lang.Var

var A_arbace_box_elf_A_const_57 *lang.Var

var A_arbace_box_elf_A_const_58 any

var A_arbace_box_elf_A_init jrt.ClassInit

func A_arbace_box_elf_A_Init() { if !A_arbace_box_elf_A_init.Done() { A_arbace_box_elf_A_init.Run(A_arbace_box_elf_A_clinit) } }

func A_arbace_box_elf_A_clinit() { A_arbace_box_elf_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_box_elf_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_box_elf_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_box_elf_A_const_3 = lang.RT_Var_String_String__Var(Lit_0, Lit_3); A_arbace_box_elf_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_4); A_arbace_box_elf_A_const_5 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7))); A_arbace_box_elf_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_box_elf_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); var tmp1 any = lang.RT_Keyword_String_String__Keyword(Lit_5, Lit_10).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; A_arbace_box_elf_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2.Ref())); A_arbace_box_elf_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_box_elf_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_box_elf_A_const_11 = lang.RT_Var_String_String__Var(Lit_5, Lit_13); A_arbace_box_elf_A_const_12 = lang.RT_Keyword_String_String__Keyword(nil, Lit_14); A_arbace_box_elf_A_const_13 = lang.RT_Keyword_String_String__Keyword(nil, Lit_15); A_arbace_box_elf_A_const_14 = lang.RT_Keyword_String_String__Keyword(nil, Lit_16); A_arbace_box_elf_A_const_15 = lang.RT_Keyword_String_String__Keyword(nil, Lit_17); A_arbace_box_elf_A_const_16 = lang.RT_Keyword_String_String__Keyword(nil, Lit_18); A_arbace_box_elf_A_const_17 = lang.RT_Keyword_String_String__Keyword(nil, Lit_19); A_arbace_box_elf_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_box_elf_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_box_elf_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_box_elf_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_box_elf_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_box_elf_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_box_elf_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_box_elf_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_box_elf_A_const_26 = lang.RT_Keyword_String_String__Keyword(nil, Lit_28); A_arbace_box_elf_A_const_27 = lang.RT_Keyword_String_String__Keyword(nil, Lit_29); A_arbace_box_elf_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_box_elf_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_box_elf_A_const_30 = lang.RT_Var_String_String__Var(Lit_5, Lit_32); A_arbace_box_elf_A_const_31 = lang.RT_Var_String_String__Var(Lit_5, Lit_33); A_arbace_box_elf_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_box_elf_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_box_elf_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_box_elf_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_box_elf_A_const_36 = lang.RT_Var_String_String__Var(Lit_5, Lit_18); A_arbace_box_elf_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_box_elf_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_box_elf_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_box_elf_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_box_elf_A_const_41 = lang.RT_Var_String_String__Var(Lit_5, Lit_42); A_arbace_box_elf_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_box_elf_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_box_elf_A_const_44 = lang.RT_Var_String_String__Var(Lit_5, Lit_45); A_arbace_box_elf_A_const_45 = lang.RT_Var_String_String__Var(Lit_5, Lit_46); A_arbace_box_elf_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_box_elf_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_box_elf_A_const_48 = lang.RT_Var_String_String__Var(Lit_5, Lit_49); A_arbace_box_elf_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_box_elf_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_box_elf_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_box_elf_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_box_elf_A_const_53 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_box_elf_A_const_54 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_box_elf_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_box_elf_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_box_elf_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_box_elf_A_const_58 = jrt.Long_ValueOf_J__Long(24).Ref() }

func A_arbace_box_elf_A_New() *A_arbace_box_elf_A { A_arbace_box_elf_A_Init(); t := &A_arbace_box_elf_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf_A) Ctor() {}

func (t *A_arbace_box_elf_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_A_class }

func (t *A_arbace_box_elf_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_A); return ok }

func A_arbace_box_elf_A_Cast(x any) *A_arbace_box_elf_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_A_class)) }; return v }



type A_arbace_box_elf_align_A struct{ jrt.Object }

func (t *A_arbace_box_elf_align_A) Is_Compiler_AOTF2() {}

var A_arbace_box_elf_align_A_fn_class *jrt.Class

var A_arbace_box_elf_align_A_init jrt.ClassInit

func A_arbace_box_elf_align_A_Init() { if !A_arbace_box_elf_align_A_init.Done() { A_arbace_box_elf_align_A_init.Run(A_arbace_box_elf_align_A_clinit) } }

func A_arbace_box_elf_align_A_clinit() { A_arbace_box_elf_align_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_58, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_align_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_align_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_align_A_class }

func (t *A_arbace_box_elf_align_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_align_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_align_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_align_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_align_A); return ok }

func A_arbace_box_elf_align_A_Cast(x any) *A_arbace_box_elf_align_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_align_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_align_A_class)) }; return v }



type A_arbace_box_elf_c_string_A struct{ jrt.Object }

func (t *A_arbace_box_elf_c_string_A) Is_Compiler_AOTF2() {}

var A_arbace_box_elf_c_string_A_fn_class *jrt.Class

var A_arbace_box_elf_c_string_A_init jrt.ClassInit

func A_arbace_box_elf_c_string_A_Init() { if !A_arbace_box_elf_c_string_A_init.Done() { A_arbace_box_elf_c_string_A_init.Run(A_arbace_box_elf_c_string_A_clinit) } }

func A_arbace_box_elf_c_string_A_clinit() { A_arbace_box_elf_c_string_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_59, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_c_string_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_c_string_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_c_string_A_class }

func (t *A_arbace_box_elf_c_string_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_c_string_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_c_string_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_c_string_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_c_string_A); return ok }

func A_arbace_box_elf_c_string_A_Cast(x any) *A_arbace_box_elf_c_string_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_c_string_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_c_string_A_class)) }; return v }



type A_arbace_box_elf_cut_symbols_A struct{ jrt.Object }

func (t *A_arbace_box_elf_cut_symbols_A) Is_Compiler_AOTF2() {}

var A_arbace_box_elf_cut_symbols_A_fn_class *jrt.Class

var A_arbace_box_elf_cut_symbols_A_init jrt.ClassInit

func A_arbace_box_elf_cut_symbols_A_Init() { if !A_arbace_box_elf_cut_symbols_A_init.Done() { A_arbace_box_elf_cut_symbols_A_init.Run(A_arbace_box_elf_cut_symbols_A_clinit) } }

func A_arbace_box_elf_cut_symbols_A_clinit() { A_arbace_box_elf_cut_symbols_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_60, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_cut_symbols_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_cut_symbols_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_cut_symbols_A_class }

func (t *A_arbace_box_elf_cut_symbols_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_cut_symbols_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_cut_symbols_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_cut_symbols_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_cut_symbols_A); return ok }

func A_arbace_box_elf_cut_symbols_A_Cast(x any) *A_arbace_box_elf_cut_symbols_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_cut_symbols_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_cut_symbols_A_class)) }; return v }



type A_arbace_box_elf_cut_symbols_fn__581000020_A struct{ jrt.Object }

func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) Is_Compiler_AOTF2() {}

var A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class *jrt.Class

var A_arbace_box_elf_cut_symbols_fn__581000020_A_init jrt.ClassInit

func A_arbace_box_elf_cut_symbols_fn__581000020_A_Init() { if !A_arbace_box_elf_cut_symbols_fn__581000020_A_init.Done() { A_arbace_box_elf_cut_symbols_fn__581000020_A_init.Run(A_arbace_box_elf_cut_symbols_fn__581000020_A_clinit) } }

func A_arbace_box_elf_cut_symbols_fn__581000020_A_clinit() { A_arbace_box_elf_cut_symbols_fn__581000020_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_68, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_cut_symbols_fn__581000020_A_class }

func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_cut_symbols_fn__581000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_cut_symbols_fn__581000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_cut_symbols_fn__581000020_A); return ok }

func A_arbace_box_elf_cut_symbols_fn__581000020_A_Cast(x any) *A_arbace_box_elf_cut_symbols_fn__581000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_cut_symbols_fn__581000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_cut_symbols_fn__581000020_A_class)) }; return v }



type A_arbace_box_elf_cut_symbols_fn__581000022_A struct{ jrt.Object; F_secs any }

func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) Is_Compiler_AOTF1() {}

var A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class *jrt.Class

var A_arbace_box_elf_cut_symbols_fn__581000022_A_init jrt.ClassInit

func A_arbace_box_elf_cut_symbols_fn__581000022_A_Init() { if !A_arbace_box_elf_cut_symbols_fn__581000022_A_init.Done() { A_arbace_box_elf_cut_symbols_fn__581000022_A_init.Run(A_arbace_box_elf_cut_symbols_fn__581000022_A_clinit) } }

func A_arbace_box_elf_cut_symbols_fn__581000022_A_clinit() { A_arbace_box_elf_cut_symbols_fn__581000022_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_69, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_cut_symbols_fn__581000022_A_class }

func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_cut_symbols_fn__581000022_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_cut_symbols_fn__581000022_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_cut_symbols_fn__581000022_A); return ok }

func A_arbace_box_elf_cut_symbols_fn__581000022_A_Cast(x any) *A_arbace_box_elf_cut_symbols_fn__581000022_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_cut_symbols_fn__581000022_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_cut_symbols_fn__581000022_A_class)) }; return v }



type A_arbace_box_elf_cut_symbols_fn__581000052_A struct{ jrt.Object; F_kept, F_data any }

func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) Is_Compiler_AOTF0() {}

var A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class *jrt.Class

var A_arbace_box_elf_cut_symbols_fn__581000052_A_init jrt.ClassInit

func A_arbace_box_elf_cut_symbols_fn__581000052_A_Init() { if !A_arbace_box_elf_cut_symbols_fn__581000052_A_init.Done() { A_arbace_box_elf_cut_symbols_fn__581000052_A_init.Run(A_arbace_box_elf_cut_symbols_fn__581000052_A_clinit) } }

func A_arbace_box_elf_cut_symbols_fn__581000052_A_clinit() { A_arbace_box_elf_cut_symbols_fn__581000052_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_70, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_cut_symbols_fn__581000052_A_class }

func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_cut_symbols_fn__581000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_cut_symbols_fn__581000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_cut_symbols_fn__581000052_A); return ok }

func A_arbace_box_elf_cut_symbols_fn__581000052_A_Cast(x any) *A_arbace_box_elf_cut_symbols_fn__581000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_cut_symbols_fn__581000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_cut_symbols_fn__581000052_A_class)) }; return v }



type A_arbace_box_elf_cut_symbols_fn__581000058_A struct{ jrt.Object }

func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) Is_Compiler_AOTF2() {}

var A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class *jrt.Class

var A_arbace_box_elf_cut_symbols_fn__581000058_A_init jrt.ClassInit

func A_arbace_box_elf_cut_symbols_fn__581000058_A_Init() { if !A_arbace_box_elf_cut_symbols_fn__581000058_A_init.Done() { A_arbace_box_elf_cut_symbols_fn__581000058_A_init.Run(A_arbace_box_elf_cut_symbols_fn__581000058_A_clinit) } }

func A_arbace_box_elf_cut_symbols_fn__581000058_A_clinit() { A_arbace_box_elf_cut_symbols_fn__581000058_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_73, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_cut_symbols_fn__581000058_A_class }

func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_cut_symbols_fn__581000058_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_cut_symbols_fn__581000058_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_cut_symbols_fn__581000058_A); return ok }

func A_arbace_box_elf_cut_symbols_fn__581000058_A_Cast(x any) *A_arbace_box_elf_cut_symbols_fn__581000058_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_cut_symbols_fn__581000058_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_cut_symbols_fn__581000058_A_class)) }; return v }



type A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A struct{ jrt.Object; F_k any }

func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) Is_Compiler_AOTF1() {}

var A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class *jrt.Class

var A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_init jrt.ClassInit

func A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_Init() { if !A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_init.Done() { A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_init.Run(A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_clinit) } }

func A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_clinit() { A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_74, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_class }

func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A); return ok }

func A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_Cast(x any) *A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_cut_symbols_fn__581000058_fn__581000059_A_class)) }; return v }



type A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A struct{ jrt.Object; F_data, F_st, F_strs, F_want, F_b any }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) Is_Compiler_AOTF1() {}

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class *jrt.Class

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_init jrt.ClassInit

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_Init() { if !A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_init.Done() { A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_init.Run(A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_clinit) } }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_clinit() { A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_75, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_class }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A); return ok }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_Cast(x any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_cut_symbols_iter__581000038__581000042_A_class)) }; return v }



type A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A struct{ jrt.Object; F_s__581000039, F_data, F_st, F_strs, F_iter__581000038, F_want, F_b any }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) Is_Compiler_AOTF0() {}

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class *jrt.Class

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_init jrt.ClassInit

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_Init() { if !A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_init.Done() { A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_init.Run(A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_clinit) } }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_clinit() { A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_76, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_class }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A); return ok }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_Cast(x any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_A_class)) }; return v }



type A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A struct{ jrt.Object; F_b__581000041, F_data, F_st, F_strs, F_want any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b any }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) Is_Compiler_AOTF0() {}

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class *jrt.Class

var A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_init jrt.ClassInit

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_Init() { if !A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_init.Done() { A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_init.Run(A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_clinit) } }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_clinit() { A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_77, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_class }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A); return ok }

func A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_Cast(x any) *A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_cut_symbols_iter__581000038__581000042_fn__581000043_fn__581000044_A_class)) }; return v }



type A_arbace_box_elf_cut_symbols_place__581000070_A struct{ jrt.Object; F_places, F_o, F_secs any }

func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) Is_Compiler_AOTF2() {}

var A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class *jrt.Class

var A_arbace_box_elf_cut_symbols_place__581000070_A_init jrt.ClassInit

func A_arbace_box_elf_cut_symbols_place__581000070_A_Init() { if !A_arbace_box_elf_cut_symbols_place__581000070_A_init.Done() { A_arbace_box_elf_cut_symbols_place__581000070_A_init.Run(A_arbace_box_elf_cut_symbols_place__581000070_A_clinit) } }

func A_arbace_box_elf_cut_symbols_place__581000070_A_clinit() { A_arbace_box_elf_cut_symbols_place__581000070_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_78, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_cut_symbols_place__581000070_A_class }

func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_cut_symbols_place__581000070_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_cut_symbols_place__581000070_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_cut_symbols_place__581000070_A); return ok }

func A_arbace_box_elf_cut_symbols_place__581000070_A_Cast(x any) *A_arbace_box_elf_cut_symbols_place__581000070_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_cut_symbols_place__581000070_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_cut_symbols_place__581000070_A_class)) }; return v }



type A_arbace_box_elf_cut_symbols_sec__581000018_A struct{ jrt.Object; F_shentsize, F_shoff int64; F_b any }

func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) Is_Compiler_AOTF1() {}

var A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class *jrt.Class

var A_arbace_box_elf_cut_symbols_sec__581000018_A_init jrt.ClassInit

func A_arbace_box_elf_cut_symbols_sec__581000018_A_Init() { if !A_arbace_box_elf_cut_symbols_sec__581000018_A_init.Done() { A_arbace_box_elf_cut_symbols_sec__581000018_A_init.Run(A_arbace_box_elf_cut_symbols_sec__581000018_A_clinit) } }

func A_arbace_box_elf_cut_symbols_sec__581000018_A_clinit() { A_arbace_box_elf_cut_symbols_sec__581000018_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_79, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_cut_symbols_sec__581000018_A_class }

func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_cut_symbols_sec__581000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_cut_symbols_sec__581000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_cut_symbols_sec__581000018_A); return ok }

func A_arbace_box_elf_cut_symbols_sec__581000018_A_Cast(x any) *A_arbace_box_elf_cut_symbols_sec__581000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_cut_symbols_sec__581000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_cut_symbols_sec__581000018_A_class)) }; return v }



type A_arbace_box_elf_eval581000004_A struct{ jrt.Object }

func A_arbace_box_elf_eval581000004_A_New() *A_arbace_box_elf_eval581000004_A { t := &A_arbace_box_elf_eval581000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf_eval581000004_A) Ctor() {}

func (t *A_arbace_box_elf_eval581000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_eval581000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_eval581000004_A_class }

func (t *A_arbace_box_elf_eval581000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_eval581000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_eval581000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_eval581000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_eval581000004_A); return ok }

func A_arbace_box_elf_eval581000004_A_Cast(x any) *A_arbace_box_elf_eval581000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_eval581000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_eval581000004_A_class)) }; return v }



type A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A struct{ jrt.Object }

func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) Is_Compiler_AOTF0() {}

var A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_fn_class *jrt.Class

var A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_init jrt.ClassInit

func A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_Init() { if !A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_init.Done() { A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_init.Run(A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_clinit) } }

func A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_clinit() { A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_80, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_class }

func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A); return ok }

func A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_Cast(x any) *A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_eval581000004_loading__1927001464__auto____581000005_A_class)) }; return v }



type A_arbace_box_elf_eval581000008_A struct{ jrt.Object }

func A_arbace_box_elf_eval581000008_A_New() *A_arbace_box_elf_eval581000008_A { t := &A_arbace_box_elf_eval581000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_elf_eval581000008_A) Ctor() {}

func (t *A_arbace_box_elf_eval581000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_eval581000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_eval581000008_A_class }

func (t *A_arbace_box_elf_eval581000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_eval581000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_eval581000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_eval581000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_eval581000008_A); return ok }

func A_arbace_box_elf_eval581000008_A_Cast(x any) *A_arbace_box_elf_eval581000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_eval581000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_eval581000008_A_class)) }; return v }



type A_arbace_box_elf_eval581000008_fn__581000009_A struct{ jrt.Object }

func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) Is_Compiler_AOTF0() {}

var A_arbace_box_elf_eval581000008_fn__581000009_A_fn_class *jrt.Class

var A_arbace_box_elf_eval581000008_fn__581000009_A_init jrt.ClassInit

func A_arbace_box_elf_eval581000008_fn__581000009_A_Init() { if !A_arbace_box_elf_eval581000008_fn__581000009_A_init.Done() { A_arbace_box_elf_eval581000008_fn__581000009_A_init.Run(A_arbace_box_elf_eval581000008_fn__581000009_A_clinit) } }

func A_arbace_box_elf_eval581000008_fn__581000009_A_clinit() { A_arbace_box_elf_eval581000008_fn__581000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_85, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_eval581000008_fn__581000009_A_class }

func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_eval581000008_fn__581000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_eval581000008_fn__581000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_eval581000008_fn__581000009_A); return ok }

func A_arbace_box_elf_eval581000008_fn__581000009_A_Cast(x any) *A_arbace_box_elf_eval581000008_fn__581000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_eval581000008_fn__581000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_eval581000008_fn__581000009_A_class)) }; return v }



type A_arbace_box_elf_fail_A struct{ jrt.Object }

func (t *A_arbace_box_elf_fail_A) Is_Compiler_AOTF1() {}

var A_arbace_box_elf_fail_A_fn_class *jrt.Class

var A_arbace_box_elf_fail_A_init jrt.ClassInit

func A_arbace_box_elf_fail_A_Init() { if !A_arbace_box_elf_fail_A_init.Done() { A_arbace_box_elf_fail_A_init.Run(A_arbace_box_elf_fail_A_clinit) } }

func A_arbace_box_elf_fail_A_clinit() { A_arbace_box_elf_fail_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_86, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_fail_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_fail_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_fail_A_class }

func (t *A_arbace_box_elf_fail_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_fail_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_fail_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_fail_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_fail_A); return ok }

func A_arbace_box_elf_fail_A_Cast(x any) *A_arbace_box_elf_fail_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_fail_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_fail_A_class)) }; return v }



type A_arbace_box_elf_le_A struct{ jrt.Object }

func (t *A_arbace_box_elf_le_A) Is_Compiler_AOTF1() {}

var A_arbace_box_elf_le_A_fn_class *jrt.Class

var A_arbace_box_elf_le_A_init jrt.ClassInit

func A_arbace_box_elf_le_A_Init() { if !A_arbace_box_elf_le_A_init.Done() { A_arbace_box_elf_le_A_init.Run(A_arbace_box_elf_le_A_clinit) } }

func A_arbace_box_elf_le_A_clinit() { A_arbace_box_elf_le_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_88, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_elf_le_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_elf_le_A) GetClass__Class() *jrt.Class { return A_arbace_box_elf_le_A_class }

func (t *A_arbace_box_elf_le_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_elf_le_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_elf_le_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_elf_le_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_elf_le_A); return ok }

func A_arbace_box_elf_le_A_Cast(x any) *A_arbace_box_elf_le_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_elf_le_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_elf_le_A_class)) }; return v }
