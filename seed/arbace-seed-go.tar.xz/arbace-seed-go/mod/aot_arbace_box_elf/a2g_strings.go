//line a2g_strings.ae:1
package aot_arbace_box_elf

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn3,docks14,arbace.box.elf5,errorkn4,typekn6,offsetkn4,sizekn4,linkkn5,alignkn7,entsizekn4,namekn5,entryv11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn14,arbace.box.elfm2,R1,s572,(cut-symbols image names): image (the bytes of a 64-bit little-endian ELF executable whose\n  .symtab, .strtab and .shstrtab are the last things in the file, as Go's linker writes them)\n  with a symbol table of the named symbols alone, in the image's order, each of which it must\n  define as a global symbol: everything before the three tables as it is, then the three, each\n  aligned as its section header says; only their offsets and sizes and the symbol table's first\n  global index change. tools/elfsyms does the same with Go's debug/elf; the two give the same\n  bytes.v11,arbace.core13,*loaded-libs*v11,arbace.core7,ex-infom2,R2,Tv11,arbace.core3,notv11,arbace.core3,modv14,arbace.box.elf2,leR3,R4,R5,R6,R7,R8,v11,arbace.core4,mapvv11,arbace.core5,firstv11,arbace.core7,sort-byv11,arbace.core3,setv11,arbace.core3,vecv11,arbace.core3,seqv11,arbace.core4,nextv11,arbace.core8,to-arrayR9,R10,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv14,arbace.box.elf9,STB_LOCALv14,arbace.box.elf4,failv11,arbace.core10,chunk-restv11,arbace.core4,sortv11,arbace.core6,reducev11,arbace.core4,atomv14,arbace.box.elf5,alignv11,arbace.core5,swap!v11,arbace.core5,assocv11,arbace.core5,rangev11,arbace.core12,keep-indexedv14,arbace.box.elf10,SHT_SYMTABv11,arbace.core11,map-indexedv11,arbace.core6,vectorv14,arbace.box.elf10,SHT_NOBITSv14,arbace.box.elf8,SHT_NULLv11,arbace.core4,lastv11,arbace.core12,chunk-bufferv14,arbace.box.elf8,c-stringv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core4,restl1,v11,arbace.core6,removev11,arbace.core3,mapv11,arbace.core4,somel24,")

var Lit_1 *jrt.String = jrt.Intern("not a 64-bit little-endian ELF file")

var Lit_2 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$sec__581000018")

var Lit_3 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$fn__581000020")

var Lit_4 *jrt.String = jrt.Intern("no symbol table")

var Lit_5 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$fn__581000022")

var Lit_6 *jrt.String = jrt.Intern("the section headers are not before the symbol table")

var Lit_7 *jrt.String = jrt.Intern("a section is after the symbol table")

var Lit_8 *jrt.String = jrt.Intern("a segment is after the symbol table")

var Lit_9 *jrt.String = jrt.Intern("something after the symbol table and the section names")

var Lit_10 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$iter__581000038__581000042")

var Lit_11 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$fn__581000052")

var Lit_12 *jrt.String = jrt.Intern("no symbol ")

var Lit_13 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$fn__581000058")

var Lit_14 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$place__581000070")

var Lit_15 *jrt.String = jrt.Intern("symbol ")

var Lit_16 *jrt.String = jrt.Intern(" is local")

var Lit_17 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$fn__581000058$fn__581000059")

var Lit_18 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$iter__581000038__581000042$fn__581000043")

var Lit_19 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$iter__581000038__581000042$fn__581000043$fn__581000044")

var Lit_20 *jrt.String = jrt.Intern("java.io.ByteArrayOutputStream")

var Lit_21 *jrt.String = jrt.Intern("java.nio.ByteBuffer")

var Lit_22 *jrt.String = jrt.Intern("java.nio.ByteOrder")

var Lit_23 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_24 *jrt.String = jrt.Intern("arbace.box.elf: ")

var Lit_25 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,msgkn4,linekn6,columnkn4,filekn3,tagyn5,bytesyn19,java.nio.ByteBufferyn4,longyn21,ByteArrayOutputStreamyn29,java.io.ByteArrayOutputStreamyn5,namesv11,arbace.core5,in-nsMyn14,arbace.box.elfm2,R0,s572,(cut-symbols image names): image (the bytes of a 64-bit little-endian ELF executable whose\n  .symtab, .strtab and .shstrtab are the last things in the file, as Go's linker writes them)\n  with a symbol table of the named symbols alone, in the image's order, each of which it must\n  define as a global symbol: everything before the three tables as it is, then the three, each\n  aligned as its section header says; only their offsets and sizes and the symbol table's first\n  global index change. tools/elfsyms does the same with Go's debug/elf; the two give the same\n  bytes.m2,R0,s572,(cut-symbols image names): image (the bytes of a 64-bit little-endian ELF executable whose\n  .symtab, .strtab and .shstrtab are the last things in the file, as Go's linker writes them)\n  with a symbol table of the named symbols alone, in the image's order, each of which it must\n  define as a global symbol: everything before the three tables as it is, then the three, each\n  aligned as its section header says; only their offsets and sizes and the symbol table's first\n  global index change. tools/elfsyms does the same with Go's debug/elf; the two give the same\n  bytes.R1,v14,arbace.box.elf4,failm10,R2,TR3,L1,V1,R4,R5,i15,R6,i1,R7,s17,arbace/box/elf.aev14,arbace.box.elf8,SHT_NULLl0,m8,R2,TR5,i18,R6,i1,R7,s17,arbace/box/elf.aev14,arbace.box.elf10,SHT_SYMTABl2,m8,R2,TR5,i19,R6,i1,R7,s17,arbace/box/elf.aev14,arbace.box.elf10,SHT_NOBITSl8,m8,R2,TR5,i20,R6,i1,R7,s17,arbace/box/elf.aev14,arbace.box.elf9,STB_LOCALm8,R2,TR5,i21,R6,i1,R7,s17,arbace/box/elf.aev14,arbace.box.elf2,lem10,R2,TR3,L1,MV1,Myn1,bm2,R8,R9,m2,R8,R10,R5,i23,R6,i1,R7,s17,arbace/box/elf.aev14,arbace.box.elf8,c-stringm10,R2,TR3,L1,V2,Myn1,bm2,R8,R9,Myn3,offm2,R8,R11,R5,i26,R6,i1,R7,s17,arbace/box/elf.aev14,arbace.box.elf5,alignm10,R2,TR3,L1,MV2,Myn1,om2,R8,R12,Myn1,am2,R8,R11,m2,R8,R13,R5,i32,R6,i1,R7,s17,arbace/box/elf.aev14,arbace.box.elf11,cut-symbolsm10,R3,L1,MV2,Myn4,datam2,R8,R9,R14,m2,R8,R9,R0,s90,Image (bytes) with its symbol table cut to names (see the namespace's doc): the new bytes.R5,i38,R6,i1,R7,s17,arbace/box/elf.ae")

var Lit_26 *jrt.String = jrt.Intern("arbace.box.elf$eval581000004$loading__1927001464__auto____581000005")

var Lit_27 *jrt.String = jrt.Intern("arbace.box.elf$eval581000008$fn__581000009")

var Lit_28 *jrt.String = jrt.Intern("arbace.box.elf$fail")

var Lit_29 *jrt.String = jrt.Intern("arbace.box.elf$le")

var Lit_30 *jrt.String = jrt.Intern("arbace.box.elf$c_string")

var Lit_31 *jrt.String = jrt.Intern("arbace.box.elf$align")

var Lit_32 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols")
