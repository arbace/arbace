//line a2g_strings.ae:1
package aot_arbace_box_elf

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("commute")

var Lit_3 *jrt.String = jrt.Intern("deref")

var Lit_4 *jrt.String = jrt.Intern("conj")

var Lit_5 *jrt.String = jrt.Intern("arbace.box.elf")

var Lit_6 *jrt.String = jrt.Intern("doc")

var Lit_7 *jrt.String = jrt.Intern("(cut-symbols image names): image (the bytes of a 64-bit little-endian ELF executable whose\n  .symtab, .strtab and .shstrtab are the last things in the file, as Go's linker writes them)\n  with a symbol table of the named symbols alone, in the image's order, each of which it must\n  define as a global symbol: everything before the three tables as it is, then the three, each\n  aligned as its section header says; only their offsets and sizes and the symbol table's first\n  global index change. tools/elfsyms does the same with Go's debug/elf; the two give the same\n  bytes.")

var Lit_8 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_9 *jrt.String = jrt.Intern("ex-info")

var Lit_10 *jrt.String = jrt.Intern("error")

var Lit_11 *jrt.String = jrt.Intern("not")

var Lit_12 *jrt.String = jrt.Intern("mod")

var Lit_13 *jrt.String = jrt.Intern("le")

var Lit_14 *jrt.String = jrt.Intern("type")

var Lit_15 *jrt.String = jrt.Intern("offset")

var Lit_16 *jrt.String = jrt.Intern("size")

var Lit_17 *jrt.String = jrt.Intern("link")

var Lit_18 *jrt.String = jrt.Intern("align")

var Lit_19 *jrt.String = jrt.Intern("entsize")

var Lit_20 *jrt.String = jrt.Intern("mapv")

var Lit_21 *jrt.String = jrt.Intern("first")

var Lit_22 *jrt.String = jrt.Intern("sort-by")

var Lit_23 *jrt.String = jrt.Intern("set")

var Lit_24 *jrt.String = jrt.Intern("vec")

var Lit_25 *jrt.String = jrt.Intern("seq")

var Lit_26 *jrt.String = jrt.Intern("next")

var Lit_27 *jrt.String = jrt.Intern("to-array")

var Lit_28 *jrt.String = jrt.Intern("name")

var Lit_29 *jrt.String = jrt.Intern("entry")

var Lit_30 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_31 *jrt.String = jrt.Intern("chunk-first")

var Lit_32 *jrt.String = jrt.Intern("STB_LOCAL")

var Lit_33 *jrt.String = jrt.Intern("fail")

var Lit_34 *jrt.String = jrt.Intern("chunk-rest")

var Lit_35 *jrt.String = jrt.Intern("sort")

var Lit_36 *jrt.String = jrt.Intern("reduce")

var Lit_37 *jrt.String = jrt.Intern("atom")

var Lit_38 *jrt.String = jrt.Intern("swap!")

var Lit_39 *jrt.String = jrt.Intern("assoc")

var Lit_40 *jrt.String = jrt.Intern("range")

var Lit_41 *jrt.String = jrt.Intern("keep-indexed")

var Lit_42 *jrt.String = jrt.Intern("SHT_SYMTAB")

var Lit_43 *jrt.String = jrt.Intern("map-indexed")

var Lit_44 *jrt.String = jrt.Intern("vector")

var Lit_45 *jrt.String = jrt.Intern("SHT_NOBITS")

var Lit_46 *jrt.String = jrt.Intern("SHT_NULL")

var Lit_47 *jrt.String = jrt.Intern("last")

var Lit_48 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_49 *jrt.String = jrt.Intern("c-string")

var Lit_50 *jrt.String = jrt.Intern("chunk-append")

var Lit_51 *jrt.String = jrt.Intern("chunk-cons")

var Lit_52 *jrt.String = jrt.Intern("cons")

var Lit_53 *jrt.String = jrt.Intern("chunk")

var Lit_54 *jrt.String = jrt.Intern("rest")

var Lit_55 *jrt.String = jrt.Intern("remove")

var Lit_56 *jrt.String = jrt.Intern("map")

var Lit_57 *jrt.String = jrt.Intern("some")

var Lit_58 *jrt.String = jrt.Intern("arbace.box.elf$align")

var Lit_59 *jrt.String = jrt.Intern("arbace.box.elf$c_string")

var Lit_60 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols")

var Lit_61 *jrt.String = jrt.Intern("not a 64-bit little-endian ELF file")

var Lit_62 *jrt.String = jrt.Intern("no symbol table")

var Lit_63 *jrt.String = jrt.Intern("the section headers are not before the symbol table")

var Lit_64 *jrt.String = jrt.Intern("a section is after the symbol table")

var Lit_65 *jrt.String = jrt.Intern("a segment is after the symbol table")

var Lit_66 *jrt.String = jrt.Intern("something after the symbol table and the section names")

var Lit_67 *jrt.String = jrt.Intern("no symbol ")

var Lit_68 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$fn__581000020")

var Lit_69 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$fn__581000022")

var Lit_70 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$fn__581000052")

var Lit_71 *jrt.String = jrt.Intern("symbol ")

var Lit_72 *jrt.String = jrt.Intern(" is local")

var Lit_73 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$fn__581000058")

var Lit_74 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$fn__581000058$fn__581000059")

var Lit_75 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$iter__581000038__581000042")

var Lit_76 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$iter__581000038__581000042$fn__581000043")

var Lit_77 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$iter__581000038__581000042$fn__581000043$fn__581000044")

var Lit_78 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$place__581000070")

var Lit_79 *jrt.String = jrt.Intern("arbace.box.elf$cut_symbols$sec__581000018")

var Lit_80 *jrt.String = jrt.Intern("arbace.box.elf$eval581000004$loading__1927001464__auto____581000005")

var Lit_81 *jrt.String = jrt.Intern("java.io.ByteArrayOutputStream")

var Lit_82 *jrt.String = jrt.Intern("java.nio.ByteBuffer")

var Lit_83 *jrt.String = jrt.Intern("java.nio.ByteOrder")

var Lit_84 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_85 *jrt.String = jrt.Intern("arbace.box.elf$eval581000008$fn__581000009")

var Lit_86 *jrt.String = jrt.Intern("arbace.box.elf$fail")

var Lit_87 *jrt.String = jrt.Intern("arbace.box.elf: ")

var Lit_88 *jrt.String = jrt.Intern("arbace.box.elf$le")

var Lit_89 *jrt.String = jrt.Intern("in-ns")

var Lit_90 *jrt.String = jrt.Intern("private")

var Lit_91 *jrt.String = jrt.Intern("arglists")

var Lit_92 *jrt.String = jrt.Intern("msg")

var Lit_93 *jrt.String = jrt.Intern("line")

var Lit_94 *jrt.String = jrt.Intern("column")

var Lit_95 *jrt.String = jrt.Intern("file")

var Lit_96 *jrt.String = jrt.Intern("arbace/box/elf.ae")

var Lit_97 *jrt.String = jrt.Intern("b")

var Lit_98 *jrt.String = jrt.Intern("tag")

var Lit_99 *jrt.String = jrt.Intern("bytes")

var Lit_100 *jrt.String = jrt.Intern("off")

var Lit_101 *jrt.String = jrt.Intern("long")

var Lit_102 *jrt.String = jrt.Intern("o")

var Lit_103 *jrt.String = jrt.Intern("ByteArrayOutputStream")

var Lit_104 *jrt.String = jrt.Intern("a")

var Lit_105 *jrt.String = jrt.Intern("cut-symbols")

var Lit_106 *jrt.String = jrt.Intern("data")

var Lit_107 *jrt.String = jrt.Intern("names")

var Lit_108 *jrt.String = jrt.Intern("Image (bytes) with its symbol table cut to names (see the namespace's doc): the new bytes.")
