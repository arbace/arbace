//line aot_arbace_repr_clojure_text.ae:1
package aot_arbace_repr_clojure_text

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A_New() *A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_text_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_text_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_clojure_text_eval670000008_fn__670000009_A_New() *A_arbace_repr_clojure_text_eval670000008_fn__670000009_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_eval670000008_fn__670000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000008_fn__670000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000008_fn__670000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_4.GetRawRoot__O()); var tmp2 any; var root_9 any = A_arbace_repr_clojure_text_A_const_5.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = A_arbace_repr_clojure_text_A_const_6; if linked_10 == nil { tmp2 = ifn_11.Invoke_O__O(arg_12) } else { tmp2 = linked_10.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_9, arg_12) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_clojure_text_A_const_7.GetRawRoot__O(), A_arbace_repr_clojure_text_A_const_8) }
















func A_arbace_repr_clojure_text_fail_A_New() *A_arbace_repr_clojure_text_fail_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_fail_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_repr_clojure_text_fail_A) Ctor() {}
//line :18:1
func (t *A_arbace_repr_clojure_text_fail_A) Invoke_O_O_O_O__O(self, s__0, i__1, msg__2 any) any { var line__4 int64; var tmp1 any; var root_26 any = A_arbace_repr_clojure_text_A_const_9.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_28 lang.IFn; if
												linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any; var tmp2 any = A_arbace_repr_clojure_text_fail_fn__670000013_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_repr_clojure_text_fail_fn__670000013_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_repr_clojure_text_fail_fn__670000013_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; arg_29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_30 any; var root_20 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = s__0; var arg_24 any = A_arbace_repr_clojure_text_A_const_12; var arg_25 any = lang.Numbers_Min_O_J__O_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(s__0))); if linked_21 == nil { arg_30 = ifn_22.Invoke_O_O_O__O(arg_23, arg_24, arg_25) } else { arg_30 = linked_21.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_20, arg_23, arg_24, arg_25) }; if linked_27 == nil { tmp1 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { tmp1 = linked_27.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; line__4 = lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp1))); var tmp4 any; var root_31 any = /*line :18:1*/A_arbace_repr_clojure_text_A_const_13.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_33 lang.IFn; if

	linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, msg__2, nil, jrt.Long_ValueOf_J__Long_NoInit(line__4).Ref(), nil)).Ref(); var tmp5 any = A_arbace_repr_clojure_text_A_const_14; var tmp6 any = A_arbace_repr_clojure_text_A_const_15; var arg_35 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, i__1, tmp6, jrt.Long_ValueOf_J__Long_NoInit(line__4).Ref())); if linked_32 == nil { tmp4 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { tmp4 = linked_32.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; /*line :18:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp4))) }
func A_arbace_repr_clojure_text_fail_fn__670000013_A_New() *A_arbace_repr_clojure_text_fail_fn__670000013_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_fail_fn__670000013_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_repr_clojure_text_fail_fn__670000013_A) Ctor() {}
//line :19:1
func (t *A_arbace_repr_clojure_text_fail_fn__670000013_A) Invoke_O_O__O(self, p1__670000012_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_clojure_text_A_const_10, p1__670000012_SHARP___1)).Ref() }


func A_arbace_repr_clojure_text_ws_QMARK__A_New() *A_arbace_repr_clojure_text_ws_QMARK__A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_ws_QMARK__A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_repr_clojure_text_ws_QMARK__A) Ctor() {}
//line :22:1
func (t *A_arbace_repr_clojure_text_ws_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 bool = jrt.Character_IsWhitespace_C__Z_NoInit(lang.RT_CharCast_O__C_NoInit(c__0)); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(c__0, A_arbace_repr_clojure_text_A_const_16)).Ref() } }

func A_arbace_repr_clojure_text_terminating_QMARK__A_New() *A_arbace_repr_clojure_text_terminating_QMARK__A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_terminating_QMARK__A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_repr_clojure_text_terminating_QMARK__A) Ctor() {}
//line :24:1
func (t *A_arbace_repr_clojure_text_terminating_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 any; var root_36 any = A_arbace_repr_clojure_text_A_const_17.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, A_arbace_repr_clojure_text_ws_QMARK__A_fn_class); var ifn_38 lang.IFn; if



	linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = c__0; if linked_37 == nil { or__1927000174__auto____2 = ifn_38.Invoke_O__O(arg_39) } else { or__1927000174__auto____2 = linked_37.(*A_arbace_repr_clojure_text_ws_QMARK__A).Invoke_O_O__O(root_36, arg_39) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var G__670000017__3_ any = c__0; switch lang.Util_Hash_O__I_NoInit(G__670000017__3_) { case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_18) { return jrt.Boolean_TRUE.Ref() }; case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_19) { return jrt.Boolean_TRUE.Ref() }; case 41: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_20) { return jrt.Boolean_TRUE.Ref() }; case 59: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_21) { return jrt.Boolean_TRUE.Ref() }; case 64: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_22) { return jrt.Boolean_TRUE.Ref() }; case 91: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_23) { return jrt.Boolean_TRUE.Ref() }; case 92: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_24) { return jrt.Boolean_TRUE.Ref() }; case 93: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_25) { return jrt.Boolean_TRUE.Ref() }; case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_26) { return jrt.Boolean_TRUE.Ref() }; case 96: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_27) { return jrt.Boolean_TRUE.Ref() }; case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_28) { return jrt.Boolean_TRUE.Ref() }; case 125: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_29) { return jrt.Boolean_TRUE.Ref() }; case 126: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_30) { return jrt.Boolean_TRUE.Ref() }; default:}; return jrt.Boolean_FALSE.Ref() } }

func A_arbace_repr_clojure_text_at_A_New() *A_arbace_repr_clojure_text_at_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_at_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_repr_clojure_text_at_A) Ctor() {}
//line :30:1
func (t *A_arbace_repr_clojure_text_at_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var tmp1 bool; var na_41 any = i__1; var na_42 int64 = int64(lang.RT_Count_O__I_NoInit(s__0)); if jrt.Long_InstanceOf(na_41) { var n0_43 int64 = jrt.NN(jrt.Long_Cast(na_41)).LongValue__J(); var n1_44 int64 = na_42; tmp1 = n0_43 < n1_44 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_41, na_42) }; if tmp1 { return jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__1))).Ref() } else { return nil } }

func A_arbace_repr_clojure_text_line_end_A_New() *A_arbace_repr_clojure_text_line_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_line_end_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_repr_clojure_text_line_end_A) Ctor() {}
//line :32:1
func (t *A_arbace_repr_clojure_text_line_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 int32 = jrt.NN(jrt.String_Cast(s__0)).IndexOf_String_I__I(Lit_15, lang.RT_IntCast_O__I_NoInit(i__1)); if
												lang.Numbers_IsNeg_J__Z_NoInit(int64(j__3)) { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(s__0)).Ref() } else { return jrt.Integer_ValueOf_I__Integer_NoInit(j__3).Ref() } }

func A_arbace_repr_clojure_text_token_end_A_New() *A_arbace_repr_clojure_text_token_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_token_end_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_repr_clojure_text_token_end_A) Ctor() {}
//line :35:1
func (t *A_arbace_repr_clojure_text_token_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var j__4 any = i__1; L1: for {



	var tmp1 any; var and__1927000168__auto____5 bool; var na_46 any = j__4; var na_47 int64 = int64(n__3); if jrt.Long_InstanceOf(na_46) { var n0_48 int64 = jrt.NN(jrt.Long_Cast(na_46)).LongValue__J(); var n1_49 int64 = na_47; and__1927000168__auto____5 = n0_48 < n1_49 } else { and__1927000168__auto____5 = lang.Numbers_Lt_O_J__Z_NoInit(na_46, na_47) }; if and__1927000168__auto____5 { var root_55 any = A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any; var root_51 any = A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))).Ref(); if linked_52 == nil { arg_58 = ifn_53.Invoke_O__O(arg_54) } else { arg_58 = linked_52.(*A_arbace_repr_clojure_text_terminating_QMARK__A).Invoke_O_O__O(root_51, arg_54) }; if linked_56 == nil { tmp1 = ifn_57.Invoke_O__O(arg_58) } else { tmp1 = linked_56.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_55, arg_58) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp1) { var tmp2 jrt.Number_I; var na_59 any = j__4; if jrt.Long_InstanceOf(na_59) { var n0_60 int64 = jrt.NN(jrt.Long_Cast(na_59)).LongValue__J(); if n0_60 == 9223372036854775807 { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_59) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_60 + 1)) } } else { if jrt.Double_InstanceOf(na_59) { var n0_60_2 float64 = jrt.NN(jrt.Double_Cast(na_59)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_60_2 + 1.0)) } else { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_59) } }; j__4 = tmp2; continue L1 } else { return j__4 } } }; /*line :35:1*/panic("j2g: unreachable") }





func A_arbace_repr_clojure_text_string_end_A_New() *A_arbace_repr_clojure_text_string_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_string_end_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_repr_clojure_text_string_end_A) Ctor() {}
//line :41:1
func (t *A_arbace_repr_clojure_text_string_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var j__4 any
												var na_61 any = i__1


	if jrt.Long_InstanceOf(na_61) { var n0_62 int64 = jrt.NN(jrt.Long_Cast(na_61)).LongValue__J(); if n0_62 == 9223372036854775807 { j__4 = lang.Numbers_Inc_O__Number_NoInit(na_61) } else { j__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_62 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_61) { var n0_62_2 float64 = jrt.NN(jrt.Double_Cast(na_61)).DoubleValue__D(); j__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_62_2 + 1.0).Ref() } else { j__4 = lang.Numbers_Inc_O__Number_NoInit(na_61) } }
//line :41:1
L1: for {




	var tmp1 bool; var na_63 any = j__4; var na_64 int64 = int64(n__3); if jrt.Long_InstanceOf(na_63) { var n0_65 int64 = jrt.NN(jrt.Long_Cast(na_63)).LongValue__J(); var n1_66 int64 = na_64; tmp1 = n0_65 >= n1_66 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_63, na_64) }; if tmp1 { var root_68 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = s__0; var arg_72 any = i__1; var arg_73 any = Lit_22; if linked_69 == nil { return ifn_70.Invoke_O_O_O__O(arg_71, arg_72, arg_73) } else { return linked_69.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_68, arg_71, arg_72, arg_73) } } else { if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_24)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))) {
		var tmp2 jrt.Number_I; var na_76 any = j__4; var na_77 int64 = 2; if jrt.Long_InstanceOf(na_76) { var n0_78 int64 = jrt.NN(jrt.Long_Cast(na_76)).LongValue__J(); var n1_79 int64 = na_77; var nr_80 int64 = n0_78 + n1_79; if (n0_78^nr_80)&(n1_79^nr_80) >= 0 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_80)) } else { tmp2 = lang.Numbers_Add_O_J__Number_NoInit(na_76, na_77) } } else { tmp2 = lang.Numbers_Add_O_J__Number_NoInit(na_76, na_77) }; j__4 = tmp2; continue L1 } else {
//line :46:1
			if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_18)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))) {

				var na_74 any = j__4; if jrt.Long_InstanceOf(na_74) { var n0_75 int64 = jrt.NN(jrt.Long_Cast(na_74)).LongValue__J(); if n0_75 == 9223372036854775807 { return lang.Numbers_Inc_O__Number_NoInit(na_74) } else { return jrt.Long_ValueOf_J__Long_NoInit(n0_75 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_74) { var n0_75_2 float64 = jrt.NN(jrt.Double_Cast(na_74)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_75_2 + 1.0).Ref() } else { return lang.Numbers_Inc_O__Number_NoInit(na_74) } } } else {
//line :46:1
					if A_arbace_repr_clojure_text_A_const_34 != nil {


						var tmp3 jrt.Number_I; var na_81 any = j__4; if jrt.Long_InstanceOf(na_81) { var n0_82 int64 = jrt.NN(jrt.Long_Cast(na_81)).LongValue__J(); if n0_82 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_81) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_82 + 1)) } } else { if jrt.Double_InstanceOf(na_81) { var n0_82_2 float64 = jrt.NN(jrt.Double_Cast(na_81)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_82_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_81) } }; j__4 = tmp3; continue L1 } else {
//line :46:1
							return nil } } } } } }; /*line :41:1*/panic("j2g: unreachable") }









func A_arbace_repr_clojure_text_char_end_A_New() *A_arbace_repr_clojure_text_char_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_char_end_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_repr_clojure_text_char_end_A) Ctor() {}
//line :51:1
func (t *A_arbace_repr_clojure_text_char_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any {



	var tmp1 bool; var na_93 any; var na_95 any = i__1; if jrt.Long_InstanceOf(na_95) { var n0_96 int64 = jrt.NN(jrt.Long_Cast(na_95)).LongValue__J(); if n0_96 == 9223372036854775807 { na_93 = lang.Numbers_Inc_O__Number_NoInit(na_95) } else { na_93 = jrt.Long_ValueOf_J__Long_NoInit(n0_96 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_95) { var n0_96_2 float64 = jrt.NN(jrt.Double_Cast(na_95)).DoubleValue__D(); na_93 = jrt.Double_ValueOf_D__Double_NoInit(n0_96_2 + 1.0).Ref() } else { na_93 = lang.Numbers_Inc_O__Number_NoInit(na_95) } }; var na_94 int64 = int64(lang.RT_Count_O__I_NoInit(s__0)); if jrt.Long_InstanceOf(na_93) { var n0_97 int64 = jrt.NN(jrt.Long_Cast(na_93)).LongValue__J(); var n1_98 int64 = na_94; tmp1 = n0_97 >= n1_98 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_93, na_94) }; if tmp1 { var root_100 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = s__0; var arg_104 any = i__1; var arg_105 any = Lit_4; if linked_101 == nil { ifn_102.Invoke_O_O_O__O(arg_103, arg_104, arg_105) } else { linked_101.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_100, arg_103, arg_104, arg_105) } }
	var root_88 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = s__0; var arg_92 any; var na_83 any = i__1; var na_84 int64 = 2; if jrt.Long_InstanceOf(na_83) { var n0_85 int64 = jrt.NN(jrt.Long_Cast(na_83)).LongValue__J(); var n1_86 int64 = na_84; var nr_87 int64 = n0_85 + n1_86; if (n0_85^nr_87)&(n1_86^nr_87) >= 0 { arg_92 = jrt.Long_ValueOf_J__Long_NoInit(nr_87).Ref() } else { arg_92 = lang.Numbers_Add_O_J__Number_NoInit(na_83, na_84) } } else { arg_92 = lang.Numbers_Add_O_J__Number_NoInit(na_83, na_84) }; if linked_89 == nil { return ifn_90.Invoke_O_O__O(arg_91, arg_92) } else { return linked_89.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_88, arg_91, arg_92)
	}
}

func A_arbace_repr_clojure_text_skip_ws_A_New() *A_arbace_repr_clojure_text_skip_ws_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_skip_ws_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_repr_clojure_text_skip_ws_A) Ctor() {}
//line :60:1
func (t *A_arbace_repr_clojure_text_skip_ws_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var i__4 any = i__1; L1: for {





	var tmp1 bool; var na_106 any = i__4; var na_107 int64 = int64(n__3); if jrt.Long_InstanceOf(na_106) { var n0_108 int64 = jrt.NN(jrt.Long_Cast(na_106)).LongValue__J(); var n1_109 int64 = na_107; tmp1 = n0_108 >= n1_109 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_106, na_107) }; if tmp1 { return i__4 } else { var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__4)); var tmp2 any; var root_111 any = A_arbace_repr_clojure_text_A_const_17.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, A_arbace_repr_clojure_text_ws_QMARK__A_fn_class); var ifn_113 lang.IFn


		if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = jrt.Character_ValueOf_C__Character_NoInit(c__5).Ref(); if linked_112 == nil { tmp2 = ifn_113.Invoke_O__O(arg_114) } else { tmp2 = linked_112.(*A_arbace_repr_clojure_text_ws_QMARK__A).Invoke_O_O__O(root_111, arg_114) }; if jrt.J2g_Truth(tmp2) { var tmp3 jrt.Number_I; var na_129 any = i__4; if jrt.Long_InstanceOf(na_129) { var n0_130 int64 = jrt.NN(jrt.Long_Cast(na_129)).LongValue__J(); if n0_130 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_129) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_130 + 1)) } } else { if jrt.Double_InstanceOf(na_129) { var n0_130_2 float64 = jrt.NN(jrt.Double_Cast(na_129)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_130_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_129) } }; i__4 = tmp3; continue L1 } else { if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_21)).CharValue__C()) {
			var tmp4 any; var root_131 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = s__0; var arg_135 any = i__4; if linked_132 == nil { tmp4 = ifn_133.Invoke_O_O__O(arg_134, arg_135) } else { tmp4 = linked_132.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_131, arg_134, arg_135) }; i__4 = tmp4; continue L1 } else {
//line :69:1
				var tmp5 bool; var and__1927000168__auto____6 bool = lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())

				if and__1927000168__auto____6 { var tmp6 any = A_arbace_repr_clojure_text_A_const_37; var tmp7 any; var root_117 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = s__0; var arg_121 any; var na_115 any = i__4; if jrt.Long_InstanceOf(na_115) { var n0_116 int64 = jrt.NN(jrt.Long_Cast(na_115)).LongValue__J(); if n0_116 == 9223372036854775807 { arg_121 = lang.Numbers_Inc_O__Number_NoInit(na_115) } else { arg_121 = jrt.Long_ValueOf_J__Long_NoInit(n0_116 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_115) { var n0_116_2 float64 = jrt.NN(jrt.Double_Cast(na_115)).DoubleValue__D(); arg_121 = jrt.Double_ValueOf_D__Double_NoInit(n0_116_2 + 1.0).Ref() } else { arg_121 = lang.Numbers_Inc_O__Number_NoInit(na_115) } }; if linked_118 == nil { tmp7 = ifn_119.Invoke_O_O__O(arg_120, arg_121) } else { tmp7 = linked_118.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_117, arg_120, arg_121) }; tmp5 = lang.Util_Equiv_O_O__Z_NoInit(tmp6, tmp7) } else { tmp5 = and__1927000168__auto____6 }
//line :69:1
				if tmp5 {

					var tmp8 any; var root_136 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = s__0; var arg_140 any = i__4; if linked_137 == nil { tmp8 = ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { tmp8 = linked_137.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }; i__4 = tmp8; continue L1 } else {
//line :69:1
						var tmp9 bool; var and__1927000168__auto____6_2 bool = lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())


						if and__1927000168__auto____6_2 { var tmp10 any = A_arbace_repr_clojure_text_A_const_39; var tmp11 any; var root_124 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = s__0; var arg_128 any; var na_122 any = i__4; if jrt.Long_InstanceOf(na_122) { var n0_123 int64 = jrt.NN(jrt.Long_Cast(na_122)).LongValue__J(); if n0_123 == 9223372036854775807 { arg_128 = lang.Numbers_Inc_O__Number_NoInit(na_122) } else { arg_128 = jrt.Long_ValueOf_J__Long_NoInit(n0_123 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_122) { var n0_123_2 float64 = jrt.NN(jrt.Double_Cast(na_122)).DoubleValue__D(); arg_128 = jrt.Double_ValueOf_D__Double_NoInit(n0_123_2 + 1.0).Ref() } else { arg_128 = lang.Numbers_Inc_O__Number_NoInit(na_122) } }; if linked_125 == nil { tmp11 = ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { tmp11 = linked_125.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_124, arg_127, arg_128) }; tmp9 = lang.Util_Equiv_O_O__Z_NoInit(tmp10, tmp11) } else { tmp9 = and__1927000168__auto____6_2 }
//line :69:1
						if tmp9 {


							var tmp12 any; var root_151 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = s__0; var arg_155 any; var root_146 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = s__0; var arg_150 any; var na_141 any = i__4; var na_142 int64 = 2; if jrt.Long_InstanceOf(na_141) { var n0_143 int64 = jrt.NN(jrt.Long_Cast(na_141)).LongValue__J(); var n1_144 int64 = na_142; var nr_145 int64 = n0_143 + n1_144; if (n0_143^nr_145)&(n1_144^nr_145) >= 0 { arg_150 = jrt.Long_ValueOf_J__Long_NoInit(nr_145).Ref() } else { arg_150 = lang.Numbers_Add_O_J__Number_NoInit(na_141, na_142) } } else { arg_150 = lang.Numbers_Add_O_J__Number_NoInit(na_141, na_142) }; if linked_147 == nil { arg_155 = ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { arg_155 = linked_147.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) }; if linked_152 == nil { tmp12 = ifn_153.Invoke_O_O__O(arg_154, arg_155) } else { tmp12 = linked_152.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_151, arg_154, arg_155) }; i__4 = tmp12; continue L1 } else {
//line :69:1
								if A_arbace_repr_clojure_text_A_const_34 != nil { return i__4 } else { return nil } } } } } } } }; /*line :60:1*/panic("j2g: unreachable") }
















func A_arbace_repr_clojure_text_coll_end_A_New() *A_arbace_repr_clojure_text_coll_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_coll_end_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_repr_clojure_text_coll_end_A) Ctor() {}
//line :77:1
func (t *A_arbace_repr_clojure_text_coll_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var close__3 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_43.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__1))).Ref()); var j__4 any; var root_158 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_160 lang.IFn



	if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = s__0; var arg_162 any; var na_156 any = i__1; if jrt.Long_InstanceOf(na_156) { var n0_157 int64 = jrt.NN(jrt.Long_Cast(na_156)).LongValue__J(); if n0_157 == 9223372036854775807 { arg_162 = lang.Numbers_Inc_O__Number_NoInit(na_156) } else { arg_162 = jrt.Long_ValueOf_J__Long_NoInit(n0_157 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_156) { var n0_157_2 float64 = jrt.NN(jrt.Double_Cast(na_156)).DoubleValue__D(); arg_162 = jrt.Double_ValueOf_D__Double_NoInit(n0_157_2 + 1.0).Ref() } else { arg_162 = lang.Numbers_Inc_O__Number_NoInit(na_156) } }; if linked_159 == nil { j__4 = ifn_160.Invoke_O_O__O(arg_161, arg_162) } else { j__4 = linked_159.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_158, arg_161, arg_162) }
//line :77:1
L1: for { var c__5 any; var root_163 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_165 lang.IFn




	if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = s__0; var arg_167 any = j__4; if linked_164 == nil { c__5 = ifn_165.Invoke_O_O__O(arg_166, arg_167) } else { c__5 = linked_164.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_163, arg_166, arg_167) }
	if lang.Util_Identical_O_O__Z_NoInit(c__5, nil) { var root_168 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = s__0; var arg_172 any = i__1; var arg_173 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, close__3)).Ref(); if linked_169 == nil { return ifn_170.Invoke_O_O_O__O(arg_171, arg_172, arg_173) } else { return linked_169.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_168, arg_171, arg_172, arg_173) } } else { if lang.Util_Equiv_O_O__Z_NoInit(c__5, close__3) {
		var na_174 any = j__4; if jrt.Long_InstanceOf(na_174) { var n0_175 int64 = jrt.NN(jrt.Long_Cast(na_174)).LongValue__J(); if n0_175 == 9223372036854775807 { return lang.Numbers_Inc_O__Number_NoInit(na_174) } else { return jrt.Long_ValueOf_J__Long_NoInit(n0_175 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_174) { var n0_175_2 float64 = jrt.NN(jrt.Double_Cast(na_174)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_175_2 + 1.0).Ref() } else { return lang.Numbers_Inc_O__Number_NoInit(na_174) } } } else {
//line :83:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_44).Invoke_O__O(c__5)) {

				var root_176 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = s__0; var arg_180 any = j__4; var arg_181 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__5)).Ref(); if linked_177 == nil { return ifn_178.Invoke_O_O_O__O(arg_179, arg_180, arg_181) } else { return linked_177.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_176, arg_179, arg_180, arg_181) } } else {
//line :83:1
					if A_arbace_repr_clojure_text_A_const_34 != nil {


						var tmp1 any; var root_187 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = s__0; var arg_191 any; var root_182 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = s__0; var arg_186 any = j__4; if linked_183 == nil { arg_191 = ifn_184.Invoke_O_O__O(arg_185, arg_186) } else { arg_191 = linked_183.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_182, arg_185, arg_186) }; if linked_188 == nil { tmp1 = ifn_189.Invoke_O_O__O(arg_190, arg_191) } else { tmp1 = linked_188.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_187, arg_190, arg_191) }; j__4 = tmp1; continue L1 } else {
//line :83:1
							return nil } } } } } }; /*line :77:1*/panic("j2g: unreachable") }










func A_arbace_repr_clojure_text_next_form_end_A_New() *A_arbace_repr_clojure_text_next_form_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_next_form_end_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_repr_clojure_text_next_form_end_A) Ctor() {}
//line :88:1
func (t *A_arbace_repr_clojure_text_next_form_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 any; var root_192 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_194 lang.IFn; if
												linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = s__0; var arg_196 any = i__1; if linked_193 == nil { j__3 = ifn_194.Invoke_O_O__O(arg_195, arg_196) } else { j__3 = linked_193.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_192, arg_195, arg_196) }; var tmp1 bool; var na_202 any = j__3; var na_203 int64 =
												int64(lang.RT_Count_O__I_NoInit(s__0)); if jrt.Long_InstanceOf(na_202) { var n0_204 int64 = jrt.NN(jrt.Long_Cast(na_202)).LongValue__J(); var n1_205 int64 = na_203; tmp1 = n0_204 >= n1_205 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_202, na_203) }; if tmp1 { var root_207 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = s__0; var arg_211 any = i__1; var arg_212 any = Lit_12; if linked_208 == nil { ifn_209.Invoke_O_O_O__O(arg_210, arg_211, arg_212) } else { linked_208.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_207, arg_210, arg_211, arg_212) } }; var root_197 any =
												A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = s__0; var arg_201 any = j__3; if linked_198 == nil { return ifn_199.Invoke_O_O__O(arg_200, arg_201) } else { return linked_198.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_197, arg_200, arg_201) } }

func A_arbace_repr_clojure_text_form_end_A_New() *A_arbace_repr_clojure_text_form_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_form_end_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_repr_clojure_text_form_end_A) Ctor() {}
//line :93:1
func (t *A_arbace_repr_clojure_text_form_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var c__3 any; var root_213 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_215 lang.IFn; if


	linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = s__0; var arg_217 any = i__1; if linked_214 == nil { c__3 = ifn_215.Invoke_O_O__O(arg_216, arg_217) } else { c__3 = linked_214.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_213, arg_216, arg_217) }; var G__670000027__4_ any = c__3; switch
	lang.Util_Hash_O__I_NoInit(G__670000027__4_) { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, nil) {
		var root_219 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = s__0; var arg_223 any = i__1; var arg_224 any = Lit_12; if linked_220 == nil { return ifn_221.Invoke_O_O_O__O(arg_222, arg_223, arg_224) } else { return linked_220.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_219, arg_222, arg_223, arg_224) } }
//line :97:1
	case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_18) {


		var root_225 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = s__0; var arg_229 any = i__1; if linked_226 == nil { return ifn_227.Invoke_O_O__O(arg_228, arg_229) } else { return linked_226.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_225, arg_228, arg_229) } }
//line :97:1
	case 35: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_36) { var d__5 any; var root_232 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_234 lang.IFn








		if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = s__0; var arg_236 any; var na_230 any = i__1; if jrt.Long_InstanceOf(na_230) { var n0_231 int64 = jrt.NN(jrt.Long_Cast(na_230)).LongValue__J(); if n0_231 == 9223372036854775807 { arg_236 = lang.Numbers_Inc_O__Number_NoInit(na_230) } else { arg_236 = jrt.Long_ValueOf_J__Long_NoInit(n0_231 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_230) { var n0_231_2 float64 = jrt.NN(jrt.Double_Cast(na_230)).DoubleValue__D(); arg_236 = jrt.Double_ValueOf_D__Double_NoInit(n0_231_2 + 1.0).Ref() } else { arg_236 = lang.Numbers_Inc_O__Number_NoInit(na_230) } }; if linked_233 == nil { d__5 = ifn_234.Invoke_O_O__O(arg_235, arg_236) } else { d__5 = linked_233.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_232, arg_235, arg_236) }
//line :97:1
		var G__670000028__6_ any = d__5









		switch lang.Util_Hash_O__I_NoInit(G__670000028__6_) { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, nil) {
			var root_238 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = s__0; var arg_242 any = i__1; var arg_243 any = Lit_13; if linked_239 == nil { return ifn_240.Invoke_O_O_O__O(arg_241, arg_242, arg_243) } else { return linked_239.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_238, arg_241, arg_242, arg_243) } }
//line :107:1
		case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_37) {






			var root_249 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = s__0; var arg_253 any; var root_244 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = s__0; var arg_248 any = i__1; if linked_245 == nil { arg_253 = ifn_246.Invoke_O_O__O(arg_247, arg_248) } else { arg_253 = linked_245.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_244, arg_247, arg_248) }; if linked_250 == nil { return ifn_251.Invoke_O_O__O(arg_252, arg_253) } else { return linked_250.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_249, arg_252, arg_253) } }
//line :107:1
		case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_18) {


			var root_256 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = s__0; var arg_260 any; var na_254 any = i__1; if jrt.Long_InstanceOf(na_254) { var n0_255 int64 = jrt.NN(jrt.Long_Cast(na_254)).LongValue__J(); if n0_255 == 9223372036854775807 { arg_260 = lang.Numbers_Inc_O__Number_NoInit(na_254) } else { arg_260 = jrt.Long_ValueOf_J__Long_NoInit(n0_255 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_254) { var n0_255_2 float64 = jrt.NN(jrt.Double_Cast(na_254)).DoubleValue__D(); arg_260 = jrt.Double_ValueOf_D__Double_NoInit(n0_255_2 + 1.0).Ref() } else { arg_260 = lang.Numbers_Inc_O__Number_NoInit(na_254) } }; if linked_257 == nil { return ifn_258.Invoke_O_O__O(arg_259, arg_260) } else { return linked_257.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_256, arg_259, arg_260) } }
//line :107:1
		case 35: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_36) {








			var root_266 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = s__0; var arg_270 any; var na_261 any = i__1; var na_262 int64 = 2; if jrt.Long_InstanceOf(na_261) { var n0_263 int64 = jrt.NN(jrt.Long_Cast(na_261)).LongValue__J(); var n1_264 int64 = na_262; var nr_265 int64 = n0_263 + n1_264; if (n0_263^nr_265)&(n1_264^nr_265) >= 0 { arg_270 = jrt.Long_ValueOf_J__Long_NoInit(nr_265).Ref() } else { arg_270 = lang.Numbers_Add_O_J__Number_NoInit(na_261, na_262) } } else { arg_270 = lang.Numbers_Add_O_J__Number_NoInit(na_261, na_262) }; if linked_267 == nil { return ifn_268.Invoke_O_O__O(arg_269, arg_270) } else { return linked_267.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_266, arg_269, arg_270) } }
//line :107:1
		case 39: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_47) {



			var root_300 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = s__0; var arg_304 any; var na_295 any = i__1; var na_296 int64 = 2; if jrt.Long_InstanceOf(na_295) { var n0_297 int64 = jrt.NN(jrt.Long_Cast(na_295)).LongValue__J(); var n1_298 int64 = na_296; var nr_299 int64 = n0_297 + n1_298; if (n0_297^nr_299)&(n1_298^nr_299) >= 0 { arg_304 = jrt.Long_ValueOf_J__Long_NoInit(nr_299).Ref() } else { arg_304 = lang.Numbers_Add_O_J__Number_NoInit(na_295, na_296) } } else { arg_304 = lang.Numbers_Add_O_J__Number_NoInit(na_295, na_296) }; if linked_301 == nil { return ifn_302.Invoke_O_O__O(arg_303, arg_304) } else { return linked_301.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_300, arg_303, arg_304) } }
//line :107:1
		case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_19) {

			var root_307 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any = s__0; var arg_311 any; var na_305 any = i__1; if jrt.Long_InstanceOf(na_305) { var n0_306 int64 = jrt.NN(jrt.Long_Cast(na_305)).LongValue__J(); if n0_306 == 9223372036854775807 { arg_311 = lang.Numbers_Inc_O__Number_NoInit(na_305) } else { arg_311 = jrt.Long_ValueOf_J__Long_NoInit(n0_306 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_305) { var n0_306_2 float64 = jrt.NN(jrt.Double_Cast(na_305)).DoubleValue__D(); arg_311 = jrt.Double_ValueOf_D__Double_NoInit(n0_306_2 + 1.0).Ref() } else { arg_311 = lang.Numbers_Inc_O__Number_NoInit(na_305) } }; if linked_308 == nil { return ifn_309.Invoke_O_O__O(arg_310, arg_311) } else { return linked_308.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_307, arg_310, arg_311) } }
//line :107:1
		case 58: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_49) { var j__7 any; var root_319 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_321 lang.IFn









			if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = s__0; var arg_323 any; var root_314 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = s__0; var arg_318 any; var na_312 any = i__1; if jrt.Long_InstanceOf(na_312) { var n0_313 int64 = jrt.NN(jrt.Long_Cast(na_312)).LongValue__J(); if n0_313 == 9223372036854775807 { arg_318 = lang.Numbers_Inc_O__Number_NoInit(na_312) } else { arg_318 = jrt.Long_ValueOf_J__Long_NoInit(n0_313 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_312) { var n0_313_2 float64 = jrt.NN(jrt.Double_Cast(na_312)).DoubleValue__D(); arg_318 = jrt.Double_ValueOf_D__Double_NoInit(n0_313_2 + 1.0).Ref() } else { arg_318 = lang.Numbers_Inc_O__Number_NoInit(na_312) } }; if linked_315 == nil { arg_323 = ifn_316.Invoke_O_O__O(arg_317, arg_318) } else { arg_323 = linked_315.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_314, arg_317, arg_318) }; if linked_320 == nil { j__7 = ifn_321.Invoke_O_O__O(arg_322, arg_323) } else { j__7 = linked_320.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_319, arg_322, arg_323) }
			var tmp1 any = A_arbace_repr_clojure_text_A_const_28; var tmp2 any; var root_339 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = s__0; var arg_343 any = j__7; if linked_340 == nil { tmp2 = ifn_341.Invoke_O_O__O(arg_342, arg_343) } else { tmp2 = linked_340.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_339, arg_342, arg_343) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { } else { var root_344 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = s__0; var arg_348 any = i__1; var arg_349 any = Lit_14; if linked_345 == nil { ifn_346.Invoke_O_O_O__O(arg_347, arg_348, arg_349) } else { linked_345.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_344, arg_347, arg_348, arg_349) } }
			var root_324 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = s__0; var arg_328 any = j__7; if linked_325 == nil { return ifn_326.Invoke_O_O__O(arg_327, arg_328) } else { return linked_325.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_324, arg_327, arg_328) } }
//line :107:1
		case 61: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_50) {



			var root_334 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = s__0; var arg_338 any; var na_329 any = i__1; var na_330 int64 = 2; if jrt.Long_InstanceOf(na_329) { var n0_331 int64 = jrt.NN(jrt.Long_Cast(na_329)).LongValue__J(); var n1_332 int64 = na_330; var nr_333 int64 = n0_331 + n1_332; if (n0_331^nr_333)&(n1_332^nr_333) >= 0 { arg_338 = jrt.Long_ValueOf_J__Long_NoInit(nr_333).Ref() } else { arg_338 = lang.Numbers_Add_O_J__Number_NoInit(na_329, na_330) } } else { arg_338 = lang.Numbers_Add_O_J__Number_NoInit(na_329, na_330) }; if linked_335 == nil { return ifn_336.Invoke_O_O__O(arg_337, arg_338) } else { return linked_335.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_334, arg_337, arg_338) } }
//line :107:1
		case 63: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_51) {







			var root_355 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = s__0; var arg_359 any; var root_350 any = A_arbace_repr_clojure_text_A_const_52.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, A_arbace_repr_clojure_text_cond_open_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = s__0; var arg_354 any = i__1; if linked_351 == nil { arg_359 = ifn_352.Invoke_O_O__O(arg_353, arg_354) } else { arg_359 = linked_351.(*A_arbace_repr_clojure_text_cond_open_A).Invoke_O_O_O__O(root_350, arg_353, arg_354) }; if linked_356 == nil { return ifn_357.Invoke_O_O__O(arg_358, arg_359) } else { return linked_356.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_355, arg_358, arg_359) } }
//line :107:1
		case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_26) {




			var root_370 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = s__0; var arg_374 any; var root_365 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = s__0; var arg_369 any; var na_360 any = i__1; var na_361 int64 = 2; if jrt.Long_InstanceOf(na_360) { var n0_362 int64 = jrt.NN(jrt.Long_Cast(na_360)).LongValue__J(); var n1_363 int64 = na_361; var nr_364 int64 = n0_362 + n1_363; if (n0_362^nr_364)&(n1_363^nr_364) >= 0 { arg_369 = jrt.Long_ValueOf_J__Long_NoInit(nr_364).Ref() } else { arg_369 = lang.Numbers_Add_O_J__Number_NoInit(na_360, na_361) } } else { arg_369 = lang.Numbers_Add_O_J__Number_NoInit(na_360, na_361) }; if linked_366 == nil { arg_374 = ifn_367.Invoke_O_O__O(arg_368, arg_369) } else { arg_374 = linked_366.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_365, arg_368, arg_369) }; if linked_371 == nil { return ifn_372.Invoke_O_O__O(arg_373, arg_374) } else { return linked_371.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_370, arg_373, arg_374) } }
//line :107:1
		case 95: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_39) {





			var root_385 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = s__0; var arg_389 any; var root_380 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = s__0; var arg_384 any; var na_375 any = i__1; var na_376 int64 = 2; if jrt.Long_InstanceOf(na_375) { var n0_377 int64 = jrt.NN(jrt.Long_Cast(na_375)).LongValue__J(); var n1_378 int64 = na_376; var nr_379 int64 = n0_377 + n1_378; if (n0_377^nr_379)&(n1_378^nr_379) >= 0 { arg_384 = jrt.Long_ValueOf_J__Long_NoInit(nr_379).Ref() } else { arg_384 = lang.Numbers_Add_O_J__Number_NoInit(na_375, na_376) } } else { arg_384 = lang.Numbers_Add_O_J__Number_NoInit(na_375, na_376) }; if linked_381 == nil { arg_389 = ifn_382.Invoke_O_O__O(arg_383, arg_384) } else { arg_389 = linked_381.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_380, arg_383, arg_384) }; if linked_386 == nil { return ifn_387.Invoke_O_O__O(arg_388, arg_389) } else { return linked_386.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_385, arg_388, arg_389) } }
//line :107:1
		case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_28) {

			var root_392 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = s__0; var arg_396 any; var na_390 any = i__1; if jrt.Long_InstanceOf(na_390) { var n0_391 int64 = jrt.NN(jrt.Long_Cast(na_390)).LongValue__J(); if n0_391 == 9223372036854775807 { arg_396 = lang.Numbers_Inc_O__Number_NoInit(na_390) } else { arg_396 = jrt.Long_ValueOf_J__Long_NoInit(n0_391 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_390) { var n0_391_2 float64 = jrt.NN(jrt.Double_Cast(na_390)).DoubleValue__D(); arg_396 = jrt.Double_ValueOf_D__Double_NoInit(n0_391_2 + 1.0).Ref() } else { arg_396 = lang.Numbers_Inc_O__Number_NoInit(na_390) } }; if linked_393 == nil { return ifn_394.Invoke_O_O__O(arg_395, arg_396) } else { return linked_393.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_392, arg_395, arg_396) } }
//line :107:1
		default:
		}












		var root_278 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = s__0; var arg_282 any; var root_273 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = s__0; var arg_277 any; var na_271 any = i__1; if jrt.Long_InstanceOf(na_271) { var n0_272 int64 = jrt.NN(jrt.Long_Cast(na_271)).LongValue__J(); if n0_272 == 9223372036854775807 { arg_277 = lang.Numbers_Inc_O__Number_NoInit(na_271) } else { arg_277 = jrt.Long_ValueOf_J__Long_NoInit(n0_272 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_271) { var n0_272_2 float64 = jrt.NN(jrt.Double_Cast(na_271)).DoubleValue__D(); arg_277 = jrt.Double_ValueOf_D__Double_NoInit(n0_272_2 + 1.0).Ref() } else { arg_277 = lang.Numbers_Inc_O__Number_NoInit(na_271) } }; if linked_274 == nil { arg_282 = ifn_275.Invoke_O_O__O(arg_276, arg_277) } else { arg_282 = linked_274.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_273, arg_276, arg_277) }; if linked_279 == nil { return ifn_280.Invoke_O_O__O(arg_281, arg_282) } else { return linked_279.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_278, arg_281, arg_282) } }
//line :97:1
	case 39: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_47) {




		var root_285 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = s__0; var arg_289 any; var na_283 any = i__1; if jrt.Long_InstanceOf(na_283) { var n0_284 int64 = jrt.NN(jrt.Long_Cast(na_283)).LongValue__J(); if n0_284 == 9223372036854775807 { arg_289 = lang.Numbers_Inc_O__Number_NoInit(na_283) } else { arg_289 = jrt.Long_ValueOf_J__Long_NoInit(n0_284 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_283) { var n0_284_2 float64 = jrt.NN(jrt.Double_Cast(na_283)).DoubleValue__D(); arg_289 = jrt.Double_ValueOf_D__Double_NoInit(n0_284_2 + 1.0).Ref() } else { arg_289 = lang.Numbers_Inc_O__Number_NoInit(na_283) } }; if linked_286 == nil { return ifn_287.Invoke_O_O__O(arg_288, arg_289) } else { return linked_286.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_285, arg_288, arg_289) } }
//line :97:1
	case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_19) {

		var root_397 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = s__0; var arg_401 any = i__1; if linked_398 == nil { return ifn_399.Invoke_O_O__O(arg_400, arg_401) } else { return linked_398.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_397, arg_400, arg_401) } }
//line :97:1
	case 41: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_20) {







		var root_402 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = s__0; var arg_406 any = i__1; var arg_407 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref(); if linked_403 == nil { return ifn_404.Invoke_O_O_O__O(arg_405, arg_406, arg_407) } else { return linked_403.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_402, arg_405, arg_406, arg_407) } }
//line :97:1
	case 64: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_22) {




		var root_410 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = s__0; var arg_414 any; var na_408 any = i__1; if jrt.Long_InstanceOf(na_408) { var n0_409 int64 = jrt.NN(jrt.Long_Cast(na_408)).LongValue__J(); if n0_409 == 9223372036854775807 { arg_414 = lang.Numbers_Inc_O__Number_NoInit(na_408) } else { arg_414 = jrt.Long_ValueOf_J__Long_NoInit(n0_409 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_408) { var n0_409_2 float64 = jrt.NN(jrt.Double_Cast(na_408)).DoubleValue__D(); arg_414 = jrt.Double_ValueOf_D__Double_NoInit(n0_409_2 + 1.0).Ref() } else { arg_414 = lang.Numbers_Inc_O__Number_NoInit(na_408) } }; if linked_411 == nil { return ifn_412.Invoke_O_O__O(arg_413, arg_414) } else { return linked_411.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_410, arg_413, arg_414) } }
//line :97:1
	case 91: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_23) {

		var root_415 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = s__0; var arg_419 any = i__1; if linked_416 == nil { return ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { return linked_416.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) } }
//line :97:1
	case 92: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_24) {



		var root_420 any = A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, A_arbace_repr_clojure_text_char_end_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = s__0; var arg_424 any = i__1; if linked_421 == nil { return ifn_422.Invoke_O_O__O(arg_423, arg_424) } else { return linked_421.(*A_arbace_repr_clojure_text_char_end_A).Invoke_O_O_O__O(root_420, arg_423, arg_424) } }
//line :97:1
	case 93: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_25) {







		var root_425 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = s__0; var arg_429 any = i__1; var arg_430 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref(); if linked_426 == nil { return ifn_427.Invoke_O_O_O__O(arg_428, arg_429, arg_430) } else { return linked_426.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_425, arg_428, arg_429, arg_430) } }
//line :97:1
	case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_26) {






		var root_438 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = s__0; var arg_442 any; var root_433 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = s__0; var arg_437 any; var na_431 any = i__1; if jrt.Long_InstanceOf(na_431) { var n0_432 int64 = jrt.NN(jrt.Long_Cast(na_431)).LongValue__J(); if n0_432 == 9223372036854775807 { arg_437 = lang.Numbers_Inc_O__Number_NoInit(na_431) } else { arg_437 = jrt.Long_ValueOf_J__Long_NoInit(n0_432 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_431) { var n0_432_2 float64 = jrt.NN(jrt.Double_Cast(na_431)).DoubleValue__D(); arg_437 = jrt.Double_ValueOf_D__Double_NoInit(n0_432_2 + 1.0).Ref() } else { arg_437 = lang.Numbers_Inc_O__Number_NoInit(na_431) } }; if linked_434 == nil { arg_442 = ifn_435.Invoke_O_O__O(arg_436, arg_437) } else { arg_442 = linked_434.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_433, arg_436, arg_437) }; if linked_439 == nil { return ifn_440.Invoke_O_O__O(arg_441, arg_442) } else { return linked_439.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_438, arg_441, arg_442) } }
//line :97:1
	case 96: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_27) {




		var root_445 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = s__0; var arg_449 any; var na_443 any = i__1; if jrt.Long_InstanceOf(na_443) { var n0_444 int64 = jrt.NN(jrt.Long_Cast(na_443)).LongValue__J(); if n0_444 == 9223372036854775807 { arg_449 = lang.Numbers_Inc_O__Number_NoInit(na_443) } else { arg_449 = jrt.Long_ValueOf_J__Long_NoInit(n0_444 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_443) { var n0_444_2 float64 = jrt.NN(jrt.Double_Cast(na_443)).DoubleValue__D(); arg_449 = jrt.Double_ValueOf_D__Double_NoInit(n0_444_2 + 1.0).Ref() } else { arg_449 = lang.Numbers_Inc_O__Number_NoInit(na_443) } }; if linked_446 == nil { return ifn_447.Invoke_O_O__O(arg_448, arg_449) } else { return linked_446.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_445, arg_448, arg_449) } }
//line :97:1
	case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_28) {

		var root_450 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = s__0; var arg_454 any = i__1; if linked_451 == nil { return ifn_452.Invoke_O_O__O(arg_453, arg_454) } else { return linked_451.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_450, arg_453, arg_454) } }
//line :97:1
	case 125: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_29) {







		var root_455 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = s__0; var arg_459 any = i__1; var arg_460 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref(); if linked_456 == nil { return ifn_457.Invoke_O_O_O__O(arg_458, arg_459, arg_460) } else { return linked_456.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_455, arg_458, arg_459, arg_460) } }
//line :97:1
	case 126: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_30) {





		var root_475 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = s__0; var arg_479 any; var tmp3 any = A_arbace_repr_clojure_text_A_const_22; var tmp4 any; var root_463 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = s__0; var arg_467 any; var na_461 any = i__1; if jrt.Long_InstanceOf(na_461) { var n0_462 int64 = jrt.NN(jrt.Long_Cast(na_461)).LongValue__J(); if n0_462 == 9223372036854775807 { arg_467 = lang.Numbers_Inc_O__Number_NoInit(na_461) } else { arg_467 = jrt.Long_ValueOf_J__Long_NoInit(n0_462 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_461) { var n0_462_2 float64 = jrt.NN(jrt.Double_Cast(na_461)).DoubleValue__D(); arg_467 = jrt.Double_ValueOf_D__Double_NoInit(n0_462_2 + 1.0).Ref() } else { arg_467 = lang.Numbers_Inc_O__Number_NoInit(na_461) } }; if linked_464 == nil { tmp4 = ifn_465.Invoke_O_O__O(arg_466, arg_467) } else { tmp4 = linked_464.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_463, arg_466, arg_467) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4) { var na_468 any = i__1; var na_469 int64 = 2; if jrt.Long_InstanceOf(na_468) { var n0_470 int64 = jrt.NN(jrt.Long_Cast(na_468)).LongValue__J(); var n1_471 int64 = na_469; var nr_472 int64 = n0_470 + n1_471; if (n0_470^nr_472)&(n1_471^nr_472) >= 0 { arg_479 = jrt.Long_ValueOf_J__Long_NoInit(nr_472).Ref() } else { arg_479 = lang.Numbers_Add_O_J__Number_NoInit(na_468, na_469) } } else { arg_479 = lang.Numbers_Add_O_J__Number_NoInit(na_468, na_469) } } else { var na_473 any = i__1; if jrt.Long_InstanceOf(na_473) { var n0_474 int64 = jrt.NN(jrt.Long_Cast(na_473)).LongValue__J(); if n0_474 == 9223372036854775807 { arg_479 = lang.Numbers_Inc_O__Number_NoInit(na_473) } else { arg_479 = jrt.Long_ValueOf_J__Long_NoInit(n0_474 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_473) { var n0_474_2 float64 = jrt.NN(jrt.Double_Cast(na_473)).DoubleValue__D(); arg_479 = jrt.Double_ValueOf_D__Double_NoInit(n0_474_2 + 1.0).Ref() } else { arg_479 = lang.Numbers_Inc_O__Number_NoInit(na_473) } } }; if linked_476 == nil { return ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { return linked_476.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) } }
//line :97:1
	default:}; var root_290 any =
























	A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = s__0; var arg_294 any = i__1; if linked_291 == nil { return ifn_292.Invoke_O_O__O(arg_293, arg_294) } else { return linked_291.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_290, arg_293, arg_294) } }



func A_arbace_repr_clojure_text_cond_open_A_New() *A_arbace_repr_clojure_text_cond_open_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_cond_open_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_repr_clojure_text_cond_open_A) Ctor() {}
//line :126:1
func (t *A_arbace_repr_clojure_text_cond_open_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 any; var tmp1 any = A_arbace_repr_clojure_text_cond_open_fn__670000030_A_New_O_O(i__1, s__0); var tmp2 *jrt.Class; var fncls__511 *jrt.Class = A_arbace_repr_clojure_text_cond_open_fn__670000030_A_fn_class; if



	fncls__511 == nil { var fncls__511d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_repr_clojure_text_cond_open_fn__670000030_A_fn_class = fncls__511d; tmp2 = fncls__511d } else { tmp2 = fncls__511 }; j__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var tmp3 any = A_arbace_repr_clojure_text_A_const_19; var tmp4 any; var root_512 any =

	A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = s__0; var arg_516 any = j__3; if linked_513 == nil { tmp4 = ifn_514.Invoke_O_O__O(arg_515, arg_516) } else { tmp4 = linked_513.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_512, arg_515, arg_516) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4) { } else { var root_517 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = s__0; var arg_521 any = i__1; var arg_522 any = Lit_8; if linked_518 == nil { ifn_519.Invoke_O_O_O__O(arg_520, arg_521, arg_522) } else { linked_518.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_517, arg_520, arg_521, arg_522) } }; return j__3 }
//line :130:1
func A_arbace_repr_clojure_text_cond_open_fn__670000030_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_text_cond_open_fn__670000030_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_cond_open_fn__670000030_A{}; t.Ctor_O_O(p0, p1); return t }
//line :130:1
func (t *A_arbace_repr_clojure_text_cond_open_fn__670000030_A) Ctor_O_O(c__i, c__s any) { t.F_i = c__i; t.F_s = c__s }
//line :130:1
func (t *A_arbace_repr_clojure_text_cond_open_fn__670000030_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 any = A_arbace_repr_clojure_text_A_const_22; var tmp2 any; var root_485 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = t.F_s; var arg_489 any; var na_480 any = t.F_i; var na_481 int64 = 2; if jrt.Long_InstanceOf(na_480) { var n0_482 int64 = jrt.NN(jrt.Long_Cast(na_480)).LongValue__J(); var n1_483 int64 = na_481; var nr_484 int64 = n0_482 + n1_483; if (n0_482^nr_484)&(n1_483^nr_484) >= 0 { arg_489 = jrt.Long_ValueOf_J__Long_NoInit(nr_484).Ref() } else { arg_489 = lang.Numbers_Add_O_J__Number_NoInit(na_480, na_481) } } else { arg_489 = lang.Numbers_Add_O_J__Number_NoInit(na_480, na_481) }; if linked_486 == nil { tmp2 = ifn_487.Invoke_O_O__O(arg_488, arg_489) } else { tmp2 = linked_486.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_485, arg_488, arg_489) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { var na_490 any; var t_ any = t.F_i; t.F_i = nil; na_490 = t_; var na_491 int64 = 3; if jrt.Long_InstanceOf(na_490) { var n0_492 int64 = jrt.NN(jrt.Long_Cast(na_490)).LongValue__J(); var n1_493 int64 = na_491; var nr_494 int64 = n0_492 + n1_493; if (n0_492^nr_494)&(n1_493^nr_494) >= 0 { j__1 = jrt.Long_ValueOf_J__Long_NoInit(nr_494).Ref() } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_490, na_491) } } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_490, na_491) } } else { var na_495 any; var t__2 any = t.F_i; t.F_i = nil; na_495 = t__2; var na_496 int64 = 2; if jrt.Long_InstanceOf(na_495) { var n0_497 int64 = jrt.NN(jrt.Long_Cast(na_495)).LongValue__J(); var n1_498 int64 = na_496; var nr_499 int64 = n0_497 + n1_498; if (n0_497^nr_499)&(n1_498^nr_499) >= 0 { j__1 = jrt.Long_ValueOf_J__Long_NoInit(nr_499).Ref() } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_495, na_496) } } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_495, na_496) } }; L1: for {
												var tmp3 any; var and__1927000168__auto____2 bool; var na_500 any = j__1; var na_501 int64 = int64(lang.RT_Count_O__I_NoInit(t.F_s)); if jrt.Long_InstanceOf(na_500) { var n0_502 int64 = jrt.NN(jrt.Long_Cast(na_500)).LongValue__J(); var n1_503 int64 = na_501; and__1927000168__auto____2 = n0_502 < n1_503 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_J__Z_NoInit(na_500, na_501) }; if and__1927000168__auto____2 { var root_505 any = A_arbace_repr_clojure_text_A_const_17.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, A_arbace_repr_clojure_text_ws_QMARK__A_fn_class); var ifn_507 lang.IFn; if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var tmp4 *jrt.String = jrt.String_Cast(t.F_s); var arg_508 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(tmp4).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))).Ref(); if linked_506 == nil { tmp3 = ifn_507.Invoke_O__O(arg_508) } else { tmp3 = linked_506.(*A_arbace_repr_clojure_text_ws_QMARK__A).Invoke_O_O__O(root_505, arg_508) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp3) { var tmp5 jrt.Number_I; var na_509 any = j__1; if jrt.Long_InstanceOf(na_509) { var n0_510 int64 = jrt.NN(jrt.Long_Cast(na_509)).LongValue__J(); if n0_510 == 9223372036854775807 { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_509) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_510 + 1)) } } else { if jrt.Double_InstanceOf(na_509) { var n0_510_2 float64 = jrt.NN(jrt.Double_Cast(na_509)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_510_2 + 1.0)) } else { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_509) } }; j__1 = tmp5; continue L1 } else { return j__1 } } }; /*line :130:1*/panic("j2g: unreachable") }




func A_arbace_repr_clojure_text_branches_A_New() *A_arbace_repr_clojure_text_branches_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_branches_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_repr_clojure_text_branches_A) Ctor() {}
//line :135:1
func (t *A_arbace_repr_clojure_text_branches_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var j__3 any; var root_525 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_527 lang.IFn



	if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = s__0; var arg_529 any; var na_523 any = i__1; if jrt.Long_InstanceOf(na_523) { var n0_524 int64 = jrt.NN(jrt.Long_Cast(na_523)).LongValue__J(); if n0_524 == 9223372036854775807 { arg_529 = lang.Numbers_Inc_O__Number_NoInit(na_523) } else { arg_529 = jrt.Long_ValueOf_J__Long_NoInit(n0_524 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_523) { var n0_524_2 float64 = jrt.NN(jrt.Double_Cast(na_523)).DoubleValue__D(); arg_529 = jrt.Double_ValueOf_D__Double_NoInit(n0_524_2 + 1.0).Ref() } else { arg_529 = lang.Numbers_Inc_O__Number_NoInit(na_523) } }; if linked_526 == nil { j__3 = ifn_527.Invoke_O_O__O(arg_528, arg_529) } else { j__3 = linked_526.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_525, arg_528, arg_529) }
//line :135:1
	var bs__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		var tmp1 any = A_arbace_repr_clojure_text_A_const_20; var tmp2 any; var root_530 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = s__0; var arg_534 any = j__3; if linked_531 == nil { tmp2 = ifn_532.Invoke_O_O__O(arg_533, arg_534) } else { tmp2 = linked_531.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_530, arg_533, arg_534) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { return bs__4 } else { var fe__5 any; var root_535 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_537 lang.IFn

			if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = s__0; var arg_539 any = j__3; if linked_536 == nil { fe__5 = ifn_537.Invoke_O_O__O(arg_538, arg_539) } else { fe__5 = linked_536.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_535, arg_538, arg_539) }
//line :140:1
			var feature__6 any; var root_540 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_542 lang.IFn


			if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = s__0; var arg_544 any = j__3; var arg_545 any = fe__5; if linked_541 == nil { feature__6 = ifn_542.Invoke_O_O_O__O(arg_543, arg_544, arg_545) } else { feature__6 = linked_541.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_540, arg_543, arg_544, arg_545) }
//line :140:1
			var v__7 any; var root_546 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_548 lang.IFn



			if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = s__0; var arg_550 any = fe__5; if linked_547 == nil { v__7 = ifn_548.Invoke_O_O__O(arg_549, arg_550) } else { v__7 = linked_547.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_546, arg_549, arg_550) }
			var tmp3 any; var root_556 any = A_arbace_repr_clojure_text_A_const_54.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = feature__6; var arg_560 any = Lit_1; if linked_557 == nil { tmp3 = ifn_558.Invoke_O_O__O(arg_559, arg_560) } else { tmp3 = linked_557.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_556, arg_559, arg_560) }; if jrt.J2g_Truth(tmp3) { } else { var root_561 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = s__0; var arg_565 any = j__3; var arg_566 any = Lit_2; if linked_562 == nil { ifn_563.Invoke_O_O_O__O(arg_564, arg_565, arg_566) } else { linked_562.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_561, arg_564, arg_565, arg_566) } }
			var tmp4 any = A_arbace_repr_clojure_text_A_const_20; var tmp5 any; var root_567 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = s__0; var arg_571 any = v__7; if linked_568 == nil { tmp5 = ifn_569.Invoke_O_O__O(arg_570, arg_571) } else { tmp5 = linked_568.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_567, arg_570, arg_571) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5) { var root_572 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = s__0; var arg_576 any = v__7; var arg_577 any = Lit_3; if linked_573 == nil { ifn_574.Invoke_O_O_O__O(arg_575, arg_576, arg_577) } else { linked_573.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_572, arg_575, arg_576, arg_577) } }
//line :140:1
			var ve__8 any; var root_551 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_553 lang.IFn






			if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = s__0; var arg_555 any = v__7; if linked_552 == nil { ve__8 = ifn_553.Invoke_O_O__O(arg_554, arg_555) } else { ve__8 = linked_552.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_551, arg_554, arg_555) }
			var tmp6 any; var root_578 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = s__0; var arg_582 any = ve__8; if linked_579 == nil { tmp6 = ifn_580.Invoke_O_O__O(arg_581, arg_582) } else { tmp6 = linked_579.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_578, arg_581, arg_582) }; var tmp7 any = tmp6; var tmp8 any; var root_592 any = A_arbace_repr_clojure_text_A_const_7.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = bs__4; var arg_596 any; var tmp9 any; var root_588 any = A_arbace_repr_clojure_text_A_const_55.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any; var root_583 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = feature__6; var arg_587 any = A_arbace_repr_clojure_text_A_const_56; if linked_584 == nil { arg_591 = ifn_585.Invoke_O_O__O(arg_586, arg_587) } else { arg_591 = linked_584.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_583, arg_586, arg_587) }; if linked_589 == nil { tmp9 = ifn_590.Invoke_O__O(arg_591) } else { tmp9 = linked_589.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_588, arg_591) }; arg_596 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp9, v__7, ve__8); if linked_593 == nil { tmp8 = ifn_594.Invoke_O_O__O(arg_595, arg_596) } else { tmp8 = linked_593.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_592, arg_595, arg_596) }; j__3, bs__4 = tmp7, tmp8; continue L1 } } }; /*line :135:1*/panic("j2g: unreachable") }
















func A_arbace_repr_clojure_text_selected_A_New() *A_arbace_repr_clojure_text_selected_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_selected_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_repr_clojure_text_selected_A) Ctor() {}
//line :152:1
func (t *A_arbace_repr_clojure_text_selected_A) Invoke_O_O_O_O_O__O(self, s__0, i__1, features__2, depth__3 any) any { var splice_QMARK___5 bool; var tmp1 any = A_arbace_repr_clojure_text_A_const_22; var tmp2 any; var root_602 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_604 lang.IFn; if




	linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = s__0; var arg_606 any; var na_597 any = i__1; var na_598 int64 = 2; if jrt.Long_InstanceOf(na_597) { var n0_599 int64 = jrt.NN(jrt.Long_Cast(na_597)).LongValue__J(); var n1_600 int64 = na_598; var nr_601 int64 = n0_599 + n1_600; if (n0_599^nr_601)&(n1_600^nr_601) >= 0 { arg_606 = jrt.Long_ValueOf_J__Long_NoInit(nr_601).Ref() } else { arg_606 = lang.Numbers_Add_O_J__Number_NoInit(na_597, na_598) } } else { arg_606 = lang.Numbers_Add_O_J__Number_NoInit(na_597, na_598) }; if linked_603 == nil { tmp2 = ifn_604.Invoke_O_O__O(arg_605, arg_606) } else { tmp2 = linked_603.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_602, arg_605, arg_606) }; splice_QMARK___5 = lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2); var open__6 any; var root_607 any = /*line :152:1*/A_arbace_repr_clojure_text_A_const_52.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, A_arbace_repr_clojure_text_cond_open_A_fn_class); var ifn_609 lang.IFn; if





	linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = s__0; var arg_611 any = i__1; if linked_608 == nil { open__6 = ifn_609.Invoke_O_O__O(arg_610, arg_611) } else { open__6 = linked_608.(*A_arbace_repr_clojure_text_cond_open_A).Invoke_O_O_O__O(root_607, arg_610, arg_611) }; var vec__670000034__7 any; var root_628 any = /*line :152:1*/A_arbace_repr_clojure_text_A_const_57.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_630 lang.IFn; if






	linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any; var root_623 any = A_arbace_repr_clojure_text_A_const_9.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_625 lang.IFn; if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any; var tmp3 any = A_arbace_repr_clojure_text_selected_fn__670000038_A_New_O(features__2); var tmp4 *jrt.Class; var fncls__617 *jrt.Class = A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class; if fncls__617 == nil { var fncls__617d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class = fncls__617d; tmp4 = fncls__617d } else { tmp4 = fncls__617 }; arg_626 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_627 any; var root_618 any = A_arbace_repr_clojure_text_A_const_60.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, A_arbace_repr_clojure_text_branches_A_fn_class); var ifn_620 lang.IFn; if
	linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = s__0; var arg_622 any = open__6; if linked_619 == nil { arg_627 = ifn_620.Invoke_O_O__O(arg_621, arg_622) } else { arg_627 = linked_619.(*A_arbace_repr_clojure_text_branches_A).Invoke_O_O_O__O(root_618, arg_621, arg_622) }; if /*line :159:1*/ linked_624 == nil { arg_631 = ifn_625.Invoke_O_O__O(arg_626, arg_627) } else { arg_631 = linked_624.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_623, arg_626, arg_627) }; if linked_629 == nil { vec__670000034__7 = ifn_630.Invoke_O__O(arg_631) } else { vec__670000034__7 = linked_629.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_628, arg_631) }; var ___8 any = /*line :152:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(0), nil); var v__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(1), nil); var ve__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp5 bool; var and__1927000168__auto____11 bool = splice_QMARK___5; _ = ___8; if and__1927000168__auto____11 {








		var na_670 any = depth__3; if jrt.Long_InstanceOf(na_670) { var n0_671 int64 = jrt.NN(jrt.Long_Cast(na_670)).LongValue__J(); tmp5 = n0_671 == 0 } else { if jrt.Double_InstanceOf(na_670) { var n0_671_2 float64 = jrt.NN(jrt.Double_Cast(na_670)).DoubleValue__D(); tmp5 = n0_671_2 == 0.0 } else { tmp5 = lang.Numbers_IsZero_O__Z_NoInit(na_670) } } } else { tmp5 = and__1927000168__auto____11 }; if tmp5 {
			var root_672 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = s__0; var arg_676 any = i__1; var arg_677 any = Lit_19; if linked_673 == nil { ifn_674.Invoke_O_O_O__O(arg_675, arg_676, arg_677) } else { linked_673.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_672, arg_675, arg_676, arg_677) } }; if


	lang.Util_Identical_O_O__Z_NoInit(v__9, nil) { return Lit_20 } else { var tmp6 any; var root_632 any = A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_634 lang.IFn
		if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(splice_QMARK___5).Ref(); if linked_633 == nil { tmp6 = ifn_634.Invoke_O__O(arg_635) } else { tmp6 = linked_633.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_632, arg_635) }
//line :165:1
		if jrt.J2g_Truth(tmp6) {
			var root_642 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any; var root_636 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_638 lang.IFn; if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any = s__0; var arg_640 any = v__9; var arg_641 any = ve__10; if linked_637 == nil { arg_645 = ifn_638.Invoke_O_O_O__O(arg_639, arg_640, arg_641) } else { arg_645 = linked_637.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_636, arg_639, arg_640, arg_641) }; var arg_646 any = features__2; var arg_647 any = depth__3; if linked_643 == nil { return ifn_644.Invoke_O_O_O__O(arg_645, arg_646, arg_647) } else { return linked_643.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O_O__O(root_642, arg_645, arg_646, arg_647) } } else {
//line :165:1
				var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_62); var tmp8 any; var root_678 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_680 lang.IFn

				if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = s__0; var arg_682 any = v__9; if linked_679 == nil { tmp8 = ifn_680.Invoke_O_O__O(arg_681, arg_682) } else { tmp8 = linked_679.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_678, arg_681, arg_682) }
//line :165:1
				if jrt.J2g_Truth(tmp7.Invoke_O__O(tmp8)) {

					var root_658 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any; var root_652 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = s__0; var arg_656 any; var na_648 any = v__9; if jrt.Long_InstanceOf(na_648) { var n0_649 int64 = jrt.NN(jrt.Long_Cast(na_648)).LongValue__J(); if n0_649 == 9223372036854775807 { arg_656 = lang.Numbers_Inc_O__Number_NoInit(na_648) } else { arg_656 = jrt.Long_ValueOf_J__Long_NoInit(n0_649 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_648) { var n0_649_2 float64 = jrt.NN(jrt.Double_Cast(na_648)).DoubleValue__D(); arg_656 = jrt.Double_ValueOf_D__Double_NoInit(n0_649_2 + 1.0).Ref() } else { arg_656 = lang.Numbers_Inc_O__Number_NoInit(na_648) } }; var arg_657 any; var na_650 any = ve__10; if jrt.Long_InstanceOf(na_650) { var n0_651 int64 = jrt.NN(jrt.Long_Cast(na_650)).LongValue__J(); if n0_651 == -9223372036854775808 { arg_657 = lang.Numbers_Dec_O__Number_NoInit(na_650) } else { arg_657 = jrt.Long_ValueOf_J__Long_NoInit(n0_651 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_650) { var n0_651_2 float64 = jrt.NN(jrt.Double_Cast(na_650)).DoubleValue__D(); arg_657 = jrt.Double_ValueOf_D__Double_NoInit(n0_651_2 - 1.0).Ref() } else { arg_657 = lang.Numbers_Dec_O__Number_NoInit(na_650) } }; if linked_653 == nil { arg_661 = ifn_654.Invoke_O_O_O__O(arg_655, arg_656, arg_657) } else { arg_661 = linked_653.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_652, arg_655, arg_656, arg_657) }; var arg_662 any = features__2; var arg_663 any = depth__3; if linked_659 == nil { return ifn_660.Invoke_O_O_O__O(arg_661, arg_662, arg_663) } else { return linked_659.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O_O__O(root_658, arg_661, arg_662, arg_663) } } else {
//line :165:1
						if A_arbace_repr_clojure_text_A_const_34 != nil {


							var root_664 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = s__0; var arg_668 any = v__9; var arg_669 any = Lit_21; if linked_665 == nil { return ifn_666.Invoke_O_O_O__O(arg_667, arg_668, arg_669) } else { return linked_665.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_664, arg_667, arg_668, arg_669) } } else {
//line :165:1
								return nil } } } } }
//line :159:1
func A_arbace_repr_clojure_text_selected_fn__670000038_A_New_O(p0 any) *A_arbace_repr_clojure_text_selected_fn__670000038_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_selected_fn__670000038_A{}; t.Ctor_O(p0); return t }
//line :159:1
func (t *A_arbace_repr_clojure_text_selected_fn__670000038_A) Ctor_O(c__features any) { t.F_features = c__features }
//line :159:1
func (t *A_arbace_repr_clojure_text_selected_fn__670000038_A) Invoke_O_O__O(self, p__670000037__1 any) any { var vec__670000039__2 any = p__670000037__1; var f__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000039__2, lang.RT_IntCast_J__I_NoInit(0), nil); var or__1927000174__auto____4 any; var root_612 any = A_arbace_repr_clojure_text_A_const_58.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = t.F_features; var arg_616 any = f__3; if linked_613 == nil { or__1927000174__auto____4 = ifn_614.Invoke_O_O__O(arg_615, arg_616) } else { or__1927000174__auto____4 = linked_613.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_612, arg_615, arg_616) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(f__3, A_arbace_repr_clojure_text_A_const_59)).Ref() } }










func A_arbace_repr_clojure_text_resolve_conditionals_A_New() *A_arbace_repr_clojure_text_resolve_conditionals_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_resolve_conditionals_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_A) Ctor() {}
//line :170:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_A) Invoke_O_O_O_O__O(self, s__0, features__1, depth0__2 any) any {






	{ var tmp1 any; var root_688 any = A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any; var root_683 any = A_arbace_repr_clojure_text_A_const_63.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = s__0; var arg_687 any = Lit_16; if linked_684 == nil { arg_691 = ifn_685.Invoke_O_O__O(arg_686, arg_687) } else { arg_691 = linked_684.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_683, arg_686, arg_687) }; if linked_689 == nil { tmp1 = ifn_690.Invoke_O__O(arg_691) } else { tmp1 = linked_689.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_688, arg_691) }; if jrt.J2g_Truth(tmp1) { return s__0 } else { var n__4 int32 = lang.RT_Count_O__I_NoInit(s__0); var sb__5 any = jrt.StringBuilder_New(); var i__6 any = lang.RT_Box_J__Number_NoInit(0); var depth__7 any = depth0__2; L1: for {



		var tmp2 bool; var na_692 any = i__6; var na_693 int64 = int64(n__4); if jrt.Long_InstanceOf(na_692) { var n0_694 int64 = jrt.NN(jrt.Long_Cast(na_692)).LongValue__J(); var n1_695 int64 = na_693; tmp2 = n0_694 >= n1_695 } else { tmp2 = lang.Numbers_Gte_O_J__Z_NoInit(na_692, na_693) }; if tmp2 {
			var root_697 any = A_arbace_repr_clojure_text_A_const_64.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = sb__5; if linked_698 == nil { return ifn_699.Invoke_O__O(arg_700) } else { return linked_698.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_697, arg_700) } } else {
//line :181:1
				var c__8 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__6)); var copy__9 any; var tmp3 any = A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A_New_O_O_O(i__6, sb__5, s__0); var tmp4 *jrt.Class
				var fncls__701 /*line :181:1*/*jrt.Class = A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A_fn_class


				if fncls__701 == nil { var fncls__701d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A_fn_class = fncls__701d; tmp4 = fncls__701d } else { tmp4 = fncls__701 }; copy__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)
//line :181:1
				var G__670000050__10_ uint16 = c__8



				switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__10_).Ref()) { case 34: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__10_).Ref(), A_arbace_repr_clojure_text_A_const_18) {
					var tmp5 lang.IFn = lang.IFn_Cast(copy__9); var tmp6 any; var root_716 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = s__0; var arg_720 any = i__6; if linked_717 == nil { tmp6 = ifn_718.Invoke_O_O__O(arg_719, arg_720) } else { tmp6 = linked_717.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_716, arg_719, arg_720) }; i__6, depth__7 = tmp5.Invoke_O__O(tmp6), depth__7; continue L1 }
//line :185:1
				case 35: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__10_).Ref(), A_arbace_repr_clojure_text_A_const_36) { var G__670000051__11_ any; var root_705 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_707 lang.IFn





					if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = s__0; var arg_709 any; var na_703 any = i__6; if jrt.Long_InstanceOf(na_703) { var n0_704 int64 = jrt.NN(jrt.Long_Cast(na_703)).LongValue__J(); if n0_704 == 9223372036854775807 { arg_709 = lang.Numbers_Inc_O__Number_NoInit(na_703) } else { arg_709 = jrt.Long_ValueOf_J__Long_NoInit(n0_704 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_703) { var n0_704_2 float64 = jrt.NN(jrt.Double_Cast(na_703)).DoubleValue__D(); arg_709 = jrt.Double_ValueOf_D__Double_NoInit(n0_704_2 + 1.0).Ref() } else { arg_709 = lang.Numbers_Inc_O__Number_NoInit(na_703) } }; if linked_706 == nil { G__670000051__11_ = ifn_707.Invoke_O_O__O(arg_708, arg_709) } else { G__670000051__11_ = linked_706.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_705, arg_708, arg_709) }; switch lang.Util_Hash_O__I_NoInit(G__670000051__11_) { case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__670000051__11_, A_arbace_repr_clojure_text_A_const_37) {

						var tmp7 lang.IFn = lang.IFn_Cast(copy__9); var tmp8 any; var root_721 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = s__0; var arg_725 any = i__6; if linked_722 == nil { tmp8 = ifn_723.Invoke_O_O__O(arg_724, arg_725) } else { tmp8 = linked_722.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_721, arg_724, arg_725) }; i__6, depth__7 = tmp7.Invoke_O__O(tmp8), depth__7; continue L1 }
//line :191:1
					case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000051__11_, A_arbace_repr_clojure_text_A_const_18) {
						var tmp9 lang.IFn = lang.IFn_Cast(copy__9); var tmp10 any; var root_728 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = s__0; var arg_732 any; var na_726 any = i__6; if jrt.Long_InstanceOf(na_726) { var n0_727 int64 = jrt.NN(jrt.Long_Cast(na_726)).LongValue__J(); if n0_727 == 9223372036854775807 { arg_732 = lang.Numbers_Inc_O__Number_NoInit(na_726) } else { arg_732 = jrt.Long_ValueOf_J__Long_NoInit(n0_727 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_726) { var n0_727_2 float64 = jrt.NN(jrt.Double_Cast(na_726)).DoubleValue__D(); arg_732 = jrt.Double_ValueOf_D__Double_NoInit(n0_727_2 + 1.0).Ref() } else { arg_732 = lang.Numbers_Inc_O__Number_NoInit(na_726) } }; if linked_729 == nil { tmp10 = ifn_730.Invoke_O_O__O(arg_731, arg_732) } else { tmp10 = linked_729.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_728, arg_731, arg_732) }; i__6, depth__7 = tmp9.Invoke_O__O(tmp10), depth__7; continue L1 }
//line :191:1
					case 63: if lang.Util_Equiv_O_O__Z_NoInit(G__670000051__11_, A_arbace_repr_clojure_text_A_const_51) { var e__12 any; var root_711 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_713 lang.IFn


						if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = s__0; var arg_715 any = i__6; if linked_712 == nil { e__12 = ifn_713.Invoke_O_O__O(arg_714, arg_715) } else { e__12 = linked_712.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_711, arg_714, arg_715) }
						var tmp11 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__5); var tmp12 any; var root_733 any = A_arbace_repr_clojure_text_A_const_65.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, A_arbace_repr_clojure_text_selected_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = s__0; var arg_737 any = i__6; var arg_738 any = features__1; var arg_739 any = depth__7; if linked_734 == nil { tmp12 = ifn_735.Invoke_O_O_O_O__O(arg_736, arg_737, arg_738, arg_739) } else { tmp12 = linked_734.(*A_arbace_repr_clojure_text_selected_A).Invoke_O_O_O_O_O__O(root_733, arg_736, arg_737, arg_738, arg_739) }; jrt.NN(tmp11).Append_String__StringBuilder(jrt.String_Cast(tmp12))
						i__6, depth__7 = e__12, depth__7; continue L1 }
//line :191:1
					default:
					}




					var tmp13 lang.IFn = lang.IFn_Cast(copy__9); var tmp14 jrt.Number_I; var na_740 any = i__6; if jrt.Long_InstanceOf(na_740) { var n0_741 int64 = jrt.NN(jrt.Long_Cast(na_740)).LongValue__J(); if n0_741 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_740) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_741 + 1)) } } else { if jrt.Double_InstanceOf(na_740) { var n0_741_2 float64 = jrt.NN(jrt.Double_Cast(na_740)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_741_2 + 1.0)) } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_740) } }; i__6, depth__7 = tmp13.Invoke_O__O(tmp14), depth__7; continue L1 }
//line :185:1
				case 40: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__10_).Ref(), A_arbace_repr_clojure_text_A_const_19) {



					var tmp15 lang.IFn = lang.IFn_Cast(copy__9); var tmp16 jrt.Number_I; var na_742 any = i__6; if jrt.Long_InstanceOf(na_742) { var n0_743 int64 = jrt.NN(jrt.Long_Cast(na_742)).LongValue__J(); if n0_743 == 9223372036854775807 { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_742) } else { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_743 + 1)) } } else { if jrt.Double_InstanceOf(na_742) { var n0_743_2 float64 = jrt.NN(jrt.Double_Cast(na_742)).DoubleValue__D(); tmp16 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_743_2 + 1.0)) } else { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_742) } }; var tmp17 any = tmp15.Invoke_O__O(tmp16); var tmp18 jrt.Number_I; var na_744 any = depth__7; if jrt.Long_InstanceOf(na_744) { var n0_745 int64 = jrt.NN(jrt.Long_Cast(na_744)).LongValue__J(); if n0_745 == 9223372036854775807 { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_744) } else { tmp18 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_745 + 1)) } } else { if jrt.Double_InstanceOf(na_744) { var n0_745_2 float64 = jrt.NN(jrt.Double_Cast(na_744)).DoubleValue__D(); tmp18 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_745_2 + 1.0)) } else { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_744) } }; i__6, depth__7 = tmp17, tmp18; continue L1 }
//line :185:1
				case 41: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__10_).Ref(), A_arbace_repr_clojure_text_A_const_20) {




					var tmp19 lang.IFn = lang.IFn_Cast(copy__9); var tmp20 jrt.Number_I; var na_746 any = i__6; if jrt.Long_InstanceOf(na_746) { var n0_747 int64 = jrt.NN(jrt.Long_Cast(na_746)).LongValue__J(); if n0_747 == 9223372036854775807 { tmp20 = lang.Numbers_Inc_O__Number_NoInit(na_746) } else { tmp20 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_747 + 1)) } } else { if jrt.Double_InstanceOf(na_746) { var n0_747_2 float64 = jrt.NN(jrt.Double_Cast(na_746)).DoubleValue__D(); tmp20 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_747_2 + 1.0)) } else { tmp20 = lang.Numbers_Inc_O__Number_NoInit(na_746) } }; var tmp21 any = tmp19.Invoke_O__O(tmp20); var tmp22 jrt.Number_I; var na_748 any = depth__7; if jrt.Long_InstanceOf(na_748) { var n0_749 int64 = jrt.NN(jrt.Long_Cast(na_748)).LongValue__J(); if n0_749 == -9223372036854775808 { tmp22 = lang.Numbers_Dec_O__Number_NoInit(na_748) } else { tmp22 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_749 - 1)) } } else { if jrt.Double_InstanceOf(na_748) { var n0_749_2 float64 = jrt.NN(jrt.Double_Cast(na_748)).DoubleValue__D(); tmp22 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_749_2 - 1.0)) } else { tmp22 = lang.Numbers_Dec_O__Number_NoInit(na_748) } }; i__6, depth__7 = tmp21, lang.Numbers_Max_J_O__O_NoInit(0, tmp22); continue L1 }
//line :185:1
				case 59: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__10_).Ref(), A_arbace_repr_clojure_text_A_const_21) {

					var tmp23 lang.IFn = lang.IFn_Cast(copy__9); var tmp24 any; var root_750 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = s__0; var arg_754 any = i__6; if linked_751 == nil { tmp24 = ifn_752.Invoke_O_O__O(arg_753, arg_754) } else { tmp24 = linked_751.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_750, arg_753, arg_754) }; i__6, depth__7 = tmp23.Invoke_O__O(tmp24), depth__7; continue L1 }
//line :185:1
				case 91: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__10_).Ref(), A_arbace_repr_clojure_text_A_const_23) {



					var tmp25 lang.IFn = lang.IFn_Cast(copy__9); var tmp26 jrt.Number_I; var na_755 any = i__6; if jrt.Long_InstanceOf(na_755) { var n0_756 int64 = jrt.NN(jrt.Long_Cast(na_755)).LongValue__J(); if n0_756 == 9223372036854775807 { tmp26 = lang.Numbers_Inc_O__Number_NoInit(na_755) } else { tmp26 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_756 + 1)) } } else { if jrt.Double_InstanceOf(na_755) { var n0_756_2 float64 = jrt.NN(jrt.Double_Cast(na_755)).DoubleValue__D(); tmp26 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_756_2 + 1.0)) } else { tmp26 = lang.Numbers_Inc_O__Number_NoInit(na_755) } }; var tmp27 any = tmp25.Invoke_O__O(tmp26); var tmp28 jrt.Number_I; var na_757 any = depth__7; if jrt.Long_InstanceOf(na_757) { var n0_758 int64 = jrt.NN(jrt.Long_Cast(na_757)).LongValue__J(); if n0_758 == 9223372036854775807 { tmp28 = lang.Numbers_Inc_O__Number_NoInit(na_757) } else { tmp28 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_758 + 1)) } } else { if jrt.Double_InstanceOf(na_757) { var n0_758_2 float64 = jrt.NN(jrt.Double_Cast(na_757)).DoubleValue__D(); tmp28 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_758_2 + 1.0)) } else { tmp28 = lang.Numbers_Inc_O__Number_NoInit(na_757) } }; i__6, depth__7 = tmp27, tmp28; continue L1 }
//line :185:1
				case 92: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__10_).Ref(), A_arbace_repr_clojure_text_A_const_24) {


					var tmp29 lang.IFn = lang.IFn_Cast(copy__9); var tmp30 any; var root_759 any = A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, A_arbace_repr_clojure_text_char_end_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = s__0; var arg_763 any = i__6; if linked_760 == nil { tmp30 = ifn_761.Invoke_O_O__O(arg_762, arg_763) } else { tmp30 = linked_760.(*A_arbace_repr_clojure_text_char_end_A).Invoke_O_O_O__O(root_759, arg_762, arg_763) }; i__6, depth__7 = tmp29.Invoke_O__O(tmp30), depth__7; continue L1 }
//line :185:1
				case 93: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__10_).Ref(), A_arbace_repr_clojure_text_A_const_25) {




					var tmp31 lang.IFn = lang.IFn_Cast(copy__9); var tmp32 jrt.Number_I; var na_764 any = i__6; if jrt.Long_InstanceOf(na_764) { var n0_765 int64 = jrt.NN(jrt.Long_Cast(na_764)).LongValue__J(); if n0_765 == 9223372036854775807 { tmp32 = lang.Numbers_Inc_O__Number_NoInit(na_764) } else { tmp32 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_765 + 1)) } } else { if jrt.Double_InstanceOf(na_764) { var n0_765_2 float64 = jrt.NN(jrt.Double_Cast(na_764)).DoubleValue__D(); tmp32 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_765_2 + 1.0)) } else { tmp32 = lang.Numbers_Inc_O__Number_NoInit(na_764) } }; var tmp33 any = tmp31.Invoke_O__O(tmp32); var tmp34 jrt.Number_I; var na_766 any = depth__7; if jrt.Long_InstanceOf(na_766) { var n0_767 int64 = jrt.NN(jrt.Long_Cast(na_766)).LongValue__J(); if n0_767 == -9223372036854775808 { tmp34 = lang.Numbers_Dec_O__Number_NoInit(na_766) } else { tmp34 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_767 - 1)) } } else { if jrt.Double_InstanceOf(na_766) { var n0_767_2 float64 = jrt.NN(jrt.Double_Cast(na_766)).DoubleValue__D(); tmp34 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_767_2 - 1.0)) } else { tmp34 = lang.Numbers_Dec_O__Number_NoInit(na_766) } }; i__6, depth__7 = tmp33, lang.Numbers_Max_J_O__O_NoInit(0, tmp34); continue L1 }
//line :185:1
				case 123: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__10_).Ref(), A_arbace_repr_clojure_text_A_const_28) {



					var tmp35 lang.IFn = lang.IFn_Cast(copy__9); var tmp36 jrt.Number_I; var na_768 any = i__6; if jrt.Long_InstanceOf(na_768) { var n0_769 int64 = jrt.NN(jrt.Long_Cast(na_768)).LongValue__J(); if n0_769 == 9223372036854775807 { tmp36 = lang.Numbers_Inc_O__Number_NoInit(na_768) } else { tmp36 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_769 + 1)) } } else { if jrt.Double_InstanceOf(na_768) { var n0_769_2 float64 = jrt.NN(jrt.Double_Cast(na_768)).DoubleValue__D(); tmp36 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_769_2 + 1.0)) } else { tmp36 = lang.Numbers_Inc_O__Number_NoInit(na_768) } }; var tmp37 any = tmp35.Invoke_O__O(tmp36); var tmp38 jrt.Number_I; var na_770 any = depth__7; if jrt.Long_InstanceOf(na_770) { var n0_771 int64 = jrt.NN(jrt.Long_Cast(na_770)).LongValue__J(); if n0_771 == 9223372036854775807 { tmp38 = lang.Numbers_Inc_O__Number_NoInit(na_770) } else { tmp38 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_771 + 1)) } } else { if jrt.Double_InstanceOf(na_770) { var n0_771_2 float64 = jrt.NN(jrt.Double_Cast(na_770)).DoubleValue__D(); tmp38 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_771_2 + 1.0)) } else { tmp38 = lang.Numbers_Inc_O__Number_NoInit(na_770) } }; i__6, depth__7 = tmp37, tmp38; continue L1 }
//line :185:1
				case 125: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__10_).Ref(), A_arbace_repr_clojure_text_A_const_29) {




					var tmp39 lang.IFn = lang.IFn_Cast(copy__9); var tmp40 jrt.Number_I; var na_772 any = i__6; if jrt.Long_InstanceOf(na_772) { var n0_773 int64 = jrt.NN(jrt.Long_Cast(na_772)).LongValue__J(); if n0_773 == 9223372036854775807 { tmp40 = lang.Numbers_Inc_O__Number_NoInit(na_772) } else { tmp40 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_773 + 1)) } } else { if jrt.Double_InstanceOf(na_772) { var n0_773_2 float64 = jrt.NN(jrt.Double_Cast(na_772)).DoubleValue__D(); tmp40 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_773_2 + 1.0)) } else { tmp40 = lang.Numbers_Inc_O__Number_NoInit(na_772) } }; var tmp41 any = tmp39.Invoke_O__O(tmp40); var tmp42 jrt.Number_I; var na_774 any = depth__7; if jrt.Long_InstanceOf(na_774) { var n0_775 int64 = jrt.NN(jrt.Long_Cast(na_774)).LongValue__J(); if n0_775 == -9223372036854775808 { tmp42 = lang.Numbers_Dec_O__Number_NoInit(na_774) } else { tmp42 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_775 - 1)) } } else { if jrt.Double_InstanceOf(na_774) { var n0_775_2 float64 = jrt.NN(jrt.Double_Cast(na_774)).DoubleValue__D(); tmp42 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_775_2 - 1.0)) } else { tmp42 = lang.Numbers_Dec_O__Number_NoInit(na_774) } }; i__6, depth__7 = tmp41, lang.Numbers_Max_J_O__O_NoInit(0, tmp42); continue L1 }
//line :185:1
				default:
				}











				var tmp43 lang.IFn = lang.IFn_Cast(copy__9); var tmp44 any; var tmp45 any; var root_776 any = A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = jrt.Character_ValueOf_C__Character_NoInit(c__8).Ref(); if linked_777 == nil { tmp45 = ifn_778.Invoke_O__O(arg_779) } else { tmp45 = linked_777.(*A_arbace_repr_clojure_text_terminating_QMARK__A).Invoke_O_O__O(root_776, arg_779) }; if jrt.J2g_Truth(tmp45) { var na_780 any = i__6; if jrt.Long_InstanceOf(na_780) { var n0_781 int64 = jrt.NN(jrt.Long_Cast(na_780)).LongValue__J(); if n0_781 == 9223372036854775807 { tmp44 = lang.Numbers_Inc_O__Number_NoInit(na_780) } else { tmp44 = jrt.Long_ValueOf_J__Long_NoInit(n0_781 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_780) { var n0_781_2 float64 = jrt.NN(jrt.Double_Cast(na_780)).DoubleValue__D(); tmp44 = jrt.Double_ValueOf_D__Double_NoInit(n0_781_2 + 1.0).Ref() } else { tmp44 = lang.Numbers_Inc_O__Number_NoInit(na_780) } } } else { var root_782 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_784 lang.IFn; if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = s__0; var arg_786 any = i__6; if linked_783 == nil { tmp44 = ifn_784.Invoke_O_O__O(arg_785, arg_786) } else { tmp44 = linked_783.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_782, arg_785, arg_786) } }; i__6, depth__7 = tmp43.Invoke_O__O(tmp44), depth__7; continue L1 } } } }
//line :170:1
	panic("j2g: unreachable") }
//line :170:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_A) Invoke_O_O_O__O(self, s__0, features__1 any) any {




	var root_787 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = s__0; var arg_791 any = features__1; var arg_792 any = A_arbace_repr_clojure_text_A_const_12; if linked_788 == nil { return ifn_789.Invoke_O_O_O__O(arg_790, arg_791, arg_792) } else { return linked_788.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O_O__O(root_787, arg_790, arg_791, arg_792) } }
//line :170:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_A) Invoke_O_O__O(self, s__0 any) any {



	var root_793 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = s__0; var arg_797 any = A_arbace_repr_clojure_text_A_const_66; if linked_794 == nil { return ifn_795.Invoke_O_O__O(arg_796, arg_797) } else { return linked_794.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O__O(root_793, arg_796, arg_797)
	}
}







func A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :184:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A) Ctor_O_O_O(c__i, c__sb, c__s any) { t.F_i = c__i; t.F_sb = c__sb; t.F_s = c__s }
//line :184:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A) Invoke_O_O__O(self, j__1 any) any { var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp2 jrt.CharSequence = jrt.CharSequence_Cast(t.F_s); jrt.NN(tmp1).Append_CharSequence_I_I__StringBuilder(tmp2, lang.RT_IntCast_O__I_NoInit(t.F_i), lang.RT_IntCast_O__I_NoInit(j__1)); return j__1 }

















func A_arbace_repr_clojure_text_code_tokens_A_New() *A_arbace_repr_clojure_text_code_tokens_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_code_tokens_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_repr_clojure_text_code_tokens_A) Ctor() {}
//line :202:1
func (t *A_arbace_repr_clojure_text_code_tokens_A) Invoke_O_O__O(self, s__0 any) any { { var n__2 int32 = lang.RT_Count_O__I_NoInit(s__0); var i__3 any = lang.RT_Box_J__Number_NoInit(0); var out__4 any; var root_798 any = A_arbace_repr_clojure_text_A_const_67.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_800 lang.IFn




	if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = lang.PersistentVector_EMPTY.Ref(); if linked_799 == nil { out__4 = ifn_800.Invoke_O__O(arg_801) } else { out__4 = linked_799.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_798, arg_801) }
//line :202:1
L1: for {





	var tmp1 bool; var na_802 any = i__3; var na_803 int64 = int64(n__2); if jrt.Long_InstanceOf(na_802) { var n0_804 int64 = jrt.NN(jrt.Long_Cast(na_802)).LongValue__J(); var n1_805 int64 = na_803; tmp1 = n0_804 >= n1_805 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_802, na_803) }; if tmp1 {
		var root_807 any = A_arbace_repr_clojure_text_A_const_68.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = out__4; if linked_808 == nil { return ifn_809.Invoke_O__O(arg_810) } else { return linked_808.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_807, arg_810) } } else {
//line :208:1
			var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__3))


			if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_18)).CharValue__C()) {
				var tmp2 any; var root_828 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = s__0; var arg_832 any = i__3; if linked_829 == nil { tmp2 = ifn_830.Invoke_O_O__O(arg_831, arg_832) } else { tmp2 = linked_829.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_828, arg_831, arg_832) }; i__3, out__4 = tmp2, out__4; continue L1 } else {
//line :211:1
					if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_21)).CharValue__C()) {

						var tmp3 any; var root_833 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = s__0; var arg_837 any = i__3; if linked_834 == nil { tmp3 = ifn_835.Invoke_O_O__O(arg_836, arg_837) } else { tmp3 = linked_834.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_833, arg_836, arg_837) }; i__3, out__4 = tmp3, out__4; continue L1 } else {
//line :211:1
							if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_24)).CharValue__C()) {


								var tmp4 any; var root_838 any = A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, A_arbace_repr_clojure_text_char_end_A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = s__0; var arg_842 any = i__3; if linked_839 == nil { tmp4 = ifn_840.Invoke_O_O__O(arg_841, arg_842) } else { tmp4 = linked_839.(*A_arbace_repr_clojure_text_char_end_A).Invoke_O_O_O__O(root_838, arg_841, arg_842) }; i__3, out__4 = tmp4, out__4; continue L1 } else {
//line :211:1
									if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C()) { var G__670000054__6_ any; var root_813 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_815 lang.IFn



										if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = s__0; var arg_817 any; var na_811 any = i__3; if jrt.Long_InstanceOf(na_811) { var n0_812 int64 = jrt.NN(jrt.Long_Cast(na_811)).LongValue__J(); if n0_812 == 9223372036854775807 { arg_817 = lang.Numbers_Inc_O__Number_NoInit(na_811) } else { arg_817 = jrt.Long_ValueOf_J__Long_NoInit(n0_812 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_811) { var n0_812_2 float64 = jrt.NN(jrt.Double_Cast(na_811)).DoubleValue__D(); arg_817 = jrt.Double_ValueOf_D__Double_NoInit(n0_812_2 + 1.0).Ref() } else { arg_817 = lang.Numbers_Inc_O__Number_NoInit(na_811) } }; if linked_814 == nil { G__670000054__6_ = ifn_815.Invoke_O_O__O(arg_816, arg_817) } else { G__670000054__6_ = linked_814.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_813, arg_816, arg_817) }; switch lang.Util_Hash_O__I_NoInit(G__670000054__6_) { case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__670000054__6_, A_arbace_repr_clojure_text_A_const_37) {

											var tmp5 any; var root_843 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_843, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_845 lang.IFn; if linked_844 == nil { ifn_845 = lang.IFn_Cast(root_843) } else { ifn_845 = nil }; var arg_846 any = s__0; var arg_847 any = i__3; if linked_844 == nil { tmp5 = ifn_845.Invoke_O_O__O(arg_846, arg_847) } else { tmp5 = linked_844.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_843, arg_846, arg_847) }; i__3, out__4 = tmp5, out__4; continue L1 }
//line :215:1
										case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000054__6_, A_arbace_repr_clojure_text_A_const_18) {
											var tmp6 any; var root_850 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = s__0; var arg_854 any; var na_848 any = i__3; if jrt.Long_InstanceOf(na_848) { var n0_849 int64 = jrt.NN(jrt.Long_Cast(na_848)).LongValue__J(); if n0_849 == 9223372036854775807 { arg_854 = lang.Numbers_Inc_O__Number_NoInit(na_848) } else { arg_854 = jrt.Long_ValueOf_J__Long_NoInit(n0_849 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_848) { var n0_849_2 float64 = jrt.NN(jrt.Double_Cast(na_848)).DoubleValue__D(); arg_854 = jrt.Double_ValueOf_D__Double_NoInit(n0_849_2 + 1.0).Ref() } else { arg_854 = lang.Numbers_Inc_O__Number_NoInit(na_848) } }; if linked_851 == nil { tmp6 = ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { tmp6 = linked_851.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_850, arg_853, arg_854) }; i__3, out__4 = tmp6, out__4; continue L1 }
//line :215:1
										default:
										}

										var tmp7 jrt.Number_I; var na_855 any = i__3; if jrt.Long_InstanceOf(na_855) { var n0_856 int64 = jrt.NN(jrt.Long_Cast(na_855)).LongValue__J(); if n0_856 == 9223372036854775807 { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_855) } else { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_856 + 1)) } } else { if jrt.Double_InstanceOf(na_855) { var n0_856_2 float64 = jrt.NN(jrt.Double_Cast(na_855)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_856_2 + 1.0)) } else { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_855) } }; i__3, out__4 = tmp7, out__4; continue L1 } else {
//line :211:1
											var tmp8 any; var root_819 any = A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_819, A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class); var ifn_821 lang.IFn







											if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var arg_822 any = jrt.Character_ValueOf_C__Character_NoInit(c__5).Ref(); if linked_820 == nil { tmp8 = ifn_821.Invoke_O__O(arg_822) } else { tmp8 = linked_820.(*A_arbace_repr_clojure_text_terminating_QMARK__A).Invoke_O_O__O(root_819, arg_822) }
//line :211:1
											if jrt.J2g_Truth(tmp8) {







												var tmp9 jrt.Number_I; var na_857 any = i__3; if jrt.Long_InstanceOf(na_857) { var n0_858 int64 = jrt.NN(jrt.Long_Cast(na_857)).LongValue__J(); if n0_858 == 9223372036854775807 { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_857) } else { tmp9 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_858 + 1)) } } else { if jrt.Double_InstanceOf(na_857) { var n0_858_2 float64 = jrt.NN(jrt.Double_Cast(na_857)).DoubleValue__D(); tmp9 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_858_2 + 1.0)) } else { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_857) } }; i__3, out__4 = tmp9, out__4; continue L1 } else {
//line :211:1
													var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_69); if jrt.J2g_Truth(tmp10.Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(c__5).Ref())) {








														var tmp11 jrt.Number_I; var na_859 any = i__3; if jrt.Long_InstanceOf(na_859) { var n0_860 int64 = jrt.NN(jrt.Long_Cast(na_859)).LongValue__J(); if n0_860 == 9223372036854775807 { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_859) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_860 + 1)) } } else { if jrt.Double_InstanceOf(na_859) { var n0_860_2 float64 = jrt.NN(jrt.Double_Cast(na_859)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_860_2 + 1.0)) } else { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_859) } }; i__3, out__4 = tmp11, out__4; continue L1 } else {
//line :211:1
															if A_arbace_repr_clojure_text_A_const_34 != nil { var e__6 any; var root_823 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_825 lang.IFn









																if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any = s__0; var arg_827 any = i__3; if linked_824 == nil { e__6 = ifn_825.Invoke_O_O__O(arg_826, arg_827) } else { e__6 = linked_824.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_823, arg_826, arg_827) }; var tmp12 any; var root_861 any = A_arbace_repr_clojure_text_A_const_70.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = out__4; var arg_865 any = lang.Tuple_Create_O_O__IPersistentVector(i__3, e__6); if linked_862 == nil { tmp12 = ifn_863.Invoke_O_O__O(arg_864, arg_865) } else { tmp12 = linked_862.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_861, arg_864, arg_865) }; i__3, out__4 = e__6, tmp12; continue L1 } else {
//line :211:1
																	return nil } } } } } } } } } }; /*line :202:1*/panic("j2g: unreachable") }




















func A_arbace_repr_clojure_text_list_spans_A_New() *A_arbace_repr_clojure_text_list_spans_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_list_spans_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_repr_clojure_text_list_spans_A) Ctor() {}
//line :223:1
func (t *A_arbace_repr_clojure_text_list_spans_A) Invoke_O_O_O__O(self, s__0, pred__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var i__4 any = lang.RT_Box_J__Number_NoInit(0); var out__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




	var tmp1 bool; var na_866 any = i__4; var na_867 int64 = int64(n__3); if jrt.Long_InstanceOf(na_866) { var n0_868 int64 = jrt.NN(jrt.Long_Cast(na_866)).LongValue__J(); var n1_869 int64 = na_867; tmp1 = n0_868 >= n1_869 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_866, na_867) }; if tmp1 { return out__5 } else { var c__6 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__4))


		if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_18)).CharValue__C()) {
			var tmp2 any; var root_921 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = s__0; var arg_925 any = i__4; if linked_922 == nil { tmp2 = ifn_923.Invoke_O_O__O(arg_924, arg_925) } else { tmp2 = linked_922.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_921, arg_924, arg_925) }; i__4, out__5 = tmp2, out__5; continue L1 } else {
//line :231:1
				if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_21)).CharValue__C()) {

					var tmp3 any; var root_926 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = s__0; var arg_930 any = i__4; if linked_927 == nil { tmp3 = ifn_928.Invoke_O_O__O(arg_929, arg_930) } else { tmp3 = linked_927.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_926, arg_929, arg_930) }; i__4, out__5 = tmp3, out__5; continue L1 } else {
//line :231:1
						if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_24)).CharValue__C()) {


							var tmp4 any; var root_931 any = A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O(); var linked_932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_931, A_arbace_repr_clojure_text_char_end_A_fn_class); var ifn_933 lang.IFn; if linked_932 == nil { ifn_933 = lang.IFn_Cast(root_931) } else { ifn_933 = nil }; var arg_934 any = s__0; var arg_935 any = i__4; if linked_932 == nil { tmp4 = ifn_933.Invoke_O_O__O(arg_934, arg_935) } else { tmp4 = linked_932.(*A_arbace_repr_clojure_text_char_end_A).Invoke_O_O_O__O(root_931, arg_934, arg_935) }; i__4, out__5 = tmp4, out__5; continue L1 } else {
//line :231:1
								var tmp5 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())



								if and__1927000168__auto____7 { var tmp6 any = A_arbace_repr_clojure_text_A_const_18; var tmp7 any; var root_873 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = s__0; var arg_877 any; var na_871 any = i__4; if jrt.Long_InstanceOf(na_871) { var n0_872 int64 = jrt.NN(jrt.Long_Cast(na_871)).LongValue__J(); if n0_872 == 9223372036854775807 { arg_877 = lang.Numbers_Inc_O__Number_NoInit(na_871) } else { arg_877 = jrt.Long_ValueOf_J__Long_NoInit(n0_872 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_871) { var n0_872_2 float64 = jrt.NN(jrt.Double_Cast(na_871)).DoubleValue__D(); arg_877 = jrt.Double_ValueOf_D__Double_NoInit(n0_872_2 + 1.0).Ref() } else { arg_877 = lang.Numbers_Inc_O__Number_NoInit(na_871) } }; if linked_874 == nil { tmp7 = ifn_875.Invoke_O_O__O(arg_876, arg_877) } else { tmp7 = linked_874.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_873, arg_876, arg_877) }; tmp5 = lang.Util_Equiv_O_O__Z_NoInit(tmp6, tmp7) } else { tmp5 = and__1927000168__auto____7 }
//line :231:1
								if tmp5 {



									var tmp8 any; var root_938 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = s__0; var arg_942 any; var na_936 any = i__4; if jrt.Long_InstanceOf(na_936) { var n0_937 int64 = jrt.NN(jrt.Long_Cast(na_936)).LongValue__J(); if n0_937 == 9223372036854775807 { arg_942 = lang.Numbers_Inc_O__Number_NoInit(na_936) } else { arg_942 = jrt.Long_ValueOf_J__Long_NoInit(n0_937 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_936) { var n0_937_2 float64 = jrt.NN(jrt.Double_Cast(na_936)).DoubleValue__D(); arg_942 = jrt.Double_ValueOf_D__Double_NoInit(n0_937_2 + 1.0).Ref() } else { arg_942 = lang.Numbers_Inc_O__Number_NoInit(na_936) } }; if linked_939 == nil { tmp8 = ifn_940.Invoke_O_O__O(arg_941, arg_942) } else { tmp8 = linked_939.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_938, arg_941, arg_942) }; i__4, out__5 = tmp8, out__5; continue L1 } else {
//line :231:1
										var tmp9 bool; var and__1927000168__auto____7_2 bool = lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())




										if and__1927000168__auto____7_2 { var tmp10 any = A_arbace_repr_clojure_text_A_const_37; var tmp11 any; var root_880 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = s__0; var arg_884 any; var na_878 any = i__4; if jrt.Long_InstanceOf(na_878) { var n0_879 int64 = jrt.NN(jrt.Long_Cast(na_878)).LongValue__J(); if n0_879 == 9223372036854775807 { arg_884 = lang.Numbers_Inc_O__Number_NoInit(na_878) } else { arg_884 = jrt.Long_ValueOf_J__Long_NoInit(n0_879 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_878) { var n0_879_2 float64 = jrt.NN(jrt.Double_Cast(na_878)).DoubleValue__D(); arg_884 = jrt.Double_ValueOf_D__Double_NoInit(n0_879_2 + 1.0).Ref() } else { arg_884 = lang.Numbers_Inc_O__Number_NoInit(na_878) } }; if linked_881 == nil { tmp11 = ifn_882.Invoke_O_O__O(arg_883, arg_884) } else { tmp11 = linked_881.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_880, arg_883, arg_884) }; tmp9 = lang.Util_Equiv_O_O__Z_NoInit(tmp10, tmp11) } else { tmp9 = and__1927000168__auto____7_2 }
//line :231:1
										if tmp9 {




											var tmp12 any; var root_943 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = s__0; var arg_947 any = i__4; if linked_944 == nil { tmp12 = ifn_945.Invoke_O_O__O(arg_946, arg_947) } else { tmp12 = linked_944.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_943, arg_946, arg_947) }; i__4, out__5 = tmp12, out__5; continue L1 } else {
//line :231:1
												if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_19)).CharValue__C()) { var h__7 any; var root_887 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_889 lang.IFn






													if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = s__0; var arg_891 any; var na_885 any = i__4; if jrt.Long_InstanceOf(na_885) { var n0_886 int64 = jrt.NN(jrt.Long_Cast(na_885)).LongValue__J(); if n0_886 == 9223372036854775807 { arg_891 = lang.Numbers_Inc_O__Number_NoInit(na_885) } else { arg_891 = jrt.Long_ValueOf_J__Long_NoInit(n0_886 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_885) { var n0_886_2 float64 = jrt.NN(jrt.Double_Cast(na_885)).DoubleValue__D(); arg_891 = jrt.Double_ValueOf_D__Double_NoInit(n0_886_2 + 1.0).Ref() } else { arg_891 = lang.Numbers_Inc_O__Number_NoInit(na_885) } }; if linked_888 == nil { h__7 = ifn_889.Invoke_O_O__O(arg_890, arg_891) } else { h__7 = linked_888.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_887, arg_890, arg_891) }
//line :231:1
													var head__8 any; var tmp13 any; var and__1927000168__auto____8 bool; var na_892 any = h__7; var na_893 int64 = int64(n__3)







													if jrt.Long_InstanceOf(na_892) { var n0_894 int64 = jrt.NN(jrt.Long_Cast(na_892)).LongValue__J(); var n1_895 int64 = na_893; and__1927000168__auto____8 = n0_894 < n1_895 } else { and__1927000168__auto____8 = lang.Numbers_Lt_O_J__Z_NoInit(na_892, na_893) }; if and__1927000168__auto____8 { var root_901 any = A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any; var root_897 any = A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(h__7))).Ref(); if linked_898 == nil { arg_904 = ifn_899.Invoke_O__O(arg_900) } else { arg_904 = linked_898.(*A_arbace_repr_clojure_text_terminating_QMARK__A).Invoke_O_O__O(root_897, arg_900) }; if linked_902 == nil { tmp13 = ifn_903.Invoke_O__O(arg_904) } else { tmp13 = linked_902.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_901, arg_904) } } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp13) {
														var root_910 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = s__0; var arg_914 any = h__7; var arg_915 any; var root_905 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = s__0; var arg_909 any = h__7; if linked_906 == nil { arg_915 = ifn_907.Invoke_O_O__O(arg_908, arg_909) } else { arg_915 = linked_906.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_905, arg_908, arg_909) }; if linked_911 == nil { head__8 = ifn_912.Invoke_O_O_O__O(arg_913, arg_914, arg_915) } else { head__8 = linked_911.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_910, arg_913, arg_914, arg_915) } } else {
//line :239:1
															head__8 = nil
														}
													var tmp14 any; var and__1927000168__auto____9 any = head__8; if jrt.J2g_Truth(and__1927000168__auto____9) { tmp14 = lang.IFn_Cast(pred__1).Invoke_O__O(head__8) } else { tmp14 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp14) { var e__9 any; var root_916 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_918 lang.IFn
														if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any = s__0; var arg_920 any = i__4; if linked_917 == nil { e__9 = ifn_918.Invoke_O_O__O(arg_919, arg_920) } else { e__9 = linked_917.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_916, arg_919, arg_920) }; var tmp15 any; var root_948 any = A_arbace_repr_clojure_text_A_const_7.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = out__5; var arg_952 any = lang.Tuple_Create_O_O__IPersistentVector(i__4, e__9); if linked_949 == nil { tmp15 = ifn_950.Invoke_O_O__O(arg_951, arg_952) } else { tmp15 = linked_949.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_948, arg_951, arg_952) }; i__4, out__5 = e__9, tmp15; continue L1 } else {
															var tmp16 jrt.Number_I; var na_953 any = i__4; if jrt.Long_InstanceOf(na_953) { var n0_954 int64 = jrt.NN(jrt.Long_Cast(na_953)).LongValue__J(); if n0_954 == 9223372036854775807 { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_953) } else { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_954 + 1)) } } else { if jrt.Double_InstanceOf(na_953) { var n0_954_2 float64 = jrt.NN(jrt.Double_Cast(na_953)).DoubleValue__D(); tmp16 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_954_2 + 1.0)) } else { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_953) } }; i__4, out__5 = tmp16, out__5; continue L1 } } else {
//line :231:1
																if A_arbace_repr_clojure_text_A_const_34 != nil {












																	var tmp17 jrt.Number_I; var na_955 any = i__4; if jrt.Long_InstanceOf(na_955) { var n0_956 int64 = jrt.NN(jrt.Long_Cast(na_955)).LongValue__J(); if n0_956 == 9223372036854775807 { tmp17 = lang.Numbers_Inc_O__Number_NoInit(na_955) } else { tmp17 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_956 + 1)) } } else { if jrt.Double_InstanceOf(na_955) { var n0_956_2 float64 = jrt.NN(jrt.Double_Cast(na_955)).DoubleValue__D(); tmp17 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_956_2 + 1.0)) } else { tmp17 = lang.Numbers_Inc_O__Number_NoInit(na_955) } }; i__4, out__5 = tmp17, out__5; continue L1 } else {
//line :231:1
																		return nil } } } } } } } } } }; /*line :223:1*/panic("j2g: unreachable") }







type A_arbace_repr_clojure_text_A struct{ jrt.Object }

var A_arbace_repr_clojure_text_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_text_A_const_0 *lang.Var

var A_arbace_repr_clojure_text_A_const_1 any

var A_arbace_repr_clojure_text_A_const_2 *lang.Var

var A_arbace_repr_clojure_text_A_const_3 any

var A_arbace_repr_clojure_text_A_const_4 *lang.Var

var A_arbace_repr_clojure_text_A_const_5 *lang.Var

var A_arbace_repr_clojure_text_A_const_6 *lang.Var

var A_arbace_repr_clojure_text_A_const_7 *lang.Var

var A_arbace_repr_clojure_text_A_const_8 any

var A_arbace_repr_clojure_text_A_const_9 *lang.Var

var A_arbace_repr_clojure_text_A_const_10 any

var A_arbace_repr_clojure_text_A_const_11 *lang.Var

var A_arbace_repr_clojure_text_A_const_12 any

var A_arbace_repr_clojure_text_A_const_13 *lang.Var

var A_arbace_repr_clojure_text_A_const_14 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_15 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_16 any

var A_arbace_repr_clojure_text_A_const_17 *lang.Var

var A_arbace_repr_clojure_text_A_const_18 any

var A_arbace_repr_clojure_text_A_const_19 any

var A_arbace_repr_clojure_text_A_const_20 any

var A_arbace_repr_clojure_text_A_const_21 any

var A_arbace_repr_clojure_text_A_const_22 any

var A_arbace_repr_clojure_text_A_const_23 any

var A_arbace_repr_clojure_text_A_const_24 any

var A_arbace_repr_clojure_text_A_const_25 any

var A_arbace_repr_clojure_text_A_const_26 any

var A_arbace_repr_clojure_text_A_const_27 any

var A_arbace_repr_clojure_text_A_const_28 any

var A_arbace_repr_clojure_text_A_const_29 any

var A_arbace_repr_clojure_text_A_const_30 any

var A_arbace_repr_clojure_text_A_const_31 *lang.Var

var A_arbace_repr_clojure_text_A_const_32 *lang.Var

var A_arbace_repr_clojure_text_A_const_33 *lang.Var

var A_arbace_repr_clojure_text_A_const_34 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_35 *lang.Var

var A_arbace_repr_clojure_text_A_const_36 any

var A_arbace_repr_clojure_text_A_const_37 any

var A_arbace_repr_clojure_text_A_const_38 *lang.Var

var A_arbace_repr_clojure_text_A_const_39 any

var A_arbace_repr_clojure_text_A_const_40 *lang.Var

var A_arbace_repr_clojure_text_A_const_41 *lang.Var

var A_arbace_repr_clojure_text_A_const_42 *lang.Var

var A_arbace_repr_clojure_text_A_const_43 *lang.Var

var A_arbace_repr_clojure_text_A_const_44 any

var A_arbace_repr_clojure_text_A_const_45 *lang.Var

var A_arbace_repr_clojure_text_A_const_46 *lang.Var

var A_arbace_repr_clojure_text_A_const_47 any

var A_arbace_repr_clojure_text_A_const_48 *lang.Var

var A_arbace_repr_clojure_text_A_const_49 any

var A_arbace_repr_clojure_text_A_const_50 any

var A_arbace_repr_clojure_text_A_const_51 any

var A_arbace_repr_clojure_text_A_const_52 *lang.Var

var A_arbace_repr_clojure_text_A_const_53 *lang.Var

var A_arbace_repr_clojure_text_A_const_54 *lang.Var

var A_arbace_repr_clojure_text_A_const_55 *lang.Var

var A_arbace_repr_clojure_text_A_const_56 any

var A_arbace_repr_clojure_text_A_const_57 *lang.Var

var A_arbace_repr_clojure_text_A_const_58 *lang.Var

var A_arbace_repr_clojure_text_A_const_59 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_60 *lang.Var

var A_arbace_repr_clojure_text_A_const_61 *lang.Var

var A_arbace_repr_clojure_text_A_const_62 any

var A_arbace_repr_clojure_text_A_const_63 *lang.Var

var A_arbace_repr_clojure_text_A_const_64 *lang.Var

var A_arbace_repr_clojure_text_A_const_65 *lang.Var

var A_arbace_repr_clojure_text_A_const_66 any

var A_arbace_repr_clojure_text_A_const_67 *lang.Var

var A_arbace_repr_clojure_text_A_const_68 *lang.Var

var A_arbace_repr_clojure_text_A_const_69 any

var A_arbace_repr_clojure_text_A_const_70 *lang.Var

var A_arbace_repr_clojure_text_A_init jrt.ClassInit

func A_arbace_repr_clojure_text_A_Init() { if !A_arbace_repr_clojure_text_A_init.Done() { A_arbace_repr_clojure_text_A_init.Run(A_arbace_repr_clojure_text_A_clinit) } }

func A_arbace_repr_clojure_text_A_clinit() { A_arbace_repr_clojure_text_A_clinit_p0(); A_arbace_repr_clojure_text_A_clinit_p1(); A_arbace_repr_clojure_text_A_clinit_p2(); A_arbace_repr_clojure_text_A_clinit_p3(); A_arbace_repr_clojure_text_A_clinit_p4(); A_arbace_repr_clojure_text_A_clinit_p5() }

func A_arbace_repr_clojure_text_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_text_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 81); A_arbace_repr_clojure_text_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[10]); A_arbace_repr_clojure_text_A_const_1 = A_arbace_repr_clojure_text_A_const_pool.A[11]; A_arbace_repr_clojure_text_A_const_2 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[12]); A_arbace_repr_clojure_text_A_const_3 = A_arbace_repr_clojure_text_A_const_pool.A[13]; A_arbace_repr_clojure_text_A_const_4 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[14]); A_arbace_repr_clojure_text_A_const_5 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[15]); A_arbace_repr_clojure_text_A_const_6 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[16]); A_arbace_repr_clojure_text_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[17]); A_arbace_repr_clojure_text_A_const_8 = A_arbace_repr_clojure_text_A_const_pool.A[18]; A_arbace_repr_clojure_text_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[19]); A_arbace_repr_clojure_text_A_const_10 = A_arbace_repr_clojure_text_A_const_pool.A[20]; A_arbace_repr_clojure_text_A_const_11 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[21]) }

func A_arbace_repr_clojure_text_A_clinit_p1() { A_arbace_repr_clojure_text_A_const_12 = A_arbace_repr_clojure_text_A_const_pool.A[22]; A_arbace_repr_clojure_text_A_const_13 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[23]); A_arbace_repr_clojure_text_A_const_14 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[24]); A_arbace_repr_clojure_text_A_const_15 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[25]); A_arbace_repr_clojure_text_A_const_16 = A_arbace_repr_clojure_text_A_const_pool.A[26]; A_arbace_repr_clojure_text_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[27]); A_arbace_repr_clojure_text_A_const_18 = A_arbace_repr_clojure_text_A_const_pool.A[28]; A_arbace_repr_clojure_text_A_const_19 = A_arbace_repr_clojure_text_A_const_pool.A[29]; A_arbace_repr_clojure_text_A_const_20 = A_arbace_repr_clojure_text_A_const_pool.A[30]; A_arbace_repr_clojure_text_A_const_21 = A_arbace_repr_clojure_text_A_const_pool.A[31]; A_arbace_repr_clojure_text_A_const_22 = A_arbace_repr_clojure_text_A_const_pool.A[32]; A_arbace_repr_clojure_text_A_const_23 = A_arbace_repr_clojure_text_A_const_pool.A[33]; A_arbace_repr_clojure_text_A_const_24 = A_arbace_repr_clojure_text_A_const_pool.A[34]; A_arbace_repr_clojure_text_A_const_25 = A_arbace_repr_clojure_text_A_const_pool.A[35] }

func A_arbace_repr_clojure_text_A_clinit_p2() { A_arbace_repr_clojure_text_A_const_26 = A_arbace_repr_clojure_text_A_const_pool.A[36]; A_arbace_repr_clojure_text_A_const_27 = A_arbace_repr_clojure_text_A_const_pool.A[37]; A_arbace_repr_clojure_text_A_const_28 = A_arbace_repr_clojure_text_A_const_pool.A[38]; A_arbace_repr_clojure_text_A_const_29 = A_arbace_repr_clojure_text_A_const_pool.A[39]; A_arbace_repr_clojure_text_A_const_30 = A_arbace_repr_clojure_text_A_const_pool.A[40]; A_arbace_repr_clojure_text_A_const_31 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[41]); A_arbace_repr_clojure_text_A_const_32 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[42]); A_arbace_repr_clojure_text_A_const_33 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[43]); A_arbace_repr_clojure_text_A_const_34 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[44]); A_arbace_repr_clojure_text_A_const_35 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[45]); A_arbace_repr_clojure_text_A_const_36 = A_arbace_repr_clojure_text_A_const_pool.A[46]; A_arbace_repr_clojure_text_A_const_37 = A_arbace_repr_clojure_text_A_const_pool.A[47]; A_arbace_repr_clojure_text_A_const_38 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[48]); A_arbace_repr_clojure_text_A_const_39 = A_arbace_repr_clojure_text_A_const_pool.A[49] }

func A_arbace_repr_clojure_text_A_clinit_p3() { A_arbace_repr_clojure_text_A_const_40 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[50]); A_arbace_repr_clojure_text_A_const_41 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[51]); A_arbace_repr_clojure_text_A_const_42 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[52]); A_arbace_repr_clojure_text_A_const_43 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[53]); A_arbace_repr_clojure_text_A_const_44 = A_arbace_repr_clojure_text_A_const_pool.A[54]; A_arbace_repr_clojure_text_A_const_45 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[55]); A_arbace_repr_clojure_text_A_const_46 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[56]); A_arbace_repr_clojure_text_A_const_47 = A_arbace_repr_clojure_text_A_const_pool.A[57]; A_arbace_repr_clojure_text_A_const_48 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[58]); A_arbace_repr_clojure_text_A_const_49 = A_arbace_repr_clojure_text_A_const_pool.A[59]; A_arbace_repr_clojure_text_A_const_50 = A_arbace_repr_clojure_text_A_const_pool.A[60]; A_arbace_repr_clojure_text_A_const_51 = A_arbace_repr_clojure_text_A_const_pool.A[61]; A_arbace_repr_clojure_text_A_const_52 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[62]) }

func A_arbace_repr_clojure_text_A_clinit_p4() { A_arbace_repr_clojure_text_A_const_53 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[63]); A_arbace_repr_clojure_text_A_const_54 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[64]); A_arbace_repr_clojure_text_A_const_55 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[65]); A_arbace_repr_clojure_text_A_const_56 = A_arbace_repr_clojure_text_A_const_pool.A[66]; A_arbace_repr_clojure_text_A_const_57 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[67]); A_arbace_repr_clojure_text_A_const_58 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[68]); A_arbace_repr_clojure_text_A_const_59 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[69]); A_arbace_repr_clojure_text_A_const_60 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[70]); A_arbace_repr_clojure_text_A_const_61 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[71]); A_arbace_repr_clojure_text_A_const_62 = A_arbace_repr_clojure_text_A_const_pool.A[72]; A_arbace_repr_clojure_text_A_const_63 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[73]); A_arbace_repr_clojure_text_A_const_64 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[74]) }

func A_arbace_repr_clojure_text_A_clinit_p5() { A_arbace_repr_clojure_text_A_const_65 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[75]); A_arbace_repr_clojure_text_A_const_66 = A_arbace_repr_clojure_text_A_const_pool.A[76]; A_arbace_repr_clojure_text_A_const_67 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[77]); A_arbace_repr_clojure_text_A_const_68 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[78]); A_arbace_repr_clojure_text_A_const_69 = A_arbace_repr_clojure_text_A_const_pool.A[79]; A_arbace_repr_clojure_text_A_const_70 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[80]) }

func A_arbace_repr_clojure_text_A_New() *A_arbace_repr_clojure_text_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_text_A) Ctor() {}

func (t *A_arbace_repr_clojure_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_text_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_text_A_class }

func (t *A_arbace_repr_clojure_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_text_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_text_A); return ok }

func A_arbace_repr_clojure_text_A_Cast(x any) *A_arbace_repr_clojure_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_text_A_class)) }; return v }



type A_arbace_repr_clojure_text_at_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_at_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_branches_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_branches_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_char_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_char_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_code_tokens_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_code_tokens_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_coll_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_coll_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_cond_open_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_cond_open_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_cond_open_fn__670000030_A struct{ j2g_header uint64; F_i, F_s any }

var A_arbace_repr_clojure_text_cond_open_fn__670000030_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_eval670000004_A struct{ jrt.Object }

func A_arbace_repr_clojure_text_eval670000004_A_New() *A_arbace_repr_clojure_text_eval670000004_A { t := &A_arbace_repr_clojure_text_eval670000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_text_eval670000004_A) Ctor() {}

func (t *A_arbace_repr_clojure_text_eval670000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_text_eval670000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_text_eval670000004_A_class }

func (t *A_arbace_repr_clojure_text_eval670000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_text_eval670000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_text_eval670000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_text_eval670000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_text_eval670000004_A); return ok }

func A_arbace_repr_clojure_text_eval670000004_A_Cast(x any) *A_arbace_repr_clojure_text_eval670000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_text_eval670000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_text_eval670000004_A_class)) }; return v }



type A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_eval670000008_A struct{ jrt.Object }

func A_arbace_repr_clojure_text_eval670000008_A_New() *A_arbace_repr_clojure_text_eval670000008_A { t := &A_arbace_repr_clojure_text_eval670000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_text_eval670000008_A) Ctor() {}

func (t *A_arbace_repr_clojure_text_eval670000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_text_eval670000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_text_eval670000008_A_class }

func (t *A_arbace_repr_clojure_text_eval670000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_text_eval670000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_text_eval670000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_text_eval670000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_text_eval670000008_A); return ok }

func A_arbace_repr_clojure_text_eval670000008_A_Cast(x any) *A_arbace_repr_clojure_text_eval670000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_text_eval670000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_text_eval670000008_A_class)) }; return v }



type A_arbace_repr_clojure_text_eval670000008_fn__670000009_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_eval670000008_fn__670000009_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_fail_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_fail_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_fail_fn__670000013_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_fail_fn__670000013_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_form_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_form_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_line_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_line_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_list_spans_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_list_spans_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_next_form_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_next_form_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_resolve_conditionals_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A struct{ j2g_header uint64; F_i, F_sb, F_s any }

var A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_selected_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_selected_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_selected_fn__670000038_A struct{ j2g_header uint64; F_features any }

var A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_skip_ws_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_skip_ws_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_string_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_string_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_terminating_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_token_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_token_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_ws_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_ws_QMARK__A_fn_class *jrt.Class
