//line aot_arbace_repr_clojure_text.ae:1
package aot_arbace_repr_clojure_text

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A_New() *A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_text_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_text_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_clojure_text_eval670000008_fn__670000009_A_New() *A_arbace_repr_clojure_text_eval670000008_fn__670000009_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_eval670000008_fn__670000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000008_fn__670000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000008_fn__670000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_repr_clojure_text_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_repr_clojure_text_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_clojure_text_A_const_7.GetRawRoot__O(), A_arbace_repr_clojure_text_A_const_8) }

















func A_arbace_repr_clojure_text_fail_A_New() *A_arbace_repr_clojure_text_fail_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_fail_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_repr_clojure_text_fail_A) Ctor() {}
//line :19:1
func (t *A_arbace_repr_clojure_text_fail_A) Invoke_O_O_O_O__O(self, s__0, i__1, msg__2 any) any { var line__4 int64; var tmp1 any; var root_19 any = A_arbace_repr_clojure_text_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_21 lang.IFn; if
												linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any; var tmp2 any = A_arbace_repr_clojure_text_fail_fn__670000013_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_repr_clojure_text_fail_fn__670000013_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_repr_clojure_text_fail_fn__670000013_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; arg_22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_23 any; var root_25 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = s__0; var arg_29 any = A_arbace_repr_clojure_text_A_const_12; var arg_30 any = lang.Numbers_Min_O_J__O_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(s__0))); if linked_26 == nil { arg_23 = ifn_27.Invoke_O_O_O__O(arg_28, arg_29, arg_30) } else { arg_23 = linked_26.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_25, arg_28, arg_29, arg_30) }; if linked_20 == nil { tmp1 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { tmp1 = linked_20.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) }; line__4 = lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp1))); var tmp4 any; var root_31 any = /*line :19:1*/A_arbace_repr_clojure_text_A_const_13.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_33 lang.IFn; if

	linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, msg__2, nil, jrt.Long_ValueOf_J__Long_NoInit(line__4).Ref(), nil)).Ref(); var tmp5 any = A_arbace_repr_clojure_text_A_const_14; var tmp6 any = A_arbace_repr_clojure_text_A_const_15; var arg_35 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, i__1, tmp6, jrt.Long_ValueOf_J__Long_NoInit(line__4).Ref())); if linked_32 == nil { tmp4 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { tmp4 = linked_32.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; /*line :19:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp4))) }
func A_arbace_repr_clojure_text_fail_fn__670000013_A_New() *A_arbace_repr_clojure_text_fail_fn__670000013_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_fail_fn__670000013_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_repr_clojure_text_fail_fn__670000013_A) Ctor() {}
//line :20:1
func (t *A_arbace_repr_clojure_text_fail_fn__670000013_A) Invoke_O_O__O(self, p1__670000012_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_clojure_text_A_const_10, p1__670000012_SHARP___1)).Ref() }


func A_arbace_repr_clojure_text_ws_QMARK__A_New() *A_arbace_repr_clojure_text_ws_QMARK__A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_ws_QMARK__A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_repr_clojure_text_ws_QMARK__A) Ctor() {}
//line :23:1
func (t *A_arbace_repr_clojure_text_ws_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 bool = jrt.Character_IsWhitespace_C__Z_NoInit(lang.RT_CharCast_O__C_NoInit(c__0)); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(c__0, A_arbace_repr_clojure_text_A_const_16)).Ref() } }

func A_arbace_repr_clojure_text_terminating_QMARK__A_New() *A_arbace_repr_clojure_text_terminating_QMARK__A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_terminating_QMARK__A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_repr_clojure_text_terminating_QMARK__A) Ctor() {}
//line :25:1
func (t *A_arbace_repr_clojure_text_terminating_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 any; var root_36 any = A_arbace_repr_clojure_text_A_const_17.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, A_arbace_repr_clojure_text_ws_QMARK__A_fn_class); var ifn_38 lang.IFn; if



	linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = c__0; if linked_37 == nil { or__1927000174__auto____2 = ifn_38.Invoke_O__O(arg_39) } else { or__1927000174__auto____2 = linked_37.(*A_arbace_repr_clojure_text_ws_QMARK__A).Invoke_O_O__O(root_36, arg_39) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var G__670000017__3_ any = c__0; switch lang.Util_Hash_O__I_NoInit(G__670000017__3_) { case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_18) { return jrt.Boolean_TRUE.Ref() }; case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_19) { return jrt.Boolean_TRUE.Ref() }; case 41: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_20) { return jrt.Boolean_TRUE.Ref() }; case 59: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_21) { return jrt.Boolean_TRUE.Ref() }; case 64: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_22) { return jrt.Boolean_TRUE.Ref() }; case 91: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_23) { return jrt.Boolean_TRUE.Ref() }; case 92: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_24) { return jrt.Boolean_TRUE.Ref() }; case 93: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_25) { return jrt.Boolean_TRUE.Ref() }; case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_26) { return jrt.Boolean_TRUE.Ref() }; case 96: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_27) { return jrt.Boolean_TRUE.Ref() }; case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_28) { return jrt.Boolean_TRUE.Ref() }; case 125: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_29) { return jrt.Boolean_TRUE.Ref() }; case 126: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_30) { return jrt.Boolean_TRUE.Ref() }; default:}; return jrt.Boolean_FALSE.Ref() } }

func A_arbace_repr_clojure_text_at_A_New() *A_arbace_repr_clojure_text_at_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_at_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_repr_clojure_text_at_A) Ctor() {}
//line :31:1
func (t *A_arbace_repr_clojure_text_at_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var tmp1 bool; var na_41 any = i__1; var na_42 int64 = int64(lang.RT_Count_O__I_NoInit(s__0)); if jrt.Long_InstanceOf(na_41) { var n0_43 int64 = jrt.NN(jrt.Long_Cast(na_41)).LongValue__J(); var n1_44 int64 = na_42; tmp1 = n0_43 < n1_44 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_41, na_42) }; if tmp1 { return jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__1))).Ref() } else { return nil } }

func A_arbace_repr_clojure_text_line_end_A_New() *A_arbace_repr_clojure_text_line_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_line_end_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_repr_clojure_text_line_end_A) Ctor() {}
//line :33:1
func (t *A_arbace_repr_clojure_text_line_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 int32 = jrt.NN(jrt.String_Cast(s__0)).IndexOf_String_I__I(Lit_15, lang.RT_IntCast_O__I_NoInit(i__1)); if
												lang.Numbers_IsNeg_J__Z_NoInit(int64(j__3)) { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(s__0)).Ref() } else { return jrt.Integer_ValueOf_I__Integer_NoInit(j__3).Ref() } }

func A_arbace_repr_clojure_text_token_end_A_New() *A_arbace_repr_clojure_text_token_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_token_end_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_repr_clojure_text_token_end_A) Ctor() {}
//line :36:1
func (t *A_arbace_repr_clojure_text_token_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var j__4 any = i__1; L1: for {



	var tmp1 any; var and__1927000168__auto____5 bool; var na_46 any = j__4; var na_47 int64 = int64(n__3); if jrt.Long_InstanceOf(na_46) { var n0_48 int64 = jrt.NN(jrt.Long_Cast(na_46)).LongValue__J(); var n1_49 int64 = na_47; and__1927000168__auto____5 = n0_48 < n1_49 } else { and__1927000168__auto____5 = lang.Numbers_Lt_O_J__Z_NoInit(na_46, na_47) }; if and__1927000168__auto____5 { var root_51 any = A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any; var root_55 any = A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))).Ref(); if linked_56 == nil { arg_54 = ifn_57.Invoke_O__O(arg_58) } else { arg_54 = linked_56.(*A_arbace_repr_clojure_text_terminating_QMARK__A).Invoke_O_O__O(root_55, arg_58) }; if linked_52 == nil { tmp1 = ifn_53.Invoke_O__O(arg_54) } else { tmp1 = linked_52.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_51, arg_54) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp1) { var tmp2 jrt.Number_I; var na_59 any = j__4; if jrt.Long_InstanceOf(na_59) { var n0_60 int64 = jrt.NN(jrt.Long_Cast(na_59)).LongValue__J(); if n0_60 == 9223372036854775807 { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_59) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_60 + 1)) } } else { if jrt.Double_InstanceOf(na_59) { var n0_60_2 float64 = jrt.NN(jrt.Double_Cast(na_59)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_60_2 + 1.0)) } else { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_59) } }; j__4 = tmp2; continue L1 } else { return j__4 } } }; /*line :36:1*/panic("j2g: unreachable") }





func A_arbace_repr_clojure_text_string_end_A_New() *A_arbace_repr_clojure_text_string_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_string_end_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_repr_clojure_text_string_end_A) Ctor() {}
//line :42:1
func (t *A_arbace_repr_clojure_text_string_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_O_J_O__O(self, s__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1) } else { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var j__4 any
												var na_61 any = i__1


	if jrt.Long_InstanceOf(na_61) { var n0_62 int64 = jrt.NN(jrt.Long_Cast(na_61)).LongValue__J(); if n0_62 == 9223372036854775807 { j__4 = lang.Numbers_Inc_O__Number_NoInit(na_61) } else { j__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_62 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_61) { var n0_62_2 float64 = jrt.NN(jrt.Double_Cast(na_61)).DoubleValue__D(); j__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_62_2 + 1.0).Ref() } else { j__4 = lang.Numbers_Inc_O__Number_NoInit(na_61) } }
//line :42:1
L1: for {




	var tmp1 bool; var na_63 any = j__4; var na_64 int64 = int64(n__3); if jrt.Long_InstanceOf(na_63) { var n0_65 int64 = jrt.NN(jrt.Long_Cast(na_63)).LongValue__J(); var n1_66 int64 = na_64; tmp1 = n0_65 >= n1_66 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_63, na_64) }; if tmp1 { var root_68 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = s__0; var arg_72 any = i__1; var arg_73 any = Lit_25; if linked_69 == nil { return ifn_70.Invoke_O_O_O__O(arg_71, arg_72, arg_73) } else { return linked_69.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_68, arg_71, arg_72, arg_73) } } else { if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_24)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))) {
		var tmp2 jrt.Number_I; var na_76 any = j__4; var na_77 int64 = 2; if jrt.Long_InstanceOf(na_76) { var n0_78 int64 = jrt.NN(jrt.Long_Cast(na_76)).LongValue__J(); var n1_79 int64 = na_77; var nr_80 int64 = n0_78 + n1_79; if (n0_78^nr_80)&(n1_79^nr_80) >= 0 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_80)) } else { tmp2 = lang.Numbers_Add_O_J__Number_NoInit(na_76, na_77) } } else { tmp2 = lang.Numbers_Add_O_J__Number_NoInit(na_76, na_77) }; j__4 = tmp2; continue L1 } else {
//line :47:1
			if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_18)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))) {

				var na_74 any = j__4; if jrt.Long_InstanceOf(na_74) { var n0_75 int64 = jrt.NN(jrt.Long_Cast(na_74)).LongValue__J(); if n0_75 == 9223372036854775807 { return lang.Numbers_Inc_O__Number_NoInit(na_74) } else { return jrt.Long_ValueOf_J__Long_NoInit(n0_75 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_74) { var n0_75_2 float64 = jrt.NN(jrt.Double_Cast(na_74)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_75_2 + 1.0).Ref() } else { return lang.Numbers_Inc_O__Number_NoInit(na_74) } } } else {
//line :47:1
					if A_arbace_repr_clojure_text_A_const_34 != nil {


						var tmp3 jrt.Number_I; var na_81 any = j__4; if jrt.Long_InstanceOf(na_81) { var n0_82 int64 = jrt.NN(jrt.Long_Cast(na_81)).LongValue__J(); if n0_82 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_81) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_82 + 1)) } } else { if jrt.Double_InstanceOf(na_81) { var n0_82_2 float64 = jrt.NN(jrt.Double_Cast(na_81)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_82_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_81) } }; j__4 = tmp3; continue L1 } else {
//line :47:1
							return nil } } } } } }; /*line :42:1*/panic("j2g: unreachable") }
//line :42:1
func (t *A_arbace_repr_clojure_text_string_end_A) InvokeSpec_O_O_J_O__O(self, s__0 any, i__1_l int64, i__1_b any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var j__4 any
															var n0_83 int64 = i__1_l


	if n0_83 == 9223372036854775807 { var tmp1 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp1 = i__1_b } else { tmp1 = i__1_b }; j__4 = lang.Numbers_Inc_O__Number_NoInit(tmp1) } else { j__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_83 + 1).Ref() }
//line :42:1
L1: for {




	var tmp2 bool; var na_84 any = j__4; var na_85 int64 = int64(n__3); if jrt.Long_InstanceOf(na_84) { var n0_86 int64 = jrt.NN(jrt.Long_Cast(na_84)).LongValue__J(); var n1_87 int64 = na_85; tmp2 = n0_86 >= n1_87 } else { tmp2 = lang.Numbers_Gte_O_J__Z_NoInit(na_84, na_85) }; if tmp2 { var root_89 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = s__0; var arg_93 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_93 = i__1_b } else { arg_93 = i__1_b }; var arg_94 any = Lit_25; if linked_90 == nil { return ifn_91.Invoke_O_O_O__O(arg_92, arg_93, arg_94) } else { return linked_90.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_89, arg_92, arg_93, arg_94) } } else { if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_24)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))) {
		var tmp3 jrt.Number_I; var na_97 any = j__4; var na_98 int64 = 2; if jrt.Long_InstanceOf(na_97) { var n0_99 int64 = jrt.NN(jrt.Long_Cast(na_97)).LongValue__J(); var n1_100 int64 = na_98; var nr_101 int64 = n0_99 + n1_100; if (n0_99^nr_101)&(n1_100^nr_101) >= 0 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_101)) } else { tmp3 = lang.Numbers_Add_O_J__Number_NoInit(na_97, na_98) } } else { tmp3 = lang.Numbers_Add_O_J__Number_NoInit(na_97, na_98) }; j__4 = tmp3; continue L1 } else {
//line :47:1
			if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_18)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))) {

				var na_95 any = j__4; if jrt.Long_InstanceOf(na_95) { var n0_96 int64 = jrt.NN(jrt.Long_Cast(na_95)).LongValue__J(); if n0_96 == 9223372036854775807 { return lang.Numbers_Inc_O__Number_NoInit(na_95) } else { return jrt.Long_ValueOf_J__Long_NoInit(n0_96 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_95) { var n0_96_2 float64 = jrt.NN(jrt.Double_Cast(na_95)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_96_2 + 1.0).Ref() } else { return lang.Numbers_Inc_O__Number_NoInit(na_95) } } } else {
//line :47:1
					if A_arbace_repr_clojure_text_A_const_34 != nil {


						var tmp4 jrt.Number_I; var na_102 any = j__4; if jrt.Long_InstanceOf(na_102) { var n0_103 int64 = jrt.NN(jrt.Long_Cast(na_102)).LongValue__J(); if n0_103 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_102) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_103 + 1)) } } else { if jrt.Double_InstanceOf(na_102) { var n0_103_2 float64 = jrt.NN(jrt.Double_Cast(na_102)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_103_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_102) } }; j__4 = tmp4; continue L1 } else {
//line :47:1
							return nil } } } } } }; /*line :42:1*/panic("j2g: unreachable") }









func A_arbace_repr_clojure_text_char_end_A_New() *A_arbace_repr_clojure_text_char_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_char_end_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_repr_clojure_text_char_end_A) Ctor() {}
//line :52:1
func (t *A_arbace_repr_clojure_text_char_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_O_J_O__O(self, s__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1) } else {



	var tmp1 bool; var na_114 any; var na_116 any = i__1; if jrt.Long_InstanceOf(na_116) { var n0_117 int64 = jrt.NN(jrt.Long_Cast(na_116)).LongValue__J(); if n0_117 == 9223372036854775807 { na_114 = lang.Numbers_Inc_O__Number_NoInit(na_116) } else { na_114 = jrt.Long_ValueOf_J__Long_NoInit(n0_117 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_116) { var n0_117_2 float64 = jrt.NN(jrt.Double_Cast(na_116)).DoubleValue__D(); na_114 = jrt.Double_ValueOf_D__Double_NoInit(n0_117_2 + 1.0).Ref() } else { na_114 = lang.Numbers_Inc_O__Number_NoInit(na_116) } }; var na_115 int64 = int64(lang.RT_Count_O__I_NoInit(s__0)); if jrt.Long_InstanceOf(na_114) { var n0_118 int64 = jrt.NN(jrt.Long_Cast(na_114)).LongValue__J(); var n1_119 int64 = na_115; tmp1 = n0_118 >= n1_119 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_114, na_115) }; if tmp1 { var root_121 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = s__0; var arg_125 any = i__1; var arg_126 any = Lit_4; if linked_122 == nil { ifn_123.Invoke_O_O_O__O(arg_124, arg_125, arg_126) } else { linked_122.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_121, arg_124, arg_125, arg_126) } }
	var root_104 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = s__0; var arg_108 any; var na_109 any = i__1; var na_110 int64 = 2; if jrt.Long_InstanceOf(na_109) { var n0_111 int64 = jrt.NN(jrt.Long_Cast(na_109)).LongValue__J(); var n1_112 int64 = na_110; var nr_113 int64 = n0_111 + n1_112; if (n0_111^nr_113)&(n1_112^nr_113) >= 0 { arg_108 = jrt.Long_ValueOf_J__Long_NoInit(nr_113).Ref() } else { arg_108 = lang.Numbers_Add_O_J__Number_NoInit(na_109, na_110) } } else { arg_108 = lang.Numbers_Add_O_J__Number_NoInit(na_109, na_110) }; if linked_105 == nil { return ifn_106.Invoke_O_O__O(arg_107, arg_108) } else { return linked_105.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_104, arg_107, arg_108) } } }
//line :52:1
func (t *A_arbace_repr_clojure_text_char_end_A) InvokeSpec_O_O_J_O__O(self, s__0 any, i__1_l int64, i__1_b any) any {



	var tmp1 bool; var na_136 any; var n0_138 int64 = i__1_l; if n0_138 == 9223372036854775807 { var tmp2 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp2 = i__1_b } else { tmp2 = i__1_b }; na_136 = lang.Numbers_Inc_O__Number_NoInit(tmp2) } else { na_136 = jrt.Long_ValueOf_J__Long_NoInit(n0_138 + 1).Ref() }; var na_137 int64 = int64(lang.RT_Count_O__I_NoInit(s__0)); if jrt.Long_InstanceOf(na_136) { var n0_139 int64 = jrt.NN(jrt.Long_Cast(na_136)).LongValue__J(); var n1_140 int64 = na_137; tmp1 = n0_139 >= n1_140 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_136, na_137) }; if tmp1 { var root_142 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = s__0; var arg_146 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_146 = i__1_b } else { arg_146 = i__1_b }; var arg_147 any = Lit_4; if linked_143 == nil { ifn_144.Invoke_O_O_O__O(arg_145, arg_146, arg_147) } else { linked_143.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_142, arg_145, arg_146, arg_147) } }
	var root_127 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = s__0; var arg_131 any; var na_132 int64 = 2; var n0_133 int64 = i__1_l; var n1_134 int64 = na_132; var nr_135 int64 = n0_133 + n1_134; if (n0_133^nr_135)&(n1_134^nr_135) >= 0 { arg_131 = jrt.Long_ValueOf_J__Long_NoInit(nr_135).Ref() } else { var tmp3 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp3 = i__1_b } else { tmp3 = i__1_b }; arg_131 = lang.Numbers_Add_O_J__Number_NoInit(tmp3, na_132) }; if linked_128 == nil { return ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { return linked_128.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_127, arg_130, arg_131)
	}
}

func A_arbace_repr_clojure_text_skip_ws_A_New() *A_arbace_repr_clojure_text_skip_ws_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_skip_ws_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_repr_clojure_text_skip_ws_A) Ctor() {}
//line :61:1
func (t *A_arbace_repr_clojure_text_skip_ws_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var i__4 any = i__1; L1: for {





	var tmp1 bool; var na_148 any = i__4; var na_149 int64 = int64(n__3); if jrt.Long_InstanceOf(na_148) { var n0_150 int64 = jrt.NN(jrt.Long_Cast(na_148)).LongValue__J(); var n1_151 int64 = na_149; tmp1 = n0_150 >= n1_151 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_148, na_149) }; if tmp1 { return i__4 } else { var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__4)); var tmp2 any; var root_153 any = A_arbace_repr_clojure_text_A_const_17.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, A_arbace_repr_clojure_text_ws_QMARK__A_fn_class); var ifn_155 lang.IFn


		if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = jrt.Character_ValueOf_C__Character_NoInit(c__5).Ref(); if linked_154 == nil { tmp2 = ifn_155.Invoke_O__O(arg_156) } else { tmp2 = linked_154.(*A_arbace_repr_clojure_text_ws_QMARK__A).Invoke_O_O__O(root_153, arg_156) }; if jrt.J2g_Truth(tmp2) { var tmp3 jrt.Number_I; var na_171 any = i__4; if jrt.Long_InstanceOf(na_171) { var n0_172 int64 = jrt.NN(jrt.Long_Cast(na_171)).LongValue__J(); if n0_172 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_171) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_172 + 1)) } } else { if jrt.Double_InstanceOf(na_171) { var n0_172_2 float64 = jrt.NN(jrt.Double_Cast(na_171)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_172_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_171) } }; i__4 = tmp3; continue L1 } else { if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_21)).CharValue__C()) {
			var tmp4 any; var root_173 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = s__0; var arg_177 any = i__4; if linked_174 == nil { tmp4 = ifn_175.Invoke_O_O__O(arg_176, arg_177) } else { tmp4 = linked_174.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_173, arg_176, arg_177) }; i__4 = tmp4; continue L1 } else {
//line :70:1
				var tmp5 bool; var and__1927000168__auto____6 bool = lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())

				if and__1927000168__auto____6 { var tmp6 any = A_arbace_repr_clojure_text_A_const_37; var tmp7 any; var root_157 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = s__0; var arg_161 any; var na_162 any = i__4; if jrt.Long_InstanceOf(na_162) { var n0_163 int64 = jrt.NN(jrt.Long_Cast(na_162)).LongValue__J(); if n0_163 == 9223372036854775807 { arg_161 = lang.Numbers_Inc_O__Number_NoInit(na_162) } else { arg_161 = jrt.Long_ValueOf_J__Long_NoInit(n0_163 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_162) { var n0_163_2 float64 = jrt.NN(jrt.Double_Cast(na_162)).DoubleValue__D(); arg_161 = jrt.Double_ValueOf_D__Double_NoInit(n0_163_2 + 1.0).Ref() } else { arg_161 = lang.Numbers_Inc_O__Number_NoInit(na_162) } }; if linked_158 == nil { tmp7 = ifn_159.Invoke_O_O__O(arg_160, arg_161) } else { tmp7 = linked_158.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_157, arg_160, arg_161) }; tmp5 = lang.Util_Equiv_O_O__Z_NoInit(tmp6, tmp7) } else { tmp5 = and__1927000168__auto____6 }
//line :70:1
				if tmp5 {

					var tmp8 any; var root_178 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = s__0; var arg_182 any = i__4; if linked_179 == nil { tmp8 = ifn_180.Invoke_O_O__O(arg_181, arg_182) } else { tmp8 = linked_179.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_178, arg_181, arg_182) }; i__4 = tmp8; continue L1 } else {
//line :70:1
						var tmp9 bool; var and__1927000168__auto____6_2 bool = lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())


						if and__1927000168__auto____6_2 { var tmp10 any = A_arbace_repr_clojure_text_A_const_39; var tmp11 any; var root_164 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = s__0; var arg_168 any; var na_169 any = i__4; if jrt.Long_InstanceOf(na_169) { var n0_170 int64 = jrt.NN(jrt.Long_Cast(na_169)).LongValue__J(); if n0_170 == 9223372036854775807 { arg_168 = lang.Numbers_Inc_O__Number_NoInit(na_169) } else { arg_168 = jrt.Long_ValueOf_J__Long_NoInit(n0_170 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_169) { var n0_170_2 float64 = jrt.NN(jrt.Double_Cast(na_169)).DoubleValue__D(); arg_168 = jrt.Double_ValueOf_D__Double_NoInit(n0_170_2 + 1.0).Ref() } else { arg_168 = lang.Numbers_Inc_O__Number_NoInit(na_169) } }; if linked_165 == nil { tmp11 = ifn_166.Invoke_O_O__O(arg_167, arg_168) } else { tmp11 = linked_165.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_164, arg_167, arg_168) }; tmp9 = lang.Util_Equiv_O_O__Z_NoInit(tmp10, tmp11) } else { tmp9 = and__1927000168__auto____6_2 }
//line :70:1
						if tmp9 {


							var tmp12 any; var root_183 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_183, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = s__0; var arg_187 any; var root_188 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = s__0; var arg_192 any; var na_193 any = i__4; var na_194 int64 = 2; if jrt.Long_InstanceOf(na_193) { var n0_195 int64 = jrt.NN(jrt.Long_Cast(na_193)).LongValue__J(); var n1_196 int64 = na_194; var nr_197 int64 = n0_195 + n1_196; if (n0_195^nr_197)&(n1_196^nr_197) >= 0 { arg_192 = jrt.Long_ValueOf_J__Long_NoInit(nr_197).Ref() } else { arg_192 = lang.Numbers_Add_O_J__Number_NoInit(na_193, na_194) } } else { arg_192 = lang.Numbers_Add_O_J__Number_NoInit(na_193, na_194) }; if linked_189 == nil { arg_187 = ifn_190.Invoke_O_O__O(arg_191, arg_192) } else { arg_187 = linked_189.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_188, arg_191, arg_192) }; if linked_184 == nil { tmp12 = ifn_185.Invoke_O_O__O(arg_186, arg_187) } else { if jrt.Long_InstanceOf(arg_187) { tmp12 = linked_184.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_183, arg_186, jrt.NN(jrt.Long_Cast(arg_187)).LongValue__J(), arg_187) } else { tmp12 = linked_184.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_183, arg_186, arg_187) } }; i__4 = tmp12; continue L1 } else {
//line :70:1
								if A_arbace_repr_clojure_text_A_const_34 != nil { return i__4 } else { return nil } } } } } } } }; /*line :61:1*/panic("j2g: unreachable") }
















func A_arbace_repr_clojure_text_coll_end_A_New() *A_arbace_repr_clojure_text_coll_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_coll_end_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_repr_clojure_text_coll_end_A) Ctor() {}
//line :78:1
func (t *A_arbace_repr_clojure_text_coll_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_O_J_O__O(self, s__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1) } else { var close__3 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_43.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__1))).Ref()); var j__4 any; var root_198 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_200 lang.IFn



	if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = s__0; var arg_202 any; var na_203 any = i__1; if jrt.Long_InstanceOf(na_203) { var n0_204 int64 = jrt.NN(jrt.Long_Cast(na_203)).LongValue__J(); if n0_204 == 9223372036854775807 { arg_202 = lang.Numbers_Inc_O__Number_NoInit(na_203) } else { arg_202 = jrt.Long_ValueOf_J__Long_NoInit(n0_204 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_203) { var n0_204_2 float64 = jrt.NN(jrt.Double_Cast(na_203)).DoubleValue__D(); arg_202 = jrt.Double_ValueOf_D__Double_NoInit(n0_204_2 + 1.0).Ref() } else { arg_202 = lang.Numbers_Inc_O__Number_NoInit(na_203) } }; if linked_199 == nil { j__4 = ifn_200.Invoke_O_O__O(arg_201, arg_202) } else { j__4 = linked_199.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_198, arg_201, arg_202) }
//line :78:1
L1: for { var c__5 any; var root_205 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_207 lang.IFn




	if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = s__0; var arg_209 any = j__4; if linked_206 == nil { c__5 = ifn_207.Invoke_O_O__O(arg_208, arg_209) } else { c__5 = linked_206.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_205, arg_208, arg_209) }
	if lang.Util_Identical_O_O__Z_NoInit(c__5, nil) { var root_210 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = s__0; var arg_214 any = i__1; var arg_215 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, close__3)).Ref(); if linked_211 == nil { return ifn_212.Invoke_O_O_O__O(arg_213, arg_214, arg_215) } else { return linked_211.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_210, arg_213, arg_214, arg_215) } } else { if lang.Util_Equiv_O_O__Z_NoInit(c__5, close__3) {
		var na_216 any = j__4; if jrt.Long_InstanceOf(na_216) { var n0_217 int64 = jrt.NN(jrt.Long_Cast(na_216)).LongValue__J(); if n0_217 == 9223372036854775807 { return lang.Numbers_Inc_O__Number_NoInit(na_216) } else { return jrt.Long_ValueOf_J__Long_NoInit(n0_217 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_216) { var n0_217_2 float64 = jrt.NN(jrt.Double_Cast(na_216)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_217_2 + 1.0).Ref() } else { return lang.Numbers_Inc_O__Number_NoInit(na_216) } } } else {
//line :84:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_44).Invoke_O__O(c__5)) {

				var root_218 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = s__0; var arg_222 any = j__4; var arg_223 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__5)).Ref(); if linked_219 == nil { return ifn_220.Invoke_O_O_O__O(arg_221, arg_222, arg_223) } else { return linked_219.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_218, arg_221, arg_222, arg_223) } } else {
//line :84:1
					if A_arbace_repr_clojure_text_A_const_34 != nil {


						var tmp1 any; var root_224 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = s__0; var arg_228 any; var root_229 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_229, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = s__0; var arg_233 any = j__4; if linked_230 == nil { arg_228 = ifn_231.Invoke_O_O__O(arg_232, arg_233) } else { if jrt.Long_InstanceOf(arg_233) { arg_228 = linked_230.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_229, arg_232, jrt.NN(jrt.Long_Cast(arg_233)).LongValue__J(), arg_233) } else { arg_228 = linked_230.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_229, arg_232, arg_233) } }; if linked_225 == nil { tmp1 = ifn_226.Invoke_O_O__O(arg_227, arg_228) } else { tmp1 = linked_225.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_224, arg_227, arg_228) }; j__4 = tmp1; continue L1 } else {
//line :84:1
							return nil } } } } } }; /*line :78:1*/panic("j2g: unreachable") }
//line :78:1
func (t *A_arbace_repr_clojure_text_coll_end_A) InvokeSpec_O_O_J_O__O(self, s__0 any, i__1_l int64, i__1_b any) any { { var close__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_43.GetRawRoot__O()); var tmp2 *jrt.String = jrt.String_Cast(s__0); var tmp3 any


	if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp3 = i__1_b } else { tmp3 = i__1_b }; close__3 = tmp1.Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(tmp3))).Ref())
//line :78:1
	var j__4 any; var root_234 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_236 lang.IFn



	if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = s__0; var arg_238 any; var n0_239 int64 = i__1_l; if n0_239 == 9223372036854775807 { var tmp4 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp4 = i__1_b } else { tmp4 = i__1_b }; arg_238 = lang.Numbers_Inc_O__Number_NoInit(tmp4) } else { arg_238 = jrt.Long_ValueOf_J__Long_NoInit(n0_239 + 1).Ref() }; if linked_235 == nil { j__4 = ifn_236.Invoke_O_O__O(arg_237, arg_238) } else { j__4 = linked_235.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_234, arg_237, arg_238) }
//line :78:1
L1: for { var c__5 any; var root_240 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_242 lang.IFn




	if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = s__0; var arg_244 any = j__4; if linked_241 == nil { c__5 = ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { c__5 = linked_241.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_240, arg_243, arg_244) }
	if lang.Util_Identical_O_O__Z_NoInit(c__5, nil) { var root_245 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = s__0; var arg_249 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_249 = i__1_b } else { arg_249 = i__1_b }; var arg_250 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, close__3)).Ref(); if linked_246 == nil { return ifn_247.Invoke_O_O_O__O(arg_248, arg_249, arg_250) } else { return linked_246.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_245, arg_248, arg_249, arg_250) } } else { if lang.Util_Equiv_O_O__Z_NoInit(c__5, close__3) {
		var na_251 any = j__4; if jrt.Long_InstanceOf(na_251) { var n0_252 int64 = jrt.NN(jrt.Long_Cast(na_251)).LongValue__J(); if n0_252 == 9223372036854775807 { return lang.Numbers_Inc_O__Number_NoInit(na_251) } else { return jrt.Long_ValueOf_J__Long_NoInit(n0_252 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_251) { var n0_252_2 float64 = jrt.NN(jrt.Double_Cast(na_251)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_252_2 + 1.0).Ref() } else { return lang.Numbers_Inc_O__Number_NoInit(na_251) } } } else {
//line :84:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_44).Invoke_O__O(c__5)) {

				var root_253 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = s__0; var arg_257 any = j__4; var arg_258 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__5)).Ref(); if linked_254 == nil { return ifn_255.Invoke_O_O_O__O(arg_256, arg_257, arg_258) } else { return linked_254.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_253, arg_256, arg_257, arg_258) } } else {
//line :84:1
					if A_arbace_repr_clojure_text_A_const_34 != nil {


						var tmp5 any; var root_259 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = s__0; var arg_263 any; var root_264 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_264, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = s__0; var arg_268 any = j__4; if linked_265 == nil { arg_263 = ifn_266.Invoke_O_O__O(arg_267, arg_268) } else { if jrt.Long_InstanceOf(arg_268) { arg_263 = linked_265.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_264, arg_267, jrt.NN(jrt.Long_Cast(arg_268)).LongValue__J(), arg_268) } else { arg_263 = linked_265.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_264, arg_267, arg_268) } }; if linked_260 == nil { tmp5 = ifn_261.Invoke_O_O__O(arg_262, arg_263) } else { tmp5 = linked_260.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_259, arg_262, arg_263) }; j__4 = tmp5; continue L1 } else {
//line :84:1
							return nil } } } } } }; /*line :78:1*/panic("j2g: unreachable") }










func A_arbace_repr_clojure_text_next_form_end_A_New() *A_arbace_repr_clojure_text_next_form_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_next_form_end_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_repr_clojure_text_next_form_end_A) Ctor() {}
//line :89:1
func (t *A_arbace_repr_clojure_text_next_form_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 any; var root_269 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_271 lang.IFn; if
												linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = s__0; var arg_273 any = i__1; if linked_270 == nil { j__3 = ifn_271.Invoke_O_O__O(arg_272, arg_273) } else { j__3 = linked_270.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_269, arg_272, arg_273) }; var tmp1 bool; var na_279 any = j__3; var na_280 int64 =
												int64(lang.RT_Count_O__I_NoInit(s__0)); if jrt.Long_InstanceOf(na_279) { var n0_281 int64 = jrt.NN(jrt.Long_Cast(na_279)).LongValue__J(); var n1_282 int64 = na_280; tmp1 = n0_281 >= n1_282 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_279, na_280) }; if tmp1 { var root_284 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_286 lang.IFn; if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = s__0; var arg_288 any = i__1; var arg_289 any = Lit_12; if linked_285 == nil { ifn_286.Invoke_O_O_O__O(arg_287, arg_288, arg_289) } else { linked_285.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_284, arg_287, arg_288, arg_289) } }; var root_274 any =
												A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_274, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_276 lang.IFn; if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = s__0; var arg_278 any = j__3; if linked_275 == nil { return ifn_276.Invoke_O_O__O(arg_277, arg_278) } else { if jrt.Long_InstanceOf(arg_278) { return linked_275.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_274, arg_277, jrt.NN(jrt.Long_Cast(arg_278)).LongValue__J(), arg_278) } else { return linked_275.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_274, arg_277, arg_278) } } }

func A_arbace_repr_clojure_text_form_end_A_New() *A_arbace_repr_clojure_text_form_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_form_end_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_repr_clojure_text_form_end_A) Ctor() {}
//line :94:1
func (t *A_arbace_repr_clojure_text_form_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_O_J_O__O(self, s__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1) } else { var c__3 any; var root_290 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_292 lang.IFn


	if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = s__0; var arg_294 any = i__1; if linked_291 == nil { c__3 = ifn_292.Invoke_O_O__O(arg_293, arg_294) } else { c__3 = linked_291.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_290, arg_293, arg_294) }
//line :94:1
	var G__670000027__4_ any = c__3



	switch lang.Util_Hash_O__I_NoInit(G__670000027__4_) { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, nil) {
		var root_296 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = s__0; var arg_300 any = i__1; var arg_301 any = Lit_12; if linked_297 == nil { return ifn_298.Invoke_O_O_O__O(arg_299, arg_300, arg_301) } else { return linked_297.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_296, arg_299, arg_300, arg_301) } }
//line :98:1
	case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_18) {


		var root_302 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_302, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = s__0; var arg_306 any = i__1; if linked_303 == nil { return ifn_304.Invoke_O_O__O(arg_305, arg_306) } else { if jrt.Long_InstanceOf(arg_306) { return linked_303.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_302, arg_305, jrt.NN(jrt.Long_Cast(arg_306)).LongValue__J(), arg_306) } else { return linked_303.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_302, arg_305, arg_306) } } }
//line :98:1
	case 35: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_36) { var d__5 any; var root_307 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_309 lang.IFn








		if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any = s__0; var arg_311 any; var na_312 any = i__1; if jrt.Long_InstanceOf(na_312) { var n0_313 int64 = jrt.NN(jrt.Long_Cast(na_312)).LongValue__J(); if n0_313 == 9223372036854775807 { arg_311 = lang.Numbers_Inc_O__Number_NoInit(na_312) } else { arg_311 = jrt.Long_ValueOf_J__Long_NoInit(n0_313 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_312) { var n0_313_2 float64 = jrt.NN(jrt.Double_Cast(na_312)).DoubleValue__D(); arg_311 = jrt.Double_ValueOf_D__Double_NoInit(n0_313_2 + 1.0).Ref() } else { arg_311 = lang.Numbers_Inc_O__Number_NoInit(na_312) } }; if linked_308 == nil { d__5 = ifn_309.Invoke_O_O__O(arg_310, arg_311) } else { d__5 = linked_308.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_307, arg_310, arg_311) }
//line :98:1
		var G__670000028__6_ any = d__5









		switch lang.Util_Hash_O__I_NoInit(G__670000028__6_) { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, nil) {
			var root_315 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = s__0; var arg_319 any = i__1; var arg_320 any = Lit_13; if linked_316 == nil { return ifn_317.Invoke_O_O_O__O(arg_318, arg_319, arg_320) } else { return linked_316.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_315, arg_318, arg_319, arg_320) } }
//line :108:1
		case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_37) {






			var root_321 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = s__0; var arg_325 any; var root_326 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = s__0; var arg_330 any = i__1; if linked_327 == nil { arg_325 = ifn_328.Invoke_O_O__O(arg_329, arg_330) } else { arg_325 = linked_327.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_326, arg_329, arg_330) }; if linked_322 == nil { return ifn_323.Invoke_O_O__O(arg_324, arg_325) } else { return linked_322.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_321, arg_324, arg_325) } }
//line :108:1
		case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_18) {


			var root_331 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_331, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = s__0; var arg_335 any; var na_336 any = i__1; if jrt.Long_InstanceOf(na_336) { var n0_337 int64 = jrt.NN(jrt.Long_Cast(na_336)).LongValue__J(); if n0_337 == 9223372036854775807 { arg_335 = lang.Numbers_Inc_O__Number_NoInit(na_336) } else { arg_335 = jrt.Long_ValueOf_J__Long_NoInit(n0_337 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_336) { var n0_337_2 float64 = jrt.NN(jrt.Double_Cast(na_336)).DoubleValue__D(); arg_335 = jrt.Double_ValueOf_D__Double_NoInit(n0_337_2 + 1.0).Ref() } else { arg_335 = lang.Numbers_Inc_O__Number_NoInit(na_336) } }; if linked_332 == nil { return ifn_333.Invoke_O_O__O(arg_334, arg_335) } else { if jrt.Long_InstanceOf(arg_335) { return linked_332.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_331, arg_334, jrt.NN(jrt.Long_Cast(arg_335)).LongValue__J(), arg_335) } else { return linked_332.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_331, arg_334, arg_335) } } }
//line :108:1
		case 35: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_36) {








			var root_338 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = s__0; var arg_342 any; var na_343 any = i__1; var na_344 int64 = 2; if jrt.Long_InstanceOf(na_343) { var n0_345 int64 = jrt.NN(jrt.Long_Cast(na_343)).LongValue__J(); var n1_346 int64 = na_344; var nr_347 int64 = n0_345 + n1_346; if (n0_345^nr_347)&(n1_346^nr_347) >= 0 { arg_342 = jrt.Long_ValueOf_J__Long_NoInit(nr_347).Ref() } else { arg_342 = lang.Numbers_Add_O_J__Number_NoInit(na_343, na_344) } } else { arg_342 = lang.Numbers_Add_O_J__Number_NoInit(na_343, na_344) }; if linked_339 == nil { return ifn_340.Invoke_O_O__O(arg_341, arg_342) } else { return linked_339.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_338, arg_341, arg_342) } }
//line :108:1
		case 39: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_47) {



			var root_372 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = s__0; var arg_376 any; var na_377 any = i__1; var na_378 int64 = 2; if jrt.Long_InstanceOf(na_377) { var n0_379 int64 = jrt.NN(jrt.Long_Cast(na_377)).LongValue__J(); var n1_380 int64 = na_378; var nr_381 int64 = n0_379 + n1_380; if (n0_379^nr_381)&(n1_380^nr_381) >= 0 { arg_376 = jrt.Long_ValueOf_J__Long_NoInit(nr_381).Ref() } else { arg_376 = lang.Numbers_Add_O_J__Number_NoInit(na_377, na_378) } } else { arg_376 = lang.Numbers_Add_O_J__Number_NoInit(na_377, na_378) }; if linked_373 == nil { return ifn_374.Invoke_O_O__O(arg_375, arg_376) } else { return linked_373.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_372, arg_375, arg_376) } }
//line :108:1
		case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_19) {

			var root_382 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_382, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = s__0; var arg_386 any; var na_387 any = i__1; if jrt.Long_InstanceOf(na_387) { var n0_388 int64 = jrt.NN(jrt.Long_Cast(na_387)).LongValue__J(); if n0_388 == 9223372036854775807 { arg_386 = lang.Numbers_Inc_O__Number_NoInit(na_387) } else { arg_386 = jrt.Long_ValueOf_J__Long_NoInit(n0_388 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_387) { var n0_388_2 float64 = jrt.NN(jrt.Double_Cast(na_387)).DoubleValue__D(); arg_386 = jrt.Double_ValueOf_D__Double_NoInit(n0_388_2 + 1.0).Ref() } else { arg_386 = lang.Numbers_Inc_O__Number_NoInit(na_387) } }; if linked_383 == nil { return ifn_384.Invoke_O_O__O(arg_385, arg_386) } else { if jrt.Long_InstanceOf(arg_386) { return linked_383.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_382, arg_385, jrt.NN(jrt.Long_Cast(arg_386)).LongValue__J(), arg_386) } else { return linked_383.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_382, arg_385, arg_386) } } }
//line :108:1
		case 58: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_49) { var j__7 any; var root_389 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_391 lang.IFn









			if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = s__0; var arg_393 any; var root_394 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = s__0; var arg_398 any; var na_399 any = i__1; if jrt.Long_InstanceOf(na_399) { var n0_400 int64 = jrt.NN(jrt.Long_Cast(na_399)).LongValue__J(); if n0_400 == 9223372036854775807 { arg_398 = lang.Numbers_Inc_O__Number_NoInit(na_399) } else { arg_398 = jrt.Long_ValueOf_J__Long_NoInit(n0_400 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_399) { var n0_400_2 float64 = jrt.NN(jrt.Double_Cast(na_399)).DoubleValue__D(); arg_398 = jrt.Double_ValueOf_D__Double_NoInit(n0_400_2 + 1.0).Ref() } else { arg_398 = lang.Numbers_Inc_O__Number_NoInit(na_399) } }; if linked_395 == nil { arg_393 = ifn_396.Invoke_O_O__O(arg_397, arg_398) } else { arg_393 = linked_395.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_394, arg_397, arg_398) }; if linked_390 == nil { j__7 = ifn_391.Invoke_O_O__O(arg_392, arg_393) } else { j__7 = linked_390.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_389, arg_392, arg_393) }
			var tmp1 any = A_arbace_repr_clojure_text_A_const_28; var tmp2 any; var root_416 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = s__0; var arg_420 any = j__7; if linked_417 == nil { tmp2 = ifn_418.Invoke_O_O__O(arg_419, arg_420) } else { tmp2 = linked_417.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_416, arg_419, arg_420) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { } else { var root_421 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = s__0; var arg_425 any = i__1; var arg_426 any = Lit_14; if linked_422 == nil { ifn_423.Invoke_O_O_O__O(arg_424, arg_425, arg_426) } else { linked_422.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_421, arg_424, arg_425, arg_426) } }
			var root_401 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_401, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = s__0; var arg_405 any = j__7; if linked_402 == nil { return ifn_403.Invoke_O_O__O(arg_404, arg_405) } else { if jrt.Long_InstanceOf(arg_405) { return linked_402.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_401, arg_404, jrt.NN(jrt.Long_Cast(arg_405)).LongValue__J(), arg_405) } else { return linked_402.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_401, arg_404, arg_405) } } }
//line :108:1
		case 61: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_50) {



			var root_406 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = s__0; var arg_410 any; var na_411 any = i__1; var na_412 int64 = 2; if jrt.Long_InstanceOf(na_411) { var n0_413 int64 = jrt.NN(jrt.Long_Cast(na_411)).LongValue__J(); var n1_414 int64 = na_412; var nr_415 int64 = n0_413 + n1_414; if (n0_413^nr_415)&(n1_414^nr_415) >= 0 { arg_410 = jrt.Long_ValueOf_J__Long_NoInit(nr_415).Ref() } else { arg_410 = lang.Numbers_Add_O_J__Number_NoInit(na_411, na_412) } } else { arg_410 = lang.Numbers_Add_O_J__Number_NoInit(na_411, na_412) }; if linked_407 == nil { return ifn_408.Invoke_O_O__O(arg_409, arg_410) } else { return linked_407.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_406, arg_409, arg_410) } }
//line :108:1
		case 63: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_51) {







			var root_427 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_427, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = s__0; var arg_431 any; var root_432 any = A_arbace_repr_clojure_text_A_const_52.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, A_arbace_repr_clojure_text_cond_open_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = s__0; var arg_436 any = i__1; if linked_433 == nil { arg_431 = ifn_434.Invoke_O_O__O(arg_435, arg_436) } else { arg_431 = linked_433.(*A_arbace_repr_clojure_text_cond_open_A).Invoke_O_O_O__O(root_432, arg_435, arg_436) }; if linked_428 == nil { return ifn_429.Invoke_O_O__O(arg_430, arg_431) } else { if jrt.Long_InstanceOf(arg_431) { return linked_428.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_427, arg_430, jrt.NN(jrt.Long_Cast(arg_431)).LongValue__J(), arg_431) } else { return linked_428.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_427, arg_430, arg_431) } } }
//line :108:1
		case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_26) {




			var root_437 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = s__0; var arg_441 any; var root_442 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = s__0; var arg_446 any; var na_447 any = i__1; var na_448 int64 = 2; if jrt.Long_InstanceOf(na_447) { var n0_449 int64 = jrt.NN(jrt.Long_Cast(na_447)).LongValue__J(); var n1_450 int64 = na_448; var nr_451 int64 = n0_449 + n1_450; if (n0_449^nr_451)&(n1_450^nr_451) >= 0 { arg_446 = jrt.Long_ValueOf_J__Long_NoInit(nr_451).Ref() } else { arg_446 = lang.Numbers_Add_O_J__Number_NoInit(na_447, na_448) } } else { arg_446 = lang.Numbers_Add_O_J__Number_NoInit(na_447, na_448) }; if linked_443 == nil { arg_441 = ifn_444.Invoke_O_O__O(arg_445, arg_446) } else { arg_441 = linked_443.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_442, arg_445, arg_446) }; if linked_438 == nil { return ifn_439.Invoke_O_O__O(arg_440, arg_441) } else { return linked_438.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_437, arg_440, arg_441) } }
//line :108:1
		case 95: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_39) {





			var root_452 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = s__0; var arg_456 any; var root_457 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = s__0; var arg_461 any; var na_462 any = i__1; var na_463 int64 = 2; if jrt.Long_InstanceOf(na_462) { var n0_464 int64 = jrt.NN(jrt.Long_Cast(na_462)).LongValue__J(); var n1_465 int64 = na_463; var nr_466 int64 = n0_464 + n1_465; if (n0_464^nr_466)&(n1_465^nr_466) >= 0 { arg_461 = jrt.Long_ValueOf_J__Long_NoInit(nr_466).Ref() } else { arg_461 = lang.Numbers_Add_O_J__Number_NoInit(na_462, na_463) } } else { arg_461 = lang.Numbers_Add_O_J__Number_NoInit(na_462, na_463) }; if linked_458 == nil { arg_456 = ifn_459.Invoke_O_O__O(arg_460, arg_461) } else { arg_456 = linked_458.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_457, arg_460, arg_461) }; if linked_453 == nil { return ifn_454.Invoke_O_O__O(arg_455, arg_456) } else { return linked_453.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_452, arg_455, arg_456) } }
//line :108:1
		case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_28) {

			var root_467 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_467, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = s__0; var arg_471 any; var na_472 any = i__1; if jrt.Long_InstanceOf(na_472) { var n0_473 int64 = jrt.NN(jrt.Long_Cast(na_472)).LongValue__J(); if n0_473 == 9223372036854775807 { arg_471 = lang.Numbers_Inc_O__Number_NoInit(na_472) } else { arg_471 = jrt.Long_ValueOf_J__Long_NoInit(n0_473 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_472) { var n0_473_2 float64 = jrt.NN(jrt.Double_Cast(na_472)).DoubleValue__D(); arg_471 = jrt.Double_ValueOf_D__Double_NoInit(n0_473_2 + 1.0).Ref() } else { arg_471 = lang.Numbers_Inc_O__Number_NoInit(na_472) } }; if linked_468 == nil { return ifn_469.Invoke_O_O__O(arg_470, arg_471) } else { if jrt.Long_InstanceOf(arg_471) { return linked_468.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_467, arg_470, jrt.NN(jrt.Long_Cast(arg_471)).LongValue__J(), arg_471) } else { return linked_468.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_467, arg_470, arg_471) } } }
//line :108:1
		default:
		}












		var root_348 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = s__0; var arg_352 any; var root_353 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = s__0; var arg_357 any; var na_358 any = i__1; if jrt.Long_InstanceOf(na_358) { var n0_359 int64 = jrt.NN(jrt.Long_Cast(na_358)).LongValue__J(); if n0_359 == 9223372036854775807 { arg_357 = lang.Numbers_Inc_O__Number_NoInit(na_358) } else { arg_357 = jrt.Long_ValueOf_J__Long_NoInit(n0_359 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_358) { var n0_359_2 float64 = jrt.NN(jrt.Double_Cast(na_358)).DoubleValue__D(); arg_357 = jrt.Double_ValueOf_D__Double_NoInit(n0_359_2 + 1.0).Ref() } else { arg_357 = lang.Numbers_Inc_O__Number_NoInit(na_358) } }; if linked_354 == nil { arg_352 = ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { arg_352 = linked_354.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_353, arg_356, arg_357) }; if linked_349 == nil { return ifn_350.Invoke_O_O__O(arg_351, arg_352) } else { return linked_349.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_348, arg_351, arg_352) } }
//line :98:1
	case 39: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_47) {




		var root_360 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = s__0; var arg_364 any; var na_365 any = i__1; if jrt.Long_InstanceOf(na_365) { var n0_366 int64 = jrt.NN(jrt.Long_Cast(na_365)).LongValue__J(); if n0_366 == 9223372036854775807 { arg_364 = lang.Numbers_Inc_O__Number_NoInit(na_365) } else { arg_364 = jrt.Long_ValueOf_J__Long_NoInit(n0_366 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_365) { var n0_366_2 float64 = jrt.NN(jrt.Double_Cast(na_365)).DoubleValue__D(); arg_364 = jrt.Double_ValueOf_D__Double_NoInit(n0_366_2 + 1.0).Ref() } else { arg_364 = lang.Numbers_Inc_O__Number_NoInit(na_365) } }; if linked_361 == nil { return ifn_362.Invoke_O_O__O(arg_363, arg_364) } else { return linked_361.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_360, arg_363, arg_364) } }
//line :98:1
	case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_19) {

		var root_474 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_474, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = s__0; var arg_478 any = i__1; if linked_475 == nil { return ifn_476.Invoke_O_O__O(arg_477, arg_478) } else { if jrt.Long_InstanceOf(arg_478) { return linked_475.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_474, arg_477, jrt.NN(jrt.Long_Cast(arg_478)).LongValue__J(), arg_478) } else { return linked_475.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_474, arg_477, arg_478) } } }
//line :98:1
	case 41: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_20) {







		var root_479 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = s__0; var arg_483 any = i__1; var arg_484 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref(); if linked_480 == nil { return ifn_481.Invoke_O_O_O__O(arg_482, arg_483, arg_484) } else { return linked_480.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_479, arg_482, arg_483, arg_484) } }
//line :98:1
	case 64: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_22) {




		var root_485 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = s__0; var arg_489 any; var na_490 any = i__1; if jrt.Long_InstanceOf(na_490) { var n0_491 int64 = jrt.NN(jrt.Long_Cast(na_490)).LongValue__J(); if n0_491 == 9223372036854775807 { arg_489 = lang.Numbers_Inc_O__Number_NoInit(na_490) } else { arg_489 = jrt.Long_ValueOf_J__Long_NoInit(n0_491 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_490) { var n0_491_2 float64 = jrt.NN(jrt.Double_Cast(na_490)).DoubleValue__D(); arg_489 = jrt.Double_ValueOf_D__Double_NoInit(n0_491_2 + 1.0).Ref() } else { arg_489 = lang.Numbers_Inc_O__Number_NoInit(na_490) } }; if linked_486 == nil { return ifn_487.Invoke_O_O__O(arg_488, arg_489) } else { return linked_486.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_485, arg_488, arg_489) } }
//line :98:1
	case 91: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_23) {

		var root_492 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_492, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = s__0; var arg_496 any = i__1; if linked_493 == nil { return ifn_494.Invoke_O_O__O(arg_495, arg_496) } else { if jrt.Long_InstanceOf(arg_496) { return linked_493.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_492, arg_495, jrt.NN(jrt.Long_Cast(arg_496)).LongValue__J(), arg_496) } else { return linked_493.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_492, arg_495, arg_496) } } }
//line :98:1
	case 92: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_24) {



		var root_497 any = A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_497, A_arbace_repr_clojure_text_char_end_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = s__0; var arg_501 any = i__1; if linked_498 == nil { return ifn_499.Invoke_O_O__O(arg_500, arg_501) } else { if jrt.Long_InstanceOf(arg_501) { return linked_498.(*A_arbace_repr_clojure_text_char_end_A).InvokeSpec_O_O_J_O__O(root_497, arg_500, jrt.NN(jrt.Long_Cast(arg_501)).LongValue__J(), arg_501) } else { return linked_498.(*A_arbace_repr_clojure_text_char_end_A).Invoke_O_O_O__O(root_497, arg_500, arg_501) } } }
//line :98:1
	case 93: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_25) {







		var root_502 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = s__0; var arg_506 any = i__1; var arg_507 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref(); if linked_503 == nil { return ifn_504.Invoke_O_O_O__O(arg_505, arg_506, arg_507) } else { return linked_503.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_502, arg_505, arg_506, arg_507) } }
//line :98:1
	case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_26) {






		var root_508 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = s__0; var arg_512 any; var root_513 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any = s__0; var arg_517 any; var na_518 any = i__1; if jrt.Long_InstanceOf(na_518) { var n0_519 int64 = jrt.NN(jrt.Long_Cast(na_518)).LongValue__J(); if n0_519 == 9223372036854775807 { arg_517 = lang.Numbers_Inc_O__Number_NoInit(na_518) } else { arg_517 = jrt.Long_ValueOf_J__Long_NoInit(n0_519 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_518) { var n0_519_2 float64 = jrt.NN(jrt.Double_Cast(na_518)).DoubleValue__D(); arg_517 = jrt.Double_ValueOf_D__Double_NoInit(n0_519_2 + 1.0).Ref() } else { arg_517 = lang.Numbers_Inc_O__Number_NoInit(na_518) } }; if linked_514 == nil { arg_512 = ifn_515.Invoke_O_O__O(arg_516, arg_517) } else { arg_512 = linked_514.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_513, arg_516, arg_517) }; if linked_509 == nil { return ifn_510.Invoke_O_O__O(arg_511, arg_512) } else { return linked_509.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_508, arg_511, arg_512) } }
//line :98:1
	case 96: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_27) {




		var root_520 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = s__0; var arg_524 any; var na_525 any = i__1; if jrt.Long_InstanceOf(na_525) { var n0_526 int64 = jrt.NN(jrt.Long_Cast(na_525)).LongValue__J(); if n0_526 == 9223372036854775807 { arg_524 = lang.Numbers_Inc_O__Number_NoInit(na_525) } else { arg_524 = jrt.Long_ValueOf_J__Long_NoInit(n0_526 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_525) { var n0_526_2 float64 = jrt.NN(jrt.Double_Cast(na_525)).DoubleValue__D(); arg_524 = jrt.Double_ValueOf_D__Double_NoInit(n0_526_2 + 1.0).Ref() } else { arg_524 = lang.Numbers_Inc_O__Number_NoInit(na_525) } }; if linked_521 == nil { return ifn_522.Invoke_O_O__O(arg_523, arg_524) } else { return linked_521.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_520, arg_523, arg_524) } }
//line :98:1
	case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_28) {

		var root_527 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_527, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any = s__0; var arg_531 any = i__1; if linked_528 == nil { return ifn_529.Invoke_O_O__O(arg_530, arg_531) } else { if jrt.Long_InstanceOf(arg_531) { return linked_528.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_527, arg_530, jrt.NN(jrt.Long_Cast(arg_531)).LongValue__J(), arg_531) } else { return linked_528.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_527, arg_530, arg_531) } } }
//line :98:1
	case 125: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_29) {







		var root_532 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = s__0; var arg_536 any = i__1; var arg_537 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref(); if linked_533 == nil { return ifn_534.Invoke_O_O_O__O(arg_535, arg_536, arg_537) } else { return linked_533.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_532, arg_535, arg_536, arg_537) } }
//line :98:1
	case 126: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_30) {





		var root_538 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = s__0; var arg_542 any; var tmp3 any = A_arbace_repr_clojure_text_A_const_22; var tmp4 any; var root_543 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = s__0; var arg_547 any; var na_548 any = i__1; if jrt.Long_InstanceOf(na_548) { var n0_549 int64 = jrt.NN(jrt.Long_Cast(na_548)).LongValue__J(); if n0_549 == 9223372036854775807 { arg_547 = lang.Numbers_Inc_O__Number_NoInit(na_548) } else { arg_547 = jrt.Long_ValueOf_J__Long_NoInit(n0_549 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_548) { var n0_549_2 float64 = jrt.NN(jrt.Double_Cast(na_548)).DoubleValue__D(); arg_547 = jrt.Double_ValueOf_D__Double_NoInit(n0_549_2 + 1.0).Ref() } else { arg_547 = lang.Numbers_Inc_O__Number_NoInit(na_548) } }; if linked_544 == nil { tmp4 = ifn_545.Invoke_O_O__O(arg_546, arg_547) } else { tmp4 = linked_544.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_543, arg_546, arg_547) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4) { var na_550 any = i__1; var na_551 int64 = 2; if jrt.Long_InstanceOf(na_550) { var n0_552 int64 = jrt.NN(jrt.Long_Cast(na_550)).LongValue__J(); var n1_553 int64 = na_551; var nr_554 int64 = n0_552 + n1_553; if (n0_552^nr_554)&(n1_553^nr_554) >= 0 { arg_542 = jrt.Long_ValueOf_J__Long_NoInit(nr_554).Ref() } else { arg_542 = lang.Numbers_Add_O_J__Number_NoInit(na_550, na_551) } } else { arg_542 = lang.Numbers_Add_O_J__Number_NoInit(na_550, na_551) } } else { var na_555 any = i__1; if jrt.Long_InstanceOf(na_555) { var n0_556 int64 = jrt.NN(jrt.Long_Cast(na_555)).LongValue__J(); if n0_556 == 9223372036854775807 { arg_542 = lang.Numbers_Inc_O__Number_NoInit(na_555) } else { arg_542 = jrt.Long_ValueOf_J__Long_NoInit(n0_556 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_555) { var n0_556_2 float64 = jrt.NN(jrt.Double_Cast(na_555)).DoubleValue__D(); arg_542 = jrt.Double_ValueOf_D__Double_NoInit(n0_556_2 + 1.0).Ref() } else { arg_542 = lang.Numbers_Inc_O__Number_NoInit(na_555) } } }; if linked_539 == nil { return ifn_540.Invoke_O_O__O(arg_541, arg_542) } else { return linked_539.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_538, arg_541, arg_542) } }
//line :98:1
	default:
	}























	var root_367 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = s__0; var arg_371 any = i__1; if linked_368 == nil { return ifn_369.Invoke_O_O__O(arg_370, arg_371) } else { return linked_368.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_367, arg_370, arg_371) } } }
//line :94:1
func (t *A_arbace_repr_clojure_text_form_end_A) InvokeSpec_O_O_J_O__O(self, s__0 any, i__1_l int64, i__1_b any) any { var c__3 any; var root_557 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_559 lang.IFn; if


	linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = s__0; var arg_561 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_561 = i__1_b } else { arg_561 = i__1_b }; if linked_558 == nil { c__3 = ifn_559.Invoke_O_O__O(arg_560, arg_561) } else { c__3 = linked_558.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_557, arg_560, arg_561) }; var G__670000027__4_ any = c__3; switch
	lang.Util_Hash_O__I_NoInit(G__670000027__4_) { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, nil) {
		var root_563 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = s__0; var arg_567 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_567 = i__1_b } else { arg_567 = i__1_b }; var arg_568 any = Lit_12; if linked_564 == nil { return ifn_565.Invoke_O_O_O__O(arg_566, arg_567, arg_568) } else { return linked_564.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_563, arg_566, arg_567, arg_568) } }
//line :98:1
	case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_18) {


		var root_569 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_569, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = s__0; if linked_570 == nil { var tmp1 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp1 = i__1_b } else { tmp1 = i__1_b }; return ifn_571.Invoke_O_O__O(arg_572, tmp1) } else { return linked_570.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_569, arg_572, i__1_l, i__1_b) } }
//line :98:1
	case 35: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_36) { var d__5 any; var root_574 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_576 lang.IFn








		if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = s__0; var arg_578 any; var n0_579 int64 = i__1_l; if n0_579 == 9223372036854775807 { var tmp2 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp2 = i__1_b } else { tmp2 = i__1_b }; arg_578 = lang.Numbers_Inc_O__Number_NoInit(tmp2) } else { arg_578 = jrt.Long_ValueOf_J__Long_NoInit(n0_579 + 1).Ref() }; if linked_575 == nil { d__5 = ifn_576.Invoke_O_O__O(arg_577, arg_578) } else { d__5 = linked_575.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_574, arg_577, arg_578) }
//line :98:1
		var G__670000028__6_ any = d__5









		switch lang.Util_Hash_O__I_NoInit(G__670000028__6_) { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, nil) {
			var root_581 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = s__0; var arg_585 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_585 = i__1_b } else { arg_585 = i__1_b }; var arg_586 any = Lit_13; if linked_582 == nil { return ifn_583.Invoke_O_O_O__O(arg_584, arg_585, arg_586) } else { return linked_582.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_581, arg_584, arg_585, arg_586) } }
//line :108:1
		case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_37) {






			var root_587 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = s__0; var arg_591 any; var root_592 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = s__0; var arg_596 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_596 = i__1_b } else { arg_596 = i__1_b }; if linked_593 == nil { arg_591 = ifn_594.Invoke_O_O__O(arg_595, arg_596) } else { arg_591 = linked_593.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_592, arg_595, arg_596) }; if linked_588 == nil { return ifn_589.Invoke_O_O__O(arg_590, arg_591) } else { return linked_588.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_587, arg_590, arg_591) } }
//line :108:1
		case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_18) {


			var root_597 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_597, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = s__0; var arg_601 any; var arg_601_l int64; var n0_602 int64 = i__1_l; if n0_602 == 9223372036854775807 { var tmp3 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp3 = i__1_b } else { tmp3 = i__1_b }; arg_601 = lang.Numbers_Inc_O__Number_NoInit(tmp3); arg_601_l = 0 } else { arg_601_l = n0_602 + 1 }; if linked_598 == nil { var tmp4 any; if arg_601 == nil { tmp4 = jrt.Long_ValueOf_J__Long_NoInit(arg_601_l).Ref() } else { tmp4 = arg_601 }; return ifn_599.Invoke_O_O__O(arg_600, tmp4) } else { var tmp5 bool; var tmp6 bool; tmp6 = arg_601 == nil; if !tmp6 { tmp6 = jrt.Long_InstanceOf(arg_601) }; tmp5 = tmp6; if tmp5 { var tmp7 *A_arbace_repr_clojure_text_string_end_A = linked_598.(*A_arbace_repr_clojure_text_string_end_A); var tmp8 int64; if arg_601 == nil { tmp8 = arg_601_l } else { tmp8 = jrt.NN(jrt.Long_Cast(arg_601)).LongValue__J() }; return tmp7.InvokeSpec_O_O_J_O__O(root_597, arg_600, tmp8, arg_601) } else { var tmp9 *A_arbace_repr_clojure_text_string_end_A = linked_598.(*A_arbace_repr_clojure_text_string_end_A); var tmp10 any; if arg_601 == nil { tmp10 = jrt.Long_ValueOf_J__Long_NoInit(arg_601_l).Ref() } else { tmp10 = arg_601 }; return tmp9.Invoke_O_O_O__O(root_597, arg_600, tmp10) } } }
//line :108:1
		case 35: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_36) {








			var root_603 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = s__0; var arg_607 any; var na_608 int64 = 2; var n0_609 int64 = i__1_l; var n1_610 int64 = na_608; var nr_611 int64 = n0_609 + n1_610; if (n0_609^nr_611)&(n1_610^nr_611) >= 0 { arg_607 = jrt.Long_ValueOf_J__Long_NoInit(nr_611).Ref() } else { var tmp11 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp11 = i__1_b } else { tmp11 = i__1_b }; arg_607 = lang.Numbers_Add_O_J__Number_NoInit(tmp11, na_608) }; if linked_604 == nil { return ifn_605.Invoke_O_O__O(arg_606, arg_607) } else { return linked_604.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_603, arg_606, arg_607) } }
//line :108:1
		case 39: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_47) {



			var root_634 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = s__0; var arg_638 any; var na_639 int64 = 2; var n0_640 int64 = i__1_l; var n1_641 int64 = na_639; var nr_642 int64 = n0_640 + n1_641; if (n0_640^nr_642)&(n1_641^nr_642) >= 0 { arg_638 = jrt.Long_ValueOf_J__Long_NoInit(nr_642).Ref() } else { var tmp12 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp12 = i__1_b } else { tmp12 = i__1_b }; arg_638 = lang.Numbers_Add_O_J__Number_NoInit(tmp12, na_639) }; if linked_635 == nil { return ifn_636.Invoke_O_O__O(arg_637, arg_638) } else { return linked_635.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_634, arg_637, arg_638) } }
//line :108:1
		case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_19) {

			var root_643 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_643, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = s__0; var arg_647 any; var arg_647_l int64; var n0_648 int64 = i__1_l; if n0_648 == 9223372036854775807 { var tmp13 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp13 = i__1_b } else { tmp13 = i__1_b }; arg_647 = lang.Numbers_Inc_O__Number_NoInit(tmp13); arg_647_l = 0 } else { arg_647_l = n0_648 + 1 }; if linked_644 == nil { var tmp14 any; if arg_647 == nil { tmp14 = jrt.Long_ValueOf_J__Long_NoInit(arg_647_l).Ref() } else { tmp14 = arg_647 }; return ifn_645.Invoke_O_O__O(arg_646, tmp14) } else { var tmp15 bool; var tmp16 bool; tmp16 = arg_647 == nil; if !tmp16 { tmp16 = jrt.Long_InstanceOf(arg_647) }; tmp15 = tmp16; if tmp15 { var tmp17 *A_arbace_repr_clojure_text_coll_end_A = linked_644.(*A_arbace_repr_clojure_text_coll_end_A); var tmp18 int64; if arg_647 == nil { tmp18 = arg_647_l } else { tmp18 = jrt.NN(jrt.Long_Cast(arg_647)).LongValue__J() }; return tmp17.InvokeSpec_O_O_J_O__O(root_643, arg_646, tmp18, arg_647) } else { var tmp19 *A_arbace_repr_clojure_text_coll_end_A = linked_644.(*A_arbace_repr_clojure_text_coll_end_A); var tmp20 any; if arg_647 == nil { tmp20 = jrt.Long_ValueOf_J__Long_NoInit(arg_647_l).Ref() } else { tmp20 = arg_647 }; return tmp19.Invoke_O_O_O__O(root_643, arg_646, tmp20) } } }
//line :108:1
		case 58: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_49) { var j__7 any; var root_649 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_651 lang.IFn









			if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = s__0; var arg_653 any; var root_654 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = s__0; var arg_658 any; var n0_659 int64 = i__1_l; if n0_659 == 9223372036854775807 { var tmp21 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp21 = i__1_b } else { tmp21 = i__1_b }; arg_658 = lang.Numbers_Inc_O__Number_NoInit(tmp21) } else { arg_658 = jrt.Long_ValueOf_J__Long_NoInit(n0_659 + 1).Ref() }; if linked_655 == nil { arg_653 = ifn_656.Invoke_O_O__O(arg_657, arg_658) } else { arg_653 = linked_655.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_654, arg_657, arg_658) }; if linked_650 == nil { j__7 = ifn_651.Invoke_O_O__O(arg_652, arg_653) } else { j__7 = linked_650.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_649, arg_652, arg_653) }
			var tmp22 any = A_arbace_repr_clojure_text_A_const_28; var tmp23 any; var root_674 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = s__0; var arg_678 any = j__7; if linked_675 == nil { tmp23 = ifn_676.Invoke_O_O__O(arg_677, arg_678) } else { tmp23 = linked_675.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_674, arg_677, arg_678) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp22, tmp23) { } else { var root_679 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = s__0; var arg_683 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_683 = i__1_b } else { arg_683 = i__1_b }; var arg_684 any = Lit_14; if linked_680 == nil { ifn_681.Invoke_O_O_O__O(arg_682, arg_683, arg_684) } else { linked_680.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_679, arg_682, arg_683, arg_684) } }
			var root_660 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_660, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = s__0; var arg_664 any = j__7; if linked_661 == nil { return ifn_662.Invoke_O_O__O(arg_663, arg_664) } else { if jrt.Long_InstanceOf(arg_664) { return linked_661.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_660, arg_663, jrt.NN(jrt.Long_Cast(arg_664)).LongValue__J(), arg_664) } else { return linked_661.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_660, arg_663, arg_664) } } }
//line :108:1
		case 61: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_50) {



			var root_665 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = s__0; var arg_669 any; var na_670 int64 = 2; var n0_671 int64 = i__1_l; var n1_672 int64 = na_670; var nr_673 int64 = n0_671 + n1_672; if (n0_671^nr_673)&(n1_672^nr_673) >= 0 { arg_669 = jrt.Long_ValueOf_J__Long_NoInit(nr_673).Ref() } else { var tmp24 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp24 = i__1_b } else { tmp24 = i__1_b }; arg_669 = lang.Numbers_Add_O_J__Number_NoInit(tmp24, na_670) }; if linked_666 == nil { return ifn_667.Invoke_O_O__O(arg_668, arg_669) } else { return linked_666.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_665, arg_668, arg_669) } }
//line :108:1
		case 63: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_51) {







			var root_685 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_685, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = s__0; var arg_689 any; var root_690 any = A_arbace_repr_clojure_text_A_const_52.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, A_arbace_repr_clojure_text_cond_open_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = s__0; var arg_694 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_694 = i__1_b } else { arg_694 = i__1_b }; if linked_691 == nil { arg_689 = ifn_692.Invoke_O_O__O(arg_693, arg_694) } else { arg_689 = linked_691.(*A_arbace_repr_clojure_text_cond_open_A).Invoke_O_O_O__O(root_690, arg_693, arg_694) }; if linked_686 == nil { return ifn_687.Invoke_O_O__O(arg_688, arg_689) } else { if jrt.Long_InstanceOf(arg_689) { return linked_686.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_685, arg_688, jrt.NN(jrt.Long_Cast(arg_689)).LongValue__J(), arg_689) } else { return linked_686.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_685, arg_688, arg_689) } } }
//line :108:1
		case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_26) {




			var root_695 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = s__0; var arg_699 any; var root_700 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = s__0; var arg_704 any; var na_705 int64 = 2; var n0_706 int64 = i__1_l; var n1_707 int64 = na_705; var nr_708 int64 = n0_706 + n1_707; if (n0_706^nr_708)&(n1_707^nr_708) >= 0 { arg_704 = jrt.Long_ValueOf_J__Long_NoInit(nr_708).Ref() } else { var tmp25 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp25 = i__1_b } else { tmp25 = i__1_b }; arg_704 = lang.Numbers_Add_O_J__Number_NoInit(tmp25, na_705) }; if linked_701 == nil { arg_699 = ifn_702.Invoke_O_O__O(arg_703, arg_704) } else { arg_699 = linked_701.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_700, arg_703, arg_704) }; if linked_696 == nil { return ifn_697.Invoke_O_O__O(arg_698, arg_699) } else { return linked_696.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_695, arg_698, arg_699) } }
//line :108:1
		case 95: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_39) {





			var root_709 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = s__0; var arg_713 any; var root_714 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = s__0; var arg_718 any; var na_719 int64 = 2; var n0_720 int64 = i__1_l; var n1_721 int64 = na_719; var nr_722 int64 = n0_720 + n1_721; if (n0_720^nr_722)&(n1_721^nr_722) >= 0 { arg_718 = jrt.Long_ValueOf_J__Long_NoInit(nr_722).Ref() } else { var tmp26 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp26 = i__1_b } else { tmp26 = i__1_b }; arg_718 = lang.Numbers_Add_O_J__Number_NoInit(tmp26, na_719) }; if linked_715 == nil { arg_713 = ifn_716.Invoke_O_O__O(arg_717, arg_718) } else { arg_713 = linked_715.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_714, arg_717, arg_718) }; if linked_710 == nil { return ifn_711.Invoke_O_O__O(arg_712, arg_713) } else { return linked_710.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_709, arg_712, arg_713) } }
//line :108:1
		case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_28) {

			var root_723 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_723, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = s__0; var arg_727 any; var arg_727_l int64; var n0_728 int64 = i__1_l; if n0_728 == 9223372036854775807 { var tmp27 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp27 = i__1_b } else { tmp27 = i__1_b }; arg_727 = lang.Numbers_Inc_O__Number_NoInit(tmp27); arg_727_l = 0 } else { arg_727_l = n0_728 + 1 }; if linked_724 == nil { var tmp28 any; if arg_727 == nil { tmp28 = jrt.Long_ValueOf_J__Long_NoInit(arg_727_l).Ref() } else { tmp28 = arg_727 }; return ifn_725.Invoke_O_O__O(arg_726, tmp28) } else { var tmp29 bool; var tmp30 bool; tmp30 = arg_727 == nil; if !tmp30 { tmp30 = jrt.Long_InstanceOf(arg_727) }; tmp29 = tmp30; if tmp29 { var tmp31 *A_arbace_repr_clojure_text_coll_end_A = linked_724.(*A_arbace_repr_clojure_text_coll_end_A); var tmp32 int64; if arg_727 == nil { tmp32 = arg_727_l } else { tmp32 = jrt.NN(jrt.Long_Cast(arg_727)).LongValue__J() }; return tmp31.InvokeSpec_O_O_J_O__O(root_723, arg_726, tmp32, arg_727) } else { var tmp33 *A_arbace_repr_clojure_text_coll_end_A = linked_724.(*A_arbace_repr_clojure_text_coll_end_A); var tmp34 any; if arg_727 == nil { tmp34 = jrt.Long_ValueOf_J__Long_NoInit(arg_727_l).Ref() } else { tmp34 = arg_727 }; return tmp33.Invoke_O_O_O__O(root_723, arg_726, tmp34) } } }
//line :108:1
		default:
		}












		var root_612 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = s__0; var arg_616 any; var root_617 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = s__0; var arg_621 any; var n0_622 int64 = i__1_l; if n0_622 == 9223372036854775807 { var tmp35 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp35 = i__1_b } else { tmp35 = i__1_b }; arg_621 = lang.Numbers_Inc_O__Number_NoInit(tmp35) } else { arg_621 = jrt.Long_ValueOf_J__Long_NoInit(n0_622 + 1).Ref() }; if linked_618 == nil { arg_616 = ifn_619.Invoke_O_O__O(arg_620, arg_621) } else { arg_616 = linked_618.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_617, arg_620, arg_621) }; if linked_613 == nil { return ifn_614.Invoke_O_O__O(arg_615, arg_616) } else { return linked_613.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_612, arg_615, arg_616) } }
//line :98:1
	case 39: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_47) {




		var root_623 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_625 lang.IFn; if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = s__0; var arg_627 any; var n0_628 int64 = i__1_l; if n0_628 == 9223372036854775807 { var tmp36 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp36 = i__1_b } else { tmp36 = i__1_b }; arg_627 = lang.Numbers_Inc_O__Number_NoInit(tmp36) } else { arg_627 = jrt.Long_ValueOf_J__Long_NoInit(n0_628 + 1).Ref() }; if linked_624 == nil { return ifn_625.Invoke_O_O__O(arg_626, arg_627) } else { return linked_624.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_623, arg_626, arg_627) } }
//line :98:1
	case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_19) {

		var root_729 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_729, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = s__0; if linked_730 == nil { var tmp37 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp37 = i__1_b } else { tmp37 = i__1_b }; return ifn_731.Invoke_O_O__O(arg_732, tmp37) } else { return linked_730.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_729, arg_732, i__1_l, i__1_b) } }
//line :98:1
	case 41: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_20) {







		var root_734 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any = s__0; var arg_738 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_738 = i__1_b } else { arg_738 = i__1_b }; var arg_739 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref(); if linked_735 == nil { return ifn_736.Invoke_O_O_O__O(arg_737, arg_738, arg_739) } else { return linked_735.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_734, arg_737, arg_738, arg_739) } }
//line :98:1
	case 64: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_22) {




		var root_740 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any = s__0; var arg_744 any; var n0_745 int64 = i__1_l; if n0_745 == 9223372036854775807 { var tmp38 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp38 = i__1_b } else { tmp38 = i__1_b }; arg_744 = lang.Numbers_Inc_O__Number_NoInit(tmp38) } else { arg_744 = jrt.Long_ValueOf_J__Long_NoInit(n0_745 + 1).Ref() }; if linked_741 == nil { return ifn_742.Invoke_O_O__O(arg_743, arg_744) } else { return linked_741.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_740, arg_743, arg_744) } }
//line :98:1
	case 91: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_23) {

		var root_746 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_746, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = s__0; if linked_747 == nil { var tmp39 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp39 = i__1_b } else { tmp39 = i__1_b }; return ifn_748.Invoke_O_O__O(arg_749, tmp39) } else { return linked_747.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_746, arg_749, i__1_l, i__1_b) } }
//line :98:1
	case 92: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_24) {



		var root_751 any = A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_751, A_arbace_repr_clojure_text_char_end_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = s__0; if linked_752 == nil { var tmp40 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp40 = i__1_b } else { tmp40 = i__1_b }; return ifn_753.Invoke_O_O__O(arg_754, tmp40) } else { return linked_752.(*A_arbace_repr_clojure_text_char_end_A).InvokeSpec_O_O_J_O__O(root_751, arg_754, i__1_l, i__1_b) } }
//line :98:1
	case 93: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_25) {







		var root_756 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = s__0; var arg_760 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_760 = i__1_b } else { arg_760 = i__1_b }; var arg_761 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref(); if linked_757 == nil { return ifn_758.Invoke_O_O_O__O(arg_759, arg_760, arg_761) } else { return linked_757.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_756, arg_759, arg_760, arg_761) } }
//line :98:1
	case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_26) {






		var root_762 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_764 lang.IFn; if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = s__0; var arg_766 any; var root_767 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = s__0; var arg_771 any; var n0_772 int64 = i__1_l; if n0_772 == 9223372036854775807 { var tmp41 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp41 = i__1_b } else { tmp41 = i__1_b }; arg_771 = lang.Numbers_Inc_O__Number_NoInit(tmp41) } else { arg_771 = jrt.Long_ValueOf_J__Long_NoInit(n0_772 + 1).Ref() }; if linked_768 == nil { arg_766 = ifn_769.Invoke_O_O__O(arg_770, arg_771) } else { arg_766 = linked_768.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_767, arg_770, arg_771) }; if linked_763 == nil { return ifn_764.Invoke_O_O__O(arg_765, arg_766) } else { return linked_763.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_762, arg_765, arg_766) } }
//line :98:1
	case 96: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_27) {




		var root_773 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = s__0; var arg_777 any; var n0_778 int64 = i__1_l; if n0_778 == 9223372036854775807 { var tmp42 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp42 = i__1_b } else { tmp42 = i__1_b }; arg_777 = lang.Numbers_Inc_O__Number_NoInit(tmp42) } else { arg_777 = jrt.Long_ValueOf_J__Long_NoInit(n0_778 + 1).Ref() }; if linked_774 == nil { return ifn_775.Invoke_O_O__O(arg_776, arg_777) } else { return linked_774.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_773, arg_776, arg_777) } }
//line :98:1
	case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_28) {

		var root_779 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_779, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = s__0; if linked_780 == nil { var tmp43 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp43 = i__1_b } else { tmp43 = i__1_b }; return ifn_781.Invoke_O_O__O(arg_782, tmp43) } else { return linked_780.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_779, arg_782, i__1_l, i__1_b) } }
//line :98:1
	case 125: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_29) {







		var root_784 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = s__0; var arg_788 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_788 = i__1_b } else { arg_788 = i__1_b }; var arg_789 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref(); if linked_785 == nil { return ifn_786.Invoke_O_O_O__O(arg_787, arg_788, arg_789) } else { return linked_785.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_784, arg_787, arg_788, arg_789) } }
//line :98:1
	case 126: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_30) {





		var root_790 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = s__0; var arg_794 any; var tmp44 any = A_arbace_repr_clojure_text_A_const_22; var tmp45 any; var root_795 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = s__0; var arg_799 any; var n0_800 int64 = i__1_l; if n0_800 == 9223372036854775807 { var tmp46 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp46 = i__1_b } else { tmp46 = i__1_b }; arg_799 = lang.Numbers_Inc_O__Number_NoInit(tmp46) } else { arg_799 = jrt.Long_ValueOf_J__Long_NoInit(n0_800 + 1).Ref() }; if linked_796 == nil { tmp45 = ifn_797.Invoke_O_O__O(arg_798, arg_799) } else { tmp45 = linked_796.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_795, arg_798, arg_799) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp44, tmp45) { var na_801 int64 = 2; var n0_802 int64 = i__1_l; var n1_803 int64 = na_801; var nr_804 int64 = n0_802 + n1_803; if (n0_802^nr_804)&(n1_803^nr_804) >= 0 { arg_794 = jrt.Long_ValueOf_J__Long_NoInit(nr_804).Ref() } else { var tmp47 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp47 = i__1_b } else { tmp47 = i__1_b }; arg_794 = lang.Numbers_Add_O_J__Number_NoInit(tmp47, na_801) } } else { var n0_805 int64 = i__1_l; if n0_805 == 9223372036854775807 { var tmp48 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp48 = i__1_b } else { tmp48 = i__1_b }; arg_794 = lang.Numbers_Inc_O__Number_NoInit(tmp48) } else { arg_794 = jrt.Long_ValueOf_J__Long_NoInit(n0_805 + 1).Ref() } }; if linked_791 == nil { return ifn_792.Invoke_O_O__O(arg_793, arg_794) } else { return linked_791.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_790, arg_793, arg_794) } }
//line :98:1
	default:}; var root_629 any =
























	A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = s__0; var arg_633 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_633 = i__1_b } else { arg_633 = i__1_b }; if linked_630 == nil { return ifn_631.Invoke_O_O__O(arg_632, arg_633) } else { return linked_630.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_629, arg_632, arg_633) } }



func A_arbace_repr_clojure_text_cond_open_A_New() *A_arbace_repr_clojure_text_cond_open_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_cond_open_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_repr_clojure_text_cond_open_A) Ctor() {}
//line :127:1
func (t *A_arbace_repr_clojure_text_cond_open_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 any; var tmp1 any = A_arbace_repr_clojure_text_cond_open_fn__670000030_A_New_O_O(i__1, s__0); var tmp2 *jrt.Class; var fncls__837 *jrt.Class = A_arbace_repr_clojure_text_cond_open_fn__670000030_A_fn_class; if



	fncls__837 == nil { var fncls__837d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_repr_clojure_text_cond_open_fn__670000030_A_fn_class = fncls__837d; tmp2 = fncls__837d } else { tmp2 = fncls__837 }; j__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var tmp3 any = A_arbace_repr_clojure_text_A_const_19; var tmp4 any; var root_838 any =

	A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = s__0; var arg_842 any = j__3; if linked_839 == nil { tmp4 = ifn_840.Invoke_O_O__O(arg_841, arg_842) } else { tmp4 = linked_839.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_838, arg_841, arg_842) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4) { } else { var root_843 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_843, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_845 lang.IFn; if linked_844 == nil { ifn_845 = lang.IFn_Cast(root_843) } else { ifn_845 = nil }; var arg_846 any = s__0; var arg_847 any = i__1; var arg_848 any = Lit_8; if linked_844 == nil { ifn_845.Invoke_O_O_O__O(arg_846, arg_847, arg_848) } else { linked_844.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_843, arg_846, arg_847, arg_848) } }; return j__3 }
//line :131:1
func A_arbace_repr_clojure_text_cond_open_fn__670000030_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_text_cond_open_fn__670000030_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_cond_open_fn__670000030_A{}; t.Ctor_O_O(p0, p1); return t }
//line :131:1
func (t *A_arbace_repr_clojure_text_cond_open_fn__670000030_A) Ctor_O_O(c__i, c__s any) { t.F_i = c__i; t.F_s = c__s }
//line :131:1
func (t *A_arbace_repr_clojure_text_cond_open_fn__670000030_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 any = A_arbace_repr_clojure_text_A_const_22; var tmp2 any; var root_806 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = t.F_s; var arg_810 any; var na_811 any = t.F_i; var na_812 int64 = 2; if jrt.Long_InstanceOf(na_811) { var n0_813 int64 = jrt.NN(jrt.Long_Cast(na_811)).LongValue__J(); var n1_814 int64 = na_812; var nr_815 int64 = n0_813 + n1_814; if (n0_813^nr_815)&(n1_814^nr_815) >= 0 { arg_810 = jrt.Long_ValueOf_J__Long_NoInit(nr_815).Ref() } else { arg_810 = lang.Numbers_Add_O_J__Number_NoInit(na_811, na_812) } } else { arg_810 = lang.Numbers_Add_O_J__Number_NoInit(na_811, na_812) }; if linked_807 == nil { tmp2 = ifn_808.Invoke_O_O__O(arg_809, arg_810) } else { tmp2 = linked_807.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_806, arg_809, arg_810) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { var na_816 any; var t_ any = t.F_i; t.F_i = nil; na_816 = t_; var na_817 int64 = 3; if jrt.Long_InstanceOf(na_816) { var n0_818 int64 = jrt.NN(jrt.Long_Cast(na_816)).LongValue__J(); var n1_819 int64 = na_817; var nr_820 int64 = n0_818 + n1_819; if (n0_818^nr_820)&(n1_819^nr_820) >= 0 { j__1 = jrt.Long_ValueOf_J__Long_NoInit(nr_820).Ref() } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_816, na_817) } } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_816, na_817) } } else { var na_821 any; var t__2 any = t.F_i; t.F_i = nil; na_821 = t__2; var na_822 int64 = 2; if jrt.Long_InstanceOf(na_821) { var n0_823 int64 = jrt.NN(jrt.Long_Cast(na_821)).LongValue__J(); var n1_824 int64 = na_822; var nr_825 int64 = n0_823 + n1_824; if (n0_823^nr_825)&(n1_824^nr_825) >= 0 { j__1 = jrt.Long_ValueOf_J__Long_NoInit(nr_825).Ref() } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_821, na_822) } } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_821, na_822) } }; L1: for {
												var tmp3 any; var and__1927000168__auto____2 bool; var na_826 any = j__1; var na_827 int64 = int64(lang.RT_Count_O__I_NoInit(t.F_s)); if jrt.Long_InstanceOf(na_826) { var n0_828 int64 = jrt.NN(jrt.Long_Cast(na_826)).LongValue__J(); var n1_829 int64 = na_827; and__1927000168__auto____2 = n0_828 < n1_829 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_J__Z_NoInit(na_826, na_827) }; if and__1927000168__auto____2 { var root_831 any = A_arbace_repr_clojure_text_A_const_17.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, A_arbace_repr_clojure_text_ws_QMARK__A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var tmp4 *jrt.String = jrt.String_Cast(t.F_s); var arg_834 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(tmp4).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))).Ref(); if linked_832 == nil { tmp3 = ifn_833.Invoke_O__O(arg_834) } else { tmp3 = linked_832.(*A_arbace_repr_clojure_text_ws_QMARK__A).Invoke_O_O__O(root_831, arg_834) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp3) { var tmp5 jrt.Number_I; var na_835 any = j__1; if jrt.Long_InstanceOf(na_835) { var n0_836 int64 = jrt.NN(jrt.Long_Cast(na_835)).LongValue__J(); if n0_836 == 9223372036854775807 { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_835) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_836 + 1)) } } else { if jrt.Double_InstanceOf(na_835) { var n0_836_2 float64 = jrt.NN(jrt.Double_Cast(na_835)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_836_2 + 1.0)) } else { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_835) } }; j__1 = tmp5; continue L1 } else { return j__1 } } }; /*line :131:1*/panic("j2g: unreachable") }




func A_arbace_repr_clojure_text_branches_A_New() *A_arbace_repr_clojure_text_branches_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_branches_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_repr_clojure_text_branches_A) Ctor() {}
//line :136:1
func (t *A_arbace_repr_clojure_text_branches_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_O_J_O__O(self, s__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1) } else { var j__3 any; var root_849 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_849, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_851 lang.IFn



	if linked_850 == nil { ifn_851 = lang.IFn_Cast(root_849) } else { ifn_851 = nil }; var arg_852 any = s__0; var arg_853 any; var na_854 any = i__1; if jrt.Long_InstanceOf(na_854) { var n0_855 int64 = jrt.NN(jrt.Long_Cast(na_854)).LongValue__J(); if n0_855 == 9223372036854775807 { arg_853 = lang.Numbers_Inc_O__Number_NoInit(na_854) } else { arg_853 = jrt.Long_ValueOf_J__Long_NoInit(n0_855 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_854) { var n0_855_2 float64 = jrt.NN(jrt.Double_Cast(na_854)).DoubleValue__D(); arg_853 = jrt.Double_ValueOf_D__Double_NoInit(n0_855_2 + 1.0).Ref() } else { arg_853 = lang.Numbers_Inc_O__Number_NoInit(na_854) } }; if linked_850 == nil { j__3 = ifn_851.Invoke_O_O__O(arg_852, arg_853) } else { j__3 = linked_850.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_849, arg_852, arg_853) }
//line :136:1
	var bs__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		var tmp1 any = A_arbace_repr_clojure_text_A_const_20; var tmp2 any; var root_856 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = s__0; var arg_860 any = j__3; if linked_857 == nil { tmp2 = ifn_858.Invoke_O_O__O(arg_859, arg_860) } else { tmp2 = linked_857.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_856, arg_859, arg_860) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { return bs__4 } else { var fe__5 any; var root_861 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_861, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_863 lang.IFn

			if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = s__0; var arg_865 any = j__3; if linked_862 == nil { fe__5 = ifn_863.Invoke_O_O__O(arg_864, arg_865) } else { if jrt.Long_InstanceOf(arg_865) { fe__5 = linked_862.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_861, arg_864, jrt.NN(jrt.Long_Cast(arg_865)).LongValue__J(), arg_865) } else { fe__5 = linked_862.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_861, arg_864, arg_865) } }
//line :141:1
			var feature__6 any; var root_866 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_868 lang.IFn


			if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = s__0; var arg_870 any = j__3; var arg_871 any = fe__5; if linked_867 == nil { feature__6 = ifn_868.Invoke_O_O_O__O(arg_869, arg_870, arg_871) } else { feature__6 = linked_867.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_866, arg_869, arg_870, arg_871) }
//line :141:1
			var v__7 any; var root_872 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_874 lang.IFn



			if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = s__0; var arg_876 any = fe__5; if linked_873 == nil { v__7 = ifn_874.Invoke_O_O__O(arg_875, arg_876) } else { v__7 = linked_873.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_872, arg_875, arg_876) }
			var tmp3 any; var root_882 any = A_arbace_repr_clojure_text_A_const_54.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_884 lang.IFn; if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = feature__6; var arg_886 any = Lit_1; if linked_883 == nil { tmp3 = ifn_884.Invoke_O_O__O(arg_885, arg_886) } else { tmp3 = linked_883.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_882, arg_885, arg_886) }; if jrt.J2g_Truth(tmp3) { } else { var root_887 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_889 lang.IFn; if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = s__0; var arg_891 any = j__3; var arg_892 any = Lit_2; if linked_888 == nil { ifn_889.Invoke_O_O_O__O(arg_890, arg_891, arg_892) } else { linked_888.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_887, arg_890, arg_891, arg_892) } }
			var tmp4 any = A_arbace_repr_clojure_text_A_const_20; var tmp5 any; var root_893 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = s__0; var arg_897 any = v__7; if linked_894 == nil { tmp5 = ifn_895.Invoke_O_O__O(arg_896, arg_897) } else { tmp5 = linked_894.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_893, arg_896, arg_897) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5) { var root_898 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = s__0; var arg_902 any = v__7; var arg_903 any = Lit_3; if linked_899 == nil { ifn_900.Invoke_O_O_O__O(arg_901, arg_902, arg_903) } else { linked_899.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_898, arg_901, arg_902, arg_903) } }
//line :141:1
			var ve__8 any; var root_877 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_877, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_879 lang.IFn






			if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = s__0; var arg_881 any = v__7; if linked_878 == nil { ve__8 = ifn_879.Invoke_O_O__O(arg_880, arg_881) } else { if jrt.Long_InstanceOf(arg_881) { ve__8 = linked_878.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_877, arg_880, jrt.NN(jrt.Long_Cast(arg_881)).LongValue__J(), arg_881) } else { ve__8 = linked_878.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_877, arg_880, arg_881) } }
			var tmp6 any; var root_904 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = s__0; var arg_908 any = ve__8; if linked_905 == nil { tmp6 = ifn_906.Invoke_O_O__O(arg_907, arg_908) } else { tmp6 = linked_905.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_904, arg_907, arg_908) }; var tmp7 any = tmp6; var tmp8 any; var root_909 any = A_arbace_repr_clojure_text_A_const_7.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = bs__4; var arg_913 any; var tmp9 any; var root_914 any = A_arbace_repr_clojure_text_A_const_55.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any; var root_918 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = feature__6; var arg_922 any = A_arbace_repr_clojure_text_A_const_56; if linked_919 == nil { arg_917 = ifn_920.Invoke_O_O__O(arg_921, arg_922) } else { arg_917 = linked_919.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_918, arg_921, arg_922) }; if linked_915 == nil { tmp9 = ifn_916.Invoke_O__O(arg_917) } else { tmp9 = linked_915.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_914, arg_917) }; arg_913 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp9, v__7, ve__8); if linked_910 == nil { tmp8 = ifn_911.Invoke_O_O__O(arg_912, arg_913) } else { tmp8 = linked_910.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_909, arg_912, arg_913) }; j__3, bs__4 = tmp7, tmp8; continue L1 } } }; /*line :136:1*/panic("j2g: unreachable") }
//line :136:1
func (t *A_arbace_repr_clojure_text_branches_A) InvokeSpec_O_O_J_O__O(self, s__0 any, i__1_l int64, i__1_b any) any { { var j__3 any; var root_923 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_925 lang.IFn



	if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = s__0; var arg_927 any; var n0_928 int64 = i__1_l; if n0_928 == 9223372036854775807 { var tmp1 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp1 = i__1_b } else { tmp1 = i__1_b }; arg_927 = lang.Numbers_Inc_O__Number_NoInit(tmp1) } else { arg_927 = jrt.Long_ValueOf_J__Long_NoInit(n0_928 + 1).Ref() }; if linked_924 == nil { j__3 = ifn_925.Invoke_O_O__O(arg_926, arg_927) } else { j__3 = linked_924.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_923, arg_926, arg_927) }
//line :136:1
	var bs__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		var tmp2 any = A_arbace_repr_clojure_text_A_const_20; var tmp3 any; var root_929 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = s__0; var arg_933 any = j__3; if linked_930 == nil { tmp3 = ifn_931.Invoke_O_O__O(arg_932, arg_933) } else { tmp3 = linked_930.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_929, arg_932, arg_933) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { return bs__4 } else { var fe__5 any; var root_934 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_934, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_936 lang.IFn

			if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = s__0; var arg_938 any = j__3; if linked_935 == nil { fe__5 = ifn_936.Invoke_O_O__O(arg_937, arg_938) } else { if jrt.Long_InstanceOf(arg_938) { fe__5 = linked_935.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_934, arg_937, jrt.NN(jrt.Long_Cast(arg_938)).LongValue__J(), arg_938) } else { fe__5 = linked_935.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_934, arg_937, arg_938) } }
//line :141:1
			var feature__6 any; var root_939 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_939, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_941 lang.IFn


			if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = s__0; var arg_943 any = j__3; var arg_944 any = fe__5; if linked_940 == nil { feature__6 = ifn_941.Invoke_O_O_O__O(arg_942, arg_943, arg_944) } else { feature__6 = linked_940.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_939, arg_942, arg_943, arg_944) }
//line :141:1
			var v__7 any; var root_945 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_945, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_947 lang.IFn



			if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any = s__0; var arg_949 any = fe__5; if linked_946 == nil { v__7 = ifn_947.Invoke_O_O__O(arg_948, arg_949) } else { v__7 = linked_946.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_945, arg_948, arg_949) }
			var tmp4 any; var root_955 any = A_arbace_repr_clojure_text_A_const_54.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = feature__6; var arg_959 any = Lit_1; if linked_956 == nil { tmp4 = ifn_957.Invoke_O_O__O(arg_958, arg_959) } else { tmp4 = linked_956.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_955, arg_958, arg_959) }; if jrt.J2g_Truth(tmp4) { } else { var root_960 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any = s__0; var arg_964 any = j__3; var arg_965 any = Lit_2; if linked_961 == nil { ifn_962.Invoke_O_O_O__O(arg_963, arg_964, arg_965) } else { linked_961.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_960, arg_963, arg_964, arg_965) } }
			var tmp5 any = A_arbace_repr_clojure_text_A_const_20; var tmp6 any; var root_966 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = s__0; var arg_970 any = v__7; if linked_967 == nil { tmp6 = ifn_968.Invoke_O_O__O(arg_969, arg_970) } else { tmp6 = linked_967.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_966, arg_969, arg_970) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp5, tmp6) { var root_971 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = s__0; var arg_975 any = v__7; var arg_976 any = Lit_3; if linked_972 == nil { ifn_973.Invoke_O_O_O__O(arg_974, arg_975, arg_976) } else { linked_972.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_971, arg_974, arg_975, arg_976) } }
//line :141:1
			var ve__8 any; var root_950 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_950, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_952 lang.IFn






			if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = s__0; var arg_954 any = v__7; if linked_951 == nil { ve__8 = ifn_952.Invoke_O_O__O(arg_953, arg_954) } else { if jrt.Long_InstanceOf(arg_954) { ve__8 = linked_951.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_950, arg_953, jrt.NN(jrt.Long_Cast(arg_954)).LongValue__J(), arg_954) } else { ve__8 = linked_951.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_950, arg_953, arg_954) } }
			var tmp7 any; var root_977 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_977, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_979 lang.IFn; if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any = s__0; var arg_981 any = ve__8; if linked_978 == nil { tmp7 = ifn_979.Invoke_O_O__O(arg_980, arg_981) } else { tmp7 = linked_978.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_977, arg_980, arg_981) }; var tmp8 any = tmp7; var tmp9 any; var root_982 any = A_arbace_repr_clojure_text_A_const_7.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_984 lang.IFn; if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = bs__4; var arg_986 any; var tmp10 any; var root_987 any = A_arbace_repr_clojure_text_A_const_55.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_987, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_989 lang.IFn; if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any; var root_991 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_991, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_993 lang.IFn; if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any = feature__6; var arg_995 any = A_arbace_repr_clojure_text_A_const_56; if linked_992 == nil { arg_990 = ifn_993.Invoke_O_O__O(arg_994, arg_995) } else { arg_990 = linked_992.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_991, arg_994, arg_995) }; if linked_988 == nil { tmp10 = ifn_989.Invoke_O__O(arg_990) } else { tmp10 = linked_988.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_987, arg_990) }; arg_986 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp10, v__7, ve__8); if linked_983 == nil { tmp9 = ifn_984.Invoke_O_O__O(arg_985, arg_986) } else { tmp9 = linked_983.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_982, arg_985, arg_986) }; j__3, bs__4 = tmp8, tmp9; continue L1 } } }; /*line :136:1*/panic("j2g: unreachable") }
















func A_arbace_repr_clojure_text_selected_A_New() *A_arbace_repr_clojure_text_selected_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_selected_A{}; t.Ctor(); return t }
//line :153:1
func (t *A_arbace_repr_clojure_text_selected_A) Ctor() {}
//line :153:1
func (t *A_arbace_repr_clojure_text_selected_A) Invoke_O_O_O_O_O__O(self, s__0, i__1, features__2, depth__3 any) any { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(i__1); if tmp2 { tmp2 = jrt.Long_InstanceOf(depth__3) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_O_J_O_O_J_O__O(self, s__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, features__2, jrt.NN(jrt.Long_Cast(depth__3)).LongValue__J(), depth__3) } else { var splice_QMARK___5 bool; var tmp3 any = A_arbace_repr_clojure_text_A_const_22; var tmp4 any; var root_996 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_998 lang.IFn




	if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = s__0; var arg_1000 any; var na_1001 any = i__1; var na_1002 int64 = 2; if jrt.Long_InstanceOf(na_1001) { var n0_1003 int64 = jrt.NN(jrt.Long_Cast(na_1001)).LongValue__J(); var n1_1004 int64 = na_1002; var nr_1005 int64 = n0_1003 + n1_1004; if (n0_1003^nr_1005)&(n1_1004^nr_1005) >= 0 { arg_1000 = jrt.Long_ValueOf_J__Long_NoInit(nr_1005).Ref() } else { arg_1000 = lang.Numbers_Add_O_J__Number_NoInit(na_1001, na_1002) } } else { arg_1000 = lang.Numbers_Add_O_J__Number_NoInit(na_1001, na_1002) }; if linked_997 == nil { tmp4 = ifn_998.Invoke_O_O__O(arg_999, arg_1000) } else { tmp4 = linked_997.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_996, arg_999, arg_1000) }; splice_QMARK___5 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)
//line :153:1
	var open__6 any; var root_1006 any = A_arbace_repr_clojure_text_A_const_52.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, A_arbace_repr_clojure_text_cond_open_A_fn_class); var ifn_1008 lang.IFn





	if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = s__0; var arg_1010 any = i__1; if linked_1007 == nil { open__6 = ifn_1008.Invoke_O_O__O(arg_1009, arg_1010) } else { open__6 = linked_1007.(*A_arbace_repr_clojure_text_cond_open_A).Invoke_O_O_O__O(root_1006, arg_1009, arg_1010) }
//line :153:1
	var vec__670000034__7 any; var root_1011 any = A_arbace_repr_clojure_text_A_const_57.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1013 lang.IFn






	if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any; var root_1015 any = A_arbace_repr_clojure_text_A_const_9.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1017 lang.IFn; if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any; var tmp5 any = A_arbace_repr_clojure_text_selected_fn__670000038_A_New_O(features__2); var tmp6 *jrt.Class; var fncls__1025 *jrt.Class = A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class; if fncls__1025 == nil { var fncls__1025d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class = fncls__1025d; tmp6 = fncls__1025d } else { tmp6 = fncls__1025 }; arg_1018 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1019 any; var root_1026 any = A_arbace_repr_clojure_text_A_const_60.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1026, A_arbace_repr_clojure_text_branches_A_fn_class); var ifn_1028 lang.IFn
	if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = s__0; var arg_1030 any = open__6; if linked_1027 == nil { arg_1019 = ifn_1028.Invoke_O_O__O(arg_1029, arg_1030) } else { if jrt.Long_InstanceOf(arg_1030) { arg_1019 = linked_1027.(*A_arbace_repr_clojure_text_branches_A).InvokeSpec_O_O_J_O__O(root_1026, arg_1029, jrt.NN(jrt.Long_Cast(arg_1030)).LongValue__J(), arg_1030) } else { arg_1019 = linked_1027.(*A_arbace_repr_clojure_text_branches_A).Invoke_O_O_O__O(root_1026, arg_1029, arg_1030) } }
//line :160:1
	if linked_1016 == nil { arg_1014 = ifn_1017.Invoke_O_O__O(arg_1018, arg_1019) } else { arg_1014 = linked_1016.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1015, arg_1018, arg_1019) }; if linked_1012 == nil { vec__670000034__7 = ifn_1013.Invoke_O__O(arg_1014) } else { vec__670000034__7 = linked_1012.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1011, arg_1014) }
//line :153:1
	var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(0), nil); var v__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(1), nil); var ve__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp7 bool; var and__1927000168__auto____11 bool = splice_QMARK___5; _ = ___8








	if and__1927000168__auto____11 { var na_1069 any = depth__3; if jrt.Long_InstanceOf(na_1069) { var n0_1070 int64 = jrt.NN(jrt.Long_Cast(na_1069)).LongValue__J(); tmp7 = n0_1070 == 0 } else { if jrt.Double_InstanceOf(na_1069) { var n0_1070_2 float64 = jrt.NN(jrt.Double_Cast(na_1069)).DoubleValue__D(); tmp7 = n0_1070_2 == 0.0 } else { tmp7 = lang.Numbers_IsZero_O__Z_NoInit(na_1069) } } } else { tmp7 = and__1927000168__auto____11 }; if tmp7 {
		var root_1071 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = s__0; var arg_1075 any = i__1; var arg_1076 any = Lit_22; if linked_1072 == nil { ifn_1073.Invoke_O_O_O__O(arg_1074, arg_1075, arg_1076) } else { linked_1072.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_1071, arg_1074, arg_1075, arg_1076)
		}
	}
	if lang.Util_Identical_O_O__Z_NoInit(v__9, nil) { return Lit_23 } else { var tmp8 any; var root_1031 any = A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1033 lang.IFn
		if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(splice_QMARK___5).Ref(); if linked_1032 == nil { tmp8 = ifn_1033.Invoke_O__O(arg_1034) } else { tmp8 = linked_1032.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1031, arg_1034) }
//line :166:1
		if jrt.J2g_Truth(tmp8) {
			var root_1035 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any; var root_1041 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1041, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1043 lang.IFn; if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = s__0; var arg_1045 any = v__9; var arg_1046 any = ve__10; if linked_1042 == nil { arg_1038 = ifn_1043.Invoke_O_O_O__O(arg_1044, arg_1045, arg_1046) } else { arg_1038 = linked_1042.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1041, arg_1044, arg_1045, arg_1046) }; var arg_1039 any = features__2; var arg_1040 any = depth__3; if linked_1036 == nil { return ifn_1037.Invoke_O_O_O__O(arg_1038, arg_1039, arg_1040) } else { return linked_1036.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O_O__O(root_1035, arg_1038, arg_1039, arg_1040) } } else {
//line :166:1
				var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_62); var tmp10 any; var root_1077 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_1079 lang.IFn

				if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = s__0; var arg_1081 any = v__9; if linked_1078 == nil { tmp10 = ifn_1079.Invoke_O_O__O(arg_1080, arg_1081) } else { tmp10 = linked_1078.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_1077, arg_1080, arg_1081) }
//line :166:1
				if jrt.J2g_Truth(tmp9.Invoke_O__O(tmp10)) {

					var root_1047 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any; var root_1053 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = s__0; var arg_1057 any; var na_1059 any = v__9; if jrt.Long_InstanceOf(na_1059) { var n0_1060 int64 = jrt.NN(jrt.Long_Cast(na_1059)).LongValue__J(); if n0_1060 == 9223372036854775807 { arg_1057 = lang.Numbers_Inc_O__Number_NoInit(na_1059) } else { arg_1057 = jrt.Long_ValueOf_J__Long_NoInit(n0_1060 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1059) { var n0_1060_2 float64 = jrt.NN(jrt.Double_Cast(na_1059)).DoubleValue__D(); arg_1057 = jrt.Double_ValueOf_D__Double_NoInit(n0_1060_2 + 1.0).Ref() } else { arg_1057 = lang.Numbers_Inc_O__Number_NoInit(na_1059) } }; var arg_1058 any; var na_1061 any = ve__10; if jrt.Long_InstanceOf(na_1061) { var n0_1062 int64 = jrt.NN(jrt.Long_Cast(na_1061)).LongValue__J(); if n0_1062 == -9223372036854775808 { arg_1058 = lang.Numbers_Dec_O__Number_NoInit(na_1061) } else { arg_1058 = jrt.Long_ValueOf_J__Long_NoInit(n0_1062 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_1061) { var n0_1062_2 float64 = jrt.NN(jrt.Double_Cast(na_1061)).DoubleValue__D(); arg_1058 = jrt.Double_ValueOf_D__Double_NoInit(n0_1062_2 - 1.0).Ref() } else { arg_1058 = lang.Numbers_Dec_O__Number_NoInit(na_1061) } }; if linked_1054 == nil { arg_1050 = ifn_1055.Invoke_O_O_O__O(arg_1056, arg_1057, arg_1058) } else { arg_1050 = linked_1054.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1053, arg_1056, arg_1057, arg_1058) }; var arg_1051 any = features__2; var arg_1052 any = depth__3; if linked_1048 == nil { return ifn_1049.Invoke_O_O_O__O(arg_1050, arg_1051, arg_1052) } else { return linked_1048.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O_O__O(root_1047, arg_1050, arg_1051, arg_1052) } } else {
//line :166:1
						if A_arbace_repr_clojure_text_A_const_34 != nil {


							var root_1063 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_1065 lang.IFn; if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = s__0; var arg_1067 any = v__9; var arg_1068 any = Lit_24; if linked_1064 == nil { return ifn_1065.Invoke_O_O_O__O(arg_1066, arg_1067, arg_1068) } else { return linked_1064.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_1063, arg_1066, arg_1067, arg_1068) } } else {
//line :166:1
								return nil } } } } } }
//line :153:1
func (t *A_arbace_repr_clojure_text_selected_A) InvokeSpec_O_O_J_O_O_J_O__O(self, s__0 any, i__1_l int64, i__1_b, features__2 any, depth__3_l int64, depth__3_b any) any { var splice_QMARK___5 bool; var tmp1 any = A_arbace_repr_clojure_text_A_const_22; var tmp2 any; var root_1082 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1082, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_1084 lang.IFn; if




	linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = s__0; var arg_1086 any; var na_1087 int64 = 2; var n0_1088 int64 = i__1_l; var n1_1089 int64 = na_1087; var nr_1090 int64 = n0_1088 + n1_1089; if (n0_1088^nr_1090)&(n1_1089^nr_1090) >= 0 { arg_1086 = jrt.Long_ValueOf_J__Long_NoInit(nr_1090).Ref() } else { var tmp3 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp3 = i__1_b } else { tmp3 = i__1_b }; arg_1086 = lang.Numbers_Add_O_J__Number_NoInit(tmp3, na_1087) }; if linked_1083 == nil { tmp2 = ifn_1084.Invoke_O_O__O(arg_1085, arg_1086) } else { tmp2 = linked_1083.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_1082, arg_1085, arg_1086) }; splice_QMARK___5 = lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2); var open__6 any; var root_1091 any = /*line :153:1*/A_arbace_repr_clojure_text_A_const_52.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, A_arbace_repr_clojure_text_cond_open_A_fn_class); var ifn_1093 lang.IFn; if





	linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = s__0; var arg_1095 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_1095 = i__1_b } else { arg_1095 = i__1_b }; if linked_1092 == nil { open__6 = ifn_1093.Invoke_O_O__O(arg_1094, arg_1095) } else { open__6 = linked_1092.(*A_arbace_repr_clojure_text_cond_open_A).Invoke_O_O_O__O(root_1091, arg_1094, arg_1095) }; var vec__670000034__7 any; var root_1096 any = /*line :153:1*/A_arbace_repr_clojure_text_A_const_57.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1098 lang.IFn; if






	linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any; var root_1100 any = A_arbace_repr_clojure_text_A_const_9.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1102 lang.IFn; if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any; var tmp4 any = A_arbace_repr_clojure_text_selected_fn__670000038_A_New_O(features__2); var tmp5 *jrt.Class; var fncls__1105 *jrt.Class = A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class; if fncls__1105 == nil { var fncls__1105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class = fncls__1105d; tmp5 = fncls__1105d } else { tmp5 = fncls__1105 }; arg_1103 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_1104 any; var root_1106 any = A_arbace_repr_clojure_text_A_const_60.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1106, A_arbace_repr_clojure_text_branches_A_fn_class); var ifn_1108 lang.IFn; if
	linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any = s__0; var arg_1110 any = open__6; if linked_1107 == nil { arg_1104 = ifn_1108.Invoke_O_O__O(arg_1109, arg_1110) } else { if jrt.Long_InstanceOf(arg_1110) { arg_1104 = linked_1107.(*A_arbace_repr_clojure_text_branches_A).InvokeSpec_O_O_J_O__O(root_1106, arg_1109, jrt.NN(jrt.Long_Cast(arg_1110)).LongValue__J(), arg_1110) } else { arg_1104 = linked_1107.(*A_arbace_repr_clojure_text_branches_A).Invoke_O_O_O__O(root_1106, arg_1109, arg_1110) } }; if /*line :160:1*/ linked_1101 == nil { arg_1099 = ifn_1102.Invoke_O_O__O(arg_1103, arg_1104) } else { arg_1099 = linked_1101.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1100, arg_1103, arg_1104) }; if linked_1097 == nil { vec__670000034__7 = ifn_1098.Invoke_O__O(arg_1099) } else { vec__670000034__7 = linked_1097.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1096, arg_1099) }; var ___8 any = /*line :153:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(0), nil); var v__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(1), nil); var ve__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp6 bool; var and__1927000168__auto____11 bool = splice_QMARK___5; _ = ___8; if and__1927000168__auto____11 {








		var n0_1149 int64 = depth__3_l; tmp6 = n0_1149 == 0 } else { tmp6 = and__1927000168__auto____11 }; if tmp6 {
			var root_1150 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = s__0; var arg_1154 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_1154 = i__1_b } else { arg_1154 = i__1_b }; var arg_1155 any = Lit_22; if linked_1151 == nil { ifn_1152.Invoke_O_O_O__O(arg_1153, arg_1154, arg_1155) } else { linked_1151.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_1150, arg_1153, arg_1154, arg_1155) } }; if


	lang.Util_Identical_O_O__Z_NoInit(v__9, nil) { return Lit_23 } else { var tmp7 any; var root_1111 any = A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1113 lang.IFn
		if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(splice_QMARK___5).Ref(); if linked_1112 == nil { tmp7 = ifn_1113.Invoke_O__O(arg_1114) } else { tmp7 = linked_1112.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1111, arg_1114) }
//line :166:1
		if jrt.J2g_Truth(tmp7) {
			var root_1115 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1117 lang.IFn; if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any; var root_1121 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = s__0; var arg_1125 any = v__9; var arg_1126 any = ve__10; if linked_1122 == nil { arg_1118 = ifn_1123.Invoke_O_O_O__O(arg_1124, arg_1125, arg_1126) } else { arg_1118 = linked_1122.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1121, arg_1124, arg_1125, arg_1126) }; var arg_1119 any = features__2; var arg_1120 any; if depth__3_b == nil { depth__3_b = jrt.Long_ValueOf_J__Long_NoInit(depth__3_l).Ref(); arg_1120 = depth__3_b } else { arg_1120 = depth__3_b }; if linked_1116 == nil { return ifn_1117.Invoke_O_O_O__O(arg_1118, arg_1119, arg_1120) } else { return linked_1116.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O_O__O(root_1115, arg_1118, arg_1119, arg_1120) } } else {
//line :166:1
				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_62); var tmp9 any; var root_1156 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_1158 lang.IFn

				if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any = s__0; var arg_1160 any = v__9; if linked_1157 == nil { tmp9 = ifn_1158.Invoke_O_O__O(arg_1159, arg_1160) } else { tmp9 = linked_1157.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_1156, arg_1159, arg_1160) }
//line :166:1
				if jrt.J2g_Truth(tmp8.Invoke_O__O(tmp9)) {

					var root_1127 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any; var root_1133 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any = s__0; var arg_1137 any; var na_1139 any = v__9; if jrt.Long_InstanceOf(na_1139) { var n0_1140 int64 = jrt.NN(jrt.Long_Cast(na_1139)).LongValue__J(); if n0_1140 == 9223372036854775807 { arg_1137 = lang.Numbers_Inc_O__Number_NoInit(na_1139) } else { arg_1137 = jrt.Long_ValueOf_J__Long_NoInit(n0_1140 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1139) { var n0_1140_2 float64 = jrt.NN(jrt.Double_Cast(na_1139)).DoubleValue__D(); arg_1137 = jrt.Double_ValueOf_D__Double_NoInit(n0_1140_2 + 1.0).Ref() } else { arg_1137 = lang.Numbers_Inc_O__Number_NoInit(na_1139) } }; var arg_1138 any; var na_1141 any = ve__10; if jrt.Long_InstanceOf(na_1141) { var n0_1142 int64 = jrt.NN(jrt.Long_Cast(na_1141)).LongValue__J(); if n0_1142 == -9223372036854775808 { arg_1138 = lang.Numbers_Dec_O__Number_NoInit(na_1141) } else { arg_1138 = jrt.Long_ValueOf_J__Long_NoInit(n0_1142 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_1141) { var n0_1142_2 float64 = jrt.NN(jrt.Double_Cast(na_1141)).DoubleValue__D(); arg_1138 = jrt.Double_ValueOf_D__Double_NoInit(n0_1142_2 - 1.0).Ref() } else { arg_1138 = lang.Numbers_Dec_O__Number_NoInit(na_1141) } }; if linked_1134 == nil { arg_1130 = ifn_1135.Invoke_O_O_O__O(arg_1136, arg_1137, arg_1138) } else { arg_1130 = linked_1134.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1133, arg_1136, arg_1137, arg_1138) }; var arg_1131 any = features__2; var arg_1132 any; if depth__3_b == nil { depth__3_b = jrt.Long_ValueOf_J__Long_NoInit(depth__3_l).Ref(); arg_1132 = depth__3_b } else { arg_1132 = depth__3_b }; if linked_1128 == nil { return ifn_1129.Invoke_O_O_O__O(arg_1130, arg_1131, arg_1132) } else { return linked_1128.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O_O__O(root_1127, arg_1130, arg_1131, arg_1132) } } else {
//line :166:1
						if A_arbace_repr_clojure_text_A_const_34 != nil {


							var root_1143 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_1145 lang.IFn; if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = s__0; var arg_1147 any = v__9; var arg_1148 any = Lit_24; if linked_1144 == nil { return ifn_1145.Invoke_O_O_O__O(arg_1146, arg_1147, arg_1148) } else { return linked_1144.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_1143, arg_1146, arg_1147, arg_1148) } } else {
//line :166:1
								return nil } } } } }
//line :160:1
func A_arbace_repr_clojure_text_selected_fn__670000038_A_New_O(p0 any) *A_arbace_repr_clojure_text_selected_fn__670000038_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_selected_fn__670000038_A{}; t.Ctor_O(p0); return t }
//line :160:1
func (t *A_arbace_repr_clojure_text_selected_fn__670000038_A) Ctor_O(c__features any) { t.F_features = c__features }
//line :160:1
func (t *A_arbace_repr_clojure_text_selected_fn__670000038_A) Invoke_O_O__O(self, p__670000037__1 any) any { var vec__670000039__2 any = p__670000037__1; var f__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000039__2, lang.RT_IntCast_J__I_NoInit(0), nil); var or__1927000174__auto____4 any; var root_1020 any = A_arbace_repr_clojure_text_A_const_58.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = t.F_features; var arg_1024 any = f__3; if linked_1021 == nil { or__1927000174__auto____4 = ifn_1022.Invoke_O_O__O(arg_1023, arg_1024) } else { or__1927000174__auto____4 = linked_1021.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1020, arg_1023, arg_1024) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(f__3, A_arbace_repr_clojure_text_A_const_59)).Ref() } }










func A_arbace_repr_clojure_text_resolve_STAR__A_New() *A_arbace_repr_clojure_text_resolve_STAR__A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_resolve_STAR__A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_repr_clojure_text_resolve_STAR__A) Ctor() {}
//line :171:1
func (t *A_arbace_repr_clojure_text_resolve_STAR__A) Invoke_O_O_O_O_O__O(self, s__0, features__1, depth0__2, record_QMARK___3 any) any {





	{ var tmp1 any; var root_1161 any = A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any; var root_1165 any = A_arbace_repr_clojure_text_A_const_63.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_1167 lang.IFn; if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any = s__0; var arg_1169 any = Lit_16; if linked_1166 == nil { arg_1164 = ifn_1167.Invoke_O_O__O(arg_1168, arg_1169) } else { arg_1164 = linked_1166.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_1165, arg_1168, arg_1169) }; if linked_1162 == nil { tmp1 = ifn_1163.Invoke_O__O(arg_1164) } else { tmp1 = linked_1162.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1161, arg_1164) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(s__0, lang.PersistentVector_EMPTY.Ref()) } else { var n__5 int32 = lang.RT_Count_O__I_NoInit(s__0); var sb__6 any = jrt.StringBuilder_New(); var i__7 any = lang.RT_Box_J__Number_NoInit(0); var depth__8 any = depth0__2; var recs__9 any; var root_1170 any = A_arbace_repr_clojure_text_A_const_64.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_1172 lang.IFn


		if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = lang.PersistentVector_EMPTY.Ref(); if linked_1171 == nil { recs__9 = ifn_1172.Invoke_O__O(arg_1173) } else { recs__9 = linked_1171.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_1170, arg_1173) }
//line :177:1
	L1: for {



		var tmp2 bool; var na_1174 any = i__7; var na_1175 int64 = int64(n__5); if jrt.Long_InstanceOf(na_1174) { var n0_1176 int64 = jrt.NN(jrt.Long_Cast(na_1174)).LongValue__J(); var n1_1177 int64 = na_1175; tmp2 = n0_1176 >= n1_1177 } else { tmp2 = lang.Numbers_Gte_O_J__Z_NoInit(na_1174, na_1175) }; if tmp2 { var tmp3 any; var root_1201 any = A_arbace_repr_clojure_text_A_const_66.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1203 lang.IFn
			if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = sb__6; if linked_1202 == nil { tmp3 = ifn_1203.Invoke_O__O(arg_1204) } else { tmp3 = linked_1202.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1201, arg_1204) }
//line :181:1
			var tmp4 any = tmp3; var tmp5 any; var root_1205 any = A_arbace_repr_clojure_text_A_const_67.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_1207 lang.IFn
			if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = recs__9; if linked_1206 == nil { tmp5 = ifn_1207.Invoke_O__O(arg_1208) } else { tmp5 = linked_1206.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_1205, arg_1208) }
//line :181:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp5) } else { var c__10 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__7)); var copy__11 any; var tmp6 any = A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A_New_O_O_O(i__7, sb__6, s__0); var tmp7 *jrt.Class
				var fncls__1179 /*line :181:1*/*jrt.Class = A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A_fn_class


				if fncls__1179 == nil { var fncls__1179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A_fn_class = fncls__1179d; tmp7 = fncls__1179d } else { tmp7 = fncls__1179 }; copy__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)
//line :181:1
				var G__670000050__12_ uint16 = c__10



				switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref()) { case 34: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_18) {
					var tmp8 lang.IFn = lang.IFn_Cast(copy__11); var tmp9 any; var root_1209 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1209, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = s__0; var arg_1213 any = i__7; if linked_1210 == nil { tmp9 = ifn_1211.Invoke_O_O__O(arg_1212, arg_1213) } else { if jrt.Long_InstanceOf(arg_1213) { tmp9 = linked_1210.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_1209, arg_1212, jrt.NN(jrt.Long_Cast(arg_1213)).LongValue__J(), arg_1213) } else { tmp9 = linked_1210.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_1209, arg_1212, arg_1213) } }; i__7, depth__8, recs__9 = tmp8.Invoke_O__O(tmp9), depth__8, recs__9; continue L1 }
//line :185:1
				case 35: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_36) { var G__670000051__13_ any; var root_1181 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_1183 lang.IFn





					if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = s__0; var arg_1185 any; var na_1186 any = i__7; if jrt.Long_InstanceOf(na_1186) { var n0_1187 int64 = jrt.NN(jrt.Long_Cast(na_1186)).LongValue__J(); if n0_1187 == 9223372036854775807 { arg_1185 = lang.Numbers_Inc_O__Number_NoInit(na_1186) } else { arg_1185 = jrt.Long_ValueOf_J__Long_NoInit(n0_1187 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1186) { var n0_1187_2 float64 = jrt.NN(jrt.Double_Cast(na_1186)).DoubleValue__D(); arg_1185 = jrt.Double_ValueOf_D__Double_NoInit(n0_1187_2 + 1.0).Ref() } else { arg_1185 = lang.Numbers_Inc_O__Number_NoInit(na_1186) } }; if linked_1182 == nil { G__670000051__13_ = ifn_1183.Invoke_O_O__O(arg_1184, arg_1185) } else { G__670000051__13_ = linked_1182.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_1181, arg_1184, arg_1185) }; switch lang.Util_Hash_O__I_NoInit(G__670000051__13_) { case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__670000051__13_, A_arbace_repr_clojure_text_A_const_37) {

						var tmp10 lang.IFn = lang.IFn_Cast(copy__11); var tmp11 any; var root_1214 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1214, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_1216 lang.IFn; if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any = s__0; var arg_1218 any = i__7; if linked_1215 == nil { tmp11 = ifn_1216.Invoke_O_O__O(arg_1217, arg_1218) } else { tmp11 = linked_1215.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_1214, arg_1217, arg_1218) }; i__7, depth__8, recs__9 = tmp10.Invoke_O__O(tmp11), depth__8, recs__9; continue L1 }
//line :191:1
					case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000051__13_, A_arbace_repr_clojure_text_A_const_18) {
						var tmp12 lang.IFn = lang.IFn_Cast(copy__11); var tmp13 any; var root_1219 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1219, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = s__0; var arg_1223 any; var na_1224 any = i__7; if jrt.Long_InstanceOf(na_1224) { var n0_1225 int64 = jrt.NN(jrt.Long_Cast(na_1224)).LongValue__J(); if n0_1225 == 9223372036854775807 { arg_1223 = lang.Numbers_Inc_O__Number_NoInit(na_1224) } else { arg_1223 = jrt.Long_ValueOf_J__Long_NoInit(n0_1225 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1224) { var n0_1225_2 float64 = jrt.NN(jrt.Double_Cast(na_1224)).DoubleValue__D(); arg_1223 = jrt.Double_ValueOf_D__Double_NoInit(n0_1225_2 + 1.0).Ref() } else { arg_1223 = lang.Numbers_Inc_O__Number_NoInit(na_1224) } }; if linked_1220 == nil { tmp13 = ifn_1221.Invoke_O_O__O(arg_1222, arg_1223) } else { if jrt.Long_InstanceOf(arg_1223) { tmp13 = linked_1220.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_1219, arg_1222, jrt.NN(jrt.Long_Cast(arg_1223)).LongValue__J(), arg_1223) } else { tmp13 = linked_1220.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_1219, arg_1222, arg_1223) } }; i__7, depth__8, recs__9 = tmp12.Invoke_O__O(tmp13), depth__8, recs__9; continue L1 }
//line :191:1
					case 63: if lang.Util_Equiv_O_O__Z_NoInit(G__670000051__13_, A_arbace_repr_clojure_text_A_const_51) { var e__14 any; var root_1189 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1189, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_1191 lang.IFn


						if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any = s__0; var arg_1193 any = i__7; if linked_1190 == nil { e__14 = ifn_1191.Invoke_O_O__O(arg_1192, arg_1193) } else { if jrt.Long_InstanceOf(arg_1193) { e__14 = linked_1190.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_1189, arg_1192, jrt.NN(jrt.Long_Cast(arg_1193)).LongValue__J(), arg_1193) } else { e__14 = linked_1190.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_1189, arg_1192, arg_1193) } }
//line :191:1
						var at0__15 int32 = jrt.NN(jrt.StringBuilder_Cast(sb__6)).Length__I(); var r__16 any; var root_1194 any = A_arbace_repr_clojure_text_A_const_65.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1194, A_arbace_repr_clojure_text_selected_A_fn_class); var ifn_1196 lang.IFn




						if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any = s__0; var arg_1198 any = i__7; var arg_1199 any = features__1; var arg_1200 any = depth__8; if linked_1195 == nil { r__16 = ifn_1196.Invoke_O_O_O_O__O(arg_1197, arg_1198, arg_1199, arg_1200) } else { var tmp14 bool; var tmp15 bool; tmp15 = jrt.Long_InstanceOf(arg_1198); if tmp15 { tmp15 = jrt.Long_InstanceOf(arg_1200) }; tmp14 = tmp15; if tmp14 { r__16 = linked_1195.(*A_arbace_repr_clojure_text_selected_A).InvokeSpec_O_O_J_O_O_J_O__O(root_1194, arg_1197, jrt.NN(jrt.Long_Cast(arg_1198)).LongValue__J(), arg_1198, arg_1199, jrt.NN(jrt.Long_Cast(arg_1200)).LongValue__J(), arg_1200) } else { r__16 = linked_1195.(*A_arbace_repr_clojure_text_selected_A).Invoke_O_O_O_O_O__O(root_1194, arg_1197, arg_1198, arg_1199, arg_1200) } }
						jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(jrt.String_Cast(r__16))
						var tmp16 any; if jrt.J2g_Truth(record_QMARK___3) {
							var root_1226 any = A_arbace_repr_clojure_text_A_const_68.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = recs__9; var arg_1230 any; var tmp17 any = A_arbace_repr_clojure_text_A_const_69; var tmp18 any = jrt.Integer_ValueOf_I__Integer_NoInit(at0__15).Ref(); var tmp19 any = A_arbace_repr_clojure_text_A_const_70; var tmp20 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(r__16)).Ref(); var tmp21 any = A_arbace_repr_clojure_text_A_const_71; var tmp22 any; var root_1231 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1231, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1233 lang.IFn; if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any = s__0; var arg_1235 any = i__7; var arg_1236 any = e__14; if linked_1232 == nil { tmp22 = ifn_1233.Invoke_O_O_O__O(arg_1234, arg_1235, arg_1236) } else { tmp22 = linked_1232.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1231, arg_1234, arg_1235, arg_1236) }; arg_1230 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22)); if linked_1227 == nil { tmp16 = ifn_1228.Invoke_O_O__O(arg_1229, arg_1230) } else { tmp16 = linked_1227.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_1226, arg_1229, arg_1230) } } else {
//line :198:1
								tmp16 = recs__9 }; i__7, depth__8, recs__9 = e__14, depth__8, tmp16; continue L1 }
//line :191:1
					default:
					}








					var tmp23 lang.IFn = lang.IFn_Cast(copy__11); var tmp24 jrt.Number_I; var na_1237 any = i__7; if jrt.Long_InstanceOf(na_1237) { var n0_1238 int64 = jrt.NN(jrt.Long_Cast(na_1237)).LongValue__J(); if n0_1238 == 9223372036854775807 { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_1237) } else { tmp24 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1238 + 1)) } } else { if jrt.Double_InstanceOf(na_1237) { var n0_1238_2 float64 = jrt.NN(jrt.Double_Cast(na_1237)).DoubleValue__D(); tmp24 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1238_2 + 1.0)) } else { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_1237) } }; i__7, depth__8, recs__9 = tmp23.Invoke_O__O(tmp24), depth__8, recs__9; continue L1 }
//line :185:1
				case 40: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_19) {



					var tmp25 lang.IFn = lang.IFn_Cast(copy__11); var tmp26 jrt.Number_I; var na_1239 any = i__7; if jrt.Long_InstanceOf(na_1239) { var n0_1240 int64 = jrt.NN(jrt.Long_Cast(na_1239)).LongValue__J(); if n0_1240 == 9223372036854775807 { tmp26 = lang.Numbers_Inc_O__Number_NoInit(na_1239) } else { tmp26 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1240 + 1)) } } else { if jrt.Double_InstanceOf(na_1239) { var n0_1240_2 float64 = jrt.NN(jrt.Double_Cast(na_1239)).DoubleValue__D(); tmp26 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1240_2 + 1.0)) } else { tmp26 = lang.Numbers_Inc_O__Number_NoInit(na_1239) } }; var tmp27 any = tmp25.Invoke_O__O(tmp26); var tmp28 jrt.Number_I; var na_1241 any = depth__8; if jrt.Long_InstanceOf(na_1241) { var n0_1242 int64 = jrt.NN(jrt.Long_Cast(na_1241)).LongValue__J(); if n0_1242 == 9223372036854775807 { tmp28 = lang.Numbers_Inc_O__Number_NoInit(na_1241) } else { tmp28 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1242 + 1)) } } else { if jrt.Double_InstanceOf(na_1241) { var n0_1242_2 float64 = jrt.NN(jrt.Double_Cast(na_1241)).DoubleValue__D(); tmp28 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1242_2 + 1.0)) } else { tmp28 = lang.Numbers_Inc_O__Number_NoInit(na_1241) } }; i__7, depth__8, recs__9 = tmp27, tmp28, recs__9; continue L1 }
//line :185:1
				case 41: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_20) {




					var tmp29 lang.IFn = lang.IFn_Cast(copy__11); var tmp30 jrt.Number_I; var na_1243 any = i__7; if jrt.Long_InstanceOf(na_1243) { var n0_1244 int64 = jrt.NN(jrt.Long_Cast(na_1243)).LongValue__J(); if n0_1244 == 9223372036854775807 { tmp30 = lang.Numbers_Inc_O__Number_NoInit(na_1243) } else { tmp30 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1244 + 1)) } } else { if jrt.Double_InstanceOf(na_1243) { var n0_1244_2 float64 = jrt.NN(jrt.Double_Cast(na_1243)).DoubleValue__D(); tmp30 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1244_2 + 1.0)) } else { tmp30 = lang.Numbers_Inc_O__Number_NoInit(na_1243) } }; var tmp31 any = tmp29.Invoke_O__O(tmp30); var tmp32 jrt.Number_I; var na_1245 any = depth__8; if jrt.Long_InstanceOf(na_1245) { var n0_1246 int64 = jrt.NN(jrt.Long_Cast(na_1245)).LongValue__J(); if n0_1246 == -9223372036854775808 { tmp32 = lang.Numbers_Dec_O__Number_NoInit(na_1245) } else { tmp32 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1246 - 1)) } } else { if jrt.Double_InstanceOf(na_1245) { var n0_1246_2 float64 = jrt.NN(jrt.Double_Cast(na_1245)).DoubleValue__D(); tmp32 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1246_2 - 1.0)) } else { tmp32 = lang.Numbers_Dec_O__Number_NoInit(na_1245) } }; i__7, depth__8, recs__9 = tmp31, lang.Numbers_Max_J_O__O_NoInit(0, tmp32), recs__9; continue L1 }
//line :185:1
				case 59: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_21) {

					var tmp33 lang.IFn = lang.IFn_Cast(copy__11); var tmp34 any; var root_1247 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1247, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_1249 lang.IFn; if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any = s__0; var arg_1251 any = i__7; if linked_1248 == nil { tmp34 = ifn_1249.Invoke_O_O__O(arg_1250, arg_1251) } else { tmp34 = linked_1248.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_1247, arg_1250, arg_1251) }; i__7, depth__8, recs__9 = tmp33.Invoke_O__O(tmp34), depth__8, recs__9; continue L1 }
//line :185:1
				case 91: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_23) {



					var tmp35 lang.IFn = lang.IFn_Cast(copy__11); var tmp36 jrt.Number_I; var na_1252 any = i__7; if jrt.Long_InstanceOf(na_1252) { var n0_1253 int64 = jrt.NN(jrt.Long_Cast(na_1252)).LongValue__J(); if n0_1253 == 9223372036854775807 { tmp36 = lang.Numbers_Inc_O__Number_NoInit(na_1252) } else { tmp36 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1253 + 1)) } } else { if jrt.Double_InstanceOf(na_1252) { var n0_1253_2 float64 = jrt.NN(jrt.Double_Cast(na_1252)).DoubleValue__D(); tmp36 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1253_2 + 1.0)) } else { tmp36 = lang.Numbers_Inc_O__Number_NoInit(na_1252) } }; var tmp37 any = tmp35.Invoke_O__O(tmp36); var tmp38 jrt.Number_I; var na_1254 any = depth__8; if jrt.Long_InstanceOf(na_1254) { var n0_1255 int64 = jrt.NN(jrt.Long_Cast(na_1254)).LongValue__J(); if n0_1255 == 9223372036854775807 { tmp38 = lang.Numbers_Inc_O__Number_NoInit(na_1254) } else { tmp38 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1255 + 1)) } } else { if jrt.Double_InstanceOf(na_1254) { var n0_1255_2 float64 = jrt.NN(jrt.Double_Cast(na_1254)).DoubleValue__D(); tmp38 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1255_2 + 1.0)) } else { tmp38 = lang.Numbers_Inc_O__Number_NoInit(na_1254) } }; i__7, depth__8, recs__9 = tmp37, tmp38, recs__9; continue L1 }
//line :185:1
				case 92: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_24) {


					var tmp39 lang.IFn = lang.IFn_Cast(copy__11); var tmp40 any; var root_1256 any = A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1256, A_arbace_repr_clojure_text_char_end_A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = s__0; var arg_1260 any = i__7; if linked_1257 == nil { tmp40 = ifn_1258.Invoke_O_O__O(arg_1259, arg_1260) } else { if jrt.Long_InstanceOf(arg_1260) { tmp40 = linked_1257.(*A_arbace_repr_clojure_text_char_end_A).InvokeSpec_O_O_J_O__O(root_1256, arg_1259, jrt.NN(jrt.Long_Cast(arg_1260)).LongValue__J(), arg_1260) } else { tmp40 = linked_1257.(*A_arbace_repr_clojure_text_char_end_A).Invoke_O_O_O__O(root_1256, arg_1259, arg_1260) } }; i__7, depth__8, recs__9 = tmp39.Invoke_O__O(tmp40), depth__8, recs__9; continue L1 }
//line :185:1
				case 93: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_25) {




					var tmp41 lang.IFn = lang.IFn_Cast(copy__11); var tmp42 jrt.Number_I; var na_1261 any = i__7; if jrt.Long_InstanceOf(na_1261) { var n0_1262 int64 = jrt.NN(jrt.Long_Cast(na_1261)).LongValue__J(); if n0_1262 == 9223372036854775807 { tmp42 = lang.Numbers_Inc_O__Number_NoInit(na_1261) } else { tmp42 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1262 + 1)) } } else { if jrt.Double_InstanceOf(na_1261) { var n0_1262_2 float64 = jrt.NN(jrt.Double_Cast(na_1261)).DoubleValue__D(); tmp42 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1262_2 + 1.0)) } else { tmp42 = lang.Numbers_Inc_O__Number_NoInit(na_1261) } }; var tmp43 any = tmp41.Invoke_O__O(tmp42); var tmp44 jrt.Number_I; var na_1263 any = depth__8; if jrt.Long_InstanceOf(na_1263) { var n0_1264 int64 = jrt.NN(jrt.Long_Cast(na_1263)).LongValue__J(); if n0_1264 == -9223372036854775808 { tmp44 = lang.Numbers_Dec_O__Number_NoInit(na_1263) } else { tmp44 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1264 - 1)) } } else { if jrt.Double_InstanceOf(na_1263) { var n0_1264_2 float64 = jrt.NN(jrt.Double_Cast(na_1263)).DoubleValue__D(); tmp44 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1264_2 - 1.0)) } else { tmp44 = lang.Numbers_Dec_O__Number_NoInit(na_1263) } }; i__7, depth__8, recs__9 = tmp43, lang.Numbers_Max_J_O__O_NoInit(0, tmp44), recs__9; continue L1 }
//line :185:1
				case 123: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_28) {



					var tmp45 lang.IFn = lang.IFn_Cast(copy__11); var tmp46 jrt.Number_I; var na_1265 any = i__7; if jrt.Long_InstanceOf(na_1265) { var n0_1266 int64 = jrt.NN(jrt.Long_Cast(na_1265)).LongValue__J(); if n0_1266 == 9223372036854775807 { tmp46 = lang.Numbers_Inc_O__Number_NoInit(na_1265) } else { tmp46 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1266 + 1)) } } else { if jrt.Double_InstanceOf(na_1265) { var n0_1266_2 float64 = jrt.NN(jrt.Double_Cast(na_1265)).DoubleValue__D(); tmp46 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1266_2 + 1.0)) } else { tmp46 = lang.Numbers_Inc_O__Number_NoInit(na_1265) } }; var tmp47 any = tmp45.Invoke_O__O(tmp46); var tmp48 jrt.Number_I; var na_1267 any = depth__8; if jrt.Long_InstanceOf(na_1267) { var n0_1268 int64 = jrt.NN(jrt.Long_Cast(na_1267)).LongValue__J(); if n0_1268 == 9223372036854775807 { tmp48 = lang.Numbers_Inc_O__Number_NoInit(na_1267) } else { tmp48 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1268 + 1)) } } else { if jrt.Double_InstanceOf(na_1267) { var n0_1268_2 float64 = jrt.NN(jrt.Double_Cast(na_1267)).DoubleValue__D(); tmp48 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1268_2 + 1.0)) } else { tmp48 = lang.Numbers_Inc_O__Number_NoInit(na_1267) } }; i__7, depth__8, recs__9 = tmp47, tmp48, recs__9; continue L1 }
//line :185:1
				case 125: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_29) {




					var tmp49 lang.IFn = lang.IFn_Cast(copy__11); var tmp50 jrt.Number_I; var na_1269 any = i__7; if jrt.Long_InstanceOf(na_1269) { var n0_1270 int64 = jrt.NN(jrt.Long_Cast(na_1269)).LongValue__J(); if n0_1270 == 9223372036854775807 { tmp50 = lang.Numbers_Inc_O__Number_NoInit(na_1269) } else { tmp50 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1270 + 1)) } } else { if jrt.Double_InstanceOf(na_1269) { var n0_1270_2 float64 = jrt.NN(jrt.Double_Cast(na_1269)).DoubleValue__D(); tmp50 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1270_2 + 1.0)) } else { tmp50 = lang.Numbers_Inc_O__Number_NoInit(na_1269) } }; var tmp51 any = tmp49.Invoke_O__O(tmp50); var tmp52 jrt.Number_I; var na_1271 any = depth__8; if jrt.Long_InstanceOf(na_1271) { var n0_1272 int64 = jrt.NN(jrt.Long_Cast(na_1271)).LongValue__J(); if n0_1272 == -9223372036854775808 { tmp52 = lang.Numbers_Dec_O__Number_NoInit(na_1271) } else { tmp52 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1272 - 1)) } } else { if jrt.Double_InstanceOf(na_1271) { var n0_1272_2 float64 = jrt.NN(jrt.Double_Cast(na_1271)).DoubleValue__D(); tmp52 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1272_2 - 1.0)) } else { tmp52 = lang.Numbers_Dec_O__Number_NoInit(na_1271) } }; i__7, depth__8, recs__9 = tmp51, lang.Numbers_Max_J_O__O_NoInit(0, tmp52), recs__9; continue L1 }
//line :185:1
				default:
				}















				var tmp53 lang.IFn = lang.IFn_Cast(copy__11); var tmp54 any; var tmp55 any; var root_1273 any = A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = jrt.Character_ValueOf_C__Character_NoInit(c__10).Ref(); if linked_1274 == nil { tmp55 = ifn_1275.Invoke_O__O(arg_1276) } else { tmp55 = linked_1274.(*A_arbace_repr_clojure_text_terminating_QMARK__A).Invoke_O_O__O(root_1273, arg_1276) }; if jrt.J2g_Truth(tmp55) { var na_1277 any = i__7; if jrt.Long_InstanceOf(na_1277) { var n0_1278 int64 = jrt.NN(jrt.Long_Cast(na_1277)).LongValue__J(); if n0_1278 == 9223372036854775807 { tmp54 = lang.Numbers_Inc_O__Number_NoInit(na_1277) } else { tmp54 = jrt.Long_ValueOf_J__Long_NoInit(n0_1278 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1277) { var n0_1278_2 float64 = jrt.NN(jrt.Double_Cast(na_1277)).DoubleValue__D(); tmp54 = jrt.Double_ValueOf_D__Double_NoInit(n0_1278_2 + 1.0).Ref() } else { tmp54 = lang.Numbers_Inc_O__Number_NoInit(na_1277) } } } else { var root_1279 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_1281 lang.IFn; if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any = s__0; var arg_1283 any = i__7; if linked_1280 == nil { tmp54 = ifn_1281.Invoke_O_O__O(arg_1282, arg_1283) } else { tmp54 = linked_1280.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_1279, arg_1282, arg_1283) } }; i__7, depth__8, recs__9 = tmp53.Invoke_O__O(tmp54), depth__8, recs__9; continue L1 } } } }
//line :171:1
	panic("j2g: unreachable")
}











func A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :184:1
func (t *A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A) Ctor_O_O_O(c__i, c__sb, c__s any) { t.F_i = c__i; t.F_sb = c__sb; t.F_s = c__s }
//line :184:1
func (t *A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A) Invoke_O_O__O(self, j__1 any) any { var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp2 jrt.CharSequence = jrt.CharSequence_Cast(t.F_s); jrt.NN(tmp1).Append_CharSequence_I_I__StringBuilder(tmp2, lang.RT_IntCast_O__I_NoInit(t.F_i), lang.RT_IntCast_O__I_NoInit(j__1)); return j__1 }



















func A_arbace_repr_clojure_text_resolve_conditionals_A_New() *A_arbace_repr_clojure_text_resolve_conditionals_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_resolve_conditionals_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_A) Ctor() {}
//line :204:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_A) Invoke_O_O_O_O__O(self, s__0, features__1, depth0__2 any) any {





	var root_1284 any = A_arbace_repr_clojure_text_A_const_57.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any; var root_1288 any = A_arbace_repr_clojure_text_A_const_72.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1288, A_arbace_repr_clojure_text_resolve_STAR__A_fn_class); var ifn_1290 lang.IFn; if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any = s__0; var arg_1292 any = features__1; var arg_1293 any = depth0__2; var arg_1294 any = jrt.Boolean_FALSE.Ref(); if linked_1289 == nil { arg_1287 = ifn_1290.Invoke_O_O_O_O__O(arg_1291, arg_1292, arg_1293, arg_1294) } else { arg_1287 = linked_1289.(*A_arbace_repr_clojure_text_resolve_STAR__A).Invoke_O_O_O_O_O__O(root_1288, arg_1291, arg_1292, arg_1293, arg_1294) }; if linked_1285 == nil { return ifn_1286.Invoke_O__O(arg_1287) } else { return linked_1285.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1284, arg_1287) } }
//line :204:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_A) Invoke_O_O_O__O(self, s__0, features__1 any) any {




	var root_1295 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = s__0; var arg_1299 any = features__1; var arg_1300 any = A_arbace_repr_clojure_text_A_const_12; if linked_1296 == nil { return ifn_1297.Invoke_O_O_O__O(arg_1298, arg_1299, arg_1300) } else { return linked_1296.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O_O__O(root_1295, arg_1298, arg_1299, arg_1300) } }
//line :204:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_A) Invoke_O_O__O(self, s__0 any) any {



	var root_1301 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = s__0; var arg_1305 any = A_arbace_repr_clojure_text_A_const_73; if linked_1302 == nil { return ifn_1303.Invoke_O_O__O(arg_1304, arg_1305) } else { return linked_1302.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O__O(root_1301, arg_1304, arg_1305)
	}
}

func A_arbace_repr_clojure_text_record_conditionals_A_New() *A_arbace_repr_clojure_text_record_conditionals_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_record_conditionals_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_repr_clojure_text_record_conditionals_A) Ctor() {}
//line :212:1
func (t *A_arbace_repr_clojure_text_record_conditionals_A) Invoke_O_O_O__O(self, s__0, features__1 any) any { var vec__670000054__3 any; var root_1306 any = A_arbace_repr_clojure_text_A_const_72.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, A_arbace_repr_clojure_text_resolve_STAR__A_fn_class); var ifn_1308 lang.IFn; if





	linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any = s__0; var arg_1310 any = features__1; var arg_1311 any = A_arbace_repr_clojure_text_A_const_12; var arg_1312 any = jrt.Boolean_TRUE.Ref(); if linked_1307 == nil { vec__670000054__3 = ifn_1308.Invoke_O_O_O_O__O(arg_1309, arg_1310, arg_1311, arg_1312) } else { vec__670000054__3 = linked_1307.(*A_arbace_repr_clojure_text_resolve_STAR__A).Invoke_O_O_O_O_O__O(root_1306, arg_1309, arg_1310, arg_1311, arg_1312) }; var t__4 any = /*line :212:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__670000054__3, lang.RT_IntCast_J__I_NoInit(0), nil); var recs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000054__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_text_A_const_71, t__4, A_arbace_repr_clojure_text_A_const_74, recs__5)) }







func A_arbace_repr_clojure_text_restore_conditionals_A_New() *A_arbace_repr_clojure_text_restore_conditionals_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_restore_conditionals_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_repr_clojure_text_restore_conditionals_A) Ctor() {}
//line :220:1
func (t *A_arbace_repr_clojure_text_restore_conditionals_A) Invoke_O_O_O_O__O(self, t__0, conditionals__1, features__2 any) any { var sb__4 any = jrt.StringBuilder_New(); var end__5 any; var root_1313 any = A_arbace_repr_clojure_text_A_const_75.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1315 lang.IFn; if





	linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any; var tmp1 any = A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A_New_O_O_O(sb__4, t__0, features__2); var tmp2 *jrt.Class; var fncls__1382 *jrt.Class = A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A_fn_class; if fncls__1382 == nil { var fncls__1382d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A_fn_class = fncls__1382d; tmp2 = fncls__1382d } else { tmp2 = fncls__1382 }; arg_1316 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1317 any = A_arbace_repr_clojure_text_A_const_12; var arg_1318 any = conditionals__1; if linked_1314 == nil { end__5 = ifn_1315.Invoke_O_O_O__O(arg_1316, arg_1317, arg_1318) } else { end__5 = linked_1314.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1313, arg_1316, arg_1317, arg_1318) };










	jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_CharSequence_I_I__StringBuilder(jrt.CharSequence_Cast(t__0), lang.RT_IntCast_O__I_NoInit(end__5), lang.RT_Count_O__I_NoInit(t__0)); var root_1383 any =
	A_arbace_repr_clojure_text_A_const_66.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = sb__4; if linked_1384 == nil { return ifn_1385.Invoke_O__O(arg_1386) } else { return linked_1384.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1383, arg_1386) } }
//line :226:1
func A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :226:1
func (t *A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A) Ctor_O_O_O(c__sb, c__t, c__features any) { t.F_sb = c__sb; t.F_t = c__t; t.F_features = c__features }
//line :226:1
func (t *A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A) Invoke_O_O_O__O(self, pos__1, p__670000058__2 any) any { var map__670000060__3 any = p__670000058__2; var map__670000060__4 any; if lang.ISeq_InstanceOf(map__670000060__3) { var tmp1 any; var root_1319 any = A_arbace_repr_clojure_text_A_const_76.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1321 lang.IFn; if linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any = map__670000060__3; if linked_1320 == nil { tmp1 = ifn_1321.Invoke_O__O(arg_1322) } else { tmp1 = linked_1320.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1319, arg_1322) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1323 any = A_arbace_repr_clojure_text_A_const_77.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = map__670000060__3; if linked_1324 == nil { tmp2 = ifn_1325.Invoke_O__O(arg_1326) } else { tmp2 = linked_1324.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1323, arg_1326) }; map__670000060__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1327 any = A_arbace_repr_clojure_text_A_const_78.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1327, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1329 lang.IFn; if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any = map__670000060__3; if linked_1328 == nil { tmp3 = ifn_1329.Invoke_O__O(arg_1330) } else { tmp3 = linked_1328.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1327, arg_1330) }; if jrt.J2g_Truth(tmp3) { var root_1331 any = A_arbace_repr_clojure_text_A_const_57.GetRawRoot__O(); var linked_1332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1331, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1333 lang.IFn; if linked_1332 == nil { ifn_1333 = lang.IFn_Cast(root_1331) } else { ifn_1333 = nil }; var arg_1334 any = map__670000060__3; if linked_1332 == nil { map__670000060__4 = ifn_1333.Invoke_O__O(arg_1334) } else { map__670000060__4 = linked_1332.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1331, arg_1334) } } else { map__670000060__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__670000060__4 = map__670000060__3 }; var at__5 any = lang.RT_Get_O_O__O_NoInit(map__670000060__4, A_arbace_repr_clojure_text_A_const_69); var length__6 any = lang.RT_Get_O_O__O_NoInit(map__670000060__4, A_arbace_repr_clojure_text_A_const_70); var text__7 any = lang.RT_Get_O_O__O_NoInit(map__670000060__4, A_arbace_repr_clojure_text_A_const_71); var tmp4 any; var or__1927000174__auto____8 bool; var na_1340 any = at__5; var na_1341 any = pos__1; var tmp5 bool; var tmp6 bool; tmp6 =
																	jrt.Long_InstanceOf(na_1340); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_1341) }; tmp5 = tmp6; if tmp5 { var n0_1342 int64 = jrt.NN(jrt.Long_Cast(na_1340)).LongValue__J(); var n1_1343 int64 = jrt.NN(jrt.Long_Cast(na_1341)).LongValue__J(); or__1927000174__auto____8 = n0_1342 < n1_1343 } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_1340); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_1341) }; tmp7 = tmp8; if tmp7 { var n0_1342_2 float64 = jrt.NN(jrt.Double_Cast(na_1340)).DoubleValue__D(); var n1_1343_2 float64 = jrt.NN(jrt.Double_Cast(na_1341)).DoubleValue__D(); or__1927000174__auto____8 = n0_1342_2 < n1_1343_2 } else { or__1927000174__auto____8 = lang.Numbers_Lt_O_O__Z_NoInit(na_1340, na_1341) } }; if or__1927000174__auto____8 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { var or__1927000174__auto____9 bool; var na_1345 any; var na_1347 any = at__5; var na_1348 any = length__6; var tmp9 bool; var tmp10 bool; tmp10 = jrt.Long_InstanceOf(na_1347); if tmp10 { tmp10 = jrt.Long_InstanceOf(na_1348) }; tmp9 = tmp10; if tmp9 { var n0_1349 int64 = jrt.NN(jrt.Long_Cast(na_1347)).LongValue__J(); var n1_1350 int64 = jrt.NN(jrt.Long_Cast(na_1348)).LongValue__J(); var nr_1351 int64 = n0_1349 + n1_1350; if (n0_1349^nr_1351)&(n1_1350^nr_1351) >= 0 { na_1345 = jrt.Long_ValueOf_J__Long_NoInit(nr_1351).Ref() } else { na_1345 = lang.Numbers_Add_O_O__Number_NoInit(na_1347, na_1348) } } else { var tmp11 bool; var tmp12 bool; tmp12 = jrt.Double_InstanceOf(na_1347); if tmp12 { tmp12 = jrt.Double_InstanceOf(na_1348) }; tmp11 = tmp12; if tmp11 { var n0_1349_2 float64 = jrt.NN(jrt.Double_Cast(na_1347)).DoubleValue__D(); var n1_1350_2 float64 = jrt.NN(jrt.Double_Cast(na_1348)).DoubleValue__D(); na_1345 = jrt.Double_ValueOf_D__Double_NoInit(n0_1349_2 + n1_1350_2).Ref() } else { na_1345 = lang.Numbers_Add_O_O__Number_NoInit(na_1347, na_1348) } }; var na_1346 int64 = int64(lang.RT_Count_O__I_NoInit(t.F_t)); if jrt.Long_InstanceOf(na_1345) { var n0_1352 int64 = jrt.NN(jrt.Long_Cast(na_1345)).LongValue__J(); var n1_1353 int64 = na_1346; or__1927000174__auto____9 = n0_1352 > n1_1353 } else { or__1927000174__auto____9 = lang.Numbers_Gt_O_J__Z_NoInit(na_1345, na_1346) }; if or__1927000174__auto____9 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else {
																		var root_1355 any = A_arbace_repr_clojure_text_A_const_79.GetRawRoot__O(); var linked_1356 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1355, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1357 lang.IFn; if linked_1356 == nil { ifn_1357 = lang.IFn_Cast(root_1355) } else { ifn_1357 = nil }; var arg_1358 any; var root_1360 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1360, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1362 lang.IFn; if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any = t.F_t; var arg_1364 any = at__5; var arg_1365 any; var na_1366 any = at__5; var na_1367 any = length__6; var tmp13 bool; var tmp14 bool; tmp14 = jrt.Long_InstanceOf(na_1366); if tmp14 { tmp14 = jrt.Long_InstanceOf(na_1367) }; tmp13 = tmp14; if tmp13 { var n0_1368 int64 = jrt.NN(jrt.Long_Cast(na_1366)).LongValue__J(); var n1_1369 int64 = jrt.NN(jrt.Long_Cast(na_1367)).LongValue__J(); var nr_1370 int64 = n0_1368 + n1_1369; if (n0_1368^nr_1370)&(n1_1369^nr_1370) >= 0 { arg_1365 = jrt.Long_ValueOf_J__Long_NoInit(nr_1370).Ref() } else { arg_1365 = lang.Numbers_Add_O_O__Number_NoInit(na_1366, na_1367) } } else { var tmp15 bool; var tmp16 bool; tmp16 = jrt.Double_InstanceOf(na_1366); if tmp16 { tmp16 = jrt.Double_InstanceOf(na_1367) }; tmp15 = tmp16; if tmp15 { var n0_1368_2 float64 = jrt.NN(jrt.Double_Cast(na_1366)).DoubleValue__D(); var n1_1369_2 float64 = jrt.NN(jrt.Double_Cast(na_1367)).DoubleValue__D(); arg_1365 = jrt.Double_ValueOf_D__Double_NoInit(n0_1368_2 + n1_1369_2).Ref() } else { arg_1365 = lang.Numbers_Add_O_O__Number_NoInit(na_1366, na_1367) } }; if linked_1361 == nil { arg_1358 = ifn_1362.Invoke_O_O_O__O(arg_1363, arg_1364, arg_1365) } else { arg_1358 = linked_1361.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1360, arg_1363, arg_1364, arg_1365) }; var arg_1359 any; var root_1371 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1373 lang.IFn
																		if linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; var arg_1374 any = text__7; var arg_1375 any = t.F_features; var arg_1376 any = A_arbace_repr_clojure_text_A_const_56; if linked_1372 == nil { arg_1359 = ifn_1373.Invoke_O_O_O__O(arg_1374, arg_1375, arg_1376) } else { arg_1359 = linked_1372.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O_O__O(root_1371, arg_1374, arg_1375, arg_1376) }
//line :228:1
		if linked_1356 == nil { tmp4 = ifn_1357.Invoke_O_O__O(arg_1358, arg_1359) } else { tmp4 = linked_1356.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1355, arg_1358, arg_1359) } } }; if /*line :227:1*/ jrt.J2g_Truth(tmp4) { var tmp17 any; var root_1377 any = A_arbace_repr_clojure_text_A_const_13.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1379 lang.IFn


			if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil, Lit_20), jrt.RefArrayOf(jrt.Object_class, nil, at__5, nil)).Ref(); var arg_1381 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_text_A_const_69, at__5)); if linked_1378 == nil { tmp17 = ifn_1379.Invoke_O_O__O(arg_1380, arg_1381) } else { tmp17 = linked_1378.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1377, arg_1380, arg_1381) }
//line :227:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp17))) }; var tmp18 /*line :233:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp19 jrt.CharSequence = jrt.CharSequence_Cast(t.F_t); jrt.NN(tmp18).Append_CharSequence_I_I__StringBuilder(tmp19, lang.RT_IntCast_O__I_NoInit(pos__1), lang.RT_IntCast_O__I_NoInit(at__5)); var tmp20 /*line :234:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp20).Append_String__StringBuilder(jrt.String_Cast(text__7)); var na_1335 any = at__5; var na_1336 any = length__6; var tmp21 bool; var tmp22 bool; tmp22 =
	jrt.Long_InstanceOf(na_1335); if tmp22 { tmp22 = jrt.Long_InstanceOf(na_1336) }; tmp21 = tmp22; if tmp21 { var n0_1337 int64 = jrt.NN(jrt.Long_Cast(na_1335)).LongValue__J(); var n1_1338 int64 = jrt.NN(jrt.Long_Cast(na_1336)).LongValue__J(); var nr_1339 int64 = n0_1337 + n1_1338; if (n0_1337^nr_1339)&(n1_1338^nr_1339) >= 0 { return jrt.Long_ValueOf_J__Long_NoInit(nr_1339).Ref() } else { return lang.Numbers_Add_O_O__Number_NoInit(na_1335, na_1336) } } else { var tmp23 bool; var tmp24 bool; tmp24 = jrt.Double_InstanceOf(na_1335); if tmp24 { tmp24 = jrt.Double_InstanceOf(na_1336) }; tmp23 = tmp24; if tmp23 { var n0_1337_2 float64 = jrt.NN(jrt.Double_Cast(na_1335)).DoubleValue__D(); var n1_1338_2 float64 = jrt.NN(jrt.Double_Cast(na_1336)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_1337_2 + n1_1338_2).Ref() } else { return lang.Numbers_Add_O_O__Number_NoInit(na_1335, na_1336) } } }






func A_arbace_repr_clojure_text_code_tokens_A_New() *A_arbace_repr_clojure_text_code_tokens_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_code_tokens_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_repr_clojure_text_code_tokens_A) Ctor() {}
//line :242:1
func (t *A_arbace_repr_clojure_text_code_tokens_A) Invoke_O_O__O(self, s__0 any) any { { var n__2 int32 = lang.RT_Count_O__I_NoInit(s__0); var i__3 any = lang.RT_Box_J__Number_NoInit(0); var out__4 any; var root_1387 any = A_arbace_repr_clojure_text_A_const_64.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_1389 lang.IFn




	if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = lang.PersistentVector_EMPTY.Ref(); if linked_1388 == nil { out__4 = ifn_1389.Invoke_O__O(arg_1390) } else { out__4 = linked_1388.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_1387, arg_1390) }
//line :242:1
L1: for {





	var tmp1 bool; var na_1391 any = i__3; var na_1392 int64 = int64(n__2); if jrt.Long_InstanceOf(na_1391) { var n0_1393 int64 = jrt.NN(jrt.Long_Cast(na_1391)).LongValue__J(); var n1_1394 int64 = na_1392; tmp1 = n0_1393 >= n1_1394 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_1391, na_1392) }; if tmp1 {
		var root_1396 any = A_arbace_repr_clojure_text_A_const_67.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = out__4; if linked_1397 == nil { return ifn_1398.Invoke_O__O(arg_1399) } else { return linked_1397.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_1396, arg_1399) } } else {
//line :248:1
			var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__3))


			if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_18)).CharValue__C()) {
				var tmp2 any; var root_1417 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1417, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = s__0; var arg_1421 any = i__3; if linked_1418 == nil { tmp2 = ifn_1419.Invoke_O_O__O(arg_1420, arg_1421) } else { if jrt.Long_InstanceOf(arg_1421) { tmp2 = linked_1418.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_1417, arg_1420, jrt.NN(jrt.Long_Cast(arg_1421)).LongValue__J(), arg_1421) } else { tmp2 = linked_1418.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_1417, arg_1420, arg_1421) } }; i__3, out__4 = tmp2, out__4; continue L1 } else {
//line :251:1
					if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_21)).CharValue__C()) {

						var tmp3 any; var root_1422 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_1424 lang.IFn; if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = s__0; var arg_1426 any = i__3; if linked_1423 == nil { tmp3 = ifn_1424.Invoke_O_O__O(arg_1425, arg_1426) } else { tmp3 = linked_1423.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_1422, arg_1425, arg_1426) }; i__3, out__4 = tmp3, out__4; continue L1 } else {
//line :251:1
							if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_24)).CharValue__C()) {


								var tmp4 any; var root_1427 any = A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1427, A_arbace_repr_clojure_text_char_end_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = s__0; var arg_1431 any = i__3; if linked_1428 == nil { tmp4 = ifn_1429.Invoke_O_O__O(arg_1430, arg_1431) } else { if jrt.Long_InstanceOf(arg_1431) { tmp4 = linked_1428.(*A_arbace_repr_clojure_text_char_end_A).InvokeSpec_O_O_J_O__O(root_1427, arg_1430, jrt.NN(jrt.Long_Cast(arg_1431)).LongValue__J(), arg_1431) } else { tmp4 = linked_1428.(*A_arbace_repr_clojure_text_char_end_A).Invoke_O_O_O__O(root_1427, arg_1430, arg_1431) } }; i__3, out__4 = tmp4, out__4; continue L1 } else {
//line :251:1
									if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C()) { var G__670000065__6_ any; var root_1400 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_1402 lang.IFn



										if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any = s__0; var arg_1404 any; var na_1405 any = i__3; if jrt.Long_InstanceOf(na_1405) { var n0_1406 int64 = jrt.NN(jrt.Long_Cast(na_1405)).LongValue__J(); if n0_1406 == 9223372036854775807 { arg_1404 = lang.Numbers_Inc_O__Number_NoInit(na_1405) } else { arg_1404 = jrt.Long_ValueOf_J__Long_NoInit(n0_1406 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1405) { var n0_1406_2 float64 = jrt.NN(jrt.Double_Cast(na_1405)).DoubleValue__D(); arg_1404 = jrt.Double_ValueOf_D__Double_NoInit(n0_1406_2 + 1.0).Ref() } else { arg_1404 = lang.Numbers_Inc_O__Number_NoInit(na_1405) } }; if linked_1401 == nil { G__670000065__6_ = ifn_1402.Invoke_O_O__O(arg_1403, arg_1404) } else { G__670000065__6_ = linked_1401.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_1400, arg_1403, arg_1404) }; switch lang.Util_Hash_O__I_NoInit(G__670000065__6_) { case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__670000065__6_, A_arbace_repr_clojure_text_A_const_37) {

											var tmp5 any; var root_1432 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_1433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1432, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_1434 lang.IFn; if linked_1433 == nil { ifn_1434 = lang.IFn_Cast(root_1432) } else { ifn_1434 = nil }; var arg_1435 any = s__0; var arg_1436 any = i__3; if linked_1433 == nil { tmp5 = ifn_1434.Invoke_O_O__O(arg_1435, arg_1436) } else { tmp5 = linked_1433.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_1432, arg_1435, arg_1436) }; i__3, out__4 = tmp5, out__4; continue L1 }
//line :255:1
										case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000065__6_, A_arbace_repr_clojure_text_A_const_18) {
											var tmp6 any; var root_1437 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1437, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_1439 lang.IFn; if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = s__0; var arg_1441 any; var na_1442 any = i__3; if jrt.Long_InstanceOf(na_1442) { var n0_1443 int64 = jrt.NN(jrt.Long_Cast(na_1442)).LongValue__J(); if n0_1443 == 9223372036854775807 { arg_1441 = lang.Numbers_Inc_O__Number_NoInit(na_1442) } else { arg_1441 = jrt.Long_ValueOf_J__Long_NoInit(n0_1443 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1442) { var n0_1443_2 float64 = jrt.NN(jrt.Double_Cast(na_1442)).DoubleValue__D(); arg_1441 = jrt.Double_ValueOf_D__Double_NoInit(n0_1443_2 + 1.0).Ref() } else { arg_1441 = lang.Numbers_Inc_O__Number_NoInit(na_1442) } }; if linked_1438 == nil { tmp6 = ifn_1439.Invoke_O_O__O(arg_1440, arg_1441) } else { if jrt.Long_InstanceOf(arg_1441) { tmp6 = linked_1438.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_1437, arg_1440, jrt.NN(jrt.Long_Cast(arg_1441)).LongValue__J(), arg_1441) } else { tmp6 = linked_1438.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_1437, arg_1440, arg_1441) } }; i__3, out__4 = tmp6, out__4; continue L1 }
//line :255:1
										default:
										}

										var tmp7 jrt.Number_I; var na_1444 any = i__3; if jrt.Long_InstanceOf(na_1444) { var n0_1445 int64 = jrt.NN(jrt.Long_Cast(na_1444)).LongValue__J(); if n0_1445 == 9223372036854775807 { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_1444) } else { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1445 + 1)) } } else { if jrt.Double_InstanceOf(na_1444) { var n0_1445_2 float64 = jrt.NN(jrt.Double_Cast(na_1444)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1445_2 + 1.0)) } else { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_1444) } }; i__3, out__4 = tmp7, out__4; continue L1 } else {
//line :251:1
											var tmp8 any; var root_1408 any = A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class); var ifn_1410 lang.IFn







											if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = jrt.Character_ValueOf_C__Character_NoInit(c__5).Ref(); if linked_1409 == nil { tmp8 = ifn_1410.Invoke_O__O(arg_1411) } else { tmp8 = linked_1409.(*A_arbace_repr_clojure_text_terminating_QMARK__A).Invoke_O_O__O(root_1408, arg_1411) }
//line :251:1
											if jrt.J2g_Truth(tmp8) {







												var tmp9 jrt.Number_I; var na_1446 any = i__3; if jrt.Long_InstanceOf(na_1446) { var n0_1447 int64 = jrt.NN(jrt.Long_Cast(na_1446)).LongValue__J(); if n0_1447 == 9223372036854775807 { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_1446) } else { tmp9 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1447 + 1)) } } else { if jrt.Double_InstanceOf(na_1446) { var n0_1447_2 float64 = jrt.NN(jrt.Double_Cast(na_1446)).DoubleValue__D(); tmp9 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1447_2 + 1.0)) } else { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_1446) } }; i__3, out__4 = tmp9, out__4; continue L1 } else {
//line :251:1
													var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_80); if jrt.J2g_Truth(tmp10.Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(c__5).Ref())) {








														var tmp11 jrt.Number_I; var na_1448 any = i__3; if jrt.Long_InstanceOf(na_1448) { var n0_1449 int64 = jrt.NN(jrt.Long_Cast(na_1448)).LongValue__J(); if n0_1449 == 9223372036854775807 { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_1448) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1449 + 1)) } } else { if jrt.Double_InstanceOf(na_1448) { var n0_1449_2 float64 = jrt.NN(jrt.Double_Cast(na_1448)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1449_2 + 1.0)) } else { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_1448) } }; i__3, out__4 = tmp11, out__4; continue L1 } else {
//line :251:1
															if A_arbace_repr_clojure_text_A_const_34 != nil { var e__6 any; var root_1412 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_1414 lang.IFn









																if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = s__0; var arg_1416 any = i__3; if linked_1413 == nil { e__6 = ifn_1414.Invoke_O_O__O(arg_1415, arg_1416) } else { e__6 = linked_1413.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_1412, arg_1415, arg_1416) }; var tmp12 any; var root_1450 any = A_arbace_repr_clojure_text_A_const_68.GetRawRoot__O(); var linked_1451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1450, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_1452 lang.IFn; if linked_1451 == nil { ifn_1452 = lang.IFn_Cast(root_1450) } else { ifn_1452 = nil }; var arg_1453 any = out__4; var arg_1454 any = lang.Tuple_Create_O_O__IPersistentVector(i__3, e__6); if linked_1451 == nil { tmp12 = ifn_1452.Invoke_O_O__O(arg_1453, arg_1454) } else { tmp12 = linked_1451.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_1450, arg_1453, arg_1454) }; i__3, out__4 = e__6, tmp12; continue L1 } else {
//line :251:1
																	return nil } } } } } } } } } }; /*line :242:1*/panic("j2g: unreachable") }




















func A_arbace_repr_clojure_text_list_spans_A_New() *A_arbace_repr_clojure_text_list_spans_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_list_spans_A{}; t.Ctor(); return t }
//line :263:1
func (t *A_arbace_repr_clojure_text_list_spans_A) Ctor() {}
//line :263:1
func (t *A_arbace_repr_clojure_text_list_spans_A) Invoke_O_O_O__O(self, s__0, pred__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var i__4 any = lang.RT_Box_J__Number_NoInit(0); var out__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




	var tmp1 bool; var na_1455 any = i__4; var na_1456 int64 = int64(n__3); if jrt.Long_InstanceOf(na_1455) { var n0_1457 int64 = jrt.NN(jrt.Long_Cast(na_1455)).LongValue__J(); var n1_1458 int64 = na_1456; tmp1 = n0_1457 >= n1_1458 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_1455, na_1456) }; if tmp1 { return out__5 } else { var c__6 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__4))


		if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_18)).CharValue__C()) {
			var tmp2 any; var root_1510 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1510, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any = s__0; var arg_1514 any = i__4; if linked_1511 == nil { tmp2 = ifn_1512.Invoke_O_O__O(arg_1513, arg_1514) } else { if jrt.Long_InstanceOf(arg_1514) { tmp2 = linked_1511.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_1510, arg_1513, jrt.NN(jrt.Long_Cast(arg_1514)).LongValue__J(), arg_1514) } else { tmp2 = linked_1511.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_1510, arg_1513, arg_1514) } }; i__4, out__5 = tmp2, out__5; continue L1 } else {
//line :271:1
				if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_21)).CharValue__C()) {

					var tmp3 any; var root_1515 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_1516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1515, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_1517 lang.IFn; if linked_1516 == nil { ifn_1517 = lang.IFn_Cast(root_1515) } else { ifn_1517 = nil }; var arg_1518 any = s__0; var arg_1519 any = i__4; if linked_1516 == nil { tmp3 = ifn_1517.Invoke_O_O__O(arg_1518, arg_1519) } else { tmp3 = linked_1516.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_1515, arg_1518, arg_1519) }; i__4, out__5 = tmp3, out__5; continue L1 } else {
//line :271:1
						if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_24)).CharValue__C()) {


							var tmp4 any; var root_1520 any = A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1520, A_arbace_repr_clojure_text_char_end_A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = s__0; var arg_1524 any = i__4; if linked_1521 == nil { tmp4 = ifn_1522.Invoke_O_O__O(arg_1523, arg_1524) } else { if jrt.Long_InstanceOf(arg_1524) { tmp4 = linked_1521.(*A_arbace_repr_clojure_text_char_end_A).InvokeSpec_O_O_J_O__O(root_1520, arg_1523, jrt.NN(jrt.Long_Cast(arg_1524)).LongValue__J(), arg_1524) } else { tmp4 = linked_1521.(*A_arbace_repr_clojure_text_char_end_A).Invoke_O_O_O__O(root_1520, arg_1523, arg_1524) } }; i__4, out__5 = tmp4, out__5; continue L1 } else {
//line :271:1
								var tmp5 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())



								if and__1927000168__auto____7 { var tmp6 any = A_arbace_repr_clojure_text_A_const_18; var tmp7 any; var root_1460 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_1462 lang.IFn; if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any = s__0; var arg_1464 any; var na_1465 any = i__4; if jrt.Long_InstanceOf(na_1465) { var n0_1466 int64 = jrt.NN(jrt.Long_Cast(na_1465)).LongValue__J(); if n0_1466 == 9223372036854775807 { arg_1464 = lang.Numbers_Inc_O__Number_NoInit(na_1465) } else { arg_1464 = jrt.Long_ValueOf_J__Long_NoInit(n0_1466 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1465) { var n0_1466_2 float64 = jrt.NN(jrt.Double_Cast(na_1465)).DoubleValue__D(); arg_1464 = jrt.Double_ValueOf_D__Double_NoInit(n0_1466_2 + 1.0).Ref() } else { arg_1464 = lang.Numbers_Inc_O__Number_NoInit(na_1465) } }; if linked_1461 == nil { tmp7 = ifn_1462.Invoke_O_O__O(arg_1463, arg_1464) } else { tmp7 = linked_1461.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_1460, arg_1463, arg_1464) }; tmp5 = lang.Util_Equiv_O_O__Z_NoInit(tmp6, tmp7) } else { tmp5 = and__1927000168__auto____7 }
//line :271:1
								if tmp5 {



									var tmp8 any; var root_1525 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1525, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_1527 lang.IFn; if linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; var arg_1528 any = s__0; var arg_1529 any; var na_1530 any = i__4; if jrt.Long_InstanceOf(na_1530) { var n0_1531 int64 = jrt.NN(jrt.Long_Cast(na_1530)).LongValue__J(); if n0_1531 == 9223372036854775807 { arg_1529 = lang.Numbers_Inc_O__Number_NoInit(na_1530) } else { arg_1529 = jrt.Long_ValueOf_J__Long_NoInit(n0_1531 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1530) { var n0_1531_2 float64 = jrt.NN(jrt.Double_Cast(na_1530)).DoubleValue__D(); arg_1529 = jrt.Double_ValueOf_D__Double_NoInit(n0_1531_2 + 1.0).Ref() } else { arg_1529 = lang.Numbers_Inc_O__Number_NoInit(na_1530) } }; if linked_1526 == nil { tmp8 = ifn_1527.Invoke_O_O__O(arg_1528, arg_1529) } else { if jrt.Long_InstanceOf(arg_1529) { tmp8 = linked_1526.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_1525, arg_1528, jrt.NN(jrt.Long_Cast(arg_1529)).LongValue__J(), arg_1529) } else { tmp8 = linked_1526.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_1525, arg_1528, arg_1529) } }; i__4, out__5 = tmp8, out__5; continue L1 } else {
//line :271:1
										var tmp9 bool; var and__1927000168__auto____7_2 bool = lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())




										if and__1927000168__auto____7_2 { var tmp10 any = A_arbace_repr_clojure_text_A_const_37; var tmp11 any; var root_1467 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_1469 lang.IFn; if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = s__0; var arg_1471 any; var na_1472 any = i__4; if jrt.Long_InstanceOf(na_1472) { var n0_1473 int64 = jrt.NN(jrt.Long_Cast(na_1472)).LongValue__J(); if n0_1473 == 9223372036854775807 { arg_1471 = lang.Numbers_Inc_O__Number_NoInit(na_1472) } else { arg_1471 = jrt.Long_ValueOf_J__Long_NoInit(n0_1473 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1472) { var n0_1473_2 float64 = jrt.NN(jrt.Double_Cast(na_1472)).DoubleValue__D(); arg_1471 = jrt.Double_ValueOf_D__Double_NoInit(n0_1473_2 + 1.0).Ref() } else { arg_1471 = lang.Numbers_Inc_O__Number_NoInit(na_1472) } }; if linked_1468 == nil { tmp11 = ifn_1469.Invoke_O_O__O(arg_1470, arg_1471) } else { tmp11 = linked_1468.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_1467, arg_1470, arg_1471) }; tmp9 = lang.Util_Equiv_O_O__Z_NoInit(tmp10, tmp11) } else { tmp9 = and__1927000168__auto____7_2 }
//line :271:1
										if tmp9 {




											var tmp12 any; var root_1532 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any = s__0; var arg_1536 any = i__4; if linked_1533 == nil { tmp12 = ifn_1534.Invoke_O_O__O(arg_1535, arg_1536) } else { tmp12 = linked_1533.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_1532, arg_1535, arg_1536) }; i__4, out__5 = tmp12, out__5; continue L1 } else {
//line :271:1
												if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_19)).CharValue__C()) { var h__7 any; var root_1474 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1474, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_1476 lang.IFn






													if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any = s__0; var arg_1478 any; var na_1479 any = i__4; if jrt.Long_InstanceOf(na_1479) { var n0_1480 int64 = jrt.NN(jrt.Long_Cast(na_1479)).LongValue__J(); if n0_1480 == 9223372036854775807 { arg_1478 = lang.Numbers_Inc_O__Number_NoInit(na_1479) } else { arg_1478 = jrt.Long_ValueOf_J__Long_NoInit(n0_1480 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1479) { var n0_1480_2 float64 = jrt.NN(jrt.Double_Cast(na_1479)).DoubleValue__D(); arg_1478 = jrt.Double_ValueOf_D__Double_NoInit(n0_1480_2 + 1.0).Ref() } else { arg_1478 = lang.Numbers_Inc_O__Number_NoInit(na_1479) } }; if linked_1475 == nil { h__7 = ifn_1476.Invoke_O_O__O(arg_1477, arg_1478) } else { h__7 = linked_1475.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_1474, arg_1477, arg_1478) }
//line :271:1
													var head__8 any; var tmp13 any; var and__1927000168__auto____8 bool; var na_1481 any = h__7; var na_1482 int64 = int64(n__3)







													if jrt.Long_InstanceOf(na_1481) { var n0_1483 int64 = jrt.NN(jrt.Long_Cast(na_1481)).LongValue__J(); var n1_1484 int64 = na_1482; and__1927000168__auto____8 = n0_1483 < n1_1484 } else { and__1927000168__auto____8 = lang.Numbers_Lt_O_J__Z_NoInit(na_1481, na_1482) }; if and__1927000168__auto____8 { var root_1486 any = A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1486, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1488 lang.IFn; if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any; var root_1490 any = A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class); var ifn_1492 lang.IFn; if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(h__7))).Ref(); if linked_1491 == nil { arg_1489 = ifn_1492.Invoke_O__O(arg_1493) } else { arg_1489 = linked_1491.(*A_arbace_repr_clojure_text_terminating_QMARK__A).Invoke_O_O__O(root_1490, arg_1493) }; if linked_1487 == nil { tmp13 = ifn_1488.Invoke_O__O(arg_1489) } else { tmp13 = linked_1487.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1486, arg_1489) } } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp13) {
														var root_1494 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_1495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1494, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1496 lang.IFn; if linked_1495 == nil { ifn_1496 = lang.IFn_Cast(root_1494) } else { ifn_1496 = nil }; var arg_1497 any = s__0; var arg_1498 any = h__7; var arg_1499 any; var root_1500 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_1502 lang.IFn; if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any = s__0; var arg_1504 any = h__7; if linked_1501 == nil { arg_1499 = ifn_1502.Invoke_O_O__O(arg_1503, arg_1504) } else { arg_1499 = linked_1501.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_1500, arg_1503, arg_1504) }; if linked_1495 == nil { head__8 = ifn_1496.Invoke_O_O_O__O(arg_1497, arg_1498, arg_1499) } else { head__8 = linked_1495.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1494, arg_1497, arg_1498, arg_1499) } } else {
//line :279:1
															head__8 = nil
														}
													var tmp14 any; var and__1927000168__auto____9 any = head__8; if jrt.J2g_Truth(and__1927000168__auto____9) { tmp14 = lang.IFn_Cast(pred__1).Invoke_O__O(head__8) } else { tmp14 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp14) { var e__9 any; var root_1505 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1505, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_1507 lang.IFn
														if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = s__0; var arg_1509 any = i__4; if linked_1506 == nil { e__9 = ifn_1507.Invoke_O_O__O(arg_1508, arg_1509) } else { if jrt.Long_InstanceOf(arg_1509) { e__9 = linked_1506.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_1505, arg_1508, jrt.NN(jrt.Long_Cast(arg_1509)).LongValue__J(), arg_1509) } else { e__9 = linked_1506.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_1505, arg_1508, arg_1509) } }; var tmp15 any; var root_1537 any = A_arbace_repr_clojure_text_A_const_7.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = out__5; var arg_1541 any = lang.Tuple_Create_O_O__IPersistentVector(i__4, e__9); if linked_1538 == nil { tmp15 = ifn_1539.Invoke_O_O__O(arg_1540, arg_1541) } else { tmp15 = linked_1538.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1537, arg_1540, arg_1541) }; i__4, out__5 = e__9, tmp15; continue L1 } else {
															var tmp16 jrt.Number_I; var na_1542 any = i__4; if jrt.Long_InstanceOf(na_1542) { var n0_1543 int64 = jrt.NN(jrt.Long_Cast(na_1542)).LongValue__J(); if n0_1543 == 9223372036854775807 { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_1542) } else { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1543 + 1)) } } else { if jrt.Double_InstanceOf(na_1542) { var n0_1543_2 float64 = jrt.NN(jrt.Double_Cast(na_1542)).DoubleValue__D(); tmp16 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1543_2 + 1.0)) } else { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_1542) } }; i__4, out__5 = tmp16, out__5; continue L1 } } else {
//line :271:1
																if A_arbace_repr_clojure_text_A_const_34 != nil {












																	var tmp17 jrt.Number_I; var na_1544 any = i__4; if jrt.Long_InstanceOf(na_1544) { var n0_1545 int64 = jrt.NN(jrt.Long_Cast(na_1544)).LongValue__J(); if n0_1545 == 9223372036854775807 { tmp17 = lang.Numbers_Inc_O__Number_NoInit(na_1544) } else { tmp17 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1545 + 1)) } } else { if jrt.Double_InstanceOf(na_1544) { var n0_1545_2 float64 = jrt.NN(jrt.Double_Cast(na_1544)).DoubleValue__D(); tmp17 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1545_2 + 1.0)) } else { tmp17 = lang.Numbers_Inc_O__Number_NoInit(na_1544) } }; i__4, out__5 = tmp17, out__5; continue L1 } else {
//line :271:1
																		return nil } } } } } } } } } }; /*line :263:1*/panic("j2g: unreachable") }







type A_arbace_repr_clojure_text_A struct{ jrt.Object }

var A_arbace_repr_clojure_text_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_text_A_const_0 *lang.Var

var A_arbace_repr_clojure_text_A_const_1 any

var A_arbace_repr_clojure_text_A_const_2 *lang.Var

var A_arbace_repr_clojure_text_A_const_3 any

var A_arbace_repr_clojure_text_A_const_4 *lang.Var

var A_arbace_repr_clojure_text_A_const_5 *lang.Var

var A_arbace_repr_clojure_text_A_const_6 *lang.Var

var A_arbace_repr_clojure_text_A_const_7 *lang.Var

var A_arbace_repr_clojure_text_A_const_8 any

var A_arbace_repr_clojure_text_A_const_9 *lang.Var

var A_arbace_repr_clojure_text_A_const_10 any

var A_arbace_repr_clojure_text_A_const_11 *lang.Var

var A_arbace_repr_clojure_text_A_const_12 any

var A_arbace_repr_clojure_text_A_const_13 *lang.Var

var A_arbace_repr_clojure_text_A_const_14 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_15 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_16 any

var A_arbace_repr_clojure_text_A_const_17 *lang.Var

var A_arbace_repr_clojure_text_A_const_18 any

var A_arbace_repr_clojure_text_A_const_19 any

var A_arbace_repr_clojure_text_A_const_20 any

var A_arbace_repr_clojure_text_A_const_21 any

var A_arbace_repr_clojure_text_A_const_22 any

var A_arbace_repr_clojure_text_A_const_23 any

var A_arbace_repr_clojure_text_A_const_24 any

var A_arbace_repr_clojure_text_A_const_25 any

var A_arbace_repr_clojure_text_A_const_26 any

var A_arbace_repr_clojure_text_A_const_27 any

var A_arbace_repr_clojure_text_A_const_28 any

var A_arbace_repr_clojure_text_A_const_29 any

var A_arbace_repr_clojure_text_A_const_30 any

var A_arbace_repr_clojure_text_A_const_31 *lang.Var

var A_arbace_repr_clojure_text_A_const_32 *lang.Var

var A_arbace_repr_clojure_text_A_const_33 *lang.Var

var A_arbace_repr_clojure_text_A_const_34 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_35 *lang.Var

var A_arbace_repr_clojure_text_A_const_36 any

var A_arbace_repr_clojure_text_A_const_37 any

var A_arbace_repr_clojure_text_A_const_38 *lang.Var

var A_arbace_repr_clojure_text_A_const_39 any

var A_arbace_repr_clojure_text_A_const_40 *lang.Var

var A_arbace_repr_clojure_text_A_const_41 *lang.Var

var A_arbace_repr_clojure_text_A_const_42 *lang.Var

var A_arbace_repr_clojure_text_A_const_43 *lang.Var

var A_arbace_repr_clojure_text_A_const_44 any

var A_arbace_repr_clojure_text_A_const_45 *lang.Var

var A_arbace_repr_clojure_text_A_const_46 *lang.Var

var A_arbace_repr_clojure_text_A_const_47 any

var A_arbace_repr_clojure_text_A_const_48 *lang.Var

var A_arbace_repr_clojure_text_A_const_49 any

var A_arbace_repr_clojure_text_A_const_50 any

var A_arbace_repr_clojure_text_A_const_51 any

var A_arbace_repr_clojure_text_A_const_52 *lang.Var

var A_arbace_repr_clojure_text_A_const_53 *lang.Var

var A_arbace_repr_clojure_text_A_const_54 *lang.Var

var A_arbace_repr_clojure_text_A_const_55 *lang.Var

var A_arbace_repr_clojure_text_A_const_56 any

var A_arbace_repr_clojure_text_A_const_57 *lang.Var

var A_arbace_repr_clojure_text_A_const_58 *lang.Var

var A_arbace_repr_clojure_text_A_const_59 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_60 *lang.Var

var A_arbace_repr_clojure_text_A_const_61 *lang.Var

var A_arbace_repr_clojure_text_A_const_62 any

var A_arbace_repr_clojure_text_A_const_63 *lang.Var

var A_arbace_repr_clojure_text_A_const_64 *lang.Var

var A_arbace_repr_clojure_text_A_const_65 *lang.Var

var A_arbace_repr_clojure_text_A_const_66 *lang.Var

var A_arbace_repr_clojure_text_A_const_67 *lang.Var

var A_arbace_repr_clojure_text_A_const_68 *lang.Var

var A_arbace_repr_clojure_text_A_const_69 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_70 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_71 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_72 *lang.Var

var A_arbace_repr_clojure_text_A_const_73 any

var A_arbace_repr_clojure_text_A_const_74 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_75 *lang.Var

var A_arbace_repr_clojure_text_A_const_76 *lang.Var

var A_arbace_repr_clojure_text_A_const_77 *lang.Var

var A_arbace_repr_clojure_text_A_const_78 *lang.Var

var A_arbace_repr_clojure_text_A_const_79 *lang.Var

var A_arbace_repr_clojure_text_A_const_80 any

var A_arbace_repr_clojure_text_A_init jrt.ClassInit

func A_arbace_repr_clojure_text_A_Init() { if !A_arbace_repr_clojure_text_A_init.Done() { A_arbace_repr_clojure_text_A_init.Run(A_arbace_repr_clojure_text_A_clinit) } }

func A_arbace_repr_clojure_text_A_clinit() { A_arbace_repr_clojure_text_A_clinit_p0(); A_arbace_repr_clojure_text_A_clinit_p1(); A_arbace_repr_clojure_text_A_clinit_p2(); A_arbace_repr_clojure_text_A_clinit_p3(); A_arbace_repr_clojure_text_A_clinit_p4(); A_arbace_repr_clojure_text_A_clinit_p5(); A_arbace_repr_clojure_text_A_clinit_p6() }

func A_arbace_repr_clojure_text_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_text_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 95); A_arbace_repr_clojure_text_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[14]); A_arbace_repr_clojure_text_A_const_1 = A_arbace_repr_clojure_text_A_const_pool.A[15]; A_arbace_repr_clojure_text_A_const_2 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[16]); A_arbace_repr_clojure_text_A_const_3 = A_arbace_repr_clojure_text_A_const_pool.A[17]; A_arbace_repr_clojure_text_A_const_4 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[18]); A_arbace_repr_clojure_text_A_const_5 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[19]); A_arbace_repr_clojure_text_A_const_6 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[20]); A_arbace_repr_clojure_text_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[21]); A_arbace_repr_clojure_text_A_const_8 = A_arbace_repr_clojure_text_A_const_pool.A[22]; A_arbace_repr_clojure_text_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[23]); A_arbace_repr_clojure_text_A_const_10 = A_arbace_repr_clojure_text_A_const_pool.A[24]; A_arbace_repr_clojure_text_A_const_11 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[25]) }

func A_arbace_repr_clojure_text_A_clinit_p1() { A_arbace_repr_clojure_text_A_const_12 = A_arbace_repr_clojure_text_A_const_pool.A[26]; A_arbace_repr_clojure_text_A_const_13 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[27]); A_arbace_repr_clojure_text_A_const_14 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[28]); A_arbace_repr_clojure_text_A_const_15 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[29]); A_arbace_repr_clojure_text_A_const_16 = A_arbace_repr_clojure_text_A_const_pool.A[30]; A_arbace_repr_clojure_text_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[31]); A_arbace_repr_clojure_text_A_const_18 = A_arbace_repr_clojure_text_A_const_pool.A[32]; A_arbace_repr_clojure_text_A_const_19 = A_arbace_repr_clojure_text_A_const_pool.A[33]; A_arbace_repr_clojure_text_A_const_20 = A_arbace_repr_clojure_text_A_const_pool.A[34]; A_arbace_repr_clojure_text_A_const_21 = A_arbace_repr_clojure_text_A_const_pool.A[35]; A_arbace_repr_clojure_text_A_const_22 = A_arbace_repr_clojure_text_A_const_pool.A[36]; A_arbace_repr_clojure_text_A_const_23 = A_arbace_repr_clojure_text_A_const_pool.A[37]; A_arbace_repr_clojure_text_A_const_24 = A_arbace_repr_clojure_text_A_const_pool.A[38]; A_arbace_repr_clojure_text_A_const_25 = A_arbace_repr_clojure_text_A_const_pool.A[39] }

func A_arbace_repr_clojure_text_A_clinit_p2() { A_arbace_repr_clojure_text_A_const_26 = A_arbace_repr_clojure_text_A_const_pool.A[40]; A_arbace_repr_clojure_text_A_const_27 = A_arbace_repr_clojure_text_A_const_pool.A[41]; A_arbace_repr_clojure_text_A_const_28 = A_arbace_repr_clojure_text_A_const_pool.A[42]; A_arbace_repr_clojure_text_A_const_29 = A_arbace_repr_clojure_text_A_const_pool.A[43]; A_arbace_repr_clojure_text_A_const_30 = A_arbace_repr_clojure_text_A_const_pool.A[44]; A_arbace_repr_clojure_text_A_const_31 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[45]); A_arbace_repr_clojure_text_A_const_32 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[46]); A_arbace_repr_clojure_text_A_const_33 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[47]); A_arbace_repr_clojure_text_A_const_34 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[48]); A_arbace_repr_clojure_text_A_const_35 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[49]); A_arbace_repr_clojure_text_A_const_36 = A_arbace_repr_clojure_text_A_const_pool.A[50]; A_arbace_repr_clojure_text_A_const_37 = A_arbace_repr_clojure_text_A_const_pool.A[51]; A_arbace_repr_clojure_text_A_const_38 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[52]); A_arbace_repr_clojure_text_A_const_39 = A_arbace_repr_clojure_text_A_const_pool.A[53] }

func A_arbace_repr_clojure_text_A_clinit_p3() { A_arbace_repr_clojure_text_A_const_40 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[54]); A_arbace_repr_clojure_text_A_const_41 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[55]); A_arbace_repr_clojure_text_A_const_42 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[56]); A_arbace_repr_clojure_text_A_const_43 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[57]); A_arbace_repr_clojure_text_A_const_44 = A_arbace_repr_clojure_text_A_const_pool.A[58]; A_arbace_repr_clojure_text_A_const_45 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[59]); A_arbace_repr_clojure_text_A_const_46 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[60]); A_arbace_repr_clojure_text_A_const_47 = A_arbace_repr_clojure_text_A_const_pool.A[61]; A_arbace_repr_clojure_text_A_const_48 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[62]); A_arbace_repr_clojure_text_A_const_49 = A_arbace_repr_clojure_text_A_const_pool.A[63]; A_arbace_repr_clojure_text_A_const_50 = A_arbace_repr_clojure_text_A_const_pool.A[64]; A_arbace_repr_clojure_text_A_const_51 = A_arbace_repr_clojure_text_A_const_pool.A[65]; A_arbace_repr_clojure_text_A_const_52 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[66]) }

func A_arbace_repr_clojure_text_A_clinit_p4() { A_arbace_repr_clojure_text_A_const_53 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[67]); A_arbace_repr_clojure_text_A_const_54 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[68]); A_arbace_repr_clojure_text_A_const_55 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[69]); A_arbace_repr_clojure_text_A_const_56 = A_arbace_repr_clojure_text_A_const_pool.A[70]; A_arbace_repr_clojure_text_A_const_57 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[71]); A_arbace_repr_clojure_text_A_const_58 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[72]); A_arbace_repr_clojure_text_A_const_59 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[73]); A_arbace_repr_clojure_text_A_const_60 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[74]); A_arbace_repr_clojure_text_A_const_61 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[75]); A_arbace_repr_clojure_text_A_const_62 = A_arbace_repr_clojure_text_A_const_pool.A[76]; A_arbace_repr_clojure_text_A_const_63 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[77]); A_arbace_repr_clojure_text_A_const_64 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[78]) }

func A_arbace_repr_clojure_text_A_clinit_p5() { A_arbace_repr_clojure_text_A_const_65 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[79]); A_arbace_repr_clojure_text_A_const_66 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[80]); A_arbace_repr_clojure_text_A_const_67 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[81]); A_arbace_repr_clojure_text_A_const_68 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[82]); A_arbace_repr_clojure_text_A_const_69 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[83]); A_arbace_repr_clojure_text_A_const_70 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[84]); A_arbace_repr_clojure_text_A_const_71 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[85]); A_arbace_repr_clojure_text_A_const_72 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[86]); A_arbace_repr_clojure_text_A_const_73 = A_arbace_repr_clojure_text_A_const_pool.A[87]; A_arbace_repr_clojure_text_A_const_74 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[88]); A_arbace_repr_clojure_text_A_const_75 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[89]); A_arbace_repr_clojure_text_A_const_76 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[90]) }

func A_arbace_repr_clojure_text_A_clinit_p6() { A_arbace_repr_clojure_text_A_const_77 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[91]); A_arbace_repr_clojure_text_A_const_78 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[92]); A_arbace_repr_clojure_text_A_const_79 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[93]); A_arbace_repr_clojure_text_A_const_80 = A_arbace_repr_clojure_text_A_const_pool.A[94] }

func A_arbace_repr_clojure_text_A_New() *A_arbace_repr_clojure_text_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_text_A) Ctor() {}

func (t *A_arbace_repr_clojure_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_text_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_text_A_class }

func (t *A_arbace_repr_clojure_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_text_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_text_A); return ok }

func A_arbace_repr_clojure_text_A_Cast(x any) *A_arbace_repr_clojure_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_text_A_class)) }; return v }



type A_arbace_repr_clojure_text_at_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_at_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_branches_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_branches_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_char_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_char_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_code_tokens_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_code_tokens_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_coll_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_coll_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_cond_open_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_cond_open_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_cond_open_fn__670000030_A struct{ j2g_header uint64; F_i, F_s any }

var A_arbace_repr_clojure_text_cond_open_fn__670000030_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_eval670000004_A struct{ jrt.Object }

func A_arbace_repr_clojure_text_eval670000004_A_New() *A_arbace_repr_clojure_text_eval670000004_A { t := &A_arbace_repr_clojure_text_eval670000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_text_eval670000004_A) Ctor() {}

func (t *A_arbace_repr_clojure_text_eval670000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_text_eval670000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_text_eval670000004_A_class }

func (t *A_arbace_repr_clojure_text_eval670000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_text_eval670000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_text_eval670000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_text_eval670000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_text_eval670000004_A); return ok }

func A_arbace_repr_clojure_text_eval670000004_A_Cast(x any) *A_arbace_repr_clojure_text_eval670000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_text_eval670000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_text_eval670000004_A_class)) }; return v }



type A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_eval670000008_A struct{ jrt.Object }

func A_arbace_repr_clojure_text_eval670000008_A_New() *A_arbace_repr_clojure_text_eval670000008_A { t := &A_arbace_repr_clojure_text_eval670000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_text_eval670000008_A) Ctor() {}

func (t *A_arbace_repr_clojure_text_eval670000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_text_eval670000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_text_eval670000008_A_class }

func (t *A_arbace_repr_clojure_text_eval670000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_text_eval670000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_text_eval670000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_text_eval670000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_text_eval670000008_A); return ok }

func A_arbace_repr_clojure_text_eval670000008_A_Cast(x any) *A_arbace_repr_clojure_text_eval670000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_text_eval670000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_text_eval670000008_A_class)) }; return v }



type A_arbace_repr_clojure_text_eval670000008_fn__670000009_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_eval670000008_fn__670000009_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_fail_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_fail_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_fail_fn__670000013_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_fail_fn__670000013_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_form_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_form_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_line_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_line_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_list_spans_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_list_spans_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_next_form_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_next_form_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_record_conditionals_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_record_conditionals_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_resolve_STAR__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_resolve_STAR__A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A struct{ j2g_header uint64; F_i, F_sb, F_s any }

var A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_resolve_conditionals_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_restore_conditionals_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_restore_conditionals_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A struct{ j2g_header uint64; F_sb, F_t, F_features any }

var A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_selected_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_selected_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_selected_fn__670000038_A struct{ j2g_header uint64; F_features any }

var A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_skip_ws_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_skip_ws_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_string_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_string_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_terminating_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_token_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_token_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_ws_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_ws_QMARK__A_fn_class *jrt.Class
