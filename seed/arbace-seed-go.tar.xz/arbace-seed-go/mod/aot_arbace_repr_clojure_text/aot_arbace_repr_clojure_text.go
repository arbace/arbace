//line aot_arbace_repr_clojure_text.ae:1
package aot_arbace_repr_clojure_text

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A_New() *A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_text_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_text_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_clojure_text_eval670000008_fn__670000009_A_New() *A_arbace_repr_clojure_text_eval670000008_fn__670000009_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_eval670000008_fn__670000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000008_fn__670000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000008_fn__670000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_repr_clojure_text_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_repr_clojure_text_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_clojure_text_A_const_7.GetRawRoot__O(), A_arbace_repr_clojure_text_A_const_8) }

















func A_arbace_repr_clojure_text_fail_A_New() *A_arbace_repr_clojure_text_fail_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_fail_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_repr_clojure_text_fail_A) Ctor() {}
//line :19:1
func (t *A_arbace_repr_clojure_text_fail_A) Invoke_O_O_O_O__O(self, s__0, i__1, msg__2 any) any { var line__4 int64; var tmp1 any; var root_19 any = A_arbace_repr_clojure_text_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_21 lang.IFn; if
												linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any; var fnbody__25 any = A_arbace_repr_clojure_text_fail_fn__670000013_A_New(); var tmp2 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_repr_clojure_text_fail_fn__670000013_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); A_arbace_repr_clojure_text_fail_fn__670000013_A_fn_class = fncls__24d; tmp2 = fncls__24d } else { tmp2 = fncls__24 }; arg_22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__25, tmp2, nil); var arg_23 any; var root_26 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = s__0; var arg_30 any = A_arbace_repr_clojure_text_A_const_12; var arg_31 any = lang.Numbers_Min_O_J__O_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(s__0))); if linked_27 == nil { arg_23 = ifn_28.Invoke_O_O_O__O(arg_29, arg_30, arg_31) } else { arg_23 = linked_27.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_26, arg_29, arg_30, arg_31) }; if linked_20 == nil { tmp1 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { tmp1 = linked_20.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) }; line__4 = lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp1))); var tmp3 any; var root_32 any = /*line :19:1*/A_arbace_repr_clojure_text_A_const_13.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_34 lang.IFn; if

	linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, msg__2, nil, jrt.Long_ValueOf_J__Long_NoInit(line__4).Ref(), nil)).Ref(); var tmp4 any = A_arbace_repr_clojure_text_A_const_14; var tmp5 any = A_arbace_repr_clojure_text_A_const_15; var arg_36 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, i__1, tmp5, jrt.Long_ValueOf_J__Long_NoInit(line__4).Ref())); if linked_33 == nil { tmp3 = ifn_34.Invoke_O_O__O(arg_35, arg_36) } else { tmp3 = linked_33.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_32, arg_35, arg_36) }; /*line :19:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp3))) }
func A_arbace_repr_clojure_text_fail_fn__670000013_A_New() *A_arbace_repr_clojure_text_fail_fn__670000013_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_fail_fn__670000013_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_repr_clojure_text_fail_fn__670000013_A) Ctor() {}
//line :20:1
func (t *A_arbace_repr_clojure_text_fail_fn__670000013_A) Invoke_O_O__O(self, p1__670000012_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_clojure_text_A_const_10, p1__670000012_SHARP___1)).Ref() }


func A_arbace_repr_clojure_text_ws_QMARK__A_New() *A_arbace_repr_clojure_text_ws_QMARK__A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_ws_QMARK__A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_repr_clojure_text_ws_QMARK__A) Ctor() {}
//line :23:1
func (t *A_arbace_repr_clojure_text_ws_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 bool = jrt.Character_IsWhitespace_C__Z_NoInit(lang.RT_CharCast_O__C_NoInit(c__0)); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(c__0, A_arbace_repr_clojure_text_A_const_16)).Ref() } }

func A_arbace_repr_clojure_text_terminating_QMARK__A_New() *A_arbace_repr_clojure_text_terminating_QMARK__A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_terminating_QMARK__A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_repr_clojure_text_terminating_QMARK__A) Ctor() {}
//line :25:1
func (t *A_arbace_repr_clojure_text_terminating_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 any; var root_37 any = A_arbace_repr_clojure_text_A_const_17.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, A_arbace_repr_clojure_text_ws_QMARK__A_fn_class); var ifn_39 lang.IFn; if



	linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = c__0; if linked_38 == nil { or__1927000174__auto____2 = ifn_39.Invoke_O__O(arg_40) } else { or__1927000174__auto____2 = linked_38.(*A_arbace_repr_clojure_text_ws_QMARK__A).Invoke_O_O__O(root_37, arg_40) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var G__670000017__3_ any = c__0; switch lang.Util_Hash_O__I_NoInit(G__670000017__3_) { case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_18) { return jrt.Boolean_TRUE.Ref() }; case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_19) { return jrt.Boolean_TRUE.Ref() }; case 41: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_20) { return jrt.Boolean_TRUE.Ref() }; case 59: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_21) { return jrt.Boolean_TRUE.Ref() }; case 64: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_22) { return jrt.Boolean_TRUE.Ref() }; case 91: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_23) { return jrt.Boolean_TRUE.Ref() }; case 92: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_24) { return jrt.Boolean_TRUE.Ref() }; case 93: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_25) { return jrt.Boolean_TRUE.Ref() }; case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_26) { return jrt.Boolean_TRUE.Ref() }; case 96: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_27) { return jrt.Boolean_TRUE.Ref() }; case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_28) { return jrt.Boolean_TRUE.Ref() }; case 125: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_29) { return jrt.Boolean_TRUE.Ref() }; case 126: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_30) { return jrt.Boolean_TRUE.Ref() }; default:}; return jrt.Boolean_FALSE.Ref() } }

func A_arbace_repr_clojure_text_at_A_New() *A_arbace_repr_clojure_text_at_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_at_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_repr_clojure_text_at_A) Ctor() {}
//line :31:1
func (t *A_arbace_repr_clojure_text_at_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var tmp1 bool; var na_42 any = i__1; var na_43 int64 = int64(lang.RT_Count_O__I_NoInit(s__0)); if jrt.Long_InstanceOf(na_42) { var n0_44 int64 = jrt.NN(jrt.Long_Cast(na_42)).LongValue__J(); var n1_45 int64 = na_43; tmp1 = n0_44 < n1_45 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_42, na_43) }; if tmp1 { return jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__1))).Ref() } else { return nil } }

func A_arbace_repr_clojure_text_line_end_A_New() *A_arbace_repr_clojure_text_line_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_line_end_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_repr_clojure_text_line_end_A) Ctor() {}
//line :33:1
func (t *A_arbace_repr_clojure_text_line_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 int32 = jrt.NN(jrt.String_Cast(s__0)).IndexOf_String_I__I(Lit_15, lang.RT_IntCast_O__I_NoInit(i__1)); if
												lang.Numbers_IsNeg_J__Z_NoInit(int64(j__3)) { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(s__0)).Ref() } else { return jrt.Integer_ValueOf_I__Integer_NoInit(j__3).Ref() } }

func A_arbace_repr_clojure_text_token_end_A_New() *A_arbace_repr_clojure_text_token_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_token_end_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_repr_clojure_text_token_end_A) Ctor() {}
//line :36:1
func (t *A_arbace_repr_clojure_text_token_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var j__4 any = i__1; L1: for {



	var tmp1 any; var and__1927000168__auto____5 bool; var na_47 any = j__4; var na_48 int64 = int64(n__3); if jrt.Long_InstanceOf(na_47) { var n0_49 int64 = jrt.NN(jrt.Long_Cast(na_47)).LongValue__J(); var n1_50 int64 = na_48; and__1927000168__auto____5 = n0_49 < n1_50 } else { and__1927000168__auto____5 = lang.Numbers_Lt_O_J__Z_NoInit(na_47, na_48) }; if and__1927000168__auto____5 { var root_52 any = A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any; var root_56 any = A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))).Ref(); if linked_57 == nil { arg_55 = ifn_58.Invoke_O__O(arg_59) } else { arg_55 = linked_57.(*A_arbace_repr_clojure_text_terminating_QMARK__A).Invoke_O_O__O(root_56, arg_59) }; if linked_53 == nil { tmp1 = ifn_54.Invoke_O__O(arg_55) } else { tmp1 = linked_53.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_52, arg_55) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp1) { var tmp2 jrt.Number_I; var na_60 any = j__4; if jrt.Long_InstanceOf(na_60) { var n0_61 int64 = jrt.NN(jrt.Long_Cast(na_60)).LongValue__J(); if n0_61 == 9223372036854775807 { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_60) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_61 + 1)) } } else { if jrt.Double_InstanceOf(na_60) { var n0_61_2 float64 = jrt.NN(jrt.Double_Cast(na_60)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_61_2 + 1.0)) } else { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_60) } }; j__4 = tmp2; continue L1 } else { return j__4 } } }; /*line :36:1*/panic("j2g: unreachable") }





func A_arbace_repr_clojure_text_string_end_A_New() *A_arbace_repr_clojure_text_string_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_string_end_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_repr_clojure_text_string_end_A) Ctor() {}
//line :42:1
func (t *A_arbace_repr_clojure_text_string_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_O_J_O__O(self, s__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1) } else { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var j__4 any
												var na_62 any = i__1


	if jrt.Long_InstanceOf(na_62) { var n0_63 int64 = jrt.NN(jrt.Long_Cast(na_62)).LongValue__J(); if n0_63 == 9223372036854775807 { j__4 = lang.Numbers_Inc_O__Number_NoInit(na_62) } else { j__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_63 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_62) { var n0_63_2 float64 = jrt.NN(jrt.Double_Cast(na_62)).DoubleValue__D(); j__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_63_2 + 1.0).Ref() } else { j__4 = lang.Numbers_Inc_O__Number_NoInit(na_62) } }
//line :42:1
L1: for {




	var tmp1 bool; var na_64 any = j__4; var na_65 int64 = int64(n__3); if jrt.Long_InstanceOf(na_64) { var n0_66 int64 = jrt.NN(jrt.Long_Cast(na_64)).LongValue__J(); var n1_67 int64 = na_65; tmp1 = n0_66 >= n1_67 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_64, na_65) }; if tmp1 { var root_69 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = s__0; var arg_73 any = i__1; var arg_74 any = Lit_25; if linked_70 == nil { return ifn_71.Invoke_O_O_O__O(arg_72, arg_73, arg_74) } else { return linked_70.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_69, arg_72, arg_73, arg_74) } } else { if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_24)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))) {
		var tmp2 jrt.Number_I; var na_77 any = j__4; var na_78 int64 = 2; if jrt.Long_InstanceOf(na_77) { var n0_79 int64 = jrt.NN(jrt.Long_Cast(na_77)).LongValue__J(); var n1_80 int64 = na_78; var nr_81 int64 = n0_79 + n1_80; if (n0_79^nr_81)&(n1_80^nr_81) >= 0 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_81)) } else { tmp2 = lang.Numbers_Add_O_J__Number_NoInit(na_77, na_78) } } else { tmp2 = lang.Numbers_Add_O_J__Number_NoInit(na_77, na_78) }; j__4 = tmp2; continue L1 } else {
//line :47:1
			if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_18)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))) {

				var na_75 any = j__4; if jrt.Long_InstanceOf(na_75) { var n0_76 int64 = jrt.NN(jrt.Long_Cast(na_75)).LongValue__J(); if n0_76 == 9223372036854775807 { return lang.Numbers_Inc_O__Number_NoInit(na_75) } else { return jrt.Long_ValueOf_J__Long_NoInit(n0_76 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_75) { var n0_76_2 float64 = jrt.NN(jrt.Double_Cast(na_75)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_76_2 + 1.0).Ref() } else { return lang.Numbers_Inc_O__Number_NoInit(na_75) } } } else {
//line :47:1
					if A_arbace_repr_clojure_text_A_const_34 != nil {


						var tmp3 jrt.Number_I; var na_82 any = j__4; if jrt.Long_InstanceOf(na_82) { var n0_83 int64 = jrt.NN(jrt.Long_Cast(na_82)).LongValue__J(); if n0_83 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_82) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_83 + 1)) } } else { if jrt.Double_InstanceOf(na_82) { var n0_83_2 float64 = jrt.NN(jrt.Double_Cast(na_82)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_83_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_82) } }; j__4 = tmp3; continue L1 } else {
//line :47:1
							return nil } } } } } }; /*line :42:1*/panic("j2g: unreachable") }
//line :42:1
func (t *A_arbace_repr_clojure_text_string_end_A) InvokeSpec_O_O_J_O__O(self, s__0 any, i__1_l int64, i__1_b any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var j__4 any
															var n0_84 int64 = i__1_l


	if n0_84 == 9223372036854775807 { var tmp1 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp1 = i__1_b } else { tmp1 = i__1_b }; j__4 = lang.Numbers_Inc_O__Number_NoInit(tmp1) } else { j__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_84 + 1).Ref() }
//line :42:1
L1: for {




	var tmp2 bool; var na_85 any = j__4; var na_86 int64 = int64(n__3); if jrt.Long_InstanceOf(na_85) { var n0_87 int64 = jrt.NN(jrt.Long_Cast(na_85)).LongValue__J(); var n1_88 int64 = na_86; tmp2 = n0_87 >= n1_88 } else { tmp2 = lang.Numbers_Gte_O_J__Z_NoInit(na_85, na_86) }; if tmp2 { var root_90 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = s__0; var arg_94 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_94 = i__1_b } else { arg_94 = i__1_b }; var arg_95 any = Lit_25; if linked_91 == nil { return ifn_92.Invoke_O_O_O__O(arg_93, arg_94, arg_95) } else { return linked_91.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_90, arg_93, arg_94, arg_95) } } else { if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_24)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))) {
		var tmp3 jrt.Number_I; var na_98 any = j__4; var na_99 int64 = 2; if jrt.Long_InstanceOf(na_98) { var n0_100 int64 = jrt.NN(jrt.Long_Cast(na_98)).LongValue__J(); var n1_101 int64 = na_99; var nr_102 int64 = n0_100 + n1_101; if (n0_100^nr_102)&(n1_101^nr_102) >= 0 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_102)) } else { tmp3 = lang.Numbers_Add_O_J__Number_NoInit(na_98, na_99) } } else { tmp3 = lang.Numbers_Add_O_J__Number_NoInit(na_98, na_99) }; j__4 = tmp3; continue L1 } else {
//line :47:1
			if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_18)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))) {

				var na_96 any = j__4; if jrt.Long_InstanceOf(na_96) { var n0_97 int64 = jrt.NN(jrt.Long_Cast(na_96)).LongValue__J(); if n0_97 == 9223372036854775807 { return lang.Numbers_Inc_O__Number_NoInit(na_96) } else { return jrt.Long_ValueOf_J__Long_NoInit(n0_97 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_96) { var n0_97_2 float64 = jrt.NN(jrt.Double_Cast(na_96)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_97_2 + 1.0).Ref() } else { return lang.Numbers_Inc_O__Number_NoInit(na_96) } } } else {
//line :47:1
					if A_arbace_repr_clojure_text_A_const_34 != nil {


						var tmp4 jrt.Number_I; var na_103 any = j__4; if jrt.Long_InstanceOf(na_103) { var n0_104 int64 = jrt.NN(jrt.Long_Cast(na_103)).LongValue__J(); if n0_104 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_103) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_104 + 1)) } } else { if jrt.Double_InstanceOf(na_103) { var n0_104_2 float64 = jrt.NN(jrt.Double_Cast(na_103)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_104_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_103) } }; j__4 = tmp4; continue L1 } else {
//line :47:1
							return nil } } } } } }; /*line :42:1*/panic("j2g: unreachable") }









func A_arbace_repr_clojure_text_char_end_A_New() *A_arbace_repr_clojure_text_char_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_char_end_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_repr_clojure_text_char_end_A) Ctor() {}
//line :52:1
func (t *A_arbace_repr_clojure_text_char_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_O_J_O__O(self, s__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1) } else {



	var tmp1 bool; var na_115 any; var na_117 any = i__1; if jrt.Long_InstanceOf(na_117) { var n0_118 int64 = jrt.NN(jrt.Long_Cast(na_117)).LongValue__J(); if n0_118 == 9223372036854775807 { na_115 = lang.Numbers_Inc_O__Number_NoInit(na_117) } else { na_115 = jrt.Long_ValueOf_J__Long_NoInit(n0_118 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_117) { var n0_118_2 float64 = jrt.NN(jrt.Double_Cast(na_117)).DoubleValue__D(); na_115 = jrt.Double_ValueOf_D__Double_NoInit(n0_118_2 + 1.0).Ref() } else { na_115 = lang.Numbers_Inc_O__Number_NoInit(na_117) } }; var na_116 int64 = int64(lang.RT_Count_O__I_NoInit(s__0)); if jrt.Long_InstanceOf(na_115) { var n0_119 int64 = jrt.NN(jrt.Long_Cast(na_115)).LongValue__J(); var n1_120 int64 = na_116; tmp1 = n0_119 >= n1_120 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_115, na_116) }; if tmp1 { var root_122 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = s__0; var arg_126 any = i__1; var arg_127 any = Lit_4; if linked_123 == nil { ifn_124.Invoke_O_O_O__O(arg_125, arg_126, arg_127) } else { linked_123.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_122, arg_125, arg_126, arg_127) } }
	var root_105 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = s__0; var arg_109 any; var na_110 any = i__1; var na_111 int64 = 2; if jrt.Long_InstanceOf(na_110) { var n0_112 int64 = jrt.NN(jrt.Long_Cast(na_110)).LongValue__J(); var n1_113 int64 = na_111; var nr_114 int64 = n0_112 + n1_113; if (n0_112^nr_114)&(n1_113^nr_114) >= 0 { arg_109 = jrt.Long_ValueOf_J__Long_NoInit(nr_114).Ref() } else { arg_109 = lang.Numbers_Add_O_J__Number_NoInit(na_110, na_111) } } else { arg_109 = lang.Numbers_Add_O_J__Number_NoInit(na_110, na_111) }; if linked_106 == nil { return ifn_107.Invoke_O_O__O(arg_108, arg_109) } else { return linked_106.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_105, arg_108, arg_109) } } }
//line :52:1
func (t *A_arbace_repr_clojure_text_char_end_A) InvokeSpec_O_O_J_O__O(self, s__0 any, i__1_l int64, i__1_b any) any {



	var tmp1 bool; var na_137 any; var n0_139 int64 = i__1_l; if n0_139 == 9223372036854775807 { var tmp2 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp2 = i__1_b } else { tmp2 = i__1_b }; na_137 = lang.Numbers_Inc_O__Number_NoInit(tmp2) } else { na_137 = jrt.Long_ValueOf_J__Long_NoInit(n0_139 + 1).Ref() }; var na_138 int64 = int64(lang.RT_Count_O__I_NoInit(s__0)); if jrt.Long_InstanceOf(na_137) { var n0_140 int64 = jrt.NN(jrt.Long_Cast(na_137)).LongValue__J(); var n1_141 int64 = na_138; tmp1 = n0_140 >= n1_141 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_137, na_138) }; if tmp1 { var root_143 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = s__0; var arg_147 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_147 = i__1_b } else { arg_147 = i__1_b }; var arg_148 any = Lit_4; if linked_144 == nil { ifn_145.Invoke_O_O_O__O(arg_146, arg_147, arg_148) } else { linked_144.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_143, arg_146, arg_147, arg_148) } }
	var root_128 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = s__0; var arg_132 any; var na_133 int64 = 2; var n0_134 int64 = i__1_l; var n1_135 int64 = na_133; var nr_136 int64 = n0_134 + n1_135; if (n0_134^nr_136)&(n1_135^nr_136) >= 0 { arg_132 = jrt.Long_ValueOf_J__Long_NoInit(nr_136).Ref() } else { var tmp3 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp3 = i__1_b } else { tmp3 = i__1_b }; arg_132 = lang.Numbers_Add_O_J__Number_NoInit(tmp3, na_133) }; if linked_129 == nil { return ifn_130.Invoke_O_O__O(arg_131, arg_132) } else { return linked_129.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_128, arg_131, arg_132)
	}
}

func A_arbace_repr_clojure_text_skip_ws_A_New() *A_arbace_repr_clojure_text_skip_ws_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_skip_ws_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_repr_clojure_text_skip_ws_A) Ctor() {}
//line :61:1
func (t *A_arbace_repr_clojure_text_skip_ws_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var i__4 any = i__1; L1: for {





	var tmp1 bool; var na_149 any = i__4; var na_150 int64 = int64(n__3); if jrt.Long_InstanceOf(na_149) { var n0_151 int64 = jrt.NN(jrt.Long_Cast(na_149)).LongValue__J(); var n1_152 int64 = na_150; tmp1 = n0_151 >= n1_152 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_149, na_150) }; if tmp1 { return i__4 } else { var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__4)); var tmp2 any; var root_154 any = A_arbace_repr_clojure_text_A_const_17.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, A_arbace_repr_clojure_text_ws_QMARK__A_fn_class); var ifn_156 lang.IFn


		if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = jrt.Character_ValueOf_C__Character_NoInit(c__5).Ref(); if linked_155 == nil { tmp2 = ifn_156.Invoke_O__O(arg_157) } else { tmp2 = linked_155.(*A_arbace_repr_clojure_text_ws_QMARK__A).Invoke_O_O__O(root_154, arg_157) }; if jrt.J2g_Truth(tmp2) { var tmp3 jrt.Number_I; var na_172 any = i__4; if jrt.Long_InstanceOf(na_172) { var n0_173 int64 = jrt.NN(jrt.Long_Cast(na_172)).LongValue__J(); if n0_173 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_172) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_173 + 1)) } } else { if jrt.Double_InstanceOf(na_172) { var n0_173_2 float64 = jrt.NN(jrt.Double_Cast(na_172)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_173_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_172) } }; i__4 = tmp3; continue L1 } else { if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_21)).CharValue__C()) {
			var tmp4 any; var root_174 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = s__0; var arg_178 any = i__4; if linked_175 == nil { tmp4 = ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { tmp4 = linked_175.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_174, arg_177, arg_178) }; i__4 = tmp4; continue L1 } else {
//line :70:1
				var tmp5 bool; var and__1927000168__auto____6 bool = lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())

				if and__1927000168__auto____6 { var tmp6 any = A_arbace_repr_clojure_text_A_const_37; var tmp7 any; var root_158 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = s__0; var arg_162 any; var na_163 any = i__4; if jrt.Long_InstanceOf(na_163) { var n0_164 int64 = jrt.NN(jrt.Long_Cast(na_163)).LongValue__J(); if n0_164 == 9223372036854775807 { arg_162 = lang.Numbers_Inc_O__Number_NoInit(na_163) } else { arg_162 = jrt.Long_ValueOf_J__Long_NoInit(n0_164 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_163) { var n0_164_2 float64 = jrt.NN(jrt.Double_Cast(na_163)).DoubleValue__D(); arg_162 = jrt.Double_ValueOf_D__Double_NoInit(n0_164_2 + 1.0).Ref() } else { arg_162 = lang.Numbers_Inc_O__Number_NoInit(na_163) } }; if linked_159 == nil { tmp7 = ifn_160.Invoke_O_O__O(arg_161, arg_162) } else { tmp7 = linked_159.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_158, arg_161, arg_162) }; tmp5 = lang.Util_Equiv_O_O__Z_NoInit(tmp6, tmp7) } else { tmp5 = and__1927000168__auto____6 }
//line :70:1
				if tmp5 {

					var tmp8 any; var root_179 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = s__0; var arg_183 any = i__4; if linked_180 == nil { tmp8 = ifn_181.Invoke_O_O__O(arg_182, arg_183) } else { tmp8 = linked_180.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_179, arg_182, arg_183) }; i__4 = tmp8; continue L1 } else {
//line :70:1
						var tmp9 bool; var and__1927000168__auto____6_2 bool = lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())


						if and__1927000168__auto____6_2 { var tmp10 any = A_arbace_repr_clojure_text_A_const_39; var tmp11 any; var root_165 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = s__0; var arg_169 any; var na_170 any = i__4; if jrt.Long_InstanceOf(na_170) { var n0_171 int64 = jrt.NN(jrt.Long_Cast(na_170)).LongValue__J(); if n0_171 == 9223372036854775807 { arg_169 = lang.Numbers_Inc_O__Number_NoInit(na_170) } else { arg_169 = jrt.Long_ValueOf_J__Long_NoInit(n0_171 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_170) { var n0_171_2 float64 = jrt.NN(jrt.Double_Cast(na_170)).DoubleValue__D(); arg_169 = jrt.Double_ValueOf_D__Double_NoInit(n0_171_2 + 1.0).Ref() } else { arg_169 = lang.Numbers_Inc_O__Number_NoInit(na_170) } }; if linked_166 == nil { tmp11 = ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { tmp11 = linked_166.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_165, arg_168, arg_169) }; tmp9 = lang.Util_Equiv_O_O__Z_NoInit(tmp10, tmp11) } else { tmp9 = and__1927000168__auto____6_2 }
//line :70:1
						if tmp9 {


							var tmp12 any; var root_184 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_184, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = s__0; var arg_188 any; var root_189 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = s__0; var arg_193 any; var na_194 any = i__4; var na_195 int64 = 2; if jrt.Long_InstanceOf(na_194) { var n0_196 int64 = jrt.NN(jrt.Long_Cast(na_194)).LongValue__J(); var n1_197 int64 = na_195; var nr_198 int64 = n0_196 + n1_197; if (n0_196^nr_198)&(n1_197^nr_198) >= 0 { arg_193 = jrt.Long_ValueOf_J__Long_NoInit(nr_198).Ref() } else { arg_193 = lang.Numbers_Add_O_J__Number_NoInit(na_194, na_195) } } else { arg_193 = lang.Numbers_Add_O_J__Number_NoInit(na_194, na_195) }; if linked_190 == nil { arg_188 = ifn_191.Invoke_O_O__O(arg_192, arg_193) } else { arg_188 = linked_190.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_189, arg_192, arg_193) }; if linked_185 == nil { tmp12 = ifn_186.Invoke_O_O__O(arg_187, arg_188) } else { if jrt.Long_InstanceOf(arg_188) { tmp12 = linked_185.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_184, arg_187, jrt.NN(jrt.Long_Cast(arg_188)).LongValue__J(), arg_188) } else { tmp12 = linked_185.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_184, arg_187, arg_188) } }; i__4 = tmp12; continue L1 } else {
//line :70:1
								if A_arbace_repr_clojure_text_A_const_34 != nil { return i__4 } else { return nil } } } } } } } }; /*line :61:1*/panic("j2g: unreachable") }
















func A_arbace_repr_clojure_text_coll_end_A_New() *A_arbace_repr_clojure_text_coll_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_coll_end_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_repr_clojure_text_coll_end_A) Ctor() {}
//line :78:1
func (t *A_arbace_repr_clojure_text_coll_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_O_J_O__O(self, s__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1) } else { var close__3 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_43.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__1))).Ref()); var j__4 any; var root_199 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_201 lang.IFn



	if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = s__0; var arg_203 any; var na_204 any = i__1; if jrt.Long_InstanceOf(na_204) { var n0_205 int64 = jrt.NN(jrt.Long_Cast(na_204)).LongValue__J(); if n0_205 == 9223372036854775807 { arg_203 = lang.Numbers_Inc_O__Number_NoInit(na_204) } else { arg_203 = jrt.Long_ValueOf_J__Long_NoInit(n0_205 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_204) { var n0_205_2 float64 = jrt.NN(jrt.Double_Cast(na_204)).DoubleValue__D(); arg_203 = jrt.Double_ValueOf_D__Double_NoInit(n0_205_2 + 1.0).Ref() } else { arg_203 = lang.Numbers_Inc_O__Number_NoInit(na_204) } }; if linked_200 == nil { j__4 = ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { j__4 = linked_200.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_199, arg_202, arg_203) }
//line :78:1
L1: for { var c__5 any; var root_206 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_208 lang.IFn




	if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = s__0; var arg_210 any = j__4; if linked_207 == nil { c__5 = ifn_208.Invoke_O_O__O(arg_209, arg_210) } else { c__5 = linked_207.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_206, arg_209, arg_210) }
	if lang.Util_Identical_O_O__Z_NoInit(c__5, nil) { var root_211 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = s__0; var arg_215 any = i__1; var arg_216 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, close__3)).Ref(); if linked_212 == nil { return ifn_213.Invoke_O_O_O__O(arg_214, arg_215, arg_216) } else { return linked_212.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_211, arg_214, arg_215, arg_216) } } else { if lang.Util_Equiv_O_O__Z_NoInit(c__5, close__3) {
		var na_217 any = j__4; if jrt.Long_InstanceOf(na_217) { var n0_218 int64 = jrt.NN(jrt.Long_Cast(na_217)).LongValue__J(); if n0_218 == 9223372036854775807 { return lang.Numbers_Inc_O__Number_NoInit(na_217) } else { return jrt.Long_ValueOf_J__Long_NoInit(n0_218 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_217) { var n0_218_2 float64 = jrt.NN(jrt.Double_Cast(na_217)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_218_2 + 1.0).Ref() } else { return lang.Numbers_Inc_O__Number_NoInit(na_217) } } } else {
//line :84:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_44).Invoke_O__O(c__5)) {

				var root_219 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = s__0; var arg_223 any = j__4; var arg_224 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__5)).Ref(); if linked_220 == nil { return ifn_221.Invoke_O_O_O__O(arg_222, arg_223, arg_224) } else { return linked_220.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_219, arg_222, arg_223, arg_224) } } else {
//line :84:1
					if A_arbace_repr_clojure_text_A_const_34 != nil {


						var tmp1 any; var root_225 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = s__0; var arg_229 any; var root_230 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_230, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = s__0; var arg_234 any = j__4; if linked_231 == nil { arg_229 = ifn_232.Invoke_O_O__O(arg_233, arg_234) } else { if jrt.Long_InstanceOf(arg_234) { arg_229 = linked_231.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_230, arg_233, jrt.NN(jrt.Long_Cast(arg_234)).LongValue__J(), arg_234) } else { arg_229 = linked_231.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_230, arg_233, arg_234) } }; if linked_226 == nil { tmp1 = ifn_227.Invoke_O_O__O(arg_228, arg_229) } else { tmp1 = linked_226.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_225, arg_228, arg_229) }; j__4 = tmp1; continue L1 } else {
//line :84:1
							return nil } } } } } }; /*line :78:1*/panic("j2g: unreachable") }
//line :78:1
func (t *A_arbace_repr_clojure_text_coll_end_A) InvokeSpec_O_O_J_O__O(self, s__0 any, i__1_l int64, i__1_b any) any { { var close__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_43.GetRawRoot__O()); var tmp2 *jrt.String = jrt.String_Cast(s__0); var tmp3 any


	if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp3 = i__1_b } else { tmp3 = i__1_b }; close__3 = tmp1.Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(tmp3))).Ref())
//line :78:1
	var j__4 any; var root_235 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_237 lang.IFn



	if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = s__0; var arg_239 any; var n0_240 int64 = i__1_l; if n0_240 == 9223372036854775807 { var tmp4 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp4 = i__1_b } else { tmp4 = i__1_b }; arg_239 = lang.Numbers_Inc_O__Number_NoInit(tmp4) } else { arg_239 = jrt.Long_ValueOf_J__Long_NoInit(n0_240 + 1).Ref() }; if linked_236 == nil { j__4 = ifn_237.Invoke_O_O__O(arg_238, arg_239) } else { j__4 = linked_236.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_235, arg_238, arg_239) }
//line :78:1
L1: for { var c__5 any; var root_241 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_243 lang.IFn




	if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = s__0; var arg_245 any = j__4; if linked_242 == nil { c__5 = ifn_243.Invoke_O_O__O(arg_244, arg_245) } else { c__5 = linked_242.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_241, arg_244, arg_245) }
	if lang.Util_Identical_O_O__Z_NoInit(c__5, nil) { var root_246 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = s__0; var arg_250 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_250 = i__1_b } else { arg_250 = i__1_b }; var arg_251 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, close__3)).Ref(); if linked_247 == nil { return ifn_248.Invoke_O_O_O__O(arg_249, arg_250, arg_251) } else { return linked_247.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_246, arg_249, arg_250, arg_251) } } else { if lang.Util_Equiv_O_O__Z_NoInit(c__5, close__3) {
		var na_252 any = j__4; if jrt.Long_InstanceOf(na_252) { var n0_253 int64 = jrt.NN(jrt.Long_Cast(na_252)).LongValue__J(); if n0_253 == 9223372036854775807 { return lang.Numbers_Inc_O__Number_NoInit(na_252) } else { return jrt.Long_ValueOf_J__Long_NoInit(n0_253 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_252) { var n0_253_2 float64 = jrt.NN(jrt.Double_Cast(na_252)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_253_2 + 1.0).Ref() } else { return lang.Numbers_Inc_O__Number_NoInit(na_252) } } } else {
//line :84:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_44).Invoke_O__O(c__5)) {

				var root_254 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = s__0; var arg_258 any = j__4; var arg_259 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__5)).Ref(); if linked_255 == nil { return ifn_256.Invoke_O_O_O__O(arg_257, arg_258, arg_259) } else { return linked_255.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_254, arg_257, arg_258, arg_259) } } else {
//line :84:1
					if A_arbace_repr_clojure_text_A_const_34 != nil {


						var tmp5 any; var root_260 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = s__0; var arg_264 any; var root_265 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_265, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = s__0; var arg_269 any = j__4; if linked_266 == nil { arg_264 = ifn_267.Invoke_O_O__O(arg_268, arg_269) } else { if jrt.Long_InstanceOf(arg_269) { arg_264 = linked_266.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_265, arg_268, jrt.NN(jrt.Long_Cast(arg_269)).LongValue__J(), arg_269) } else { arg_264 = linked_266.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_265, arg_268, arg_269) } }; if linked_261 == nil { tmp5 = ifn_262.Invoke_O_O__O(arg_263, arg_264) } else { tmp5 = linked_261.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_260, arg_263, arg_264) }; j__4 = tmp5; continue L1 } else {
//line :84:1
							return nil } } } } } }; /*line :78:1*/panic("j2g: unreachable") }










func A_arbace_repr_clojure_text_next_form_end_A_New() *A_arbace_repr_clojure_text_next_form_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_next_form_end_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_repr_clojure_text_next_form_end_A) Ctor() {}
//line :89:1
func (t *A_arbace_repr_clojure_text_next_form_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 any; var root_270 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_272 lang.IFn; if
												linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = s__0; var arg_274 any = i__1; if linked_271 == nil { j__3 = ifn_272.Invoke_O_O__O(arg_273, arg_274) } else { j__3 = linked_271.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_270, arg_273, arg_274) }; var tmp1 bool; var na_280 any = j__3; var na_281 int64 =
												int64(lang.RT_Count_O__I_NoInit(s__0)); if jrt.Long_InstanceOf(na_280) { var n0_282 int64 = jrt.NN(jrt.Long_Cast(na_280)).LongValue__J(); var n1_283 int64 = na_281; tmp1 = n0_282 >= n1_283 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_280, na_281) }; if tmp1 { var root_285 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = s__0; var arg_289 any = i__1; var arg_290 any = Lit_12; if linked_286 == nil { ifn_287.Invoke_O_O_O__O(arg_288, arg_289, arg_290) } else { linked_286.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_285, arg_288, arg_289, arg_290) } }; var root_275 any =
												A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_275, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = s__0; var arg_279 any = j__3; if linked_276 == nil { return ifn_277.Invoke_O_O__O(arg_278, arg_279) } else { if jrt.Long_InstanceOf(arg_279) { return linked_276.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_275, arg_278, jrt.NN(jrt.Long_Cast(arg_279)).LongValue__J(), arg_279) } else { return linked_276.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_275, arg_278, arg_279) } } }

func A_arbace_repr_clojure_text_form_end_A_New() *A_arbace_repr_clojure_text_form_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_form_end_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_repr_clojure_text_form_end_A) Ctor() {}
//line :94:1
func (t *A_arbace_repr_clojure_text_form_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_O_J_O__O(self, s__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1) } else { var c__3 any; var root_291 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_293 lang.IFn


	if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = s__0; var arg_295 any = i__1; if linked_292 == nil { c__3 = ifn_293.Invoke_O_O__O(arg_294, arg_295) } else { c__3 = linked_292.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_291, arg_294, arg_295) }
//line :94:1
	var G__670000027__4_ any = c__3



	switch lang.Util_Hash_O__I_NoInit(G__670000027__4_) { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, nil) {
		var root_297 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = s__0; var arg_301 any = i__1; var arg_302 any = Lit_12; if linked_298 == nil { return ifn_299.Invoke_O_O_O__O(arg_300, arg_301, arg_302) } else { return linked_298.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_297, arg_300, arg_301, arg_302) } }
//line :98:1
	case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_18) {


		var root_303 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_303, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = s__0; var arg_307 any = i__1; if linked_304 == nil { return ifn_305.Invoke_O_O__O(arg_306, arg_307) } else { if jrt.Long_InstanceOf(arg_307) { return linked_304.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_303, arg_306, jrt.NN(jrt.Long_Cast(arg_307)).LongValue__J(), arg_307) } else { return linked_304.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_303, arg_306, arg_307) } } }
//line :98:1
	case 35: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_36) { var d__5 any; var root_308 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_310 lang.IFn








		if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = s__0; var arg_312 any; var na_313 any = i__1; if jrt.Long_InstanceOf(na_313) { var n0_314 int64 = jrt.NN(jrt.Long_Cast(na_313)).LongValue__J(); if n0_314 == 9223372036854775807 { arg_312 = lang.Numbers_Inc_O__Number_NoInit(na_313) } else { arg_312 = jrt.Long_ValueOf_J__Long_NoInit(n0_314 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_313) { var n0_314_2 float64 = jrt.NN(jrt.Double_Cast(na_313)).DoubleValue__D(); arg_312 = jrt.Double_ValueOf_D__Double_NoInit(n0_314_2 + 1.0).Ref() } else { arg_312 = lang.Numbers_Inc_O__Number_NoInit(na_313) } }; if linked_309 == nil { d__5 = ifn_310.Invoke_O_O__O(arg_311, arg_312) } else { d__5 = linked_309.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_308, arg_311, arg_312) }
//line :98:1
		var G__670000028__6_ any = d__5









		switch lang.Util_Hash_O__I_NoInit(G__670000028__6_) { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, nil) {
			var root_316 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = s__0; var arg_320 any = i__1; var arg_321 any = Lit_13; if linked_317 == nil { return ifn_318.Invoke_O_O_O__O(arg_319, arg_320, arg_321) } else { return linked_317.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_316, arg_319, arg_320, arg_321) } }
//line :108:1
		case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_37) {






			var root_322 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = s__0; var arg_326 any; var root_327 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = s__0; var arg_331 any = i__1; if linked_328 == nil { arg_326 = ifn_329.Invoke_O_O__O(arg_330, arg_331) } else { arg_326 = linked_328.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_327, arg_330, arg_331) }; if linked_323 == nil { return ifn_324.Invoke_O_O__O(arg_325, arg_326) } else { return linked_323.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_322, arg_325, arg_326) } }
//line :108:1
		case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_18) {


			var root_332 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_332, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = s__0; var arg_336 any; var na_337 any = i__1; if jrt.Long_InstanceOf(na_337) { var n0_338 int64 = jrt.NN(jrt.Long_Cast(na_337)).LongValue__J(); if n0_338 == 9223372036854775807 { arg_336 = lang.Numbers_Inc_O__Number_NoInit(na_337) } else { arg_336 = jrt.Long_ValueOf_J__Long_NoInit(n0_338 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_337) { var n0_338_2 float64 = jrt.NN(jrt.Double_Cast(na_337)).DoubleValue__D(); arg_336 = jrt.Double_ValueOf_D__Double_NoInit(n0_338_2 + 1.0).Ref() } else { arg_336 = lang.Numbers_Inc_O__Number_NoInit(na_337) } }; if linked_333 == nil { return ifn_334.Invoke_O_O__O(arg_335, arg_336) } else { if jrt.Long_InstanceOf(arg_336) { return linked_333.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_332, arg_335, jrt.NN(jrt.Long_Cast(arg_336)).LongValue__J(), arg_336) } else { return linked_333.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_332, arg_335, arg_336) } } }
//line :108:1
		case 35: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_36) {








			var root_339 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = s__0; var arg_343 any; var na_344 any = i__1; var na_345 int64 = 2; if jrt.Long_InstanceOf(na_344) { var n0_346 int64 = jrt.NN(jrt.Long_Cast(na_344)).LongValue__J(); var n1_347 int64 = na_345; var nr_348 int64 = n0_346 + n1_347; if (n0_346^nr_348)&(n1_347^nr_348) >= 0 { arg_343 = jrt.Long_ValueOf_J__Long_NoInit(nr_348).Ref() } else { arg_343 = lang.Numbers_Add_O_J__Number_NoInit(na_344, na_345) } } else { arg_343 = lang.Numbers_Add_O_J__Number_NoInit(na_344, na_345) }; if linked_340 == nil { return ifn_341.Invoke_O_O__O(arg_342, arg_343) } else { return linked_340.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_339, arg_342, arg_343) } }
//line :108:1
		case 39: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_47) {



			var root_373 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_373, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_375 lang.IFn; if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any = s__0; var arg_377 any; var na_378 any = i__1; var na_379 int64 = 2; if jrt.Long_InstanceOf(na_378) { var n0_380 int64 = jrt.NN(jrt.Long_Cast(na_378)).LongValue__J(); var n1_381 int64 = na_379; var nr_382 int64 = n0_380 + n1_381; if (n0_380^nr_382)&(n1_381^nr_382) >= 0 { arg_377 = jrt.Long_ValueOf_J__Long_NoInit(nr_382).Ref() } else { arg_377 = lang.Numbers_Add_O_J__Number_NoInit(na_378, na_379) } } else { arg_377 = lang.Numbers_Add_O_J__Number_NoInit(na_378, na_379) }; if linked_374 == nil { return ifn_375.Invoke_O_O__O(arg_376, arg_377) } else { return linked_374.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_373, arg_376, arg_377) } }
//line :108:1
		case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_19) {

			var root_383 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_383, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = s__0; var arg_387 any; var na_388 any = i__1; if jrt.Long_InstanceOf(na_388) { var n0_389 int64 = jrt.NN(jrt.Long_Cast(na_388)).LongValue__J(); if n0_389 == 9223372036854775807 { arg_387 = lang.Numbers_Inc_O__Number_NoInit(na_388) } else { arg_387 = jrt.Long_ValueOf_J__Long_NoInit(n0_389 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_388) { var n0_389_2 float64 = jrt.NN(jrt.Double_Cast(na_388)).DoubleValue__D(); arg_387 = jrt.Double_ValueOf_D__Double_NoInit(n0_389_2 + 1.0).Ref() } else { arg_387 = lang.Numbers_Inc_O__Number_NoInit(na_388) } }; if linked_384 == nil { return ifn_385.Invoke_O_O__O(arg_386, arg_387) } else { if jrt.Long_InstanceOf(arg_387) { return linked_384.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_383, arg_386, jrt.NN(jrt.Long_Cast(arg_387)).LongValue__J(), arg_387) } else { return linked_384.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_383, arg_386, arg_387) } } }
//line :108:1
		case 58: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_49) { var j__7 any; var root_390 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_392 lang.IFn









			if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = s__0; var arg_394 any; var root_395 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = s__0; var arg_399 any; var na_400 any = i__1; if jrt.Long_InstanceOf(na_400) { var n0_401 int64 = jrt.NN(jrt.Long_Cast(na_400)).LongValue__J(); if n0_401 == 9223372036854775807 { arg_399 = lang.Numbers_Inc_O__Number_NoInit(na_400) } else { arg_399 = jrt.Long_ValueOf_J__Long_NoInit(n0_401 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_400) { var n0_401_2 float64 = jrt.NN(jrt.Double_Cast(na_400)).DoubleValue__D(); arg_399 = jrt.Double_ValueOf_D__Double_NoInit(n0_401_2 + 1.0).Ref() } else { arg_399 = lang.Numbers_Inc_O__Number_NoInit(na_400) } }; if linked_396 == nil { arg_394 = ifn_397.Invoke_O_O__O(arg_398, arg_399) } else { arg_394 = linked_396.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_395, arg_398, arg_399) }; if linked_391 == nil { j__7 = ifn_392.Invoke_O_O__O(arg_393, arg_394) } else { j__7 = linked_391.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_390, arg_393, arg_394) }
			var tmp1 any = A_arbace_repr_clojure_text_A_const_28; var tmp2 any; var root_417 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = s__0; var arg_421 any = j__7; if linked_418 == nil { tmp2 = ifn_419.Invoke_O_O__O(arg_420, arg_421) } else { tmp2 = linked_418.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_417, arg_420, arg_421) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { } else { var root_422 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = s__0; var arg_426 any = i__1; var arg_427 any = Lit_14; if linked_423 == nil { ifn_424.Invoke_O_O_O__O(arg_425, arg_426, arg_427) } else { linked_423.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_422, arg_425, arg_426, arg_427) } }
			var root_402 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_402, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = s__0; var arg_406 any = j__7; if linked_403 == nil { return ifn_404.Invoke_O_O__O(arg_405, arg_406) } else { if jrt.Long_InstanceOf(arg_406) { return linked_403.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_402, arg_405, jrt.NN(jrt.Long_Cast(arg_406)).LongValue__J(), arg_406) } else { return linked_403.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_402, arg_405, arg_406) } } }
//line :108:1
		case 61: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_50) {



			var root_407 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = s__0; var arg_411 any; var na_412 any = i__1; var na_413 int64 = 2; if jrt.Long_InstanceOf(na_412) { var n0_414 int64 = jrt.NN(jrt.Long_Cast(na_412)).LongValue__J(); var n1_415 int64 = na_413; var nr_416 int64 = n0_414 + n1_415; if (n0_414^nr_416)&(n1_415^nr_416) >= 0 { arg_411 = jrt.Long_ValueOf_J__Long_NoInit(nr_416).Ref() } else { arg_411 = lang.Numbers_Add_O_J__Number_NoInit(na_412, na_413) } } else { arg_411 = lang.Numbers_Add_O_J__Number_NoInit(na_412, na_413) }; if linked_408 == nil { return ifn_409.Invoke_O_O__O(arg_410, arg_411) } else { return linked_408.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_407, arg_410, arg_411) } }
//line :108:1
		case 63: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_51) {







			var root_428 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_428, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = s__0; var arg_432 any; var root_433 any = A_arbace_repr_clojure_text_A_const_52.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, A_arbace_repr_clojure_text_cond_open_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = s__0; var arg_437 any = i__1; if linked_434 == nil { arg_432 = ifn_435.Invoke_O_O__O(arg_436, arg_437) } else { arg_432 = linked_434.(*A_arbace_repr_clojure_text_cond_open_A).Invoke_O_O_O__O(root_433, arg_436, arg_437) }; if linked_429 == nil { return ifn_430.Invoke_O_O__O(arg_431, arg_432) } else { if jrt.Long_InstanceOf(arg_432) { return linked_429.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_428, arg_431, jrt.NN(jrt.Long_Cast(arg_432)).LongValue__J(), arg_432) } else { return linked_429.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_428, arg_431, arg_432) } } }
//line :108:1
		case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_26) {




			var root_438 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = s__0; var arg_442 any; var root_443 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = s__0; var arg_447 any; var na_448 any = i__1; var na_449 int64 = 2; if jrt.Long_InstanceOf(na_448) { var n0_450 int64 = jrt.NN(jrt.Long_Cast(na_448)).LongValue__J(); var n1_451 int64 = na_449; var nr_452 int64 = n0_450 + n1_451; if (n0_450^nr_452)&(n1_451^nr_452) >= 0 { arg_447 = jrt.Long_ValueOf_J__Long_NoInit(nr_452).Ref() } else { arg_447 = lang.Numbers_Add_O_J__Number_NoInit(na_448, na_449) } } else { arg_447 = lang.Numbers_Add_O_J__Number_NoInit(na_448, na_449) }; if linked_444 == nil { arg_442 = ifn_445.Invoke_O_O__O(arg_446, arg_447) } else { arg_442 = linked_444.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_443, arg_446, arg_447) }; if linked_439 == nil { return ifn_440.Invoke_O_O__O(arg_441, arg_442) } else { return linked_439.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_438, arg_441, arg_442) } }
//line :108:1
		case 95: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_39) {





			var root_453 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = s__0; var arg_457 any; var root_458 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = s__0; var arg_462 any; var na_463 any = i__1; var na_464 int64 = 2; if jrt.Long_InstanceOf(na_463) { var n0_465 int64 = jrt.NN(jrt.Long_Cast(na_463)).LongValue__J(); var n1_466 int64 = na_464; var nr_467 int64 = n0_465 + n1_466; if (n0_465^nr_467)&(n1_466^nr_467) >= 0 { arg_462 = jrt.Long_ValueOf_J__Long_NoInit(nr_467).Ref() } else { arg_462 = lang.Numbers_Add_O_J__Number_NoInit(na_463, na_464) } } else { arg_462 = lang.Numbers_Add_O_J__Number_NoInit(na_463, na_464) }; if linked_459 == nil { arg_457 = ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { arg_457 = linked_459.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_458, arg_461, arg_462) }; if linked_454 == nil { return ifn_455.Invoke_O_O__O(arg_456, arg_457) } else { return linked_454.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_453, arg_456, arg_457) } }
//line :108:1
		case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_28) {

			var root_468 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_468, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = s__0; var arg_472 any; var na_473 any = i__1; if jrt.Long_InstanceOf(na_473) { var n0_474 int64 = jrt.NN(jrt.Long_Cast(na_473)).LongValue__J(); if n0_474 == 9223372036854775807 { arg_472 = lang.Numbers_Inc_O__Number_NoInit(na_473) } else { arg_472 = jrt.Long_ValueOf_J__Long_NoInit(n0_474 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_473) { var n0_474_2 float64 = jrt.NN(jrt.Double_Cast(na_473)).DoubleValue__D(); arg_472 = jrt.Double_ValueOf_D__Double_NoInit(n0_474_2 + 1.0).Ref() } else { arg_472 = lang.Numbers_Inc_O__Number_NoInit(na_473) } }; if linked_469 == nil { return ifn_470.Invoke_O_O__O(arg_471, arg_472) } else { if jrt.Long_InstanceOf(arg_472) { return linked_469.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_468, arg_471, jrt.NN(jrt.Long_Cast(arg_472)).LongValue__J(), arg_472) } else { return linked_469.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_468, arg_471, arg_472) } } }
//line :108:1
		default:
		}












		var root_349 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = s__0; var arg_353 any; var root_354 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = s__0; var arg_358 any; var na_359 any = i__1; if jrt.Long_InstanceOf(na_359) { var n0_360 int64 = jrt.NN(jrt.Long_Cast(na_359)).LongValue__J(); if n0_360 == 9223372036854775807 { arg_358 = lang.Numbers_Inc_O__Number_NoInit(na_359) } else { arg_358 = jrt.Long_ValueOf_J__Long_NoInit(n0_360 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_359) { var n0_360_2 float64 = jrt.NN(jrt.Double_Cast(na_359)).DoubleValue__D(); arg_358 = jrt.Double_ValueOf_D__Double_NoInit(n0_360_2 + 1.0).Ref() } else { arg_358 = lang.Numbers_Inc_O__Number_NoInit(na_359) } }; if linked_355 == nil { arg_353 = ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { arg_353 = linked_355.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) }; if linked_350 == nil { return ifn_351.Invoke_O_O__O(arg_352, arg_353) } else { return linked_350.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_349, arg_352, arg_353) } }
//line :98:1
	case 39: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_47) {




		var root_361 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = s__0; var arg_365 any; var na_366 any = i__1; if jrt.Long_InstanceOf(na_366) { var n0_367 int64 = jrt.NN(jrt.Long_Cast(na_366)).LongValue__J(); if n0_367 == 9223372036854775807 { arg_365 = lang.Numbers_Inc_O__Number_NoInit(na_366) } else { arg_365 = jrt.Long_ValueOf_J__Long_NoInit(n0_367 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_366) { var n0_367_2 float64 = jrt.NN(jrt.Double_Cast(na_366)).DoubleValue__D(); arg_365 = jrt.Double_ValueOf_D__Double_NoInit(n0_367_2 + 1.0).Ref() } else { arg_365 = lang.Numbers_Inc_O__Number_NoInit(na_366) } }; if linked_362 == nil { return ifn_363.Invoke_O_O__O(arg_364, arg_365) } else { return linked_362.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_361, arg_364, arg_365) } }
//line :98:1
	case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_19) {

		var root_475 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_475, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = s__0; var arg_479 any = i__1; if linked_476 == nil { return ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { if jrt.Long_InstanceOf(arg_479) { return linked_476.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_475, arg_478, jrt.NN(jrt.Long_Cast(arg_479)).LongValue__J(), arg_479) } else { return linked_476.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) } } }
//line :98:1
	case 41: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_20) {







		var root_480 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = s__0; var arg_484 any = i__1; var arg_485 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref(); if linked_481 == nil { return ifn_482.Invoke_O_O_O__O(arg_483, arg_484, arg_485) } else { return linked_481.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_480, arg_483, arg_484, arg_485) } }
//line :98:1
	case 64: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_22) {




		var root_486 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = s__0; var arg_490 any; var na_491 any = i__1; if jrt.Long_InstanceOf(na_491) { var n0_492 int64 = jrt.NN(jrt.Long_Cast(na_491)).LongValue__J(); if n0_492 == 9223372036854775807 { arg_490 = lang.Numbers_Inc_O__Number_NoInit(na_491) } else { arg_490 = jrt.Long_ValueOf_J__Long_NoInit(n0_492 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_491) { var n0_492_2 float64 = jrt.NN(jrt.Double_Cast(na_491)).DoubleValue__D(); arg_490 = jrt.Double_ValueOf_D__Double_NoInit(n0_492_2 + 1.0).Ref() } else { arg_490 = lang.Numbers_Inc_O__Number_NoInit(na_491) } }; if linked_487 == nil { return ifn_488.Invoke_O_O__O(arg_489, arg_490) } else { return linked_487.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_486, arg_489, arg_490) } }
//line :98:1
	case 91: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_23) {

		var root_493 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_493, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = s__0; var arg_497 any = i__1; if linked_494 == nil { return ifn_495.Invoke_O_O__O(arg_496, arg_497) } else { if jrt.Long_InstanceOf(arg_497) { return linked_494.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_493, arg_496, jrt.NN(jrt.Long_Cast(arg_497)).LongValue__J(), arg_497) } else { return linked_494.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_493, arg_496, arg_497) } } }
//line :98:1
	case 92: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_24) {



		var root_498 any = A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_498, A_arbace_repr_clojure_text_char_end_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = s__0; var arg_502 any = i__1; if linked_499 == nil { return ifn_500.Invoke_O_O__O(arg_501, arg_502) } else { if jrt.Long_InstanceOf(arg_502) { return linked_499.(*A_arbace_repr_clojure_text_char_end_A).InvokeSpec_O_O_J_O__O(root_498, arg_501, jrt.NN(jrt.Long_Cast(arg_502)).LongValue__J(), arg_502) } else { return linked_499.(*A_arbace_repr_clojure_text_char_end_A).Invoke_O_O_O__O(root_498, arg_501, arg_502) } } }
//line :98:1
	case 93: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_25) {







		var root_503 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = s__0; var arg_507 any = i__1; var arg_508 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref(); if linked_504 == nil { return ifn_505.Invoke_O_O_O__O(arg_506, arg_507, arg_508) } else { return linked_504.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_503, arg_506, arg_507, arg_508) } }
//line :98:1
	case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_26) {






		var root_509 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_511 lang.IFn; if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = s__0; var arg_513 any; var root_514 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = s__0; var arg_518 any; var na_519 any = i__1; if jrt.Long_InstanceOf(na_519) { var n0_520 int64 = jrt.NN(jrt.Long_Cast(na_519)).LongValue__J(); if n0_520 == 9223372036854775807 { arg_518 = lang.Numbers_Inc_O__Number_NoInit(na_519) } else { arg_518 = jrt.Long_ValueOf_J__Long_NoInit(n0_520 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_519) { var n0_520_2 float64 = jrt.NN(jrt.Double_Cast(na_519)).DoubleValue__D(); arg_518 = jrt.Double_ValueOf_D__Double_NoInit(n0_520_2 + 1.0).Ref() } else { arg_518 = lang.Numbers_Inc_O__Number_NoInit(na_519) } }; if linked_515 == nil { arg_513 = ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { arg_513 = linked_515.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) }; if linked_510 == nil { return ifn_511.Invoke_O_O__O(arg_512, arg_513) } else { return linked_510.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_509, arg_512, arg_513) } }
//line :98:1
	case 96: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_27) {




		var root_521 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = s__0; var arg_525 any; var na_526 any = i__1; if jrt.Long_InstanceOf(na_526) { var n0_527 int64 = jrt.NN(jrt.Long_Cast(na_526)).LongValue__J(); if n0_527 == 9223372036854775807 { arg_525 = lang.Numbers_Inc_O__Number_NoInit(na_526) } else { arg_525 = jrt.Long_ValueOf_J__Long_NoInit(n0_527 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_526) { var n0_527_2 float64 = jrt.NN(jrt.Double_Cast(na_526)).DoubleValue__D(); arg_525 = jrt.Double_ValueOf_D__Double_NoInit(n0_527_2 + 1.0).Ref() } else { arg_525 = lang.Numbers_Inc_O__Number_NoInit(na_526) } }; if linked_522 == nil { return ifn_523.Invoke_O_O__O(arg_524, arg_525) } else { return linked_522.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_521, arg_524, arg_525) } }
//line :98:1
	case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_28) {

		var root_528 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_528, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = s__0; var arg_532 any = i__1; if linked_529 == nil { return ifn_530.Invoke_O_O__O(arg_531, arg_532) } else { if jrt.Long_InstanceOf(arg_532) { return linked_529.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_528, arg_531, jrt.NN(jrt.Long_Cast(arg_532)).LongValue__J(), arg_532) } else { return linked_529.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_528, arg_531, arg_532) } } }
//line :98:1
	case 125: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_29) {







		var root_533 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = s__0; var arg_537 any = i__1; var arg_538 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref(); if linked_534 == nil { return ifn_535.Invoke_O_O_O__O(arg_536, arg_537, arg_538) } else { return linked_534.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_533, arg_536, arg_537, arg_538) } }
//line :98:1
	case 126: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_30) {





		var root_539 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = s__0; var arg_543 any; var tmp3 any = A_arbace_repr_clojure_text_A_const_22; var tmp4 any; var root_544 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = s__0; var arg_548 any; var na_549 any = i__1; if jrt.Long_InstanceOf(na_549) { var n0_550 int64 = jrt.NN(jrt.Long_Cast(na_549)).LongValue__J(); if n0_550 == 9223372036854775807 { arg_548 = lang.Numbers_Inc_O__Number_NoInit(na_549) } else { arg_548 = jrt.Long_ValueOf_J__Long_NoInit(n0_550 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_549) { var n0_550_2 float64 = jrt.NN(jrt.Double_Cast(na_549)).DoubleValue__D(); arg_548 = jrt.Double_ValueOf_D__Double_NoInit(n0_550_2 + 1.0).Ref() } else { arg_548 = lang.Numbers_Inc_O__Number_NoInit(na_549) } }; if linked_545 == nil { tmp4 = ifn_546.Invoke_O_O__O(arg_547, arg_548) } else { tmp4 = linked_545.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_544, arg_547, arg_548) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4) { var na_551 any = i__1; var na_552 int64 = 2; if jrt.Long_InstanceOf(na_551) { var n0_553 int64 = jrt.NN(jrt.Long_Cast(na_551)).LongValue__J(); var n1_554 int64 = na_552; var nr_555 int64 = n0_553 + n1_554; if (n0_553^nr_555)&(n1_554^nr_555) >= 0 { arg_543 = jrt.Long_ValueOf_J__Long_NoInit(nr_555).Ref() } else { arg_543 = lang.Numbers_Add_O_J__Number_NoInit(na_551, na_552) } } else { arg_543 = lang.Numbers_Add_O_J__Number_NoInit(na_551, na_552) } } else { var na_556 any = i__1; if jrt.Long_InstanceOf(na_556) { var n0_557 int64 = jrt.NN(jrt.Long_Cast(na_556)).LongValue__J(); if n0_557 == 9223372036854775807 { arg_543 = lang.Numbers_Inc_O__Number_NoInit(na_556) } else { arg_543 = jrt.Long_ValueOf_J__Long_NoInit(n0_557 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_556) { var n0_557_2 float64 = jrt.NN(jrt.Double_Cast(na_556)).DoubleValue__D(); arg_543 = jrt.Double_ValueOf_D__Double_NoInit(n0_557_2 + 1.0).Ref() } else { arg_543 = lang.Numbers_Inc_O__Number_NoInit(na_556) } } }; if linked_540 == nil { return ifn_541.Invoke_O_O__O(arg_542, arg_543) } else { return linked_540.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_539, arg_542, arg_543) } }
//line :98:1
	default:
	}























	var root_368 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = s__0; var arg_372 any = i__1; if linked_369 == nil { return ifn_370.Invoke_O_O__O(arg_371, arg_372) } else { return linked_369.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_368, arg_371, arg_372) } } }
//line :94:1
func (t *A_arbace_repr_clojure_text_form_end_A) InvokeSpec_O_O_J_O__O(self, s__0 any, i__1_l int64, i__1_b any) any { var c__3 any; var root_558 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_560 lang.IFn; if


	linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = s__0; var arg_562 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_562 = i__1_b } else { arg_562 = i__1_b }; if linked_559 == nil { c__3 = ifn_560.Invoke_O_O__O(arg_561, arg_562) } else { c__3 = linked_559.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_558, arg_561, arg_562) }; var G__670000027__4_ any = c__3; switch
	lang.Util_Hash_O__I_NoInit(G__670000027__4_) { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, nil) {
		var root_564 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = s__0; var arg_568 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_568 = i__1_b } else { arg_568 = i__1_b }; var arg_569 any = Lit_12; if linked_565 == nil { return ifn_566.Invoke_O_O_O__O(arg_567, arg_568, arg_569) } else { return linked_565.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_564, arg_567, arg_568, arg_569) } }
//line :98:1
	case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_18) {


		var root_570 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_570, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = s__0; if linked_571 == nil { var tmp1 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp1 = i__1_b } else { tmp1 = i__1_b }; return ifn_572.Invoke_O_O__O(arg_573, tmp1) } else { return linked_571.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_570, arg_573, i__1_l, i__1_b) } }
//line :98:1
	case 35: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_36) { var d__5 any; var root_575 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_577 lang.IFn








		if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = s__0; var arg_579 any; var n0_580 int64 = i__1_l; if n0_580 == 9223372036854775807 { var tmp2 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp2 = i__1_b } else { tmp2 = i__1_b }; arg_579 = lang.Numbers_Inc_O__Number_NoInit(tmp2) } else { arg_579 = jrt.Long_ValueOf_J__Long_NoInit(n0_580 + 1).Ref() }; if linked_576 == nil { d__5 = ifn_577.Invoke_O_O__O(arg_578, arg_579) } else { d__5 = linked_576.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_575, arg_578, arg_579) }
//line :98:1
		var G__670000028__6_ any = d__5









		switch lang.Util_Hash_O__I_NoInit(G__670000028__6_) { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, nil) {
			var root_582 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = s__0; var arg_586 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_586 = i__1_b } else { arg_586 = i__1_b }; var arg_587 any = Lit_13; if linked_583 == nil { return ifn_584.Invoke_O_O_O__O(arg_585, arg_586, arg_587) } else { return linked_583.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_582, arg_585, arg_586, arg_587) } }
//line :108:1
		case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_37) {






			var root_588 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = s__0; var arg_592 any; var root_593 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = s__0; var arg_597 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_597 = i__1_b } else { arg_597 = i__1_b }; if linked_594 == nil { arg_592 = ifn_595.Invoke_O_O__O(arg_596, arg_597) } else { arg_592 = linked_594.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_593, arg_596, arg_597) }; if linked_589 == nil { return ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { return linked_589.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_588, arg_591, arg_592) } }
//line :108:1
		case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_18) {


			var root_598 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_598, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = s__0; var arg_602 any; var arg_602_l int64; var n0_603 int64 = i__1_l; if n0_603 == 9223372036854775807 { var tmp3 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp3 = i__1_b } else { tmp3 = i__1_b }; arg_602 = lang.Numbers_Inc_O__Number_NoInit(tmp3); arg_602_l = 0 } else { arg_602_l = n0_603 + 1 }; if linked_599 == nil { var tmp4 any; if arg_602 == nil { tmp4 = jrt.Long_ValueOf_J__Long_NoInit(arg_602_l).Ref() } else { tmp4 = arg_602 }; return ifn_600.Invoke_O_O__O(arg_601, tmp4) } else { var tmp5 bool; var tmp6 bool; tmp6 = arg_602 == nil; if !tmp6 { tmp6 = jrt.Long_InstanceOf(arg_602) }; tmp5 = tmp6; if tmp5 { var tmp7 *A_arbace_repr_clojure_text_string_end_A = linked_599.(*A_arbace_repr_clojure_text_string_end_A); var tmp8 int64; if arg_602 == nil { tmp8 = arg_602_l } else { tmp8 = jrt.NN(jrt.Long_Cast(arg_602)).LongValue__J() }; return tmp7.InvokeSpec_O_O_J_O__O(root_598, arg_601, tmp8, arg_602) } else { var tmp9 *A_arbace_repr_clojure_text_string_end_A = linked_599.(*A_arbace_repr_clojure_text_string_end_A); var tmp10 any; if arg_602 == nil { tmp10 = jrt.Long_ValueOf_J__Long_NoInit(arg_602_l).Ref() } else { tmp10 = arg_602 }; return tmp9.Invoke_O_O_O__O(root_598, arg_601, tmp10) } } }
//line :108:1
		case 35: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_36) {








			var root_604 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = s__0; var arg_608 any; var na_609 int64 = 2; var n0_610 int64 = i__1_l; var n1_611 int64 = na_609; var nr_612 int64 = n0_610 + n1_611; if (n0_610^nr_612)&(n1_611^nr_612) >= 0 { arg_608 = jrt.Long_ValueOf_J__Long_NoInit(nr_612).Ref() } else { var tmp11 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp11 = i__1_b } else { tmp11 = i__1_b }; arg_608 = lang.Numbers_Add_O_J__Number_NoInit(tmp11, na_609) }; if linked_605 == nil { return ifn_606.Invoke_O_O__O(arg_607, arg_608) } else { return linked_605.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_604, arg_607, arg_608) } }
//line :108:1
		case 39: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_47) {



			var root_635 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = s__0; var arg_639 any; var na_640 int64 = 2; var n0_641 int64 = i__1_l; var n1_642 int64 = na_640; var nr_643 int64 = n0_641 + n1_642; if (n0_641^nr_643)&(n1_642^nr_643) >= 0 { arg_639 = jrt.Long_ValueOf_J__Long_NoInit(nr_643).Ref() } else { var tmp12 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp12 = i__1_b } else { tmp12 = i__1_b }; arg_639 = lang.Numbers_Add_O_J__Number_NoInit(tmp12, na_640) }; if linked_636 == nil { return ifn_637.Invoke_O_O__O(arg_638, arg_639) } else { return linked_636.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_635, arg_638, arg_639) } }
//line :108:1
		case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_19) {

			var root_644 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_644, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = s__0; var arg_648 any; var arg_648_l int64; var n0_649 int64 = i__1_l; if n0_649 == 9223372036854775807 { var tmp13 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp13 = i__1_b } else { tmp13 = i__1_b }; arg_648 = lang.Numbers_Inc_O__Number_NoInit(tmp13); arg_648_l = 0 } else { arg_648_l = n0_649 + 1 }; if linked_645 == nil { var tmp14 any; if arg_648 == nil { tmp14 = jrt.Long_ValueOf_J__Long_NoInit(arg_648_l).Ref() } else { tmp14 = arg_648 }; return ifn_646.Invoke_O_O__O(arg_647, tmp14) } else { var tmp15 bool; var tmp16 bool; tmp16 = arg_648 == nil; if !tmp16 { tmp16 = jrt.Long_InstanceOf(arg_648) }; tmp15 = tmp16; if tmp15 { var tmp17 *A_arbace_repr_clojure_text_coll_end_A = linked_645.(*A_arbace_repr_clojure_text_coll_end_A); var tmp18 int64; if arg_648 == nil { tmp18 = arg_648_l } else { tmp18 = jrt.NN(jrt.Long_Cast(arg_648)).LongValue__J() }; return tmp17.InvokeSpec_O_O_J_O__O(root_644, arg_647, tmp18, arg_648) } else { var tmp19 *A_arbace_repr_clojure_text_coll_end_A = linked_645.(*A_arbace_repr_clojure_text_coll_end_A); var tmp20 any; if arg_648 == nil { tmp20 = jrt.Long_ValueOf_J__Long_NoInit(arg_648_l).Ref() } else { tmp20 = arg_648 }; return tmp19.Invoke_O_O_O__O(root_644, arg_647, tmp20) } } }
//line :108:1
		case 58: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_49) { var j__7 any; var root_650 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_652 lang.IFn









			if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = s__0; var arg_654 any; var root_655 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = s__0; var arg_659 any; var n0_660 int64 = i__1_l; if n0_660 == 9223372036854775807 { var tmp21 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp21 = i__1_b } else { tmp21 = i__1_b }; arg_659 = lang.Numbers_Inc_O__Number_NoInit(tmp21) } else { arg_659 = jrt.Long_ValueOf_J__Long_NoInit(n0_660 + 1).Ref() }; if linked_656 == nil { arg_654 = ifn_657.Invoke_O_O__O(arg_658, arg_659) } else { arg_654 = linked_656.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_655, arg_658, arg_659) }; if linked_651 == nil { j__7 = ifn_652.Invoke_O_O__O(arg_653, arg_654) } else { j__7 = linked_651.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_650, arg_653, arg_654) }
			var tmp22 any = A_arbace_repr_clojure_text_A_const_28; var tmp23 any; var root_675 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = s__0; var arg_679 any = j__7; if linked_676 == nil { tmp23 = ifn_677.Invoke_O_O__O(arg_678, arg_679) } else { tmp23 = linked_676.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_675, arg_678, arg_679) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp22, tmp23) { } else { var root_680 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = s__0; var arg_684 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_684 = i__1_b } else { arg_684 = i__1_b }; var arg_685 any = Lit_14; if linked_681 == nil { ifn_682.Invoke_O_O_O__O(arg_683, arg_684, arg_685) } else { linked_681.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_680, arg_683, arg_684, arg_685) } }
			var root_661 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_661, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = s__0; var arg_665 any = j__7; if linked_662 == nil { return ifn_663.Invoke_O_O__O(arg_664, arg_665) } else { if jrt.Long_InstanceOf(arg_665) { return linked_662.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_661, arg_664, jrt.NN(jrt.Long_Cast(arg_665)).LongValue__J(), arg_665) } else { return linked_662.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_661, arg_664, arg_665) } } }
//line :108:1
		case 61: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_50) {



			var root_666 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = s__0; var arg_670 any; var na_671 int64 = 2; var n0_672 int64 = i__1_l; var n1_673 int64 = na_671; var nr_674 int64 = n0_672 + n1_673; if (n0_672^nr_674)&(n1_673^nr_674) >= 0 { arg_670 = jrt.Long_ValueOf_J__Long_NoInit(nr_674).Ref() } else { var tmp24 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp24 = i__1_b } else { tmp24 = i__1_b }; arg_670 = lang.Numbers_Add_O_J__Number_NoInit(tmp24, na_671) }; if linked_667 == nil { return ifn_668.Invoke_O_O__O(arg_669, arg_670) } else { return linked_667.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_666, arg_669, arg_670) } }
//line :108:1
		case 63: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_51) {







			var root_686 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_686, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = s__0; var arg_690 any; var root_691 any = A_arbace_repr_clojure_text_A_const_52.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, A_arbace_repr_clojure_text_cond_open_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = s__0; var arg_695 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_695 = i__1_b } else { arg_695 = i__1_b }; if linked_692 == nil { arg_690 = ifn_693.Invoke_O_O__O(arg_694, arg_695) } else { arg_690 = linked_692.(*A_arbace_repr_clojure_text_cond_open_A).Invoke_O_O_O__O(root_691, arg_694, arg_695) }; if linked_687 == nil { return ifn_688.Invoke_O_O__O(arg_689, arg_690) } else { if jrt.Long_InstanceOf(arg_690) { return linked_687.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_686, arg_689, jrt.NN(jrt.Long_Cast(arg_690)).LongValue__J(), arg_690) } else { return linked_687.(*A_arbace_repr_clojure_text_coll_end_A).Invoke_O_O_O__O(root_686, arg_689, arg_690) } } }
//line :108:1
		case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_26) {




			var root_696 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = s__0; var arg_700 any; var root_701 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = s__0; var arg_705 any; var na_706 int64 = 2; var n0_707 int64 = i__1_l; var n1_708 int64 = na_706; var nr_709 int64 = n0_707 + n1_708; if (n0_707^nr_709)&(n1_708^nr_709) >= 0 { arg_705 = jrt.Long_ValueOf_J__Long_NoInit(nr_709).Ref() } else { var tmp25 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp25 = i__1_b } else { tmp25 = i__1_b }; arg_705 = lang.Numbers_Add_O_J__Number_NoInit(tmp25, na_706) }; if linked_702 == nil { arg_700 = ifn_703.Invoke_O_O__O(arg_704, arg_705) } else { arg_700 = linked_702.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_701, arg_704, arg_705) }; if linked_697 == nil { return ifn_698.Invoke_O_O__O(arg_699, arg_700) } else { return linked_697.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_696, arg_699, arg_700) } }
//line :108:1
		case 95: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_39) {





			var root_710 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = s__0; var arg_714 any; var root_715 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = s__0; var arg_719 any; var na_720 int64 = 2; var n0_721 int64 = i__1_l; var n1_722 int64 = na_720; var nr_723 int64 = n0_721 + n1_722; if (n0_721^nr_723)&(n1_722^nr_723) >= 0 { arg_719 = jrt.Long_ValueOf_J__Long_NoInit(nr_723).Ref() } else { var tmp26 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp26 = i__1_b } else { tmp26 = i__1_b }; arg_719 = lang.Numbers_Add_O_J__Number_NoInit(tmp26, na_720) }; if linked_716 == nil { arg_714 = ifn_717.Invoke_O_O__O(arg_718, arg_719) } else { arg_714 = linked_716.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_715, arg_718, arg_719) }; if linked_711 == nil { return ifn_712.Invoke_O_O__O(arg_713, arg_714) } else { return linked_711.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_710, arg_713, arg_714) } }
//line :108:1
		case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_28) {

			var root_724 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_724, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_726 lang.IFn; if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = s__0; var arg_728 any; var arg_728_l int64; var n0_729 int64 = i__1_l; if n0_729 == 9223372036854775807 { var tmp27 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp27 = i__1_b } else { tmp27 = i__1_b }; arg_728 = lang.Numbers_Inc_O__Number_NoInit(tmp27); arg_728_l = 0 } else { arg_728_l = n0_729 + 1 }; if linked_725 == nil { var tmp28 any; if arg_728 == nil { tmp28 = jrt.Long_ValueOf_J__Long_NoInit(arg_728_l).Ref() } else { tmp28 = arg_728 }; return ifn_726.Invoke_O_O__O(arg_727, tmp28) } else { var tmp29 bool; var tmp30 bool; tmp30 = arg_728 == nil; if !tmp30 { tmp30 = jrt.Long_InstanceOf(arg_728) }; tmp29 = tmp30; if tmp29 { var tmp31 *A_arbace_repr_clojure_text_coll_end_A = linked_725.(*A_arbace_repr_clojure_text_coll_end_A); var tmp32 int64; if arg_728 == nil { tmp32 = arg_728_l } else { tmp32 = jrt.NN(jrt.Long_Cast(arg_728)).LongValue__J() }; return tmp31.InvokeSpec_O_O_J_O__O(root_724, arg_727, tmp32, arg_728) } else { var tmp33 *A_arbace_repr_clojure_text_coll_end_A = linked_725.(*A_arbace_repr_clojure_text_coll_end_A); var tmp34 any; if arg_728 == nil { tmp34 = jrt.Long_ValueOf_J__Long_NoInit(arg_728_l).Ref() } else { tmp34 = arg_728 }; return tmp33.Invoke_O_O_O__O(root_724, arg_727, tmp34) } } }
//line :108:1
		default:
		}












		var root_613 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any = s__0; var arg_617 any; var root_618 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = s__0; var arg_622 any; var n0_623 int64 = i__1_l; if n0_623 == 9223372036854775807 { var tmp35 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp35 = i__1_b } else { tmp35 = i__1_b }; arg_622 = lang.Numbers_Inc_O__Number_NoInit(tmp35) } else { arg_622 = jrt.Long_ValueOf_J__Long_NoInit(n0_623 + 1).Ref() }; if linked_619 == nil { arg_617 = ifn_620.Invoke_O_O__O(arg_621, arg_622) } else { arg_617 = linked_619.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_618, arg_621, arg_622) }; if linked_614 == nil { return ifn_615.Invoke_O_O__O(arg_616, arg_617) } else { return linked_614.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_613, arg_616, arg_617) } }
//line :98:1
	case 39: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_47) {




		var root_624 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = s__0; var arg_628 any; var n0_629 int64 = i__1_l; if n0_629 == 9223372036854775807 { var tmp36 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp36 = i__1_b } else { tmp36 = i__1_b }; arg_628 = lang.Numbers_Inc_O__Number_NoInit(tmp36) } else { arg_628 = jrt.Long_ValueOf_J__Long_NoInit(n0_629 + 1).Ref() }; if linked_625 == nil { return ifn_626.Invoke_O_O__O(arg_627, arg_628) } else { return linked_625.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_624, arg_627, arg_628) } }
//line :98:1
	case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_19) {

		var root_730 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_730, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any = s__0; if linked_731 == nil { var tmp37 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp37 = i__1_b } else { tmp37 = i__1_b }; return ifn_732.Invoke_O_O__O(arg_733, tmp37) } else { return linked_731.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_730, arg_733, i__1_l, i__1_b) } }
//line :98:1
	case 41: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_20) {







		var root_735 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = s__0; var arg_739 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_739 = i__1_b } else { arg_739 = i__1_b }; var arg_740 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref(); if linked_736 == nil { return ifn_737.Invoke_O_O_O__O(arg_738, arg_739, arg_740) } else { return linked_736.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_735, arg_738, arg_739, arg_740) } }
//line :98:1
	case 64: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_22) {




		var root_741 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = s__0; var arg_745 any; var n0_746 int64 = i__1_l; if n0_746 == 9223372036854775807 { var tmp38 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp38 = i__1_b } else { tmp38 = i__1_b }; arg_745 = lang.Numbers_Inc_O__Number_NoInit(tmp38) } else { arg_745 = jrt.Long_ValueOf_J__Long_NoInit(n0_746 + 1).Ref() }; if linked_742 == nil { return ifn_743.Invoke_O_O__O(arg_744, arg_745) } else { return linked_742.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_741, arg_744, arg_745) } }
//line :98:1
	case 91: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_23) {

		var root_747 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_747, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = s__0; if linked_748 == nil { var tmp39 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp39 = i__1_b } else { tmp39 = i__1_b }; return ifn_749.Invoke_O_O__O(arg_750, tmp39) } else { return linked_748.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_747, arg_750, i__1_l, i__1_b) } }
//line :98:1
	case 92: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_24) {



		var root_752 any = A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_752, A_arbace_repr_clojure_text_char_end_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = s__0; if linked_753 == nil { var tmp40 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp40 = i__1_b } else { tmp40 = i__1_b }; return ifn_754.Invoke_O_O__O(arg_755, tmp40) } else { return linked_753.(*A_arbace_repr_clojure_text_char_end_A).InvokeSpec_O_O_J_O__O(root_752, arg_755, i__1_l, i__1_b) } }
//line :98:1
	case 93: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_25) {







		var root_757 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = s__0; var arg_761 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_761 = i__1_b } else { arg_761 = i__1_b }; var arg_762 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref(); if linked_758 == nil { return ifn_759.Invoke_O_O_O__O(arg_760, arg_761, arg_762) } else { return linked_758.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_757, arg_760, arg_761, arg_762) } }
//line :98:1
	case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_26) {






		var root_763 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = s__0; var arg_767 any; var root_768 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = s__0; var arg_772 any; var n0_773 int64 = i__1_l; if n0_773 == 9223372036854775807 { var tmp41 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp41 = i__1_b } else { tmp41 = i__1_b }; arg_772 = lang.Numbers_Inc_O__Number_NoInit(tmp41) } else { arg_772 = jrt.Long_ValueOf_J__Long_NoInit(n0_773 + 1).Ref() }; if linked_769 == nil { arg_767 = ifn_770.Invoke_O_O__O(arg_771, arg_772) } else { arg_767 = linked_769.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_768, arg_771, arg_772) }; if linked_764 == nil { return ifn_765.Invoke_O_O__O(arg_766, arg_767) } else { return linked_764.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_763, arg_766, arg_767) } }
//line :98:1
	case 96: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_27) {




		var root_774 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = s__0; var arg_778 any; var n0_779 int64 = i__1_l; if n0_779 == 9223372036854775807 { var tmp42 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp42 = i__1_b } else { tmp42 = i__1_b }; arg_778 = lang.Numbers_Inc_O__Number_NoInit(tmp42) } else { arg_778 = jrt.Long_ValueOf_J__Long_NoInit(n0_779 + 1).Ref() }; if linked_775 == nil { return ifn_776.Invoke_O_O__O(arg_777, arg_778) } else { return linked_775.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_774, arg_777, arg_778) } }
//line :98:1
	case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_28) {

		var root_780 any = A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_780, A_arbace_repr_clojure_text_coll_end_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any = s__0; if linked_781 == nil { var tmp43 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp43 = i__1_b } else { tmp43 = i__1_b }; return ifn_782.Invoke_O_O__O(arg_783, tmp43) } else { return linked_781.(*A_arbace_repr_clojure_text_coll_end_A).InvokeSpec_O_O_J_O__O(root_780, arg_783, i__1_l, i__1_b) } }
//line :98:1
	case 125: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_29) {







		var root_785 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = s__0; var arg_789 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_789 = i__1_b } else { arg_789 = i__1_b }; var arg_790 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref(); if linked_786 == nil { return ifn_787.Invoke_O_O_O__O(arg_788, arg_789, arg_790) } else { return linked_786.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_785, arg_788, arg_789, arg_790) } }
//line :98:1
	case 126: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_30) {





		var root_791 any = A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, A_arbace_repr_clojure_text_next_form_end_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = s__0; var arg_795 any; var tmp44 any = A_arbace_repr_clojure_text_A_const_22; var tmp45 any; var root_796 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = s__0; var arg_800 any; var n0_801 int64 = i__1_l; if n0_801 == 9223372036854775807 { var tmp46 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp46 = i__1_b } else { tmp46 = i__1_b }; arg_800 = lang.Numbers_Inc_O__Number_NoInit(tmp46) } else { arg_800 = jrt.Long_ValueOf_J__Long_NoInit(n0_801 + 1).Ref() }; if linked_797 == nil { tmp45 = ifn_798.Invoke_O_O__O(arg_799, arg_800) } else { tmp45 = linked_797.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_796, arg_799, arg_800) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp44, tmp45) { var na_802 int64 = 2; var n0_803 int64 = i__1_l; var n1_804 int64 = na_802; var nr_805 int64 = n0_803 + n1_804; if (n0_803^nr_805)&(n1_804^nr_805) >= 0 { arg_795 = jrt.Long_ValueOf_J__Long_NoInit(nr_805).Ref() } else { var tmp47 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp47 = i__1_b } else { tmp47 = i__1_b }; arg_795 = lang.Numbers_Add_O_J__Number_NoInit(tmp47, na_802) } } else { var n0_806 int64 = i__1_l; if n0_806 == 9223372036854775807 { var tmp48 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp48 = i__1_b } else { tmp48 = i__1_b }; arg_795 = lang.Numbers_Inc_O__Number_NoInit(tmp48) } else { arg_795 = jrt.Long_ValueOf_J__Long_NoInit(n0_806 + 1).Ref() } }; if linked_792 == nil { return ifn_793.Invoke_O_O__O(arg_794, arg_795) } else { return linked_792.(*A_arbace_repr_clojure_text_next_form_end_A).Invoke_O_O_O__O(root_791, arg_794, arg_795) } }
//line :98:1
	default:}; var root_630 any =
























	A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = s__0; var arg_634 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_634 = i__1_b } else { arg_634 = i__1_b }; if linked_631 == nil { return ifn_632.Invoke_O_O__O(arg_633, arg_634) } else { return linked_631.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_630, arg_633, arg_634) } }



func A_arbace_repr_clojure_text_cond_open_A_New() *A_arbace_repr_clojure_text_cond_open_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_cond_open_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_repr_clojure_text_cond_open_A) Ctor() {}
//line :127:1
func (t *A_arbace_repr_clojure_text_cond_open_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__839 any = A_arbace_repr_clojure_text_cond_open_fn__670000030_A_New_O_O(i__1, s__0); var tmp2 *jrt.Class; var fncls__838 *jrt.Class = A_arbace_repr_clojure_text_cond_open_fn__670000030_A_fn_class; if



	fncls__838 == nil { var fncls__838d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__839); A_arbace_repr_clojure_text_cond_open_fn__670000030_A_fn_class = fncls__838d; tmp2 = fncls__838d } else { tmp2 = fncls__838 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__839, tmp2, nil); j__3 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O(); var tmp3 any = A_arbace_repr_clojure_text_A_const_19; var tmp4 any; var root_840 any =

	A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = s__0; var arg_844 any = j__3; if linked_841 == nil { tmp4 = ifn_842.Invoke_O_O__O(arg_843, arg_844) } else { tmp4 = linked_841.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_840, arg_843, arg_844) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4) { } else { var root_845 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = s__0; var arg_849 any = i__1; var arg_850 any = Lit_8; if linked_846 == nil { ifn_847.Invoke_O_O_O__O(arg_848, arg_849, arg_850) } else { linked_846.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_845, arg_848, arg_849, arg_850) } }; return j__3 }
//line :131:1
func A_arbace_repr_clojure_text_cond_open_fn__670000030_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_text_cond_open_fn__670000030_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_cond_open_fn__670000030_A{}; t.Ctor_O_O(p0, p1); return t }
//line :131:1
func (t *A_arbace_repr_clojure_text_cond_open_fn__670000030_A) Ctor_O_O(c__i, c__s any) { t.F_i = c__i; t.F_s = c__s }
//line :131:1
func (t *A_arbace_repr_clojure_text_cond_open_fn__670000030_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 any = A_arbace_repr_clojure_text_A_const_22; var tmp2 any; var root_807 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = t.F_s; var arg_811 any; var na_812 any = t.F_i; var na_813 int64 = 2; if jrt.Long_InstanceOf(na_812) { var n0_814 int64 = jrt.NN(jrt.Long_Cast(na_812)).LongValue__J(); var n1_815 int64 = na_813; var nr_816 int64 = n0_814 + n1_815; if (n0_814^nr_816)&(n1_815^nr_816) >= 0 { arg_811 = jrt.Long_ValueOf_J__Long_NoInit(nr_816).Ref() } else { arg_811 = lang.Numbers_Add_O_J__Number_NoInit(na_812, na_813) } } else { arg_811 = lang.Numbers_Add_O_J__Number_NoInit(na_812, na_813) }; if linked_808 == nil { tmp2 = ifn_809.Invoke_O_O__O(arg_810, arg_811) } else { tmp2 = linked_808.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_807, arg_810, arg_811) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { var na_817 any; var t_ any = t.F_i; t.F_i = nil; na_817 = t_; var na_818 int64 = 3; if jrt.Long_InstanceOf(na_817) { var n0_819 int64 = jrt.NN(jrt.Long_Cast(na_817)).LongValue__J(); var n1_820 int64 = na_818; var nr_821 int64 = n0_819 + n1_820; if (n0_819^nr_821)&(n1_820^nr_821) >= 0 { j__1 = jrt.Long_ValueOf_J__Long_NoInit(nr_821).Ref() } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_817, na_818) } } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_817, na_818) } } else { var na_822 any; var t__2 any = t.F_i; t.F_i = nil; na_822 = t__2; var na_823 int64 = 2; if jrt.Long_InstanceOf(na_822) { var n0_824 int64 = jrt.NN(jrt.Long_Cast(na_822)).LongValue__J(); var n1_825 int64 = na_823; var nr_826 int64 = n0_824 + n1_825; if (n0_824^nr_826)&(n1_825^nr_826) >= 0 { j__1 = jrt.Long_ValueOf_J__Long_NoInit(nr_826).Ref() } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_822, na_823) } } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_822, na_823) } }; L1: for {
												var tmp3 any; var and__1927000168__auto____2 bool; var na_827 any = j__1; var na_828 int64 = int64(lang.RT_Count_O__I_NoInit(t.F_s)); if jrt.Long_InstanceOf(na_827) { var n0_829 int64 = jrt.NN(jrt.Long_Cast(na_827)).LongValue__J(); var n1_830 int64 = na_828; and__1927000168__auto____2 = n0_829 < n1_830 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_J__Z_NoInit(na_827, na_828) }; if and__1927000168__auto____2 { var root_832 any = A_arbace_repr_clojure_text_A_const_17.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, A_arbace_repr_clojure_text_ws_QMARK__A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var tmp4 *jrt.String = jrt.String_Cast(t.F_s); var arg_835 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(tmp4).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))).Ref(); if linked_833 == nil { tmp3 = ifn_834.Invoke_O__O(arg_835) } else { tmp3 = linked_833.(*A_arbace_repr_clojure_text_ws_QMARK__A).Invoke_O_O__O(root_832, arg_835) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp3) { var tmp5 jrt.Number_I; var na_836 any = j__1; if jrt.Long_InstanceOf(na_836) { var n0_837 int64 = jrt.NN(jrt.Long_Cast(na_836)).LongValue__J(); if n0_837 == 9223372036854775807 { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_836) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_837 + 1)) } } else { if jrt.Double_InstanceOf(na_836) { var n0_837_2 float64 = jrt.NN(jrt.Double_Cast(na_836)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_837_2 + 1.0)) } else { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_836) } }; j__1 = tmp5; continue L1 } else { return j__1 } } }; /*line :131:1*/panic("j2g: unreachable") }




func A_arbace_repr_clojure_text_branches_A_New() *A_arbace_repr_clojure_text_branches_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_branches_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_repr_clojure_text_branches_A) Ctor() {}
//line :136:1
func (t *A_arbace_repr_clojure_text_branches_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_O_J_O__O(self, s__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1) } else { var j__3 any; var root_851 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_851, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_853 lang.IFn



	if linked_852 == nil { ifn_853 = lang.IFn_Cast(root_851) } else { ifn_853 = nil }; var arg_854 any = s__0; var arg_855 any; var na_856 any = i__1; if jrt.Long_InstanceOf(na_856) { var n0_857 int64 = jrt.NN(jrt.Long_Cast(na_856)).LongValue__J(); if n0_857 == 9223372036854775807 { arg_855 = lang.Numbers_Inc_O__Number_NoInit(na_856) } else { arg_855 = jrt.Long_ValueOf_J__Long_NoInit(n0_857 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_856) { var n0_857_2 float64 = jrt.NN(jrt.Double_Cast(na_856)).DoubleValue__D(); arg_855 = jrt.Double_ValueOf_D__Double_NoInit(n0_857_2 + 1.0).Ref() } else { arg_855 = lang.Numbers_Inc_O__Number_NoInit(na_856) } }; if linked_852 == nil { j__3 = ifn_853.Invoke_O_O__O(arg_854, arg_855) } else { j__3 = linked_852.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_851, arg_854, arg_855) }
//line :136:1
	var bs__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		var tmp1 any = A_arbace_repr_clojure_text_A_const_20; var tmp2 any; var root_858 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_858, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_860 lang.IFn; if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any = s__0; var arg_862 any = j__3; if linked_859 == nil { tmp2 = ifn_860.Invoke_O_O__O(arg_861, arg_862) } else { tmp2 = linked_859.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_858, arg_861, arg_862) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { return bs__4 } else { var fe__5 any; var root_863 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_864 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_863, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_865 lang.IFn

			if linked_864 == nil { ifn_865 = lang.IFn_Cast(root_863) } else { ifn_865 = nil }; var arg_866 any = s__0; var arg_867 any = j__3; if linked_864 == nil { fe__5 = ifn_865.Invoke_O_O__O(arg_866, arg_867) } else { if jrt.Long_InstanceOf(arg_867) { fe__5 = linked_864.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_863, arg_866, jrt.NN(jrt.Long_Cast(arg_867)).LongValue__J(), arg_867) } else { fe__5 = linked_864.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_863, arg_866, arg_867) } }
//line :141:1
			var feature__6 any; var root_868 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_868, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_870 lang.IFn


			if linked_869 == nil { ifn_870 = lang.IFn_Cast(root_868) } else { ifn_870 = nil }; var arg_871 any = s__0; var arg_872 any = j__3; var arg_873 any = fe__5; if linked_869 == nil { feature__6 = ifn_870.Invoke_O_O_O__O(arg_871, arg_872, arg_873) } else { feature__6 = linked_869.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_868, arg_871, arg_872, arg_873) }
//line :141:1
			var v__7 any; var root_874 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_876 lang.IFn



			if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any = s__0; var arg_878 any = fe__5; if linked_875 == nil { v__7 = ifn_876.Invoke_O_O__O(arg_877, arg_878) } else { v__7 = linked_875.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_874, arg_877, arg_878) }
			var tmp3 any; var root_884 any = A_arbace_repr_clojure_text_A_const_54.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = feature__6; var arg_888 any = Lit_1; if linked_885 == nil { tmp3 = ifn_886.Invoke_O_O__O(arg_887, arg_888) } else { tmp3 = linked_885.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_884, arg_887, arg_888) }; if jrt.J2g_Truth(tmp3) { } else { var root_889 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = s__0; var arg_893 any = j__3; var arg_894 any = Lit_2; if linked_890 == nil { ifn_891.Invoke_O_O_O__O(arg_892, arg_893, arg_894) } else { linked_890.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_889, arg_892, arg_893, arg_894) } }
			var tmp4 any = A_arbace_repr_clojure_text_A_const_20; var tmp5 any; var root_895 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = s__0; var arg_899 any = v__7; if linked_896 == nil { tmp5 = ifn_897.Invoke_O_O__O(arg_898, arg_899) } else { tmp5 = linked_896.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_895, arg_898, arg_899) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5) { var root_900 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any = s__0; var arg_904 any = v__7; var arg_905 any = Lit_3; if linked_901 == nil { ifn_902.Invoke_O_O_O__O(arg_903, arg_904, arg_905) } else { linked_901.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_900, arg_903, arg_904, arg_905) } }
//line :141:1
			var ve__8 any; var root_879 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_879, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_881 lang.IFn






			if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = s__0; var arg_883 any = v__7; if linked_880 == nil { ve__8 = ifn_881.Invoke_O_O__O(arg_882, arg_883) } else { if jrt.Long_InstanceOf(arg_883) { ve__8 = linked_880.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_879, arg_882, jrt.NN(jrt.Long_Cast(arg_883)).LongValue__J(), arg_883) } else { ve__8 = linked_880.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_879, arg_882, arg_883) } }
			var tmp6 any; var root_906 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = s__0; var arg_910 any = ve__8; if linked_907 == nil { tmp6 = ifn_908.Invoke_O_O__O(arg_909, arg_910) } else { tmp6 = linked_907.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_906, arg_909, arg_910) }; var tmp7 any = tmp6; var tmp8 any; var root_911 any = A_arbace_repr_clojure_text_A_const_7.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_911, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = bs__4; var arg_915 any; var tmp9 any; var root_916 any = A_arbace_repr_clojure_text_A_const_55.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any; var root_920 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = feature__6; var arg_924 any = A_arbace_repr_clojure_text_A_const_56; if linked_921 == nil { arg_919 = ifn_922.Invoke_O_O__O(arg_923, arg_924) } else { arg_919 = linked_921.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_920, arg_923, arg_924) }; if linked_917 == nil { tmp9 = ifn_918.Invoke_O__O(arg_919) } else { tmp9 = linked_917.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_916, arg_919) }; arg_915 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp9, v__7, ve__8); if linked_912 == nil { tmp8 = ifn_913.Invoke_O_O__O(arg_914, arg_915) } else { tmp8 = linked_912.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_911, arg_914, arg_915) }; j__3, bs__4 = tmp7, tmp8; continue L1 } } }; /*line :136:1*/panic("j2g: unreachable") }
//line :136:1
func (t *A_arbace_repr_clojure_text_branches_A) InvokeSpec_O_O_J_O__O(self, s__0 any, i__1_l int64, i__1_b any) any { { var j__3 any; var root_925 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_927 lang.IFn



	if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = s__0; var arg_929 any; var n0_930 int64 = i__1_l; if n0_930 == 9223372036854775807 { var tmp1 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp1 = i__1_b } else { tmp1 = i__1_b }; arg_929 = lang.Numbers_Inc_O__Number_NoInit(tmp1) } else { arg_929 = jrt.Long_ValueOf_J__Long_NoInit(n0_930 + 1).Ref() }; if linked_926 == nil { j__3 = ifn_927.Invoke_O_O__O(arg_928, arg_929) } else { j__3 = linked_926.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_925, arg_928, arg_929) }
//line :136:1
	var bs__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		var tmp2 any = A_arbace_repr_clojure_text_A_const_20; var tmp3 any; var root_931 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_931, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_933 lang.IFn; if linked_932 == nil { ifn_933 = lang.IFn_Cast(root_931) } else { ifn_933 = nil }; var arg_934 any = s__0; var arg_935 any = j__3; if linked_932 == nil { tmp3 = ifn_933.Invoke_O_O__O(arg_934, arg_935) } else { tmp3 = linked_932.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_931, arg_934, arg_935) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { return bs__4 } else { var fe__5 any; var root_936 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_936, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_938 lang.IFn

			if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = s__0; var arg_940 any = j__3; if linked_937 == nil { fe__5 = ifn_938.Invoke_O_O__O(arg_939, arg_940) } else { if jrt.Long_InstanceOf(arg_940) { fe__5 = linked_937.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_936, arg_939, jrt.NN(jrt.Long_Cast(arg_940)).LongValue__J(), arg_940) } else { fe__5 = linked_937.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_936, arg_939, arg_940) } }
//line :141:1
			var feature__6 any; var root_941 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_943 lang.IFn


			if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = s__0; var arg_945 any = j__3; var arg_946 any = fe__5; if linked_942 == nil { feature__6 = ifn_943.Invoke_O_O_O__O(arg_944, arg_945, arg_946) } else { feature__6 = linked_942.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_941, arg_944, arg_945, arg_946) }
//line :141:1
			var v__7 any; var root_947 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_947, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_949 lang.IFn



			if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any = s__0; var arg_951 any = fe__5; if linked_948 == nil { v__7 = ifn_949.Invoke_O_O__O(arg_950, arg_951) } else { v__7 = linked_948.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_947, arg_950, arg_951) }
			var tmp4 any; var root_957 any = A_arbace_repr_clojure_text_A_const_54.GetRawRoot__O(); var linked_958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_957, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_959 lang.IFn; if linked_958 == nil { ifn_959 = lang.IFn_Cast(root_957) } else { ifn_959 = nil }; var arg_960 any = feature__6; var arg_961 any = Lit_1; if linked_958 == nil { tmp4 = ifn_959.Invoke_O_O__O(arg_960, arg_961) } else { tmp4 = linked_958.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_957, arg_960, arg_961) }; if jrt.J2g_Truth(tmp4) { } else { var root_962 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = s__0; var arg_966 any = j__3; var arg_967 any = Lit_2; if linked_963 == nil { ifn_964.Invoke_O_O_O__O(arg_965, arg_966, arg_967) } else { linked_963.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_962, arg_965, arg_966, arg_967) } }
			var tmp5 any = A_arbace_repr_clojure_text_A_const_20; var tmp6 any; var root_968 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = s__0; var arg_972 any = v__7; if linked_969 == nil { tmp6 = ifn_970.Invoke_O_O__O(arg_971, arg_972) } else { tmp6 = linked_969.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_968, arg_971, arg_972) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp5, tmp6) { var root_973 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_975 lang.IFn; if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any = s__0; var arg_977 any = v__7; var arg_978 any = Lit_3; if linked_974 == nil { ifn_975.Invoke_O_O_O__O(arg_976, arg_977, arg_978) } else { linked_974.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_973, arg_976, arg_977, arg_978) } }
//line :141:1
			var ve__8 any; var root_952 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_952, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_954 lang.IFn






			if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = s__0; var arg_956 any = v__7; if linked_953 == nil { ve__8 = ifn_954.Invoke_O_O__O(arg_955, arg_956) } else { if jrt.Long_InstanceOf(arg_956) { ve__8 = linked_953.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_952, arg_955, jrt.NN(jrt.Long_Cast(arg_956)).LongValue__J(), arg_956) } else { ve__8 = linked_953.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_952, arg_955, arg_956) } }
			var tmp7 any; var root_979 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = s__0; var arg_983 any = ve__8; if linked_980 == nil { tmp7 = ifn_981.Invoke_O_O__O(arg_982, arg_983) } else { tmp7 = linked_980.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_979, arg_982, arg_983) }; var tmp8 any = tmp7; var tmp9 any; var root_984 any = A_arbace_repr_clojure_text_A_const_7.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = bs__4; var arg_988 any; var tmp10 any; var root_989 any = A_arbace_repr_clojure_text_A_const_55.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any; var root_993 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_993, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any = feature__6; var arg_997 any = A_arbace_repr_clojure_text_A_const_56; if linked_994 == nil { arg_992 = ifn_995.Invoke_O_O__O(arg_996, arg_997) } else { arg_992 = linked_994.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_993, arg_996, arg_997) }; if linked_990 == nil { tmp10 = ifn_991.Invoke_O__O(arg_992) } else { tmp10 = linked_990.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_989, arg_992) }; arg_988 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp10, v__7, ve__8); if linked_985 == nil { tmp9 = ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { tmp9 = linked_985.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_984, arg_987, arg_988) }; j__3, bs__4 = tmp8, tmp9; continue L1 } } }; /*line :136:1*/panic("j2g: unreachable") }
















func A_arbace_repr_clojure_text_selected_A_New() *A_arbace_repr_clojure_text_selected_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_selected_A{}; t.Ctor(); return t }
//line :153:1
func (t *A_arbace_repr_clojure_text_selected_A) Ctor() {}
//line :153:1
func (t *A_arbace_repr_clojure_text_selected_A) Invoke_O_O_O_O_O__O(self, s__0, i__1, features__2, depth__3 any) any { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(i__1); if tmp2 { tmp2 = jrt.Long_InstanceOf(depth__3) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_O_J_O_O_J_O__O(self, s__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, features__2, jrt.NN(jrt.Long_Cast(depth__3)).LongValue__J(), depth__3) } else { var splice_QMARK___5 bool; var tmp3 any = A_arbace_repr_clojure_text_A_const_22; var tmp4 any; var root_998 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_1000 lang.IFn




	if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = s__0; var arg_1002 any; var na_1003 any = i__1; var na_1004 int64 = 2; if jrt.Long_InstanceOf(na_1003) { var n0_1005 int64 = jrt.NN(jrt.Long_Cast(na_1003)).LongValue__J(); var n1_1006 int64 = na_1004; var nr_1007 int64 = n0_1005 + n1_1006; if (n0_1005^nr_1007)&(n1_1006^nr_1007) >= 0 { arg_1002 = jrt.Long_ValueOf_J__Long_NoInit(nr_1007).Ref() } else { arg_1002 = lang.Numbers_Add_O_J__Number_NoInit(na_1003, na_1004) } } else { arg_1002 = lang.Numbers_Add_O_J__Number_NoInit(na_1003, na_1004) }; if linked_999 == nil { tmp4 = ifn_1000.Invoke_O_O__O(arg_1001, arg_1002) } else { tmp4 = linked_999.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_998, arg_1001, arg_1002) }; splice_QMARK___5 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)
//line :153:1
	var open__6 any; var root_1008 any = A_arbace_repr_clojure_text_A_const_52.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, A_arbace_repr_clojure_text_cond_open_A_fn_class); var ifn_1010 lang.IFn





	if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = s__0; var arg_1012 any = i__1; if linked_1009 == nil { open__6 = ifn_1010.Invoke_O_O__O(arg_1011, arg_1012) } else { open__6 = linked_1009.(*A_arbace_repr_clojure_text_cond_open_A).Invoke_O_O_O__O(root_1008, arg_1011, arg_1012) }
//line :153:1
	var vec__670000034__7 any; var root_1013 any = A_arbace_repr_clojure_text_A_const_57.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1015 lang.IFn






	if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any; var root_1017 any = A_arbace_repr_clojure_text_A_const_9.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any; var fnbody__1028 any = A_arbace_repr_clojure_text_selected_fn__670000038_A_New_O(features__2); var tmp5 *jrt.Class; var fncls__1027 *jrt.Class = A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class; if fncls__1027 == nil { var fncls__1027d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__1028); A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class = fncls__1027d; tmp5 = fncls__1027d } else { tmp5 = fncls__1027 }; arg_1020 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1028, tmp5, nil); var arg_1021 any; var root_1029 any = A_arbace_repr_clojure_text_A_const_60.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1029, A_arbace_repr_clojure_text_branches_A_fn_class); var ifn_1031 lang.IFn
	if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = s__0; var arg_1033 any = open__6; if linked_1030 == nil { arg_1021 = ifn_1031.Invoke_O_O__O(arg_1032, arg_1033) } else { if jrt.Long_InstanceOf(arg_1033) { arg_1021 = linked_1030.(*A_arbace_repr_clojure_text_branches_A).InvokeSpec_O_O_J_O__O(root_1029, arg_1032, jrt.NN(jrt.Long_Cast(arg_1033)).LongValue__J(), arg_1033) } else { arg_1021 = linked_1030.(*A_arbace_repr_clojure_text_branches_A).Invoke_O_O_O__O(root_1029, arg_1032, arg_1033) } }
//line :160:1
	if linked_1018 == nil { arg_1016 = ifn_1019.Invoke_O_O__O(arg_1020, arg_1021) } else { arg_1016 = linked_1018.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1017, arg_1020, arg_1021) }; if linked_1014 == nil { vec__670000034__7 = ifn_1015.Invoke_O__O(arg_1016) } else { vec__670000034__7 = linked_1014.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1013, arg_1016) }
//line :153:1
	var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(0), nil); var v__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(1), nil); var ve__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp6 bool; var and__1927000168__auto____11 bool = splice_QMARK___5; _ = ___8








	if and__1927000168__auto____11 { var na_1072 any = depth__3; if jrt.Long_InstanceOf(na_1072) { var n0_1073 int64 = jrt.NN(jrt.Long_Cast(na_1072)).LongValue__J(); tmp6 = n0_1073 == 0 } else { if jrt.Double_InstanceOf(na_1072) { var n0_1073_2 float64 = jrt.NN(jrt.Double_Cast(na_1072)).DoubleValue__D(); tmp6 = n0_1073_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_1072) } } } else { tmp6 = and__1927000168__auto____11 }; if tmp6 {
		var root_1074 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_1076 lang.IFn; if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = s__0; var arg_1078 any = i__1; var arg_1079 any = Lit_22; if linked_1075 == nil { ifn_1076.Invoke_O_O_O__O(arg_1077, arg_1078, arg_1079) } else { linked_1075.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_1074, arg_1077, arg_1078, arg_1079)
		}
	}
	if lang.Util_Identical_O_O__Z_NoInit(v__9, nil) { return Lit_23 } else { var tmp7 any; var root_1034 any = A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1036 lang.IFn
		if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(splice_QMARK___5).Ref(); if linked_1035 == nil { tmp7 = ifn_1036.Invoke_O__O(arg_1037) } else { tmp7 = linked_1035.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1034, arg_1037) }
//line :166:1
		if jrt.J2g_Truth(tmp7) {
			var root_1038 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1040 lang.IFn; if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any; var root_1044 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1046 lang.IFn; if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = s__0; var arg_1048 any = v__9; var arg_1049 any = ve__10; if linked_1045 == nil { arg_1041 = ifn_1046.Invoke_O_O_O__O(arg_1047, arg_1048, arg_1049) } else { arg_1041 = linked_1045.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1044, arg_1047, arg_1048, arg_1049) }; var arg_1042 any = features__2; var arg_1043 any = depth__3; if linked_1039 == nil { return ifn_1040.Invoke_O_O_O__O(arg_1041, arg_1042, arg_1043) } else { return linked_1039.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O_O__O(root_1038, arg_1041, arg_1042, arg_1043) } } else {
//line :166:1
				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_62); var tmp9 any; var root_1080 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1080, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_1082 lang.IFn

				if linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any = s__0; var arg_1084 any = v__9; if linked_1081 == nil { tmp9 = ifn_1082.Invoke_O_O__O(arg_1083, arg_1084) } else { tmp9 = linked_1081.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_1080, arg_1083, arg_1084) }
//line :166:1
				if jrt.J2g_Truth(tmp8.Invoke_O__O(tmp9)) {

					var root_1050 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any; var root_1056 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = s__0; var arg_1060 any; var na_1062 any = v__9; if jrt.Long_InstanceOf(na_1062) { var n0_1063 int64 = jrt.NN(jrt.Long_Cast(na_1062)).LongValue__J(); if n0_1063 == 9223372036854775807 { arg_1060 = lang.Numbers_Inc_O__Number_NoInit(na_1062) } else { arg_1060 = jrt.Long_ValueOf_J__Long_NoInit(n0_1063 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1062) { var n0_1063_2 float64 = jrt.NN(jrt.Double_Cast(na_1062)).DoubleValue__D(); arg_1060 = jrt.Double_ValueOf_D__Double_NoInit(n0_1063_2 + 1.0).Ref() } else { arg_1060 = lang.Numbers_Inc_O__Number_NoInit(na_1062) } }; var arg_1061 any; var na_1064 any = ve__10; if jrt.Long_InstanceOf(na_1064) { var n0_1065 int64 = jrt.NN(jrt.Long_Cast(na_1064)).LongValue__J(); if n0_1065 == -9223372036854775808 { arg_1061 = lang.Numbers_Dec_O__Number_NoInit(na_1064) } else { arg_1061 = jrt.Long_ValueOf_J__Long_NoInit(n0_1065 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_1064) { var n0_1065_2 float64 = jrt.NN(jrt.Double_Cast(na_1064)).DoubleValue__D(); arg_1061 = jrt.Double_ValueOf_D__Double_NoInit(n0_1065_2 - 1.0).Ref() } else { arg_1061 = lang.Numbers_Dec_O__Number_NoInit(na_1064) } }; if linked_1057 == nil { arg_1053 = ifn_1058.Invoke_O_O_O__O(arg_1059, arg_1060, arg_1061) } else { arg_1053 = linked_1057.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1056, arg_1059, arg_1060, arg_1061) }; var arg_1054 any = features__2; var arg_1055 any = depth__3; if linked_1051 == nil { return ifn_1052.Invoke_O_O_O__O(arg_1053, arg_1054, arg_1055) } else { return linked_1051.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O_O__O(root_1050, arg_1053, arg_1054, arg_1055) } } else {
//line :166:1
						if A_arbace_repr_clojure_text_A_const_34 != nil {


							var root_1066 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = s__0; var arg_1070 any = v__9; var arg_1071 any = Lit_24; if linked_1067 == nil { return ifn_1068.Invoke_O_O_O__O(arg_1069, arg_1070, arg_1071) } else { return linked_1067.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_1066, arg_1069, arg_1070, arg_1071) } } else {
//line :166:1
								return nil } } } } } }
//line :153:1
func (t *A_arbace_repr_clojure_text_selected_A) InvokeSpec_O_O_J_O_O_J_O__O(self, s__0 any, i__1_l int64, i__1_b, features__2 any, depth__3_l int64, depth__3_b any) any { var splice_QMARK___5 bool; var tmp1 any = A_arbace_repr_clojure_text_A_const_22; var tmp2 any; var root_1085 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_1087 lang.IFn; if




	linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any = s__0; var arg_1089 any; var na_1090 int64 = 2; var n0_1091 int64 = i__1_l; var n1_1092 int64 = na_1090; var nr_1093 int64 = n0_1091 + n1_1092; if (n0_1091^nr_1093)&(n1_1092^nr_1093) >= 0 { arg_1089 = jrt.Long_ValueOf_J__Long_NoInit(nr_1093).Ref() } else { var tmp3 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp3 = i__1_b } else { tmp3 = i__1_b }; arg_1089 = lang.Numbers_Add_O_J__Number_NoInit(tmp3, na_1090) }; if linked_1086 == nil { tmp2 = ifn_1087.Invoke_O_O__O(arg_1088, arg_1089) } else { tmp2 = linked_1086.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_1085, arg_1088, arg_1089) }; splice_QMARK___5 = lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2); var open__6 any; var root_1094 any = /*line :153:1*/A_arbace_repr_clojure_text_A_const_52.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1094, A_arbace_repr_clojure_text_cond_open_A_fn_class); var ifn_1096 lang.IFn; if





	linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any = s__0; var arg_1098 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_1098 = i__1_b } else { arg_1098 = i__1_b }; if linked_1095 == nil { open__6 = ifn_1096.Invoke_O_O__O(arg_1097, arg_1098) } else { open__6 = linked_1095.(*A_arbace_repr_clojure_text_cond_open_A).Invoke_O_O_O__O(root_1094, arg_1097, arg_1098) }; var vec__670000034__7 any; var root_1099 any = /*line :153:1*/A_arbace_repr_clojure_text_A_const_57.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1101 lang.IFn; if






	linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any; var root_1103 any = A_arbace_repr_clojure_text_A_const_9.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any; var fnbody__1109 any = A_arbace_repr_clojure_text_selected_fn__670000038_A_New_O(features__2); var tmp4 *jrt.Class; var fncls__1108 *jrt.Class = A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class; if fncls__1108 == nil { var fncls__1108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__1109); A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class = fncls__1108d; tmp4 = fncls__1108d } else { tmp4 = fncls__1108 }; arg_1106 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1109, tmp4, nil); var arg_1107 any; var root_1110 any = A_arbace_repr_clojure_text_A_const_60.GetRawRoot__O(); var linked_1111 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1110, A_arbace_repr_clojure_text_branches_A_fn_class); var ifn_1112 lang.IFn; if
	linked_1111 == nil { ifn_1112 = lang.IFn_Cast(root_1110) } else { ifn_1112 = nil }; var arg_1113 any = s__0; var arg_1114 any = open__6; if linked_1111 == nil { arg_1107 = ifn_1112.Invoke_O_O__O(arg_1113, arg_1114) } else { if jrt.Long_InstanceOf(arg_1114) { arg_1107 = linked_1111.(*A_arbace_repr_clojure_text_branches_A).InvokeSpec_O_O_J_O__O(root_1110, arg_1113, jrt.NN(jrt.Long_Cast(arg_1114)).LongValue__J(), arg_1114) } else { arg_1107 = linked_1111.(*A_arbace_repr_clojure_text_branches_A).Invoke_O_O_O__O(root_1110, arg_1113, arg_1114) } }; if /*line :160:1*/ linked_1104 == nil { arg_1102 = ifn_1105.Invoke_O_O__O(arg_1106, arg_1107) } else { arg_1102 = linked_1104.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1103, arg_1106, arg_1107) }; if linked_1100 == nil { vec__670000034__7 = ifn_1101.Invoke_O__O(arg_1102) } else { vec__670000034__7 = linked_1100.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1099, arg_1102) }; var ___8 any = /*line :153:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(0), nil); var v__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(1), nil); var ve__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp5 bool; var and__1927000168__auto____11 bool = splice_QMARK___5; _ = ___8; if and__1927000168__auto____11 {








		var n0_1153 int64 = depth__3_l; tmp5 = n0_1153 == 0 } else { tmp5 = and__1927000168__auto____11 }; if tmp5 {
			var root_1154 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = s__0; var arg_1158 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_1158 = i__1_b } else { arg_1158 = i__1_b }; var arg_1159 any = Lit_22; if linked_1155 == nil { ifn_1156.Invoke_O_O_O__O(arg_1157, arg_1158, arg_1159) } else { linked_1155.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_1154, arg_1157, arg_1158, arg_1159) } }; if


	lang.Util_Identical_O_O__Z_NoInit(v__9, nil) { return Lit_23 } else { var tmp6 any; var root_1115 any = A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1117 lang.IFn
		if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(splice_QMARK___5).Ref(); if linked_1116 == nil { tmp6 = ifn_1117.Invoke_O__O(arg_1118) } else { tmp6 = linked_1116.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1115, arg_1118) }
//line :166:1
		if jrt.J2g_Truth(tmp6) {
			var root_1119 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1121 lang.IFn; if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any; var root_1125 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = s__0; var arg_1129 any = v__9; var arg_1130 any = ve__10; if linked_1126 == nil { arg_1122 = ifn_1127.Invoke_O_O_O__O(arg_1128, arg_1129, arg_1130) } else { arg_1122 = linked_1126.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1125, arg_1128, arg_1129, arg_1130) }; var arg_1123 any = features__2; var arg_1124 any; if depth__3_b == nil { depth__3_b = jrt.Long_ValueOf_J__Long_NoInit(depth__3_l).Ref(); arg_1124 = depth__3_b } else { arg_1124 = depth__3_b }; if linked_1120 == nil { return ifn_1121.Invoke_O_O_O__O(arg_1122, arg_1123, arg_1124) } else { return linked_1120.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O_O__O(root_1119, arg_1122, arg_1123, arg_1124) } } else {
//line :166:1
				var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_62); var tmp8 any; var root_1160 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_1161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1160, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_1162 lang.IFn

				if linked_1161 == nil { ifn_1162 = lang.IFn_Cast(root_1160) } else { ifn_1162 = nil }; var arg_1163 any = s__0; var arg_1164 any = v__9; if linked_1161 == nil { tmp8 = ifn_1162.Invoke_O_O__O(arg_1163, arg_1164) } else { tmp8 = linked_1161.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_1160, arg_1163, arg_1164) }
//line :166:1
				if jrt.J2g_Truth(tmp7.Invoke_O__O(tmp8)) {

					var root_1131 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any; var root_1137 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1137, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1139 lang.IFn; if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = s__0; var arg_1141 any; var na_1143 any = v__9; if jrt.Long_InstanceOf(na_1143) { var n0_1144 int64 = jrt.NN(jrt.Long_Cast(na_1143)).LongValue__J(); if n0_1144 == 9223372036854775807 { arg_1141 = lang.Numbers_Inc_O__Number_NoInit(na_1143) } else { arg_1141 = jrt.Long_ValueOf_J__Long_NoInit(n0_1144 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1143) { var n0_1144_2 float64 = jrt.NN(jrt.Double_Cast(na_1143)).DoubleValue__D(); arg_1141 = jrt.Double_ValueOf_D__Double_NoInit(n0_1144_2 + 1.0).Ref() } else { arg_1141 = lang.Numbers_Inc_O__Number_NoInit(na_1143) } }; var arg_1142 any; var na_1145 any = ve__10; if jrt.Long_InstanceOf(na_1145) { var n0_1146 int64 = jrt.NN(jrt.Long_Cast(na_1145)).LongValue__J(); if n0_1146 == -9223372036854775808 { arg_1142 = lang.Numbers_Dec_O__Number_NoInit(na_1145) } else { arg_1142 = jrt.Long_ValueOf_J__Long_NoInit(n0_1146 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_1145) { var n0_1146_2 float64 = jrt.NN(jrt.Double_Cast(na_1145)).DoubleValue__D(); arg_1142 = jrt.Double_ValueOf_D__Double_NoInit(n0_1146_2 - 1.0).Ref() } else { arg_1142 = lang.Numbers_Dec_O__Number_NoInit(na_1145) } }; if linked_1138 == nil { arg_1134 = ifn_1139.Invoke_O_O_O__O(arg_1140, arg_1141, arg_1142) } else { arg_1134 = linked_1138.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1137, arg_1140, arg_1141, arg_1142) }; var arg_1135 any = features__2; var arg_1136 any; if depth__3_b == nil { depth__3_b = jrt.Long_ValueOf_J__Long_NoInit(depth__3_l).Ref(); arg_1136 = depth__3_b } else { arg_1136 = depth__3_b }; if linked_1132 == nil { return ifn_1133.Invoke_O_O_O__O(arg_1134, arg_1135, arg_1136) } else { return linked_1132.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O_O__O(root_1131, arg_1134, arg_1135, arg_1136) } } else {
//line :166:1
						if A_arbace_repr_clojure_text_A_const_34 != nil {


							var root_1147 any = A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, A_arbace_repr_clojure_text_fail_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = s__0; var arg_1151 any = v__9; var arg_1152 any = Lit_24; if linked_1148 == nil { return ifn_1149.Invoke_O_O_O__O(arg_1150, arg_1151, arg_1152) } else { return linked_1148.(*A_arbace_repr_clojure_text_fail_A).Invoke_O_O_O_O__O(root_1147, arg_1150, arg_1151, arg_1152) } } else {
//line :166:1
								return nil } } } } }
//line :160:1
func A_arbace_repr_clojure_text_selected_fn__670000038_A_New_O(p0 any) *A_arbace_repr_clojure_text_selected_fn__670000038_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_selected_fn__670000038_A{}; t.Ctor_O(p0); return t }
//line :160:1
func (t *A_arbace_repr_clojure_text_selected_fn__670000038_A) Ctor_O(c__features any) { t.F_features = c__features }
//line :160:1
func (t *A_arbace_repr_clojure_text_selected_fn__670000038_A) Invoke_O_O__O(self, p__670000037__1 any) any { var vec__670000039__2 any = p__670000037__1; var f__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000039__2, lang.RT_IntCast_J__I_NoInit(0), nil); var or__1927000174__auto____4 any; var root_1022 any = A_arbace_repr_clojure_text_A_const_58.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = t.F_features; var arg_1026 any = f__3; if linked_1023 == nil { or__1927000174__auto____4 = ifn_1024.Invoke_O_O__O(arg_1025, arg_1026) } else { or__1927000174__auto____4 = linked_1023.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1022, arg_1025, arg_1026) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(f__3, A_arbace_repr_clojure_text_A_const_59)).Ref() } }










func A_arbace_repr_clojure_text_resolve_STAR__A_New() *A_arbace_repr_clojure_text_resolve_STAR__A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_resolve_STAR__A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_repr_clojure_text_resolve_STAR__A) Ctor() {}
//line :171:1
func (t *A_arbace_repr_clojure_text_resolve_STAR__A) Invoke_O_O_O_O_O__O(self, s__0, features__1, depth0__2, record_QMARK___3 any) any {





	{ var tmp1 any; var root_1165 any = A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1167 lang.IFn; if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any; var root_1169 any = A_arbace_repr_clojure_text_A_const_63.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = s__0; var arg_1173 any = Lit_16; if linked_1170 == nil { arg_1168 = ifn_1171.Invoke_O_O__O(arg_1172, arg_1173) } else { arg_1168 = linked_1170.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_1169, arg_1172, arg_1173) }; if linked_1166 == nil { tmp1 = ifn_1167.Invoke_O__O(arg_1168) } else { tmp1 = linked_1166.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1165, arg_1168) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(s__0, lang.PersistentVector_EMPTY.Ref()) } else { var n__5 int32 = lang.RT_Count_O__I_NoInit(s__0); var sb__6 any = jrt.StringBuilder_New(); var i__7 any = lang.RT_Box_J__Number_NoInit(0); var depth__8 any = depth0__2; var recs__9 any; var root_1174 any = A_arbace_repr_clojure_text_A_const_64.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_1176 lang.IFn


		if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any = lang.PersistentVector_EMPTY.Ref(); if linked_1175 == nil { recs__9 = ifn_1176.Invoke_O__O(arg_1177) } else { recs__9 = linked_1175.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_1174, arg_1177) }
//line :177:1
	L1: for {



		var tmp2 bool; var na_1178 any = i__7; var na_1179 int64 = int64(n__5); if jrt.Long_InstanceOf(na_1178) { var n0_1180 int64 = jrt.NN(jrt.Long_Cast(na_1178)).LongValue__J(); var n1_1181 int64 = na_1179; tmp2 = n0_1180 >= n1_1181 } else { tmp2 = lang.Numbers_Gte_O_J__Z_NoInit(na_1178, na_1179) }; if tmp2 { var tmp3 any; var root_1206 any = A_arbace_repr_clojure_text_A_const_66.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1206, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1208 lang.IFn
			if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = sb__6; if linked_1207 == nil { tmp3 = ifn_1208.Invoke_O__O(arg_1209) } else { tmp3 = linked_1207.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1206, arg_1209) }
//line :181:1
			var tmp4 any = tmp3; var tmp5 any; var root_1210 any = A_arbace_repr_clojure_text_A_const_67.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_1212 lang.IFn
			if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = recs__9; if linked_1211 == nil { tmp5 = ifn_1212.Invoke_O__O(arg_1213) } else { tmp5 = linked_1211.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_1210, arg_1213) }
//line :181:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp5) } else { var c__10 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__7)); var copy__11 any; var fnbody__1184 any = A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A_New_O_O_O(i__7, sb__6, s__0); var tmp6 *jrt.Class
				var fncls__1183 /*line :181:1*/*jrt.Class = A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A_fn_class


				if fncls__1183 == nil { var fncls__1183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, fnbody__1184); A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A_fn_class = fncls__1183d; tmp6 = fncls__1183d } else { tmp6 = fncls__1183 }; copy__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1184, tmp6, nil)
//line :181:1
				var G__670000050__12_ uint16 = c__10



				switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref()) { case 34: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_18) {
					var tmp7 lang.IFn = lang.IFn_Cast(copy__11); var tmp8 any; var root_1214 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1214, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_1216 lang.IFn; if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any = s__0; var arg_1218 any = i__7; if linked_1215 == nil { tmp8 = ifn_1216.Invoke_O_O__O(arg_1217, arg_1218) } else { if jrt.Long_InstanceOf(arg_1218) { tmp8 = linked_1215.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_1214, arg_1217, jrt.NN(jrt.Long_Cast(arg_1218)).LongValue__J(), arg_1218) } else { tmp8 = linked_1215.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_1214, arg_1217, arg_1218) } }; i__7, depth__8, recs__9 = tmp7.Invoke_O__O(tmp8), depth__8, recs__9; continue L1 }
//line :185:1
				case 35: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_36) { var G__670000051__13_ any; var root_1186 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_1188 lang.IFn





					if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any = s__0; var arg_1190 any; var na_1191 any = i__7; if jrt.Long_InstanceOf(na_1191) { var n0_1192 int64 = jrt.NN(jrt.Long_Cast(na_1191)).LongValue__J(); if n0_1192 == 9223372036854775807 { arg_1190 = lang.Numbers_Inc_O__Number_NoInit(na_1191) } else { arg_1190 = jrt.Long_ValueOf_J__Long_NoInit(n0_1192 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1191) { var n0_1192_2 float64 = jrt.NN(jrt.Double_Cast(na_1191)).DoubleValue__D(); arg_1190 = jrt.Double_ValueOf_D__Double_NoInit(n0_1192_2 + 1.0).Ref() } else { arg_1190 = lang.Numbers_Inc_O__Number_NoInit(na_1191) } }; if linked_1187 == nil { G__670000051__13_ = ifn_1188.Invoke_O_O__O(arg_1189, arg_1190) } else { G__670000051__13_ = linked_1187.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_1186, arg_1189, arg_1190) }; switch lang.Util_Hash_O__I_NoInit(G__670000051__13_) { case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__670000051__13_, A_arbace_repr_clojure_text_A_const_37) {

						var tmp9 lang.IFn = lang.IFn_Cast(copy__11); var tmp10 any; var root_1219 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = s__0; var arg_1223 any = i__7; if linked_1220 == nil { tmp10 = ifn_1221.Invoke_O_O__O(arg_1222, arg_1223) } else { tmp10 = linked_1220.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_1219, arg_1222, arg_1223) }; i__7, depth__8, recs__9 = tmp9.Invoke_O__O(tmp10), depth__8, recs__9; continue L1 }
//line :191:1
					case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000051__13_, A_arbace_repr_clojure_text_A_const_18) {
						var tmp11 lang.IFn = lang.IFn_Cast(copy__11); var tmp12 any; var root_1224 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1224, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = s__0; var arg_1228 any; var na_1229 any = i__7; if jrt.Long_InstanceOf(na_1229) { var n0_1230 int64 = jrt.NN(jrt.Long_Cast(na_1229)).LongValue__J(); if n0_1230 == 9223372036854775807 { arg_1228 = lang.Numbers_Inc_O__Number_NoInit(na_1229) } else { arg_1228 = jrt.Long_ValueOf_J__Long_NoInit(n0_1230 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1229) { var n0_1230_2 float64 = jrt.NN(jrt.Double_Cast(na_1229)).DoubleValue__D(); arg_1228 = jrt.Double_ValueOf_D__Double_NoInit(n0_1230_2 + 1.0).Ref() } else { arg_1228 = lang.Numbers_Inc_O__Number_NoInit(na_1229) } }; if linked_1225 == nil { tmp12 = ifn_1226.Invoke_O_O__O(arg_1227, arg_1228) } else { if jrt.Long_InstanceOf(arg_1228) { tmp12 = linked_1225.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_1224, arg_1227, jrt.NN(jrt.Long_Cast(arg_1228)).LongValue__J(), arg_1228) } else { tmp12 = linked_1225.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_1224, arg_1227, arg_1228) } }; i__7, depth__8, recs__9 = tmp11.Invoke_O__O(tmp12), depth__8, recs__9; continue L1 }
//line :191:1
					case 63: if lang.Util_Equiv_O_O__Z_NoInit(G__670000051__13_, A_arbace_repr_clojure_text_A_const_51) { var e__14 any; var root_1194 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1194, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_1196 lang.IFn


						if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any = s__0; var arg_1198 any = i__7; if linked_1195 == nil { e__14 = ifn_1196.Invoke_O_O__O(arg_1197, arg_1198) } else { if jrt.Long_InstanceOf(arg_1198) { e__14 = linked_1195.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_1194, arg_1197, jrt.NN(jrt.Long_Cast(arg_1198)).LongValue__J(), arg_1198) } else { e__14 = linked_1195.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_1194, arg_1197, arg_1198) } }
//line :191:1
						var at0__15 int32 = jrt.NN(jrt.StringBuilder_Cast(sb__6)).Length__I(); var r__16 any; var root_1199 any = A_arbace_repr_clojure_text_A_const_65.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1199, A_arbace_repr_clojure_text_selected_A_fn_class); var ifn_1201 lang.IFn




						if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = s__0; var arg_1203 any = i__7; var arg_1204 any = features__1; var arg_1205 any = depth__8; if linked_1200 == nil { r__16 = ifn_1201.Invoke_O_O_O_O__O(arg_1202, arg_1203, arg_1204, arg_1205) } else { var tmp13 bool; var tmp14 bool; tmp14 = jrt.Long_InstanceOf(arg_1203); if tmp14 { tmp14 = jrt.Long_InstanceOf(arg_1205) }; tmp13 = tmp14; if tmp13 { r__16 = linked_1200.(*A_arbace_repr_clojure_text_selected_A).InvokeSpec_O_O_J_O_O_J_O__O(root_1199, arg_1202, jrt.NN(jrt.Long_Cast(arg_1203)).LongValue__J(), arg_1203, arg_1204, jrt.NN(jrt.Long_Cast(arg_1205)).LongValue__J(), arg_1205) } else { r__16 = linked_1200.(*A_arbace_repr_clojure_text_selected_A).Invoke_O_O_O_O_O__O(root_1199, arg_1202, arg_1203, arg_1204, arg_1205) } }
						jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(jrt.String_Cast(r__16))
						var tmp15 any; if jrt.J2g_Truth(record_QMARK___3) {
							var root_1231 any = A_arbace_repr_clojure_text_A_const_68.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1231, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_1233 lang.IFn; if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any = recs__9; var arg_1235 any; var tmp16 any = A_arbace_repr_clojure_text_A_const_69; var tmp17 any = jrt.Integer_ValueOf_I__Integer_NoInit(at0__15).Ref(); var tmp18 any = A_arbace_repr_clojure_text_A_const_70; var tmp19 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(r__16)).Ref(); var tmp20 any = A_arbace_repr_clojure_text_A_const_71; var tmp21 any; var root_1236 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = s__0; var arg_1240 any = i__7; var arg_1241 any = e__14; if linked_1237 == nil { tmp21 = ifn_1238.Invoke_O_O_O__O(arg_1239, arg_1240, arg_1241) } else { tmp21 = linked_1237.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1236, arg_1239, arg_1240, arg_1241) }; arg_1235 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21)); if linked_1232 == nil { tmp15 = ifn_1233.Invoke_O_O__O(arg_1234, arg_1235) } else { tmp15 = linked_1232.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_1231, arg_1234, arg_1235) } } else {
//line :198:1
								tmp15 = recs__9 }; i__7, depth__8, recs__9 = e__14, depth__8, tmp15; continue L1 }
//line :191:1
					default:
					}








					var tmp22 lang.IFn = lang.IFn_Cast(copy__11); var tmp23 jrt.Number_I; var na_1242 any = i__7; if jrt.Long_InstanceOf(na_1242) { var n0_1243 int64 = jrt.NN(jrt.Long_Cast(na_1242)).LongValue__J(); if n0_1243 == 9223372036854775807 { tmp23 = lang.Numbers_Inc_O__Number_NoInit(na_1242) } else { tmp23 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1243 + 1)) } } else { if jrt.Double_InstanceOf(na_1242) { var n0_1243_2 float64 = jrt.NN(jrt.Double_Cast(na_1242)).DoubleValue__D(); tmp23 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1243_2 + 1.0)) } else { tmp23 = lang.Numbers_Inc_O__Number_NoInit(na_1242) } }; i__7, depth__8, recs__9 = tmp22.Invoke_O__O(tmp23), depth__8, recs__9; continue L1 }
//line :185:1
				case 40: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_19) {



					var tmp24 lang.IFn = lang.IFn_Cast(copy__11); var tmp25 jrt.Number_I; var na_1244 any = i__7; if jrt.Long_InstanceOf(na_1244) { var n0_1245 int64 = jrt.NN(jrt.Long_Cast(na_1244)).LongValue__J(); if n0_1245 == 9223372036854775807 { tmp25 = lang.Numbers_Inc_O__Number_NoInit(na_1244) } else { tmp25 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1245 + 1)) } } else { if jrt.Double_InstanceOf(na_1244) { var n0_1245_2 float64 = jrt.NN(jrt.Double_Cast(na_1244)).DoubleValue__D(); tmp25 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1245_2 + 1.0)) } else { tmp25 = lang.Numbers_Inc_O__Number_NoInit(na_1244) } }; var tmp26 any = tmp24.Invoke_O__O(tmp25); var tmp27 jrt.Number_I; var na_1246 any = depth__8; if jrt.Long_InstanceOf(na_1246) { var n0_1247 int64 = jrt.NN(jrt.Long_Cast(na_1246)).LongValue__J(); if n0_1247 == 9223372036854775807 { tmp27 = lang.Numbers_Inc_O__Number_NoInit(na_1246) } else { tmp27 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1247 + 1)) } } else { if jrt.Double_InstanceOf(na_1246) { var n0_1247_2 float64 = jrt.NN(jrt.Double_Cast(na_1246)).DoubleValue__D(); tmp27 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1247_2 + 1.0)) } else { tmp27 = lang.Numbers_Inc_O__Number_NoInit(na_1246) } }; i__7, depth__8, recs__9 = tmp26, tmp27, recs__9; continue L1 }
//line :185:1
				case 41: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_20) {




					var tmp28 lang.IFn = lang.IFn_Cast(copy__11); var tmp29 jrt.Number_I; var na_1248 any = i__7; if jrt.Long_InstanceOf(na_1248) { var n0_1249 int64 = jrt.NN(jrt.Long_Cast(na_1248)).LongValue__J(); if n0_1249 == 9223372036854775807 { tmp29 = lang.Numbers_Inc_O__Number_NoInit(na_1248) } else { tmp29 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1249 + 1)) } } else { if jrt.Double_InstanceOf(na_1248) { var n0_1249_2 float64 = jrt.NN(jrt.Double_Cast(na_1248)).DoubleValue__D(); tmp29 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1249_2 + 1.0)) } else { tmp29 = lang.Numbers_Inc_O__Number_NoInit(na_1248) } }; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 jrt.Number_I; var na_1250 any = depth__8; if jrt.Long_InstanceOf(na_1250) { var n0_1251 int64 = jrt.NN(jrt.Long_Cast(na_1250)).LongValue__J(); if n0_1251 == -9223372036854775808 { tmp31 = lang.Numbers_Dec_O__Number_NoInit(na_1250) } else { tmp31 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1251 - 1)) } } else { if jrt.Double_InstanceOf(na_1250) { var n0_1251_2 float64 = jrt.NN(jrt.Double_Cast(na_1250)).DoubleValue__D(); tmp31 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1251_2 - 1.0)) } else { tmp31 = lang.Numbers_Dec_O__Number_NoInit(na_1250) } }; i__7, depth__8, recs__9 = tmp30, lang.Numbers_Max_J_O__O_NoInit(0, tmp31), recs__9; continue L1 }
//line :185:1
				case 59: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_21) {

					var tmp32 lang.IFn = lang.IFn_Cast(copy__11); var tmp33 any; var root_1252 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_1254 lang.IFn; if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any = s__0; var arg_1256 any = i__7; if linked_1253 == nil { tmp33 = ifn_1254.Invoke_O_O__O(arg_1255, arg_1256) } else { tmp33 = linked_1253.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_1252, arg_1255, arg_1256) }; i__7, depth__8, recs__9 = tmp32.Invoke_O__O(tmp33), depth__8, recs__9; continue L1 }
//line :185:1
				case 91: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_23) {



					var tmp34 lang.IFn = lang.IFn_Cast(copy__11); var tmp35 jrt.Number_I; var na_1257 any = i__7; if jrt.Long_InstanceOf(na_1257) { var n0_1258 int64 = jrt.NN(jrt.Long_Cast(na_1257)).LongValue__J(); if n0_1258 == 9223372036854775807 { tmp35 = lang.Numbers_Inc_O__Number_NoInit(na_1257) } else { tmp35 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1258 + 1)) } } else { if jrt.Double_InstanceOf(na_1257) { var n0_1258_2 float64 = jrt.NN(jrt.Double_Cast(na_1257)).DoubleValue__D(); tmp35 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1258_2 + 1.0)) } else { tmp35 = lang.Numbers_Inc_O__Number_NoInit(na_1257) } }; var tmp36 any = tmp34.Invoke_O__O(tmp35); var tmp37 jrt.Number_I; var na_1259 any = depth__8; if jrt.Long_InstanceOf(na_1259) { var n0_1260 int64 = jrt.NN(jrt.Long_Cast(na_1259)).LongValue__J(); if n0_1260 == 9223372036854775807 { tmp37 = lang.Numbers_Inc_O__Number_NoInit(na_1259) } else { tmp37 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1260 + 1)) } } else { if jrt.Double_InstanceOf(na_1259) { var n0_1260_2 float64 = jrt.NN(jrt.Double_Cast(na_1259)).DoubleValue__D(); tmp37 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1260_2 + 1.0)) } else { tmp37 = lang.Numbers_Inc_O__Number_NoInit(na_1259) } }; i__7, depth__8, recs__9 = tmp36, tmp37, recs__9; continue L1 }
//line :185:1
				case 92: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_24) {


					var tmp38 lang.IFn = lang.IFn_Cast(copy__11); var tmp39 any; var root_1261 any = A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1261, A_arbace_repr_clojure_text_char_end_A_fn_class); var ifn_1263 lang.IFn; if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any = s__0; var arg_1265 any = i__7; if linked_1262 == nil { tmp39 = ifn_1263.Invoke_O_O__O(arg_1264, arg_1265) } else { if jrt.Long_InstanceOf(arg_1265) { tmp39 = linked_1262.(*A_arbace_repr_clojure_text_char_end_A).InvokeSpec_O_O_J_O__O(root_1261, arg_1264, jrt.NN(jrt.Long_Cast(arg_1265)).LongValue__J(), arg_1265) } else { tmp39 = linked_1262.(*A_arbace_repr_clojure_text_char_end_A).Invoke_O_O_O__O(root_1261, arg_1264, arg_1265) } }; i__7, depth__8, recs__9 = tmp38.Invoke_O__O(tmp39), depth__8, recs__9; continue L1 }
//line :185:1
				case 93: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_25) {




					var tmp40 lang.IFn = lang.IFn_Cast(copy__11); var tmp41 jrt.Number_I; var na_1266 any = i__7; if jrt.Long_InstanceOf(na_1266) { var n0_1267 int64 = jrt.NN(jrt.Long_Cast(na_1266)).LongValue__J(); if n0_1267 == 9223372036854775807 { tmp41 = lang.Numbers_Inc_O__Number_NoInit(na_1266) } else { tmp41 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1267 + 1)) } } else { if jrt.Double_InstanceOf(na_1266) { var n0_1267_2 float64 = jrt.NN(jrt.Double_Cast(na_1266)).DoubleValue__D(); tmp41 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1267_2 + 1.0)) } else { tmp41 = lang.Numbers_Inc_O__Number_NoInit(na_1266) } }; var tmp42 any = tmp40.Invoke_O__O(tmp41); var tmp43 jrt.Number_I; var na_1268 any = depth__8; if jrt.Long_InstanceOf(na_1268) { var n0_1269 int64 = jrt.NN(jrt.Long_Cast(na_1268)).LongValue__J(); if n0_1269 == -9223372036854775808 { tmp43 = lang.Numbers_Dec_O__Number_NoInit(na_1268) } else { tmp43 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1269 - 1)) } } else { if jrt.Double_InstanceOf(na_1268) { var n0_1269_2 float64 = jrt.NN(jrt.Double_Cast(na_1268)).DoubleValue__D(); tmp43 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1269_2 - 1.0)) } else { tmp43 = lang.Numbers_Dec_O__Number_NoInit(na_1268) } }; i__7, depth__8, recs__9 = tmp42, lang.Numbers_Max_J_O__O_NoInit(0, tmp43), recs__9; continue L1 }
//line :185:1
				case 123: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_28) {



					var tmp44 lang.IFn = lang.IFn_Cast(copy__11); var tmp45 jrt.Number_I; var na_1270 any = i__7; if jrt.Long_InstanceOf(na_1270) { var n0_1271 int64 = jrt.NN(jrt.Long_Cast(na_1270)).LongValue__J(); if n0_1271 == 9223372036854775807 { tmp45 = lang.Numbers_Inc_O__Number_NoInit(na_1270) } else { tmp45 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1271 + 1)) } } else { if jrt.Double_InstanceOf(na_1270) { var n0_1271_2 float64 = jrt.NN(jrt.Double_Cast(na_1270)).DoubleValue__D(); tmp45 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1271_2 + 1.0)) } else { tmp45 = lang.Numbers_Inc_O__Number_NoInit(na_1270) } }; var tmp46 any = tmp44.Invoke_O__O(tmp45); var tmp47 jrt.Number_I; var na_1272 any = depth__8; if jrt.Long_InstanceOf(na_1272) { var n0_1273 int64 = jrt.NN(jrt.Long_Cast(na_1272)).LongValue__J(); if n0_1273 == 9223372036854775807 { tmp47 = lang.Numbers_Inc_O__Number_NoInit(na_1272) } else { tmp47 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1273 + 1)) } } else { if jrt.Double_InstanceOf(na_1272) { var n0_1273_2 float64 = jrt.NN(jrt.Double_Cast(na_1272)).DoubleValue__D(); tmp47 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1273_2 + 1.0)) } else { tmp47 = lang.Numbers_Inc_O__Number_NoInit(na_1272) } }; i__7, depth__8, recs__9 = tmp46, tmp47, recs__9; continue L1 }
//line :185:1
				case 125: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__12_).Ref(), A_arbace_repr_clojure_text_A_const_29) {




					var tmp48 lang.IFn = lang.IFn_Cast(copy__11); var tmp49 jrt.Number_I; var na_1274 any = i__7; if jrt.Long_InstanceOf(na_1274) { var n0_1275 int64 = jrt.NN(jrt.Long_Cast(na_1274)).LongValue__J(); if n0_1275 == 9223372036854775807 { tmp49 = lang.Numbers_Inc_O__Number_NoInit(na_1274) } else { tmp49 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1275 + 1)) } } else { if jrt.Double_InstanceOf(na_1274) { var n0_1275_2 float64 = jrt.NN(jrt.Double_Cast(na_1274)).DoubleValue__D(); tmp49 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1275_2 + 1.0)) } else { tmp49 = lang.Numbers_Inc_O__Number_NoInit(na_1274) } }; var tmp50 any = tmp48.Invoke_O__O(tmp49); var tmp51 jrt.Number_I; var na_1276 any = depth__8; if jrt.Long_InstanceOf(na_1276) { var n0_1277 int64 = jrt.NN(jrt.Long_Cast(na_1276)).LongValue__J(); if n0_1277 == -9223372036854775808 { tmp51 = lang.Numbers_Dec_O__Number_NoInit(na_1276) } else { tmp51 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1277 - 1)) } } else { if jrt.Double_InstanceOf(na_1276) { var n0_1277_2 float64 = jrt.NN(jrt.Double_Cast(na_1276)).DoubleValue__D(); tmp51 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1277_2 - 1.0)) } else { tmp51 = lang.Numbers_Dec_O__Number_NoInit(na_1276) } }; i__7, depth__8, recs__9 = tmp50, lang.Numbers_Max_J_O__O_NoInit(0, tmp51), recs__9; continue L1 }
//line :185:1
				default:
				}















				var tmp52 lang.IFn = lang.IFn_Cast(copy__11); var tmp53 any; var tmp54 any; var root_1278 any = A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1278, A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class); var ifn_1280 lang.IFn; if linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any = jrt.Character_ValueOf_C__Character_NoInit(c__10).Ref(); if linked_1279 == nil { tmp54 = ifn_1280.Invoke_O__O(arg_1281) } else { tmp54 = linked_1279.(*A_arbace_repr_clojure_text_terminating_QMARK__A).Invoke_O_O__O(root_1278, arg_1281) }; if jrt.J2g_Truth(tmp54) { var na_1282 any = i__7; if jrt.Long_InstanceOf(na_1282) { var n0_1283 int64 = jrt.NN(jrt.Long_Cast(na_1282)).LongValue__J(); if n0_1283 == 9223372036854775807 { tmp53 = lang.Numbers_Inc_O__Number_NoInit(na_1282) } else { tmp53 = jrt.Long_ValueOf_J__Long_NoInit(n0_1283 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1282) { var n0_1283_2 float64 = jrt.NN(jrt.Double_Cast(na_1282)).DoubleValue__D(); tmp53 = jrt.Double_ValueOf_D__Double_NoInit(n0_1283_2 + 1.0).Ref() } else { tmp53 = lang.Numbers_Inc_O__Number_NoInit(na_1282) } } } else { var root_1284 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = s__0; var arg_1288 any = i__7; if linked_1285 == nil { tmp53 = ifn_1286.Invoke_O_O__O(arg_1287, arg_1288) } else { tmp53 = linked_1285.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_1284, arg_1287, arg_1288) } }; i__7, depth__8, recs__9 = tmp52.Invoke_O__O(tmp53), depth__8, recs__9; continue L1 } } } }
//line :171:1
	panic("j2g: unreachable")
}











func A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :184:1
func (t *A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A) Ctor_O_O_O(c__i, c__sb, c__s any) { t.F_i = c__i; t.F_sb = c__sb; t.F_s = c__s }
//line :184:1
func (t *A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A) Invoke_O_O__O(self, j__1 any) any { var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp2 jrt.CharSequence = jrt.CharSequence_Cast(t.F_s); jrt.NN(tmp1).Append_CharSequence_I_I__StringBuilder(tmp2, lang.RT_IntCast_O__I_NoInit(t.F_i), lang.RT_IntCast_O__I_NoInit(j__1)); return j__1 }



















func A_arbace_repr_clojure_text_resolve_conditionals_A_New() *A_arbace_repr_clojure_text_resolve_conditionals_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_resolve_conditionals_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_A) Ctor() {}
//line :204:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_A) Invoke_O_O_O_O__O(self, s__0, features__1, depth0__2 any) any {





	var root_1289 any = A_arbace_repr_clojure_text_A_const_57.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any; var root_1293 any = A_arbace_repr_clojure_text_A_const_72.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, A_arbace_repr_clojure_text_resolve_STAR__A_fn_class); var ifn_1295 lang.IFn; if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = s__0; var arg_1297 any = features__1; var arg_1298 any = depth0__2; var arg_1299 any = jrt.Boolean_FALSE.Ref(); if linked_1294 == nil { arg_1292 = ifn_1295.Invoke_O_O_O_O__O(arg_1296, arg_1297, arg_1298, arg_1299) } else { arg_1292 = linked_1294.(*A_arbace_repr_clojure_text_resolve_STAR__A).Invoke_O_O_O_O_O__O(root_1293, arg_1296, arg_1297, arg_1298, arg_1299) }; if linked_1290 == nil { return ifn_1291.Invoke_O__O(arg_1292) } else { return linked_1290.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1289, arg_1292) } }
//line :204:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_A) Invoke_O_O_O__O(self, s__0, features__1 any) any {




	var root_1300 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_1301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1300, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1302 lang.IFn; if linked_1301 == nil { ifn_1302 = lang.IFn_Cast(root_1300) } else { ifn_1302 = nil }; var arg_1303 any = s__0; var arg_1304 any = features__1; var arg_1305 any = A_arbace_repr_clojure_text_A_const_12; if linked_1301 == nil { return ifn_1302.Invoke_O_O_O__O(arg_1303, arg_1304, arg_1305) } else { return linked_1301.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O_O__O(root_1300, arg_1303, arg_1304, arg_1305) } }
//line :204:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_A) Invoke_O_O__O(self, s__0 any) any {



	var root_1306 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1308 lang.IFn; if linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any = s__0; var arg_1310 any = A_arbace_repr_clojure_text_A_const_73; if linked_1307 == nil { return ifn_1308.Invoke_O_O__O(arg_1309, arg_1310) } else { return linked_1307.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O__O(root_1306, arg_1309, arg_1310)
	}
}

func A_arbace_repr_clojure_text_record_conditionals_A_New() *A_arbace_repr_clojure_text_record_conditionals_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_record_conditionals_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_repr_clojure_text_record_conditionals_A) Ctor() {}
//line :212:1
func (t *A_arbace_repr_clojure_text_record_conditionals_A) Invoke_O_O_O__O(self, s__0, features__1 any) any { var vec__670000054__3 any; var root_1311 any = A_arbace_repr_clojure_text_A_const_72.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, A_arbace_repr_clojure_text_resolve_STAR__A_fn_class); var ifn_1313 lang.IFn; if





	linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any = s__0; var arg_1315 any = features__1; var arg_1316 any = A_arbace_repr_clojure_text_A_const_12; var arg_1317 any = jrt.Boolean_TRUE.Ref(); if linked_1312 == nil { vec__670000054__3 = ifn_1313.Invoke_O_O_O_O__O(arg_1314, arg_1315, arg_1316, arg_1317) } else { vec__670000054__3 = linked_1312.(*A_arbace_repr_clojure_text_resolve_STAR__A).Invoke_O_O_O_O_O__O(root_1311, arg_1314, arg_1315, arg_1316, arg_1317) }; var t__4 any = /*line :212:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__670000054__3, lang.RT_IntCast_J__I_NoInit(0), nil); var recs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000054__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_text_A_const_71, t__4, A_arbace_repr_clojure_text_A_const_74, recs__5)) }







func A_arbace_repr_clojure_text_restore_conditionals_A_New() *A_arbace_repr_clojure_text_restore_conditionals_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_restore_conditionals_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_repr_clojure_text_restore_conditionals_A) Ctor() {}
//line :220:1
func (t *A_arbace_repr_clojure_text_restore_conditionals_A) Invoke_O_O_O_O__O(self, t__0, conditionals__1, features__2 any) any { var sb__4 any = jrt.StringBuilder_New(); var end__5 any; var root_1318 any = A_arbace_repr_clojure_text_A_const_75.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1320 lang.IFn; if





	linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any; var fnbody__1388 any = A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A_New_O_O_O(sb__4, t__0, features__2); var tmp1 *jrt.Class; var fncls__1387 *jrt.Class = A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A_fn_class; if fncls__1387 == nil { var fncls__1387d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, fnbody__1388); A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A_fn_class = fncls__1387d; tmp1 = fncls__1387d } else { tmp1 = fncls__1387 }; arg_1321 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1388, tmp1, nil); var arg_1322 any = A_arbace_repr_clojure_text_A_const_12; var arg_1323 any = conditionals__1; if linked_1319 == nil { end__5 = ifn_1320.Invoke_O_O_O__O(arg_1321, arg_1322, arg_1323) } else { end__5 = linked_1319.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1318, arg_1321, arg_1322, arg_1323) };










	jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_CharSequence_I_I__StringBuilder(jrt.CharSequence_Cast(t__0), lang.RT_IntCast_O__I_NoInit(end__5), lang.RT_Count_O__I_NoInit(t__0)); var root_1389 any =
	A_arbace_repr_clojure_text_A_const_66.GetRawRoot__O(); var linked_1390 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1389, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1391 lang.IFn; if linked_1390 == nil { ifn_1391 = lang.IFn_Cast(root_1389) } else { ifn_1391 = nil }; var arg_1392 any = sb__4; if linked_1390 == nil { return ifn_1391.Invoke_O__O(arg_1392) } else { return linked_1390.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1389, arg_1392) } }
//line :226:1
func A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :226:1
func (t *A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A) Ctor_O_O_O(c__sb, c__t, c__features any) { t.F_sb = c__sb; t.F_t = c__t; t.F_features = c__features }
//line :226:1
func (t *A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A) Invoke_O_O_O__O(self, pos__1, p__670000058__2 any) any { var map__670000060__3 any = p__670000058__2; var map__670000060__4 any; if lang.ISeq_InstanceOf(map__670000060__3) { var tmp1 any; var root_1324 any = A_arbace_repr_clojure_text_A_const_76.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1326 lang.IFn; if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = map__670000060__3; if linked_1325 == nil { tmp1 = ifn_1326.Invoke_O__O(arg_1327) } else { tmp1 = linked_1325.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1324, arg_1327) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1328 any = A_arbace_repr_clojure_text_A_const_77.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any = map__670000060__3; if linked_1329 == nil { tmp2 = ifn_1330.Invoke_O__O(arg_1331) } else { tmp2 = linked_1329.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1328, arg_1331) }; map__670000060__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1332 any = A_arbace_repr_clojure_text_A_const_78.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = map__670000060__3; if linked_1333 == nil { tmp3 = ifn_1334.Invoke_O__O(arg_1335) } else { tmp3 = linked_1333.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1332, arg_1335) }; if jrt.J2g_Truth(tmp3) { var root_1336 any = A_arbace_repr_clojure_text_A_const_57.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = map__670000060__3; if linked_1337 == nil { map__670000060__4 = ifn_1338.Invoke_O__O(arg_1339) } else { map__670000060__4 = linked_1337.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1336, arg_1339) } } else { map__670000060__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__670000060__4 = map__670000060__3 }; var at__5 any = lang.RT_Get_O_O__O_NoInit(map__670000060__4, A_arbace_repr_clojure_text_A_const_69); var length__6 any = lang.RT_Get_O_O__O_NoInit(map__670000060__4, A_arbace_repr_clojure_text_A_const_70); var text__7 any = lang.RT_Get_O_O__O_NoInit(map__670000060__4, A_arbace_repr_clojure_text_A_const_71); var tmp4 any; var or__1927000174__auto____8 bool; var na_1345 any = at__5; var na_1346 any = pos__1; var tmp5 bool; var tmp6 bool; tmp6 =
																	jrt.Long_InstanceOf(na_1345); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_1346) }; tmp5 = tmp6; if tmp5 { var n0_1347 int64 = jrt.NN(jrt.Long_Cast(na_1345)).LongValue__J(); var n1_1348 int64 = jrt.NN(jrt.Long_Cast(na_1346)).LongValue__J(); or__1927000174__auto____8 = n0_1347 < n1_1348 } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_1345); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_1346) }; tmp7 = tmp8; if tmp7 { var n0_1347_2 float64 = jrt.NN(jrt.Double_Cast(na_1345)).DoubleValue__D(); var n1_1348_2 float64 = jrt.NN(jrt.Double_Cast(na_1346)).DoubleValue__D(); or__1927000174__auto____8 = n0_1347_2 < n1_1348_2 } else { or__1927000174__auto____8 = lang.Numbers_Lt_O_O__Z_NoInit(na_1345, na_1346) } }; if or__1927000174__auto____8 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { var or__1927000174__auto____9 bool; var na_1350 any; var na_1352 any = at__5; var na_1353 any = length__6; var tmp9 bool; var tmp10 bool; tmp10 = jrt.Long_InstanceOf(na_1352); if tmp10 { tmp10 = jrt.Long_InstanceOf(na_1353) }; tmp9 = tmp10; if tmp9 { var n0_1354 int64 = jrt.NN(jrt.Long_Cast(na_1352)).LongValue__J(); var n1_1355 int64 = jrt.NN(jrt.Long_Cast(na_1353)).LongValue__J(); var nr_1356 int64 = n0_1354 + n1_1355; if (n0_1354^nr_1356)&(n1_1355^nr_1356) >= 0 { na_1350 = jrt.Long_ValueOf_J__Long_NoInit(nr_1356).Ref() } else { na_1350 = lang.Numbers_Add_O_O__Number_NoInit(na_1352, na_1353) } } else { var tmp11 bool; var tmp12 bool; tmp12 = jrt.Double_InstanceOf(na_1352); if tmp12 { tmp12 = jrt.Double_InstanceOf(na_1353) }; tmp11 = tmp12; if tmp11 { var n0_1354_2 float64 = jrt.NN(jrt.Double_Cast(na_1352)).DoubleValue__D(); var n1_1355_2 float64 = jrt.NN(jrt.Double_Cast(na_1353)).DoubleValue__D(); na_1350 = jrt.Double_ValueOf_D__Double_NoInit(n0_1354_2 + n1_1355_2).Ref() } else { na_1350 = lang.Numbers_Add_O_O__Number_NoInit(na_1352, na_1353) } }; var na_1351 int64 = int64(lang.RT_Count_O__I_NoInit(t.F_t)); if jrt.Long_InstanceOf(na_1350) { var n0_1357 int64 = jrt.NN(jrt.Long_Cast(na_1350)).LongValue__J(); var n1_1358 int64 = na_1351; or__1927000174__auto____9 = n0_1357 > n1_1358 } else { or__1927000174__auto____9 = lang.Numbers_Gt_O_J__Z_NoInit(na_1350, na_1351) }; if or__1927000174__auto____9 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else {
																		var root_1360 any = A_arbace_repr_clojure_text_A_const_79.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1360, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1362 lang.IFn; if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any; var root_1365 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_1366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1365, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1367 lang.IFn; if linked_1366 == nil { ifn_1367 = lang.IFn_Cast(root_1365) } else { ifn_1367 = nil }; var arg_1368 any = t.F_t; var arg_1369 any = at__5; var arg_1370 any; var na_1371 any = at__5; var na_1372 any = length__6; var tmp13 bool; var tmp14 bool; tmp14 = jrt.Long_InstanceOf(na_1371); if tmp14 { tmp14 = jrt.Long_InstanceOf(na_1372) }; tmp13 = tmp14; if tmp13 { var n0_1373 int64 = jrt.NN(jrt.Long_Cast(na_1371)).LongValue__J(); var n1_1374 int64 = jrt.NN(jrt.Long_Cast(na_1372)).LongValue__J(); var nr_1375 int64 = n0_1373 + n1_1374; if (n0_1373^nr_1375)&(n1_1374^nr_1375) >= 0 { arg_1370 = jrt.Long_ValueOf_J__Long_NoInit(nr_1375).Ref() } else { arg_1370 = lang.Numbers_Add_O_O__Number_NoInit(na_1371, na_1372) } } else { var tmp15 bool; var tmp16 bool; tmp16 = jrt.Double_InstanceOf(na_1371); if tmp16 { tmp16 = jrt.Double_InstanceOf(na_1372) }; tmp15 = tmp16; if tmp15 { var n0_1373_2 float64 = jrt.NN(jrt.Double_Cast(na_1371)).DoubleValue__D(); var n1_1374_2 float64 = jrt.NN(jrt.Double_Cast(na_1372)).DoubleValue__D(); arg_1370 = jrt.Double_ValueOf_D__Double_NoInit(n0_1373_2 + n1_1374_2).Ref() } else { arg_1370 = lang.Numbers_Add_O_O__Number_NoInit(na_1371, na_1372) } }; if linked_1366 == nil { arg_1363 = ifn_1367.Invoke_O_O_O__O(arg_1368, arg_1369, arg_1370) } else { arg_1363 = linked_1366.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1365, arg_1368, arg_1369, arg_1370) }; var arg_1364 any; var root_1376 any = A_arbace_repr_clojure_text_A_const_61.GetRawRoot__O(); var linked_1377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1376, A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1378 lang.IFn
																		if linked_1377 == nil { ifn_1378 = lang.IFn_Cast(root_1376) } else { ifn_1378 = nil }; var arg_1379 any = text__7; var arg_1380 any = t.F_features; var arg_1381 any = A_arbace_repr_clojure_text_A_const_56; if linked_1377 == nil { arg_1364 = ifn_1378.Invoke_O_O_O__O(arg_1379, arg_1380, arg_1381) } else { arg_1364 = linked_1377.(*A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O_O__O(root_1376, arg_1379, arg_1380, arg_1381) }
//line :228:1
		if linked_1361 == nil { tmp4 = ifn_1362.Invoke_O_O__O(arg_1363, arg_1364) } else { tmp4 = linked_1361.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1360, arg_1363, arg_1364) } } }; if /*line :227:1*/ jrt.J2g_Truth(tmp4) { var tmp17 any; var root_1382 any = A_arbace_repr_clojure_text_A_const_13.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1384 lang.IFn


			if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil, Lit_20), jrt.RefArrayOf(jrt.Object_class, nil, at__5, nil)).Ref(); var arg_1386 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_text_A_const_69, at__5)); if linked_1383 == nil { tmp17 = ifn_1384.Invoke_O_O__O(arg_1385, arg_1386) } else { tmp17 = linked_1383.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1382, arg_1385, arg_1386) }
//line :227:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp17))) }; var tmp18 /*line :233:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp19 jrt.CharSequence = jrt.CharSequence_Cast(t.F_t); jrt.NN(tmp18).Append_CharSequence_I_I__StringBuilder(tmp19, lang.RT_IntCast_O__I_NoInit(pos__1), lang.RT_IntCast_O__I_NoInit(at__5)); var tmp20 /*line :234:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp20).Append_String__StringBuilder(jrt.String_Cast(text__7)); var na_1340 any = at__5; var na_1341 any = length__6; var tmp21 bool; var tmp22 bool; tmp22 =
	jrt.Long_InstanceOf(na_1340); if tmp22 { tmp22 = jrt.Long_InstanceOf(na_1341) }; tmp21 = tmp22; if tmp21 { var n0_1342 int64 = jrt.NN(jrt.Long_Cast(na_1340)).LongValue__J(); var n1_1343 int64 = jrt.NN(jrt.Long_Cast(na_1341)).LongValue__J(); var nr_1344 int64 = n0_1342 + n1_1343; if (n0_1342^nr_1344)&(n1_1343^nr_1344) >= 0 { return jrt.Long_ValueOf_J__Long_NoInit(nr_1344).Ref() } else { return lang.Numbers_Add_O_O__Number_NoInit(na_1340, na_1341) } } else { var tmp23 bool; var tmp24 bool; tmp24 = jrt.Double_InstanceOf(na_1340); if tmp24 { tmp24 = jrt.Double_InstanceOf(na_1341) }; tmp23 = tmp24; if tmp23 { var n0_1342_2 float64 = jrt.NN(jrt.Double_Cast(na_1340)).DoubleValue__D(); var n1_1343_2 float64 = jrt.NN(jrt.Double_Cast(na_1341)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_1342_2 + n1_1343_2).Ref() } else { return lang.Numbers_Add_O_O__Number_NoInit(na_1340, na_1341) } } }






func A_arbace_repr_clojure_text_code_tokens_A_New() *A_arbace_repr_clojure_text_code_tokens_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_code_tokens_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_repr_clojure_text_code_tokens_A) Ctor() {}
//line :242:1
func (t *A_arbace_repr_clojure_text_code_tokens_A) Invoke_O_O__O(self, s__0 any) any { { var n__2 int32 = lang.RT_Count_O__I_NoInit(s__0); var i__3 any = lang.RT_Box_J__Number_NoInit(0); var out__4 any; var root_1393 any = A_arbace_repr_clojure_text_A_const_64.GetRawRoot__O(); var linked_1394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1393, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_1395 lang.IFn




	if linked_1394 == nil { ifn_1395 = lang.IFn_Cast(root_1393) } else { ifn_1395 = nil }; var arg_1396 any = lang.PersistentVector_EMPTY.Ref(); if linked_1394 == nil { out__4 = ifn_1395.Invoke_O__O(arg_1396) } else { out__4 = linked_1394.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_1393, arg_1396) }
//line :242:1
L1: for {





	var tmp1 bool; var na_1397 any = i__3; var na_1398 int64 = int64(n__2); if jrt.Long_InstanceOf(na_1397) { var n0_1399 int64 = jrt.NN(jrt.Long_Cast(na_1397)).LongValue__J(); var n1_1400 int64 = na_1398; tmp1 = n0_1399 >= n1_1400 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_1397, na_1398) }; if tmp1 {
		var root_1402 any = A_arbace_repr_clojure_text_A_const_67.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = out__4; if linked_1403 == nil { return ifn_1404.Invoke_O__O(arg_1405) } else { return linked_1403.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_1402, arg_1405) } } else {
//line :248:1
			var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__3))


			if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_18)).CharValue__C()) {
				var tmp2 any; var root_1423 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1423, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any = s__0; var arg_1427 any = i__3; if linked_1424 == nil { tmp2 = ifn_1425.Invoke_O_O__O(arg_1426, arg_1427) } else { if jrt.Long_InstanceOf(arg_1427) { tmp2 = linked_1424.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_1423, arg_1426, jrt.NN(jrt.Long_Cast(arg_1427)).LongValue__J(), arg_1427) } else { tmp2 = linked_1424.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_1423, arg_1426, arg_1427) } }; i__3, out__4 = tmp2, out__4; continue L1 } else {
//line :251:1
					if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_21)).CharValue__C()) {

						var tmp3 any; var root_1428 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = s__0; var arg_1432 any = i__3; if linked_1429 == nil { tmp3 = ifn_1430.Invoke_O_O__O(arg_1431, arg_1432) } else { tmp3 = linked_1429.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_1428, arg_1431, arg_1432) }; i__3, out__4 = tmp3, out__4; continue L1 } else {
//line :251:1
							if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_24)).CharValue__C()) {


								var tmp4 any; var root_1433 any = A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1433, A_arbace_repr_clojure_text_char_end_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = s__0; var arg_1437 any = i__3; if linked_1434 == nil { tmp4 = ifn_1435.Invoke_O_O__O(arg_1436, arg_1437) } else { if jrt.Long_InstanceOf(arg_1437) { tmp4 = linked_1434.(*A_arbace_repr_clojure_text_char_end_A).InvokeSpec_O_O_J_O__O(root_1433, arg_1436, jrt.NN(jrt.Long_Cast(arg_1437)).LongValue__J(), arg_1437) } else { tmp4 = linked_1434.(*A_arbace_repr_clojure_text_char_end_A).Invoke_O_O_O__O(root_1433, arg_1436, arg_1437) } }; i__3, out__4 = tmp4, out__4; continue L1 } else {
//line :251:1
									if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C()) { var G__670000065__6_ any; var root_1406 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_1408 lang.IFn



										if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any = s__0; var arg_1410 any; var na_1411 any = i__3; if jrt.Long_InstanceOf(na_1411) { var n0_1412 int64 = jrt.NN(jrt.Long_Cast(na_1411)).LongValue__J(); if n0_1412 == 9223372036854775807 { arg_1410 = lang.Numbers_Inc_O__Number_NoInit(na_1411) } else { arg_1410 = jrt.Long_ValueOf_J__Long_NoInit(n0_1412 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1411) { var n0_1412_2 float64 = jrt.NN(jrt.Double_Cast(na_1411)).DoubleValue__D(); arg_1410 = jrt.Double_ValueOf_D__Double_NoInit(n0_1412_2 + 1.0).Ref() } else { arg_1410 = lang.Numbers_Inc_O__Number_NoInit(na_1411) } }; if linked_1407 == nil { G__670000065__6_ = ifn_1408.Invoke_O_O__O(arg_1409, arg_1410) } else { G__670000065__6_ = linked_1407.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_1406, arg_1409, arg_1410) }; switch lang.Util_Hash_O__I_NoInit(G__670000065__6_) { case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__670000065__6_, A_arbace_repr_clojure_text_A_const_37) {

											var tmp5 any; var root_1438 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_1439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1438, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_1440 lang.IFn; if linked_1439 == nil { ifn_1440 = lang.IFn_Cast(root_1438) } else { ifn_1440 = nil }; var arg_1441 any = s__0; var arg_1442 any = i__3; if linked_1439 == nil { tmp5 = ifn_1440.Invoke_O_O__O(arg_1441, arg_1442) } else { tmp5 = linked_1439.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_1438, arg_1441, arg_1442) }; i__3, out__4 = tmp5, out__4; continue L1 }
//line :255:1
										case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000065__6_, A_arbace_repr_clojure_text_A_const_18) {
											var tmp6 any; var root_1443 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1443, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_1445 lang.IFn; if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = s__0; var arg_1447 any; var na_1448 any = i__3; if jrt.Long_InstanceOf(na_1448) { var n0_1449 int64 = jrt.NN(jrt.Long_Cast(na_1448)).LongValue__J(); if n0_1449 == 9223372036854775807 { arg_1447 = lang.Numbers_Inc_O__Number_NoInit(na_1448) } else { arg_1447 = jrt.Long_ValueOf_J__Long_NoInit(n0_1449 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1448) { var n0_1449_2 float64 = jrt.NN(jrt.Double_Cast(na_1448)).DoubleValue__D(); arg_1447 = jrt.Double_ValueOf_D__Double_NoInit(n0_1449_2 + 1.0).Ref() } else { arg_1447 = lang.Numbers_Inc_O__Number_NoInit(na_1448) } }; if linked_1444 == nil { tmp6 = ifn_1445.Invoke_O_O__O(arg_1446, arg_1447) } else { if jrt.Long_InstanceOf(arg_1447) { tmp6 = linked_1444.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_1443, arg_1446, jrt.NN(jrt.Long_Cast(arg_1447)).LongValue__J(), arg_1447) } else { tmp6 = linked_1444.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_1443, arg_1446, arg_1447) } }; i__3, out__4 = tmp6, out__4; continue L1 }
//line :255:1
										default:
										}

										var tmp7 jrt.Number_I; var na_1450 any = i__3; if jrt.Long_InstanceOf(na_1450) { var n0_1451 int64 = jrt.NN(jrt.Long_Cast(na_1450)).LongValue__J(); if n0_1451 == 9223372036854775807 { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_1450) } else { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1451 + 1)) } } else { if jrt.Double_InstanceOf(na_1450) { var n0_1451_2 float64 = jrt.NN(jrt.Double_Cast(na_1450)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1451_2 + 1.0)) } else { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_1450) } }; i__3, out__4 = tmp7, out__4; continue L1 } else {
//line :251:1
											var tmp8 any; var root_1414 any = A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O(); var linked_1415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1414, A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class); var ifn_1416 lang.IFn







											if linked_1415 == nil { ifn_1416 = lang.IFn_Cast(root_1414) } else { ifn_1416 = nil }; var arg_1417 any = jrt.Character_ValueOf_C__Character_NoInit(c__5).Ref(); if linked_1415 == nil { tmp8 = ifn_1416.Invoke_O__O(arg_1417) } else { tmp8 = linked_1415.(*A_arbace_repr_clojure_text_terminating_QMARK__A).Invoke_O_O__O(root_1414, arg_1417) }
//line :251:1
											if jrt.J2g_Truth(tmp8) {







												var tmp9 jrt.Number_I; var na_1452 any = i__3; if jrt.Long_InstanceOf(na_1452) { var n0_1453 int64 = jrt.NN(jrt.Long_Cast(na_1452)).LongValue__J(); if n0_1453 == 9223372036854775807 { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_1452) } else { tmp9 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1453 + 1)) } } else { if jrt.Double_InstanceOf(na_1452) { var n0_1453_2 float64 = jrt.NN(jrt.Double_Cast(na_1452)).DoubleValue__D(); tmp9 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1453_2 + 1.0)) } else { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_1452) } }; i__3, out__4 = tmp9, out__4; continue L1 } else {
//line :251:1
													var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_80); if jrt.J2g_Truth(tmp10.Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(c__5).Ref())) {








														var tmp11 jrt.Number_I; var na_1454 any = i__3; if jrt.Long_InstanceOf(na_1454) { var n0_1455 int64 = jrt.NN(jrt.Long_Cast(na_1454)).LongValue__J(); if n0_1455 == 9223372036854775807 { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_1454) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1455 + 1)) } } else { if jrt.Double_InstanceOf(na_1454) { var n0_1455_2 float64 = jrt.NN(jrt.Double_Cast(na_1454)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1455_2 + 1.0)) } else { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_1454) } }; i__3, out__4 = tmp11, out__4; continue L1 } else {
//line :251:1
															if A_arbace_repr_clojure_text_A_const_34 != nil { var e__6 any; var root_1418 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_1420 lang.IFn









																if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any = s__0; var arg_1422 any = i__3; if linked_1419 == nil { e__6 = ifn_1420.Invoke_O_O__O(arg_1421, arg_1422) } else { e__6 = linked_1419.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_1418, arg_1421, arg_1422) }; var tmp12 any; var root_1456 any = A_arbace_repr_clojure_text_A_const_68.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1456, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_1458 lang.IFn; if linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any = out__4; var arg_1460 any = lang.Tuple_Create_O_O__IPersistentVector(i__3, e__6); if linked_1457 == nil { tmp12 = ifn_1458.Invoke_O_O__O(arg_1459, arg_1460) } else { tmp12 = linked_1457.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_1456, arg_1459, arg_1460) }; i__3, out__4 = e__6, tmp12; continue L1 } else {
//line :251:1
																	return nil } } } } } } } } } }; /*line :242:1*/panic("j2g: unreachable") }




















func A_arbace_repr_clojure_text_list_spans_A_New() *A_arbace_repr_clojure_text_list_spans_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_list_spans_A{}; t.Ctor(); return t }
//line :263:1
func (t *A_arbace_repr_clojure_text_list_spans_A) Ctor() {}
//line :263:1
func (t *A_arbace_repr_clojure_text_list_spans_A) Invoke_O_O_O__O(self, s__0, pred__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var i__4 any = lang.RT_Box_J__Number_NoInit(0); var out__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




	var tmp1 bool; var na_1461 any = i__4; var na_1462 int64 = int64(n__3); if jrt.Long_InstanceOf(na_1461) { var n0_1463 int64 = jrt.NN(jrt.Long_Cast(na_1461)).LongValue__J(); var n1_1464 int64 = na_1462; tmp1 = n0_1463 >= n1_1464 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_1461, na_1462) }; if tmp1 { return out__5 } else { var c__6 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__4))


		if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_18)).CharValue__C()) {
			var tmp2 any; var root_1516 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1516, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_1518 lang.IFn; if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any = s__0; var arg_1520 any = i__4; if linked_1517 == nil { tmp2 = ifn_1518.Invoke_O_O__O(arg_1519, arg_1520) } else { if jrt.Long_InstanceOf(arg_1520) { tmp2 = linked_1517.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_1516, arg_1519, jrt.NN(jrt.Long_Cast(arg_1520)).LongValue__J(), arg_1520) } else { tmp2 = linked_1517.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_1516, arg_1519, arg_1520) } }; i__4, out__5 = tmp2, out__5; continue L1 } else {
//line :271:1
				if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_21)).CharValue__C()) {

					var tmp3 any; var root_1521 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1521, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_1523 lang.IFn; if linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any = s__0; var arg_1525 any = i__4; if linked_1522 == nil { tmp3 = ifn_1523.Invoke_O_O__O(arg_1524, arg_1525) } else { tmp3 = linked_1522.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_1521, arg_1524, arg_1525) }; i__4, out__5 = tmp3, out__5; continue L1 } else {
//line :271:1
						if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_24)).CharValue__C()) {


							var tmp4 any; var root_1526 any = A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1526, A_arbace_repr_clojure_text_char_end_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = s__0; var arg_1530 any = i__4; if linked_1527 == nil { tmp4 = ifn_1528.Invoke_O_O__O(arg_1529, arg_1530) } else { if jrt.Long_InstanceOf(arg_1530) { tmp4 = linked_1527.(*A_arbace_repr_clojure_text_char_end_A).InvokeSpec_O_O_J_O__O(root_1526, arg_1529, jrt.NN(jrt.Long_Cast(arg_1530)).LongValue__J(), arg_1530) } else { tmp4 = linked_1527.(*A_arbace_repr_clojure_text_char_end_A).Invoke_O_O_O__O(root_1526, arg_1529, arg_1530) } }; i__4, out__5 = tmp4, out__5; continue L1 } else {
//line :271:1
								var tmp5 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())



								if and__1927000168__auto____7 { var tmp6 any = A_arbace_repr_clojure_text_A_const_18; var tmp7 any; var root_1466 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_1468 lang.IFn; if linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any = s__0; var arg_1470 any; var na_1471 any = i__4; if jrt.Long_InstanceOf(na_1471) { var n0_1472 int64 = jrt.NN(jrt.Long_Cast(na_1471)).LongValue__J(); if n0_1472 == 9223372036854775807 { arg_1470 = lang.Numbers_Inc_O__Number_NoInit(na_1471) } else { arg_1470 = jrt.Long_ValueOf_J__Long_NoInit(n0_1472 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1471) { var n0_1472_2 float64 = jrt.NN(jrt.Double_Cast(na_1471)).DoubleValue__D(); arg_1470 = jrt.Double_ValueOf_D__Double_NoInit(n0_1472_2 + 1.0).Ref() } else { arg_1470 = lang.Numbers_Inc_O__Number_NoInit(na_1471) } }; if linked_1467 == nil { tmp7 = ifn_1468.Invoke_O_O__O(arg_1469, arg_1470) } else { tmp7 = linked_1467.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_1466, arg_1469, arg_1470) }; tmp5 = lang.Util_Equiv_O_O__Z_NoInit(tmp6, tmp7) } else { tmp5 = and__1927000168__auto____7 }
//line :271:1
								if tmp5 {



									var tmp8 any; var root_1531 any = A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1531, A_arbace_repr_clojure_text_string_end_A_fn_class); var ifn_1533 lang.IFn; if linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = s__0; var arg_1535 any; var na_1536 any = i__4; if jrt.Long_InstanceOf(na_1536) { var n0_1537 int64 = jrt.NN(jrt.Long_Cast(na_1536)).LongValue__J(); if n0_1537 == 9223372036854775807 { arg_1535 = lang.Numbers_Inc_O__Number_NoInit(na_1536) } else { arg_1535 = jrt.Long_ValueOf_J__Long_NoInit(n0_1537 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1536) { var n0_1537_2 float64 = jrt.NN(jrt.Double_Cast(na_1536)).DoubleValue__D(); arg_1535 = jrt.Double_ValueOf_D__Double_NoInit(n0_1537_2 + 1.0).Ref() } else { arg_1535 = lang.Numbers_Inc_O__Number_NoInit(na_1536) } }; if linked_1532 == nil { tmp8 = ifn_1533.Invoke_O_O__O(arg_1534, arg_1535) } else { if jrt.Long_InstanceOf(arg_1535) { tmp8 = linked_1532.(*A_arbace_repr_clojure_text_string_end_A).InvokeSpec_O_O_J_O__O(root_1531, arg_1534, jrt.NN(jrt.Long_Cast(arg_1535)).LongValue__J(), arg_1535) } else { tmp8 = linked_1532.(*A_arbace_repr_clojure_text_string_end_A).Invoke_O_O_O__O(root_1531, arg_1534, arg_1535) } }; i__4, out__5 = tmp8, out__5; continue L1 } else {
//line :271:1
										var tmp9 bool; var and__1927000168__auto____7_2 bool = lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())




										if and__1927000168__auto____7_2 { var tmp10 any = A_arbace_repr_clojure_text_A_const_37; var tmp11 any; var root_1473 any = A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, A_arbace_repr_clojure_text_at_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = s__0; var arg_1477 any; var na_1478 any = i__4; if jrt.Long_InstanceOf(na_1478) { var n0_1479 int64 = jrt.NN(jrt.Long_Cast(na_1478)).LongValue__J(); if n0_1479 == 9223372036854775807 { arg_1477 = lang.Numbers_Inc_O__Number_NoInit(na_1478) } else { arg_1477 = jrt.Long_ValueOf_J__Long_NoInit(n0_1479 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1478) { var n0_1479_2 float64 = jrt.NN(jrt.Double_Cast(na_1478)).DoubleValue__D(); arg_1477 = jrt.Double_ValueOf_D__Double_NoInit(n0_1479_2 + 1.0).Ref() } else { arg_1477 = lang.Numbers_Inc_O__Number_NoInit(na_1478) } }; if linked_1474 == nil { tmp11 = ifn_1475.Invoke_O_O__O(arg_1476, arg_1477) } else { tmp11 = linked_1474.(*A_arbace_repr_clojure_text_at_A).Invoke_O_O_O__O(root_1473, arg_1476, arg_1477) }; tmp9 = lang.Util_Equiv_O_O__Z_NoInit(tmp10, tmp11) } else { tmp9 = and__1927000168__auto____7_2 }
//line :271:1
										if tmp9 {




											var tmp12 any; var root_1538 any = A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, A_arbace_repr_clojure_text_line_end_A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = s__0; var arg_1542 any = i__4; if linked_1539 == nil { tmp12 = ifn_1540.Invoke_O_O__O(arg_1541, arg_1542) } else { tmp12 = linked_1539.(*A_arbace_repr_clojure_text_line_end_A).Invoke_O_O_O__O(root_1538, arg_1541, arg_1542) }; i__4, out__5 = tmp12, out__5; continue L1 } else {
//line :271:1
												if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_19)).CharValue__C()) { var h__7 any; var root_1480 any = A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, A_arbace_repr_clojure_text_skip_ws_A_fn_class); var ifn_1482 lang.IFn






													if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = s__0; var arg_1484 any; var na_1485 any = i__4; if jrt.Long_InstanceOf(na_1485) { var n0_1486 int64 = jrt.NN(jrt.Long_Cast(na_1485)).LongValue__J(); if n0_1486 == 9223372036854775807 { arg_1484 = lang.Numbers_Inc_O__Number_NoInit(na_1485) } else { arg_1484 = jrt.Long_ValueOf_J__Long_NoInit(n0_1486 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1485) { var n0_1486_2 float64 = jrt.NN(jrt.Double_Cast(na_1485)).DoubleValue__D(); arg_1484 = jrt.Double_ValueOf_D__Double_NoInit(n0_1486_2 + 1.0).Ref() } else { arg_1484 = lang.Numbers_Inc_O__Number_NoInit(na_1485) } }; if linked_1481 == nil { h__7 = ifn_1482.Invoke_O_O__O(arg_1483, arg_1484) } else { h__7 = linked_1481.(*A_arbace_repr_clojure_text_skip_ws_A).Invoke_O_O_O__O(root_1480, arg_1483, arg_1484) }
//line :271:1
													var head__8 any; var tmp13 any; var and__1927000168__auto____8 bool; var na_1487 any = h__7; var na_1488 int64 = int64(n__3)







													if jrt.Long_InstanceOf(na_1487) { var n0_1489 int64 = jrt.NN(jrt.Long_Cast(na_1487)).LongValue__J(); var n1_1490 int64 = na_1488; and__1927000168__auto____8 = n0_1489 < n1_1490 } else { and__1927000168__auto____8 = lang.Numbers_Lt_O_J__Z_NoInit(na_1487, na_1488) }; if and__1927000168__auto____8 { var root_1492 any = A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any; var root_1496 any = A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class); var ifn_1498 lang.IFn; if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(h__7))).Ref(); if linked_1497 == nil { arg_1495 = ifn_1498.Invoke_O__O(arg_1499) } else { arg_1495 = linked_1497.(*A_arbace_repr_clojure_text_terminating_QMARK__A).Invoke_O_O__O(root_1496, arg_1499) }; if linked_1493 == nil { tmp13 = ifn_1494.Invoke_O__O(arg_1495) } else { tmp13 = linked_1493.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1492, arg_1495) } } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp13) {
														var root_1500 any = A_arbace_repr_clojure_text_A_const_11.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1502 lang.IFn; if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any = s__0; var arg_1504 any = h__7; var arg_1505 any; var root_1506 any = A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O(); var linked_1507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1506, A_arbace_repr_clojure_text_token_end_A_fn_class); var ifn_1508 lang.IFn; if linked_1507 == nil { ifn_1508 = lang.IFn_Cast(root_1506) } else { ifn_1508 = nil }; var arg_1509 any = s__0; var arg_1510 any = h__7; if linked_1507 == nil { arg_1505 = ifn_1508.Invoke_O_O__O(arg_1509, arg_1510) } else { arg_1505 = linked_1507.(*A_arbace_repr_clojure_text_token_end_A).Invoke_O_O_O__O(root_1506, arg_1509, arg_1510) }; if linked_1501 == nil { head__8 = ifn_1502.Invoke_O_O_O__O(arg_1503, arg_1504, arg_1505) } else { head__8 = linked_1501.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1500, arg_1503, arg_1504, arg_1505) } } else {
//line :279:1
															head__8 = nil
														}
													var tmp14 any; var and__1927000168__auto____9 any = head__8; if jrt.J2g_Truth(and__1927000168__auto____9) { tmp14 = lang.IFn_Cast(pred__1).Invoke_O__O(head__8) } else { tmp14 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp14) { var e__9 any; var root_1511 any = A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1511, A_arbace_repr_clojure_text_form_end_A_fn_class); var ifn_1513 lang.IFn
														if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any = s__0; var arg_1515 any = i__4; if linked_1512 == nil { e__9 = ifn_1513.Invoke_O_O__O(arg_1514, arg_1515) } else { if jrt.Long_InstanceOf(arg_1515) { e__9 = linked_1512.(*A_arbace_repr_clojure_text_form_end_A).InvokeSpec_O_O_J_O__O(root_1511, arg_1514, jrt.NN(jrt.Long_Cast(arg_1515)).LongValue__J(), arg_1515) } else { e__9 = linked_1512.(*A_arbace_repr_clojure_text_form_end_A).Invoke_O_O_O__O(root_1511, arg_1514, arg_1515) } }; var tmp15 any; var root_1543 any = A_arbace_repr_clojure_text_A_const_7.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1543, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1545 lang.IFn; if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = out__5; var arg_1547 any = lang.Tuple_Create_O_O__IPersistentVector(i__4, e__9); if linked_1544 == nil { tmp15 = ifn_1545.Invoke_O_O__O(arg_1546, arg_1547) } else { tmp15 = linked_1544.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1543, arg_1546, arg_1547) }; i__4, out__5 = e__9, tmp15; continue L1 } else {
															var tmp16 jrt.Number_I; var na_1548 any = i__4; if jrt.Long_InstanceOf(na_1548) { var n0_1549 int64 = jrt.NN(jrt.Long_Cast(na_1548)).LongValue__J(); if n0_1549 == 9223372036854775807 { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_1548) } else { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1549 + 1)) } } else { if jrt.Double_InstanceOf(na_1548) { var n0_1549_2 float64 = jrt.NN(jrt.Double_Cast(na_1548)).DoubleValue__D(); tmp16 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1549_2 + 1.0)) } else { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_1548) } }; i__4, out__5 = tmp16, out__5; continue L1 } } else {
//line :271:1
																if A_arbace_repr_clojure_text_A_const_34 != nil {












																	var tmp17 jrt.Number_I; var na_1550 any = i__4; if jrt.Long_InstanceOf(na_1550) { var n0_1551 int64 = jrt.NN(jrt.Long_Cast(na_1550)).LongValue__J(); if n0_1551 == 9223372036854775807 { tmp17 = lang.Numbers_Inc_O__Number_NoInit(na_1550) } else { tmp17 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1551 + 1)) } } else { if jrt.Double_InstanceOf(na_1550) { var n0_1551_2 float64 = jrt.NN(jrt.Double_Cast(na_1550)).DoubleValue__D(); tmp17 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1551_2 + 1.0)) } else { tmp17 = lang.Numbers_Inc_O__Number_NoInit(na_1550) } }; i__4, out__5 = tmp17, out__5; continue L1 } else {
//line :271:1
																		return nil } } } } } } } } } }; /*line :263:1*/panic("j2g: unreachable") }







type A_arbace_repr_clojure_text_A struct{ jrt.Object }

var A_arbace_repr_clojure_text_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_text_A_const_0 *lang.Var

var A_arbace_repr_clojure_text_A_const_1 any

var A_arbace_repr_clojure_text_A_const_2 *lang.Var

var A_arbace_repr_clojure_text_A_const_3 any

var A_arbace_repr_clojure_text_A_const_4 *lang.Var

var A_arbace_repr_clojure_text_A_const_5 *lang.Var

var A_arbace_repr_clojure_text_A_const_6 *lang.Var

var A_arbace_repr_clojure_text_A_const_7 *lang.Var

var A_arbace_repr_clojure_text_A_const_8 any

var A_arbace_repr_clojure_text_A_const_9 *lang.Var

var A_arbace_repr_clojure_text_A_const_10 any

var A_arbace_repr_clojure_text_A_const_11 *lang.Var

var A_arbace_repr_clojure_text_A_const_12 any

var A_arbace_repr_clojure_text_A_const_13 *lang.Var

var A_arbace_repr_clojure_text_A_const_14 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_15 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_16 any

var A_arbace_repr_clojure_text_A_const_17 *lang.Var

var A_arbace_repr_clojure_text_A_const_18 any

var A_arbace_repr_clojure_text_A_const_19 any

var A_arbace_repr_clojure_text_A_const_20 any

var A_arbace_repr_clojure_text_A_const_21 any

var A_arbace_repr_clojure_text_A_const_22 any

var A_arbace_repr_clojure_text_A_const_23 any

var A_arbace_repr_clojure_text_A_const_24 any

var A_arbace_repr_clojure_text_A_const_25 any

var A_arbace_repr_clojure_text_A_const_26 any

var A_arbace_repr_clojure_text_A_const_27 any

var A_arbace_repr_clojure_text_A_const_28 any

var A_arbace_repr_clojure_text_A_const_29 any

var A_arbace_repr_clojure_text_A_const_30 any

var A_arbace_repr_clojure_text_A_const_31 *lang.Var

var A_arbace_repr_clojure_text_A_const_32 *lang.Var

var A_arbace_repr_clojure_text_A_const_33 *lang.Var

var A_arbace_repr_clojure_text_A_const_34 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_35 *lang.Var

var A_arbace_repr_clojure_text_A_const_36 any

var A_arbace_repr_clojure_text_A_const_37 any

var A_arbace_repr_clojure_text_A_const_38 *lang.Var

var A_arbace_repr_clojure_text_A_const_39 any

var A_arbace_repr_clojure_text_A_const_40 *lang.Var

var A_arbace_repr_clojure_text_A_const_41 *lang.Var

var A_arbace_repr_clojure_text_A_const_42 *lang.Var

var A_arbace_repr_clojure_text_A_const_43 *lang.Var

var A_arbace_repr_clojure_text_A_const_44 any

var A_arbace_repr_clojure_text_A_const_45 *lang.Var

var A_arbace_repr_clojure_text_A_const_46 *lang.Var

var A_arbace_repr_clojure_text_A_const_47 any

var A_arbace_repr_clojure_text_A_const_48 *lang.Var

var A_arbace_repr_clojure_text_A_const_49 any

var A_arbace_repr_clojure_text_A_const_50 any

var A_arbace_repr_clojure_text_A_const_51 any

var A_arbace_repr_clojure_text_A_const_52 *lang.Var

var A_arbace_repr_clojure_text_A_const_53 *lang.Var

var A_arbace_repr_clojure_text_A_const_54 *lang.Var

var A_arbace_repr_clojure_text_A_const_55 *lang.Var

var A_arbace_repr_clojure_text_A_const_56 any

var A_arbace_repr_clojure_text_A_const_57 *lang.Var

var A_arbace_repr_clojure_text_A_const_58 *lang.Var

var A_arbace_repr_clojure_text_A_const_59 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_60 *lang.Var

var A_arbace_repr_clojure_text_A_const_61 *lang.Var

var A_arbace_repr_clojure_text_A_const_62 any

var A_arbace_repr_clojure_text_A_const_63 *lang.Var

var A_arbace_repr_clojure_text_A_const_64 *lang.Var

var A_arbace_repr_clojure_text_A_const_65 *lang.Var

var A_arbace_repr_clojure_text_A_const_66 *lang.Var

var A_arbace_repr_clojure_text_A_const_67 *lang.Var

var A_arbace_repr_clojure_text_A_const_68 *lang.Var

var A_arbace_repr_clojure_text_A_const_69 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_70 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_71 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_72 *lang.Var

var A_arbace_repr_clojure_text_A_const_73 any

var A_arbace_repr_clojure_text_A_const_74 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_75 *lang.Var

var A_arbace_repr_clojure_text_A_const_76 *lang.Var

var A_arbace_repr_clojure_text_A_const_77 *lang.Var

var A_arbace_repr_clojure_text_A_const_78 *lang.Var

var A_arbace_repr_clojure_text_A_const_79 *lang.Var

var A_arbace_repr_clojure_text_A_const_80 any

var A_arbace_repr_clojure_text_A_init jrt.ClassInit

func A_arbace_repr_clojure_text_A_Init() { if !A_arbace_repr_clojure_text_A_init.Done() { A_arbace_repr_clojure_text_A_init.Run(A_arbace_repr_clojure_text_A_clinit) } }

func A_arbace_repr_clojure_text_A_clinit() { A_arbace_repr_clojure_text_A_clinit_p0(); A_arbace_repr_clojure_text_A_clinit_p1(); A_arbace_repr_clojure_text_A_clinit_p2(); A_arbace_repr_clojure_text_A_clinit_p3(); A_arbace_repr_clojure_text_A_clinit_p4(); A_arbace_repr_clojure_text_A_clinit_p5(); A_arbace_repr_clojure_text_A_clinit_p6() }

func A_arbace_repr_clojure_text_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_text_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 95); A_arbace_repr_clojure_text_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[14]); A_arbace_repr_clojure_text_A_const_1 = A_arbace_repr_clojure_text_A_const_pool.A[15]; A_arbace_repr_clojure_text_A_const_2 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[16]); A_arbace_repr_clojure_text_A_const_3 = A_arbace_repr_clojure_text_A_const_pool.A[17]; A_arbace_repr_clojure_text_A_const_4 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[18]); A_arbace_repr_clojure_text_A_const_5 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[19]); A_arbace_repr_clojure_text_A_const_6 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[20]); A_arbace_repr_clojure_text_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[21]); A_arbace_repr_clojure_text_A_const_8 = A_arbace_repr_clojure_text_A_const_pool.A[22]; A_arbace_repr_clojure_text_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[23]); A_arbace_repr_clojure_text_A_const_10 = A_arbace_repr_clojure_text_A_const_pool.A[24]; A_arbace_repr_clojure_text_A_const_11 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[25]) }

func A_arbace_repr_clojure_text_A_clinit_p1() { A_arbace_repr_clojure_text_A_const_12 = A_arbace_repr_clojure_text_A_const_pool.A[26]; A_arbace_repr_clojure_text_A_const_13 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[27]); A_arbace_repr_clojure_text_A_const_14 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[28]); A_arbace_repr_clojure_text_A_const_15 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[29]); A_arbace_repr_clojure_text_A_const_16 = A_arbace_repr_clojure_text_A_const_pool.A[30]; A_arbace_repr_clojure_text_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[31]); A_arbace_repr_clojure_text_A_const_18 = A_arbace_repr_clojure_text_A_const_pool.A[32]; A_arbace_repr_clojure_text_A_const_19 = A_arbace_repr_clojure_text_A_const_pool.A[33]; A_arbace_repr_clojure_text_A_const_20 = A_arbace_repr_clojure_text_A_const_pool.A[34]; A_arbace_repr_clojure_text_A_const_21 = A_arbace_repr_clojure_text_A_const_pool.A[35]; A_arbace_repr_clojure_text_A_const_22 = A_arbace_repr_clojure_text_A_const_pool.A[36]; A_arbace_repr_clojure_text_A_const_23 = A_arbace_repr_clojure_text_A_const_pool.A[37]; A_arbace_repr_clojure_text_A_const_24 = A_arbace_repr_clojure_text_A_const_pool.A[38]; A_arbace_repr_clojure_text_A_const_25 = A_arbace_repr_clojure_text_A_const_pool.A[39] }

func A_arbace_repr_clojure_text_A_clinit_p2() { A_arbace_repr_clojure_text_A_const_26 = A_arbace_repr_clojure_text_A_const_pool.A[40]; A_arbace_repr_clojure_text_A_const_27 = A_arbace_repr_clojure_text_A_const_pool.A[41]; A_arbace_repr_clojure_text_A_const_28 = A_arbace_repr_clojure_text_A_const_pool.A[42]; A_arbace_repr_clojure_text_A_const_29 = A_arbace_repr_clojure_text_A_const_pool.A[43]; A_arbace_repr_clojure_text_A_const_30 = A_arbace_repr_clojure_text_A_const_pool.A[44]; A_arbace_repr_clojure_text_A_const_31 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[45]); A_arbace_repr_clojure_text_A_const_32 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[46]); A_arbace_repr_clojure_text_A_const_33 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[47]); A_arbace_repr_clojure_text_A_const_34 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[48]); A_arbace_repr_clojure_text_A_const_35 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[49]); A_arbace_repr_clojure_text_A_const_36 = A_arbace_repr_clojure_text_A_const_pool.A[50]; A_arbace_repr_clojure_text_A_const_37 = A_arbace_repr_clojure_text_A_const_pool.A[51]; A_arbace_repr_clojure_text_A_const_38 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[52]); A_arbace_repr_clojure_text_A_const_39 = A_arbace_repr_clojure_text_A_const_pool.A[53] }

func A_arbace_repr_clojure_text_A_clinit_p3() { A_arbace_repr_clojure_text_A_const_40 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[54]); A_arbace_repr_clojure_text_A_const_41 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[55]); A_arbace_repr_clojure_text_A_const_42 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[56]); A_arbace_repr_clojure_text_A_const_43 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[57]); A_arbace_repr_clojure_text_A_const_44 = A_arbace_repr_clojure_text_A_const_pool.A[58]; A_arbace_repr_clojure_text_A_const_45 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[59]); A_arbace_repr_clojure_text_A_const_46 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[60]); A_arbace_repr_clojure_text_A_const_47 = A_arbace_repr_clojure_text_A_const_pool.A[61]; A_arbace_repr_clojure_text_A_const_48 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[62]); A_arbace_repr_clojure_text_A_const_49 = A_arbace_repr_clojure_text_A_const_pool.A[63]; A_arbace_repr_clojure_text_A_const_50 = A_arbace_repr_clojure_text_A_const_pool.A[64]; A_arbace_repr_clojure_text_A_const_51 = A_arbace_repr_clojure_text_A_const_pool.A[65]; A_arbace_repr_clojure_text_A_const_52 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[66]) }

func A_arbace_repr_clojure_text_A_clinit_p4() { A_arbace_repr_clojure_text_A_const_53 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[67]); A_arbace_repr_clojure_text_A_const_54 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[68]); A_arbace_repr_clojure_text_A_const_55 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[69]); A_arbace_repr_clojure_text_A_const_56 = A_arbace_repr_clojure_text_A_const_pool.A[70]; A_arbace_repr_clojure_text_A_const_57 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[71]); A_arbace_repr_clojure_text_A_const_58 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[72]); A_arbace_repr_clojure_text_A_const_59 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[73]); A_arbace_repr_clojure_text_A_const_60 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[74]); A_arbace_repr_clojure_text_A_const_61 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[75]); A_arbace_repr_clojure_text_A_const_62 = A_arbace_repr_clojure_text_A_const_pool.A[76]; A_arbace_repr_clojure_text_A_const_63 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[77]); A_arbace_repr_clojure_text_A_const_64 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[78]) }

func A_arbace_repr_clojure_text_A_clinit_p5() { A_arbace_repr_clojure_text_A_const_65 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[79]); A_arbace_repr_clojure_text_A_const_66 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[80]); A_arbace_repr_clojure_text_A_const_67 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[81]); A_arbace_repr_clojure_text_A_const_68 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[82]); A_arbace_repr_clojure_text_A_const_69 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[83]); A_arbace_repr_clojure_text_A_const_70 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[84]); A_arbace_repr_clojure_text_A_const_71 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[85]); A_arbace_repr_clojure_text_A_const_72 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[86]); A_arbace_repr_clojure_text_A_const_73 = A_arbace_repr_clojure_text_A_const_pool.A[87]; A_arbace_repr_clojure_text_A_const_74 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[88]); A_arbace_repr_clojure_text_A_const_75 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[89]); A_arbace_repr_clojure_text_A_const_76 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[90]) }

func A_arbace_repr_clojure_text_A_clinit_p6() { A_arbace_repr_clojure_text_A_const_77 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[91]); A_arbace_repr_clojure_text_A_const_78 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[92]); A_arbace_repr_clojure_text_A_const_79 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[93]); A_arbace_repr_clojure_text_A_const_80 = A_arbace_repr_clojure_text_A_const_pool.A[94] }

func A_arbace_repr_clojure_text_A_New() *A_arbace_repr_clojure_text_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_text_A) Ctor() {}

func (t *A_arbace_repr_clojure_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_text_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_text_A_class }

func (t *A_arbace_repr_clojure_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_text_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_text_A); return ok }

func A_arbace_repr_clojure_text_A_Cast(x any) *A_arbace_repr_clojure_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_text_A_class)) }; return v }



type A_arbace_repr_clojure_text_at_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_at_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_branches_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_branches_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_char_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_char_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_code_tokens_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_code_tokens_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_coll_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_coll_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_cond_open_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_cond_open_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_cond_open_fn__670000030_A struct{ j2g_header uint64; F_i, F_s any }

var A_arbace_repr_clojure_text_cond_open_fn__670000030_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_eval670000004_A struct{ jrt.Object }

func A_arbace_repr_clojure_text_eval670000004_A_New() *A_arbace_repr_clojure_text_eval670000004_A { t := &A_arbace_repr_clojure_text_eval670000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_text_eval670000004_A) Ctor() {}

func (t *A_arbace_repr_clojure_text_eval670000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_text_eval670000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_text_eval670000004_A_class }

func (t *A_arbace_repr_clojure_text_eval670000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_text_eval670000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_text_eval670000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_text_eval670000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_text_eval670000004_A); return ok }

func A_arbace_repr_clojure_text_eval670000004_A_Cast(x any) *A_arbace_repr_clojure_text_eval670000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_text_eval670000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_text_eval670000004_A_class)) }; return v }



type A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_eval670000008_A struct{ jrt.Object }

func A_arbace_repr_clojure_text_eval670000008_A_New() *A_arbace_repr_clojure_text_eval670000008_A { t := &A_arbace_repr_clojure_text_eval670000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_text_eval670000008_A) Ctor() {}

func (t *A_arbace_repr_clojure_text_eval670000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_text_eval670000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_text_eval670000008_A_class }

func (t *A_arbace_repr_clojure_text_eval670000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_text_eval670000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_text_eval670000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_text_eval670000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_text_eval670000008_A); return ok }

func A_arbace_repr_clojure_text_eval670000008_A_Cast(x any) *A_arbace_repr_clojure_text_eval670000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_text_eval670000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_text_eval670000008_A_class)) }; return v }



type A_arbace_repr_clojure_text_eval670000008_fn__670000009_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_eval670000008_fn__670000009_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_fail_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_fail_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_fail_fn__670000013_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_fail_fn__670000013_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_form_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_form_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_line_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_line_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_list_spans_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_list_spans_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_next_form_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_next_form_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_record_conditionals_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_record_conditionals_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_resolve_STAR__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_resolve_STAR__A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A struct{ j2g_header uint64; F_i, F_sb, F_s any }

var A_arbace_repr_clojure_text_resolve_STAR__copy__670000048_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_resolve_conditionals_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_restore_conditionals_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_restore_conditionals_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A struct{ j2g_header uint64; F_sb, F_t, F_features any }

var A_arbace_repr_clojure_text_restore_conditionals_fn__670000059_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_selected_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_selected_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_selected_fn__670000038_A struct{ j2g_header uint64; F_features any }

var A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_skip_ws_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_skip_ws_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_string_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_string_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_terminating_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_token_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_token_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_ws_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_ws_QMARK__A_fn_class *jrt.Class
