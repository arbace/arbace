//line aot_arbace_repr_clojure_text.ae:1
package aot_arbace_repr_clojure_text

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A_New() *A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_text_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_text_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_clojure_text_eval670000008_fn__670000009_A_New() *A_arbace_repr_clojure_text_eval670000008_fn__670000009_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_eval670000008_fn__670000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000008_fn__670000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_text_eval670000008_fn__670000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_text_A_const_8), A_arbace_repr_clojure_text_A_const_6.GetRawRoot__O(), A_arbace_repr_clojure_text_A_const_7) }
















func A_arbace_repr_clojure_text_fail_A_New() *A_arbace_repr_clojure_text_fail_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_fail_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_repr_clojure_text_fail_A) Ctor() {}
//line :18:1
func (t *A_arbace_repr_clojure_text_fail_A) Invoke_O_O_O_O__O(self, s__0, i__1, msg__2 any) any { var line__4 int64; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_9.GetRawRoot__O()); var tmp2 any = A_arbace_repr_clojure_text_fail_fn__670000013_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_clojure_text_fail_fn__670000013_A_fn_class; if
												fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_repr_clojure_text_fail_fn__670000013_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_12.GetRawRoot__O()); var tmp5 any = A_arbace_repr_clojure_text_A_const_13; line__4 = lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), tmp4.Invoke_O_O_O__O(s__0, tmp5, lang.Numbers_Min_O_J__O_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(s__0)))))))); var tmp6 any = A_arbace_repr_clojure_text_A_const_14; var tmp7 any = A_arbace_repr_clojure_text_A_const_15; /*line :18:1*/panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_10.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, msg__2, nil, jrt.Long_ValueOf_J__Long_NoInit(line__4).Ref(), nil)).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, i__1, tmp7, jrt.Long_ValueOf_J__Long_NoInit(line__4).Ref())))))) }
func A_arbace_repr_clojure_text_fail_fn__670000013_A_New() *A_arbace_repr_clojure_text_fail_fn__670000013_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_fail_fn__670000013_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_repr_clojure_text_fail_fn__670000013_A) Ctor() {}
//line :19:1
func (t *A_arbace_repr_clojure_text_fail_fn__670000013_A) Invoke_O_O__O(self, p1__670000012_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_clojure_text_A_const_11, p1__670000012_SHARP___1)).Ref() }


func A_arbace_repr_clojure_text_ws_QMARK__A_New() *A_arbace_repr_clojure_text_ws_QMARK__A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_ws_QMARK__A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_repr_clojure_text_ws_QMARK__A) Ctor() {}
//line :22:1
func (t *A_arbace_repr_clojure_text_ws_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 bool = jrt.Character_IsWhitespace_C__Z_NoInit(lang.RT_CharCast_O__C_NoInit(c__0)); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(c__0, A_arbace_repr_clojure_text_A_const_16)).Ref() } }

func A_arbace_repr_clojure_text_terminating_QMARK__A_New() *A_arbace_repr_clojure_text_terminating_QMARK__A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_terminating_QMARK__A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_repr_clojure_text_terminating_QMARK__A) Ctor() {}
//line :24:1
func (t *A_arbace_repr_clojure_text_terminating_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_17.GetRawRoot__O()).Invoke_O__O(c__0); if



	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var G__670000017__3_ any = c__0; switch lang.Util_Hash_O__I_NoInit(G__670000017__3_) { case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_18) { return jrt.Boolean_TRUE.Ref() }; case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_19) { return jrt.Boolean_TRUE.Ref() }; case 41: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_20) { return jrt.Boolean_TRUE.Ref() }; case 59: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_21) { return jrt.Boolean_TRUE.Ref() }; case 64: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_22) { return jrt.Boolean_TRUE.Ref() }; case 91: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_23) { return jrt.Boolean_TRUE.Ref() }; case 92: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_24) { return jrt.Boolean_TRUE.Ref() }; case 93: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_25) { return jrt.Boolean_TRUE.Ref() }; case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_26) { return jrt.Boolean_TRUE.Ref() }; case 96: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_27) { return jrt.Boolean_TRUE.Ref() }; case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_28) { return jrt.Boolean_TRUE.Ref() }; case 125: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_29) { return jrt.Boolean_TRUE.Ref() }; case 126: if lang.Util_Equiv_O_O__Z_NoInit(G__670000017__3_, A_arbace_repr_clojure_text_A_const_30) { return jrt.Boolean_TRUE.Ref() }; default:}; return jrt.Boolean_FALSE.Ref() } }

func A_arbace_repr_clojure_text_at_A_New() *A_arbace_repr_clojure_text_at_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_at_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_repr_clojure_text_at_A) Ctor() {}
//line :30:1
func (t *A_arbace_repr_clojure_text_at_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var tmp1 bool; var na_3 any = i__1; var na_4 int64 = int64(lang.RT_Count_O__I_NoInit(s__0)); if jrt.Long_InstanceOf(na_3) { var n0_5 int64 = jrt.NN(jrt.Long_Cast(na_3)).LongValue__J(); var n1_6 int64 = na_4; tmp1 = n0_5 < n1_6 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_3, na_4) }; if tmp1 { return jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__1))).Ref() } else { return nil } }

func A_arbace_repr_clojure_text_line_end_A_New() *A_arbace_repr_clojure_text_line_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_line_end_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_repr_clojure_text_line_end_A) Ctor() {}
//line :32:1
func (t *A_arbace_repr_clojure_text_line_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 int32 = jrt.NN(jrt.String_Cast(s__0)).IndexOf_String_I__I(Lit_15, lang.RT_IntCast_O__I_NoInit(i__1)); if
												lang.Numbers_IsNeg_J__Z_NoInit(int64(j__3)) { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(s__0)).Ref() } else { return jrt.Integer_ValueOf_I__Integer_NoInit(j__3).Ref() } }

func A_arbace_repr_clojure_text_token_end_A_New() *A_arbace_repr_clojure_text_token_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_token_end_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_repr_clojure_text_token_end_A) Ctor() {}
//line :35:1
func (t *A_arbace_repr_clojure_text_token_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var j__4 any = i__1; L1: for {



	var tmp1 any; var and__1927000168__auto____5 bool; var na_8 any = j__4; var na_9 int64 = int64(n__3); if jrt.Long_InstanceOf(na_8) { var n0_10 int64 = jrt.NN(jrt.Long_Cast(na_8)).LongValue__J(); var n1_11 int64 = na_9; and__1927000168__auto____5 = n0_10 < n1_11 } else { and__1927000168__auto____5 = lang.Numbers_Lt_O_J__Z_NoInit(na_8, na_9) }; if and__1927000168__auto____5 { tmp1 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))).Ref())) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp1) { var tmp2 jrt.Number_I; var na_13 any = j__4; if jrt.Long_InstanceOf(na_13) { var n0_14 int64 = jrt.NN(jrt.Long_Cast(na_13)).LongValue__J(); if n0_14 == 9223372036854775807 { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_13) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_14 + 1)) } } else { if jrt.Double_InstanceOf(na_13) { var n0_14_2 float64 = jrt.NN(jrt.Double_Cast(na_13)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_14_2 + 1.0)) } else { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_13) } }; j__4 = tmp2; continue L1 } else { return j__4 } } }; /*line :35:1*/panic("j2g: unreachable") }





func A_arbace_repr_clojure_text_string_end_A_New() *A_arbace_repr_clojure_text_string_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_string_end_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_repr_clojure_text_string_end_A) Ctor() {}
//line :41:1
func (t *A_arbace_repr_clojure_text_string_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var j__4 any
												var na_15 any = i__1


	if jrt.Long_InstanceOf(na_15) { var n0_16 int64 = jrt.NN(jrt.Long_Cast(na_15)).LongValue__J(); if n0_16 == 9223372036854775807 { j__4 = lang.Numbers_Inc_O__Number_NoInit(na_15) } else { j__4 = jrt.Long_ValueOf_J__Long_NoInit(n0_16 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_15) { var n0_16_2 float64 = jrt.NN(jrt.Double_Cast(na_15)).DoubleValue__D(); j__4 = jrt.Double_ValueOf_D__Double_NoInit(n0_16_2 + 1.0).Ref() } else { j__4 = lang.Numbers_Inc_O__Number_NoInit(na_15) } }
//line :41:1
L1: for {




	var tmp1 bool; var na_17 any = j__4; var na_18 int64 = int64(n__3); if jrt.Long_InstanceOf(na_17) { var n0_19 int64 = jrt.NN(jrt.Long_Cast(na_17)).LongValue__J(); var n1_20 int64 = na_18; tmp1 = n0_19 >= n1_20 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_17, na_18) }; if tmp1 { return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_22) } else { if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_24)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))) {
		var tmp2 jrt.Number_I; var na_24 any = j__4; var na_25 int64 = 2; if jrt.Long_InstanceOf(na_24) { var n0_26 int64 = jrt.NN(jrt.Long_Cast(na_24)).LongValue__J(); var n1_27 int64 = na_25; var nr_28 int64 = n0_26 + n1_27; if (n0_26^nr_28)&(n1_27^nr_28) >= 0 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_28)) } else { tmp2 = lang.Numbers_Add_O_J__Number_NoInit(na_24, na_25) } } else { tmp2 = lang.Numbers_Add_O_J__Number_NoInit(na_24, na_25) }; j__4 = tmp2; continue L1 } else {
//line :46:1
			if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_18)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__4))) {

				var na_22 any = j__4; if jrt.Long_InstanceOf(na_22) { var n0_23 int64 = jrt.NN(jrt.Long_Cast(na_22)).LongValue__J(); if n0_23 == 9223372036854775807 { return lang.Numbers_Inc_O__Number_NoInit(na_22) } else { return jrt.Long_ValueOf_J__Long_NoInit(n0_23 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_22) { var n0_23_2 float64 = jrt.NN(jrt.Double_Cast(na_22)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_23_2 + 1.0).Ref() } else { return lang.Numbers_Inc_O__Number_NoInit(na_22) } } } else {
//line :46:1
					if A_arbace_repr_clojure_text_A_const_34 != nil {


						var tmp3 jrt.Number_I; var na_29 any = j__4; if jrt.Long_InstanceOf(na_29) { var n0_30 int64 = jrt.NN(jrt.Long_Cast(na_29)).LongValue__J(); if n0_30 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_29) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_30 + 1)) } } else { if jrt.Double_InstanceOf(na_29) { var n0_30_2 float64 = jrt.NN(jrt.Double_Cast(na_29)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_30_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_29) } }; j__4 = tmp3; continue L1 } else {
//line :46:1
							return nil } } } } } }; /*line :41:1*/panic("j2g: unreachable") }









func A_arbace_repr_clojure_text_char_end_A_New() *A_arbace_repr_clojure_text_char_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_char_end_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_repr_clojure_text_char_end_A) Ctor() {}
//line :51:1
func (t *A_arbace_repr_clojure_text_char_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any {



	var tmp1 bool; var na_31 any; var na_33 any = i__1; if jrt.Long_InstanceOf(na_33) { var n0_34 int64 = jrt.NN(jrt.Long_Cast(na_33)).LongValue__J(); if n0_34 == 9223372036854775807 { na_31 = lang.Numbers_Inc_O__Number_NoInit(na_33) } else { na_31 = jrt.Long_ValueOf_J__Long_NoInit(n0_34 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_33) { var n0_34_2 float64 = jrt.NN(jrt.Double_Cast(na_33)).DoubleValue__D(); na_31 = jrt.Double_ValueOf_D__Double_NoInit(n0_34_2 + 1.0).Ref() } else { na_31 = lang.Numbers_Inc_O__Number_NoInit(na_33) } }; var na_32 int64 = int64(lang.RT_Count_O__I_NoInit(s__0)); if jrt.Long_InstanceOf(na_31) { var n0_35 int64 = jrt.NN(jrt.Long_Cast(na_31)).LongValue__J(); var n1_36 int64 = na_32; tmp1 = n0_35 >= n1_36 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_31, na_32) }; if tmp1 { lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_4) }
	var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O()); var tmp3 jrt.Number_I; var na_38 any = i__1; var na_39 int64 = 2; if jrt.Long_InstanceOf(na_38) { var n0_40 int64 = jrt.NN(jrt.Long_Cast(na_38)).LongValue__J(); var n1_41 int64 = na_39; var nr_42 int64 = n0_40 + n1_41; if (n0_40^nr_42)&(n1_41^nr_42) >= 0 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_42)) } else { tmp3 = lang.Numbers_Add_O_J__Number_NoInit(na_38, na_39) } } else { tmp3 = lang.Numbers_Add_O_J__Number_NoInit(na_38, na_39) }; return tmp2.Invoke_O_O__O(s__0, tmp3)
}


func A_arbace_repr_clojure_text_skip_ws_A_New() *A_arbace_repr_clojure_text_skip_ws_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_skip_ws_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_repr_clojure_text_skip_ws_A) Ctor() {}
//line :60:1
func (t *A_arbace_repr_clojure_text_skip_ws_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var i__4 any = i__1; L1: for {





	var tmp1 bool; var na_43 any = i__4; var na_44 int64 = int64(n__3); if jrt.Long_InstanceOf(na_43) { var n0_45 int64 = jrt.NN(jrt.Long_Cast(na_43)).LongValue__J(); var n1_46 int64 = na_44; tmp1 = n0_45 >= n1_46 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_43, na_44) }; if tmp1 { return i__4 } else { var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__4))


		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_17.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(c__5).Ref())) { var tmp2 jrt.Number_I; var na_48 any = i__4; if jrt.Long_InstanceOf(na_48) { var n0_49 int64 = jrt.NN(jrt.Long_Cast(na_48)).LongValue__J(); if n0_49 == 9223372036854775807 { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_48) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_49 + 1)) } } else { if jrt.Double_InstanceOf(na_48) { var n0_49_2 float64 = jrt.NN(jrt.Double_Cast(na_48)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_49_2 + 1.0)) } else { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_48) } }; i__4 = tmp2; continue L1 } else { if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_21)).CharValue__C()) {
			i__4 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__4); continue L1 } else {
//line :69:1
				var tmp3 bool; var and__1927000168__auto____6 bool = lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())

				if and__1927000168__auto____6 { var tmp4 any = A_arbace_repr_clojure_text_A_const_37; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()); var tmp6 jrt.Number_I; var na_50 any = i__4; if jrt.Long_InstanceOf(na_50) { var n0_51 int64 = jrt.NN(jrt.Long_Cast(na_50)).LongValue__J(); if n0_51 == 9223372036854775807 { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_50) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_51 + 1)) } } else { if jrt.Double_InstanceOf(na_50) { var n0_51_2 float64 = jrt.NN(jrt.Double_Cast(na_50)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_51_2 + 1.0)) } else { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_50) } }; tmp3 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5.Invoke_O_O__O(s__0, tmp6)) } else { tmp3 = and__1927000168__auto____6 }
//line :69:1
				if tmp3 {

					i__4 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__4); continue L1 } else {
//line :69:1
						var tmp7 bool; var and__1927000168__auto____6_2 bool = lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())


						if and__1927000168__auto____6_2 { var tmp8 any = A_arbace_repr_clojure_text_A_const_39; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()); var tmp10 jrt.Number_I; var na_52 any = i__4; if jrt.Long_InstanceOf(na_52) { var n0_53 int64 = jrt.NN(jrt.Long_Cast(na_52)).LongValue__J(); if n0_53 == 9223372036854775807 { tmp10 = lang.Numbers_Inc_O__Number_NoInit(na_52) } else { tmp10 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_53 + 1)) } } else { if jrt.Double_InstanceOf(na_52) { var n0_53_2 float64 = jrt.NN(jrt.Double_Cast(na_52)).DoubleValue__D(); tmp10 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_53_2 + 1.0)) } else { tmp10 = lang.Numbers_Inc_O__Number_NoInit(na_52) } }; tmp7 = lang.Util_Equiv_O_O__Z_NoInit(tmp8, tmp9.Invoke_O_O__O(s__0, tmp10)) } else { tmp7 = and__1927000168__auto____6_2 }
//line :69:1
						if tmp7 {


							var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O()); var tmp13 jrt.Number_I; var na_54 any = i__4; var na_55 int64 = 2; if jrt.Long_InstanceOf(na_54) { var n0_56 int64 = jrt.NN(jrt.Long_Cast(na_54)).LongValue__J(); var n1_57 int64 = na_55; var nr_58 int64 = n0_56 + n1_57; if (n0_56^nr_58)&(n1_57^nr_58) >= 0 { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_58)) } else { tmp13 = lang.Numbers_Add_O_J__Number_NoInit(na_54, na_55) } } else { tmp13 = lang.Numbers_Add_O_J__Number_NoInit(na_54, na_55) }; i__4 = tmp11.Invoke_O_O__O(s__0, tmp12.Invoke_O_O__O(s__0, tmp13)); continue L1 } else {
//line :69:1
								if A_arbace_repr_clojure_text_A_const_34 != nil { return i__4 } else { return nil } } } } } } } }; /*line :60:1*/panic("j2g: unreachable") }
















func A_arbace_repr_clojure_text_coll_end_A_New() *A_arbace_repr_clojure_text_coll_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_coll_end_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_repr_clojure_text_coll_end_A) Ctor() {}
//line :77:1
func (t *A_arbace_repr_clojure_text_coll_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var close__3 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_43.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__1))).Ref()); var j__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O()); var tmp2 jrt.Number_I
												var na_61 any = i__1


	if jrt.Long_InstanceOf(na_61) { var n0_62 int64 = jrt.NN(jrt.Long_Cast(na_61)).LongValue__J(); if n0_62 == 9223372036854775807 { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_61) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_62 + 1)) } } else { if jrt.Double_InstanceOf(na_61) { var n0_62_2 float64 = jrt.NN(jrt.Double_Cast(na_61)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_62_2 + 1.0)) } else { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_61) } }; j__4 = tmp1.Invoke_O_O__O(s__0, tmp2)
//line :77:1
L1: for { var c__5 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, j__4)





	if lang.Util_Identical_O_O__Z_NoInit(c__5, nil) { return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, close__3)).Ref()) } else { if lang.Util_Equiv_O_O__Z_NoInit(c__5, close__3) {
		var na_59 any = j__4; if jrt.Long_InstanceOf(na_59) { var n0_60 int64 = jrt.NN(jrt.Long_Cast(na_59)).LongValue__J(); if n0_60 == 9223372036854775807 { return lang.Numbers_Inc_O__Number_NoInit(na_59) } else { return jrt.Long_ValueOf_J__Long_NoInit(n0_60 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_59) { var n0_60_2 float64 = jrt.NN(jrt.Double_Cast(na_59)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_60_2 + 1.0).Ref() } else { return lang.Numbers_Inc_O__Number_NoInit(na_59) } } } else {
//line :83:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_44).Invoke_O__O(c__5)) {

				return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, j__4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__5)).Ref()) } else {
//line :83:1
					if A_arbace_repr_clojure_text_A_const_34 != nil {


						j__4 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O()).Invoke_O_O__O(s__0, j__4)); continue L1 } else {
//line :83:1
							return nil } } } } } }; /*line :77:1*/panic("j2g: unreachable") }










func A_arbace_repr_clojure_text_next_form_end_A_New() *A_arbace_repr_clojure_text_next_form_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_next_form_end_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_repr_clojure_text_next_form_end_A) Ctor() {}
//line :88:1
func (t *A_arbace_repr_clojure_text_next_form_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1); var tmp1 bool; var na_63 any = j__3; var na_64 int64 = int64(lang.RT_Count_O__I_NoInit(s__0)); if

	jrt.Long_InstanceOf(na_63) { var n0_65 int64 = jrt.NN(jrt.Long_Cast(na_63)).LongValue__J(); var n1_66 int64 = na_64; tmp1 = n0_65 >= n1_66 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_63, na_64) }; if tmp1 { lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_12) }; return /*line :91:1*/ lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O()).Invoke_O_O__O(s__0, j__3) }

func A_arbace_repr_clojure_text_form_end_A_New() *A_arbace_repr_clojure_text_form_end_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_form_end_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_repr_clojure_text_form_end_A) Ctor() {}
//line :93:1
func (t *A_arbace_repr_clojure_text_form_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var c__3 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1); var G__670000027__4_ any = c__3; switch



	lang.Util_Hash_O__I_NoInit(G__670000027__4_) { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, nil) {
		return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_12) }
//line :97:1
	case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_18) {


		return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }
//line :97:1
	case 35: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_36) { var d__5 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()); var tmp2 jrt.Number_I
		var na_70 any = i__1







		if jrt.Long_InstanceOf(na_70) { var n0_71 int64 = jrt.NN(jrt.Long_Cast(na_70)).LongValue__J(); if n0_71 == 9223372036854775807 { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_70) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_71 + 1)) } } else { if jrt.Double_InstanceOf(na_70) { var n0_71_2 float64 = jrt.NN(jrt.Double_Cast(na_70)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_71_2 + 1.0)) } else { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_70) } }; d__5 = tmp1.Invoke_O_O__O(s__0, tmp2)
//line :97:1
		var G__670000028__6_ any = d__5









		switch lang.Util_Hash_O__I_NoInit(G__670000028__6_) { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, nil) {
			return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_13) }
//line :107:1
		case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_37) {






			return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1)) }
//line :107:1
		case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_18) {


			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O()); var tmp4 jrt.Number_I; var na_72 any = i__1; if jrt.Long_InstanceOf(na_72) { var n0_73 int64 = jrt.NN(jrt.Long_Cast(na_72)).LongValue__J(); if n0_73 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_72) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_73 + 1)) } } else { if jrt.Double_InstanceOf(na_72) { var n0_73_2 float64 = jrt.NN(jrt.Double_Cast(na_72)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_73_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_72) } }; return tmp3.Invoke_O_O__O(s__0, tmp4) }
//line :107:1
		case 35: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_36) {








			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O()); var tmp6 jrt.Number_I; var na_74 any = i__1; var na_75 int64 = 2; if jrt.Long_InstanceOf(na_74) { var n0_76 int64 = jrt.NN(jrt.Long_Cast(na_74)).LongValue__J(); var n1_77 int64 = na_75; var nr_78 int64 = n0_76 + n1_77; if (n0_76^nr_78)&(n1_77^nr_78) >= 0 { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_78)) } else { tmp6 = lang.Numbers_Add_O_J__Number_NoInit(na_74, na_75) } } else { tmp6 = lang.Numbers_Add_O_J__Number_NoInit(na_74, na_75) }; return tmp5.Invoke_O_O__O(s__0, tmp6) }
//line :107:1
		case 39: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_47) {



			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O()); var tmp8 jrt.Number_I; var na_79 any = i__1; var na_80 int64 = 2; if jrt.Long_InstanceOf(na_79) { var n0_81 int64 = jrt.NN(jrt.Long_Cast(na_79)).LongValue__J(); var n1_82 int64 = na_80; var nr_83 int64 = n0_81 + n1_82; if (n0_81^nr_83)&(n1_82^nr_83) >= 0 { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_83)) } else { tmp8 = lang.Numbers_Add_O_J__Number_NoInit(na_79, na_80) } } else { tmp8 = lang.Numbers_Add_O_J__Number_NoInit(na_79, na_80) }; return tmp7.Invoke_O_O__O(s__0, tmp8) }
//line :107:1
		case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_19) {

			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O()); var tmp10 jrt.Number_I; var na_84 any = i__1; if jrt.Long_InstanceOf(na_84) { var n0_85 int64 = jrt.NN(jrt.Long_Cast(na_84)).LongValue__J(); if n0_85 == 9223372036854775807 { tmp10 = lang.Numbers_Inc_O__Number_NoInit(na_84) } else { tmp10 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_85 + 1)) } } else { if jrt.Double_InstanceOf(na_84) { var n0_85_2 float64 = jrt.NN(jrt.Double_Cast(na_84)).DoubleValue__D(); tmp10 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_85_2 + 1.0)) } else { tmp10 = lang.Numbers_Inc_O__Number_NoInit(na_84) } }; return tmp9.Invoke_O_O__O(s__0, tmp10) }
//line :107:1
		case 58: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_49) { var j__7 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O()); var tmp13 jrt.Number_I
			var na_86 any = i__1








			if jrt.Long_InstanceOf(na_86) { var n0_87 int64 = jrt.NN(jrt.Long_Cast(na_86)).LongValue__J(); if n0_87 == 9223372036854775807 { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_86) } else { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_87 + 1)) } } else { if jrt.Double_InstanceOf(na_86) { var n0_87_2 float64 = jrt.NN(jrt.Double_Cast(na_86)).DoubleValue__D(); tmp13 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_87_2 + 1.0)) } else { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_86) } }; j__7 = tmp11.Invoke_O_O__O(s__0, tmp12.Invoke_O_O__O(s__0, tmp13))
			var tmp14 any = A_arbace_repr_clojure_text_A_const_28; if lang.Util_Equiv_O_O__Z_NoInit(tmp14, lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, j__7)) { } else { lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_14) }
			return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O()).Invoke_O_O__O(s__0, j__7) }
//line :107:1
		case 61: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_50) {



			var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O()); var tmp16 jrt.Number_I; var na_88 any = i__1; var na_89 int64 = 2; if jrt.Long_InstanceOf(na_88) { var n0_90 int64 = jrt.NN(jrt.Long_Cast(na_88)).LongValue__J(); var n1_91 int64 = na_89; var nr_92 int64 = n0_90 + n1_91; if (n0_90^nr_92)&(n1_91^nr_92) >= 0 { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_92)) } else { tmp16 = lang.Numbers_Add_O_J__Number_NoInit(na_88, na_89) } } else { tmp16 = lang.Numbers_Add_O_J__Number_NoInit(na_88, na_89) }; return tmp15.Invoke_O_O__O(s__0, tmp16) }
//line :107:1
		case 63: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_51) {







			return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_52.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1)) }
//line :107:1
		case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_26) {




			var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O()); var tmp19 jrt.Number_I; var na_93 any = i__1; var na_94 int64 = 2; if jrt.Long_InstanceOf(na_93) { var n0_95 int64 = jrt.NN(jrt.Long_Cast(na_93)).LongValue__J(); var n1_96 int64 = na_94; var nr_97 int64 = n0_95 + n1_96; if (n0_95^nr_97)&(n1_96^nr_97) >= 0 { tmp19 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_97)) } else { tmp19 = lang.Numbers_Add_O_J__Number_NoInit(na_93, na_94) } } else { tmp19 = lang.Numbers_Add_O_J__Number_NoInit(na_93, na_94) }; return tmp17.Invoke_O_O__O(s__0, tmp18.Invoke_O_O__O(s__0, tmp19)) }
//line :107:1
		case 95: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_39) {





			var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O()); var tmp22 jrt.Number_I; var na_98 any = i__1; var na_99 int64 = 2; if jrt.Long_InstanceOf(na_98) { var n0_100 int64 = jrt.NN(jrt.Long_Cast(na_98)).LongValue__J(); var n1_101 int64 = na_99; var nr_102 int64 = n0_100 + n1_101; if (n0_100^nr_102)&(n1_101^nr_102) >= 0 { tmp22 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_102)) } else { tmp22 = lang.Numbers_Add_O_J__Number_NoInit(na_98, na_99) } } else { tmp22 = lang.Numbers_Add_O_J__Number_NoInit(na_98, na_99) }; return tmp20.Invoke_O_O__O(s__0, tmp21.Invoke_O_O__O(s__0, tmp22)) }
//line :107:1
		case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000028__6_, A_arbace_repr_clojure_text_A_const_28) {

			var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O()); var tmp24 jrt.Number_I; var na_103 any = i__1; if jrt.Long_InstanceOf(na_103) { var n0_104 int64 = jrt.NN(jrt.Long_Cast(na_103)).LongValue__J(); if n0_104 == 9223372036854775807 { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_103) } else { tmp24 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_104 + 1)) } } else { if jrt.Double_InstanceOf(na_103) { var n0_104_2 float64 = jrt.NN(jrt.Double_Cast(na_103)).DoubleValue__D(); tmp24 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_104_2 + 1.0)) } else { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_103) } }; return tmp23.Invoke_O_O__O(s__0, tmp24) }
//line :107:1
		default:
		}












		var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O()); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O()); var tmp27 jrt.Number_I; var na_105 any = i__1; if jrt.Long_InstanceOf(na_105) { var n0_106 int64 = jrt.NN(jrt.Long_Cast(na_105)).LongValue__J(); if n0_106 == 9223372036854775807 { tmp27 = lang.Numbers_Inc_O__Number_NoInit(na_105) } else { tmp27 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_106 + 1)) } } else { if jrt.Double_InstanceOf(na_105) { var n0_106_2 float64 = jrt.NN(jrt.Double_Cast(na_105)).DoubleValue__D(); tmp27 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_106_2 + 1.0)) } else { tmp27 = lang.Numbers_Inc_O__Number_NoInit(na_105) } }; return tmp25.Invoke_O_O__O(s__0, tmp26.Invoke_O_O__O(s__0, tmp27)) }
//line :97:1
	case 39: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_47) {




		var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O()); var tmp29 jrt.Number_I; var na_107 any = i__1; if jrt.Long_InstanceOf(na_107) { var n0_108 int64 = jrt.NN(jrt.Long_Cast(na_107)).LongValue__J(); if n0_108 == 9223372036854775807 { tmp29 = lang.Numbers_Inc_O__Number_NoInit(na_107) } else { tmp29 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_108 + 1)) } } else { if jrt.Double_InstanceOf(na_107) { var n0_108_2 float64 = jrt.NN(jrt.Double_Cast(na_107)).DoubleValue__D(); tmp29 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_108_2 + 1.0)) } else { tmp29 = lang.Numbers_Inc_O__Number_NoInit(na_107) } }; return tmp28.Invoke_O_O__O(s__0, tmp29) }
//line :97:1
	case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_19) {

		return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }
//line :97:1
	case 41: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_20) {







		return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref()) }
//line :97:1
	case 64: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_22) {




		var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O()); var tmp31 jrt.Number_I; var na_109 any = i__1; if jrt.Long_InstanceOf(na_109) { var n0_110 int64 = jrt.NN(jrt.Long_Cast(na_109)).LongValue__J(); if n0_110 == 9223372036854775807 { tmp31 = lang.Numbers_Inc_O__Number_NoInit(na_109) } else { tmp31 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_110 + 1)) } } else { if jrt.Double_InstanceOf(na_109) { var n0_110_2 float64 = jrt.NN(jrt.Double_Cast(na_109)).DoubleValue__D(); tmp31 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_110_2 + 1.0)) } else { tmp31 = lang.Numbers_Inc_O__Number_NoInit(na_109) } }; return tmp30.Invoke_O_O__O(s__0, tmp31) }
//line :97:1
	case 91: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_23) {

		return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }
//line :97:1
	case 92: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_24) {



		return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }
//line :97:1
	case 93: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_25) {







		return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref()) }
//line :97:1
	case 94: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_26) {






		var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O()); var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O()); var tmp34 jrt.Number_I; var na_111 any = i__1; if jrt.Long_InstanceOf(na_111) { var n0_112 int64 = jrt.NN(jrt.Long_Cast(na_111)).LongValue__J(); if n0_112 == 9223372036854775807 { tmp34 = lang.Numbers_Inc_O__Number_NoInit(na_111) } else { tmp34 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_112 + 1)) } } else { if jrt.Double_InstanceOf(na_111) { var n0_112_2 float64 = jrt.NN(jrt.Double_Cast(na_111)).DoubleValue__D(); tmp34 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_112_2 + 1.0)) } else { tmp34 = lang.Numbers_Inc_O__Number_NoInit(na_111) } }; return tmp32.Invoke_O_O__O(s__0, tmp33.Invoke_O_O__O(s__0, tmp34)) }
//line :97:1
	case 96: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_27) {




		var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O()); var tmp36 jrt.Number_I; var na_113 any = i__1; if jrt.Long_InstanceOf(na_113) { var n0_114 int64 = jrt.NN(jrt.Long_Cast(na_113)).LongValue__J(); if n0_114 == 9223372036854775807 { tmp36 = lang.Numbers_Inc_O__Number_NoInit(na_113) } else { tmp36 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_114 + 1)) } } else { if jrt.Double_InstanceOf(na_113) { var n0_114_2 float64 = jrt.NN(jrt.Double_Cast(na_113)).DoubleValue__D(); tmp36 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_114_2 + 1.0)) } else { tmp36 = lang.Numbers_Inc_O__Number_NoInit(na_113) } }; return tmp35.Invoke_O_O__O(s__0, tmp36) }
//line :97:1
	case 123: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_28) {

		return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_48.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }
//line :97:1
	case 125: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_29) {







		return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref()) }
//line :97:1
	case 126: if lang.Util_Equiv_O_O__Z_NoInit(G__670000027__4_, A_arbace_repr_clojure_text_A_const_30) {





		var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_46.GetRawRoot__O()); var tmp38 jrt.Number_I; var tmp39 any = A_arbace_repr_clojure_text_A_const_22; var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()); var tmp41 jrt.Number_I; var na_122 any = i__1; if jrt.Long_InstanceOf(na_122) { var n0_123 int64 = jrt.NN(jrt.Long_Cast(na_122)).LongValue__J(); if n0_123 == 9223372036854775807 { tmp41 = lang.Numbers_Inc_O__Number_NoInit(na_122) } else { tmp41 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_123 + 1)) } } else { if jrt.Double_InstanceOf(na_122) { var n0_123_2 float64 = jrt.NN(jrt.Double_Cast(na_122)).DoubleValue__D(); tmp41 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_123_2 + 1.0)) } else { tmp41 = lang.Numbers_Inc_O__Number_NoInit(na_122) } }; if lang.Util_Equiv_O_O__Z_NoInit(tmp39, tmp40.Invoke_O_O__O(s__0, tmp41)) { var na_115 any = i__1; var na_116 int64 = 2; if jrt.Long_InstanceOf(na_115) { var n0_117 int64 = jrt.NN(jrt.Long_Cast(na_115)).LongValue__J(); var n1_118 int64 = na_116; var nr_119 int64 = n0_117 + n1_118; if (n0_117^nr_119)&(n1_118^nr_119) >= 0 { tmp38 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_119)) } else { tmp38 = lang.Numbers_Add_O_J__Number_NoInit(na_115, na_116) } } else { tmp38 = lang.Numbers_Add_O_J__Number_NoInit(na_115, na_116) } } else { var na_120 any = i__1; if jrt.Long_InstanceOf(na_120) { var n0_121 int64 = jrt.NN(jrt.Long_Cast(na_120)).LongValue__J(); if n0_121 == 9223372036854775807 { tmp38 = lang.Numbers_Inc_O__Number_NoInit(na_120) } else { tmp38 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_121 + 1)) } } else { if jrt.Double_InstanceOf(na_120) { var n0_121_2 float64 = jrt.NN(jrt.Double_Cast(na_120)).DoubleValue__D(); tmp38 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_121_2 + 1.0)) } else { tmp38 = lang.Numbers_Inc_O__Number_NoInit(na_120) } } }; return tmp37.Invoke_O_O__O(s__0, tmp38) }
//line :97:1
	default:}; return /*line :122:1*/ lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }



func A_arbace_repr_clojure_text_cond_open_A_New() *A_arbace_repr_clojure_text_cond_open_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_cond_open_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_repr_clojure_text_cond_open_A) Ctor() {}
//line :126:1
func (t *A_arbace_repr_clojure_text_cond_open_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 any; var tmp1 any = A_arbace_repr_clojure_text_cond_open_fn__670000030_A_New_O_O(i__1, s__0); var tmp2 *jrt.Class; var fncls__146 *jrt.Class = A_arbace_repr_clojure_text_cond_open_fn__670000030_A_fn_class; if



	fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_repr_clojure_text_cond_open_fn__670000030_A_fn_class = fncls__146d; tmp2 = fncls__146d } else { tmp2 = fncls__146 }; j__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var tmp3 any = A_arbace_repr_clojure_text_A_const_19; if

	lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, j__3)) { } else { lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_8) }; return j__3 }
//line :130:1
func A_arbace_repr_clojure_text_cond_open_fn__670000030_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_text_cond_open_fn__670000030_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_cond_open_fn__670000030_A{}; t.Ctor_O_O(p0, p1); return t }
//line :130:1
func (t *A_arbace_repr_clojure_text_cond_open_fn__670000030_A) Ctor_O_O(c__i, c__s any) { t.F_i = c__i; t.F_s = c__s }
//line :130:1
func (t *A_arbace_repr_clojure_text_cond_open_fn__670000030_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 any = A_arbace_repr_clojure_text_A_const_22; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()); var tmp3 any = t.F_s; var tmp4 jrt.Number_I; var na_139 any = t.F_i; var na_140 int64 = 2; if jrt.Long_InstanceOf(na_139) { var n0_141 int64 = jrt.NN(jrt.Long_Cast(na_139)).LongValue__J(); var n1_142 int64 = na_140; var nr_143 int64 = n0_141 + n1_142; if (n0_141^nr_143)&(n1_142^nr_143) >= 0 { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_143)) } else { tmp4 = lang.Numbers_Add_O_J__Number_NoInit(na_139, na_140) } } else { tmp4 = lang.Numbers_Add_O_J__Number_NoInit(na_139, na_140) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O_O__O(tmp3, tmp4)) { var na_124 any; var t_ any = t.F_i; t.F_i = nil; na_124 = t_; var na_125 int64 = 3; if jrt.Long_InstanceOf(na_124) { var n0_126 int64 = jrt.NN(jrt.Long_Cast(na_124)).LongValue__J(); var n1_127 int64 = na_125; var nr_128 int64 = n0_126 + n1_127; if (n0_126^nr_128)&(n1_127^nr_128) >= 0 { j__1 = jrt.Long_ValueOf_J__Long_NoInit(nr_128).Ref() } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_124, na_125) } } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_124, na_125) } } else { var na_129 any; var t__2 any = t.F_i; t.F_i = nil; na_129 = t__2; var na_130 int64 = 2; if jrt.Long_InstanceOf(na_129) { var n0_131 int64 = jrt.NN(jrt.Long_Cast(na_129)).LongValue__J(); var n1_132 int64 = na_130; var nr_133 int64 = n0_131 + n1_132; if (n0_131^nr_133)&(n1_132^nr_133) >= 0 { j__1 = jrt.Long_ValueOf_J__Long_NoInit(nr_133).Ref() } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_129, na_130) } } else { j__1 = lang.Numbers_Add_O_J__Number_NoInit(na_129, na_130) } }; L1: for {
												var tmp5 any; var and__1927000168__auto____2 bool; var na_134 any = j__1; var na_135 int64 = int64(lang.RT_Count_O__I_NoInit(t.F_s)); if jrt.Long_InstanceOf(na_134) { var n0_136 int64 = jrt.NN(jrt.Long_Cast(na_134)).LongValue__J(); var n1_137 int64 = na_135; and__1927000168__auto____2 = n0_136 < n1_137 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_J__Z_NoInit(na_134, na_135) }; if and__1927000168__auto____2 { var tmp6 *jrt.String = jrt.String_Cast(t.F_s); tmp5 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_17.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(tmp6).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))).Ref()) } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp5) { var tmp7 jrt.Number_I; var na_144 any = j__1; if jrt.Long_InstanceOf(na_144) { var n0_145 int64 = jrt.NN(jrt.Long_Cast(na_144)).LongValue__J(); if n0_145 == 9223372036854775807 { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_144) } else { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_145 + 1)) } } else { if jrt.Double_InstanceOf(na_144) { var n0_145_2 float64 = jrt.NN(jrt.Double_Cast(na_144)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_145_2 + 1.0)) } else { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_144) } }; j__1 = tmp7; continue L1 } else { return j__1 } } }; /*line :130:1*/panic("j2g: unreachable") }




func A_arbace_repr_clojure_text_branches_A_New() *A_arbace_repr_clojure_text_branches_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_branches_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_repr_clojure_text_branches_A) Ctor() {}
//line :135:1
func (t *A_arbace_repr_clojure_text_branches_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var j__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O()); var tmp2 jrt.Number_I
												var na_147 any = i__1


	if jrt.Long_InstanceOf(na_147) { var n0_148 int64 = jrt.NN(jrt.Long_Cast(na_147)).LongValue__J(); if n0_148 == 9223372036854775807 { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_147) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_148 + 1)) } } else { if jrt.Double_InstanceOf(na_147) { var n0_148_2 float64 = jrt.NN(jrt.Double_Cast(na_147)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_148_2 + 1.0)) } else { tmp2 = lang.Numbers_Inc_O__Number_NoInit(na_147) } }; j__3 = tmp1.Invoke_O_O__O(s__0, tmp2)
//line :135:1
	var bs__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		var tmp3 any = A_arbace_repr_clojure_text_A_const_20; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, j__3)) { return bs__4 } else { var fe__5 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O()).Invoke_O_O__O(s__0, j__3); var feature__6 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(s__0, j__3, fe__5); var v__7 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O()).Invoke_O_O__O(s__0, fe__5)




			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_54.GetRawRoot__O()).Invoke_O_O__O(feature__6, Lit_1)) { } else { lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, j__3, Lit_2) }
			var tmp4 any = A_arbace_repr_clojure_text_A_const_20; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, v__7)) { lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, v__7, Lit_3) }
//line :140:1
			var ve__8 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O()).Invoke_O_O__O(s__0, v__7)







			j__3, bs__4 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O()).Invoke_O_O__O(s__0, ve__8), lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_6.GetRawRoot__O()).Invoke_O_O__O(bs__4, lang.Tuple_Create_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_12.GetRawRoot__O()).Invoke_O_O__O(feature__6, A_arbace_repr_clojure_text_A_const_56)), v__7, ve__8)); continue L1 } } }; /*line :135:1*/panic("j2g: unreachable") }
















func A_arbace_repr_clojure_text_selected_A_New() *A_arbace_repr_clojure_text_selected_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_selected_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_repr_clojure_text_selected_A) Ctor() {}
//line :152:1
func (t *A_arbace_repr_clojure_text_selected_A) Invoke_O_O_O_O_O__O(self, s__0, i__1, features__2, depth__3 any) any { var splice_QMARK___5 bool; var tmp1 any = A_arbace_repr_clojure_text_A_const_22; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()); var tmp3 jrt.Number_I; var na_149 any = i__1; var na_150 int64 = 2; if




	jrt.Long_InstanceOf(na_149) { var n0_151 int64 = jrt.NN(jrt.Long_Cast(na_149)).LongValue__J(); var n1_152 int64 = na_150; var nr_153 int64 = n0_151 + n1_152; if (n0_151^nr_153)&(n1_152^nr_153) >= 0 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_153)) } else { tmp3 = lang.Numbers_Add_O_J__Number_NoInit(na_149, na_150) } } else { tmp3 = lang.Numbers_Add_O_J__Number_NoInit(na_149, na_150) }; splice_QMARK___5 = lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O_O__O(s__0, tmp3)); var open__6 any = /*line :152:1*/lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_52.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1); var vec__670000034__7 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_57.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_9.GetRawRoot__O()); var tmp6 any = A_arbace_repr_clojure_text_selected_fn__670000038_A_New_O(features__2); var tmp7 *jrt.Class; var fncls__154 *jrt.Class = A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class; if






	fncls__154 == nil { var fncls__154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class = fncls__154d; tmp7 = fncls__154d } else { tmp7 = fncls__154 }; vec__670000034__7 = tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_62.GetRawRoot__O()).Invoke_O_O__O(s__0, open__6))); var ___8 any = /*line :152:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(0), nil); var v__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(1), nil); var ve__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000034__7, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp8 bool; var and__1927000168__auto____11 bool = splice_QMARK___5; _ = ___8; if and__1927000168__auto____11 {








		var na_155 any = depth__3; if jrt.Long_InstanceOf(na_155) { var n0_156 int64 = jrt.NN(jrt.Long_Cast(na_155)).LongValue__J(); tmp8 = n0_156 == 0 } else { if jrt.Double_InstanceOf(na_155) { var n0_156_2 float64 = jrt.NN(jrt.Double_Cast(na_155)).DoubleValue__D(); tmp8 = n0_156_2 == 0.0 } else { tmp8 = lang.Numbers_IsZero_O__Z_NoInit(na_155) } } } else { tmp8 = and__1927000168__auto____11 }; if tmp8 {
			lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_19) }; if
	lang.Util_Identical_O_O__Z_NoInit(v__9, nil) { return Lit_20 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(splice_QMARK___5).Ref())) {
		return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(s__0, v__9, ve__10), features__2) } else {
//line :163:1
			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_59); if jrt.J2g_Truth(tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, v__9))) {

				var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_58.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_12.GetRawRoot__O()); var tmp12 jrt.Number_I; var na_157 any = v__9; if jrt.Long_InstanceOf(na_157) { var n0_158 int64 = jrt.NN(jrt.Long_Cast(na_157)).LongValue__J(); if n0_158 == 9223372036854775807 { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_157) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_158 + 1)) } } else { if jrt.Double_InstanceOf(na_157) { var n0_158_2 float64 = jrt.NN(jrt.Double_Cast(na_157)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_158_2 + 1.0)) } else { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_157) } }; var tmp13 any = tmp12; var tmp14 jrt.Number_I; var na_159 any = ve__10; if jrt.Long_InstanceOf(na_159) { var n0_160 int64 = jrt.NN(jrt.Long_Cast(na_159)).LongValue__J(); if n0_160 == -9223372036854775808 { tmp14 = lang.Numbers_Dec_O__Number_NoInit(na_159) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_160 - 1)) } } else { if jrt.Double_InstanceOf(na_159) { var n0_160_2 float64 = jrt.NN(jrt.Double_Cast(na_159)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_160_2 - 1.0)) } else { tmp14 = lang.Numbers_Dec_O__Number_NoInit(na_159) } }; return tmp10.Invoke_O_O__O(tmp11.Invoke_O_O_O__O(s__0, tmp13, tmp14), features__2) } else {
//line :163:1
					if A_arbace_repr_clojure_text_A_const_34 != nil {


						return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, v__9, Lit_21) } else {
//line :163:1
							return nil } } } } }
//line :159:1
func A_arbace_repr_clojure_text_selected_fn__670000038_A_New_O(p0 any) *A_arbace_repr_clojure_text_selected_fn__670000038_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_selected_fn__670000038_A{}; t.Ctor_O(p0); return t }
//line :159:1
func (t *A_arbace_repr_clojure_text_selected_fn__670000038_A) Ctor_O(c__features any) { t.F_features = c__features }
//line :159:1
func (t *A_arbace_repr_clojure_text_selected_fn__670000038_A) Invoke_O_O__O(self, p__670000037__1 any) any { var vec__670000039__2 any = p__670000037__1; var f__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__670000039__2, lang.RT_IntCast_J__I_NoInit(0), nil); var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_60.GetRawRoot__O()).Invoke_O_O__O(t.F_features, f__3); if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(f__3, A_arbace_repr_clojure_text_A_const_61)).Ref() } }








func A_arbace_repr_clojure_text_resolve_conditionals_A_New() *A_arbace_repr_clojure_text_resolve_conditionals_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_resolve_conditionals_A{}; t.Ctor(); return t }
//line :168:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_A) Ctor() {}
//line :168:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_A) Invoke_O_O_O__O(self, s__0, features__1 any) any {





	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_64.GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_16))) { return s__0 } else { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var sb__4 any = jrt.StringBuilder_New(); var i__5 any = lang.RT_Box_J__Number_NoInit(0); var depth__6 int64 = 0; L1: for {



		var tmp1 bool; var na_161 any = i__5; var na_162 int64 = int64(n__3); if jrt.Long_InstanceOf(na_161) { var n0_163 int64 = jrt.NN(jrt.Long_Cast(na_161)).LongValue__J(); var n1_164 int64 = na_162; tmp1 = n0_163 >= n1_164 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_161, na_162) }; if tmp1 {
			return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_63.GetRawRoot__O()).Invoke_O__O(sb__4) } else {
//line :178:1
				var c__7 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__5)); var copy__8 any; var tmp2 any = A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A_New_O_O_O(i__5, sb__4, s__0); var tmp3 *jrt.Class
				var fncls__166 /*line :178:1*/*jrt.Class = A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A_fn_class


				if fncls__166 == nil { var fncls__166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A_fn_class = fncls__166d; tmp3 = fncls__166d } else { tmp3 = fncls__166 }; copy__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :178:1
				var G__670000050__9_ uint16 = c__7



				switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__9_).Ref()) { case 34: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__9_).Ref(), A_arbace_repr_clojure_text_A_const_18) {
					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O()).Invoke_O_O__O(s__0, i__5)), depth__6; continue L1 }
//line :182:1
				case 35: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__9_).Ref(), A_arbace_repr_clojure_text_A_const_36) { var G__670000051__10_ any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()); var tmp5 jrt.Number_I
					var na_169 any = i__5




					if jrt.Long_InstanceOf(na_169) { var n0_170 int64 = jrt.NN(jrt.Long_Cast(na_169)).LongValue__J(); if n0_170 == 9223372036854775807 { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_169) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_170 + 1)) } } else { if jrt.Double_InstanceOf(na_169) { var n0_170_2 float64 = jrt.NN(jrt.Double_Cast(na_169)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_170_2 + 1.0)) } else { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_169) } }; G__670000051__10_ = tmp4.Invoke_O_O__O(s__0, tmp5); switch lang.Util_Hash_O__I_NoInit(G__670000051__10_) { case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__670000051__10_, A_arbace_repr_clojure_text_A_const_37) {

						i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__5)), depth__6; continue L1 }
//line :188:1
					case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000051__10_, A_arbace_repr_clojure_text_A_const_18) {
						var tmp6 lang.IFn = lang.IFn_Cast(copy__8); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O()); var tmp8 jrt.Number_I; var na_171 any = i__5; if jrt.Long_InstanceOf(na_171) { var n0_172 int64 = jrt.NN(jrt.Long_Cast(na_171)).LongValue__J(); if n0_172 == 9223372036854775807 { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_171) } else { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_172 + 1)) } } else { if jrt.Double_InstanceOf(na_171) { var n0_172_2 float64 = jrt.NN(jrt.Double_Cast(na_171)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_172_2 + 1.0)) } else { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_171) } }; i__5, depth__6 = tmp6.Invoke_O__O(tmp7.Invoke_O_O__O(s__0, tmp8)), depth__6; continue L1 }
//line :188:1
					case 63: if lang.Util_Equiv_O_O__Z_NoInit(G__670000051__10_, A_arbace_repr_clojure_text_A_const_51) { var e__11 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O()).Invoke_O_O__O(s__0, i__5)



						jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_65.GetRawRoot__O()).Invoke_O_O_O_O__O(s__0, i__5, features__1, jrt.Long_ValueOf_J__Long_NoInit(depth__6).Ref())))
						i__5, depth__6 = e__11, depth__6; continue L1 }
//line :188:1
					default:
					}




					var tmp9 lang.IFn = lang.IFn_Cast(copy__8); var tmp10 jrt.Number_I; var na_173 any = i__5; if jrt.Long_InstanceOf(na_173) { var n0_174 int64 = jrt.NN(jrt.Long_Cast(na_173)).LongValue__J(); if n0_174 == 9223372036854775807 { tmp10 = lang.Numbers_Inc_O__Number_NoInit(na_173) } else { tmp10 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_174 + 1)) } } else { if jrt.Double_InstanceOf(na_173) { var n0_174_2 float64 = jrt.NN(jrt.Double_Cast(na_173)).DoubleValue__D(); tmp10 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_174_2 + 1.0)) } else { tmp10 = lang.Numbers_Inc_O__Number_NoInit(na_173) } }; i__5, depth__6 = tmp9.Invoke_O__O(tmp10), depth__6; continue L1 }
//line :182:1
				case 40: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__9_).Ref(), A_arbace_repr_clojure_text_A_const_19) {



					var tmp11 lang.IFn = lang.IFn_Cast(copy__8); var tmp12 jrt.Number_I; var na_175 any = i__5; if jrt.Long_InstanceOf(na_175) { var n0_176 int64 = jrt.NN(jrt.Long_Cast(na_175)).LongValue__J(); if n0_176 == 9223372036854775807 { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_175) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_176 + 1)) } } else { if jrt.Double_InstanceOf(na_175) { var n0_176_2 float64 = jrt.NN(jrt.Double_Cast(na_175)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_176_2 + 1.0)) } else { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_175) } }; i__5, depth__6 = tmp11.Invoke_O__O(tmp12), lang.Numbers_Inc_J__J_NoInit(depth__6); continue L1 }
//line :182:1
				case 41: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__9_).Ref(), A_arbace_repr_clojure_text_A_const_20) {




					var tmp13 lang.IFn = lang.IFn_Cast(copy__8); var tmp14 jrt.Number_I; var na_177 any = i__5; if jrt.Long_InstanceOf(na_177) { var n0_178 int64 = jrt.NN(jrt.Long_Cast(na_177)).LongValue__J(); if n0_178 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_177) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_178 + 1)) } } else { if jrt.Double_InstanceOf(na_177) { var n0_178_2 float64 = jrt.NN(jrt.Double_Cast(na_177)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_178_2 + 1.0)) } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_177) } }; i__5, depth__6 = tmp13.Invoke_O__O(tmp14), lang.Numbers_Max_J_J__J_NoInit(0, lang.Numbers_Dec_J__J_NoInit(depth__6)); continue L1 }
//line :182:1
				case 59: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__9_).Ref(), A_arbace_repr_clojure_text_A_const_21) {

					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__5)), depth__6; continue L1 }
//line :182:1
				case 91: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__9_).Ref(), A_arbace_repr_clojure_text_A_const_23) {



					var tmp15 lang.IFn = lang.IFn_Cast(copy__8); var tmp16 jrt.Number_I; var na_179 any = i__5; if jrt.Long_InstanceOf(na_179) { var n0_180 int64 = jrt.NN(jrt.Long_Cast(na_179)).LongValue__J(); if n0_180 == 9223372036854775807 { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_179) } else { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_180 + 1)) } } else { if jrt.Double_InstanceOf(na_179) { var n0_180_2 float64 = jrt.NN(jrt.Double_Cast(na_179)).DoubleValue__D(); tmp16 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_180_2 + 1.0)) } else { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_179) } }; i__5, depth__6 = tmp15.Invoke_O__O(tmp16), lang.Numbers_Inc_J__J_NoInit(depth__6); continue L1 }
//line :182:1
				case 92: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__9_).Ref(), A_arbace_repr_clojure_text_A_const_24) {


					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O()).Invoke_O_O__O(s__0, i__5)), depth__6; continue L1 }
//line :182:1
				case 93: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__9_).Ref(), A_arbace_repr_clojure_text_A_const_25) {




					var tmp17 lang.IFn = lang.IFn_Cast(copy__8); var tmp18 jrt.Number_I; var na_181 any = i__5; if jrt.Long_InstanceOf(na_181) { var n0_182 int64 = jrt.NN(jrt.Long_Cast(na_181)).LongValue__J(); if n0_182 == 9223372036854775807 { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_181) } else { tmp18 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_182 + 1)) } } else { if jrt.Double_InstanceOf(na_181) { var n0_182_2 float64 = jrt.NN(jrt.Double_Cast(na_181)).DoubleValue__D(); tmp18 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_182_2 + 1.0)) } else { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_181) } }; i__5, depth__6 = tmp17.Invoke_O__O(tmp18), lang.Numbers_Max_J_J__J_NoInit(0, lang.Numbers_Dec_J__J_NoInit(depth__6)); continue L1 }
//line :182:1
				case 123: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__9_).Ref(), A_arbace_repr_clojure_text_A_const_28) {



					var tmp19 lang.IFn = lang.IFn_Cast(copy__8); var tmp20 jrt.Number_I; var na_183 any = i__5; if jrt.Long_InstanceOf(na_183) { var n0_184 int64 = jrt.NN(jrt.Long_Cast(na_183)).LongValue__J(); if n0_184 == 9223372036854775807 { tmp20 = lang.Numbers_Inc_O__Number_NoInit(na_183) } else { tmp20 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_184 + 1)) } } else { if jrt.Double_InstanceOf(na_183) { var n0_184_2 float64 = jrt.NN(jrt.Double_Cast(na_183)).DoubleValue__D(); tmp20 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_184_2 + 1.0)) } else { tmp20 = lang.Numbers_Inc_O__Number_NoInit(na_183) } }; i__5, depth__6 = tmp19.Invoke_O__O(tmp20), lang.Numbers_Inc_J__J_NoInit(depth__6); continue L1 }
//line :182:1
				case 125: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__670000050__9_).Ref(), A_arbace_repr_clojure_text_A_const_29) {




					var tmp21 lang.IFn = lang.IFn_Cast(copy__8); var tmp22 jrt.Number_I; var na_185 any = i__5; if jrt.Long_InstanceOf(na_185) { var n0_186 int64 = jrt.NN(jrt.Long_Cast(na_185)).LongValue__J(); if n0_186 == 9223372036854775807 { tmp22 = lang.Numbers_Inc_O__Number_NoInit(na_185) } else { tmp22 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_186 + 1)) } } else { if jrt.Double_InstanceOf(na_185) { var n0_186_2 float64 = jrt.NN(jrt.Double_Cast(na_185)).DoubleValue__D(); tmp22 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_186_2 + 1.0)) } else { tmp22 = lang.Numbers_Inc_O__Number_NoInit(na_185) } }; i__5, depth__6 = tmp21.Invoke_O__O(tmp22), lang.Numbers_Max_J_J__J_NoInit(0, lang.Numbers_Dec_J__J_NoInit(depth__6)); continue L1 }
//line :182:1
				default:
				}











				var tmp23 lang.IFn = lang.IFn_Cast(copy__8); var tmp24 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(c__7).Ref())) { var na_187 any = i__5; if jrt.Long_InstanceOf(na_187) { var n0_188 int64 = jrt.NN(jrt.Long_Cast(na_187)).LongValue__J(); if n0_188 == 9223372036854775807 { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_187) } else { tmp24 = jrt.Long_ValueOf_J__Long_NoInit(n0_188 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_187) { var n0_188_2 float64 = jrt.NN(jrt.Double_Cast(na_187)).DoubleValue__D(); tmp24 = jrt.Double_ValueOf_D__Double_NoInit(n0_188_2 + 1.0).Ref() } else { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_187) } } } else { tmp24 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(s__0, i__5) }; i__5, depth__6 = tmp23.Invoke_O__O(tmp24), depth__6; continue L1 } } }
//line :168:1
	panic("j2g: unreachable") }
//line :168:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_A) Invoke_O_O__O(self, s__0 any) any {



	return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_58.GetRawRoot__O()).Invoke_O_O__O(s__0, A_arbace_repr_clojure_text_A_const_66)
}







func A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :181:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A) Ctor_O_O_O(c__i, c__sb, c__s any) { t.F_i = c__i; t.F_sb = c__sb; t.F_s = c__s }
//line :181:1
func (t *A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A) Invoke_O_O__O(self, j__1 any) any { var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp2 jrt.CharSequence = jrt.CharSequence_Cast(t.F_s); jrt.NN(tmp1).Append_CharSequence_I_I__StringBuilder(tmp2, lang.RT_IntCast_O__I_NoInit(t.F_i), lang.RT_IntCast_O__I_NoInit(j__1)); return j__1 }

















func A_arbace_repr_clojure_text_code_tokens_A_New() *A_arbace_repr_clojure_text_code_tokens_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_code_tokens_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_repr_clojure_text_code_tokens_A) Ctor() {}
//line :199:1
func (t *A_arbace_repr_clojure_text_code_tokens_A) Invoke_O_O__O(self, s__0 any) any { { var n__2 int32 = lang.RT_Count_O__I_NoInit(s__0); var i__3 any = lang.RT_Box_J__Number_NoInit(0); var out__4 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_67.GetRawRoot__O()).Invoke_O__O(lang.PersistentVector_EMPTY.Ref()); L1: for {





	var tmp1 bool; var na_189 any = i__3; var na_190 int64 = int64(n__2); if jrt.Long_InstanceOf(na_189) { var n0_191 int64 = jrt.NN(jrt.Long_Cast(na_189)).LongValue__J(); var n1_192 int64 = na_190; tmp1 = n0_191 >= n1_192 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_189, na_190) }; if tmp1 {
		return lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_68.GetRawRoot__O()).Invoke_O__O(out__4) } else {
//line :205:1
			var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__3))


			if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_18)).CharValue__C()) {
				i__3, out__4 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O()).Invoke_O_O__O(s__0, i__3), out__4; continue L1 } else {
//line :208:1
					if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_21)).CharValue__C()) {

						i__3, out__4 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__3), out__4; continue L1 } else {
//line :208:1
							if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_24)).CharValue__C()) {


								i__3, out__4 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O()).Invoke_O_O__O(s__0, i__3), out__4; continue L1 } else {
//line :208:1
									if lang.Util_Equiv_C_C__Z_NoInit(c__5, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C()) { var G__670000054__6_ any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()); var tmp3 jrt.Number_I
										var na_195 any = i__3


										if jrt.Long_InstanceOf(na_195) { var n0_196 int64 = jrt.NN(jrt.Long_Cast(na_195)).LongValue__J(); if n0_196 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_195) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_196 + 1)) } } else { if jrt.Double_InstanceOf(na_195) { var n0_196_2 float64 = jrt.NN(jrt.Double_Cast(na_195)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_196_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_195) } }; G__670000054__6_ = tmp2.Invoke_O_O__O(s__0, tmp3); switch lang.Util_Hash_O__I_NoInit(G__670000054__6_) { case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__670000054__6_, A_arbace_repr_clojure_text_A_const_37) {

											i__3, out__4 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__3), out__4; continue L1 }
//line :212:1
										case 34: if lang.Util_Equiv_O_O__Z_NoInit(G__670000054__6_, A_arbace_repr_clojure_text_A_const_18) {
											var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O()); var tmp5 jrt.Number_I; var na_197 any = i__3; if jrt.Long_InstanceOf(na_197) { var n0_198 int64 = jrt.NN(jrt.Long_Cast(na_197)).LongValue__J(); if n0_198 == 9223372036854775807 { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_197) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_198 + 1)) } } else { if jrt.Double_InstanceOf(na_197) { var n0_198_2 float64 = jrt.NN(jrt.Double_Cast(na_197)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_198_2 + 1.0)) } else { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_197) } }; i__3, out__4 = tmp4.Invoke_O_O__O(s__0, tmp5), out__4; continue L1 }
//line :212:1
										default:
										}

										var tmp6 jrt.Number_I; var na_199 any = i__3; if jrt.Long_InstanceOf(na_199) { var n0_200 int64 = jrt.NN(jrt.Long_Cast(na_199)).LongValue__J(); if n0_200 == 9223372036854775807 { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_199) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_200 + 1)) } } else { if jrt.Double_InstanceOf(na_199) { var n0_200_2 float64 = jrt.NN(jrt.Double_Cast(na_199)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_200_2 + 1.0)) } else { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_199) } }; i__3, out__4 = tmp6, out__4; continue L1 } else {
//line :208:1
											if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(c__5).Ref())) {







												var tmp7 jrt.Number_I; var na_201 any = i__3; if jrt.Long_InstanceOf(na_201) { var n0_202 int64 = jrt.NN(jrt.Long_Cast(na_201)).LongValue__J(); if n0_202 == 9223372036854775807 { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_201) } else { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_202 + 1)) } } else { if jrt.Double_InstanceOf(na_201) { var n0_202_2 float64 = jrt.NN(jrt.Double_Cast(na_201)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_202_2 + 1.0)) } else { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_201) } }; i__3, out__4 = tmp7, out__4; continue L1 } else {
//line :208:1
													var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_69); if jrt.J2g_Truth(tmp8.Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(c__5).Ref())) {








														var tmp9 jrt.Number_I; var na_203 any = i__3; if jrt.Long_InstanceOf(na_203) { var n0_204 int64 = jrt.NN(jrt.Long_Cast(na_203)).LongValue__J(); if n0_204 == 9223372036854775807 { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_203) } else { tmp9 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_204 + 1)) } } else { if jrt.Double_InstanceOf(na_203) { var n0_204_2 float64 = jrt.NN(jrt.Double_Cast(na_203)).DoubleValue__D(); tmp9 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_204_2 + 1.0)) } else { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_203) } }; i__3, out__4 = tmp9, out__4; continue L1 } else {
//line :208:1
															if A_arbace_repr_clojure_text_A_const_34 != nil { var e__6 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(s__0, i__3)









																i__3, out__4 = e__6, lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_70.GetRawRoot__O()).Invoke_O_O__O(out__4, lang.Tuple_Create_O_O__IPersistentVector(i__3, e__6)); continue L1 } else {
//line :208:1
																	return nil } } } } } } } } } }; /*line :199:1*/panic("j2g: unreachable") }




















func A_arbace_repr_clojure_text_list_spans_A_New() *A_arbace_repr_clojure_text_list_spans_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_list_spans_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_repr_clojure_text_list_spans_A) Ctor() {}
//line :220:1
func (t *A_arbace_repr_clojure_text_list_spans_A) Invoke_O_O_O__O(self, s__0, pred__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(s__0); var i__4 any = lang.RT_Box_J__Number_NoInit(0); var out__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




	var tmp1 bool; var na_205 any = i__4; var na_206 int64 = int64(n__3); if jrt.Long_InstanceOf(na_205) { var n0_207 int64 = jrt.NN(jrt.Long_Cast(na_205)).LongValue__J(); var n1_208 int64 = na_206; tmp1 = n0_207 >= n1_208 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_205, na_206) }; if tmp1 { return out__5 } else { var c__6 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__4))


		if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_18)).CharValue__C()) {
			i__4, out__5 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O()).Invoke_O_O__O(s__0, i__4), out__5; continue L1 } else {
//line :228:1
				if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_21)).CharValue__C()) {

					i__4, out__5 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__4), out__5; continue L1 } else {
//line :228:1
						if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_24)).CharValue__C()) {


							i__4, out__5 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_53.GetRawRoot__O()).Invoke_O_O__O(s__0, i__4), out__5; continue L1 } else {
//line :228:1
								var tmp2 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())



								if and__1927000168__auto____7 { var tmp3 any = A_arbace_repr_clojure_text_A_const_18; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()); var tmp5 jrt.Number_I; var na_215 any = i__4; if jrt.Long_InstanceOf(na_215) { var n0_216 int64 = jrt.NN(jrt.Long_Cast(na_215)).LongValue__J(); if n0_216 == 9223372036854775807 { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_215) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_216 + 1)) } } else { if jrt.Double_InstanceOf(na_215) { var n0_216_2 float64 = jrt.NN(jrt.Double_Cast(na_215)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_216_2 + 1.0)) } else { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_215) } }; tmp2 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4.Invoke_O_O__O(s__0, tmp5)) } else { tmp2 = and__1927000168__auto____7 }
//line :228:1
								if tmp2 {



									var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_45.GetRawRoot__O()); var tmp7 jrt.Number_I; var na_217 any = i__4; if jrt.Long_InstanceOf(na_217) { var n0_218 int64 = jrt.NN(jrt.Long_Cast(na_217)).LongValue__J(); if n0_218 == 9223372036854775807 { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_217) } else { tmp7 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_218 + 1)) } } else { if jrt.Double_InstanceOf(na_217) { var n0_218_2 float64 = jrt.NN(jrt.Double_Cast(na_217)).DoubleValue__D(); tmp7 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_218_2 + 1.0)) } else { tmp7 = lang.Numbers_Inc_O__Number_NoInit(na_217) } }; i__4, out__5 = tmp6.Invoke_O_O__O(s__0, tmp7), out__5; continue L1 } else {
//line :228:1
										var tmp8 bool; var and__1927000168__auto____7_2 bool = lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_36)).CharValue__C())




										if and__1927000168__auto____7_2 { var tmp9 any = A_arbace_repr_clojure_text_A_const_37; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_38.GetRawRoot__O()); var tmp11 jrt.Number_I; var na_219 any = i__4; if jrt.Long_InstanceOf(na_219) { var n0_220 int64 = jrt.NN(jrt.Long_Cast(na_219)).LongValue__J(); if n0_220 == 9223372036854775807 { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_219) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_220 + 1)) } } else { if jrt.Double_InstanceOf(na_219) { var n0_220_2 float64 = jrt.NN(jrt.Double_Cast(na_219)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_220_2 + 1.0)) } else { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_219) } }; tmp8 = lang.Util_Equiv_O_O__Z_NoInit(tmp9, tmp10.Invoke_O_O__O(s__0, tmp11)) } else { tmp8 = and__1927000168__auto____7_2 }
//line :228:1
										if tmp8 {




											i__4, out__5 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__4), out__5; continue L1 } else {
//line :228:1
												if lang.Util_Equiv_C_C__Z_NoInit(c__6, jrt.NN(jrt.Character_Cast(A_arbace_repr_clojure_text_A_const_19)).CharValue__C()) { var h__7 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_42.GetRawRoot__O()); var tmp13 jrt.Number_I
													var na_221 any = i__4





													if jrt.Long_InstanceOf(na_221) { var n0_222 int64 = jrt.NN(jrt.Long_Cast(na_221)).LongValue__J(); if n0_222 == 9223372036854775807 { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_221) } else { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_222 + 1)) } } else { if jrt.Double_InstanceOf(na_221) { var n0_222_2 float64 = jrt.NN(jrt.Double_Cast(na_221)).DoubleValue__D(); tmp13 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_222_2 + 1.0)) } else { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_221) } }; h__7 = tmp12.Invoke_O_O__O(s__0, tmp13)
//line :228:1
													var head__8 any; var tmp14 any; var and__1927000168__auto____8 bool; var na_210 any = h__7; var na_211 int64 = int64(n__3)







													if jrt.Long_InstanceOf(na_210) { var n0_212 int64 = jrt.NN(jrt.Long_Cast(na_210)).LongValue__J(); var n1_213 int64 = na_211; and__1927000168__auto____8 = n0_212 < n1_213 } else { and__1927000168__auto____8 = lang.Numbers_Lt_O_J__Z_NoInit(na_210, na_211) }; if and__1927000168__auto____8 { tmp14 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_32.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(h__7))).Ref())) } else { tmp14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp14) {
														head__8 = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(s__0, h__7, lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(s__0, h__7)) } else {
//line :236:1
															head__8 = nil
														}
													var tmp15 any; var and__1927000168__auto____9 any = head__8; if jrt.J2g_Truth(and__1927000168__auto____9) { tmp15 = lang.IFn_Cast(pred__1).Invoke_O__O(head__8) } else { tmp15 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp15) { var e__9 any = lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_41.GetRawRoot__O()).Invoke_O_O__O(s__0, i__4)
														i__4, out__5 = e__9, lang.IFn_Cast(A_arbace_repr_clojure_text_A_const_6.GetRawRoot__O()).Invoke_O_O__O(out__5, lang.Tuple_Create_O_O__IPersistentVector(i__4, e__9)); continue L1 } else {
															var tmp16 jrt.Number_I; var na_223 any = i__4; if jrt.Long_InstanceOf(na_223) { var n0_224 int64 = jrt.NN(jrt.Long_Cast(na_223)).LongValue__J(); if n0_224 == 9223372036854775807 { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_223) } else { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_224 + 1)) } } else { if jrt.Double_InstanceOf(na_223) { var n0_224_2 float64 = jrt.NN(jrt.Double_Cast(na_223)).DoubleValue__D(); tmp16 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_224_2 + 1.0)) } else { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_223) } }; i__4, out__5 = tmp16, out__5; continue L1 } } else {
//line :228:1
																if A_arbace_repr_clojure_text_A_const_34 != nil {












																	var tmp17 jrt.Number_I; var na_225 any = i__4; if jrt.Long_InstanceOf(na_225) { var n0_226 int64 = jrt.NN(jrt.Long_Cast(na_225)).LongValue__J(); if n0_226 == 9223372036854775807 { tmp17 = lang.Numbers_Inc_O__Number_NoInit(na_225) } else { tmp17 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_226 + 1)) } } else { if jrt.Double_InstanceOf(na_225) { var n0_226_2 float64 = jrt.NN(jrt.Double_Cast(na_225)).DoubleValue__D(); tmp17 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_226_2 + 1.0)) } else { tmp17 = lang.Numbers_Inc_O__Number_NoInit(na_225) } }; i__4, out__5 = tmp17, out__5; continue L1 } else {
//line :228:1
																		return nil } } } } } } } } } }; /*line :220:1*/panic("j2g: unreachable") }







type A_arbace_repr_clojure_text_A struct{ jrt.Object }

var A_arbace_repr_clojure_text_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_text_A_const_0 *lang.Var

var A_arbace_repr_clojure_text_A_const_1 *lang.Var

var A_arbace_repr_clojure_text_A_const_2 any

var A_arbace_repr_clojure_text_A_const_3 any

var A_arbace_repr_clojure_text_A_const_4 *lang.Var

var A_arbace_repr_clojure_text_A_const_5 *lang.Var

var A_arbace_repr_clojure_text_A_const_6 *lang.Var

var A_arbace_repr_clojure_text_A_const_7 any

var A_arbace_repr_clojure_text_A_const_8 *lang.Var

var A_arbace_repr_clojure_text_A_const_9 *lang.Var

var A_arbace_repr_clojure_text_A_const_10 *lang.Var

var A_arbace_repr_clojure_text_A_const_11 any

var A_arbace_repr_clojure_text_A_const_12 *lang.Var

var A_arbace_repr_clojure_text_A_const_13 any

var A_arbace_repr_clojure_text_A_const_14 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_15 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_16 any

var A_arbace_repr_clojure_text_A_const_17 *lang.Var

var A_arbace_repr_clojure_text_A_const_18 any

var A_arbace_repr_clojure_text_A_const_19 any

var A_arbace_repr_clojure_text_A_const_20 any

var A_arbace_repr_clojure_text_A_const_21 any

var A_arbace_repr_clojure_text_A_const_22 any

var A_arbace_repr_clojure_text_A_const_23 any

var A_arbace_repr_clojure_text_A_const_24 any

var A_arbace_repr_clojure_text_A_const_25 any

var A_arbace_repr_clojure_text_A_const_26 any

var A_arbace_repr_clojure_text_A_const_27 any

var A_arbace_repr_clojure_text_A_const_28 any

var A_arbace_repr_clojure_text_A_const_29 any

var A_arbace_repr_clojure_text_A_const_30 any

var A_arbace_repr_clojure_text_A_const_31 *lang.Var

var A_arbace_repr_clojure_text_A_const_32 *lang.Var

var A_arbace_repr_clojure_text_A_const_33 *lang.Var

var A_arbace_repr_clojure_text_A_const_34 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_35 *lang.Var

var A_arbace_repr_clojure_text_A_const_36 any

var A_arbace_repr_clojure_text_A_const_37 any

var A_arbace_repr_clojure_text_A_const_38 *lang.Var

var A_arbace_repr_clojure_text_A_const_39 any

var A_arbace_repr_clojure_text_A_const_40 *lang.Var

var A_arbace_repr_clojure_text_A_const_41 *lang.Var

var A_arbace_repr_clojure_text_A_const_42 *lang.Var

var A_arbace_repr_clojure_text_A_const_43 *lang.Var

var A_arbace_repr_clojure_text_A_const_44 any

var A_arbace_repr_clojure_text_A_const_45 *lang.Var

var A_arbace_repr_clojure_text_A_const_46 *lang.Var

var A_arbace_repr_clojure_text_A_const_47 any

var A_arbace_repr_clojure_text_A_const_48 *lang.Var

var A_arbace_repr_clojure_text_A_const_49 any

var A_arbace_repr_clojure_text_A_const_50 any

var A_arbace_repr_clojure_text_A_const_51 any

var A_arbace_repr_clojure_text_A_const_52 *lang.Var

var A_arbace_repr_clojure_text_A_const_53 *lang.Var

var A_arbace_repr_clojure_text_A_const_54 *lang.Var

var A_arbace_repr_clojure_text_A_const_55 *lang.Var

var A_arbace_repr_clojure_text_A_const_56 any

var A_arbace_repr_clojure_text_A_const_57 *lang.Var

var A_arbace_repr_clojure_text_A_const_58 *lang.Var

var A_arbace_repr_clojure_text_A_const_59 any

var A_arbace_repr_clojure_text_A_const_60 *lang.Var

var A_arbace_repr_clojure_text_A_const_61 *lang.Keyword

var A_arbace_repr_clojure_text_A_const_62 *lang.Var

var A_arbace_repr_clojure_text_A_const_63 *lang.Var

var A_arbace_repr_clojure_text_A_const_64 *lang.Var

var A_arbace_repr_clojure_text_A_const_65 *lang.Var

var A_arbace_repr_clojure_text_A_const_66 any

var A_arbace_repr_clojure_text_A_const_67 *lang.Var

var A_arbace_repr_clojure_text_A_const_68 *lang.Var

var A_arbace_repr_clojure_text_A_const_69 any

var A_arbace_repr_clojure_text_A_const_70 *lang.Var

var A_arbace_repr_clojure_text_A_init jrt.ClassInit

func A_arbace_repr_clojure_text_A_Init() { if !A_arbace_repr_clojure_text_A_init.Done() { A_arbace_repr_clojure_text_A_init.Run(A_arbace_repr_clojure_text_A_clinit) } }

func A_arbace_repr_clojure_text_A_clinit() { A_arbace_repr_clojure_text_A_clinit_p0(); A_arbace_repr_clojure_text_A_clinit_p1(); A_arbace_repr_clojure_text_A_clinit_p2(); A_arbace_repr_clojure_text_A_clinit_p3(); A_arbace_repr_clojure_text_A_clinit_p4(); A_arbace_repr_clojure_text_A_clinit_p5() }

func A_arbace_repr_clojure_text_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_text_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 81); A_arbace_repr_clojure_text_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[10]); A_arbace_repr_clojure_text_A_const_1 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[11]); A_arbace_repr_clojure_text_A_const_2 = A_arbace_repr_clojure_text_A_const_pool.A[12]; A_arbace_repr_clojure_text_A_const_3 = A_arbace_repr_clojure_text_A_const_pool.A[13]; A_arbace_repr_clojure_text_A_const_4 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[14]); A_arbace_repr_clojure_text_A_const_5 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[15]); A_arbace_repr_clojure_text_A_const_6 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[16]); A_arbace_repr_clojure_text_A_const_7 = A_arbace_repr_clojure_text_A_const_pool.A[17]; A_arbace_repr_clojure_text_A_const_8 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[18]); A_arbace_repr_clojure_text_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[19]); A_arbace_repr_clojure_text_A_const_10 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[20]); A_arbace_repr_clojure_text_A_const_11 = A_arbace_repr_clojure_text_A_const_pool.A[21] }

func A_arbace_repr_clojure_text_A_clinit_p1() { A_arbace_repr_clojure_text_A_const_12 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[22]); A_arbace_repr_clojure_text_A_const_13 = A_arbace_repr_clojure_text_A_const_pool.A[23]; A_arbace_repr_clojure_text_A_const_14 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[24]); A_arbace_repr_clojure_text_A_const_15 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[25]); A_arbace_repr_clojure_text_A_const_16 = A_arbace_repr_clojure_text_A_const_pool.A[26]; A_arbace_repr_clojure_text_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[27]); A_arbace_repr_clojure_text_A_const_18 = A_arbace_repr_clojure_text_A_const_pool.A[28]; A_arbace_repr_clojure_text_A_const_19 = A_arbace_repr_clojure_text_A_const_pool.A[29]; A_arbace_repr_clojure_text_A_const_20 = A_arbace_repr_clojure_text_A_const_pool.A[30]; A_arbace_repr_clojure_text_A_const_21 = A_arbace_repr_clojure_text_A_const_pool.A[31]; A_arbace_repr_clojure_text_A_const_22 = A_arbace_repr_clojure_text_A_const_pool.A[32]; A_arbace_repr_clojure_text_A_const_23 = A_arbace_repr_clojure_text_A_const_pool.A[33]; A_arbace_repr_clojure_text_A_const_24 = A_arbace_repr_clojure_text_A_const_pool.A[34]; A_arbace_repr_clojure_text_A_const_25 = A_arbace_repr_clojure_text_A_const_pool.A[35] }

func A_arbace_repr_clojure_text_A_clinit_p2() { A_arbace_repr_clojure_text_A_const_26 = A_arbace_repr_clojure_text_A_const_pool.A[36]; A_arbace_repr_clojure_text_A_const_27 = A_arbace_repr_clojure_text_A_const_pool.A[37]; A_arbace_repr_clojure_text_A_const_28 = A_arbace_repr_clojure_text_A_const_pool.A[38]; A_arbace_repr_clojure_text_A_const_29 = A_arbace_repr_clojure_text_A_const_pool.A[39]; A_arbace_repr_clojure_text_A_const_30 = A_arbace_repr_clojure_text_A_const_pool.A[40]; A_arbace_repr_clojure_text_A_const_31 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[41]); A_arbace_repr_clojure_text_A_const_32 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[42]); A_arbace_repr_clojure_text_A_const_33 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[43]); A_arbace_repr_clojure_text_A_const_34 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[44]); A_arbace_repr_clojure_text_A_const_35 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[45]); A_arbace_repr_clojure_text_A_const_36 = A_arbace_repr_clojure_text_A_const_pool.A[46]; A_arbace_repr_clojure_text_A_const_37 = A_arbace_repr_clojure_text_A_const_pool.A[47]; A_arbace_repr_clojure_text_A_const_38 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[48]); A_arbace_repr_clojure_text_A_const_39 = A_arbace_repr_clojure_text_A_const_pool.A[49] }

func A_arbace_repr_clojure_text_A_clinit_p3() { A_arbace_repr_clojure_text_A_const_40 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[50]); A_arbace_repr_clojure_text_A_const_41 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[51]); A_arbace_repr_clojure_text_A_const_42 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[52]); A_arbace_repr_clojure_text_A_const_43 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[53]); A_arbace_repr_clojure_text_A_const_44 = A_arbace_repr_clojure_text_A_const_pool.A[54]; A_arbace_repr_clojure_text_A_const_45 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[55]); A_arbace_repr_clojure_text_A_const_46 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[56]); A_arbace_repr_clojure_text_A_const_47 = A_arbace_repr_clojure_text_A_const_pool.A[57]; A_arbace_repr_clojure_text_A_const_48 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[58]); A_arbace_repr_clojure_text_A_const_49 = A_arbace_repr_clojure_text_A_const_pool.A[59]; A_arbace_repr_clojure_text_A_const_50 = A_arbace_repr_clojure_text_A_const_pool.A[60]; A_arbace_repr_clojure_text_A_const_51 = A_arbace_repr_clojure_text_A_const_pool.A[61]; A_arbace_repr_clojure_text_A_const_52 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[62]) }

func A_arbace_repr_clojure_text_A_clinit_p4() { A_arbace_repr_clojure_text_A_const_53 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[63]); A_arbace_repr_clojure_text_A_const_54 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[64]); A_arbace_repr_clojure_text_A_const_55 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[65]); A_arbace_repr_clojure_text_A_const_56 = A_arbace_repr_clojure_text_A_const_pool.A[66]; A_arbace_repr_clojure_text_A_const_57 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[67]); A_arbace_repr_clojure_text_A_const_58 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[68]); A_arbace_repr_clojure_text_A_const_59 = A_arbace_repr_clojure_text_A_const_pool.A[69]; A_arbace_repr_clojure_text_A_const_60 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[70]); A_arbace_repr_clojure_text_A_const_61 = lang.Keyword_Cast(A_arbace_repr_clojure_text_A_const_pool.A[71]); A_arbace_repr_clojure_text_A_const_62 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[72]); A_arbace_repr_clojure_text_A_const_63 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[73]); A_arbace_repr_clojure_text_A_const_64 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[74]) }

func A_arbace_repr_clojure_text_A_clinit_p5() { A_arbace_repr_clojure_text_A_const_65 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[75]); A_arbace_repr_clojure_text_A_const_66 = A_arbace_repr_clojure_text_A_const_pool.A[76]; A_arbace_repr_clojure_text_A_const_67 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[77]); A_arbace_repr_clojure_text_A_const_68 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[78]); A_arbace_repr_clojure_text_A_const_69 = A_arbace_repr_clojure_text_A_const_pool.A[79]; A_arbace_repr_clojure_text_A_const_70 = lang.Var_Cast(A_arbace_repr_clojure_text_A_const_pool.A[80]) }

func A_arbace_repr_clojure_text_A_New() *A_arbace_repr_clojure_text_A { A_arbace_repr_clojure_text_A_Init(); t := &A_arbace_repr_clojure_text_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_text_A) Ctor() {}

func (t *A_arbace_repr_clojure_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_text_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_text_A_class }

func (t *A_arbace_repr_clojure_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_text_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_text_A); return ok }

func A_arbace_repr_clojure_text_A_Cast(x any) *A_arbace_repr_clojure_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_text_A_class)) }; return v }



type A_arbace_repr_clojure_text_at_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_at_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_branches_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_branches_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_char_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_char_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_code_tokens_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_code_tokens_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_coll_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_coll_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_cond_open_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_cond_open_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_cond_open_fn__670000030_A struct{ j2g_header uint64; F_i, F_s any }

var A_arbace_repr_clojure_text_cond_open_fn__670000030_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_eval670000004_A struct{ jrt.Object }

func A_arbace_repr_clojure_text_eval670000004_A_New() *A_arbace_repr_clojure_text_eval670000004_A { t := &A_arbace_repr_clojure_text_eval670000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_text_eval670000004_A) Ctor() {}

func (t *A_arbace_repr_clojure_text_eval670000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_text_eval670000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_text_eval670000004_A_class }

func (t *A_arbace_repr_clojure_text_eval670000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_text_eval670000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_text_eval670000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_text_eval670000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_text_eval670000004_A); return ok }

func A_arbace_repr_clojure_text_eval670000004_A_Cast(x any) *A_arbace_repr_clojure_text_eval670000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_text_eval670000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_text_eval670000004_A_class)) }; return v }



type A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_eval670000004_loading__1927001464__auto____670000005_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_eval670000008_A struct{ jrt.Object }

func A_arbace_repr_clojure_text_eval670000008_A_New() *A_arbace_repr_clojure_text_eval670000008_A { t := &A_arbace_repr_clojure_text_eval670000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_text_eval670000008_A) Ctor() {}

func (t *A_arbace_repr_clojure_text_eval670000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_text_eval670000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_text_eval670000008_A_class }

func (t *A_arbace_repr_clojure_text_eval670000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_text_eval670000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_text_eval670000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_text_eval670000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_text_eval670000008_A); return ok }

func A_arbace_repr_clojure_text_eval670000008_A_Cast(x any) *A_arbace_repr_clojure_text_eval670000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_text_eval670000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_text_eval670000008_A_class)) }; return v }



type A_arbace_repr_clojure_text_eval670000008_fn__670000009_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_eval670000008_fn__670000009_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_fail_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_fail_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_fail_fn__670000013_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_fail_fn__670000013_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_form_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_form_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_line_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_line_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_list_spans_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_list_spans_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_next_form_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_next_form_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_resolve_conditionals_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A struct{ j2g_header uint64; F_i, F_sb, F_s any }

var A_arbace_repr_clojure_text_resolve_conditionals_copy__670000048_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_selected_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_selected_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_selected_fn__670000038_A struct{ j2g_header uint64; F_features any }

var A_arbace_repr_clojure_text_selected_fn__670000038_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_skip_ws_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_skip_ws_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_string_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_string_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_terminating_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_terminating_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_token_end_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_token_end_A_fn_class *jrt.Class



type A_arbace_repr_clojure_text_ws_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_text_ws_QMARK__A_fn_class *jrt.Class
