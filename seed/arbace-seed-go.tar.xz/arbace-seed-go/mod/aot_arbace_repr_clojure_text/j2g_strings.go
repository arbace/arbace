//line j2g_strings.ae:1
package aot_arbace_repr_clojure_text

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn11,arbace.corekn3,dockn5,indexkn4,linekn4,elsekn7,defaultkn2,atkn6,lengthkn4,textkn3,cljkn12,conditionalsv11,arbace.core7,requireV3,R0,R1,R2,v11,arbace.core5,referR3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn24,arbace.repr.clojure.textm2,R4,s1158,Clojure source text, read lexically as the reader would, for repr/clojure's rules: they\n  rewrite text and keep everything else (layout, comments) as it is. The scanner knows the\n  reader's lexical syntax (doc/REPR-CLOJURE.md, \"How it reads\"): strings, regex literals,\n  character literals, comments (`;`, `#!`), discarded forms (`#_`), dispatch macros, tagged\n  literals, metadata, the quoting macros and tokens (symbols, keywords, numbers), which run\n  until whitespace or a terminating macro character, as LispReader's do. It does not build forms: it finds where\n  they begin and end.\n\n  - `form-end`: the end of the form beginning at an index;\n  - `resolve-conditionals`: reader conditionals (`#?`, `#?@`) replaced by their selected\n    branch's text, for a .cljc file becoming a .ae file (which the reader reads without\n    conditionals); `record-conditionals` and `restore-conditionals`, the same with a record of\n    what it drops and that record put back (read --full);\n  - `code-tokens`: the spans of the tokens outside strings, comments and character literals,\n    for rules that rewrite symbols; `list-spans`: the spans of the lists a token heads.v11,arbace.core6,filterc10,v11,arbace.core4,subsl0,v11,arbace.core7,ex-infoR5,R6,c44,v24,arbace.repr.clojure.text3,ws?c34,c40,c41,c59,c64,c91,c92,c93,c94,c96,c123,c125,c126,v11,arbace.core3,notv24,arbace.repr.clojure.text12,terminating?v24,arbace.repr.clojure.text4,failR7,v24,arbace.repr.clojure.text9,token-endc35,c33,v24,arbace.repr.clojure.text2,atc95,v24,arbace.repr.clojure.text8,line-endv24,arbace.repr.clojure.text8,form-endv24,arbace.repr.clojure.text7,skip-wsv24,arbace.repr.clojure.text6,closerS3,c41,c93,c125,v24,arbace.repr.clojure.text10,string-endv24,arbace.repr.clojure.text13,next-form-endc39,v24,arbace.repr.clojure.text8,coll-endc58,c61,c63,v24,arbace.repr.clojure.text9,cond-openv24,arbace.repr.clojure.text8,char-endv13,arbace.string12,starts-with?v11,arbace.core7,keywordl1,v11,arbace.core5,firstv11,arbace.core9,contains?R8,v24,arbace.repr.clojure.text8,branchesv24,arbace.repr.clojure.text20,resolve-conditionalsS2,c40,c91,v13,arbace.string9,includes?v11,arbace.core9,transientv24,arbace.repr.clojure.text8,selectedv11,arbace.core3,strv11,arbace.core11,persistent!v11,arbace.core5,conj!R9,R10,R11,v24,arbace.repr.clojure.text8,resolve*S1,R12,R13,v11,arbace.core6,reducev11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core4,not=S2,c96,c39,")

var Lit_1 *jrt.String = jrt.Intern(":")

var Lit_2 *jrt.String = jrt.Intern("Feature should be a keyword")

var Lit_3 *jrt.String = jrt.Intern("read-cond requires an even number of forms")

var Lit_4 *jrt.String = jrt.Intern("EOF while reading a character")

var Lit_5 *jrt.String = jrt.Intern("EOF while reading, expected ")

var Lit_6 *jrt.String = jrt.Intern("Unmatched delimiter: ")

var Lit_7 *jrt.String = jrt.Intern("arbace.repr.clojure.text$cond_open$fn__670000030")

var Lit_8 *jrt.String = jrt.Intern("read-cond body must be a list")

var Lit_9 *jrt.String = jrt.Intern("arbace.repr.clojure.text$fail$fn__670000013")

var Lit_10 *jrt.String = jrt.Intern(" (line ")

var Lit_11 *jrt.String = jrt.Intern(")")

var Lit_12 *jrt.String = jrt.Intern("EOF while reading")

var Lit_13 *jrt.String = jrt.Intern("EOF while reading a dispatch macro")

var Lit_14 *jrt.String = jrt.Intern("Namespaced map must specify a map")

var Lit_15 *jrt.String = jrt.Intern("\n")

var Lit_16 *jrt.String = jrt.Intern("#?")

var Lit_17 *jrt.String = jrt.Intern("arbace.repr.clojure.text$resolve_STAR_$copy__670000048")

var Lit_18 *jrt.String = jrt.Intern("arbace.repr.clojure.text$restore_conditionals$fn__670000059")

var Lit_19 *jrt.String = jrt.Intern("the reader conditional recorded at offset ")

var Lit_20 *jrt.String = jrt.Intern(" does not match the text (edited since read --full?)")

var Lit_21 *jrt.String = jrt.Intern("arbace.repr.clojure.text$selected$fn__670000038")

var Lit_22 *jrt.String = jrt.Intern("Reader conditional splicing not allowed at the top level.")

var Lit_23 *jrt.String = jrt.Intern("")

var Lit_24 *jrt.String = jrt.Intern("Spliced form list in read-conditional must implement java.util.List")

var Lit_25 *jrt.String = jrt.Intern("EOF while reading a string")

var Lit_26 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistskn3,tagyn6,Stringyn1,iyn3,msgkn4,linekn6,columnkn4,fileyn1,ckn8,declaredyn1,syn8,featuresyn5,depthyn6,depth0yn7,record?yn12,conditionalsyn4,predv11,arbace.core5,in-nsMyn24,arbace.repr.clojure.textm2,R0,s1158,Clojure source text, read lexically as the reader would, for repr/clojure's rules: they\n  rewrite text and keep everything else (layout, comments) as it is. The scanner knows the\n  reader's lexical syntax (doc/REPR-CLOJURE.md, \"How it reads\"): strings, regex literals,\n  character literals, comments (`;`, `#!`), discarded forms (`#_`), dispatch macros, tagged\n  literals, metadata, the quoting macros and tokens (symbols, keywords, numbers), which run\n  until whitespace or a terminating macro character, as LispReader's do. It does not build forms: it finds where\n  they begin and end.\n\n  - `form-end`: the end of the form beginning at an index;\n  - `resolve-conditionals`: reader conditionals (`#?`, `#?@`) replaced by their selected\n    branch's text, for a .cljc file becoming a .ae file (which the reader reads without\n    conditionals); `record-conditionals` and `restore-conditionals`, the same with a record of\n    what it drops and that record put back (read --full);\n  - `code-tokens`: the spans of the tokens outside strings, comments and character literals,\n    for rules that rewrite symbols; `list-spans`: the spans of the lists a token heads.m2,R0,s1158,Clojure source text, read lexically as the reader would, for repr/clojure's rules: they\n  rewrite text and keep everything else (layout, comments) as it is. The scanner knows the\n  reader's lexical syntax (doc/REPR-CLOJURE.md, \"How it reads\"): strings, regex literals,\n  character literals, comments (`;`, `#!`), discarded forms (`#_`), dispatch macros, tagged\n  literals, metadata, the quoting macros and tokens (symbols, keywords, numbers), which run\n  until whitespace or a terminating macro character, as LispReader's do. It does not build forms: it finds where\n  they begin and end.\n\n  - `form-end`: the end of the form beginning at an index;\n  - `resolve-conditionals`: reader conditionals (`#?`, `#?@`) replaced by their selected\n    branch's text, for a .cljc file becoming a .ae file (which the reader reads without\n    conditionals); `record-conditionals` and `restore-conditionals`, the same with a record of\n    what it drops and that record put back (read --full);\n  - `code-tokens`: the spans of the tokens outside strings, comments and character literals,\n    for rules that rewrite symbols; `list-spans`: the spans of the lists a token heads.R1,v24,arbace.repr.clojure.text4,failm10,R2,TR3,L1,V3,Myn1,sm2,R4,R5,R6,R7,R8,i19,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text3,ws?m10,R2,TR3,L1,V1,R11,R8,i23,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text12,terminating?m12,R2,TR3,L1,V1,R11,R0,s138,Whether c ends a token: whitespace or a terminating macro character of LispReader (`#`\n  and `'` are not: they may occur inside a symbol).R8,i25,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text2,atm10,R2,TR3,L1,V2,Myn1,sm2,R4,R5,R6,R8,i31,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text8,line-endm10,R2,TR3,L1,V2,Myn1,sm2,R4,R5,R6,R8,i33,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text9,token-endm10,R3,L1,V2,Myn1,sm2,R4,R5,R6,R0,s36,The end of the token beginning at i.R8,i36,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text10,string-endm12,R2,TR3,L1,V2,Myn1,sm2,R4,R5,R6,R0,s69,The end of the string (or regex) literal whose opening quote is at i.R8,i42,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text8,char-endm12,R2,TR3,L1,V2,Myn1,sm2,R4,R5,R6,R0,s133,The end of the character literal whose backslash is at i: the character after it, then a\n  token's characters (`\\newline`, `\\u0041`).R8,i52,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text8,form-endm8,R12,TR8,i59,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text9,cond-openm8,R12,TR8,i59,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text7,skip-wsm10,R3,L1,V2,Myn1,sm2,R4,R5,R6,R0,s120,The index of the next form at or after i: whitespace, commas, comments (`;`, `#!`) and\n  discarded forms (`#_`) skipped.R8,i61,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text6,closerm6,c40,c41,c91,c93,c123,c125,m8,R2,TR8,i76,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text8,coll-endm12,R2,TR3,L1,V2,Myn1,sm2,R4,R5,R6,R0,s58,The end of the collection whose opening delimiter is at i.R8,i78,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text13,next-form-endm10,R2,TR3,L1,V2,R13,R6,R8,i89,R9,i1,R10,s27,arbace/repr/clojure/text.aem10,R3,L1,V2,Myn1,sm2,R4,R5,R6,R0,s52,The end of the form beginning at i (not whitespace).R8,i94,R9,i1,R10,s27,arbace/repr/clojure/text.aem12,R2,TR3,L1,V2,Myn1,sm2,R4,R5,R6,R0,s117,The index of the list of the reader conditional at i (`#?` or `#?@`, then whitespace, as\n  ConditionalReader allows).R8,i127,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text8,branchesm12,R2,TR3,L1,V2,Myn1,sm2,R4,R5,R6,R0,s105,The branches of the reader conditional whose list opens at i: [feature value-start\n  value-end] for each.R8,i136,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text20,resolve-conditionalsm8,R12,TR8,i151,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text8,selectedm12,R2,TR3,L1,V4,Myn1,sm2,R4,R5,R6,R14,R15,R0,s260,The text a reader conditional at i reads as, for the platform features: the first branch\n  whose feature is one of them or :default (as LispReader chooses), with its own conditionals\n  resolved; spliced (`#?@`), the contents of its list or vector; none: empty.R8,i153,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text8,resolve*m12,R2,TR3,L1,V4,Myn1,sm2,R4,R5,R14,R16,R17,R0,s289,resolve-conditionals' work: [text records], records (when record? is true) the reader\n  conditionals of s at its own level, in order, each {:at :length :text}: where its reading\n  stands in the text made and how long it is, and its own text in s (nested conditionals in it\n  as they were).R8,i171,R9,i1,R10,s27,arbace/repr/clojure/text.aem10,R3,L3,V1,R13,V2,R13,R14,V3,Myn1,sm2,R4,R5,R14,R16,R0,s263,Source text s with each reader conditional replaced by the text it reads as on a platform\n  with the features (a set of keywords, Arbace's #{:clj}): its selected branch, verbatim\n  (spliced: the contents of its list), or nothing. Everything else is kept as it is.R8,i204,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text19,record-conditionalsm10,R3,L1,V2,Myn1,sm2,R4,R5,R14,R0,s338,resolve-conditionals with a record of what it dropped, for read --full (doc/REPR-CLOJURE.md,\n  \"Read --full\"): {:text the text resolved, :conditionals [{:at :length :text} ...]}, each of\n  s's reader conditionals in order: its reading's offset and length in :text, and its own text,\n  so that restore-conditionals gives s back from :text.R8,i212,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text20,restore-conditionalsm10,R3,L1,V3,Myn1,tm2,R4,R5,R18,R14,R0,s271,record-conditionals reversed: the text t (resolved) with each recorded conditional put back\n  in place of its reading. Each reading must still be what its conditional reads as (the\n  features'; a splice as within a collection), else it fails (t is not the text recorded).R8,i220,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text11,code-tokensm10,R3,L1,V1,Myn1,sm2,R4,R5,R0,s170,The [start end] spans of the tokens of s (symbols, keywords, numbers, the tags of tagged\n  literals) outside strings, regex and character literals and comments, in order.R8,i242,R9,i1,R10,s27,arbace/repr/clojure/text.aev24,arbace.repr.clojure.text10,list-spansm10,R3,L1,V2,Myn1,sm2,R4,R5,R19,R0,s72,The [start end] spans of the lists of s whose head token satisfies pred.R8,i263,R9,i1,R10,s27,arbace/repr/clojure/text.ae")

var Lit_27 *jrt.String = jrt.Intern("arbace.repr.clojure.text$eval670000004$loading__1927001464__auto____670000005")

var Lit_28 *jrt.String = jrt.Intern("arbace.repr.clojure.text$eval670000008$fn__670000009")

var Lit_29 *jrt.String = jrt.Intern("arbace.repr.clojure.text$fail")

var Lit_30 *jrt.String = jrt.Intern("arbace.repr.clojure.text$ws_QMARK_")

var Lit_31 *jrt.String = jrt.Intern("arbace.repr.clojure.text$terminating_QMARK_")

var Lit_32 *jrt.String = jrt.Intern("arbace.repr.clojure.text$at")

var Lit_33 *jrt.String = jrt.Intern("arbace.repr.clojure.text$line_end")

var Lit_34 *jrt.String = jrt.Intern("arbace.repr.clojure.text$token_end")

var Lit_35 *jrt.String = jrt.Intern("arbace.repr.clojure.text$string_end")

var Lit_36 *jrt.String = jrt.Intern("arbace.repr.clojure.text$char_end")

var Lit_37 *jrt.String = jrt.Intern("arbace.repr.clojure.text$skip_ws")

var Lit_38 *jrt.String = jrt.Intern("arbace.repr.clojure.text$coll_end")

var Lit_39 *jrt.String = jrt.Intern("arbace.repr.clojure.text$next_form_end")

var Lit_40 *jrt.String = jrt.Intern("arbace.repr.clojure.text$form_end")

var Lit_41 *jrt.String = jrt.Intern("arbace.repr.clojure.text$cond_open")

var Lit_42 *jrt.String = jrt.Intern("arbace.repr.clojure.text$branches")

var Lit_43 *jrt.String = jrt.Intern("arbace.repr.clojure.text$selected")

var Lit_44 *jrt.String = jrt.Intern("arbace.repr.clojure.text$resolve_STAR_")

var Lit_45 *jrt.String = jrt.Intern("arbace.repr.clojure.text$resolve_conditionals")

var Lit_46 *jrt.String = jrt.Intern("arbace.repr.clojure.text$record_conditionals")

var Lit_47 *jrt.String = jrt.Intern("arbace.repr.clojure.text$restore_conditionals")

var Lit_48 *jrt.String = jrt.Intern("arbace.repr.clojure.text$code_tokens")

var Lit_49 *jrt.String = jrt.Intern("arbace.repr.clojure.text$list_spans")
