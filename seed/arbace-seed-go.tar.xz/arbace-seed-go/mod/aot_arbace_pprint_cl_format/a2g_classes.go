//line a2g_classes.ae:1
package aot_arbace_pprint_cl_format

import "arbace/jrt"


func A_arbace_pprint_cl_format__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_pprint_cl_format__init_A_Load__O()}; return nil }

func A_arbace_pprint_cl_format__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_pprint_cl_format__init_A_New()}; return nil }

var A_arbace_pprint_cl_format__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_pprint_cl_format__init_A_invoke, New: A_arbace_pprint_cl_format__init_A_new}

var A_arbace_pprint_cl_format__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.pprint.cl_format__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_pprint_cl_format.A_arbace_pprint_cl_format__init_A", Source: "cl_format.ae"})

func init() { i := A_arbace_pprint_cl_format__init_A_class.Info(); i.IsInstance = A_arbace_pprint_cl_format__init_A_InstanceOf; i.Init = A_arbace_pprint_cl_format__init_A_Init; i.Table = A_arbace_pprint_cl_format__init_A_members }
