//line aot_arbace_pprint_cl_format__init.ae:1
package aot_arbace_pprint_cl_format

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_cl_format__init_A_Load__O() any { jrt.StartCheck(); A_arbace_pprint_cl_format__init_part0_A_Init__O(); A_arbace_pprint_cl_format__init_part1_A_Init__O(); A_arbace_pprint_cl_format__init_part0_A_Load__O(); A_arbace_pprint_cl_format__init_part1_A_Load__O(); return nil }












func A_arbace_pprint_cl_format__init_part0_A_Unit0__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); return lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_cl_format__init_part0_A_const_1) }
//line :18:1
func A_arbace_pprint_cl_format__init_part0_A_Init__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); return nil }
//line :18:1
func A_arbace_pprint_cl_format__init_part0_A_Load__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); A_arbace_pprint_cl_format__init_part0_A_Unit0__O(); A_arbace_pprint_cl_format__init_part0_A_Unit1__O(); A_arbace_pprint_cl_format__init_part0_A_Unit2__O(); A_arbace_pprint_cl_format__init_part0_A_Unit3__O(); A_arbace_pprint_cl_format__init_part0_A_Unit4__O(); A_arbace_pprint_cl_format__init_part0_A_Unit5__O(); A_arbace_pprint_cl_format__init_part0_A_Unit6__O(); A_arbace_pprint_cl_format__init_part0_A_Unit7__O(); A_arbace_pprint_cl_format__init_part0_A_Unit8__O(); A_arbace_pprint_cl_format__init_part0_A_Unit9__O(); A_arbace_pprint_cl_format__init_part0_A_Unit10__O(); A_arbace_pprint_cl_format__init_part0_A_Unit11__O(); A_arbace_pprint_cl_format__init_part0_A_Unit12__O(); A_arbace_pprint_cl_format__init_part0_A_Unit13__O(); A_arbace_pprint_cl_format__init_part0_A_Unit14__O(); A_arbace_pprint_cl_format__init_part0_A_Unit15__O(); A_arbace_pprint_cl_format__init_part0_A_Unit16__O(); A_arbace_pprint_cl_format__init_part0_A_Unit17__O(); A_arbace_pprint_cl_format__init_part0_A_Unit18__O(); A_arbace_pprint_cl_format__init_part0_A_Unit19__O(); A_arbace_pprint_cl_format__init_part0_A_Unit20__O(); A_arbace_pprint_cl_format__init_part0_A_Unit21__O(); A_arbace_pprint_cl_format__init_part0_A_Unit22__O(); A_arbace_pprint_cl_format__init_part0_A_Unit23__O(); A_arbace_pprint_cl_format__init_part0_A_Unit24__O(); A_arbace_pprint_cl_format__init_part0_A_Unit25__O(); A_arbace_pprint_cl_format__init_part0_A_Unit26__O(); A_arbace_pprint_cl_format__init_part0_A_Unit27__O(); A_arbace_pprint_cl_format__init_part0_A_Unit28__O(); A_arbace_pprint_cl_format__init_part0_A_Unit29__O(); A_arbace_pprint_cl_format__init_part0_A_Unit30__O(); A_arbace_pprint_cl_format__init_part0_A_Unit31__O(); A_arbace_pprint_cl_format__init_part0_A_Unit32__O(); A_arbace_pprint_cl_format__init_part0_A_Unit33__O(); A_arbace_pprint_cl_format__init_part0_A_Unit34__O(); A_arbace_pprint_cl_format__init_part0_A_Unit35__O(); A_arbace_pprint_cl_format__init_part0_A_Unit36__O(); A_arbace_pprint_cl_format__init_part0_A_Unit37__O(); A_arbace_pprint_cl_format__init_part0_A_Unit38__O(); A_arbace_pprint_cl_format__init_part0_A_Unit39__O(); A_arbace_pprint_cl_format__init_part0_A_Unit40__O(); A_arbace_pprint_cl_format__init_part0_A_Unit41__O(); A_arbace_pprint_cl_format__init_part0_A_Unit42__O(); A_arbace_pprint_cl_format__init_part0_A_Unit43__O(); A_arbace_pprint_cl_format__init_part0_A_Unit44__O(); A_arbace_pprint_cl_format__init_part0_A_Unit45__O(); A_arbace_pprint_cl_format__init_part0_A_Unit46__O(); A_arbace_pprint_cl_format__init_part0_A_Unit47__O(); A_arbace_pprint_cl_format__init_part0_A_Unit48__O(); A_arbace_pprint_cl_format__init_part0_A_Unit49__O(); A_arbace_pprint_cl_format__init_part0_A_Unit50__O(); A_arbace_pprint_cl_format__init_part0_A_Unit51__O(); A_arbace_pprint_cl_format__init_part0_A_Unit52__O(); A_arbace_pprint_cl_format__init_part0_A_Unit53__O(); A_arbace_pprint_cl_format__init_part0_A_Unit54__O(); A_arbace_pprint_cl_format__init_part0_A_Unit55__O(); A_arbace_pprint_cl_format__init_part0_A_Unit56__O(); A_arbace_pprint_cl_format__init_part0_A_Unit57__O(); A_arbace_pprint_cl_format__init_part0_A_Unit58__O(); A_arbace_pprint_cl_format__init_part0_A_Unit59__O(); A_arbace_pprint_cl_format__init_part0_A_Unit60__O(); A_arbace_pprint_cl_format__init_part0_A_Unit61__O(); A_arbace_pprint_cl_format__init_part0_A_Unit62__O(); A_arbace_pprint_cl_format__init_part0_A_Unit63__O(); A_arbace_pprint_cl_format__init_part0_A_Unit64__O(); A_arbace_pprint_cl_format__init_part0_A_Unit65__O(); A_arbace_pprint_cl_format__init_part0_A_Unit66__O(); A_arbace_pprint_cl_format__init_part0_A_Unit67__O(); A_arbace_pprint_cl_format__init_part0_A_Unit68__O(); A_arbace_pprint_cl_format__init_part0_A_Unit69__O(); A_arbace_pprint_cl_format__init_part0_A_Unit70__O(); A_arbace_pprint_cl_format__init_part0_A_Unit71__O(); A_arbace_pprint_cl_format__init_part0_A_Unit72__O(); A_arbace_pprint_cl_format__init_part0_A_Unit73__O(); A_arbace_pprint_cl_format__init_part0_A_Unit74__O(); A_arbace_pprint_cl_format__init_part0_A_Unit75__O(); A_arbace_pprint_cl_format__init_part0_A_Unit76__O(); A_arbace_pprint_cl_format__init_part0_A_Unit77__O(); A_arbace_pprint_cl_format__init_part0_A_Unit78__O(); A_arbace_pprint_cl_format__init_part0_A_Unit79__O(); A_arbace_pprint_cl_format__init_part0_A_Unit80__O(); A_arbace_pprint_cl_format__init_part0_A_Unit81__O(); A_arbace_pprint_cl_format__init_part0_A_Unit82__O(); A_arbace_pprint_cl_format__init_part0_A_Unit83__O(); A_arbace_pprint_cl_format__init_part0_A_Unit84__O(); A_arbace_pprint_cl_format__init_part0_A_Unit85__O(); A_arbace_pprint_cl_format__init_part0_A_Unit86__O(); A_arbace_pprint_cl_format__init_part0_A_Unit87__O(); A_arbace_pprint_cl_format__init_part0_A_Unit88__O(); A_arbace_pprint_cl_format__init_part0_A_Unit89__O(); A_arbace_pprint_cl_format__init_part0_A_Unit90__O(); A_arbace_pprint_cl_format__init_part0_A_Unit91__O(); A_arbace_pprint_cl_format__init_part0_A_Unit92__O(); A_arbace_pprint_cl_format__init_part0_A_Unit93__O(); A_arbace_pprint_cl_format__init_part0_A_Unit94__O(); A_arbace_pprint_cl_format__init_part0_A_Unit95__O(); A_arbace_pprint_cl_format__init_part0_A_Unit96__O(); A_arbace_pprint_cl_format__init_part0_A_Unit97__O(); A_arbace_pprint_cl_format__init_part0_A_Unit98__O(); A_arbace_pprint_cl_format__init_part0_A_Unit99__O(); return nil }


func A_arbace_pprint_cl_format__init_part0_A_Unit1__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_3)); return A_arbace_pprint_cl_format__init_part0_A_const_2 }
func A_arbace_pprint_cl_format__init_part0_A_Unit2__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_5)); return A_arbace_pprint_cl_format__init_part0_A_const_4 }
func A_arbace_pprint_cl_format__init_part0_A_Unit3__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(23, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_7)); return A_arbace_pprint_cl_format__init_part0_A_const_6 }


func A_arbace_pprint_cl_format__init_part0_A_Unit4__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_8; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__2 any = aot_arbace_pprint.A_arbace_pprint_cl_format_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_cl_format_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, true, nil); aot_arbace_pprint.A_arbace_pprint_cl_format_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__2, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_9)); return A_arbace_pprint_cl_format__init_part0_A_const_8 }






































func A_arbace_pprint_cl_format__init_part0_A_Unit5__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); A_arbace_pprint_cl_format__init_part0_A_const_10.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_11)); return A_arbace_pprint_cl_format__init_part0_A_const_10.SetDynamic_Z__Var(true).Ref() }

func A_arbace_pprint_cl_format__init_part0_A_Unit6__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = aot_arbace_pprint.A_arbace_pprint_format_error_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_error_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); aot_arbace_pprint.A_arbace_pprint_format_error_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_13)); return A_arbace_pprint_cl_format__init_part0_A_const_12 }










func A_arbace_pprint_cl_format__init_part0_A_Unit7__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(78, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_14; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_15.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_16, A_arbace_pprint_cl_format__init_part0_A_const_17, A_arbace_pprint_cl_format__init_part0_A_const_18)); var tmp2 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_14; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_19)); return A_arbace_pprint_cl_format__init_part0_A_const_14 }


func A_arbace_pprint_cl_format__init_part0_A_Unit8__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(81, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = aot_arbace_pprint.A_arbace_pprint_init_navigator_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_init_navigator_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); aot_arbace_pprint.A_arbace_pprint_init_navigator_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_20)); return A_arbace_pprint_cl_format__init_part0_A_const_6 }







func A_arbace_pprint_cl_format__init_part0_A_Unit9__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = aot_arbace_pprint.A_arbace_pprint_next_arg_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_next_arg_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); aot_arbace_pprint.A_arbace_pprint_next_arg_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_22)); return A_arbace_pprint_cl_format__init_part0_A_const_21 }





func A_arbace_pprint_cl_format__init_part0_A_Unit10__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = aot_arbace_pprint.A_arbace_pprint_next_arg_or_nil_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_next_arg_or_nil_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); aot_arbace_pprint.A_arbace_pprint_next_arg_or_nil_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_24)); return A_arbace_pprint_cl_format__init_part0_A_const_23 }






func A_arbace_pprint_cl_format__init_part0_A_Unit11__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(102, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = aot_arbace_pprint.A_arbace_pprint_get_format_arg_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_format_arg_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, nil); aot_arbace_pprint.A_arbace_pprint_get_format_arg_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_26)); return A_arbace_pprint_cl_format__init_part0_A_const_25 }






func A_arbace_pprint_cl_format__init_part0_A_Unit12__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_27; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_28)); return A_arbace_pprint_cl_format__init_part0_A_const_27 }

func A_arbace_pprint_cl_format__init_part0_A_Unit13__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(111, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = aot_arbace_pprint.A_arbace_pprint_absolute_reposition_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_absolute_reposition_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, nil); aot_arbace_pprint.A_arbace_pprint_absolute_reposition_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_30)); return A_arbace_pprint_cl_format__init_part0_A_const_29 }




func A_arbace_pprint_cl_format__init_part0_A_Unit14__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(116, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = aot_arbace_pprint.A_arbace_pprint_relative_reposition_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_relative_reposition_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, nil); aot_arbace_pprint.A_arbace_pprint_relative_reposition_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_31)); return A_arbace_pprint_cl_format__init_part0_A_const_27 }





func A_arbace_pprint_cl_format__init_part0_A_Unit15__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(122, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_32; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_15.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_33, A_arbace_pprint_cl_format__init_part0_A_const_34, A_arbace_pprint_cl_format__init_part0_A_const_35, A_arbace_pprint_cl_format__init_part0_A_const_36)); var tmp2 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_32; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_37)); return A_arbace_pprint_cl_format__init_part0_A_const_32 }










func A_arbace_pprint_cl_format__init_part0_A_Unit16__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(133, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__31 any = aot_arbace_pprint.A_arbace_pprint_realize_parameter_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_realize_parameter_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); aot_arbace_pprint.A_arbace_pprint_realize_parameter_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__31, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_39)); return A_arbace_pprint_cl_format__init_part0_A_const_38 }















func A_arbace_pprint_cl_format__init_part0_A_Unit17__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__33 any = aot_arbace_pprint.A_arbace_pprint_realize_parameter_list_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_realize_parameter_list_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, nil); aot_arbace_pprint.A_arbace_pprint_realize_parameter_list_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__33, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_41)); return A_arbace_pprint_cl_format__init_part0_A_const_40 }












func A_arbace_pprint_cl_format__init_part0_A_Unit18__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(162, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_42; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_43)); return A_arbace_pprint_cl_format__init_part0_A_const_42 }

func A_arbace_pprint_cl_format__init_part0_A_Unit19__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); A_arbace_pprint_cl_format__init_part0_A_const_44.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_45); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_44; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_46)); return A_arbace_pprint_cl_format__init_part0_A_const_44 }


func A_arbace_pprint_cl_format__init_part0_A_Unit20__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__35 any = aot_arbace_pprint.A_arbace_pprint_format_simple_number_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_simple_number_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, nil); aot_arbace_pprint.A_arbace_pprint_format_simple_number_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__35, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_48)); return A_arbace_pprint_cl_format__init_part0_A_const_47 }













func A_arbace_pprint_cl_format__init_part0_A_Unit21__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(181, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__37 any = aot_arbace_pprint.A_arbace_pprint_format_ascii_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_ascii_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, nil); aot_arbace_pprint.A_arbace_pprint_format_ascii_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__37, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_50)); return A_arbace_pprint_cl_format__init_part0_A_const_49 }






















func A_arbace_pprint_cl_format__init_part0_A_Unit22__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(204, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__39 any = aot_arbace_pprint.A_arbace_pprint_integral_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_integral_QMARK__A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); aot_arbace_pprint.A_arbace_pprint_integral_QMARK__A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__39, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_52)); return A_arbace_pprint_cl_format__init_part0_A_const_51 }










func A_arbace_pprint_cl_format__init_part0_A_Unit23__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(215, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__41 any = aot_arbace_pprint.A_arbace_pprint_remainders_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_remainders_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, nil); aot_arbace_pprint.A_arbace_pprint_remainders_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__41, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_54)); return A_arbace_pprint_cl_format__init_part0_A_const_53 }










func A_arbace_pprint_cl_format__init_part0_A_Unit24__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(226, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__43 any = aot_arbace_pprint.A_arbace_pprint_base_str_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_base_str_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, nil); aot_arbace_pprint.A_arbace_pprint_base_str_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__43, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_56)); return A_arbace_pprint_cl_format__init_part0_A_const_55 }














func A_arbace_pprint_cl_format__init_part0_A_Unit25__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(241, 1); A_arbace_pprint_cl_format__init_part0_A_const_57.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_58); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_57; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_59)); return A_arbace_pprint_cl_format__init_part0_A_const_57 }


func A_arbace_pprint_cl_format__init_part0_A_Unit26__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(244, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__45 any = aot_arbace_pprint.A_arbace_pprint_opt_base_str_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_opt_base_str_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, nil); aot_arbace_pprint.A_arbace_pprint_opt_base_str_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__45, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_60)); return A_arbace_pprint_cl_format__init_part0_A_const_42 }








func A_arbace_pprint_cl_format__init_part0_A_Unit27__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(253, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__47 any = aot_arbace_pprint.A_arbace_pprint_group_by_STAR__A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_group_by_STAR__A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); aot_arbace_pprint.A_arbace_pprint_group_by_STAR__A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__47, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_62)); return A_arbace_pprint_cl_format__init_part0_A_const_61 }




func A_arbace_pprint_cl_format__init_part0_A_Unit28__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(258, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__49 any = aot_arbace_pprint.A_arbace_pprint_format_integer_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_integer_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, nil); aot_arbace_pprint.A_arbace_pprint_format_integer_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__49, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_64)); return A_arbace_pprint_cl_format__init_part0_A_const_63 }





























func A_arbace_pprint_cl_format__init_part0_A_Unit29__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); A_arbace_pprint_cl_format__init_part0_A_const_65.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_66); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_65; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_67)); return A_arbace_pprint_cl_format__init_part0_A_const_65 }





func A_arbace_pprint_cl_format__init_part0_A_Unit30__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(294, 1); A_arbace_pprint_cl_format__init_part0_A_const_68.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_69); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_68; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_70)); return A_arbace_pprint_cl_format__init_part0_A_const_68 }





func A_arbace_pprint_cl_format__init_part0_A_Unit31__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(300, 1); A_arbace_pprint_cl_format__init_part0_A_const_71.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_72); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_71; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_73)); return A_arbace_pprint_cl_format__init_part0_A_const_71 }



func A_arbace_pprint_cl_format__init_part0_A_Unit32__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(304, 1); A_arbace_pprint_cl_format__init_part0_A_const_74.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_75); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_74; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_76)); return A_arbace_pprint_cl_format__init_part0_A_const_74 }








func A_arbace_pprint_cl_format__init_part0_A_Unit33__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(313, 1); A_arbace_pprint_cl_format__init_part0_A_const_77.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_78); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_77; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_79)); return A_arbace_pprint_cl_format__init_part0_A_const_77 }







func A_arbace_pprint_cl_format__init_part0_A_Unit34__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(321, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__51 any = aot_arbace_pprint.A_arbace_pprint_format_simple_cardinal_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_simple_cardinal_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); aot_arbace_pprint.A_arbace_pprint_format_simple_cardinal_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__51, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_81)); return A_arbace_pprint_cl_format__init_part0_A_const_80 }

















func A_arbace_pprint_cl_format__init_part0_A_Unit35__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(339, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__53 any = aot_arbace_pprint.A_arbace_pprint_add_english_scales_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_add_english_scales_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); aot_arbace_pprint.A_arbace_pprint_add_english_scales_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__53, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_83)); return A_arbace_pprint_cl_format__init_part0_A_const_82 }






















func A_arbace_pprint_cl_format__init_part0_A_Unit36__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(362, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__55 any = aot_arbace_pprint.A_arbace_pprint_format_cardinal_english_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_cardinal_english_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, nil); aot_arbace_pprint.A_arbace_pprint_format_cardinal_english_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__55, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_85)); return A_arbace_pprint_cl_format__init_part0_A_const_84 }
















func A_arbace_pprint_cl_format__init_part0_A_Unit37__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(379, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__57 any = aot_arbace_pprint.A_arbace_pprint_format_simple_ordinal_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_simple_ordinal_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, nil); aot_arbace_pprint.A_arbace_pprint_format_simple_ordinal_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__57, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_87)); return A_arbace_pprint_cl_format__init_part0_A_const_86 }





















func A_arbace_pprint_cl_format__init_part0_A_Unit38__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(401, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_88; var tmp2 *lang.Compiler_AOTFn; var fnbody__59 any = aot_arbace_pprint.A_arbace_pprint_format_ordinal_english_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_ordinal_english_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); aot_arbace_pprint.A_arbace_pprint_format_ordinal_english_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__59, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_89)); return A_arbace_pprint_cl_format__init_part0_A_const_88 }



































func A_arbace_pprint_cl_format__init_part0_A_Unit39__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(437, 1); A_arbace_pprint_cl_format__init_part0_A_const_90.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_91); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_92)); return A_arbace_pprint_cl_format__init_part0_A_const_90 }






func A_arbace_pprint_cl_format__init_part0_A_Unit40__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(444, 1); A_arbace_pprint_cl_format__init_part0_A_const_93.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_94); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_93; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_95)); return A_arbace_pprint_cl_format__init_part0_A_const_93 }






func A_arbace_pprint_cl_format__init_part0_A_Unit41__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(451, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_96; var tmp2 *lang.Compiler_AOTFn; var fnbody__61 any = aot_arbace_pprint.A_arbace_pprint_format_roman_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_roman_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); aot_arbace_pprint.A_arbace_pprint_format_roman_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__61, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_97)); return A_arbace_pprint_cl_format__init_part0_A_const_96 }























func A_arbace_pprint_cl_format__init_part0_A_Unit42__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(475, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__63 any = aot_arbace_pprint.A_arbace_pprint_format_old_roman_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_old_roman_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); aot_arbace_pprint.A_arbace_pprint_format_old_roman_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__63, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_99)); return A_arbace_pprint_cl_format__init_part0_A_const_98 }


func A_arbace_pprint_cl_format__init_part0_A_Unit43__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(478, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_100; var tmp2 *lang.Compiler_AOTFn; var fnbody__65 any = aot_arbace_pprint.A_arbace_pprint_format_new_roman_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_new_roman_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, nil); aot_arbace_pprint.A_arbace_pprint_format_new_roman_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__65, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_101)); return A_arbace_pprint_cl_format__init_part0_A_const_100 }






func A_arbace_pprint_cl_format__init_part0_A_Unit44__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(485, 1); A_arbace_pprint_cl_format__init_part0_A_const_102.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_103); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_102; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_104)); return A_arbace_pprint_cl_format__init_part0_A_const_102 }


func A_arbace_pprint_cl_format__init_part0_A_Unit45__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(488, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__67 any = aot_arbace_pprint.A_arbace_pprint_pretty_character_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pretty_character_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); aot_arbace_pprint.A_arbace_pprint_pretty_character_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__67, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_106)); return A_arbace_pprint_cl_format__init_part0_A_const_105 }













func A_arbace_pprint_cl_format__init_part0_A_Unit46__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(502, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__69 any = aot_arbace_pprint.A_arbace_pprint_readable_character_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_readable_character_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, nil); aot_arbace_pprint.A_arbace_pprint_readable_character_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__69, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_108)); return A_arbace_pprint_cl_format__init_part0_A_const_107 }







func A_arbace_pprint_cl_format__init_part0_A_Unit47__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(510, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_109; var tmp2 *lang.Compiler_AOTFn; var fnbody__71 any = aot_arbace_pprint.A_arbace_pprint_plain_character_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_plain_character_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); aot_arbace_pprint.A_arbace_pprint_plain_character_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__71, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_110)); return A_arbace_pprint_cl_format__init_part0_A_const_109 }






func A_arbace_pprint_cl_format__init_part0_A_Unit48__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(517, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__73 any = aot_arbace_pprint.A_arbace_pprint_abort_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_abort_QMARK__A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); aot_arbace_pprint.A_arbace_pprint_abort_QMARK__A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__73, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_112)); return A_arbace_pprint_cl_format__init_part0_A_const_111 }




func A_arbace_pprint_cl_format__init_part0_A_Unit49__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(522, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__75 any = aot_arbace_pprint.A_arbace_pprint_execute_sub_format_A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_execute_sub_format_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, nil); aot_arbace_pprint.A_arbace_pprint_execute_sub_format_A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__75, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_114)); return A_arbace_pprint_cl_format__init_part0_A_const_113 }

















func A_arbace_pprint_cl_format__init_part0_A_Unit50__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(540, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_115; var tmp2 *lang.Compiler_AOTFn; var fnbody__77 any = aot_arbace_pprint.A_arbace_pprint_float_parts_base_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_float_parts_base_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); aot_arbace_pprint.A_arbace_pprint_float_parts_base_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__77, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_116)); return A_arbace_pprint_cl_format__init_part0_A_const_115 }













func A_arbace_pprint_cl_format__init_part0_A_Unit51__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(554, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_117; var tmp2 *lang.Compiler_AOTFn; var fnbody__79 any = aot_arbace_pprint.A_arbace_pprint_float_parts_A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_float_parts_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); aot_arbace_pprint.A_arbace_pprint_float_parts_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__79, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_118)); return A_arbace_pprint_cl_format__init_part0_A_const_117 }











func A_arbace_pprint_cl_format__init_part0_A_Unit52__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(566, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_119; var tmp2 *lang.Compiler_AOTFn; var fnbody__81 any = aot_arbace_pprint.A_arbace_pprint_inc_s_A_New(); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_inc_s_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); aot_arbace_pprint.A_arbace_pprint_inc_s_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__81, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_120)); return A_arbace_pprint_cl_format__init_part0_A_const_119 }















func A_arbace_pprint_cl_format__init_part0_A_Unit53__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(582, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__83 any = aot_arbace_pprint.A_arbace_pprint_round_str_A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_round_str_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); aot_arbace_pprint.A_arbace_pprint_round_str_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__83, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_122)); return A_arbace_pprint_cl_format__init_part0_A_const_121 }









































func A_arbace_pprint_cl_format__init_part0_A_Unit54__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(624, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__85 any = aot_arbace_pprint.A_arbace_pprint_expand_fixed_A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_expand_fixed_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, nil); aot_arbace_pprint.A_arbace_pprint_expand_fixed_A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__85, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_124)); return A_arbace_pprint_cl_format__init_part0_A_const_123 }









func A_arbace_pprint_cl_format__init_part0_A_Unit55__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(634, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__87 any = aot_arbace_pprint.A_arbace_pprint_insert_decimal_A_New(); var tmp3 *jrt.Class; var fncls__86 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_insert_decimal_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, nil); aot_arbace_pprint.A_arbace_pprint_insert_decimal_A_fn_class = fncls__86d; tmp3 = fncls__86d } else { tmp3 = fncls__86 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__87, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_126)); return A_arbace_pprint_cl_format__init_part0_A_const_125 }







func A_arbace_pprint_cl_format__init_part0_A_Unit56__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(642, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__89 any = aot_arbace_pprint.A_arbace_pprint_get_fixed_A_New(); var tmp3 *jrt.Class; var fncls__88 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_fixed_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); aot_arbace_pprint.A_arbace_pprint_get_fixed_A_fn_class = fncls__88d; tmp3 = fncls__88d } else { tmp3 = fncls__88 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__89, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_128)); return A_arbace_pprint_cl_format__init_part0_A_const_127 }


func A_arbace_pprint_cl_format__init_part0_A_Unit57__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(645, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__91 any = aot_arbace_pprint.A_arbace_pprint_insert_scaled_decimal_A_New(); var tmp3 *jrt.Class; var fncls__90 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_insert_scaled_decimal_A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); aot_arbace_pprint.A_arbace_pprint_insert_scaled_decimal_A_fn_class = fncls__90d; tmp3 = fncls__90d } else { tmp3 = fncls__90 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__91, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_130)); return A_arbace_pprint_cl_format__init_part0_A_const_129 }






func A_arbace_pprint_cl_format__init_part0_A_Unit58__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(652, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__93 any = aot_arbace_pprint.A_arbace_pprint_convert_ratio_A_New(); var tmp3 *jrt.Class; var fncls__92 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_convert_ratio_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); aot_arbace_pprint.A_arbace_pprint_convert_ratio_A_fn_class = fncls__92d; tmp3 = fncls__92d } else { tmp3 = fncls__92 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__93, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_132)); return A_arbace_pprint_cl_format__init_part0_A_const_131 }
















func A_arbace_pprint_cl_format__init_part0_A_Unit59__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(669, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__95 any = aot_arbace_pprint.A_arbace_pprint_fixed_float_A_New(); var tmp3 *jrt.Class; var fncls__94 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fixed_float_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, nil); aot_arbace_pprint.A_arbace_pprint_fixed_float_A_fn_class = fncls__94d; tmp3 = fncls__94d } else { tmp3 = fncls__94 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__95, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_134)); return A_arbace_pprint_cl_format__init_part0_A_const_133 }














































func A_arbace_pprint_cl_format__init_part0_A_Unit60__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(716, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__97 any = aot_arbace_pprint.A_arbace_pprint_exponential_float_A_New(); var tmp3 *jrt.Class; var fncls__96 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_exponential_float_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, nil); aot_arbace_pprint.A_arbace_pprint_exponential_float_A_fn_class = fncls__96d; tmp3 = fncls__96d } else { tmp3 = fncls__96 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__97, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_136)); return A_arbace_pprint_cl_format__init_part0_A_const_135 }









































































func A_arbace_pprint_cl_format__init_part0_A_Unit61__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(790, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_137; var tmp2 *lang.Compiler_AOTFn; var fnbody__99 any = aot_arbace_pprint.A_arbace_pprint_general_float_A_New(); var tmp3 *jrt.Class; var fncls__98 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_general_float_A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); aot_arbace_pprint.A_arbace_pprint_general_float_A_fn_class = fncls__98d; tmp3 = fncls__98d } else { tmp3 = fncls__98 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__99, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_138)); return A_arbace_pprint_cl_format__init_part0_A_const_137 }






















func A_arbace_pprint_cl_format__init_part0_A_Unit62__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(813, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_139; var tmp2 *lang.Compiler_AOTFn; var fnbody__101 any = aot_arbace_pprint.A_arbace_pprint_dollar_float_A_New(); var tmp3 *jrt.Class; var fncls__100 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_dollar_float_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); aot_arbace_pprint.A_arbace_pprint_dollar_float_A_fn_class = fncls__100d; tmp3 = fncls__100d } else { tmp3 = fncls__100 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__101, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_140)); return A_arbace_pprint_cl_format__init_part0_A_const_139 }

























func A_arbace_pprint_cl_format__init_part0_A_Unit63__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(839, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_141; var tmp2 *lang.Compiler_AOTFn; var fnbody__103 any = aot_arbace_pprint.A_arbace_pprint_choice_conditional_A_New(); var tmp3 *jrt.Class; var fncls__102 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_choice_conditional_A_fn_class; if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, nil); aot_arbace_pprint.A_arbace_pprint_choice_conditional_A_fn_class = fncls__102d; tmp3 = fncls__102d } else { tmp3 = fncls__102 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__103, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_142)); return A_arbace_pprint_cl_format__init_part0_A_const_141 }











func A_arbace_pprint_cl_format__init_part0_A_Unit64__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(851, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_143; var tmp2 *lang.Compiler_AOTFn; var fnbody__105 any = aot_arbace_pprint.A_arbace_pprint_boolean_conditional_A_New(); var tmp3 *jrt.Class; var fncls__104 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_boolean_conditional_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, nil); aot_arbace_pprint.A_arbace_pprint_boolean_conditional_A_fn_class = fncls__104d; tmp3 = fncls__104d } else { tmp3 = fncls__104 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__105, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_144)); return A_arbace_pprint_cl_format__init_part0_A_const_143 }











func A_arbace_pprint_cl_format__init_part0_A_Unit65__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(863, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_145; var tmp2 *lang.Compiler_AOTFn; var fnbody__107 any = aot_arbace_pprint.A_arbace_pprint_check_arg_conditional_A_New(); var tmp3 *jrt.Class; var fncls__106 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_check_arg_conditional_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, nil); aot_arbace_pprint.A_arbace_pprint_check_arg_conditional_A_fn_class = fncls__106d; tmp3 = fncls__106d } else { tmp3 = fncls__106 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__107, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_146)); return A_arbace_pprint_cl_format__init_part0_A_const_145 }
















func A_arbace_pprint_cl_format__init_part0_A_Unit66__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(880, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_147; var tmp2 *lang.Compiler_AOTFn; var fnbody__109 any = aot_arbace_pprint.A_arbace_pprint_iterate_sublist_A_New(); var tmp3 *jrt.Class; var fncls__108 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_iterate_sublist_A_fn_class; if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); aot_arbace_pprint.A_arbace_pprint_iterate_sublist_A_fn_class = fncls__108d; tmp3 = fncls__108d } else { tmp3 = fncls__108 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__109, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_148)); return A_arbace_pprint_cl_format__init_part0_A_const_147 }
























func A_arbace_pprint_cl_format__init_part0_A_Unit67__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(905, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_149; var tmp2 *lang.Compiler_AOTFn; var fnbody__111 any = aot_arbace_pprint.A_arbace_pprint_iterate_list_of_sublists_A_New(); var tmp3 *jrt.Class; var fncls__110 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_iterate_list_of_sublists_A_fn_class; if fncls__110 == nil { var fncls__110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, nil); aot_arbace_pprint.A_arbace_pprint_iterate_list_of_sublists_A_fn_class = fncls__110d; tmp3 = fncls__110d } else { tmp3 = fncls__110 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__111, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_150)); return A_arbace_pprint_cl_format__init_part0_A_const_149 }






















func A_arbace_pprint_cl_format__init_part0_A_Unit68__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(928, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_151; var tmp2 *lang.Compiler_AOTFn; var fnbody__113 any = aot_arbace_pprint.A_arbace_pprint_iterate_main_list_A_New(); var tmp3 *jrt.Class; var fncls__112 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_iterate_main_list_A_fn_class; if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, nil); aot_arbace_pprint.A_arbace_pprint_iterate_main_list_A_fn_class = fncls__112d; tmp3 = fncls__112d } else { tmp3 = fncls__112 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__113, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_151; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_152)); return A_arbace_pprint_cl_format__init_part0_A_const_151 }























func A_arbace_pprint_cl_format__init_part0_A_Unit69__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(952, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_153; var tmp2 *lang.Compiler_AOTFn; var fnbody__115 any = aot_arbace_pprint.A_arbace_pprint_iterate_main_sublists_A_New(); var tmp3 *jrt.Class; var fncls__114 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_iterate_main_sublists_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, nil); aot_arbace_pprint.A_arbace_pprint_iterate_main_sublists_A_fn_class = fncls__114d; tmp3 = fncls__114d } else { tmp3 = fncls__114 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__115, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_153; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_154)); return A_arbace_pprint_cl_format__init_part0_A_const_153 }































func A_arbace_pprint_cl_format__init_part0_A_Unit70__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(984, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_155; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_156)); return A_arbace_pprint_cl_format__init_part0_A_const_155 }
func A_arbace_pprint_cl_format__init_part0_A_Unit71__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(985, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_157; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_158)); return A_arbace_pprint_cl_format__init_part0_A_const_157 }

func A_arbace_pprint_cl_format__init_part0_A_Unit72__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(987, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_159; var tmp2 *lang.Compiler_AOTFn; var fnbody__117 any = aot_arbace_pprint.A_arbace_pprint_logical_block_or_justify_A_New(); var tmp3 *jrt.Class; var fncls__116 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_logical_block_or_justify_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, nil); aot_arbace_pprint.A_arbace_pprint_logical_block_or_justify_A_fn_class = fncls__116d; tmp3 = fncls__116d } else { tmp3 = fncls__116 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__117, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_160)); return A_arbace_pprint_cl_format__init_part0_A_const_159 }








func A_arbace_pprint_cl_format__init_part0_A_Unit73__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(996, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_161; var tmp2 *lang.Compiler_AOTFn; var fnbody__119 any = aot_arbace_pprint.A_arbace_pprint_render_clauses_A_New(); var tmp3 *jrt.Class; var fncls__118 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_render_clauses_A_fn_class; if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, nil); aot_arbace_pprint.A_arbace_pprint_render_clauses_A_fn_class = fncls__118d; tmp3 = fncls__118d } else { tmp3 = fncls__118 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__119, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_162)); return A_arbace_pprint_cl_format__init_part0_A_const_161 }














func A_arbace_pprint_cl_format__init_part0_A_Unit74__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1011, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_157; var tmp2 *lang.Compiler_AOTFn; var fnbody__121 any = aot_arbace_pprint.A_arbace_pprint_justify_clauses_A_New(); var tmp3 *jrt.Class; var fncls__120 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_justify_clauses_A_fn_class; if fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); aot_arbace_pprint.A_arbace_pprint_justify_clauses_A_fn_class = fncls__120d; tmp3 = fncls__120d } else { tmp3 = fncls__120 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__121, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_157; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_163)); return A_arbace_pprint_cl_format__init_part0_A_const_157 }






















































func A_arbace_pprint_cl_format__init_part0_A_Unit75__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1066, 1); var tmp1 any = A_arbace_pprint_cl_format__init_part0_A_const_167; lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_166.GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq_NoInit(tmp1, lang.RT_Seq_O__ISeq_NoInit(jrt.RefArrayOf(jrt.Object_class)))); var tmp2 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_164; var tmp3 *lang.Compiler_AOTFn; var fnbody__123 any = aot_arbace_pprint.A_arbace_pprint_downcase_writer_A_New(); var tmp4 *jrt.Class; var fncls__122 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_downcase_writer_A_fn_class; if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, nil); aot_arbace_pprint.A_arbace_pprint_downcase_writer_A_fn_class = fncls__122d; tmp4 = fncls__122d } else { tmp4 = fncls__122 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__123, tmp4, nil); tmp2.BindRoot_O__V(tmp3.Ref()); var tmp5 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_164; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_165)); return A_arbace_pprint_cl_format__init_part0_A_const_164 }

















func A_arbace_pprint_cl_format__init_part0_A_Unit76__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1084, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_168; var tmp2 *lang.Compiler_AOTFn; var fnbody__125 any = aot_arbace_pprint.A_arbace_pprint_upcase_writer_A_New(); var tmp3 *jrt.Class; var fncls__124 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_upcase_writer_A_fn_class; if fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, nil); aot_arbace_pprint.A_arbace_pprint_upcase_writer_A_fn_class = fncls__124d; tmp3 = fncls__124d } else { tmp3 = fncls__124 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__125, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_168; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_169)); return A_arbace_pprint_cl_format__init_part0_A_const_168 }

















func A_arbace_pprint_cl_format__init_part0_A_Unit77__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1102, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_170; var tmp2 *lang.Compiler_AOTFn; var fnbody__127 any = aot_arbace_pprint.A_arbace_pprint_capitalize_string_A_New(); var tmp3 *jrt.Class; var fncls__126 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_capitalize_string_A_fn_class; if fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, nil); aot_arbace_pprint.A_arbace_pprint_capitalize_string_A_fn_class = fncls__126d; tmp3 = fncls__126d } else { tmp3 = fncls__126 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__127, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_170; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_171)); return A_arbace_pprint_cl_format__init_part0_A_const_170 }























func A_arbace_pprint_cl_format__init_part0_A_Unit78__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1126, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_172; var tmp2 *lang.Compiler_AOTFn; var fnbody__129 any = aot_arbace_pprint.A_arbace_pprint_capitalize_word_writer_A_New(); var tmp3 *jrt.Class; var fncls__128 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_capitalize_word_writer_A_fn_class; if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, nil); aot_arbace_pprint.A_arbace_pprint_capitalize_word_writer_A_fn_class = fncls__128d; tmp3 = fncls__128d } else { tmp3 = fncls__128 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__129, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_172; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_173)); return A_arbace_pprint_cl_format__init_part0_A_const_172 }



























func A_arbace_pprint_cl_format__init_part0_A_Unit79__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1154, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_174; var tmp2 *lang.Compiler_AOTFn; var fnbody__131 any = aot_arbace_pprint.A_arbace_pprint_init_cap_writer_A_New(); var tmp3 *jrt.Class; var fncls__130 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_init_cap_writer_A_fn_class; if fncls__130 == nil { var fncls__130d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, nil); aot_arbace_pprint.A_arbace_pprint_init_cap_writer_A_fn_class = fncls__130d; tmp3 = fncls__130d } else { tmp3 = fncls__130 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__131, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_174; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_175)); return A_arbace_pprint_cl_format__init_part0_A_const_174 }

































func A_arbace_pprint_cl_format__init_part0_A_Unit80__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1188, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_176; var tmp2 *lang.Compiler_AOTFn; var fnbody__133 any = aot_arbace_pprint.A_arbace_pprint_modify_case_A_New(); var tmp3 *jrt.Class; var fncls__132 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_modify_case_A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, nil); aot_arbace_pprint.A_arbace_pprint_modify_case_A_fn_class = fncls__132d; tmp3 = fncls__132d } else { tmp3 = fncls__132 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__133, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_176; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_177)); return A_arbace_pprint_cl_format__init_part0_A_const_176 }








func A_arbace_pprint_cl_format__init_part0_A_Unit81__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1197, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_178; var tmp2 *lang.Compiler_AOTFn; var fnbody__135 any = aot_arbace_pprint.A_arbace_pprint_get_pretty_writer_A_New(); var tmp3 *jrt.Class; var fncls__134 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_pretty_writer_A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, nil); aot_arbace_pprint.A_arbace_pprint_get_pretty_writer_A_fn_class = fncls__134d; tmp3 = fncls__134d } else { tmp3 = fncls__134 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__135, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_178; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_179)); return A_arbace_pprint_cl_format__init_part0_A_const_178 }









































func A_arbace_pprint_cl_format__init_part0_A_Unit82__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1239, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_180; var tmp2 *lang.Compiler_AOTFn; var fnbody__137 any = aot_arbace_pprint.A_arbace_pprint_fresh_line_A_New(); var tmp3 *jrt.Class; var fncls__136 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fresh_line_A_fn_class; if fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, nil); aot_arbace_pprint.A_arbace_pprint_fresh_line_A_fn_class = fncls__136d; tmp3 = fncls__136d } else { tmp3 = fncls__136 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__137, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_180; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_181)); return A_arbace_pprint_cl_format__init_part0_A_const_180 }









func A_arbace_pprint_cl_format__init_part0_A_Unit83__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1249, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_182; var tmp2 *lang.Compiler_AOTFn; var fnbody__139 any = aot_arbace_pprint.A_arbace_pprint_absolute_tabulation_A_New(); var tmp3 *jrt.Class; var fncls__138 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_absolute_tabulation_A_fn_class; if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, nil); aot_arbace_pprint.A_arbace_pprint_absolute_tabulation_A_fn_class = fncls__138d; tmp3 = fncls__138d } else { tmp3 = fncls__138 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__139, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_182; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_183)); return A_arbace_pprint_cl_format__init_part0_A_const_182 }










func A_arbace_pprint_cl_format__init_part0_A_Unit84__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1260, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_184; var tmp2 *lang.Compiler_AOTFn; var fnbody__141 any = aot_arbace_pprint.A_arbace_pprint_relative_tabulation_A_New(); var tmp3 *jrt.Class; var fncls__140 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_relative_tabulation_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, nil); aot_arbace_pprint.A_arbace_pprint_relative_tabulation_A_fn_class = fncls__140d; tmp3 = fncls__140d } else { tmp3 = fncls__140 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__141, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_184; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_185)); return A_arbace_pprint_cl_format__init_part0_A_const_184 }














func A_arbace_pprint_cl_format__init_part0_A_Unit85__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1275, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_155; var tmp2 *lang.Compiler_AOTFn; var fnbody__143 any = aot_arbace_pprint.A_arbace_pprint_format_logical_block_A_New(); var tmp3 *jrt.Class; var fncls__142 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_logical_block_A_fn_class; if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, nil); aot_arbace_pprint.A_arbace_pprint_format_logical_block_A_fn_class = fncls__142d; tmp3 = fncls__142d } else { tmp3 = fncls__142 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__143, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_155; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_186)); return A_arbace_pprint_cl_format__init_part0_A_const_155 }

















func A_arbace_pprint_cl_format__init_part0_A_Unit86__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1293, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_187; var tmp2 *lang.Compiler_AOTFn; var fnbody__145 any = aot_arbace_pprint.A_arbace_pprint_set_indent_A_New(); var tmp3 *jrt.Class; var fncls__144 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_set_indent_A_fn_class; if fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, nil); aot_arbace_pprint.A_arbace_pprint_set_indent_A_fn_class = fncls__144d; tmp3 = fncls__144d } else { tmp3 = fncls__144 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__145, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_187; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_188)); return A_arbace_pprint_cl_format__init_part0_A_const_187 }






func A_arbace_pprint_cl_format__init_part0_A_Unit87__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1300, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_189; var tmp2 *lang.Compiler_AOTFn; var fnbody__147 any = aot_arbace_pprint.A_arbace_pprint_conditional_newline_A_New(); var tmp3 *jrt.Class; var fncls__146 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_conditional_newline_A_fn_class; if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, nil); aot_arbace_pprint.A_arbace_pprint_conditional_newline_A_fn_class = fncls__146d; tmp3 = fncls__146d } else { tmp3 = fncls__146 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__147, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_189; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_190)); return A_arbace_pprint_cl_format__init_part0_A_const_189 }












func A_arbace_pprint_cl_format__init_part0_A_Unit88__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1313, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_191; var tmp2 *lang.Compiler_AOTFn; var fnbody__149 any = aot_arbace_pprint.A_arbace_pprint_process_directive_table_element_A_New(); var tmp3 *jrt.Class; var fncls__148 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_process_directive_table_element_A_fn_class; if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); aot_arbace_pprint.A_arbace_pprint_process_directive_table_element_A_fn_class = fncls__148d; tmp3 = fncls__148d } else { tmp3 = fncls__148 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__149, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_191; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_192)); return A_arbace_pprint_cl_format__init_part0_A_const_191 }







func A_arbace_pprint_cl_format__init_part0_A_Unit89__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1321, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_193; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__151 any = aot_arbace_pprint.A_arbace_pprint_defdirectives_A_New(); var tmp3 *jrt.Class; var fncls__150 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_defdirectives_A_fn_class; if fncls__150 == nil { var fncls__150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, true, nil); aot_arbace_pprint.A_arbace_pprint_defdirectives_A_fn_class = fncls__150d; tmp3 = fncls__150d } else { tmp3 = fncls__150 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__151, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_193; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_194)); return A_arbace_pprint_cl_format__init_part0_A_const_193 }
//line :1321:1
func A_arbace_pprint_cl_format__init_part0_A_Unit90__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1321, 1); A_arbace_pprint_cl_format__init_part0_A_const_193.SetMacro__V(); return nil }
//line :1321:1
func A_arbace_pprint_cl_format__init_part0_A_Unit91__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1321, 1); return A_arbace_pprint_cl_format__init_part0_A_const_193 }





func A_arbace_pprint_cl_format__init_part0_A_Unit92__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1327, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_195; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_196.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_cl_format__init_part0_A_const_197; var tmp4 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp5 any = A_arbace_pprint_cl_format__init_part0_A_const_197; var tmp6 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp7 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_200, A_arbace_pprint_cl_format__init_part0_A_const_201, A_arbace_pprint_cl_format__init_part0_A_const_202, A_arbace_pprint_cl_format__init_part0_A_const_203, A_arbace_pprint_cl_format__init_part0_A_const_204, A_arbace_pprint_cl_format__init_part0_A_const_205, A_arbace_pprint_cl_format__init_part0_A_const_206, A_arbace_pprint_cl_format__init_part0_A_const_207); var tmp8 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp9 any = A_arbace_pprint_cl_format__init_part0_A_const_209; var tmp10 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp11 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp12 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp13 *lang.Compiler_AOTFn; var fnbody__164 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000328_A_New(); var tmp14 *jrt.Class; var fncls__163 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000328_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000328_A_fn_class = fncls__163d; tmp14 = fncls__163d } else { tmp14 = fncls__163 }; tmp13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__164, tmp14, nil); var tmp15 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13.Ref())); var tmp16 any = A_arbace_pprint_cl_format__init_part0_A_const_212; var tmp17 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp18 any = A_arbace_pprint_cl_format__init_part0_A_const_212; var tmp19 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp20 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_200, A_arbace_pprint_cl_format__init_part0_A_const_213, A_arbace_pprint_cl_format__init_part0_A_const_202, A_arbace_pprint_cl_format__init_part0_A_const_214, A_arbace_pprint_cl_format__init_part0_A_const_204, A_arbace_pprint_cl_format__init_part0_A_const_215, A_arbace_pprint_cl_format__init_part0_A_const_206, A_arbace_pprint_cl_format__init_part0_A_const_216); var tmp21 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp22 any = A_arbace_pprint_cl_format__init_part0_A_const_217; var tmp23 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp24 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp25 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp26 *lang.Compiler_AOTFn; var fnbody__177 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000332_A_New(); var tmp27 *jrt.Class; var fncls__176 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000332_A_fn_class; if fncls__176 == nil { var fncls__176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000332_A_fn_class = fncls__176d; tmp27 = fncls__176d } else { tmp27 = fncls__176 }; tmp26 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__177, tmp27, nil); var tmp28 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26.Ref())); var tmp29 any = A_arbace_pprint_cl_format__init_part0_A_const_218; var tmp30 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp31 any = A_arbace_pprint_cl_format__init_part0_A_const_218; var tmp32 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp33 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_200, A_arbace_pprint_cl_format__init_part0_A_const_219, A_arbace_pprint_cl_format__init_part0_A_const_206, A_arbace_pprint_cl_format__init_part0_A_const_220, A_arbace_pprint_cl_format__init_part0_A_const_221, A_arbace_pprint_cl_format__init_part0_A_const_222, A_arbace_pprint_cl_format__init_part0_A_const_223, A_arbace_pprint_cl_format__init_part0_A_const_224); var tmp34 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp35 any = A_arbace_pprint_cl_format__init_part0_A_const_225; var tmp36 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp37 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp38 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp39 *lang.Compiler_AOTFn; var fnbody__190 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000336_A_New(); var tmp40 *jrt.Class; var fncls__189 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000336_A_fn_class; if fncls__189 == nil { var fncls__189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000336_A_fn_class = fncls__189d; tmp40 = fncls__189d } else { tmp40 = fncls__189 }; tmp39 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__190, tmp40, nil); var tmp41 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp30, tmp31, tmp32, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39.Ref())); var tmp42 any = A_arbace_pprint_cl_format__init_part0_A_const_226; var tmp43 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp44 any = A_arbace_pprint_cl_format__init_part0_A_const_226; var tmp45 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp46 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_200, A_arbace_pprint_cl_format__init_part0_A_const_227, A_arbace_pprint_cl_format__init_part0_A_const_206, A_arbace_pprint_cl_format__init_part0_A_const_228, A_arbace_pprint_cl_format__init_part0_A_const_221, A_arbace_pprint_cl_format__init_part0_A_const_229, A_arbace_pprint_cl_format__init_part0_A_const_223, A_arbace_pprint_cl_format__init_part0_A_const_230); var tmp47 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp48 any = A_arbace_pprint_cl_format__init_part0_A_const_231; var tmp49 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp50 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp51 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp52 *lang.Compiler_AOTFn; var fnbody__203 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000340_A_New(); var tmp53 *jrt.Class; var fncls__202 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000340_A_fn_class; if fncls__202 == nil { var fncls__202d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000340_A_fn_class = fncls__202d; tmp53 = fncls__202d } else { tmp53 = fncls__202 }; tmp52 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__203, tmp53, nil); var tmp54 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp44, tmp45, tmp46, tmp47, tmp48, tmp49, tmp50, tmp51, tmp52.Ref())); var tmp55 any = A_arbace_pprint_cl_format__init_part0_A_const_232; var tmp56 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp57 any = A_arbace_pprint_cl_format__init_part0_A_const_232; var tmp58 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp59 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_200, A_arbace_pprint_cl_format__init_part0_A_const_233, A_arbace_pprint_cl_format__init_part0_A_const_206, A_arbace_pprint_cl_format__init_part0_A_const_234, A_arbace_pprint_cl_format__init_part0_A_const_221, A_arbace_pprint_cl_format__init_part0_A_const_235, A_arbace_pprint_cl_format__init_part0_A_const_223, A_arbace_pprint_cl_format__init_part0_A_const_236); var tmp60 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp61 any = A_arbace_pprint_cl_format__init_part0_A_const_237; var tmp62 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp63 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp64 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp65 *lang.Compiler_AOTFn; var fnbody__216 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000344_A_New(); var tmp66 *jrt.Class; var fncls__215 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000344_A_fn_class; if fncls__215 == nil { var fncls__215d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000344_A_fn_class = fncls__215d; tmp66 = fncls__215d } else { tmp66 = fncls__215 }; tmp65 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__216, tmp66, nil); var tmp67 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp56, tmp57, tmp58, tmp59, tmp60, tmp61, tmp62, tmp63, tmp64, tmp65.Ref())); var tmp68 any = A_arbace_pprint_cl_format__init_part0_A_const_238; var tmp69 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp70 any = A_arbace_pprint_cl_format__init_part0_A_const_238; var tmp71 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp72 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_200, A_arbace_pprint_cl_format__init_part0_A_const_239, A_arbace_pprint_cl_format__init_part0_A_const_206, A_arbace_pprint_cl_format__init_part0_A_const_240, A_arbace_pprint_cl_format__init_part0_A_const_221, A_arbace_pprint_cl_format__init_part0_A_const_241, A_arbace_pprint_cl_format__init_part0_A_const_223, A_arbace_pprint_cl_format__init_part0_A_const_242); var tmp73 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp74 any = A_arbace_pprint_cl_format__init_part0_A_const_243; var tmp75 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp76 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp77 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp78 *lang.Compiler_AOTFn; var fnbody__229 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000348_A_New(); var tmp79 *jrt.Class; var fncls__228 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000348_A_fn_class; if fncls__228 == nil { var fncls__228d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000348_A_fn_class = fncls__228d; tmp79 = fncls__228d } else { tmp79 = fncls__228 }; tmp78 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__229, tmp79, nil); var tmp80 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp69, tmp70, tmp71, tmp72, tmp73, tmp74, tmp75, tmp76, tmp77, tmp78.Ref())); var tmp81 any = A_arbace_pprint_cl_format__init_part0_A_const_244; var tmp82 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp83 any = A_arbace_pprint_cl_format__init_part0_A_const_244; var tmp84 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp85 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_245, A_arbace_pprint_cl_format__init_part0_A_const_246, A_arbace_pprint_cl_format__init_part0_A_const_200, A_arbace_pprint_cl_format__init_part0_A_const_247, A_arbace_pprint_cl_format__init_part0_A_const_206, A_arbace_pprint_cl_format__init_part0_A_const_248, A_arbace_pprint_cl_format__init_part0_A_const_221, A_arbace_pprint_cl_format__init_part0_A_const_249, A_arbace_pprint_cl_format__init_part0_A_const_223, A_arbace_pprint_cl_format__init_part0_A_const_250); var tmp86 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp87 any = A_arbace_pprint_cl_format__init_part0_A_const_251; var tmp88 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp89 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp90 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp91 *lang.Compiler_AOTFn; var fnbody__244 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000352_A_New(); var tmp92 *jrt.Class; var fncls__243 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000352_A_fn_class; if fncls__243 == nil { var fncls__243d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000352_A_fn_class = fncls__243d; tmp92 = fncls__243d } else { tmp92 = fncls__243 }; tmp91 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__244, tmp92, nil); var tmp93 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp82, tmp83, tmp84, tmp85, tmp86, tmp87, tmp88, tmp89, tmp90, tmp91.Ref())); var tmp94 any = A_arbace_pprint_cl_format__init_part0_A_const_252; var tmp95 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp96 any = A_arbace_pprint_cl_format__init_part0_A_const_252; var tmp97 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp98 any; var root_245 any = A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; if linked_246 == nil { tmp98 = ifn_247.Invoke__O() } else { tmp98 = linked_246.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_245) }; var tmp99 any = tmp98; var tmp100 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp101 any = A_arbace_pprint_cl_format__init_part0_A_const_253; var tmp102 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp103 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp104 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp105 *lang.Compiler_AOTFn; var fnbody__249 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000364_A_New(); var tmp106 *jrt.Class; var fncls__248 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000364_A_fn_class; if fncls__248 == nil { var fncls__248d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000364_A_fn_class = fncls__248d; tmp106 = fncls__248d } else { tmp106 = fncls__248 }; tmp105 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__249, tmp106, nil); var tmp107 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp95, tmp96, tmp97, tmp99, tmp100, tmp101, tmp102, tmp103, tmp104, tmp105.Ref())); var tmp108 any = A_arbace_pprint_cl_format__init_part0_A_const_254; var tmp109 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp110 any = A_arbace_pprint_cl_format__init_part0_A_const_254; var tmp111 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp112 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_255, A_arbace_pprint_cl_format__init_part0_A_const_256); var tmp113 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp114 any = A_arbace_pprint_cl_format__init_part0_A_const_257; var tmp115 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp116 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp117 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp118 *lang.Compiler_AOTFn; var fnbody__256 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000371_A_New(); var tmp119 *jrt.Class; var fncls__255 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000371_A_fn_class; if fncls__255 == nil { var fncls__255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000371_A_fn_class = fncls__255d; tmp119 = fncls__255d } else { tmp119 = fncls__255 }; tmp118 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__256, tmp119, nil); var tmp120 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp109, tmp110, tmp111, tmp112, tmp113, tmp114, tmp115, tmp116, tmp117, tmp118.Ref())); var tmp121 any = A_arbace_pprint_cl_format__init_part0_A_const_258; var tmp122 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp123 any = A_arbace_pprint_cl_format__init_part0_A_const_258; var tmp124 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp125 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_259, A_arbace_pprint_cl_format__init_part0_A_const_260, A_arbace_pprint_cl_format__init_part0_A_const_261, A_arbace_pprint_cl_format__init_part0_A_const_262, A_arbace_pprint_cl_format__init_part0_A_const_263, A_arbace_pprint_cl_format__init_part0_A_const_264, A_arbace_pprint_cl_format__init_part0_A_const_265, A_arbace_pprint_cl_format__init_part0_A_const_266, A_arbace_pprint_cl_format__init_part0_A_const_206, A_arbace_pprint_cl_format__init_part0_A_const_267); var tmp126 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp127 any = A_arbace_pprint_cl_format__init_part0_A_const_268; var tmp128 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp129 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp130 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp131 *lang.Compiler_AOTFn; var fnbody__271 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000373_A_New(); var tmp132 *jrt.Class; var fncls__270 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000373_A_fn_class; if fncls__270 == nil { var fncls__270d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000373_A_fn_class = fncls__270d; tmp132 = fncls__270d } else { tmp132 = fncls__270 }; tmp131 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__271, tmp132, nil); var tmp133 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp122, tmp123, tmp124, tmp125, tmp126, tmp127, tmp128, tmp129, tmp130, tmp131.Ref())); var tmp134 any = A_arbace_pprint_cl_format__init_part0_A_const_269; var tmp135 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp136 any = A_arbace_pprint_cl_format__init_part0_A_const_269; var tmp137 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp138 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_259, A_arbace_pprint_cl_format__init_part0_A_const_270, A_arbace_pprint_cl_format__init_part0_A_const_261, A_arbace_pprint_cl_format__init_part0_A_const_271, A_arbace_pprint_cl_format__init_part0_A_const_272, A_arbace_pprint_cl_format__init_part0_A_const_273, A_arbace_pprint_cl_format__init_part0_A_const_263, A_arbace_pprint_cl_format__init_part0_A_const_274, A_arbace_pprint_cl_format__init_part0_A_const_265, A_arbace_pprint_cl_format__init_part0_A_const_275, A_arbace_pprint_cl_format__init_part0_A_const_206, A_arbace_pprint_cl_format__init_part0_A_const_276, A_arbace_pprint_cl_format__init_part0_A_const_277, A_arbace_pprint_cl_format__init_part0_A_const_278); var tmp139 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp140 any = A_arbace_pprint_cl_format__init_part0_A_const_279; var tmp141 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp142 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp143 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp144 *lang.Compiler_AOTFn; var fnbody__290 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000375_A_New(); var tmp145 *jrt.Class; var fncls__289 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000375_A_fn_class; if fncls__289 == nil { var fncls__289d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000375_A_fn_class = fncls__289d; tmp145 = fncls__289d } else { tmp145 = fncls__289 }; tmp144 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__290, tmp145, nil); var tmp146 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp135, tmp136, tmp137, tmp138, tmp139, tmp140, tmp141, tmp142, tmp143, tmp144.Ref())); var tmp147 any = A_arbace_pprint_cl_format__init_part0_A_const_280; var tmp148 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp149 any = A_arbace_pprint_cl_format__init_part0_A_const_280; var tmp150 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp151 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_259, A_arbace_pprint_cl_format__init_part0_A_const_281, A_arbace_pprint_cl_format__init_part0_A_const_261, A_arbace_pprint_cl_format__init_part0_A_const_282, A_arbace_pprint_cl_format__init_part0_A_const_272, A_arbace_pprint_cl_format__init_part0_A_const_283, A_arbace_pprint_cl_format__init_part0_A_const_263, A_arbace_pprint_cl_format__init_part0_A_const_284, A_arbace_pprint_cl_format__init_part0_A_const_265, A_arbace_pprint_cl_format__init_part0_A_const_285, A_arbace_pprint_cl_format__init_part0_A_const_206, A_arbace_pprint_cl_format__init_part0_A_const_286, A_arbace_pprint_cl_format__init_part0_A_const_277, A_arbace_pprint_cl_format__init_part0_A_const_287); var tmp152 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp153 any = A_arbace_pprint_cl_format__init_part0_A_const_288; var tmp154 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp155 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp156 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp157 *lang.Compiler_AOTFn; var fnbody__309 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000377_A_New(); var tmp158 *jrt.Class; var fncls__308 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000377_A_fn_class; if fncls__308 == nil { var fncls__308d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000377_A_fn_class = fncls__308d; tmp158 = fncls__308d } else { tmp158 = fncls__308 }; tmp157 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__309, tmp158, nil); var tmp159 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp148, tmp149, tmp150, tmp151, tmp152, tmp153, tmp154, tmp155, tmp156, tmp157.Ref())); var tmp160 any = A_arbace_pprint_cl_format__init_part0_A_const_289; var tmp161 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp162 any = A_arbace_pprint_cl_format__init_part0_A_const_289; var tmp163 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp164 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_261, A_arbace_pprint_cl_format__init_part0_A_const_290, A_arbace_pprint_cl_format__init_part0_A_const_291, A_arbace_pprint_cl_format__init_part0_A_const_292, A_arbace_pprint_cl_format__init_part0_A_const_259, A_arbace_pprint_cl_format__init_part0_A_const_293, A_arbace_pprint_cl_format__init_part0_A_const_206, A_arbace_pprint_cl_format__init_part0_A_const_294); var tmp165 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp166 any = A_arbace_pprint_cl_format__init_part0_A_const_295; var tmp167 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp168 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp169 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp170 *lang.Compiler_AOTFn; var fnbody__322 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000379_A_New(); var tmp171 *jrt.Class; var fncls__321 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000379_A_fn_class; if fncls__321 == nil { var fncls__321d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000379_A_fn_class = fncls__321d; tmp171 = fncls__321d } else { tmp171 = fncls__321 }; tmp170 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__322, tmp171, nil); var tmp172 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp161, tmp162, tmp163, tmp164, tmp165, tmp166, tmp167, tmp168, tmp169, tmp170.Ref())); var tmp173 any = A_arbace_pprint_cl_format__init_part0_A_const_296; var tmp174 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp175 any = A_arbace_pprint_cl_format__init_part0_A_const_296; var tmp176 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp177 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_297, A_arbace_pprint_cl_format__init_part0_A_const_298); var tmp178 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp179 any = lang.PersistentHashSet_EMPTY.Ref(); var tmp180 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp181 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp182 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp183 *lang.Compiler_AOTFn; var fnbody__329 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000381_A_New(); var tmp184 *jrt.Class; var fncls__328 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000381_A_fn_class; if fncls__328 == nil { var fncls__328d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000381_A_fn_class = fncls__328d; tmp184 = fncls__328d } else { tmp184 = fncls__328 }; tmp183 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__329, tmp184, nil); var tmp185 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp174, tmp175, tmp176, tmp177, tmp178, tmp179, tmp180, tmp181, tmp182, tmp183.Ref())); var tmp186 any = A_arbace_pprint_cl_format__init_part0_A_const_299; var tmp187 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp188 any = A_arbace_pprint_cl_format__init_part0_A_const_299; var tmp189 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp190 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_297, A_arbace_pprint_cl_format__init_part0_A_const_300); var tmp191 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp192 any = A_arbace_pprint_cl_format__init_part0_A_const_301; var tmp193 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp194 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp195 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp196 *lang.Compiler_AOTFn; var fnbody__336 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000385_A_New(); var tmp197 *jrt.Class; var fncls__335 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000385_A_fn_class; if fncls__335 == nil { var fncls__335d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000385_A_fn_class = fncls__335d; tmp197 = fncls__335d } else { tmp197 = fncls__335 }; tmp196 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__336, tmp197, nil); var tmp198 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp187, tmp188, tmp189, tmp190, tmp191, tmp192, tmp193, tmp194, tmp195, tmp196.Ref())); var tmp199 any = A_arbace_pprint_cl_format__init_part0_A_const_302; var tmp200 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp201 any = A_arbace_pprint_cl_format__init_part0_A_const_302; var tmp202 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp203 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_297, A_arbace_pprint_cl_format__init_part0_A_const_303); var tmp204 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp205 any = lang.PersistentHashSet_EMPTY.Ref(); var tmp206 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp207 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp208 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp209 *lang.Compiler_AOTFn; var fnbody__343 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000389_A_New(); var tmp210 *jrt.Class; var fncls__342 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000389_A_fn_class; if fncls__342 == nil { var fncls__342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000389_A_fn_class = fncls__342d; tmp210 = fncls__342d } else { tmp210 = fncls__342 }; tmp209 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__343, tmp210, nil); var tmp211 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp200, tmp201, tmp202, tmp203, tmp204, tmp205, tmp206, tmp207, tmp208, tmp209.Ref())); var tmp212 any = A_arbace_pprint_cl_format__init_part0_A_const_304; var tmp213 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp214 any = A_arbace_pprint_cl_format__init_part0_A_const_304; var tmp215 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp216 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_291, A_arbace_pprint_cl_format__init_part0_A_const_305); var tmp217 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp218 any = lang.PersistentHashSet_EMPTY.Ref(); var tmp219 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp220 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp221 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp222 *lang.Compiler_AOTFn; var fnbody__350 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000393_A_New(); var tmp223 *jrt.Class; var fncls__349 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000393_A_fn_class; if fncls__349 == nil { var fncls__349d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000393_A_fn_class = fncls__349d; tmp223 = fncls__349d } else { tmp223 = fncls__349 }; tmp222 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__350, tmp223, nil); var tmp224 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp213, tmp214, tmp215, tmp216, tmp217, tmp218, tmp219, tmp220, tmp221, tmp222.Ref())); var tmp225 any = A_arbace_pprint_cl_format__init_part0_A_const_306; var tmp226 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp227 any = A_arbace_pprint_cl_format__init_part0_A_const_306; var tmp228 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp229 any; var root_351 any = A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_353 lang.IFn; if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; if linked_352 == nil { tmp229 = ifn_353.Invoke__O() } else { tmp229 = linked_352.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_351) }; var tmp230 any = tmp229; var tmp231 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp232 any = A_arbace_pprint_cl_format__init_part0_A_const_307; var tmp233 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp234 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp235 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp236 *lang.Compiler_AOTFn; var fnbody__355 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000397_A_New(); var tmp237 *jrt.Class; var fncls__354 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000397_A_fn_class; if fncls__354 == nil { var fncls__354d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000397_A_fn_class = fncls__354d; tmp237 = fncls__354d } else { tmp237 = fncls__354 }; tmp236 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__355, tmp237, nil); var tmp238 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp226, tmp227, tmp228, tmp230, tmp231, tmp232, tmp233, tmp234, tmp235, tmp236.Ref())); var tmp239 any = A_arbace_pprint_cl_format__init_part0_A_const_308; var tmp240 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp241 any = A_arbace_pprint_cl_format__init_part0_A_const_308; var tmp242 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp243 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_309, A_arbace_pprint_cl_format__init_part0_A_const_310, A_arbace_pprint_cl_format__init_part0_A_const_202, A_arbace_pprint_cl_format__init_part0_A_const_311); var tmp244 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp245 any = A_arbace_pprint_cl_format__init_part0_A_const_312; var tmp246 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp247 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp248 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp249 *lang.Compiler_AOTFn; var fnbody__364 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000401_A_New(); var tmp250 *jrt.Class; var fncls__363 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000401_A_fn_class; if fncls__363 == nil { var fncls__363d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000401_A_fn_class = fncls__363d; tmp250 = fncls__363d } else { tmp250 = fncls__363 }; tmp249 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__364, tmp250, nil); var tmp251 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp240, tmp241, tmp242, tmp243, tmp244, tmp245, tmp246, tmp247, tmp248, tmp249.Ref())); var tmp252 any = A_arbace_pprint_cl_format__init_part0_A_const_313; var tmp253 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp254 any = A_arbace_pprint_cl_format__init_part0_A_const_313; var tmp255 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp256 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_291, A_arbace_pprint_cl_format__init_part0_A_const_314); var tmp257 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp258 any = A_arbace_pprint_cl_format__init_part0_A_const_315; var tmp259 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp260 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp261 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp262 *lang.Compiler_AOTFn; var fnbody__371 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000407_A_New(); var tmp263 *jrt.Class; var fncls__370 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000407_A_fn_class; if fncls__370 == nil { var fncls__370d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000407_A_fn_class = fncls__370d; tmp263 = fncls__370d } else { tmp263 = fncls__370 }; tmp262 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__371, tmp263, nil); var tmp264 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp253, tmp254, tmp255, tmp256, tmp257, tmp258, tmp259, tmp260, tmp261, tmp262.Ref())); var tmp265 any = A_arbace_pprint_cl_format__init_part0_A_const_316; var tmp266 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp267 any = A_arbace_pprint_cl_format__init_part0_A_const_316; var tmp268 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp269 any; var root_372 any = A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; if linked_373 == nil { tmp269 = ifn_374.Invoke__O() } else { tmp269 = linked_373.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_372) }; var tmp270 any = tmp269; var tmp271 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp272 any = A_arbace_pprint_cl_format__init_part0_A_const_317; var tmp273 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp274 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp275 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp276 *lang.Compiler_AOTFn; var fnbody__376 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000413_A_New(); var tmp277 *jrt.Class; var fncls__375 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000413_A_fn_class; if fncls__375 == nil { var fncls__375d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000413_A_fn_class = fncls__375d; tmp277 = fncls__375d } else { tmp277 = fncls__375 }; tmp276 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__376, tmp277, nil); var tmp278 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp266, tmp267, tmp268, tmp270, tmp271, tmp272, tmp273, tmp274, tmp275, tmp276.Ref())); var tmp279 any = A_arbace_pprint_cl_format__init_part0_A_const_318; var tmp280 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp281 any = A_arbace_pprint_cl_format__init_part0_A_const_318; var tmp282 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp283 any; var root_377 any = A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_377, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_379 lang.IFn; if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; if linked_378 == nil { tmp283 = ifn_379.Invoke__O() } else { tmp283 = linked_378.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_377) }; var tmp284 any = tmp283; var tmp285 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp286 any = A_arbace_pprint_cl_format__init_part0_A_const_319; var tmp287 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp288 any = A_arbace_pprint_cl_format__init_part0_A_const_320; var tmp289 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp290 *lang.Compiler_AOTFn; var fnbody__381 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000428_A_New(); var tmp291 *jrt.Class; var fncls__380 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000428_A_fn_class; if fncls__380 == nil { var fncls__380d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000428_A_fn_class = fncls__380d; tmp291 = fncls__380d } else { tmp291 = fncls__380 }; tmp290 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__381, tmp291, nil); var tmp292 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp280, tmp281, tmp282, tmp284, tmp285, tmp286, tmp287, tmp288, tmp289, tmp290.Ref())); var tmp293 any = A_arbace_pprint_cl_format__init_part0_A_const_321; var tmp294 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp295 any = A_arbace_pprint_cl_format__init_part0_A_const_321; var tmp296 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp297 any; var root_382 any = A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; if linked_383 == nil { tmp297 = ifn_384.Invoke__O() } else { tmp297 = linked_383.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_382) }; var tmp298 any = tmp297; var tmp299 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp300 any = lang.PersistentHashSet_EMPTY.Ref(); var tmp301 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp302 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp303 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp304 *lang.Compiler_AOTFn; var fnbody__386 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000432_A_New(); var tmp305 *jrt.Class; var fncls__385 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000432_A_fn_class; if fncls__385 == nil { var fncls__385d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000432_A_fn_class = fncls__385d; tmp305 = fncls__385d } else { tmp305 = fncls__385 }; tmp304 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__386, tmp305, nil); var tmp306 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp294, tmp295, tmp296, tmp298, tmp299, tmp300, tmp301, tmp302, tmp303, tmp304.Ref())); var tmp307 any = A_arbace_pprint_cl_format__init_part0_A_const_322; var tmp308 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp309 any = A_arbace_pprint_cl_format__init_part0_A_const_322; var tmp310 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp311 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_323, A_arbace_pprint_cl_format__init_part0_A_const_324); var tmp312 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp313 any = A_arbace_pprint_cl_format__init_part0_A_const_325; var tmp314 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp315 any = A_arbace_pprint_cl_format__init_part0_A_const_326; var tmp316 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp317 *lang.Compiler_AOTFn; var fnbody__393 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000434_A_New(); var tmp318 *jrt.Class; var fncls__392 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000434_A_fn_class; if fncls__392 == nil { var fncls__392d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000434_A_fn_class = fncls__392d; tmp318 = fncls__392d } else { tmp318 = fncls__392 }; tmp317 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__393, tmp318, nil); var tmp319 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp308, tmp309, tmp310, tmp311, tmp312, tmp313, tmp314, tmp315, tmp316, tmp317.Ref())); var tmp320 any = A_arbace_pprint_cl_format__init_part0_A_const_327; var tmp321 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp322 any = A_arbace_pprint_cl_format__init_part0_A_const_327; var tmp323 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp324 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_328, A_arbace_pprint_cl_format__init_part0_A_const_329, A_arbace_pprint_cl_format__init_part0_A_const_330, A_arbace_pprint_cl_format__init_part0_A_const_331); var tmp325 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp326 any = A_arbace_pprint_cl_format__init_part0_A_const_332; var tmp327 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp328 any = A_arbace_pprint_cl_format__init_part0_A_const_333; var tmp329 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp330 *lang.Compiler_AOTFn; var fnbody__402 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000436_A_New(); var tmp331 *jrt.Class; var fncls__401 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000436_A_fn_class; if fncls__401 == nil { var fncls__401d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000436_A_fn_class = fncls__401d; tmp331 = fncls__401d } else { tmp331 = fncls__401 }; tmp330 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__402, tmp331, nil); var tmp332 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp321, tmp322, tmp323, tmp324, tmp325, tmp326, tmp327, tmp328, tmp329, tmp330.Ref())); var tmp333 any = A_arbace_pprint_cl_format__init_part0_A_const_334; var tmp334 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp335 any = A_arbace_pprint_cl_format__init_part0_A_const_334; var tmp336 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp337 any; var root_403 any = A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; if linked_404 == nil { tmp337 = ifn_405.Invoke__O() } else { tmp337 = linked_404.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_403) }; var tmp338 any = tmp337; var tmp339 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp340 any = lang.PersistentHashSet_EMPTY.Ref(); var tmp341 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp342 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp343 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp344 *lang.Compiler_AOTFn; var fnbody__407 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000438_A_New(); var tmp345 *jrt.Class; var fncls__406 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000438_A_fn_class; if fncls__406 == nil { var fncls__406d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000438_A_fn_class = fncls__406d; tmp345 = fncls__406d } else { tmp345 = fncls__406 }; tmp344 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__407, tmp345, nil); var tmp346 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp334, tmp335, tmp336, tmp338, tmp339, tmp340, tmp341, tmp342, tmp343, tmp344.Ref())); var tmp347 any = A_arbace_pprint_cl_format__init_part0_A_const_335; var tmp348 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp349 any = A_arbace_pprint_cl_format__init_part0_A_const_335; var tmp350 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp351 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_336, A_arbace_pprint_cl_format__init_part0_A_const_337); var tmp352 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp353 any = A_arbace_pprint_cl_format__init_part0_A_const_338; var tmp354 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp355 any = A_arbace_pprint_cl_format__init_part0_A_const_339; var tmp356 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp357 *lang.Compiler_AOTFn; var fnbody__414 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000440_A_New(); var tmp358 *jrt.Class; var fncls__413 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000440_A_fn_class; if fncls__413 == nil { var fncls__413d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000440_A_fn_class = fncls__413d; tmp358 = fncls__413d } else { tmp358 = fncls__413 }; tmp357 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__414, tmp358, nil); var tmp359 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp348, tmp349, tmp350, tmp351, tmp352, tmp353, tmp354, tmp355, tmp356, tmp357.Ref())); var tmp360 any = A_arbace_pprint_cl_format__init_part0_A_const_340; var tmp361 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp362 any = A_arbace_pprint_cl_format__init_part0_A_const_340; var tmp363 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp364 any; var root_415 any = A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; if linked_416 == nil { tmp364 = ifn_417.Invoke__O() } else { tmp364 = linked_416.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_415) }; var tmp365 any = tmp364; var tmp366 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp367 any = A_arbace_pprint_cl_format__init_part0_A_const_341; var tmp368 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp369 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp370 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp371 *lang.Compiler_AOTFn; var fnbody__419 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000442_A_New(); var tmp372 *jrt.Class; var fncls__418 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000442_A_fn_class; if fncls__418 == nil { var fncls__418d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000442_A_fn_class = fncls__418d; tmp372 = fncls__418d } else { tmp372 = fncls__418 }; tmp371 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__419, tmp372, nil); var tmp373 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp361, tmp362, tmp363, tmp365, tmp366, tmp367, tmp368, tmp369, tmp370, tmp371.Ref())); var tmp374 any = A_arbace_pprint_cl_format__init_part0_A_const_342; var tmp375 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp376 any = A_arbace_pprint_cl_format__init_part0_A_const_342; var tmp377 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp378 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_200, A_arbace_pprint_cl_format__init_part0_A_const_343, A_arbace_pprint_cl_format__init_part0_A_const_202, A_arbace_pprint_cl_format__init_part0_A_const_344, A_arbace_pprint_cl_format__init_part0_A_const_204, A_arbace_pprint_cl_format__init_part0_A_const_345, A_arbace_pprint_cl_format__init_part0_A_const_206, A_arbace_pprint_cl_format__init_part0_A_const_346); var tmp379 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp380 any = A_arbace_pprint_cl_format__init_part0_A_const_347; var tmp381 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp382 any = A_arbace_pprint_cl_format__init_part0_A_const_348; var tmp383 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp384 *lang.Compiler_AOTFn; var fnbody__432 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000444_A_New(); var tmp385 *jrt.Class; var fncls__431 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000444_A_fn_class; if fncls__431 == nil { var fncls__431d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000444_A_fn_class = fncls__431d; tmp385 = fncls__431d } else { tmp385 = fncls__431 }; tmp384 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__432, tmp385, nil); var tmp386 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp375, tmp376, tmp377, tmp378, tmp379, tmp380, tmp381, tmp382, tmp383, tmp384.Ref())); var tmp387 any = A_arbace_pprint_cl_format__init_part0_A_const_349; var tmp388 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp389 any = A_arbace_pprint_cl_format__init_part0_A_const_349; var tmp390 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp391 any; var root_433 any = A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; if linked_434 == nil { tmp391 = ifn_435.Invoke__O() } else { tmp391 = linked_434.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_433) }; var tmp392 any = tmp391; var tmp393 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp394 any = A_arbace_pprint_cl_format__init_part0_A_const_350; var tmp395 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp396 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp397 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp398 *lang.Compiler_AOTFn; var fnbody__437 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000446_A_New(); var tmp399 *jrt.Class; var fncls__436 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000446_A_fn_class; if fncls__436 == nil { var fncls__436d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000446_A_fn_class = fncls__436d; tmp399 = fncls__436d } else { tmp399 = fncls__436 }; tmp398 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__437, tmp399, nil); var tmp400 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp388, tmp389, tmp390, tmp392, tmp393, tmp394, tmp395, tmp396, tmp397, tmp398.Ref())); var tmp401 any = A_arbace_pprint_cl_format__init_part0_A_const_351; var tmp402 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp403 any = A_arbace_pprint_cl_format__init_part0_A_const_351; var tmp404 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp405 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_352, A_arbace_pprint_cl_format__init_part0_A_const_353, A_arbace_pprint_cl_format__init_part0_A_const_354, A_arbace_pprint_cl_format__init_part0_A_const_355, A_arbace_pprint_cl_format__init_part0_A_const_356, A_arbace_pprint_cl_format__init_part0_A_const_357); var tmp406 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp407 any = A_arbace_pprint_cl_format__init_part0_A_const_358; var tmp408 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp409 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp410 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp411 *lang.Compiler_AOTFn; var fnbody__448 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000448_A_New(); var tmp412 *jrt.Class; var fncls__447 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000448_A_fn_class; if fncls__447 == nil { var fncls__447d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000448_A_fn_class = fncls__447d; tmp412 = fncls__447d } else { tmp412 = fncls__447 }; tmp411 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__448, tmp412, nil); var tmp413 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp402, tmp403, tmp404, tmp405, tmp406, tmp407, tmp408, tmp409, tmp410, tmp411.Ref())); var tmp414 any = A_arbace_pprint_cl_format__init_part0_A_const_359; var tmp415 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp416 any = A_arbace_pprint_cl_format__init_part0_A_const_359; var tmp417 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp418 any; var root_449 any = A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; if linked_450 == nil { tmp418 = ifn_451.Invoke__O() } else { tmp418 = linked_450.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_449) }; var tmp419 any = tmp418; var tmp420 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp421 any = A_arbace_pprint_cl_format__init_part0_A_const_360; var tmp422 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp423 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp424 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp425 *lang.Compiler_AOTFn; var fnbody__453 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000452_A_New(); var tmp426 *jrt.Class; var fncls__452 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000452_A_fn_class; if fncls__452 == nil { var fncls__452d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000452_A_fn_class = fncls__452d; tmp426 = fncls__452d } else { tmp426 = fncls__452 }; tmp425 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__453, tmp426, nil); var tmp427 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp415, tmp416, tmp417, tmp419, tmp420, tmp421, tmp422, tmp423, tmp424, tmp425.Ref())); var tmp428 any = A_arbace_pprint_cl_format__init_part0_A_const_361; var tmp429 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp430 any = A_arbace_pprint_cl_format__init_part0_A_const_361; var tmp431 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp432 any; var root_454 any = A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; if linked_455 == nil { tmp432 = ifn_456.Invoke__O() } else { tmp432 = linked_455.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_454) }; var tmp433 any = tmp432; var tmp434 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp435 any = A_arbace_pprint_cl_format__init_part0_A_const_362; var tmp436 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp437 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp438 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp439 *lang.Compiler_AOTFn; var fnbody__458 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000464_A_New(); var tmp440 *jrt.Class; var fncls__457 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000464_A_fn_class; if fncls__457 == nil { var fncls__457d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000464_A_fn_class = fncls__457d; tmp440 = fncls__457d } else { tmp440 = fncls__457 }; tmp439 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__458, tmp440, nil); var tmp441 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp429, tmp430, tmp431, tmp433, tmp434, tmp435, tmp436, tmp437, tmp438, tmp439.Ref())); var tmp442 any = A_arbace_pprint_cl_format__init_part0_A_const_363; var tmp443 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp444 any = A_arbace_pprint_cl_format__init_part0_A_const_363; var tmp445 any = A_arbace_pprint_cl_format__init_part0_A_const_35; var tmp446 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_291, A_arbace_pprint_cl_format__init_part0_A_const_364); var tmp447 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp448 any = A_arbace_pprint_cl_format__init_part0_A_const_365; var tmp449 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp450 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp451 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp452 *lang.Compiler_AOTFn; var fnbody__465 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000466_A_New(); var tmp453 *jrt.Class; var fncls__464 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000466_A_fn_class; if fncls__464 == nil { var fncls__464d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_103, false, nil); aot_arbace_pprint.A_arbace_pprint_fn__1819000466_A_fn_class = fncls__464d; tmp453 = fncls__464d } else { tmp453 = fncls__464 }; tmp452 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__465, tmp453, nil); tmp1.BindRoot_O__V(tmp2.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp15, tmp16, tmp28, tmp29, tmp41, tmp42, tmp54, tmp55, tmp67, tmp68, tmp80, tmp81, tmp93, tmp94, tmp107, tmp108, tmp120, tmp121, tmp133, tmp134, tmp146, tmp147, tmp159, tmp160, tmp172, tmp173, tmp185, tmp186, tmp198, tmp199, tmp211, tmp212, tmp224, tmp225, tmp238, tmp239, tmp251, tmp252, tmp264, tmp265, tmp278, tmp279, tmp292, tmp293, tmp306, tmp307, tmp319, tmp320, tmp332, tmp333, tmp346, tmp347, tmp359, tmp360, tmp373, tmp374, tmp386, tmp387, tmp400, tmp401, tmp413, tmp414, tmp427, tmp428, tmp441, tmp442, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp443, tmp444, tmp445, tmp446, tmp447, tmp448, tmp449, tmp450, tmp451, tmp452.Ref()))))))); var tmp454 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_195; tmp454.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_366)); return A_arbace_pprint_cl_format__init_part0_A_const_195 }





























































































































































































































































































func A_arbace_pprint_cl_format__init_part0_A_Unit93__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1613, 1); A_arbace_pprint_cl_format__init_part0_A_const_367.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_368); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_367; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_369)); return A_arbace_pprint_cl_format__init_part0_A_const_367 }

func A_arbace_pprint_cl_format__init_part0_A_Unit94__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1615, 1); A_arbace_pprint_cl_format__init_part0_A_const_370.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_371); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_370; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_372)); return A_arbace_pprint_cl_format__init_part0_A_const_370 }


func A_arbace_pprint_cl_format__init_part0_A_Unit95__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1618, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_373; var tmp2 *lang.Compiler_AOTFn; var fnbody__467 any = aot_arbace_pprint.A_arbace_pprint_extract_param_A_New(); var tmp3 *jrt.Class; var fncls__466 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_extract_param_A_fn_class; if fncls__466 == nil { var fncls__466d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_104, false, nil); aot_arbace_pprint.A_arbace_pprint_extract_param_A_fn_class = fncls__466d; tmp3 = fncls__466d } else { tmp3 = fncls__466 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__467, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_373; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_374)); return A_arbace_pprint_cl_format__init_part0_A_const_373 }













func A_arbace_pprint_cl_format__init_part0_A_Unit96__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1632, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_375; var tmp2 *lang.Compiler_AOTFn; var fnbody__469 any = aot_arbace_pprint.A_arbace_pprint_extract_params_A_New(); var tmp3 *jrt.Class; var fncls__468 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_extract_params_A_fn_class; if fncls__468 == nil { var fncls__468d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, nil); aot_arbace_pprint.A_arbace_pprint_extract_params_A_fn_class = fncls__468d; tmp3 = fncls__468d } else { tmp3 = fncls__468 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__469, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_375; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_376)); return A_arbace_pprint_cl_format__init_part0_A_const_375 }


func A_arbace_pprint_cl_format__init_part0_A_Unit97__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1635, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_377; var tmp2 *lang.Compiler_AOTFn; var fnbody__471 any = aot_arbace_pprint.A_arbace_pprint_translate_param_A_New(); var tmp3 *jrt.Class; var fncls__470 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_translate_param_A_fn_class; if fncls__470 == nil { var fncls__470d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, nil); aot_arbace_pprint.A_arbace_pprint_translate_param_A_fn_class = fncls__470d; tmp3 = fncls__470d } else { tmp3 = fncls__470 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__471, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_377; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_378)); return A_arbace_pprint_cl_format__init_part0_A_const_377 }











func A_arbace_pprint_cl_format__init_part0_A_Unit98__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1647, 1); A_arbace_pprint_cl_format__init_part0_A_const_379.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_380); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_379; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_381)); return A_arbace_pprint_cl_format__init_part0_A_const_379 }


func A_arbace_pprint_cl_format__init_part0_A_Unit99__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1650, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_382; var tmp2 *lang.Compiler_AOTFn; var fnbody__473 any = aot_arbace_pprint.A_arbace_pprint_extract_flags_A_New(); var tmp3 *jrt.Class; var fncls__472 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_extract_flags_A_fn_class; if fncls__472 == nil { var fncls__472d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_107, false, nil); aot_arbace_pprint.A_arbace_pprint_extract_flags_A_fn_class = fncls__472d; tmp3 = fncls__472d } else { tmp3 = fncls__472 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__473, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_382; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_383)); return A_arbace_pprint_cl_format__init_part0_A_const_382 }














func A_arbace_pprint_cl_format__init_part1_A_Unit100__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1665, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = aot_arbace_pprint.A_arbace_pprint_check_flags_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_check_flags_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_109, false, nil); aot_arbace_pprint.A_arbace_pprint_check_flags_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_1)); return A_arbace_pprint_cl_format__init_part1_A_const_0 }
//line :1665:1
func A_arbace_pprint_cl_format__init_part1_A_Init__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); return nil }
//line :1665:1
func A_arbace_pprint_cl_format__init_part1_A_Load__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); A_arbace_pprint_cl_format__init_part1_A_Unit100__O(); A_arbace_pprint_cl_format__init_part1_A_Unit101__O(); A_arbace_pprint_cl_format__init_part1_A_Unit102__O(); A_arbace_pprint_cl_format__init_part1_A_Unit103__O(); A_arbace_pprint_cl_format__init_part1_A_Unit104__O(); A_arbace_pprint_cl_format__init_part1_A_Unit105__O(); A_arbace_pprint_cl_format__init_part1_A_Unit106__O(); A_arbace_pprint_cl_format__init_part1_A_Unit107__O(); A_arbace_pprint_cl_format__init_part1_A_Unit108__O(); A_arbace_pprint_cl_format__init_part1_A_Unit109__O(); A_arbace_pprint_cl_format__init_part1_A_Unit110__O(); A_arbace_pprint_cl_format__init_part1_A_Unit111__O(); A_arbace_pprint_cl_format__init_part1_A_Unit112__O(); A_arbace_pprint_cl_format__init_part1_A_Unit113__O(); A_arbace_pprint_cl_format__init_part1_A_Unit114__O(); A_arbace_pprint_cl_format__init_part1_A_Unit115__O(); A_arbace_pprint_cl_format__init_part1_A_Unit116__O(); A_arbace_pprint_cl_format__init_part1_A_Unit117__O(); A_arbace_pprint_cl_format__init_part1_A_Unit118__O(); A_arbace_pprint_cl_format__init_part1_A_Unit119__O(); A_arbace_pprint_cl_format__init_part1_A_Unit120__O(); A_arbace_pprint_cl_format__init_part1_A_Unit121__O(); return nil }












func A_arbace_pprint_cl_format__init_part1_A_Unit101__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1678, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = aot_arbace_pprint.A_arbace_pprint_map_params_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_map_params_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_110, false, nil); aot_arbace_pprint.A_arbace_pprint_map_params_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_3)); return A_arbace_pprint_cl_format__init_part1_A_const_2 }





























func A_arbace_pprint_cl_format__init_part1_A_Unit102__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1708, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = aot_arbace_pprint.A_arbace_pprint_compile_directive_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_compile_directive_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_111, false, nil); aot_arbace_pprint.A_arbace_pprint_compile_directive_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_5)); return A_arbace_pprint_cl_format__init_part1_A_const_4 }



















func A_arbace_pprint_cl_format__init_part1_A_Unit103__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1728, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = aot_arbace_pprint.A_arbace_pprint_compile_raw_string_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_compile_raw_string_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_112, false, nil); aot_arbace_pprint.A_arbace_pprint_compile_raw_string_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_7)); return A_arbace_pprint_cl_format__init_part1_A_const_6 }


func A_arbace_pprint_cl_format__init_part1_A_Unit104__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1731, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = aot_arbace_pprint.A_arbace_pprint_right_bracket_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_right_bracket_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_113, false, nil); aot_arbace_pprint.A_arbace_pprint_right_bracket_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_9)); return A_arbace_pprint_cl_format__init_part1_A_const_8 }
func A_arbace_pprint_cl_format__init_part1_A_Unit105__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1732, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = aot_arbace_pprint.A_arbace_pprint_separator_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_separator_QMARK__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_114, false, nil); aot_arbace_pprint.A_arbace_pprint_separator_QMARK__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_11)); return A_arbace_pprint_cl_format__init_part1_A_const_10 }
func A_arbace_pprint_cl_format__init_part1_A_Unit106__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1733, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = aot_arbace_pprint.A_arbace_pprint_else_separator_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_else_separator_QMARK__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_115, false, nil); aot_arbace_pprint.A_arbace_pprint_else_separator_QMARK__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_13)); return A_arbace_pprint_cl_format__init_part1_A_const_12 }




func A_arbace_pprint_cl_format__init_part1_A_Unit107__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1738, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_15)); return A_arbace_pprint_cl_format__init_part1_A_const_14 }

func A_arbace_pprint_cl_format__init_part1_A_Unit108__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1740, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = aot_arbace_pprint.A_arbace_pprint_process_bracket_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_process_bracket_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_116, false, nil); aot_arbace_pprint.A_arbace_pprint_process_bracket_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_17)); return A_arbace_pprint_cl_format__init_part1_A_const_16 }








func A_arbace_pprint_cl_format__init_part1_A_Unit109__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1749, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = aot_arbace_pprint.A_arbace_pprint_process_clause_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_process_clause_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_117, false, nil); aot_arbace_pprint.A_arbace_pprint_process_clause_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_19)); return A_arbace_pprint_cl_format__init_part1_A_const_18 }























func A_arbace_pprint_cl_format__init_part1_A_Unit110__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1773, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = aot_arbace_pprint.A_arbace_pprint_collect_clauses_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_collect_clauses_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_118, false, nil); aot_arbace_pprint.A_arbace_pprint_collect_clauses_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_20)); return A_arbace_pprint_cl_format__init_part1_A_const_14 }
















































func A_arbace_pprint_cl_format__init_part1_A_Unit111__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1822, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = aot_arbace_pprint.A_arbace_pprint_process_nesting_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_process_nesting_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, false, nil); aot_arbace_pprint.A_arbace_pprint_process_nesting_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_22)); return A_arbace_pprint_cl_format__init_part1_A_const_21 }














func A_arbace_pprint_cl_format__init_part1_A_Unit112__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1837, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = aot_arbace_pprint.A_arbace_pprint_compile_format_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_compile_format_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, nil); aot_arbace_pprint.A_arbace_pprint_compile_format_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_24)); return A_arbace_pprint_cl_format__init_part1_A_const_23 }




















func A_arbace_pprint_cl_format__init_part1_A_Unit113__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1858, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = aot_arbace_pprint.A_arbace_pprint_needs_pretty_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_needs_pretty_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, nil); aot_arbace_pprint.A_arbace_pprint_needs_pretty_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_26)); return A_arbace_pprint_cl_format__init_part1_A_const_25 }












func A_arbace_pprint_cl_format__init_part1_A_Unit114__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1871, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = aot_arbace_pprint.A_arbace_pprint_execute_format_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_execute_format_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, nil); aot_arbace_pprint.A_arbace_pprint_execute_format_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_28)); return A_arbace_pprint_cl_format__init_part1_A_const_27 }


































func A_arbace_pprint_cl_format__init_part1_A_Unit115__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1906, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_29; var tmp2 any; var root_29 any = A_arbace_pprint_cl_format__init_part1_A_const_30.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_memoize_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = A_arbace_pprint_cl_format__init_part1_A_const_23.GetRawRoot__O(); if linked_30 == nil { tmp2 = ifn_31.Invoke_O__O(arg_32) } else { tmp2 = linked_30.(*aot_arbace_core.A_arbace_core_memoize_A).Invoke_O_O__O(root_29, arg_32) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_29; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_31)); return A_arbace_pprint_cl_format__init_part1_A_const_29 }

func A_arbace_pprint_cl_format__init_part1_A_Unit116__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1908, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = aot_arbace_pprint.A_arbace_pprint_formatter_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_formatter_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_123, false, nil); aot_arbace_pprint.A_arbace_pprint_formatter_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_33)); return A_arbace_pprint_cl_format__init_part1_A_const_32 }
//line :1908:1
func A_arbace_pprint_cl_format__init_part1_A_Unit117__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1908, 1); A_arbace_pprint_cl_format__init_part1_A_const_32.SetMacro__V(); return nil }
//line :1908:1
func A_arbace_pprint_cl_format__init_part1_A_Unit118__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1908, 1); return A_arbace_pprint_cl_format__init_part1_A_const_32 }



















func A_arbace_pprint_cl_format__init_part1_A_Unit119__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1928, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = aot_arbace_pprint.A_arbace_pprint_formatter_out_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_formatter_out_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, nil); aot_arbace_pprint.A_arbace_pprint_formatter_out_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_35)); return A_arbace_pprint_cl_format__init_part1_A_const_34 }
//line :1928:1
func A_arbace_pprint_cl_format__init_part1_A_Unit120__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1928, 1); A_arbace_pprint_cl_format__init_part1_A_const_34.SetMacro__V(); return nil }
//line :1928:1
func A_arbace_pprint_cl_format__init_part1_A_Unit121__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1928, 1); return A_arbace_pprint_cl_format__init_part1_A_const_34 }







type A_arbace_pprint_cl_format__init_A struct{ jrt.Object }

func A_arbace_pprint_cl_format__init_A_New() *A_arbace_pprint_cl_format__init_A { t := &A_arbace_pprint_cl_format__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_cl_format__init_A) Ctor() {}

func (t *A_arbace_pprint_cl_format__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_cl_format__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_cl_format__init_A_class }

func (t *A_arbace_pprint_cl_format__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_cl_format__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_pprint_cl_format__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_cl_format__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_cl_format__init_A); return ok }

func A_arbace_pprint_cl_format__init_A_Cast(x any) *A_arbace_pprint_cl_format__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_cl_format__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_cl_format__init_A_class)) }; return v }



type A_arbace_pprint_cl_format__init_part0_A struct{ jrt.Object }

var A_arbace_pprint_cl_format__init_part0_A_const_pool *jrt.RefArray

var A_arbace_pprint_cl_format__init_part0_A_const_0 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_1 any

var A_arbace_pprint_cl_format__init_part0_A_const_2 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_3 any

var A_arbace_pprint_cl_format__init_part0_A_const_4 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_5 any

var A_arbace_pprint_cl_format__init_part0_A_const_6 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_7 any

var A_arbace_pprint_cl_format__init_part0_A_const_8 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_9 any

var A_arbace_pprint_cl_format__init_part0_A_const_10 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_11 any

var A_arbace_pprint_cl_format__init_part0_A_const_12 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_13 any

var A_arbace_pprint_cl_format__init_part0_A_const_14 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_15 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_16 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_17 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_18 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_19 any

var A_arbace_pprint_cl_format__init_part0_A_const_20 any

var A_arbace_pprint_cl_format__init_part0_A_const_21 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_22 any

var A_arbace_pprint_cl_format__init_part0_A_const_23 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_24 any

var A_arbace_pprint_cl_format__init_part0_A_const_25 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_26 any

var A_arbace_pprint_cl_format__init_part0_A_const_27 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_28 any

var A_arbace_pprint_cl_format__init_part0_A_const_29 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_30 any

var A_arbace_pprint_cl_format__init_part0_A_const_31 any

var A_arbace_pprint_cl_format__init_part0_A_const_32 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_33 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_34 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_35 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_36 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_37 any

var A_arbace_pprint_cl_format__init_part0_A_const_38 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_39 any

var A_arbace_pprint_cl_format__init_part0_A_const_40 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_41 any

var A_arbace_pprint_cl_format__init_part0_A_const_42 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_43 any

var A_arbace_pprint_cl_format__init_part0_A_const_44 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_45 any

var A_arbace_pprint_cl_format__init_part0_A_const_46 any

var A_arbace_pprint_cl_format__init_part0_A_const_47 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_48 any

var A_arbace_pprint_cl_format__init_part0_A_const_49 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_50 any

var A_arbace_pprint_cl_format__init_part0_A_const_51 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_52 any

var A_arbace_pprint_cl_format__init_part0_A_const_53 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_54 any

var A_arbace_pprint_cl_format__init_part0_A_const_55 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_56 any

var A_arbace_pprint_cl_format__init_part0_A_const_57 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_58 any

var A_arbace_pprint_cl_format__init_part0_A_const_59 any

var A_arbace_pprint_cl_format__init_part0_A_const_60 any

var A_arbace_pprint_cl_format__init_part0_A_const_61 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_62 any

var A_arbace_pprint_cl_format__init_part0_A_const_63 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_64 any

var A_arbace_pprint_cl_format__init_part0_A_const_65 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_66 any

var A_arbace_pprint_cl_format__init_part0_A_const_67 any

var A_arbace_pprint_cl_format__init_part0_A_const_68 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_69 any

var A_arbace_pprint_cl_format__init_part0_A_const_70 any

var A_arbace_pprint_cl_format__init_part0_A_const_71 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_72 any

var A_arbace_pprint_cl_format__init_part0_A_const_73 any

var A_arbace_pprint_cl_format__init_part0_A_const_74 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_75 any

var A_arbace_pprint_cl_format__init_part0_A_const_76 any

var A_arbace_pprint_cl_format__init_part0_A_const_77 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_78 any

var A_arbace_pprint_cl_format__init_part0_A_const_79 any

var A_arbace_pprint_cl_format__init_part0_A_const_80 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_81 any

var A_arbace_pprint_cl_format__init_part0_A_const_82 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_83 any

var A_arbace_pprint_cl_format__init_part0_A_const_84 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_85 any

var A_arbace_pprint_cl_format__init_part0_A_const_86 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_87 any

var A_arbace_pprint_cl_format__init_part0_A_const_88 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_89 any

var A_arbace_pprint_cl_format__init_part0_A_const_90 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_91 any

var A_arbace_pprint_cl_format__init_part0_A_const_92 any

var A_arbace_pprint_cl_format__init_part0_A_const_93 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_94 any

var A_arbace_pprint_cl_format__init_part0_A_const_95 any

var A_arbace_pprint_cl_format__init_part0_A_const_96 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_97 any

var A_arbace_pprint_cl_format__init_part0_A_const_98 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_99 any

var A_arbace_pprint_cl_format__init_part0_A_const_100 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_101 any

var A_arbace_pprint_cl_format__init_part0_A_const_102 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_103 any

var A_arbace_pprint_cl_format__init_part0_A_const_104 any

var A_arbace_pprint_cl_format__init_part0_A_const_105 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_106 any

var A_arbace_pprint_cl_format__init_part0_A_const_107 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_108 any

var A_arbace_pprint_cl_format__init_part0_A_const_109 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_110 any

var A_arbace_pprint_cl_format__init_part0_A_const_111 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_112 any

var A_arbace_pprint_cl_format__init_part0_A_const_113 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_114 any

var A_arbace_pprint_cl_format__init_part0_A_const_115 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_116 any

var A_arbace_pprint_cl_format__init_part0_A_const_117 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_118 any

var A_arbace_pprint_cl_format__init_part0_A_const_119 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_120 any

var A_arbace_pprint_cl_format__init_part0_A_const_121 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_122 any

var A_arbace_pprint_cl_format__init_part0_A_const_123 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_124 any

var A_arbace_pprint_cl_format__init_part0_A_const_125 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_126 any

var A_arbace_pprint_cl_format__init_part0_A_const_127 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_128 any

var A_arbace_pprint_cl_format__init_part0_A_const_129 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_130 any

var A_arbace_pprint_cl_format__init_part0_A_const_131 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_132 any

var A_arbace_pprint_cl_format__init_part0_A_const_133 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_134 any

var A_arbace_pprint_cl_format__init_part0_A_const_135 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_136 any

var A_arbace_pprint_cl_format__init_part0_A_const_137 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_138 any

var A_arbace_pprint_cl_format__init_part0_A_const_139 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_140 any

var A_arbace_pprint_cl_format__init_part0_A_const_141 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_142 any

var A_arbace_pprint_cl_format__init_part0_A_const_143 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_144 any

var A_arbace_pprint_cl_format__init_part0_A_const_145 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_146 any

var A_arbace_pprint_cl_format__init_part0_A_const_147 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_148 any

var A_arbace_pprint_cl_format__init_part0_A_const_149 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_150 any

var A_arbace_pprint_cl_format__init_part0_A_const_151 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_152 any

var A_arbace_pprint_cl_format__init_part0_A_const_153 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_154 any

var A_arbace_pprint_cl_format__init_part0_A_const_155 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_156 any

var A_arbace_pprint_cl_format__init_part0_A_const_157 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_158 any

var A_arbace_pprint_cl_format__init_part0_A_const_159 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_160 any

var A_arbace_pprint_cl_format__init_part0_A_const_161 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_162 any

var A_arbace_pprint_cl_format__init_part0_A_const_163 any

var A_arbace_pprint_cl_format__init_part0_A_const_164 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_165 any

var A_arbace_pprint_cl_format__init_part0_A_const_166 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_167 *jrt.Class

var A_arbace_pprint_cl_format__init_part0_A_const_168 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_169 any

var A_arbace_pprint_cl_format__init_part0_A_const_170 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_171 any

var A_arbace_pprint_cl_format__init_part0_A_const_172 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_173 any

var A_arbace_pprint_cl_format__init_part0_A_const_174 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_175 any

var A_arbace_pprint_cl_format__init_part0_A_const_176 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_177 any

var A_arbace_pprint_cl_format__init_part0_A_const_178 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_179 any

var A_arbace_pprint_cl_format__init_part0_A_const_180 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_181 any

var A_arbace_pprint_cl_format__init_part0_A_const_182 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_183 any

var A_arbace_pprint_cl_format__init_part0_A_const_184 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_185 any

var A_arbace_pprint_cl_format__init_part0_A_const_186 any

var A_arbace_pprint_cl_format__init_part0_A_const_187 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_188 any

var A_arbace_pprint_cl_format__init_part0_A_const_189 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_190 any

var A_arbace_pprint_cl_format__init_part0_A_const_191 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_192 any

var A_arbace_pprint_cl_format__init_part0_A_const_193 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_194 any

var A_arbace_pprint_cl_format__init_part0_A_const_195 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_196 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_197 any

var A_arbace_pprint_cl_format__init_part0_A_const_198 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_199 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_200 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_201 any

var A_arbace_pprint_cl_format__init_part0_A_const_202 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_203 any

var A_arbace_pprint_cl_format__init_part0_A_const_204 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_205 any

var A_arbace_pprint_cl_format__init_part0_A_const_206 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_207 any

var A_arbace_pprint_cl_format__init_part0_A_const_208 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_209 any

var A_arbace_pprint_cl_format__init_part0_A_const_210 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_211 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_212 any

var A_arbace_pprint_cl_format__init_part0_A_const_213 any

var A_arbace_pprint_cl_format__init_part0_A_const_214 any

var A_arbace_pprint_cl_format__init_part0_A_const_215 any

var A_arbace_pprint_cl_format__init_part0_A_const_216 any

var A_arbace_pprint_cl_format__init_part0_A_const_217 any

var A_arbace_pprint_cl_format__init_part0_A_const_218 any

var A_arbace_pprint_cl_format__init_part0_A_const_219 any

var A_arbace_pprint_cl_format__init_part0_A_const_220 any

var A_arbace_pprint_cl_format__init_part0_A_const_221 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_222 any

var A_arbace_pprint_cl_format__init_part0_A_const_223 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_224 any

var A_arbace_pprint_cl_format__init_part0_A_const_225 any

var A_arbace_pprint_cl_format__init_part0_A_const_226 any

var A_arbace_pprint_cl_format__init_part0_A_const_227 any

var A_arbace_pprint_cl_format__init_part0_A_const_228 any

var A_arbace_pprint_cl_format__init_part0_A_const_229 any

var A_arbace_pprint_cl_format__init_part0_A_const_230 any

var A_arbace_pprint_cl_format__init_part0_A_const_231 any

var A_arbace_pprint_cl_format__init_part0_A_const_232 any

var A_arbace_pprint_cl_format__init_part0_A_const_233 any

var A_arbace_pprint_cl_format__init_part0_A_const_234 any

var A_arbace_pprint_cl_format__init_part0_A_const_235 any

var A_arbace_pprint_cl_format__init_part0_A_const_236 any

var A_arbace_pprint_cl_format__init_part0_A_const_237 any

var A_arbace_pprint_cl_format__init_part0_A_const_238 any

var A_arbace_pprint_cl_format__init_part0_A_const_239 any

var A_arbace_pprint_cl_format__init_part0_A_const_240 any

var A_arbace_pprint_cl_format__init_part0_A_const_241 any

var A_arbace_pprint_cl_format__init_part0_A_const_242 any

var A_arbace_pprint_cl_format__init_part0_A_const_243 any

var A_arbace_pprint_cl_format__init_part0_A_const_244 any

var A_arbace_pprint_cl_format__init_part0_A_const_245 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_246 any

var A_arbace_pprint_cl_format__init_part0_A_const_247 any

var A_arbace_pprint_cl_format__init_part0_A_const_248 any

var A_arbace_pprint_cl_format__init_part0_A_const_249 any

var A_arbace_pprint_cl_format__init_part0_A_const_250 any

var A_arbace_pprint_cl_format__init_part0_A_const_251 any

var A_arbace_pprint_cl_format__init_part0_A_const_252 any

var A_arbace_pprint_cl_format__init_part0_A_const_253 any

var A_arbace_pprint_cl_format__init_part0_A_const_254 any

var A_arbace_pprint_cl_format__init_part0_A_const_255 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_256 any

var A_arbace_pprint_cl_format__init_part0_A_const_257 any

var A_arbace_pprint_cl_format__init_part0_A_const_258 any

var A_arbace_pprint_cl_format__init_part0_A_const_259 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_260 any

var A_arbace_pprint_cl_format__init_part0_A_const_261 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_262 any

var A_arbace_pprint_cl_format__init_part0_A_const_263 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_264 any

var A_arbace_pprint_cl_format__init_part0_A_const_265 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_266 any

var A_arbace_pprint_cl_format__init_part0_A_const_267 any

var A_arbace_pprint_cl_format__init_part0_A_const_268 any

var A_arbace_pprint_cl_format__init_part0_A_const_269 any

var A_arbace_pprint_cl_format__init_part0_A_const_270 any

var A_arbace_pprint_cl_format__init_part0_A_const_271 any

var A_arbace_pprint_cl_format__init_part0_A_const_272 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_273 any

var A_arbace_pprint_cl_format__init_part0_A_const_274 any

var A_arbace_pprint_cl_format__init_part0_A_const_275 any

var A_arbace_pprint_cl_format__init_part0_A_const_276 any

var A_arbace_pprint_cl_format__init_part0_A_const_277 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_278 any

var A_arbace_pprint_cl_format__init_part0_A_const_279 any

var A_arbace_pprint_cl_format__init_part0_A_const_280 any

var A_arbace_pprint_cl_format__init_part0_A_const_281 any

var A_arbace_pprint_cl_format__init_part0_A_const_282 any

var A_arbace_pprint_cl_format__init_part0_A_const_283 any

var A_arbace_pprint_cl_format__init_part0_A_const_284 any

var A_arbace_pprint_cl_format__init_part0_A_const_285 any

var A_arbace_pprint_cl_format__init_part0_A_const_286 any

var A_arbace_pprint_cl_format__init_part0_A_const_287 any

var A_arbace_pprint_cl_format__init_part0_A_const_288 any

var A_arbace_pprint_cl_format__init_part0_A_const_289 any

var A_arbace_pprint_cl_format__init_part0_A_const_290 any

var A_arbace_pprint_cl_format__init_part0_A_const_291 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_292 any

var A_arbace_pprint_cl_format__init_part0_A_const_293 any

var A_arbace_pprint_cl_format__init_part0_A_const_294 any

var A_arbace_pprint_cl_format__init_part0_A_const_295 any

var A_arbace_pprint_cl_format__init_part0_A_const_296 any

var A_arbace_pprint_cl_format__init_part0_A_const_297 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_298 any

var A_arbace_pprint_cl_format__init_part0_A_const_299 any

var A_arbace_pprint_cl_format__init_part0_A_const_300 any

var A_arbace_pprint_cl_format__init_part0_A_const_301 any

var A_arbace_pprint_cl_format__init_part0_A_const_302 any

var A_arbace_pprint_cl_format__init_part0_A_const_303 any

var A_arbace_pprint_cl_format__init_part0_A_const_304 any

var A_arbace_pprint_cl_format__init_part0_A_const_305 any

var A_arbace_pprint_cl_format__init_part0_A_const_306 any

var A_arbace_pprint_cl_format__init_part0_A_const_307 any

var A_arbace_pprint_cl_format__init_part0_A_const_308 any

var A_arbace_pprint_cl_format__init_part0_A_const_309 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_310 any

var A_arbace_pprint_cl_format__init_part0_A_const_311 any

var A_arbace_pprint_cl_format__init_part0_A_const_312 any

var A_arbace_pprint_cl_format__init_part0_A_const_313 any

var A_arbace_pprint_cl_format__init_part0_A_const_314 any

var A_arbace_pprint_cl_format__init_part0_A_const_315 any

var A_arbace_pprint_cl_format__init_part0_A_const_316 any

var A_arbace_pprint_cl_format__init_part0_A_const_317 any

var A_arbace_pprint_cl_format__init_part0_A_const_318 any

var A_arbace_pprint_cl_format__init_part0_A_const_319 any

var A_arbace_pprint_cl_format__init_part0_A_const_320 any

var A_arbace_pprint_cl_format__init_part0_A_const_321 any

var A_arbace_pprint_cl_format__init_part0_A_const_322 any

var A_arbace_pprint_cl_format__init_part0_A_const_323 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_324 any

var A_arbace_pprint_cl_format__init_part0_A_const_325 any

var A_arbace_pprint_cl_format__init_part0_A_const_326 any

var A_arbace_pprint_cl_format__init_part0_A_const_327 any

var A_arbace_pprint_cl_format__init_part0_A_const_328 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_329 any

var A_arbace_pprint_cl_format__init_part0_A_const_330 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_331 any

var A_arbace_pprint_cl_format__init_part0_A_const_332 any

var A_arbace_pprint_cl_format__init_part0_A_const_333 any

var A_arbace_pprint_cl_format__init_part0_A_const_334 any

var A_arbace_pprint_cl_format__init_part0_A_const_335 any

var A_arbace_pprint_cl_format__init_part0_A_const_336 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_337 any

var A_arbace_pprint_cl_format__init_part0_A_const_338 any

var A_arbace_pprint_cl_format__init_part0_A_const_339 any

var A_arbace_pprint_cl_format__init_part0_A_const_340 any

var A_arbace_pprint_cl_format__init_part0_A_const_341 any

var A_arbace_pprint_cl_format__init_part0_A_const_342 any

var A_arbace_pprint_cl_format__init_part0_A_const_343 any

var A_arbace_pprint_cl_format__init_part0_A_const_344 any

var A_arbace_pprint_cl_format__init_part0_A_const_345 any

var A_arbace_pprint_cl_format__init_part0_A_const_346 any

var A_arbace_pprint_cl_format__init_part0_A_const_347 any

var A_arbace_pprint_cl_format__init_part0_A_const_348 any

var A_arbace_pprint_cl_format__init_part0_A_const_349 any

var A_arbace_pprint_cl_format__init_part0_A_const_350 any

var A_arbace_pprint_cl_format__init_part0_A_const_351 any

var A_arbace_pprint_cl_format__init_part0_A_const_352 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_353 any

var A_arbace_pprint_cl_format__init_part0_A_const_354 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_355 any

var A_arbace_pprint_cl_format__init_part0_A_const_356 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_357 any

var A_arbace_pprint_cl_format__init_part0_A_const_358 any

var A_arbace_pprint_cl_format__init_part0_A_const_359 any

var A_arbace_pprint_cl_format__init_part0_A_const_360 any

var A_arbace_pprint_cl_format__init_part0_A_const_361 any

var A_arbace_pprint_cl_format__init_part0_A_const_362 any

var A_arbace_pprint_cl_format__init_part0_A_const_363 any

var A_arbace_pprint_cl_format__init_part0_A_const_364 any

var A_arbace_pprint_cl_format__init_part0_A_const_365 any

var A_arbace_pprint_cl_format__init_part0_A_const_366 any

var A_arbace_pprint_cl_format__init_part0_A_const_367 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_368 any

var A_arbace_pprint_cl_format__init_part0_A_const_369 any

var A_arbace_pprint_cl_format__init_part0_A_const_370 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_371 any

var A_arbace_pprint_cl_format__init_part0_A_const_372 any

var A_arbace_pprint_cl_format__init_part0_A_const_373 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_374 any

var A_arbace_pprint_cl_format__init_part0_A_const_375 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_376 any

var A_arbace_pprint_cl_format__init_part0_A_const_377 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_378 any

var A_arbace_pprint_cl_format__init_part0_A_const_379 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_380 any

var A_arbace_pprint_cl_format__init_part0_A_const_381 any

var A_arbace_pprint_cl_format__init_part0_A_const_382 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_383 any

var A_arbace_pprint_cl_format__init_part0_A_init jrt.ClassInit

func A_arbace_pprint_cl_format__init_part0_A_Init() { if !A_arbace_pprint_cl_format__init_part0_A_init.Done() { A_arbace_pprint_cl_format__init_part0_A_init.Run(A_arbace_pprint_cl_format__init_part0_A_clinit) } }

func A_arbace_pprint_cl_format__init_part0_A_clinit() { A_arbace_pprint_cl_format__init_part0_A_clinit_p0(); A_arbace_pprint_cl_format__init_part0_A_clinit_p1(); A_arbace_pprint_cl_format__init_part0_A_clinit_p2(); A_arbace_pprint_cl_format__init_part0_A_clinit_p3(); A_arbace_pprint_cl_format__init_part0_A_clinit_p4(); A_arbace_pprint_cl_format__init_part0_A_clinit_p5(); A_arbace_pprint_cl_format__init_part0_A_clinit_p6(); A_arbace_pprint_cl_format__init_part0_A_clinit_p7(); A_arbace_pprint_cl_format__init_part0_A_clinit_p8(); A_arbace_pprint_cl_format__init_part0_A_clinit_p9(); A_arbace_pprint_cl_format__init_part0_A_clinit_p10(); A_arbace_pprint_cl_format__init_part0_A_clinit_p11(); A_arbace_pprint_cl_format__init_part0_A_clinit_p12(); A_arbace_pprint_cl_format__init_part0_A_clinit_p13(); A_arbace_pprint_cl_format__init_part0_A_clinit_p14(); A_arbace_pprint_cl_format__init_part0_A_clinit_p15(); A_arbace_pprint_cl_format__init_part0_A_clinit_p16(); A_arbace_pprint_cl_format__init_part0_A_clinit_p17(); A_arbace_pprint_cl_format__init_part0_A_clinit_p18(); A_arbace_pprint_cl_format__init_part0_A_clinit_p19(); A_arbace_pprint_cl_format__init_part0_A_clinit_p20(); A_arbace_pprint_cl_format__init_part0_A_clinit_p21(); A_arbace_pprint_cl_format__init_part0_A_clinit_p22(); A_arbace_pprint_cl_format__init_part0_A_clinit_p23(); A_arbace_pprint_cl_format__init_part0_A_clinit_p24(); A_arbace_pprint_cl_format__init_part0_A_clinit_p25(); A_arbace_pprint_cl_format__init_part0_A_clinit_p26(); A_arbace_pprint_cl_format__init_part0_A_clinit_p27() }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_pprint_cl_format__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 491); A_arbace_pprint_cl_format__init_part0_A_const_0 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[107]); A_arbace_pprint_cl_format__init_part0_A_const_1 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[108]; A_arbace_pprint_cl_format__init_part0_A_const_2 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[109]); A_arbace_pprint_cl_format__init_part0_A_const_3 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[110]; A_arbace_pprint_cl_format__init_part0_A_const_4 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[111]); A_arbace_pprint_cl_format__init_part0_A_const_5 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[112]; A_arbace_pprint_cl_format__init_part0_A_const_6 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[113]); A_arbace_pprint_cl_format__init_part0_A_const_7 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[114]; A_arbace_pprint_cl_format__init_part0_A_const_8 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[115]); A_arbace_pprint_cl_format__init_part0_A_const_9 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[116]; A_arbace_pprint_cl_format__init_part0_A_const_10 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[117]); A_arbace_pprint_cl_format__init_part0_A_const_11 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[118] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p1() { A_arbace_pprint_cl_format__init_part0_A_const_12 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[119]); A_arbace_pprint_cl_format__init_part0_A_const_13 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[120]; A_arbace_pprint_cl_format__init_part0_A_const_14 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[121]); A_arbace_pprint_cl_format__init_part0_A_const_15 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[122]); A_arbace_pprint_cl_format__init_part0_A_const_16 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[123]); A_arbace_pprint_cl_format__init_part0_A_const_17 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[124]); A_arbace_pprint_cl_format__init_part0_A_const_18 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[125]); A_arbace_pprint_cl_format__init_part0_A_const_19 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[126]; A_arbace_pprint_cl_format__init_part0_A_const_20 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[127]; A_arbace_pprint_cl_format__init_part0_A_const_21 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[128]); A_arbace_pprint_cl_format__init_part0_A_const_22 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[129]; A_arbace_pprint_cl_format__init_part0_A_const_23 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[130]); A_arbace_pprint_cl_format__init_part0_A_const_24 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[131] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p2() { A_arbace_pprint_cl_format__init_part0_A_const_25 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[132]); A_arbace_pprint_cl_format__init_part0_A_const_26 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[133]; A_arbace_pprint_cl_format__init_part0_A_const_27 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[134]); A_arbace_pprint_cl_format__init_part0_A_const_28 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[135]; A_arbace_pprint_cl_format__init_part0_A_const_29 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[136]); A_arbace_pprint_cl_format__init_part0_A_const_30 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[137]; A_arbace_pprint_cl_format__init_part0_A_const_31 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[138]; A_arbace_pprint_cl_format__init_part0_A_const_32 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[139]); A_arbace_pprint_cl_format__init_part0_A_const_33 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[140]); A_arbace_pprint_cl_format__init_part0_A_const_34 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[141]); A_arbace_pprint_cl_format__init_part0_A_const_35 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[142]); A_arbace_pprint_cl_format__init_part0_A_const_36 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[143]); A_arbace_pprint_cl_format__init_part0_A_const_37 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[144] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p3() { A_arbace_pprint_cl_format__init_part0_A_const_38 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[145]); A_arbace_pprint_cl_format__init_part0_A_const_39 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[146]; A_arbace_pprint_cl_format__init_part0_A_const_40 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[147]); A_arbace_pprint_cl_format__init_part0_A_const_41 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[148]; A_arbace_pprint_cl_format__init_part0_A_const_42 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[149]); A_arbace_pprint_cl_format__init_part0_A_const_43 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[150]; A_arbace_pprint_cl_format__init_part0_A_const_44 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[151]); A_arbace_pprint_cl_format__init_part0_A_const_45 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[152]; A_arbace_pprint_cl_format__init_part0_A_const_46 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[153]; A_arbace_pprint_cl_format__init_part0_A_const_47 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[154]); A_arbace_pprint_cl_format__init_part0_A_const_48 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[155]; A_arbace_pprint_cl_format__init_part0_A_const_49 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[156]); A_arbace_pprint_cl_format__init_part0_A_const_50 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[157] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p4() { A_arbace_pprint_cl_format__init_part0_A_const_51 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[158]); A_arbace_pprint_cl_format__init_part0_A_const_52 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[159]; A_arbace_pprint_cl_format__init_part0_A_const_53 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[160]); A_arbace_pprint_cl_format__init_part0_A_const_54 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[161]; A_arbace_pprint_cl_format__init_part0_A_const_55 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[162]); A_arbace_pprint_cl_format__init_part0_A_const_56 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[163]; A_arbace_pprint_cl_format__init_part0_A_const_57 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[164]); A_arbace_pprint_cl_format__init_part0_A_const_58 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[165]; A_arbace_pprint_cl_format__init_part0_A_const_59 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[166]; A_arbace_pprint_cl_format__init_part0_A_const_60 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[167]; A_arbace_pprint_cl_format__init_part0_A_const_61 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[168]); A_arbace_pprint_cl_format__init_part0_A_const_62 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[169]; A_arbace_pprint_cl_format__init_part0_A_const_63 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[170]); A_arbace_pprint_cl_format__init_part0_A_const_64 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[171] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p5() { A_arbace_pprint_cl_format__init_part0_A_const_65 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[172]); A_arbace_pprint_cl_format__init_part0_A_const_66 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[173]; A_arbace_pprint_cl_format__init_part0_A_const_67 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[174]; A_arbace_pprint_cl_format__init_part0_A_const_68 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[175]); A_arbace_pprint_cl_format__init_part0_A_const_69 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[176]; A_arbace_pprint_cl_format__init_part0_A_const_70 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[177]; A_arbace_pprint_cl_format__init_part0_A_const_71 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[178]); A_arbace_pprint_cl_format__init_part0_A_const_72 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[179]; A_arbace_pprint_cl_format__init_part0_A_const_73 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[180]; A_arbace_pprint_cl_format__init_part0_A_const_74 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[181]); A_arbace_pprint_cl_format__init_part0_A_const_75 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[182]; A_arbace_pprint_cl_format__init_part0_A_const_76 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[183]; A_arbace_pprint_cl_format__init_part0_A_const_77 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[184]); A_arbace_pprint_cl_format__init_part0_A_const_78 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[185] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p6() { A_arbace_pprint_cl_format__init_part0_A_const_79 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[186]; A_arbace_pprint_cl_format__init_part0_A_const_80 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[187]); A_arbace_pprint_cl_format__init_part0_A_const_81 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[188]; A_arbace_pprint_cl_format__init_part0_A_const_82 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[189]); A_arbace_pprint_cl_format__init_part0_A_const_83 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[190]; A_arbace_pprint_cl_format__init_part0_A_const_84 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[191]); A_arbace_pprint_cl_format__init_part0_A_const_85 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[192]; A_arbace_pprint_cl_format__init_part0_A_const_86 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[193]); A_arbace_pprint_cl_format__init_part0_A_const_87 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[194]; A_arbace_pprint_cl_format__init_part0_A_const_88 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[195]); A_arbace_pprint_cl_format__init_part0_A_const_89 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[196]; A_arbace_pprint_cl_format__init_part0_A_const_90 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[197]); A_arbace_pprint_cl_format__init_part0_A_const_91 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[198]; A_arbace_pprint_cl_format__init_part0_A_const_92 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[199] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p7() { A_arbace_pprint_cl_format__init_part0_A_const_93 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[200]); A_arbace_pprint_cl_format__init_part0_A_const_94 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[201]; A_arbace_pprint_cl_format__init_part0_A_const_95 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[202]; A_arbace_pprint_cl_format__init_part0_A_const_96 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[203]); A_arbace_pprint_cl_format__init_part0_A_const_97 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[204]; A_arbace_pprint_cl_format__init_part0_A_const_98 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[205]); A_arbace_pprint_cl_format__init_part0_A_const_99 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[206]; A_arbace_pprint_cl_format__init_part0_A_const_100 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[207]); A_arbace_pprint_cl_format__init_part0_A_const_101 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[208]; A_arbace_pprint_cl_format__init_part0_A_const_102 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[209]); A_arbace_pprint_cl_format__init_part0_A_const_103 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[210]; A_arbace_pprint_cl_format__init_part0_A_const_104 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[211]; A_arbace_pprint_cl_format__init_part0_A_const_105 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[212]); A_arbace_pprint_cl_format__init_part0_A_const_106 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[213] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p8() { A_arbace_pprint_cl_format__init_part0_A_const_107 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[214]); A_arbace_pprint_cl_format__init_part0_A_const_108 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[215]; A_arbace_pprint_cl_format__init_part0_A_const_109 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[216]); A_arbace_pprint_cl_format__init_part0_A_const_110 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[217]; A_arbace_pprint_cl_format__init_part0_A_const_111 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[218]); A_arbace_pprint_cl_format__init_part0_A_const_112 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[219]; A_arbace_pprint_cl_format__init_part0_A_const_113 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[220]); A_arbace_pprint_cl_format__init_part0_A_const_114 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[221]; A_arbace_pprint_cl_format__init_part0_A_const_115 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[222]); A_arbace_pprint_cl_format__init_part0_A_const_116 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[223]; A_arbace_pprint_cl_format__init_part0_A_const_117 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[224]); A_arbace_pprint_cl_format__init_part0_A_const_118 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[225]; A_arbace_pprint_cl_format__init_part0_A_const_119 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[226]) }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p9() { A_arbace_pprint_cl_format__init_part0_A_const_120 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[227]; A_arbace_pprint_cl_format__init_part0_A_const_121 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[228]); A_arbace_pprint_cl_format__init_part0_A_const_122 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[229]; A_arbace_pprint_cl_format__init_part0_A_const_123 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[230]); A_arbace_pprint_cl_format__init_part0_A_const_124 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[231]; A_arbace_pprint_cl_format__init_part0_A_const_125 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[232]); A_arbace_pprint_cl_format__init_part0_A_const_126 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[233]; A_arbace_pprint_cl_format__init_part0_A_const_127 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[234]); A_arbace_pprint_cl_format__init_part0_A_const_128 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[235]; A_arbace_pprint_cl_format__init_part0_A_const_129 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[236]); A_arbace_pprint_cl_format__init_part0_A_const_130 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[237]; A_arbace_pprint_cl_format__init_part0_A_const_131 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[238]); A_arbace_pprint_cl_format__init_part0_A_const_132 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[239] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p10() { A_arbace_pprint_cl_format__init_part0_A_const_133 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[240]); A_arbace_pprint_cl_format__init_part0_A_const_134 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[241]; A_arbace_pprint_cl_format__init_part0_A_const_135 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[242]); A_arbace_pprint_cl_format__init_part0_A_const_136 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[243]; A_arbace_pprint_cl_format__init_part0_A_const_137 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[244]); A_arbace_pprint_cl_format__init_part0_A_const_138 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[245]; A_arbace_pprint_cl_format__init_part0_A_const_139 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[246]); A_arbace_pprint_cl_format__init_part0_A_const_140 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[247]; A_arbace_pprint_cl_format__init_part0_A_const_141 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[248]); A_arbace_pprint_cl_format__init_part0_A_const_142 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[249]; A_arbace_pprint_cl_format__init_part0_A_const_143 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[250]); A_arbace_pprint_cl_format__init_part0_A_const_144 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[251]; A_arbace_pprint_cl_format__init_part0_A_const_145 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[252]) }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p11() { A_arbace_pprint_cl_format__init_part0_A_const_146 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[253]; A_arbace_pprint_cl_format__init_part0_A_const_147 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[254]); A_arbace_pprint_cl_format__init_part0_A_const_148 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[255]; A_arbace_pprint_cl_format__init_part0_A_const_149 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[256]); A_arbace_pprint_cl_format__init_part0_A_const_150 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[257]; A_arbace_pprint_cl_format__init_part0_A_const_151 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[258]); A_arbace_pprint_cl_format__init_part0_A_const_152 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[259]; A_arbace_pprint_cl_format__init_part0_A_const_153 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[260]); A_arbace_pprint_cl_format__init_part0_A_const_154 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[261]; A_arbace_pprint_cl_format__init_part0_A_const_155 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[262]); A_arbace_pprint_cl_format__init_part0_A_const_156 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[263]; A_arbace_pprint_cl_format__init_part0_A_const_157 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[264]); A_arbace_pprint_cl_format__init_part0_A_const_158 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[265] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p12() { A_arbace_pprint_cl_format__init_part0_A_const_159 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[266]); A_arbace_pprint_cl_format__init_part0_A_const_160 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[267]; A_arbace_pprint_cl_format__init_part0_A_const_161 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[268]); A_arbace_pprint_cl_format__init_part0_A_const_162 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[269]; A_arbace_pprint_cl_format__init_part0_A_const_163 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[270]; A_arbace_pprint_cl_format__init_part0_A_const_164 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[271]); A_arbace_pprint_cl_format__init_part0_A_const_165 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[272]; A_arbace_pprint_cl_format__init_part0_A_const_166 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[273]); A_arbace_pprint_cl_format__init_part0_A_const_167 = jrt.Class_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[274]); A_arbace_pprint_cl_format__init_part0_A_const_168 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[275]); A_arbace_pprint_cl_format__init_part0_A_const_169 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[276]; A_arbace_pprint_cl_format__init_part0_A_const_170 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[277]); A_arbace_pprint_cl_format__init_part0_A_const_171 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[278] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p13() { A_arbace_pprint_cl_format__init_part0_A_const_172 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[279]); A_arbace_pprint_cl_format__init_part0_A_const_173 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[280]; A_arbace_pprint_cl_format__init_part0_A_const_174 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[281]); A_arbace_pprint_cl_format__init_part0_A_const_175 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[282]; A_arbace_pprint_cl_format__init_part0_A_const_176 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[283]); A_arbace_pprint_cl_format__init_part0_A_const_177 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[284]; A_arbace_pprint_cl_format__init_part0_A_const_178 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[285]); A_arbace_pprint_cl_format__init_part0_A_const_179 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[286]; A_arbace_pprint_cl_format__init_part0_A_const_180 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[287]); A_arbace_pprint_cl_format__init_part0_A_const_181 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[288]; A_arbace_pprint_cl_format__init_part0_A_const_182 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[289]); A_arbace_pprint_cl_format__init_part0_A_const_183 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[290]; A_arbace_pprint_cl_format__init_part0_A_const_184 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[291]) }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p14() { A_arbace_pprint_cl_format__init_part0_A_const_185 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[292]; A_arbace_pprint_cl_format__init_part0_A_const_186 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[293]; A_arbace_pprint_cl_format__init_part0_A_const_187 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[294]); A_arbace_pprint_cl_format__init_part0_A_const_188 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[295]; A_arbace_pprint_cl_format__init_part0_A_const_189 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[296]); A_arbace_pprint_cl_format__init_part0_A_const_190 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[297]; A_arbace_pprint_cl_format__init_part0_A_const_191 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[298]); A_arbace_pprint_cl_format__init_part0_A_const_192 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[299]; A_arbace_pprint_cl_format__init_part0_A_const_193 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[300]); A_arbace_pprint_cl_format__init_part0_A_const_194 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[301]; A_arbace_pprint_cl_format__init_part0_A_const_195 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[302]); A_arbace_pprint_cl_format__init_part0_A_const_196 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[303]); A_arbace_pprint_cl_format__init_part0_A_const_197 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[304] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p15() { A_arbace_pprint_cl_format__init_part0_A_const_198 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[305]); A_arbace_pprint_cl_format__init_part0_A_const_199 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[306]); A_arbace_pprint_cl_format__init_part0_A_const_200 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[307]); A_arbace_pprint_cl_format__init_part0_A_const_201 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[308]; A_arbace_pprint_cl_format__init_part0_A_const_202 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[309]); A_arbace_pprint_cl_format__init_part0_A_const_203 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[310]; A_arbace_pprint_cl_format__init_part0_A_const_204 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[311]); A_arbace_pprint_cl_format__init_part0_A_const_205 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[312]; A_arbace_pprint_cl_format__init_part0_A_const_206 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[313]); A_arbace_pprint_cl_format__init_part0_A_const_207 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[314]; A_arbace_pprint_cl_format__init_part0_A_const_208 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[315]); A_arbace_pprint_cl_format__init_part0_A_const_209 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[316]; A_arbace_pprint_cl_format__init_part0_A_const_210 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[317]) }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p16() { A_arbace_pprint_cl_format__init_part0_A_const_211 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[318]); A_arbace_pprint_cl_format__init_part0_A_const_212 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[319]; A_arbace_pprint_cl_format__init_part0_A_const_213 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[320]; A_arbace_pprint_cl_format__init_part0_A_const_214 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[321]; A_arbace_pprint_cl_format__init_part0_A_const_215 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[322]; A_arbace_pprint_cl_format__init_part0_A_const_216 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[323]; A_arbace_pprint_cl_format__init_part0_A_const_217 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[324]; A_arbace_pprint_cl_format__init_part0_A_const_218 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[325]; A_arbace_pprint_cl_format__init_part0_A_const_219 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[326]; A_arbace_pprint_cl_format__init_part0_A_const_220 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[327]; A_arbace_pprint_cl_format__init_part0_A_const_221 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[328]); A_arbace_pprint_cl_format__init_part0_A_const_222 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[329]; A_arbace_pprint_cl_format__init_part0_A_const_223 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[330]); A_arbace_pprint_cl_format__init_part0_A_const_224 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[331]; A_arbace_pprint_cl_format__init_part0_A_const_225 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[332] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p17() { A_arbace_pprint_cl_format__init_part0_A_const_226 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[333]; A_arbace_pprint_cl_format__init_part0_A_const_227 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[334]; A_arbace_pprint_cl_format__init_part0_A_const_228 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[335]; A_arbace_pprint_cl_format__init_part0_A_const_229 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[336]; A_arbace_pprint_cl_format__init_part0_A_const_230 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[337]; A_arbace_pprint_cl_format__init_part0_A_const_231 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[338]; A_arbace_pprint_cl_format__init_part0_A_const_232 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[339]; A_arbace_pprint_cl_format__init_part0_A_const_233 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[340]; A_arbace_pprint_cl_format__init_part0_A_const_234 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[341]; A_arbace_pprint_cl_format__init_part0_A_const_235 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[342]; A_arbace_pprint_cl_format__init_part0_A_const_236 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[343]; A_arbace_pprint_cl_format__init_part0_A_const_237 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[344]; A_arbace_pprint_cl_format__init_part0_A_const_238 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[345]; A_arbace_pprint_cl_format__init_part0_A_const_239 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[346]; A_arbace_pprint_cl_format__init_part0_A_const_240 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[347]; A_arbace_pprint_cl_format__init_part0_A_const_241 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[348] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p18() { A_arbace_pprint_cl_format__init_part0_A_const_242 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[349]; A_arbace_pprint_cl_format__init_part0_A_const_243 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[350]; A_arbace_pprint_cl_format__init_part0_A_const_244 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[351]; A_arbace_pprint_cl_format__init_part0_A_const_245 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[352]); A_arbace_pprint_cl_format__init_part0_A_const_246 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[353]; A_arbace_pprint_cl_format__init_part0_A_const_247 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[354]; A_arbace_pprint_cl_format__init_part0_A_const_248 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[355]; A_arbace_pprint_cl_format__init_part0_A_const_249 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[356]; A_arbace_pprint_cl_format__init_part0_A_const_250 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[357]; A_arbace_pprint_cl_format__init_part0_A_const_251 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[358]; A_arbace_pprint_cl_format__init_part0_A_const_252 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[359]; A_arbace_pprint_cl_format__init_part0_A_const_253 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[360]; A_arbace_pprint_cl_format__init_part0_A_const_254 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[361]; A_arbace_pprint_cl_format__init_part0_A_const_255 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[362]); A_arbace_pprint_cl_format__init_part0_A_const_256 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[363] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p19() { A_arbace_pprint_cl_format__init_part0_A_const_257 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[364]; A_arbace_pprint_cl_format__init_part0_A_const_258 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[365]; A_arbace_pprint_cl_format__init_part0_A_const_259 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[366]); A_arbace_pprint_cl_format__init_part0_A_const_260 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[367]; A_arbace_pprint_cl_format__init_part0_A_const_261 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[368]); A_arbace_pprint_cl_format__init_part0_A_const_262 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[369]; A_arbace_pprint_cl_format__init_part0_A_const_263 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[370]); A_arbace_pprint_cl_format__init_part0_A_const_264 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[371]; A_arbace_pprint_cl_format__init_part0_A_const_265 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[372]); A_arbace_pprint_cl_format__init_part0_A_const_266 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[373]; A_arbace_pprint_cl_format__init_part0_A_const_267 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[374]; A_arbace_pprint_cl_format__init_part0_A_const_268 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[375]; A_arbace_pprint_cl_format__init_part0_A_const_269 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[376]; A_arbace_pprint_cl_format__init_part0_A_const_270 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[377] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p20() { A_arbace_pprint_cl_format__init_part0_A_const_271 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[378]; A_arbace_pprint_cl_format__init_part0_A_const_272 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[379]); A_arbace_pprint_cl_format__init_part0_A_const_273 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[380]; A_arbace_pprint_cl_format__init_part0_A_const_274 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[381]; A_arbace_pprint_cl_format__init_part0_A_const_275 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[382]; A_arbace_pprint_cl_format__init_part0_A_const_276 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[383]; A_arbace_pprint_cl_format__init_part0_A_const_277 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[384]); A_arbace_pprint_cl_format__init_part0_A_const_278 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[385]; A_arbace_pprint_cl_format__init_part0_A_const_279 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[386]; A_arbace_pprint_cl_format__init_part0_A_const_280 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[387]; A_arbace_pprint_cl_format__init_part0_A_const_281 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[388]; A_arbace_pprint_cl_format__init_part0_A_const_282 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[389]; A_arbace_pprint_cl_format__init_part0_A_const_283 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[390]; A_arbace_pprint_cl_format__init_part0_A_const_284 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[391]; A_arbace_pprint_cl_format__init_part0_A_const_285 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[392] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p21() { A_arbace_pprint_cl_format__init_part0_A_const_286 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[393]; A_arbace_pprint_cl_format__init_part0_A_const_287 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[394]; A_arbace_pprint_cl_format__init_part0_A_const_288 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[395]; A_arbace_pprint_cl_format__init_part0_A_const_289 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[396]; A_arbace_pprint_cl_format__init_part0_A_const_290 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[397]; A_arbace_pprint_cl_format__init_part0_A_const_291 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[398]); A_arbace_pprint_cl_format__init_part0_A_const_292 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[399]; A_arbace_pprint_cl_format__init_part0_A_const_293 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[400]; A_arbace_pprint_cl_format__init_part0_A_const_294 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[401]; A_arbace_pprint_cl_format__init_part0_A_const_295 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[402]; A_arbace_pprint_cl_format__init_part0_A_const_296 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[403]; A_arbace_pprint_cl_format__init_part0_A_const_297 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[404]); A_arbace_pprint_cl_format__init_part0_A_const_298 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[405]; A_arbace_pprint_cl_format__init_part0_A_const_299 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[406]; A_arbace_pprint_cl_format__init_part0_A_const_300 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[407] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p22() { A_arbace_pprint_cl_format__init_part0_A_const_301 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[408]; A_arbace_pprint_cl_format__init_part0_A_const_302 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[409]; A_arbace_pprint_cl_format__init_part0_A_const_303 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[410]; A_arbace_pprint_cl_format__init_part0_A_const_304 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[411]; A_arbace_pprint_cl_format__init_part0_A_const_305 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[412]; A_arbace_pprint_cl_format__init_part0_A_const_306 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[413]; A_arbace_pprint_cl_format__init_part0_A_const_307 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[414]; A_arbace_pprint_cl_format__init_part0_A_const_308 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[415]; A_arbace_pprint_cl_format__init_part0_A_const_309 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[416]); A_arbace_pprint_cl_format__init_part0_A_const_310 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[417]; A_arbace_pprint_cl_format__init_part0_A_const_311 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[418]; A_arbace_pprint_cl_format__init_part0_A_const_312 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[419]; A_arbace_pprint_cl_format__init_part0_A_const_313 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[420]; A_arbace_pprint_cl_format__init_part0_A_const_314 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[421]; A_arbace_pprint_cl_format__init_part0_A_const_315 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[422] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p23() { A_arbace_pprint_cl_format__init_part0_A_const_316 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[423]; A_arbace_pprint_cl_format__init_part0_A_const_317 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[424]; A_arbace_pprint_cl_format__init_part0_A_const_318 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[425]; A_arbace_pprint_cl_format__init_part0_A_const_319 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[426]; A_arbace_pprint_cl_format__init_part0_A_const_320 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[427]; A_arbace_pprint_cl_format__init_part0_A_const_321 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[428]; A_arbace_pprint_cl_format__init_part0_A_const_322 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[429]; A_arbace_pprint_cl_format__init_part0_A_const_323 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[430]); A_arbace_pprint_cl_format__init_part0_A_const_324 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[431]; A_arbace_pprint_cl_format__init_part0_A_const_325 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[432]; A_arbace_pprint_cl_format__init_part0_A_const_326 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[433]; A_arbace_pprint_cl_format__init_part0_A_const_327 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[434]; A_arbace_pprint_cl_format__init_part0_A_const_328 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[435]); A_arbace_pprint_cl_format__init_part0_A_const_329 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[436]; A_arbace_pprint_cl_format__init_part0_A_const_330 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[437]) }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p24() { A_arbace_pprint_cl_format__init_part0_A_const_331 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[438]; A_arbace_pprint_cl_format__init_part0_A_const_332 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[439]; A_arbace_pprint_cl_format__init_part0_A_const_333 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[440]; A_arbace_pprint_cl_format__init_part0_A_const_334 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[441]; A_arbace_pprint_cl_format__init_part0_A_const_335 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[442]; A_arbace_pprint_cl_format__init_part0_A_const_336 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[443]); A_arbace_pprint_cl_format__init_part0_A_const_337 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[444]; A_arbace_pprint_cl_format__init_part0_A_const_338 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[445]; A_arbace_pprint_cl_format__init_part0_A_const_339 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[446]; A_arbace_pprint_cl_format__init_part0_A_const_340 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[447]; A_arbace_pprint_cl_format__init_part0_A_const_341 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[448]; A_arbace_pprint_cl_format__init_part0_A_const_342 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[449]; A_arbace_pprint_cl_format__init_part0_A_const_343 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[450]; A_arbace_pprint_cl_format__init_part0_A_const_344 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[451]; A_arbace_pprint_cl_format__init_part0_A_const_345 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[452] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p25() { A_arbace_pprint_cl_format__init_part0_A_const_346 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[453]; A_arbace_pprint_cl_format__init_part0_A_const_347 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[454]; A_arbace_pprint_cl_format__init_part0_A_const_348 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[455]; A_arbace_pprint_cl_format__init_part0_A_const_349 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[456]; A_arbace_pprint_cl_format__init_part0_A_const_350 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[457]; A_arbace_pprint_cl_format__init_part0_A_const_351 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[458]; A_arbace_pprint_cl_format__init_part0_A_const_352 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[459]); A_arbace_pprint_cl_format__init_part0_A_const_353 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[460]; A_arbace_pprint_cl_format__init_part0_A_const_354 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[461]); A_arbace_pprint_cl_format__init_part0_A_const_355 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[462]; A_arbace_pprint_cl_format__init_part0_A_const_356 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[463]); A_arbace_pprint_cl_format__init_part0_A_const_357 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[464]; A_arbace_pprint_cl_format__init_part0_A_const_358 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[465]; A_arbace_pprint_cl_format__init_part0_A_const_359 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[466]; A_arbace_pprint_cl_format__init_part0_A_const_360 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[467] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p26() { A_arbace_pprint_cl_format__init_part0_A_const_361 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[468]; A_arbace_pprint_cl_format__init_part0_A_const_362 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[469]; A_arbace_pprint_cl_format__init_part0_A_const_363 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[470]; A_arbace_pprint_cl_format__init_part0_A_const_364 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[471]; A_arbace_pprint_cl_format__init_part0_A_const_365 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[472]; A_arbace_pprint_cl_format__init_part0_A_const_366 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[473]; A_arbace_pprint_cl_format__init_part0_A_const_367 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[474]); A_arbace_pprint_cl_format__init_part0_A_const_368 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[475]; A_arbace_pprint_cl_format__init_part0_A_const_369 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[476]; A_arbace_pprint_cl_format__init_part0_A_const_370 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[477]); A_arbace_pprint_cl_format__init_part0_A_const_371 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[478]; A_arbace_pprint_cl_format__init_part0_A_const_372 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[479]; A_arbace_pprint_cl_format__init_part0_A_const_373 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[480]); A_arbace_pprint_cl_format__init_part0_A_const_374 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[481] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p27() { A_arbace_pprint_cl_format__init_part0_A_const_375 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[482]); A_arbace_pprint_cl_format__init_part0_A_const_376 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[483]; A_arbace_pprint_cl_format__init_part0_A_const_377 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[484]); A_arbace_pprint_cl_format__init_part0_A_const_378 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[485]; A_arbace_pprint_cl_format__init_part0_A_const_379 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[486]); A_arbace_pprint_cl_format__init_part0_A_const_380 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[487]; A_arbace_pprint_cl_format__init_part0_A_const_381 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[488]; A_arbace_pprint_cl_format__init_part0_A_const_382 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[489]); A_arbace_pprint_cl_format__init_part0_A_const_383 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[490] }

func A_arbace_pprint_cl_format__init_part0_A_New() *A_arbace_pprint_cl_format__init_part0_A { A_arbace_pprint_cl_format__init_part0_A_Init(); t := &A_arbace_pprint_cl_format__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_cl_format__init_part0_A) Ctor() {}

func (t *A_arbace_pprint_cl_format__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_cl_format__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_cl_format__init_part0_A_class }

func (t *A_arbace_pprint_cl_format__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_cl_format__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_pprint_cl_format__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_cl_format__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_cl_format__init_part0_A); return ok }

func A_arbace_pprint_cl_format__init_part0_A_Cast(x any) *A_arbace_pprint_cl_format__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_cl_format__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_cl_format__init_part0_A_class)) }; return v }



type A_arbace_pprint_cl_format__init_part1_A struct{ jrt.Object }

var A_arbace_pprint_cl_format__init_part1_A_const_pool *jrt.RefArray

var A_arbace_pprint_cl_format__init_part1_A_const_0 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_1 any

var A_arbace_pprint_cl_format__init_part1_A_const_2 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_3 any

var A_arbace_pprint_cl_format__init_part1_A_const_4 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_5 any

var A_arbace_pprint_cl_format__init_part1_A_const_6 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_7 any

var A_arbace_pprint_cl_format__init_part1_A_const_8 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_9 any

var A_arbace_pprint_cl_format__init_part1_A_const_10 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_11 any

var A_arbace_pprint_cl_format__init_part1_A_const_12 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_13 any

var A_arbace_pprint_cl_format__init_part1_A_const_14 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_15 any

var A_arbace_pprint_cl_format__init_part1_A_const_16 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_17 any

var A_arbace_pprint_cl_format__init_part1_A_const_18 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_19 any

var A_arbace_pprint_cl_format__init_part1_A_const_20 any

var A_arbace_pprint_cl_format__init_part1_A_const_21 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_22 any

var A_arbace_pprint_cl_format__init_part1_A_const_23 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_24 any

var A_arbace_pprint_cl_format__init_part1_A_const_25 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_26 any

var A_arbace_pprint_cl_format__init_part1_A_const_27 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_28 any

var A_arbace_pprint_cl_format__init_part1_A_const_29 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_30 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_31 any

var A_arbace_pprint_cl_format__init_part1_A_const_32 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_33 any

var A_arbace_pprint_cl_format__init_part1_A_const_34 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_35 any

var A_arbace_pprint_cl_format__init_part1_A_init jrt.ClassInit

func A_arbace_pprint_cl_format__init_part1_A_Init() { if !A_arbace_pprint_cl_format__init_part1_A_init.Done() { A_arbace_pprint_cl_format__init_part1_A_init.Run(A_arbace_pprint_cl_format__init_part1_A_clinit) } }

func A_arbace_pprint_cl_format__init_part1_A_clinit() { A_arbace_pprint_cl_format__init_part1_A_clinit_p0(); A_arbace_pprint_cl_format__init_part1_A_clinit_p1(); A_arbace_pprint_cl_format__init_part1_A_clinit_p2() }

func A_arbace_pprint_cl_format__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_pprint_cl_format__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_108, 56); A_arbace_pprint_cl_format__init_part1_A_const_0 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[22]); A_arbace_pprint_cl_format__init_part1_A_const_1 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[23]; A_arbace_pprint_cl_format__init_part1_A_const_2 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[24]); A_arbace_pprint_cl_format__init_part1_A_const_3 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[25]; A_arbace_pprint_cl_format__init_part1_A_const_4 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[26]); A_arbace_pprint_cl_format__init_part1_A_const_5 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[27]; A_arbace_pprint_cl_format__init_part1_A_const_6 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[28]); A_arbace_pprint_cl_format__init_part1_A_const_7 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[29]; A_arbace_pprint_cl_format__init_part1_A_const_8 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[30]); A_arbace_pprint_cl_format__init_part1_A_const_9 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[31]; A_arbace_pprint_cl_format__init_part1_A_const_10 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[32]); A_arbace_pprint_cl_format__init_part1_A_const_11 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[33] }

func A_arbace_pprint_cl_format__init_part1_A_clinit_p1() { A_arbace_pprint_cl_format__init_part1_A_const_12 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[34]); A_arbace_pprint_cl_format__init_part1_A_const_13 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[35]; A_arbace_pprint_cl_format__init_part1_A_const_14 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[36]); A_arbace_pprint_cl_format__init_part1_A_const_15 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[37]; A_arbace_pprint_cl_format__init_part1_A_const_16 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[38]); A_arbace_pprint_cl_format__init_part1_A_const_17 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[39]; A_arbace_pprint_cl_format__init_part1_A_const_18 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[40]); A_arbace_pprint_cl_format__init_part1_A_const_19 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[41]; A_arbace_pprint_cl_format__init_part1_A_const_20 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[42]; A_arbace_pprint_cl_format__init_part1_A_const_21 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[43]); A_arbace_pprint_cl_format__init_part1_A_const_22 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[44] }

func A_arbace_pprint_cl_format__init_part1_A_clinit_p2() { var tmp1 *lang.Var; A_arbace_pprint_cl_format__init_part0_A_Init(); tmp1 = A_arbace_pprint_cl_format__init_part0_A_const_2; A_arbace_pprint_cl_format__init_part1_A_const_23 = tmp1; A_arbace_pprint_cl_format__init_part1_A_const_24 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[45]; A_arbace_pprint_cl_format__init_part1_A_const_25 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[46]); A_arbace_pprint_cl_format__init_part1_A_const_26 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[47]; var tmp2 *lang.Var; A_arbace_pprint_cl_format__init_part0_A_Init(); tmp2 = A_arbace_pprint_cl_format__init_part0_A_const_4; A_arbace_pprint_cl_format__init_part1_A_const_27 = tmp2; A_arbace_pprint_cl_format__init_part1_A_const_28 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[48]; A_arbace_pprint_cl_format__init_part1_A_const_29 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[49]); A_arbace_pprint_cl_format__init_part1_A_const_30 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[50]); A_arbace_pprint_cl_format__init_part1_A_const_31 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[51]; A_arbace_pprint_cl_format__init_part1_A_const_32 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[52]); A_arbace_pprint_cl_format__init_part1_A_const_33 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[53]; A_arbace_pprint_cl_format__init_part1_A_const_34 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[54]); A_arbace_pprint_cl_format__init_part1_A_const_35 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[55] }

func A_arbace_pprint_cl_format__init_part1_A_New() *A_arbace_pprint_cl_format__init_part1_A { A_arbace_pprint_cl_format__init_part1_A_Init(); t := &A_arbace_pprint_cl_format__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_cl_format__init_part1_A) Ctor() {}

func (t *A_arbace_pprint_cl_format__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_cl_format__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_cl_format__init_part1_A_class }

func (t *A_arbace_pprint_cl_format__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_cl_format__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_pprint_cl_format__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_cl_format__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_cl_format__init_part1_A); return ok }

func A_arbace_pprint_cl_format__init_part1_A_Cast(x any) *A_arbace_pprint_cl_format__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_cl_format__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_cl_format__init_part1_A_class)) }; return v }
