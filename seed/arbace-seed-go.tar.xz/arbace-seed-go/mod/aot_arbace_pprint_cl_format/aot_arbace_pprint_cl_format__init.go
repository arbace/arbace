//line aot_arbace_pprint_cl_format__init.ae:1
package aot_arbace_pprint_cl_format

import (
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_cl_format__init_A_Load__O() any { A_arbace_pprint_cl_format__init_part0_A_Init__O(); A_arbace_pprint_cl_format__init_part1_A_Init__O(); A_arbace_pprint_cl_format__init_part0_A_Load__O(); A_arbace_pprint_cl_format__init_part1_A_Load__O(); return nil }












func A_arbace_pprint_cl_format__init_part0_A_Unit0__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); return lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_cl_format__init_part0_A_const_1) }
//line :18:1
func A_arbace_pprint_cl_format__init_part0_A_Init__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); return nil }
//line :18:1
func A_arbace_pprint_cl_format__init_part0_A_Load__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); A_arbace_pprint_cl_format__init_part0_A_Unit0__O(); A_arbace_pprint_cl_format__init_part0_A_Unit1__O(); A_arbace_pprint_cl_format__init_part0_A_Unit2__O(); A_arbace_pprint_cl_format__init_part0_A_Unit3__O(); A_arbace_pprint_cl_format__init_part0_A_Unit4__O(); A_arbace_pprint_cl_format__init_part0_A_Unit5__O(); A_arbace_pprint_cl_format__init_part0_A_Unit6__O(); A_arbace_pprint_cl_format__init_part0_A_Unit7__O(); A_arbace_pprint_cl_format__init_part0_A_Unit8__O(); A_arbace_pprint_cl_format__init_part0_A_Unit9__O(); A_arbace_pprint_cl_format__init_part0_A_Unit10__O(); A_arbace_pprint_cl_format__init_part0_A_Unit11__O(); A_arbace_pprint_cl_format__init_part0_A_Unit12__O(); A_arbace_pprint_cl_format__init_part0_A_Unit13__O(); A_arbace_pprint_cl_format__init_part0_A_Unit14__O(); A_arbace_pprint_cl_format__init_part0_A_Unit15__O(); A_arbace_pprint_cl_format__init_part0_A_Unit16__O(); A_arbace_pprint_cl_format__init_part0_A_Unit17__O(); A_arbace_pprint_cl_format__init_part0_A_Unit18__O(); A_arbace_pprint_cl_format__init_part0_A_Unit19__O(); A_arbace_pprint_cl_format__init_part0_A_Unit20__O(); A_arbace_pprint_cl_format__init_part0_A_Unit21__O(); A_arbace_pprint_cl_format__init_part0_A_Unit22__O(); A_arbace_pprint_cl_format__init_part0_A_Unit23__O(); A_arbace_pprint_cl_format__init_part0_A_Unit24__O(); A_arbace_pprint_cl_format__init_part0_A_Unit25__O(); A_arbace_pprint_cl_format__init_part0_A_Unit26__O(); A_arbace_pprint_cl_format__init_part0_A_Unit27__O(); A_arbace_pprint_cl_format__init_part0_A_Unit28__O(); A_arbace_pprint_cl_format__init_part0_A_Unit29__O(); A_arbace_pprint_cl_format__init_part0_A_Unit30__O(); A_arbace_pprint_cl_format__init_part0_A_Unit31__O(); A_arbace_pprint_cl_format__init_part0_A_Unit32__O(); A_arbace_pprint_cl_format__init_part0_A_Unit33__O(); A_arbace_pprint_cl_format__init_part0_A_Unit34__O(); A_arbace_pprint_cl_format__init_part0_A_Unit35__O(); A_arbace_pprint_cl_format__init_part0_A_Unit36__O(); A_arbace_pprint_cl_format__init_part0_A_Unit37__O(); A_arbace_pprint_cl_format__init_part0_A_Unit38__O(); A_arbace_pprint_cl_format__init_part0_A_Unit39__O(); A_arbace_pprint_cl_format__init_part0_A_Unit40__O(); A_arbace_pprint_cl_format__init_part0_A_Unit41__O(); A_arbace_pprint_cl_format__init_part0_A_Unit42__O(); A_arbace_pprint_cl_format__init_part0_A_Unit43__O(); A_arbace_pprint_cl_format__init_part0_A_Unit44__O(); A_arbace_pprint_cl_format__init_part0_A_Unit45__O(); A_arbace_pprint_cl_format__init_part0_A_Unit46__O(); A_arbace_pprint_cl_format__init_part0_A_Unit47__O(); A_arbace_pprint_cl_format__init_part0_A_Unit48__O(); A_arbace_pprint_cl_format__init_part0_A_Unit49__O(); A_arbace_pprint_cl_format__init_part0_A_Unit50__O(); A_arbace_pprint_cl_format__init_part0_A_Unit51__O(); A_arbace_pprint_cl_format__init_part0_A_Unit52__O(); A_arbace_pprint_cl_format__init_part0_A_Unit53__O(); A_arbace_pprint_cl_format__init_part0_A_Unit54__O(); A_arbace_pprint_cl_format__init_part0_A_Unit55__O(); A_arbace_pprint_cl_format__init_part0_A_Unit56__O(); A_arbace_pprint_cl_format__init_part0_A_Unit57__O(); A_arbace_pprint_cl_format__init_part0_A_Unit58__O(); A_arbace_pprint_cl_format__init_part0_A_Unit59__O(); A_arbace_pprint_cl_format__init_part0_A_Unit60__O(); A_arbace_pprint_cl_format__init_part0_A_Unit61__O(); A_arbace_pprint_cl_format__init_part0_A_Unit62__O(); A_arbace_pprint_cl_format__init_part0_A_Unit63__O(); A_arbace_pprint_cl_format__init_part0_A_Unit64__O(); A_arbace_pprint_cl_format__init_part0_A_Unit65__O(); A_arbace_pprint_cl_format__init_part0_A_Unit66__O(); A_arbace_pprint_cl_format__init_part0_A_Unit67__O(); A_arbace_pprint_cl_format__init_part0_A_Unit68__O(); A_arbace_pprint_cl_format__init_part0_A_Unit69__O(); A_arbace_pprint_cl_format__init_part0_A_Unit70__O(); A_arbace_pprint_cl_format__init_part0_A_Unit71__O(); A_arbace_pprint_cl_format__init_part0_A_Unit72__O(); A_arbace_pprint_cl_format__init_part0_A_Unit73__O(); A_arbace_pprint_cl_format__init_part0_A_Unit74__O(); A_arbace_pprint_cl_format__init_part0_A_Unit75__O(); A_arbace_pprint_cl_format__init_part0_A_Unit76__O(); A_arbace_pprint_cl_format__init_part0_A_Unit77__O(); A_arbace_pprint_cl_format__init_part0_A_Unit78__O(); A_arbace_pprint_cl_format__init_part0_A_Unit79__O(); A_arbace_pprint_cl_format__init_part0_A_Unit80__O(); A_arbace_pprint_cl_format__init_part0_A_Unit81__O(); A_arbace_pprint_cl_format__init_part0_A_Unit82__O(); A_arbace_pprint_cl_format__init_part0_A_Unit83__O(); A_arbace_pprint_cl_format__init_part0_A_Unit84__O(); A_arbace_pprint_cl_format__init_part0_A_Unit85__O(); A_arbace_pprint_cl_format__init_part0_A_Unit86__O(); A_arbace_pprint_cl_format__init_part0_A_Unit87__O(); A_arbace_pprint_cl_format__init_part0_A_Unit88__O(); A_arbace_pprint_cl_format__init_part0_A_Unit89__O(); A_arbace_pprint_cl_format__init_part0_A_Unit90__O(); A_arbace_pprint_cl_format__init_part0_A_Unit91__O(); A_arbace_pprint_cl_format__init_part0_A_Unit92__O(); A_arbace_pprint_cl_format__init_part0_A_Unit93__O(); A_arbace_pprint_cl_format__init_part0_A_Unit94__O(); A_arbace_pprint_cl_format__init_part0_A_Unit95__O(); A_arbace_pprint_cl_format__init_part0_A_Unit96__O(); A_arbace_pprint_cl_format__init_part0_A_Unit97__O(); A_arbace_pprint_cl_format__init_part0_A_Unit98__O(); A_arbace_pprint_cl_format__init_part0_A_Unit99__O(); return nil }


func A_arbace_pprint_cl_format__init_part0_A_Unit1__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_3)); return A_arbace_pprint_cl_format__init_part0_A_const_2 }
func A_arbace_pprint_cl_format__init_part0_A_Unit2__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_5)); return A_arbace_pprint_cl_format__init_part0_A_const_4 }
func A_arbace_pprint_cl_format__init_part0_A_Unit3__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_7)); return A_arbace_pprint_cl_format__init_part0_A_const_6 }


func A_arbace_pprint_cl_format__init_part0_A_Unit4__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_8; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_cl_format_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_cl_format_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, true); aot_arbace_pprint.A_arbace_pprint_cl_format_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_9)); return A_arbace_pprint_cl_format__init_part0_A_const_8 }






































func A_arbace_pprint_cl_format__init_part0_A_Unit5__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(65, 1); A_arbace_pprint_cl_format__init_part0_A_const_10.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_11)); return A_arbace_pprint_cl_format__init_part0_A_const_10.SetDynamic_Z__Var(true).Ref() }

func A_arbace_pprint_cl_format__init_part0_A_Unit6__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(67, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_12; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_format_error_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_error_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); aot_arbace_pprint.A_arbace_pprint_format_error_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_13)); return A_arbace_pprint_cl_format__init_part0_A_const_12 }










func A_arbace_pprint_cl_format__init_part0_A_Unit7__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(78, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_14; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_15.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_17, A_arbace_pprint_cl_format__init_part0_A_const_18, A_arbace_pprint_cl_format__init_part0_A_const_19)); var tmp2 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_14; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_16)); return A_arbace_pprint_cl_format__init_part0_A_const_14 }


func A_arbace_pprint_cl_format__init_part0_A_Unit8__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(81, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_6; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_init_navigator_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_init_navigator_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); aot_arbace_pprint.A_arbace_pprint_init_navigator_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_20)); return A_arbace_pprint_cl_format__init_part0_A_const_6 }







func A_arbace_pprint_cl_format__init_part0_A_Unit9__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(89, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_21; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_next_arg_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_next_arg_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); aot_arbace_pprint.A_arbace_pprint_next_arg_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_22)); return A_arbace_pprint_cl_format__init_part0_A_const_21 }





func A_arbace_pprint_cl_format__init_part0_A_Unit10__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(95, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_23; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_next_arg_or_nil_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_next_arg_or_nil_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); aot_arbace_pprint.A_arbace_pprint_next_arg_or_nil_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_24)); return A_arbace_pprint_cl_format__init_part0_A_const_23 }






func A_arbace_pprint_cl_format__init_part0_A_Unit11__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(102, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_25; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_format_arg_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_format_arg_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); aot_arbace_pprint.A_arbace_pprint_get_format_arg_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_26)); return A_arbace_pprint_cl_format__init_part0_A_const_25 }






func A_arbace_pprint_cl_format__init_part0_A_Unit12__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(109, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_27; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_28)); return A_arbace_pprint_cl_format__init_part0_A_const_27 }

func A_arbace_pprint_cl_format__init_part0_A_Unit13__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(111, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_29; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_absolute_reposition_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_absolute_reposition_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); aot_arbace_pprint.A_arbace_pprint_absolute_reposition_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_30)); return A_arbace_pprint_cl_format__init_part0_A_const_29 }




func A_arbace_pprint_cl_format__init_part0_A_Unit14__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(116, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_27; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_relative_reposition_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_relative_reposition_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); aot_arbace_pprint.A_arbace_pprint_relative_reposition_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_31)); return A_arbace_pprint_cl_format__init_part0_A_const_27 }





func A_arbace_pprint_cl_format__init_part0_A_Unit15__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(122, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_32; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_15.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_34, A_arbace_pprint_cl_format__init_part0_A_const_35, A_arbace_pprint_cl_format__init_part0_A_const_36, A_arbace_pprint_cl_format__init_part0_A_const_37)); var tmp2 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_32; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_33)); return A_arbace_pprint_cl_format__init_part0_A_const_32 }










func A_arbace_pprint_cl_format__init_part0_A_Unit16__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(133, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_38; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_realize_parameter_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_realize_parameter_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); aot_arbace_pprint.A_arbace_pprint_realize_parameter_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_39)); return A_arbace_pprint_cl_format__init_part0_A_const_38 }















func A_arbace_pprint_cl_format__init_part0_A_Unit17__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(149, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_40; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_realize_parameter_list_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_realize_parameter_list_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); aot_arbace_pprint.A_arbace_pprint_realize_parameter_list_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_41)); return A_arbace_pprint_cl_format__init_part0_A_const_40 }












func A_arbace_pprint_cl_format__init_part0_A_Unit18__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(162, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_42; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_43)); return A_arbace_pprint_cl_format__init_part0_A_const_42 }

func A_arbace_pprint_cl_format__init_part0_A_Unit19__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(164, 1); A_arbace_pprint_cl_format__init_part0_A_const_44.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_45); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_44; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_46)); return A_arbace_pprint_cl_format__init_part0_A_const_44 }


func A_arbace_pprint_cl_format__init_part0_A_Unit20__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(167, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_47; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_format_simple_number_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_simple_number_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); aot_arbace_pprint.A_arbace_pprint_format_simple_number_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_48)); return A_arbace_pprint_cl_format__init_part0_A_const_47 }













func A_arbace_pprint_cl_format__init_part0_A_Unit21__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(181, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_49; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_format_ascii_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_ascii_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); aot_arbace_pprint.A_arbace_pprint_format_ascii_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_50)); return A_arbace_pprint_cl_format__init_part0_A_const_49 }






















func A_arbace_pprint_cl_format__init_part0_A_Unit22__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(204, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_51; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_integral_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_integral_QMARK__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_13, false); aot_arbace_pprint.A_arbace_pprint_integral_QMARK__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_52)); return A_arbace_pprint_cl_format__init_part0_A_const_51 }










func A_arbace_pprint_cl_format__init_part0_A_Unit23__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(215, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_53; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_remainders_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_remainders_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); aot_arbace_pprint.A_arbace_pprint_remainders_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_54)); return A_arbace_pprint_cl_format__init_part0_A_const_53 }










func A_arbace_pprint_cl_format__init_part0_A_Unit24__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(226, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_55; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_base_str_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_base_str_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); aot_arbace_pprint.A_arbace_pprint_base_str_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_56)); return A_arbace_pprint_cl_format__init_part0_A_const_55 }














func A_arbace_pprint_cl_format__init_part0_A_Unit25__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(241, 1); A_arbace_pprint_cl_format__init_part0_A_const_57.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_58); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_57; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_59)); return A_arbace_pprint_cl_format__init_part0_A_const_57 }


func A_arbace_pprint_cl_format__init_part0_A_Unit26__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(244, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_42; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_opt_base_str_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_opt_base_str_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); aot_arbace_pprint.A_arbace_pprint_opt_base_str_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_60)); return A_arbace_pprint_cl_format__init_part0_A_const_42 }








func A_arbace_pprint_cl_format__init_part0_A_Unit27__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(253, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_61; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_group_by_STAR__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_group_by_STAR__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); aot_arbace_pprint.A_arbace_pprint_group_by_STAR__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_62)); return A_arbace_pprint_cl_format__init_part0_A_const_61 }




func A_arbace_pprint_cl_format__init_part0_A_Unit28__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(258, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_63; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_format_integer_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_integer_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); aot_arbace_pprint.A_arbace_pprint_format_integer_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_64)); return A_arbace_pprint_cl_format__init_part0_A_const_63 }





























func A_arbace_pprint_cl_format__init_part0_A_Unit29__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(288, 1); A_arbace_pprint_cl_format__init_part0_A_const_65.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_66); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_65; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_67)); return A_arbace_pprint_cl_format__init_part0_A_const_65 }





func A_arbace_pprint_cl_format__init_part0_A_Unit30__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(294, 1); A_arbace_pprint_cl_format__init_part0_A_const_68.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_69); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_68; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_70)); return A_arbace_pprint_cl_format__init_part0_A_const_68 }





func A_arbace_pprint_cl_format__init_part0_A_Unit31__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(300, 1); A_arbace_pprint_cl_format__init_part0_A_const_71.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_72); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_71; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_73)); return A_arbace_pprint_cl_format__init_part0_A_const_71 }



func A_arbace_pprint_cl_format__init_part0_A_Unit32__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(304, 1); A_arbace_pprint_cl_format__init_part0_A_const_74.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_75); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_74; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_76)); return A_arbace_pprint_cl_format__init_part0_A_const_74 }








func A_arbace_pprint_cl_format__init_part0_A_Unit33__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(313, 1); A_arbace_pprint_cl_format__init_part0_A_const_77.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_78); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_77; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_79)); return A_arbace_pprint_cl_format__init_part0_A_const_77 }







func A_arbace_pprint_cl_format__init_part0_A_Unit34__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(321, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_80; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_format_simple_cardinal_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_simple_cardinal_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); aot_arbace_pprint.A_arbace_pprint_format_simple_cardinal_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_81)); return A_arbace_pprint_cl_format__init_part0_A_const_80 }

















func A_arbace_pprint_cl_format__init_part0_A_Unit35__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(339, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_82; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_add_english_scales_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_add_english_scales_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); aot_arbace_pprint.A_arbace_pprint_add_english_scales_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_83)); return A_arbace_pprint_cl_format__init_part0_A_const_82 }






















func A_arbace_pprint_cl_format__init_part0_A_Unit36__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(362, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_84; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_format_cardinal_english_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_cardinal_english_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); aot_arbace_pprint.A_arbace_pprint_format_cardinal_english_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_85)); return A_arbace_pprint_cl_format__init_part0_A_const_84 }
















func A_arbace_pprint_cl_format__init_part0_A_Unit37__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(379, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_86; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_format_simple_ordinal_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_simple_ordinal_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); aot_arbace_pprint.A_arbace_pprint_format_simple_ordinal_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_87)); return A_arbace_pprint_cl_format__init_part0_A_const_86 }





















func A_arbace_pprint_cl_format__init_part0_A_Unit38__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(401, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_88; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_format_ordinal_english_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_ordinal_english_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); aot_arbace_pprint.A_arbace_pprint_format_ordinal_english_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_89)); return A_arbace_pprint_cl_format__init_part0_A_const_88 }



































func A_arbace_pprint_cl_format__init_part0_A_Unit39__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(437, 1); A_arbace_pprint_cl_format__init_part0_A_const_90.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_91); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_92)); return A_arbace_pprint_cl_format__init_part0_A_const_90 }






func A_arbace_pprint_cl_format__init_part0_A_Unit40__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(444, 1); A_arbace_pprint_cl_format__init_part0_A_const_93.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_94); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_93; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_95)); return A_arbace_pprint_cl_format__init_part0_A_const_93 }






func A_arbace_pprint_cl_format__init_part0_A_Unit41__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(451, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_96; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_format_roman_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_roman_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); aot_arbace_pprint.A_arbace_pprint_format_roman_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_97)); return A_arbace_pprint_cl_format__init_part0_A_const_96 }























func A_arbace_pprint_cl_format__init_part0_A_Unit42__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(475, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_98; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_format_old_roman_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_old_roman_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); aot_arbace_pprint.A_arbace_pprint_format_old_roman_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_99)); return A_arbace_pprint_cl_format__init_part0_A_const_98 }


func A_arbace_pprint_cl_format__init_part0_A_Unit43__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(478, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_100; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_format_new_roman_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_new_roman_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); aot_arbace_pprint.A_arbace_pprint_format_new_roman_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_101)); return A_arbace_pprint_cl_format__init_part0_A_const_100 }






func A_arbace_pprint_cl_format__init_part0_A_Unit44__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(485, 1); A_arbace_pprint_cl_format__init_part0_A_const_102.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_103); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_102; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_104)); return A_arbace_pprint_cl_format__init_part0_A_const_102 }


func A_arbace_pprint_cl_format__init_part0_A_Unit45__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(488, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_105; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_pretty_character_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_pretty_character_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); aot_arbace_pprint.A_arbace_pprint_pretty_character_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_106)); return A_arbace_pprint_cl_format__init_part0_A_const_105 }













func A_arbace_pprint_cl_format__init_part0_A_Unit46__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(502, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_107; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_readable_character_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_readable_character_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); aot_arbace_pprint.A_arbace_pprint_readable_character_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_108)); return A_arbace_pprint_cl_format__init_part0_A_const_107 }







func A_arbace_pprint_cl_format__init_part0_A_Unit47__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(510, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_109; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_plain_character_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_plain_character_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); aot_arbace_pprint.A_arbace_pprint_plain_character_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_110)); return A_arbace_pprint_cl_format__init_part0_A_const_109 }






func A_arbace_pprint_cl_format__init_part0_A_Unit48__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(517, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_111; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_abort_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_abort_QMARK__A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); aot_arbace_pprint.A_arbace_pprint_abort_QMARK__A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_112)); return A_arbace_pprint_cl_format__init_part0_A_const_111 }




func A_arbace_pprint_cl_format__init_part0_A_Unit49__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(522, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_113; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_execute_sub_format_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_execute_sub_format_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); aot_arbace_pprint.A_arbace_pprint_execute_sub_format_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_114)); return A_arbace_pprint_cl_format__init_part0_A_const_113 }

















func A_arbace_pprint_cl_format__init_part0_A_Unit50__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(540, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_115; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_float_parts_base_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_float_parts_base_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); aot_arbace_pprint.A_arbace_pprint_float_parts_base_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_116)); return A_arbace_pprint_cl_format__init_part0_A_const_115 }













func A_arbace_pprint_cl_format__init_part0_A_Unit51__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(554, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_117; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_float_parts_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_float_parts_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); aot_arbace_pprint.A_arbace_pprint_float_parts_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_118)); return A_arbace_pprint_cl_format__init_part0_A_const_117 }











func A_arbace_pprint_cl_format__init_part0_A_Unit52__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(566, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_119; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_inc_s_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_inc_s_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); aot_arbace_pprint.A_arbace_pprint_inc_s_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_120)); return A_arbace_pprint_cl_format__init_part0_A_const_119 }















func A_arbace_pprint_cl_format__init_part0_A_Unit53__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(582, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_121; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_round_str_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_round_str_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); aot_arbace_pprint.A_arbace_pprint_round_str_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_122)); return A_arbace_pprint_cl_format__init_part0_A_const_121 }









































func A_arbace_pprint_cl_format__init_part0_A_Unit54__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(624, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_123; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_expand_fixed_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_expand_fixed_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); aot_arbace_pprint.A_arbace_pprint_expand_fixed_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_124)); return A_arbace_pprint_cl_format__init_part0_A_const_123 }









func A_arbace_pprint_cl_format__init_part0_A_Unit55__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(634, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_125; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_insert_decimal_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_insert_decimal_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); aot_arbace_pprint.A_arbace_pprint_insert_decimal_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_126)); return A_arbace_pprint_cl_format__init_part0_A_const_125 }







func A_arbace_pprint_cl_format__init_part0_A_Unit56__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(642, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_127; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_fixed_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_fixed_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); aot_arbace_pprint.A_arbace_pprint_get_fixed_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_128)); return A_arbace_pprint_cl_format__init_part0_A_const_127 }


func A_arbace_pprint_cl_format__init_part0_A_Unit57__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(645, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_129; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_insert_scaled_decimal_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_insert_scaled_decimal_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); aot_arbace_pprint.A_arbace_pprint_insert_scaled_decimal_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_130)); return A_arbace_pprint_cl_format__init_part0_A_const_129 }






func A_arbace_pprint_cl_format__init_part0_A_Unit58__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(652, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_131; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_convert_ratio_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_convert_ratio_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); aot_arbace_pprint.A_arbace_pprint_convert_ratio_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_132)); return A_arbace_pprint_cl_format__init_part0_A_const_131 }
















func A_arbace_pprint_cl_format__init_part0_A_Unit59__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(669, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_133; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_fixed_float_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fixed_float_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); aot_arbace_pprint.A_arbace_pprint_fixed_float_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_134)); return A_arbace_pprint_cl_format__init_part0_A_const_133 }














































func A_arbace_pprint_cl_format__init_part0_A_Unit60__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(716, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_135; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_exponential_float_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_exponential_float_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); aot_arbace_pprint.A_arbace_pprint_exponential_float_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_136)); return A_arbace_pprint_cl_format__init_part0_A_const_135 }









































































func A_arbace_pprint_cl_format__init_part0_A_Unit61__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(790, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_137; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_general_float_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_general_float_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); aot_arbace_pprint.A_arbace_pprint_general_float_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_138)); return A_arbace_pprint_cl_format__init_part0_A_const_137 }






















func A_arbace_pprint_cl_format__init_part0_A_Unit62__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(813, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_139; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_dollar_float_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_dollar_float_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); aot_arbace_pprint.A_arbace_pprint_dollar_float_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_140)); return A_arbace_pprint_cl_format__init_part0_A_const_139 }

























func A_arbace_pprint_cl_format__init_part0_A_Unit63__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(839, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_141; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_choice_conditional_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_choice_conditional_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); aot_arbace_pprint.A_arbace_pprint_choice_conditional_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_142)); return A_arbace_pprint_cl_format__init_part0_A_const_141 }











func A_arbace_pprint_cl_format__init_part0_A_Unit64__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(851, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_143; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_boolean_conditional_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_boolean_conditional_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); aot_arbace_pprint.A_arbace_pprint_boolean_conditional_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_144)); return A_arbace_pprint_cl_format__init_part0_A_const_143 }











func A_arbace_pprint_cl_format__init_part0_A_Unit65__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(863, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_145; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_check_arg_conditional_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_check_arg_conditional_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); aot_arbace_pprint.A_arbace_pprint_check_arg_conditional_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_146)); return A_arbace_pprint_cl_format__init_part0_A_const_145 }
















func A_arbace_pprint_cl_format__init_part0_A_Unit66__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(880, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_147; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_iterate_sublist_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_iterate_sublist_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); aot_arbace_pprint.A_arbace_pprint_iterate_sublist_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_148)); return A_arbace_pprint_cl_format__init_part0_A_const_147 }
























func A_arbace_pprint_cl_format__init_part0_A_Unit67__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(905, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_149; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_iterate_list_of_sublists_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_iterate_list_of_sublists_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); aot_arbace_pprint.A_arbace_pprint_iterate_list_of_sublists_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_150)); return A_arbace_pprint_cl_format__init_part0_A_const_149 }






















func A_arbace_pprint_cl_format__init_part0_A_Unit68__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(928, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_151; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_iterate_main_list_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_iterate_main_list_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); aot_arbace_pprint.A_arbace_pprint_iterate_main_list_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_151; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_152)); return A_arbace_pprint_cl_format__init_part0_A_const_151 }























func A_arbace_pprint_cl_format__init_part0_A_Unit69__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(952, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_153; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_iterate_main_sublists_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_iterate_main_sublists_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); aot_arbace_pprint.A_arbace_pprint_iterate_main_sublists_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_153; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_154)); return A_arbace_pprint_cl_format__init_part0_A_const_153 }































func A_arbace_pprint_cl_format__init_part0_A_Unit70__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(984, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_155; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_156)); return A_arbace_pprint_cl_format__init_part0_A_const_155 }
func A_arbace_pprint_cl_format__init_part0_A_Unit71__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(985, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_157; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_158)); return A_arbace_pprint_cl_format__init_part0_A_const_157 }

func A_arbace_pprint_cl_format__init_part0_A_Unit72__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(987, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_159; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_logical_block_or_justify_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_logical_block_or_justify_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); aot_arbace_pprint.A_arbace_pprint_logical_block_or_justify_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_160)); return A_arbace_pprint_cl_format__init_part0_A_const_159 }








func A_arbace_pprint_cl_format__init_part0_A_Unit73__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(996, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_161; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_render_clauses_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_render_clauses_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); aot_arbace_pprint.A_arbace_pprint_render_clauses_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_162)); return A_arbace_pprint_cl_format__init_part0_A_const_161 }














func A_arbace_pprint_cl_format__init_part0_A_Unit74__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1011, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_157; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_justify_clauses_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_justify_clauses_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); aot_arbace_pprint.A_arbace_pprint_justify_clauses_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_157; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_163)); return A_arbace_pprint_cl_format__init_part0_A_const_157 }






















































func A_arbace_pprint_cl_format__init_part0_A_Unit75__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1066, 1); var tmp1 any = A_arbace_pprint_cl_format__init_part0_A_const_167; lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_166.GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq(tmp1, lang.RT_Seq_O__ISeq(jrt.RefArrayOf(jrt.Object_class)))); var tmp2 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_164; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_downcase_writer_A_New(); var tmp4 *jrt.Class; var fncls__55 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_downcase_writer_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); aot_arbace_pprint.A_arbace_pprint_downcase_writer_A_fn_class = fncls__55d; tmp4 = fncls__55d } else { tmp4 = fncls__55 }; tmp2.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var tmp5 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_164; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_165)); return A_arbace_pprint_cl_format__init_part0_A_const_164 }

















func A_arbace_pprint_cl_format__init_part0_A_Unit76__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1084, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_168; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_upcase_writer_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_upcase_writer_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); aot_arbace_pprint.A_arbace_pprint_upcase_writer_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_168; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_169)); return A_arbace_pprint_cl_format__init_part0_A_const_168 }

















func A_arbace_pprint_cl_format__init_part0_A_Unit77__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1102, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_170; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_capitalize_string_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_capitalize_string_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); aot_arbace_pprint.A_arbace_pprint_capitalize_string_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_170; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_171)); return A_arbace_pprint_cl_format__init_part0_A_const_170 }























func A_arbace_pprint_cl_format__init_part0_A_Unit78__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1126, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_172; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_capitalize_word_writer_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_capitalize_word_writer_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); aot_arbace_pprint.A_arbace_pprint_capitalize_word_writer_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_172; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_173)); return A_arbace_pprint_cl_format__init_part0_A_const_172 }



























func A_arbace_pprint_cl_format__init_part0_A_Unit79__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1154, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_174; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_init_cap_writer_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_init_cap_writer_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); aot_arbace_pprint.A_arbace_pprint_init_cap_writer_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_174; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_175)); return A_arbace_pprint_cl_format__init_part0_A_const_174 }

































func A_arbace_pprint_cl_format__init_part0_A_Unit80__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1188, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_176; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_modify_case_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_modify_case_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); aot_arbace_pprint.A_arbace_pprint_modify_case_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_176; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_177)); return A_arbace_pprint_cl_format__init_part0_A_const_176 }








func A_arbace_pprint_cl_format__init_part0_A_Unit81__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1197, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_178; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_pretty_writer_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_pretty_writer_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); aot_arbace_pprint.A_arbace_pprint_get_pretty_writer_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_178; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_179)); return A_arbace_pprint_cl_format__init_part0_A_const_178 }









































func A_arbace_pprint_cl_format__init_part0_A_Unit82__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1239, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_180; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_fresh_line_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fresh_line_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); aot_arbace_pprint.A_arbace_pprint_fresh_line_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_180; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_181)); return A_arbace_pprint_cl_format__init_part0_A_const_180 }









func A_arbace_pprint_cl_format__init_part0_A_Unit83__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1249, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_182; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_absolute_tabulation_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_absolute_tabulation_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_63, false); aot_arbace_pprint.A_arbace_pprint_absolute_tabulation_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_182; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_183)); return A_arbace_pprint_cl_format__init_part0_A_const_182 }










func A_arbace_pprint_cl_format__init_part0_A_Unit84__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1260, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_184; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_relative_tabulation_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_relative_tabulation_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_64, false); aot_arbace_pprint.A_arbace_pprint_relative_tabulation_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_184; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_185)); return A_arbace_pprint_cl_format__init_part0_A_const_184 }














func A_arbace_pprint_cl_format__init_part0_A_Unit85__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1275, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_155; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_format_logical_block_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_format_logical_block_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); aot_arbace_pprint.A_arbace_pprint_format_logical_block_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_155; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_186)); return A_arbace_pprint_cl_format__init_part0_A_const_155 }

















func A_arbace_pprint_cl_format__init_part0_A_Unit86__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1293, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_187; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_set_indent_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_set_indent_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); aot_arbace_pprint.A_arbace_pprint_set_indent_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_187; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_188)); return A_arbace_pprint_cl_format__init_part0_A_const_187 }






func A_arbace_pprint_cl_format__init_part0_A_Unit87__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1300, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_189; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_conditional_newline_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_conditional_newline_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_67, false); aot_arbace_pprint.A_arbace_pprint_conditional_newline_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_189; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_190)); return A_arbace_pprint_cl_format__init_part0_A_const_189 }












func A_arbace_pprint_cl_format__init_part0_A_Unit88__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1313, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_191; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_process_directive_table_element_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_process_directive_table_element_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); aot_arbace_pprint.A_arbace_pprint_process_directive_table_element_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_191; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_192)); return A_arbace_pprint_cl_format__init_part0_A_const_191 }







func A_arbace_pprint_cl_format__init_part0_A_Unit89__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1321, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_193; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_defdirectives_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_defdirectives_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, true); aot_arbace_pprint.A_arbace_pprint_defdirectives_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_193; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_194)); return A_arbace_pprint_cl_format__init_part0_A_const_193 }
//line :1321:1
func A_arbace_pprint_cl_format__init_part0_A_Unit90__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1321, 1); A_arbace_pprint_cl_format__init_part0_A_const_193.SetMacro__V(); return nil }
//line :1321:1
func A_arbace_pprint_cl_format__init_part0_A_Unit91__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1321, 1); return A_arbace_pprint_cl_format__init_part0_A_const_193 }





func A_arbace_pprint_cl_format__init_part0_A_Unit92__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1327, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_195; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_196.GetRawRoot__O()); var tmp3 any = A_arbace_pprint_cl_format__init_part0_A_const_197; var tmp4 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp5 any = A_arbace_pprint_cl_format__init_part0_A_const_197; var tmp6 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp7 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_271, A_arbace_pprint_cl_format__init_part0_A_const_272, A_arbace_pprint_cl_format__init_part0_A_const_273, A_arbace_pprint_cl_format__init_part0_A_const_274, A_arbace_pprint_cl_format__init_part0_A_const_275, A_arbace_pprint_cl_format__init_part0_A_const_276, A_arbace_pprint_cl_format__init_part0_A_const_277, A_arbace_pprint_cl_format__init_part0_A_const_278); var tmp8 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp9 any = A_arbace_pprint_cl_format__init_part0_A_const_201; var tmp10 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp11 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp11 = lang.PersistentArrayMap_EMPTY; var tmp12 any = tmp11.Ref(); var tmp13 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp14 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000328_A_New(); var tmp15 *jrt.Class; var fncls__70 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000328_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_70, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000328_A_fn_class = fncls__70d; tmp15 = fncls__70d } else { tmp15 = fncls__70 }; var tmp16 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp12, tmp13, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil))); var tmp17 any = A_arbace_pprint_cl_format__init_part0_A_const_204; var tmp18 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp19 any = A_arbace_pprint_cl_format__init_part0_A_const_204; var tmp20 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp21 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_271, A_arbace_pprint_cl_format__init_part0_A_const_279, A_arbace_pprint_cl_format__init_part0_A_const_273, A_arbace_pprint_cl_format__init_part0_A_const_280, A_arbace_pprint_cl_format__init_part0_A_const_275, A_arbace_pprint_cl_format__init_part0_A_const_281, A_arbace_pprint_cl_format__init_part0_A_const_277, A_arbace_pprint_cl_format__init_part0_A_const_282); var tmp22 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp23 any = A_arbace_pprint_cl_format__init_part0_A_const_205; var tmp24 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp25 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp25 = lang.PersistentArrayMap_EMPTY; var tmp26 any = tmp25.Ref(); var tmp27 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp28 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000332_A_New(); var tmp29 *jrt.Class; var fncls__71 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000332_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000332_A_fn_class = fncls__71d; tmp29 = fncls__71d } else { tmp29 = fncls__71 }; var tmp30 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp26, tmp27, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil))); var tmp31 any = A_arbace_pprint_cl_format__init_part0_A_const_206; var tmp32 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp33 any = A_arbace_pprint_cl_format__init_part0_A_const_206; var tmp34 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp35 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_271, A_arbace_pprint_cl_format__init_part0_A_const_283, A_arbace_pprint_cl_format__init_part0_A_const_277, A_arbace_pprint_cl_format__init_part0_A_const_284, A_arbace_pprint_cl_format__init_part0_A_const_285, A_arbace_pprint_cl_format__init_part0_A_const_286, A_arbace_pprint_cl_format__init_part0_A_const_287, A_arbace_pprint_cl_format__init_part0_A_const_288); var tmp36 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp37 any = A_arbace_pprint_cl_format__init_part0_A_const_207; var tmp38 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp39 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp39 = lang.PersistentArrayMap_EMPTY; var tmp40 any = tmp39.Ref(); var tmp41 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp42 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000336_A_New(); var tmp43 *jrt.Class; var fncls__72 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000336_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_72, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000336_A_fn_class = fncls__72d; tmp43 = fncls__72d } else { tmp43 = fncls__72 }; var tmp44 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp32, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp40, tmp41, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp42, tmp43, nil))); var tmp45 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp46 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp47 any = A_arbace_pprint_cl_format__init_part0_A_const_208; var tmp48 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp49 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_271, A_arbace_pprint_cl_format__init_part0_A_const_289, A_arbace_pprint_cl_format__init_part0_A_const_277, A_arbace_pprint_cl_format__init_part0_A_const_290, A_arbace_pprint_cl_format__init_part0_A_const_285, A_arbace_pprint_cl_format__init_part0_A_const_291, A_arbace_pprint_cl_format__init_part0_A_const_287, A_arbace_pprint_cl_format__init_part0_A_const_292); var tmp50 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp51 any = A_arbace_pprint_cl_format__init_part0_A_const_209; var tmp52 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp53 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp53 = lang.PersistentArrayMap_EMPTY; var tmp54 any = tmp53.Ref(); var tmp55 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp56 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000340_A_New(); var tmp57 *jrt.Class; var fncls__73 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000340_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_73, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000340_A_fn_class = fncls__73d; tmp57 = fncls__73d } else { tmp57 = fncls__73 }; var tmp58 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp47, tmp48, tmp49, tmp50, tmp51, tmp52, tmp54, tmp55, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp56, tmp57, nil))); var tmp59 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp60 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp61 any = A_arbace_pprint_cl_format__init_part0_A_const_210; var tmp62 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp63 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_271, A_arbace_pprint_cl_format__init_part0_A_const_293, A_arbace_pprint_cl_format__init_part0_A_const_277, A_arbace_pprint_cl_format__init_part0_A_const_294, A_arbace_pprint_cl_format__init_part0_A_const_285, A_arbace_pprint_cl_format__init_part0_A_const_295, A_arbace_pprint_cl_format__init_part0_A_const_287, A_arbace_pprint_cl_format__init_part0_A_const_296); var tmp64 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp65 any = A_arbace_pprint_cl_format__init_part0_A_const_211; var tmp66 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp67 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp67 = lang.PersistentArrayMap_EMPTY; var tmp68 any = tmp67.Ref(); var tmp69 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp70 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000344_A_New(); var tmp71 *jrt.Class; var fncls__74 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000344_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_74, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000344_A_fn_class = fncls__74d; tmp71 = fncls__74d } else { tmp71 = fncls__74 }; var tmp72 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp60, tmp61, tmp62, tmp63, tmp64, tmp65, tmp66, tmp68, tmp69, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp70, tmp71, nil))); var tmp73 any = A_arbace_pprint_cl_format__init_part0_A_const_212; var tmp74 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp75 any = A_arbace_pprint_cl_format__init_part0_A_const_212; var tmp76 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp77 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_271, A_arbace_pprint_cl_format__init_part0_A_const_297, A_arbace_pprint_cl_format__init_part0_A_const_277, A_arbace_pprint_cl_format__init_part0_A_const_298, A_arbace_pprint_cl_format__init_part0_A_const_285, A_arbace_pprint_cl_format__init_part0_A_const_299, A_arbace_pprint_cl_format__init_part0_A_const_287, A_arbace_pprint_cl_format__init_part0_A_const_300); var tmp78 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp79 any = A_arbace_pprint_cl_format__init_part0_A_const_213; var tmp80 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp81 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp81 = lang.PersistentArrayMap_EMPTY; var tmp82 any = tmp81.Ref(); var tmp83 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp84 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000348_A_New(); var tmp85 *jrt.Class; var fncls__75 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000348_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_75, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000348_A_fn_class = fncls__75d; tmp85 = fncls__75d } else { tmp85 = fncls__75 }; var tmp86 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp74, tmp75, tmp76, tmp77, tmp78, tmp79, tmp80, tmp82, tmp83, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp84, tmp85, nil))); var tmp87 any = A_arbace_pprint_cl_format__init_part0_A_const_214; var tmp88 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp89 any = A_arbace_pprint_cl_format__init_part0_A_const_214; var tmp90 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp91 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_301, A_arbace_pprint_cl_format__init_part0_A_const_302, A_arbace_pprint_cl_format__init_part0_A_const_271, A_arbace_pprint_cl_format__init_part0_A_const_303, A_arbace_pprint_cl_format__init_part0_A_const_277, A_arbace_pprint_cl_format__init_part0_A_const_304, A_arbace_pprint_cl_format__init_part0_A_const_285, A_arbace_pprint_cl_format__init_part0_A_const_305, A_arbace_pprint_cl_format__init_part0_A_const_287, A_arbace_pprint_cl_format__init_part0_A_const_306); var tmp92 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp93 any = A_arbace_pprint_cl_format__init_part0_A_const_215; var tmp94 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp95 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp95 = lang.PersistentArrayMap_EMPTY; var tmp96 any = tmp95.Ref(); var tmp97 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp98 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000352_A_New(); var tmp99 *jrt.Class; var fncls__76 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000352_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_76, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000352_A_fn_class = fncls__76d; tmp99 = fncls__76d } else { tmp99 = fncls__76 }; var tmp100 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp88, tmp89, tmp90, tmp91, tmp92, tmp93, tmp94, tmp96, tmp97, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp98, tmp99, nil))); var tmp101 any = A_arbace_pprint_cl_format__init_part0_A_const_216; var tmp102 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp103 any = A_arbace_pprint_cl_format__init_part0_A_const_216; var tmp104 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp105 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke__O(); var tmp106 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp107 any = A_arbace_pprint_cl_format__init_part0_A_const_217; var tmp108 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp109 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp109 = lang.PersistentArrayMap_EMPTY; var tmp110 any = tmp109.Ref(); var tmp111 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp112 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000364_A_New(); var tmp113 *jrt.Class; var fncls__77 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000364_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_77, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000364_A_fn_class = fncls__77d; tmp113 = fncls__77d } else { tmp113 = fncls__77 }; var tmp114 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp102, tmp103, tmp104, tmp105, tmp106, tmp107, tmp108, tmp110, tmp111, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp112, tmp113, nil))); var tmp115 any = A_arbace_pprint_cl_format__init_part0_A_const_218; var tmp116 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp117 any = A_arbace_pprint_cl_format__init_part0_A_const_218; var tmp118 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp119 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_307, A_arbace_pprint_cl_format__init_part0_A_const_308); var tmp120 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp121 any = A_arbace_pprint_cl_format__init_part0_A_const_219; var tmp122 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp123 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp123 = lang.PersistentArrayMap_EMPTY; var tmp124 any = tmp123.Ref(); var tmp125 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp126 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000371_A_New(); var tmp127 *jrt.Class; var fncls__78 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000371_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_78, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000371_A_fn_class = fncls__78d; tmp127 = fncls__78d } else { tmp127 = fncls__78 }; var tmp128 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp116, tmp117, tmp118, tmp119, tmp120, tmp121, tmp122, tmp124, tmp125, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp126, tmp127, nil))); var tmp129 any = A_arbace_pprint_cl_format__init_part0_A_const_220; var tmp130 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp131 any = A_arbace_pprint_cl_format__init_part0_A_const_220; var tmp132 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp133 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_309, A_arbace_pprint_cl_format__init_part0_A_const_310, A_arbace_pprint_cl_format__init_part0_A_const_311, A_arbace_pprint_cl_format__init_part0_A_const_312, A_arbace_pprint_cl_format__init_part0_A_const_313, A_arbace_pprint_cl_format__init_part0_A_const_314, A_arbace_pprint_cl_format__init_part0_A_const_315, A_arbace_pprint_cl_format__init_part0_A_const_316, A_arbace_pprint_cl_format__init_part0_A_const_277, A_arbace_pprint_cl_format__init_part0_A_const_317); var tmp134 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp135 any = A_arbace_pprint_cl_format__init_part0_A_const_221; var tmp136 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp137 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp137 = lang.PersistentArrayMap_EMPTY; var tmp138 any = tmp137.Ref(); var tmp139 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp140 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000373_A_New(); var tmp141 *jrt.Class; var fncls__79 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000373_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_79, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000373_A_fn_class = fncls__79d; tmp141 = fncls__79d } else { tmp141 = fncls__79 }; var tmp142 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp130, tmp131, tmp132, tmp133, tmp134, tmp135, tmp136, tmp138, tmp139, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp140, tmp141, nil))); var tmp143 any = A_arbace_pprint_cl_format__init_part0_A_const_222; var tmp144 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp145 any = A_arbace_pprint_cl_format__init_part0_A_const_222; var tmp146 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp147 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_309, A_arbace_pprint_cl_format__init_part0_A_const_318, A_arbace_pprint_cl_format__init_part0_A_const_311, A_arbace_pprint_cl_format__init_part0_A_const_319, A_arbace_pprint_cl_format__init_part0_A_const_320, A_arbace_pprint_cl_format__init_part0_A_const_321, A_arbace_pprint_cl_format__init_part0_A_const_313, A_arbace_pprint_cl_format__init_part0_A_const_322, A_arbace_pprint_cl_format__init_part0_A_const_315, A_arbace_pprint_cl_format__init_part0_A_const_323, A_arbace_pprint_cl_format__init_part0_A_const_277, A_arbace_pprint_cl_format__init_part0_A_const_324, A_arbace_pprint_cl_format__init_part0_A_const_325, A_arbace_pprint_cl_format__init_part0_A_const_326); var tmp148 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp149 any = A_arbace_pprint_cl_format__init_part0_A_const_223; var tmp150 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp151 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp151 = lang.PersistentArrayMap_EMPTY; var tmp152 any = tmp151.Ref(); var tmp153 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp154 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000375_A_New(); var tmp155 *jrt.Class; var fncls__80 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000375_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_80, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000375_A_fn_class = fncls__80d; tmp155 = fncls__80d } else { tmp155 = fncls__80 }; var tmp156 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp144, tmp145, tmp146, tmp147, tmp148, tmp149, tmp150, tmp152, tmp153, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp154, tmp155, nil))); var tmp157 any = A_arbace_pprint_cl_format__init_part0_A_const_224; var tmp158 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp159 any = A_arbace_pprint_cl_format__init_part0_A_const_224; var tmp160 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp161 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_309, A_arbace_pprint_cl_format__init_part0_A_const_327, A_arbace_pprint_cl_format__init_part0_A_const_311, A_arbace_pprint_cl_format__init_part0_A_const_328, A_arbace_pprint_cl_format__init_part0_A_const_320, A_arbace_pprint_cl_format__init_part0_A_const_329, A_arbace_pprint_cl_format__init_part0_A_const_313, A_arbace_pprint_cl_format__init_part0_A_const_330, A_arbace_pprint_cl_format__init_part0_A_const_315, A_arbace_pprint_cl_format__init_part0_A_const_331, A_arbace_pprint_cl_format__init_part0_A_const_277, A_arbace_pprint_cl_format__init_part0_A_const_332, A_arbace_pprint_cl_format__init_part0_A_const_325, A_arbace_pprint_cl_format__init_part0_A_const_333); var tmp162 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp163 any = A_arbace_pprint_cl_format__init_part0_A_const_225; var tmp164 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp165 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp165 = lang.PersistentArrayMap_EMPTY; var tmp166 any = tmp165.Ref(); var tmp167 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp168 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000377_A_New(); var tmp169 *jrt.Class; var fncls__81 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000377_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_81, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000377_A_fn_class = fncls__81d; tmp169 = fncls__81d } else { tmp169 = fncls__81 }; var tmp170 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp158, tmp159, tmp160, tmp161, tmp162, tmp163, tmp164, tmp166, tmp167, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp168, tmp169, nil))); var tmp171 any = A_arbace_pprint_cl_format__init_part0_A_const_226; var tmp172 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp173 any = A_arbace_pprint_cl_format__init_part0_A_const_226; var tmp174 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp175 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_311, A_arbace_pprint_cl_format__init_part0_A_const_334, A_arbace_pprint_cl_format__init_part0_A_const_335, A_arbace_pprint_cl_format__init_part0_A_const_336, A_arbace_pprint_cl_format__init_part0_A_const_309, A_arbace_pprint_cl_format__init_part0_A_const_337, A_arbace_pprint_cl_format__init_part0_A_const_277, A_arbace_pprint_cl_format__init_part0_A_const_338); var tmp176 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp177 any = A_arbace_pprint_cl_format__init_part0_A_const_227; var tmp178 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp179 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp179 = lang.PersistentArrayMap_EMPTY; var tmp180 any = tmp179.Ref(); var tmp181 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp182 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000379_A_New(); var tmp183 *jrt.Class; var fncls__82 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000379_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_82, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000379_A_fn_class = fncls__82d; tmp183 = fncls__82d } else { tmp183 = fncls__82 }; var tmp184 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp172, tmp173, tmp174, tmp175, tmp176, tmp177, tmp178, tmp180, tmp181, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp182, tmp183, nil))); var tmp185 any = A_arbace_pprint_cl_format__init_part0_A_const_228; var tmp186 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp187 any = A_arbace_pprint_cl_format__init_part0_A_const_228; var tmp188 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp189 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_339, A_arbace_pprint_cl_format__init_part0_A_const_340); var tmp190 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp191 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp191 = lang.PersistentHashSet_EMPTY; var tmp192 any = tmp191.Ref(); var tmp193 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp194 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp194 = lang.PersistentArrayMap_EMPTY; var tmp195 any = tmp194.Ref(); var tmp196 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp197 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000381_A_New(); var tmp198 *jrt.Class; var fncls__83 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000381_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_83, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000381_A_fn_class = fncls__83d; tmp198 = fncls__83d } else { tmp198 = fncls__83 }; var tmp199 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp186, tmp187, tmp188, tmp189, tmp190, tmp192, tmp193, tmp195, tmp196, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp197, tmp198, nil))); var tmp200 any = A_arbace_pprint_cl_format__init_part0_A_const_229; var tmp201 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp202 any = A_arbace_pprint_cl_format__init_part0_A_const_229; var tmp203 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp204 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_339, A_arbace_pprint_cl_format__init_part0_A_const_341); var tmp205 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp206 any = A_arbace_pprint_cl_format__init_part0_A_const_230; var tmp207 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp208 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp208 = lang.PersistentArrayMap_EMPTY; var tmp209 any = tmp208.Ref(); var tmp210 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp211 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000385_A_New(); var tmp212 *jrt.Class; var fncls__84 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000385_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_84, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000385_A_fn_class = fncls__84d; tmp212 = fncls__84d } else { tmp212 = fncls__84 }; var tmp213 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp201, tmp202, tmp203, tmp204, tmp205, tmp206, tmp207, tmp209, tmp210, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp211, tmp212, nil))); var tmp214 any = A_arbace_pprint_cl_format__init_part0_A_const_231; var tmp215 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp216 any = A_arbace_pprint_cl_format__init_part0_A_const_231; var tmp217 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp218 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_339, A_arbace_pprint_cl_format__init_part0_A_const_342); var tmp219 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp220 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp220 = lang.PersistentHashSet_EMPTY; var tmp221 any = tmp220.Ref(); var tmp222 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp223 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp223 = lang.PersistentArrayMap_EMPTY; var tmp224 any = tmp223.Ref(); var tmp225 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp226 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000389_A_New(); var tmp227 *jrt.Class; var fncls__85 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000389_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_85, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000389_A_fn_class = fncls__85d; tmp227 = fncls__85d } else { tmp227 = fncls__85 }; var tmp228 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp215, tmp216, tmp217, tmp218, tmp219, tmp221, tmp222, tmp224, tmp225, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp226, tmp227, nil))); var tmp229 any = A_arbace_pprint_cl_format__init_part0_A_const_232; var tmp230 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp231 any = A_arbace_pprint_cl_format__init_part0_A_const_232; var tmp232 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp233 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_335, A_arbace_pprint_cl_format__init_part0_A_const_343); var tmp234 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp235 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp235 = lang.PersistentHashSet_EMPTY; var tmp236 any = tmp235.Ref(); var tmp237 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp238 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp238 = lang.PersistentArrayMap_EMPTY; var tmp239 any = tmp238.Ref(); var tmp240 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp241 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000393_A_New(); var tmp242 *jrt.Class; var fncls__86 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000393_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_86, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000393_A_fn_class = fncls__86d; tmp242 = fncls__86d } else { tmp242 = fncls__86 }; var tmp243 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp230, tmp231, tmp232, tmp233, tmp234, tmp236, tmp237, tmp239, tmp240, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp241, tmp242, nil))); var tmp244 any = A_arbace_pprint_cl_format__init_part0_A_const_233; var tmp245 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp246 any = A_arbace_pprint_cl_format__init_part0_A_const_233; var tmp247 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp248 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke__O(); var tmp249 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp250 any = A_arbace_pprint_cl_format__init_part0_A_const_234; var tmp251 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp252 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp252 = lang.PersistentArrayMap_EMPTY; var tmp253 any = tmp252.Ref(); var tmp254 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp255 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000397_A_New(); var tmp256 *jrt.Class; var fncls__87 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000397_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_87, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000397_A_fn_class = fncls__87d; tmp256 = fncls__87d } else { tmp256 = fncls__87 }; var tmp257 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp245, tmp246, tmp247, tmp248, tmp249, tmp250, tmp251, tmp253, tmp254, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp255, tmp256, nil))); var tmp258 any = A_arbace_pprint_cl_format__init_part0_A_const_235; var tmp259 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp260 any = A_arbace_pprint_cl_format__init_part0_A_const_235; var tmp261 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp262 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_344, A_arbace_pprint_cl_format__init_part0_A_const_345, A_arbace_pprint_cl_format__init_part0_A_const_273, A_arbace_pprint_cl_format__init_part0_A_const_346); var tmp263 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp264 any = A_arbace_pprint_cl_format__init_part0_A_const_236; var tmp265 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp266 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp266 = lang.PersistentArrayMap_EMPTY; var tmp267 any = tmp266.Ref(); var tmp268 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp269 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000401_A_New(); var tmp270 *jrt.Class; var fncls__88 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000401_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_88, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000401_A_fn_class = fncls__88d; tmp270 = fncls__88d } else { tmp270 = fncls__88 }; var tmp271 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp259, tmp260, tmp261, tmp262, tmp263, tmp264, tmp265, tmp267, tmp268, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp269, tmp270, nil))); var tmp272 any = A_arbace_pprint_cl_format__init_part0_A_const_237; var tmp273 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp274 any = A_arbace_pprint_cl_format__init_part0_A_const_237; var tmp275 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp276 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_335, A_arbace_pprint_cl_format__init_part0_A_const_347); var tmp277 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp278 any = A_arbace_pprint_cl_format__init_part0_A_const_238; var tmp279 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp280 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp280 = lang.PersistentArrayMap_EMPTY; var tmp281 any = tmp280.Ref(); var tmp282 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp283 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000407_A_New(); var tmp284 *jrt.Class; var fncls__89 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000407_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_89, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000407_A_fn_class = fncls__89d; tmp284 = fncls__89d } else { tmp284 = fncls__89 }; var tmp285 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp273, tmp274, tmp275, tmp276, tmp277, tmp278, tmp279, tmp281, tmp282, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp283, tmp284, nil))); var tmp286 any = A_arbace_pprint_cl_format__init_part0_A_const_239; var tmp287 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp288 any = A_arbace_pprint_cl_format__init_part0_A_const_239; var tmp289 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp290 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke__O(); var tmp291 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp292 any = A_arbace_pprint_cl_format__init_part0_A_const_240; var tmp293 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp294 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp294 = lang.PersistentArrayMap_EMPTY; var tmp295 any = tmp294.Ref(); var tmp296 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp297 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000413_A_New(); var tmp298 *jrt.Class; var fncls__90 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000413_A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_90, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000413_A_fn_class = fncls__90d; tmp298 = fncls__90d } else { tmp298 = fncls__90 }; var tmp299 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp287, tmp288, tmp289, tmp290, tmp291, tmp292, tmp293, tmp295, tmp296, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp297, tmp298, nil))); var tmp300 any = A_arbace_pprint_cl_format__init_part0_A_const_241; var tmp301 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp302 any = A_arbace_pprint_cl_format__init_part0_A_const_241; var tmp303 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp304 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke__O(); var tmp305 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp306 any = A_arbace_pprint_cl_format__init_part0_A_const_242; var tmp307 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp308 any = A_arbace_pprint_cl_format__init_part0_A_const_243; var tmp309 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp310 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000428_A_New(); var tmp311 *jrt.Class; var fncls__91 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000428_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_91, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000428_A_fn_class = fncls__91d; tmp311 = fncls__91d } else { tmp311 = fncls__91 }; var tmp312 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp301, tmp302, tmp303, tmp304, tmp305, tmp306, tmp307, tmp308, tmp309, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp310, tmp311, nil))); var tmp313 any = A_arbace_pprint_cl_format__init_part0_A_const_244; var tmp314 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp315 any = A_arbace_pprint_cl_format__init_part0_A_const_244; var tmp316 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp317 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke__O(); var tmp318 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp319 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp319 = lang.PersistentHashSet_EMPTY; var tmp320 any = tmp319.Ref(); var tmp321 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp322 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp322 = lang.PersistentArrayMap_EMPTY; var tmp323 any = tmp322.Ref(); var tmp324 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp325 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000432_A_New(); var tmp326 *jrt.Class; var fncls__92 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000432_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_92, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000432_A_fn_class = fncls__92d; tmp326 = fncls__92d } else { tmp326 = fncls__92 }; var tmp327 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp314, tmp315, tmp316, tmp317, tmp318, tmp320, tmp321, tmp323, tmp324, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp325, tmp326, nil))); var tmp328 any = A_arbace_pprint_cl_format__init_part0_A_const_245; var tmp329 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp330 any = A_arbace_pprint_cl_format__init_part0_A_const_245; var tmp331 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp332 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_348, A_arbace_pprint_cl_format__init_part0_A_const_349); var tmp333 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp334 any = A_arbace_pprint_cl_format__init_part0_A_const_246; var tmp335 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp336 any = A_arbace_pprint_cl_format__init_part0_A_const_247; var tmp337 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp338 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000434_A_New(); var tmp339 *jrt.Class; var fncls__93 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000434_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_93, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000434_A_fn_class = fncls__93d; tmp339 = fncls__93d } else { tmp339 = fncls__93 }; var tmp340 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp329, tmp330, tmp331, tmp332, tmp333, tmp334, tmp335, tmp336, tmp337, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp338, tmp339, nil))); var tmp341 any = A_arbace_pprint_cl_format__init_part0_A_const_248; var tmp342 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp343 any = A_arbace_pprint_cl_format__init_part0_A_const_248; var tmp344 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp345 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_350, A_arbace_pprint_cl_format__init_part0_A_const_351, A_arbace_pprint_cl_format__init_part0_A_const_352, A_arbace_pprint_cl_format__init_part0_A_const_353); var tmp346 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp347 any = A_arbace_pprint_cl_format__init_part0_A_const_249; var tmp348 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp349 any = A_arbace_pprint_cl_format__init_part0_A_const_250; var tmp350 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp351 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000436_A_New(); var tmp352 *jrt.Class; var fncls__94 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000436_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_94, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000436_A_fn_class = fncls__94d; tmp352 = fncls__94d } else { tmp352 = fncls__94 }; var tmp353 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp342, tmp343, tmp344, tmp345, tmp346, tmp347, tmp348, tmp349, tmp350, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp351, tmp352, nil))); var tmp354 any = A_arbace_pprint_cl_format__init_part0_A_const_251; var tmp355 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp356 any = A_arbace_pprint_cl_format__init_part0_A_const_251; var tmp357 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp358 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke__O(); var tmp359 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp360 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp360 = lang.PersistentHashSet_EMPTY; var tmp361 any = tmp360.Ref(); var tmp362 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp363 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp363 = lang.PersistentArrayMap_EMPTY; var tmp364 any = tmp363.Ref(); var tmp365 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp366 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000438_A_New(); var tmp367 *jrt.Class; var fncls__95 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000438_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_95, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000438_A_fn_class = fncls__95d; tmp367 = fncls__95d } else { tmp367 = fncls__95 }; var tmp368 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp355, tmp356, tmp357, tmp358, tmp359, tmp361, tmp362, tmp364, tmp365, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp366, tmp367, nil))); var tmp369 any = A_arbace_pprint_cl_format__init_part0_A_const_252; var tmp370 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp371 any = A_arbace_pprint_cl_format__init_part0_A_const_252; var tmp372 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp373 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_354, A_arbace_pprint_cl_format__init_part0_A_const_355); var tmp374 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp375 any = A_arbace_pprint_cl_format__init_part0_A_const_253; var tmp376 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp377 any = A_arbace_pprint_cl_format__init_part0_A_const_254; var tmp378 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp379 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000440_A_New(); var tmp380 *jrt.Class; var fncls__96 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000440_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_96, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000440_A_fn_class = fncls__96d; tmp380 = fncls__96d } else { tmp380 = fncls__96 }; var tmp381 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp370, tmp371, tmp372, tmp373, tmp374, tmp375, tmp376, tmp377, tmp378, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp379, tmp380, nil))); var tmp382 any = A_arbace_pprint_cl_format__init_part0_A_const_255; var tmp383 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp384 any = A_arbace_pprint_cl_format__init_part0_A_const_255; var tmp385 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp386 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke__O(); var tmp387 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp388 any = A_arbace_pprint_cl_format__init_part0_A_const_256; var tmp389 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp390 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp390 = lang.PersistentArrayMap_EMPTY; var tmp391 any = tmp390.Ref(); var tmp392 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp393 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000442_A_New(); var tmp394 *jrt.Class; var fncls__97 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000442_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_97, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000442_A_fn_class = fncls__97d; tmp394 = fncls__97d } else { tmp394 = fncls__97 }; var tmp395 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp383, tmp384, tmp385, tmp386, tmp387, tmp388, tmp389, tmp391, tmp392, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp393, tmp394, nil))); var tmp396 any = A_arbace_pprint_cl_format__init_part0_A_const_257; var tmp397 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp398 any = A_arbace_pprint_cl_format__init_part0_A_const_257; var tmp399 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp400 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_271, A_arbace_pprint_cl_format__init_part0_A_const_356, A_arbace_pprint_cl_format__init_part0_A_const_273, A_arbace_pprint_cl_format__init_part0_A_const_357, A_arbace_pprint_cl_format__init_part0_A_const_275, A_arbace_pprint_cl_format__init_part0_A_const_358, A_arbace_pprint_cl_format__init_part0_A_const_277, A_arbace_pprint_cl_format__init_part0_A_const_359); var tmp401 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp402 any = A_arbace_pprint_cl_format__init_part0_A_const_258; var tmp403 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp404 any = A_arbace_pprint_cl_format__init_part0_A_const_259; var tmp405 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp406 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000444_A_New(); var tmp407 *jrt.Class; var fncls__98 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000444_A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_98, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000444_A_fn_class = fncls__98d; tmp407 = fncls__98d } else { tmp407 = fncls__98 }; var tmp408 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp397, tmp398, tmp399, tmp400, tmp401, tmp402, tmp403, tmp404, tmp405, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp406, tmp407, nil))); var tmp409 any = A_arbace_pprint_cl_format__init_part0_A_const_260; var tmp410 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp411 any = A_arbace_pprint_cl_format__init_part0_A_const_260; var tmp412 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp413 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke__O(); var tmp414 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp415 any = A_arbace_pprint_cl_format__init_part0_A_const_261; var tmp416 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp417 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp417 = lang.PersistentArrayMap_EMPTY; var tmp418 any = tmp417.Ref(); var tmp419 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp420 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000446_A_New(); var tmp421 *jrt.Class; var fncls__99 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000446_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_99, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000446_A_fn_class = fncls__99d; tmp421 = fncls__99d } else { tmp421 = fncls__99 }; var tmp422 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp410, tmp411, tmp412, tmp413, tmp414, tmp415, tmp416, tmp418, tmp419, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp420, tmp421, nil))); var tmp423 any = A_arbace_pprint_cl_format__init_part0_A_const_262; var tmp424 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp425 any = A_arbace_pprint_cl_format__init_part0_A_const_262; var tmp426 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp427 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_360, A_arbace_pprint_cl_format__init_part0_A_const_361, A_arbace_pprint_cl_format__init_part0_A_const_362, A_arbace_pprint_cl_format__init_part0_A_const_363, A_arbace_pprint_cl_format__init_part0_A_const_364, A_arbace_pprint_cl_format__init_part0_A_const_365); var tmp428 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp429 any = A_arbace_pprint_cl_format__init_part0_A_const_263; var tmp430 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp431 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp431 = lang.PersistentArrayMap_EMPTY; var tmp432 any = tmp431.Ref(); var tmp433 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp434 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000448_A_New(); var tmp435 *jrt.Class; var fncls__100 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000448_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_100, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000448_A_fn_class = fncls__100d; tmp435 = fncls__100d } else { tmp435 = fncls__100 }; var tmp436 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp424, tmp425, tmp426, tmp427, tmp428, tmp429, tmp430, tmp432, tmp433, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp434, tmp435, nil))); var tmp437 any = A_arbace_pprint_cl_format__init_part0_A_const_264; var tmp438 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp439 any = A_arbace_pprint_cl_format__init_part0_A_const_264; var tmp440 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp441 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke__O(); var tmp442 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp443 any = A_arbace_pprint_cl_format__init_part0_A_const_265; var tmp444 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp445 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp445 = lang.PersistentArrayMap_EMPTY; var tmp446 any = tmp445.Ref(); var tmp447 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp448 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000452_A_New(); var tmp449 *jrt.Class; var fncls__101 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000452_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_101, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000452_A_fn_class = fncls__101d; tmp449 = fncls__101d } else { tmp449 = fncls__101 }; var tmp450 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp438, tmp439, tmp440, tmp441, tmp442, tmp443, tmp444, tmp446, tmp447, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp448, tmp449, nil))); var tmp451 any = A_arbace_pprint_cl_format__init_part0_A_const_266; var tmp452 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp453 any = A_arbace_pprint_cl_format__init_part0_A_const_266; var tmp454 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp455 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke__O(); var tmp456 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp457 any = A_arbace_pprint_cl_format__init_part0_A_const_267; var tmp458 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp459 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp459 = lang.PersistentArrayMap_EMPTY; var tmp460 any = tmp459.Ref(); var tmp461 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp462 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000464_A_New(); var tmp463 *jrt.Class; var fncls__102 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000464_A_fn_class; if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_102, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000464_A_fn_class = fncls__102d; tmp463 = fncls__102d } else { tmp463 = fncls__102 }; var tmp464 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp452, tmp453, tmp454, tmp455, tmp456, tmp457, tmp458, tmp460, tmp461, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp462, tmp463, nil))); var tmp465 any = A_arbace_pprint_cl_format__init_part0_A_const_268; var tmp466 any = A_arbace_pprint_cl_format__init_part0_A_const_198; var tmp467 any = A_arbace_pprint_cl_format__init_part0_A_const_268; var tmp468 any = A_arbace_pprint_cl_format__init_part0_A_const_36; var tmp469 any = lang.IFn_Cast(A_arbace_pprint_cl_format__init_part0_A_const_199.GetRawRoot__O()).Invoke_O_O__O(A_arbace_pprint_cl_format__init_part0_A_const_335, A_arbace_pprint_cl_format__init_part0_A_const_366); var tmp470 any = A_arbace_pprint_cl_format__init_part0_A_const_200; var tmp471 any = A_arbace_pprint_cl_format__init_part0_A_const_269; var tmp472 any = A_arbace_pprint_cl_format__init_part0_A_const_202; var tmp473 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp473 = lang.PersistentArrayMap_EMPTY; var tmp474 any = tmp473.Ref(); var tmp475 any = A_arbace_pprint_cl_format__init_part0_A_const_203; var tmp476 any = aot_arbace_pprint.A_arbace_pprint_fn__1819000466_A_New(); var tmp477 *jrt.Class; var fncls__103 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_fn__1819000466_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_103, false); aot_arbace_pprint.A_arbace_pprint_fn__1819000466_A_fn_class = fncls__103d; tmp477 = fncls__103d } else { tmp477 = fncls__103 }; tmp1.BindRoot_O__V(tmp2.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp16, tmp17, tmp30, tmp31, tmp44, tmp45, tmp58, tmp59, tmp72, tmp73, tmp86, tmp87, tmp100, tmp101, tmp114, tmp115, tmp128, tmp129, tmp142, tmp143, tmp156, tmp157, tmp170, tmp171, tmp184, tmp185, tmp199, tmp200, tmp213, tmp214, tmp228, tmp229, tmp243, tmp244, tmp257, tmp258, tmp271, tmp272, tmp285, tmp286, tmp299, tmp300, tmp312, tmp313, tmp327, tmp328, tmp340, tmp341, tmp353, tmp354, tmp368, tmp369, tmp381, tmp382, tmp395, tmp396, tmp408, tmp409, tmp422, tmp423, tmp436, tmp437, tmp450, tmp451, tmp464, tmp465, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp466, tmp467, tmp468, tmp469, tmp470, tmp471, tmp472, tmp474, tmp475, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp476, tmp477, nil)))))))); var tmp478 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_195; tmp478.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_270)); return A_arbace_pprint_cl_format__init_part0_A_const_195 }





























































































































































































































































































func A_arbace_pprint_cl_format__init_part0_A_Unit93__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1613, 1); A_arbace_pprint_cl_format__init_part0_A_const_367.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_368); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_367; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_369)); return A_arbace_pprint_cl_format__init_part0_A_const_367 }

func A_arbace_pprint_cl_format__init_part0_A_Unit94__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1615, 1); A_arbace_pprint_cl_format__init_part0_A_const_370.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_371); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_370; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_372)); return A_arbace_pprint_cl_format__init_part0_A_const_370 }


func A_arbace_pprint_cl_format__init_part0_A_Unit95__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1618, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_373; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_extract_param_A_New(); var tmp3 *jrt.Class; var fncls__104 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_extract_param_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_104, false); aot_arbace_pprint.A_arbace_pprint_extract_param_A_fn_class = fncls__104d; tmp3 = fncls__104d } else { tmp3 = fncls__104 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_373; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_374)); return A_arbace_pprint_cl_format__init_part0_A_const_373 }













func A_arbace_pprint_cl_format__init_part0_A_Unit96__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1632, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_375; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_extract_params_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_extract_params_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_105, false); aot_arbace_pprint.A_arbace_pprint_extract_params_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_375; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_376)); return A_arbace_pprint_cl_format__init_part0_A_const_375 }


func A_arbace_pprint_cl_format__init_part0_A_Unit97__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1635, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_377; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_translate_param_A_New(); var tmp3 *jrt.Class; var fncls__106 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_translate_param_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_106, false); aot_arbace_pprint.A_arbace_pprint_translate_param_A_fn_class = fncls__106d; tmp3 = fncls__106d } else { tmp3 = fncls__106 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_377; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_378)); return A_arbace_pprint_cl_format__init_part0_A_const_377 }











func A_arbace_pprint_cl_format__init_part0_A_Unit98__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1647, 1); A_arbace_pprint_cl_format__init_part0_A_const_379.BindRoot_O__V(A_arbace_pprint_cl_format__init_part0_A_const_380); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_379; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_381)); return A_arbace_pprint_cl_format__init_part0_A_const_379 }


func A_arbace_pprint_cl_format__init_part0_A_Unit99__O() any { A_arbace_pprint_cl_format__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1650, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_382; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_extract_flags_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_extract_flags_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_107, false); aot_arbace_pprint.A_arbace_pprint_extract_flags_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part0_A_const_382; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part0_A_const_383)); return A_arbace_pprint_cl_format__init_part0_A_const_382 }














func A_arbace_pprint_cl_format__init_part1_A_Unit100__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1665, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_0; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_check_flags_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_check_flags_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_109, false); aot_arbace_pprint.A_arbace_pprint_check_flags_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_1)); return A_arbace_pprint_cl_format__init_part1_A_const_0 }
//line :1665:1
func A_arbace_pprint_cl_format__init_part1_A_Init__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); return nil }
//line :1665:1
func A_arbace_pprint_cl_format__init_part1_A_Load__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); A_arbace_pprint_cl_format__init_part1_A_Unit100__O(); A_arbace_pprint_cl_format__init_part1_A_Unit101__O(); A_arbace_pprint_cl_format__init_part1_A_Unit102__O(); A_arbace_pprint_cl_format__init_part1_A_Unit103__O(); A_arbace_pprint_cl_format__init_part1_A_Unit104__O(); A_arbace_pprint_cl_format__init_part1_A_Unit105__O(); A_arbace_pprint_cl_format__init_part1_A_Unit106__O(); A_arbace_pprint_cl_format__init_part1_A_Unit107__O(); A_arbace_pprint_cl_format__init_part1_A_Unit108__O(); A_arbace_pprint_cl_format__init_part1_A_Unit109__O(); A_arbace_pprint_cl_format__init_part1_A_Unit110__O(); A_arbace_pprint_cl_format__init_part1_A_Unit111__O(); A_arbace_pprint_cl_format__init_part1_A_Unit112__O(); A_arbace_pprint_cl_format__init_part1_A_Unit113__O(); A_arbace_pprint_cl_format__init_part1_A_Unit114__O(); A_arbace_pprint_cl_format__init_part1_A_Unit115__O(); A_arbace_pprint_cl_format__init_part1_A_Unit116__O(); A_arbace_pprint_cl_format__init_part1_A_Unit117__O(); A_arbace_pprint_cl_format__init_part1_A_Unit118__O(); A_arbace_pprint_cl_format__init_part1_A_Unit119__O(); A_arbace_pprint_cl_format__init_part1_A_Unit120__O(); A_arbace_pprint_cl_format__init_part1_A_Unit121__O(); return nil }












func A_arbace_pprint_cl_format__init_part1_A_Unit101__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1678, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_2; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_map_params_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_map_params_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_110, false); aot_arbace_pprint.A_arbace_pprint_map_params_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_3)); return A_arbace_pprint_cl_format__init_part1_A_const_2 }





























func A_arbace_pprint_cl_format__init_part1_A_Unit102__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1708, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_4; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_compile_directive_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_compile_directive_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_111, false); aot_arbace_pprint.A_arbace_pprint_compile_directive_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_5)); return A_arbace_pprint_cl_format__init_part1_A_const_4 }



















func A_arbace_pprint_cl_format__init_part1_A_Unit103__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1728, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_6; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_compile_raw_string_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_compile_raw_string_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_112, false); aot_arbace_pprint.A_arbace_pprint_compile_raw_string_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_7)); return A_arbace_pprint_cl_format__init_part1_A_const_6 }


func A_arbace_pprint_cl_format__init_part1_A_Unit104__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1731, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_8; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_right_bracket_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_right_bracket_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_113, false); aot_arbace_pprint.A_arbace_pprint_right_bracket_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_9)); return A_arbace_pprint_cl_format__init_part1_A_const_8 }
func A_arbace_pprint_cl_format__init_part1_A_Unit105__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1732, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_10; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_separator_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_separator_QMARK__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_114, false); aot_arbace_pprint.A_arbace_pprint_separator_QMARK__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_11)); return A_arbace_pprint_cl_format__init_part1_A_const_10 }
func A_arbace_pprint_cl_format__init_part1_A_Unit106__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1733, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_12; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_else_separator_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_else_separator_QMARK__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_115, false); aot_arbace_pprint.A_arbace_pprint_else_separator_QMARK__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_13)); return A_arbace_pprint_cl_format__init_part1_A_const_12 }




func A_arbace_pprint_cl_format__init_part1_A_Unit107__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1738, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_15)); return A_arbace_pprint_cl_format__init_part1_A_const_14 }

func A_arbace_pprint_cl_format__init_part1_A_Unit108__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1740, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_16; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_process_bracket_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_process_bracket_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_116, false); aot_arbace_pprint.A_arbace_pprint_process_bracket_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_17)); return A_arbace_pprint_cl_format__init_part1_A_const_16 }








func A_arbace_pprint_cl_format__init_part1_A_Unit109__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1749, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_18; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_process_clause_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_process_clause_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_117, false); aot_arbace_pprint.A_arbace_pprint_process_clause_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_19)); return A_arbace_pprint_cl_format__init_part1_A_const_18 }























func A_arbace_pprint_cl_format__init_part1_A_Unit110__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1773, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_14; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_collect_clauses_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_collect_clauses_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_118, false); aot_arbace_pprint.A_arbace_pprint_collect_clauses_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_20)); return A_arbace_pprint_cl_format__init_part1_A_const_14 }
















































func A_arbace_pprint_cl_format__init_part1_A_Unit111__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1822, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_21; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_process_nesting_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_process_nesting_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_119, false); aot_arbace_pprint.A_arbace_pprint_process_nesting_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_22)); return A_arbace_pprint_cl_format__init_part1_A_const_21 }














func A_arbace_pprint_cl_format__init_part1_A_Unit112__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1837, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_23; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_compile_format_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_compile_format_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_120, false); aot_arbace_pprint.A_arbace_pprint_compile_format_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_24)); return A_arbace_pprint_cl_format__init_part1_A_const_23 }




















func A_arbace_pprint_cl_format__init_part1_A_Unit113__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1858, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_25; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_needs_pretty_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_needs_pretty_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_121, false); aot_arbace_pprint.A_arbace_pprint_needs_pretty_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_26)); return A_arbace_pprint_cl_format__init_part1_A_const_25 }












func A_arbace_pprint_cl_format__init_part1_A_Unit114__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1871, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_27; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_execute_format_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_execute_format_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_122, false); aot_arbace_pprint.A_arbace_pprint_execute_format_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_28)); return A_arbace_pprint_cl_format__init_part1_A_const_27 }


































func A_arbace_pprint_cl_format__init_part1_A_Unit115__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1906, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_29; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_pprint_cl_format__init_part1_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_cl_format__init_part1_A_const_23.GetRawRoot__O())); var tmp2 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_29; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_31)); return A_arbace_pprint_cl_format__init_part1_A_const_29 }

func A_arbace_pprint_cl_format__init_part1_A_Unit116__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1908, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_32; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_formatter_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_formatter_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_123, false); aot_arbace_pprint.A_arbace_pprint_formatter_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_33)); return A_arbace_pprint_cl_format__init_part1_A_const_32 }
//line :1908:1
func A_arbace_pprint_cl_format__init_part1_A_Unit117__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1908, 1); A_arbace_pprint_cl_format__init_part1_A_const_32.SetMacro__V(); return nil }
//line :1908:1
func A_arbace_pprint_cl_format__init_part1_A_Unit118__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1908, 1); return A_arbace_pprint_cl_format__init_part1_A_const_32 }



















func A_arbace_pprint_cl_format__init_part1_A_Unit119__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1928, 1); var tmp1 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_34; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_formatter_out_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_formatter_out_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_124, false); aot_arbace_pprint.A_arbace_pprint_formatter_out_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_cl_format__init_part1_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_cl_format__init_part1_A_const_35)); return A_arbace_pprint_cl_format__init_part1_A_const_34 }
//line :1928:1
func A_arbace_pprint_cl_format__init_part1_A_Unit120__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1928, 1); A_arbace_pprint_cl_format__init_part1_A_const_34.SetMacro__V(); return nil }
//line :1928:1
func A_arbace_pprint_cl_format__init_part1_A_Unit121__O() any { A_arbace_pprint_cl_format__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1928, 1); return A_arbace_pprint_cl_format__init_part1_A_const_34 }







type A_arbace_pprint_cl_format__init_A struct{ jrt.Object }

func A_arbace_pprint_cl_format__init_A_New() *A_arbace_pprint_cl_format__init_A { t := &A_arbace_pprint_cl_format__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_cl_format__init_A) Ctor() {}

func (t *A_arbace_pprint_cl_format__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_cl_format__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_cl_format__init_A_class }

func (t *A_arbace_pprint_cl_format__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_cl_format__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_pprint_cl_format__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_cl_format__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_cl_format__init_A); return ok }

func A_arbace_pprint_cl_format__init_A_Cast(x any) *A_arbace_pprint_cl_format__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_cl_format__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_cl_format__init_A_class)) }; return v }



type A_arbace_pprint_cl_format__init_part0_A struct{ jrt.Object }

var A_arbace_pprint_cl_format__init_part0_A_const_pool *jrt.RefArray

var A_arbace_pprint_cl_format__init_part0_A_const_0 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_1 any

var A_arbace_pprint_cl_format__init_part0_A_const_2 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_3 any

var A_arbace_pprint_cl_format__init_part0_A_const_4 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_5 any

var A_arbace_pprint_cl_format__init_part0_A_const_6 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_7 any

var A_arbace_pprint_cl_format__init_part0_A_const_8 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_9 any

var A_arbace_pprint_cl_format__init_part0_A_const_10 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_11 any

var A_arbace_pprint_cl_format__init_part0_A_const_12 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_13 any

var A_arbace_pprint_cl_format__init_part0_A_const_14 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_15 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_16 any

var A_arbace_pprint_cl_format__init_part0_A_const_17 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_18 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_19 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_20 any

var A_arbace_pprint_cl_format__init_part0_A_const_21 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_22 any

var A_arbace_pprint_cl_format__init_part0_A_const_23 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_24 any

var A_arbace_pprint_cl_format__init_part0_A_const_25 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_26 any

var A_arbace_pprint_cl_format__init_part0_A_const_27 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_28 any

var A_arbace_pprint_cl_format__init_part0_A_const_29 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_30 any

var A_arbace_pprint_cl_format__init_part0_A_const_31 any

var A_arbace_pprint_cl_format__init_part0_A_const_32 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_33 any

var A_arbace_pprint_cl_format__init_part0_A_const_34 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_35 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_36 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_37 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_38 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_39 any

var A_arbace_pprint_cl_format__init_part0_A_const_40 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_41 any

var A_arbace_pprint_cl_format__init_part0_A_const_42 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_43 any

var A_arbace_pprint_cl_format__init_part0_A_const_44 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_45 any

var A_arbace_pprint_cl_format__init_part0_A_const_46 any

var A_arbace_pprint_cl_format__init_part0_A_const_47 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_48 any

var A_arbace_pprint_cl_format__init_part0_A_const_49 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_50 any

var A_arbace_pprint_cl_format__init_part0_A_const_51 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_52 any

var A_arbace_pprint_cl_format__init_part0_A_const_53 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_54 any

var A_arbace_pprint_cl_format__init_part0_A_const_55 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_56 any

var A_arbace_pprint_cl_format__init_part0_A_const_57 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_58 any

var A_arbace_pprint_cl_format__init_part0_A_const_59 any

var A_arbace_pprint_cl_format__init_part0_A_const_60 any

var A_arbace_pprint_cl_format__init_part0_A_const_61 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_62 any

var A_arbace_pprint_cl_format__init_part0_A_const_63 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_64 any

var A_arbace_pprint_cl_format__init_part0_A_const_65 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_66 any

var A_arbace_pprint_cl_format__init_part0_A_const_67 any

var A_arbace_pprint_cl_format__init_part0_A_const_68 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_69 any

var A_arbace_pprint_cl_format__init_part0_A_const_70 any

var A_arbace_pprint_cl_format__init_part0_A_const_71 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_72 any

var A_arbace_pprint_cl_format__init_part0_A_const_73 any

var A_arbace_pprint_cl_format__init_part0_A_const_74 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_75 any

var A_arbace_pprint_cl_format__init_part0_A_const_76 any

var A_arbace_pprint_cl_format__init_part0_A_const_77 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_78 any

var A_arbace_pprint_cl_format__init_part0_A_const_79 any

var A_arbace_pprint_cl_format__init_part0_A_const_80 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_81 any

var A_arbace_pprint_cl_format__init_part0_A_const_82 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_83 any

var A_arbace_pprint_cl_format__init_part0_A_const_84 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_85 any

var A_arbace_pprint_cl_format__init_part0_A_const_86 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_87 any

var A_arbace_pprint_cl_format__init_part0_A_const_88 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_89 any

var A_arbace_pprint_cl_format__init_part0_A_const_90 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_91 any

var A_arbace_pprint_cl_format__init_part0_A_const_92 any

var A_arbace_pprint_cl_format__init_part0_A_const_93 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_94 any

var A_arbace_pprint_cl_format__init_part0_A_const_95 any

var A_arbace_pprint_cl_format__init_part0_A_const_96 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_97 any

var A_arbace_pprint_cl_format__init_part0_A_const_98 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_99 any

var A_arbace_pprint_cl_format__init_part0_A_const_100 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_101 any

var A_arbace_pprint_cl_format__init_part0_A_const_102 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_103 any

var A_arbace_pprint_cl_format__init_part0_A_const_104 any

var A_arbace_pprint_cl_format__init_part0_A_const_105 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_106 any

var A_arbace_pprint_cl_format__init_part0_A_const_107 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_108 any

var A_arbace_pprint_cl_format__init_part0_A_const_109 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_110 any

var A_arbace_pprint_cl_format__init_part0_A_const_111 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_112 any

var A_arbace_pprint_cl_format__init_part0_A_const_113 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_114 any

var A_arbace_pprint_cl_format__init_part0_A_const_115 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_116 any

var A_arbace_pprint_cl_format__init_part0_A_const_117 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_118 any

var A_arbace_pprint_cl_format__init_part0_A_const_119 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_120 any

var A_arbace_pprint_cl_format__init_part0_A_const_121 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_122 any

var A_arbace_pprint_cl_format__init_part0_A_const_123 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_124 any

var A_arbace_pprint_cl_format__init_part0_A_const_125 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_126 any

var A_arbace_pprint_cl_format__init_part0_A_const_127 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_128 any

var A_arbace_pprint_cl_format__init_part0_A_const_129 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_130 any

var A_arbace_pprint_cl_format__init_part0_A_const_131 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_132 any

var A_arbace_pprint_cl_format__init_part0_A_const_133 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_134 any

var A_arbace_pprint_cl_format__init_part0_A_const_135 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_136 any

var A_arbace_pprint_cl_format__init_part0_A_const_137 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_138 any

var A_arbace_pprint_cl_format__init_part0_A_const_139 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_140 any

var A_arbace_pprint_cl_format__init_part0_A_const_141 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_142 any

var A_arbace_pprint_cl_format__init_part0_A_const_143 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_144 any

var A_arbace_pprint_cl_format__init_part0_A_const_145 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_146 any

var A_arbace_pprint_cl_format__init_part0_A_const_147 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_148 any

var A_arbace_pprint_cl_format__init_part0_A_const_149 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_150 any

var A_arbace_pprint_cl_format__init_part0_A_const_151 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_152 any

var A_arbace_pprint_cl_format__init_part0_A_const_153 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_154 any

var A_arbace_pprint_cl_format__init_part0_A_const_155 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_156 any

var A_arbace_pprint_cl_format__init_part0_A_const_157 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_158 any

var A_arbace_pprint_cl_format__init_part0_A_const_159 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_160 any

var A_arbace_pprint_cl_format__init_part0_A_const_161 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_162 any

var A_arbace_pprint_cl_format__init_part0_A_const_163 any

var A_arbace_pprint_cl_format__init_part0_A_const_164 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_165 any

var A_arbace_pprint_cl_format__init_part0_A_const_166 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_167 *jrt.Class

var A_arbace_pprint_cl_format__init_part0_A_const_168 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_169 any

var A_arbace_pprint_cl_format__init_part0_A_const_170 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_171 any

var A_arbace_pprint_cl_format__init_part0_A_const_172 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_173 any

var A_arbace_pprint_cl_format__init_part0_A_const_174 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_175 any

var A_arbace_pprint_cl_format__init_part0_A_const_176 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_177 any

var A_arbace_pprint_cl_format__init_part0_A_const_178 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_179 any

var A_arbace_pprint_cl_format__init_part0_A_const_180 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_181 any

var A_arbace_pprint_cl_format__init_part0_A_const_182 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_183 any

var A_arbace_pprint_cl_format__init_part0_A_const_184 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_185 any

var A_arbace_pprint_cl_format__init_part0_A_const_186 any

var A_arbace_pprint_cl_format__init_part0_A_const_187 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_188 any

var A_arbace_pprint_cl_format__init_part0_A_const_189 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_190 any

var A_arbace_pprint_cl_format__init_part0_A_const_191 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_192 any

var A_arbace_pprint_cl_format__init_part0_A_const_193 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_194 any

var A_arbace_pprint_cl_format__init_part0_A_const_195 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_196 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_197 any

var A_arbace_pprint_cl_format__init_part0_A_const_198 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_199 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_200 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_201 any

var A_arbace_pprint_cl_format__init_part0_A_const_202 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_203 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_204 any

var A_arbace_pprint_cl_format__init_part0_A_const_205 any

var A_arbace_pprint_cl_format__init_part0_A_const_206 any

var A_arbace_pprint_cl_format__init_part0_A_const_207 any

var A_arbace_pprint_cl_format__init_part0_A_const_208 any

var A_arbace_pprint_cl_format__init_part0_A_const_209 any

var A_arbace_pprint_cl_format__init_part0_A_const_210 any

var A_arbace_pprint_cl_format__init_part0_A_const_211 any

var A_arbace_pprint_cl_format__init_part0_A_const_212 any

var A_arbace_pprint_cl_format__init_part0_A_const_213 any

var A_arbace_pprint_cl_format__init_part0_A_const_214 any

var A_arbace_pprint_cl_format__init_part0_A_const_215 any

var A_arbace_pprint_cl_format__init_part0_A_const_216 any

var A_arbace_pprint_cl_format__init_part0_A_const_217 any

var A_arbace_pprint_cl_format__init_part0_A_const_218 any

var A_arbace_pprint_cl_format__init_part0_A_const_219 any

var A_arbace_pprint_cl_format__init_part0_A_const_220 any

var A_arbace_pprint_cl_format__init_part0_A_const_221 any

var A_arbace_pprint_cl_format__init_part0_A_const_222 any

var A_arbace_pprint_cl_format__init_part0_A_const_223 any

var A_arbace_pprint_cl_format__init_part0_A_const_224 any

var A_arbace_pprint_cl_format__init_part0_A_const_225 any

var A_arbace_pprint_cl_format__init_part0_A_const_226 any

var A_arbace_pprint_cl_format__init_part0_A_const_227 any

var A_arbace_pprint_cl_format__init_part0_A_const_228 any

var A_arbace_pprint_cl_format__init_part0_A_const_229 any

var A_arbace_pprint_cl_format__init_part0_A_const_230 any

var A_arbace_pprint_cl_format__init_part0_A_const_231 any

var A_arbace_pprint_cl_format__init_part0_A_const_232 any

var A_arbace_pprint_cl_format__init_part0_A_const_233 any

var A_arbace_pprint_cl_format__init_part0_A_const_234 any

var A_arbace_pprint_cl_format__init_part0_A_const_235 any

var A_arbace_pprint_cl_format__init_part0_A_const_236 any

var A_arbace_pprint_cl_format__init_part0_A_const_237 any

var A_arbace_pprint_cl_format__init_part0_A_const_238 any

var A_arbace_pprint_cl_format__init_part0_A_const_239 any

var A_arbace_pprint_cl_format__init_part0_A_const_240 any

var A_arbace_pprint_cl_format__init_part0_A_const_241 any

var A_arbace_pprint_cl_format__init_part0_A_const_242 any

var A_arbace_pprint_cl_format__init_part0_A_const_243 any

var A_arbace_pprint_cl_format__init_part0_A_const_244 any

var A_arbace_pprint_cl_format__init_part0_A_const_245 any

var A_arbace_pprint_cl_format__init_part0_A_const_246 any

var A_arbace_pprint_cl_format__init_part0_A_const_247 any

var A_arbace_pprint_cl_format__init_part0_A_const_248 any

var A_arbace_pprint_cl_format__init_part0_A_const_249 any

var A_arbace_pprint_cl_format__init_part0_A_const_250 any

var A_arbace_pprint_cl_format__init_part0_A_const_251 any

var A_arbace_pprint_cl_format__init_part0_A_const_252 any

var A_arbace_pprint_cl_format__init_part0_A_const_253 any

var A_arbace_pprint_cl_format__init_part0_A_const_254 any

var A_arbace_pprint_cl_format__init_part0_A_const_255 any

var A_arbace_pprint_cl_format__init_part0_A_const_256 any

var A_arbace_pprint_cl_format__init_part0_A_const_257 any

var A_arbace_pprint_cl_format__init_part0_A_const_258 any

var A_arbace_pprint_cl_format__init_part0_A_const_259 any

var A_arbace_pprint_cl_format__init_part0_A_const_260 any

var A_arbace_pprint_cl_format__init_part0_A_const_261 any

var A_arbace_pprint_cl_format__init_part0_A_const_262 any

var A_arbace_pprint_cl_format__init_part0_A_const_263 any

var A_arbace_pprint_cl_format__init_part0_A_const_264 any

var A_arbace_pprint_cl_format__init_part0_A_const_265 any

var A_arbace_pprint_cl_format__init_part0_A_const_266 any

var A_arbace_pprint_cl_format__init_part0_A_const_267 any

var A_arbace_pprint_cl_format__init_part0_A_const_268 any

var A_arbace_pprint_cl_format__init_part0_A_const_269 any

var A_arbace_pprint_cl_format__init_part0_A_const_270 any

var A_arbace_pprint_cl_format__init_part0_A_const_271 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_272 any

var A_arbace_pprint_cl_format__init_part0_A_const_273 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_274 any

var A_arbace_pprint_cl_format__init_part0_A_const_275 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_276 any

var A_arbace_pprint_cl_format__init_part0_A_const_277 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_278 any

var A_arbace_pprint_cl_format__init_part0_A_const_279 any

var A_arbace_pprint_cl_format__init_part0_A_const_280 any

var A_arbace_pprint_cl_format__init_part0_A_const_281 any

var A_arbace_pprint_cl_format__init_part0_A_const_282 any

var A_arbace_pprint_cl_format__init_part0_A_const_283 any

var A_arbace_pprint_cl_format__init_part0_A_const_284 any

var A_arbace_pprint_cl_format__init_part0_A_const_285 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_286 any

var A_arbace_pprint_cl_format__init_part0_A_const_287 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_288 any

var A_arbace_pprint_cl_format__init_part0_A_const_289 any

var A_arbace_pprint_cl_format__init_part0_A_const_290 any

var A_arbace_pprint_cl_format__init_part0_A_const_291 any

var A_arbace_pprint_cl_format__init_part0_A_const_292 any

var A_arbace_pprint_cl_format__init_part0_A_const_293 any

var A_arbace_pprint_cl_format__init_part0_A_const_294 any

var A_arbace_pprint_cl_format__init_part0_A_const_295 any

var A_arbace_pprint_cl_format__init_part0_A_const_296 any

var A_arbace_pprint_cl_format__init_part0_A_const_297 any

var A_arbace_pprint_cl_format__init_part0_A_const_298 any

var A_arbace_pprint_cl_format__init_part0_A_const_299 any

var A_arbace_pprint_cl_format__init_part0_A_const_300 any

var A_arbace_pprint_cl_format__init_part0_A_const_301 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_302 any

var A_arbace_pprint_cl_format__init_part0_A_const_303 any

var A_arbace_pprint_cl_format__init_part0_A_const_304 any

var A_arbace_pprint_cl_format__init_part0_A_const_305 any

var A_arbace_pprint_cl_format__init_part0_A_const_306 any

var A_arbace_pprint_cl_format__init_part0_A_const_307 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_308 any

var A_arbace_pprint_cl_format__init_part0_A_const_309 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_310 any

var A_arbace_pprint_cl_format__init_part0_A_const_311 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_312 any

var A_arbace_pprint_cl_format__init_part0_A_const_313 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_314 any

var A_arbace_pprint_cl_format__init_part0_A_const_315 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_316 any

var A_arbace_pprint_cl_format__init_part0_A_const_317 any

var A_arbace_pprint_cl_format__init_part0_A_const_318 any

var A_arbace_pprint_cl_format__init_part0_A_const_319 any

var A_arbace_pprint_cl_format__init_part0_A_const_320 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_321 any

var A_arbace_pprint_cl_format__init_part0_A_const_322 any

var A_arbace_pprint_cl_format__init_part0_A_const_323 any

var A_arbace_pprint_cl_format__init_part0_A_const_324 any

var A_arbace_pprint_cl_format__init_part0_A_const_325 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_326 any

var A_arbace_pprint_cl_format__init_part0_A_const_327 any

var A_arbace_pprint_cl_format__init_part0_A_const_328 any

var A_arbace_pprint_cl_format__init_part0_A_const_329 any

var A_arbace_pprint_cl_format__init_part0_A_const_330 any

var A_arbace_pprint_cl_format__init_part0_A_const_331 any

var A_arbace_pprint_cl_format__init_part0_A_const_332 any

var A_arbace_pprint_cl_format__init_part0_A_const_333 any

var A_arbace_pprint_cl_format__init_part0_A_const_334 any

var A_arbace_pprint_cl_format__init_part0_A_const_335 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_336 any

var A_arbace_pprint_cl_format__init_part0_A_const_337 any

var A_arbace_pprint_cl_format__init_part0_A_const_338 any

var A_arbace_pprint_cl_format__init_part0_A_const_339 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_340 any

var A_arbace_pprint_cl_format__init_part0_A_const_341 any

var A_arbace_pprint_cl_format__init_part0_A_const_342 any

var A_arbace_pprint_cl_format__init_part0_A_const_343 any

var A_arbace_pprint_cl_format__init_part0_A_const_344 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_345 any

var A_arbace_pprint_cl_format__init_part0_A_const_346 any

var A_arbace_pprint_cl_format__init_part0_A_const_347 any

var A_arbace_pprint_cl_format__init_part0_A_const_348 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_349 any

var A_arbace_pprint_cl_format__init_part0_A_const_350 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_351 any

var A_arbace_pprint_cl_format__init_part0_A_const_352 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_353 any

var A_arbace_pprint_cl_format__init_part0_A_const_354 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_355 any

var A_arbace_pprint_cl_format__init_part0_A_const_356 any

var A_arbace_pprint_cl_format__init_part0_A_const_357 any

var A_arbace_pprint_cl_format__init_part0_A_const_358 any

var A_arbace_pprint_cl_format__init_part0_A_const_359 any

var A_arbace_pprint_cl_format__init_part0_A_const_360 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_361 any

var A_arbace_pprint_cl_format__init_part0_A_const_362 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_363 any

var A_arbace_pprint_cl_format__init_part0_A_const_364 *lang.Keyword

var A_arbace_pprint_cl_format__init_part0_A_const_365 any

var A_arbace_pprint_cl_format__init_part0_A_const_366 any

var A_arbace_pprint_cl_format__init_part0_A_const_367 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_368 any

var A_arbace_pprint_cl_format__init_part0_A_const_369 any

var A_arbace_pprint_cl_format__init_part0_A_const_370 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_371 any

var A_arbace_pprint_cl_format__init_part0_A_const_372 any

var A_arbace_pprint_cl_format__init_part0_A_const_373 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_374 any

var A_arbace_pprint_cl_format__init_part0_A_const_375 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_376 any

var A_arbace_pprint_cl_format__init_part0_A_const_377 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_378 any

var A_arbace_pprint_cl_format__init_part0_A_const_379 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_380 any

var A_arbace_pprint_cl_format__init_part0_A_const_381 any

var A_arbace_pprint_cl_format__init_part0_A_const_382 *lang.Var

var A_arbace_pprint_cl_format__init_part0_A_const_383 any

var A_arbace_pprint_cl_format__init_part0_A_init jrt.ClassInit

func A_arbace_pprint_cl_format__init_part0_A_Init() { if !A_arbace_pprint_cl_format__init_part0_A_init.Done() { A_arbace_pprint_cl_format__init_part0_A_init.Run(A_arbace_pprint_cl_format__init_part0_A_clinit) } }

func A_arbace_pprint_cl_format__init_part0_A_clinit() { A_arbace_pprint_cl_format__init_part0_A_clinit_p0(); A_arbace_pprint_cl_format__init_part0_A_clinit_p1(); A_arbace_pprint_cl_format__init_part0_A_clinit_p2(); A_arbace_pprint_cl_format__init_part0_A_clinit_p3(); A_arbace_pprint_cl_format__init_part0_A_clinit_p4(); A_arbace_pprint_cl_format__init_part0_A_clinit_p5(); A_arbace_pprint_cl_format__init_part0_A_clinit_p6(); A_arbace_pprint_cl_format__init_part0_A_clinit_p7(); A_arbace_pprint_cl_format__init_part0_A_clinit_p8(); A_arbace_pprint_cl_format__init_part0_A_clinit_p9(); A_arbace_pprint_cl_format__init_part0_A_clinit_p10(); A_arbace_pprint_cl_format__init_part0_A_clinit_p11(); A_arbace_pprint_cl_format__init_part0_A_clinit_p12(); A_arbace_pprint_cl_format__init_part0_A_clinit_p13(); A_arbace_pprint_cl_format__init_part0_A_clinit_p14(); A_arbace_pprint_cl_format__init_part0_A_clinit_p15(); A_arbace_pprint_cl_format__init_part0_A_clinit_p16(); A_arbace_pprint_cl_format__init_part0_A_clinit_p17(); A_arbace_pprint_cl_format__init_part0_A_clinit_p18(); A_arbace_pprint_cl_format__init_part0_A_clinit_p19(); A_arbace_pprint_cl_format__init_part0_A_clinit_p20(); A_arbace_pprint_cl_format__init_part0_A_clinit_p21(); A_arbace_pprint_cl_format__init_part0_A_clinit_p22(); A_arbace_pprint_cl_format__init_part0_A_clinit_p23(); A_arbace_pprint_cl_format__init_part0_A_clinit_p24(); A_arbace_pprint_cl_format__init_part0_A_clinit_p25(); A_arbace_pprint_cl_format__init_part0_A_clinit_p26(); A_arbace_pprint_cl_format__init_part0_A_clinit_p27() }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p0() { A_arbace_pprint_cl_format__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 491); A_arbace_pprint_cl_format__init_part0_A_const_0 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[107]); A_arbace_pprint_cl_format__init_part0_A_const_1 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[108]; A_arbace_pprint_cl_format__init_part0_A_const_2 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[109]); A_arbace_pprint_cl_format__init_part0_A_const_3 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[110]; A_arbace_pprint_cl_format__init_part0_A_const_4 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[111]); A_arbace_pprint_cl_format__init_part0_A_const_5 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[112]; A_arbace_pprint_cl_format__init_part0_A_const_6 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[113]); A_arbace_pprint_cl_format__init_part0_A_const_7 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[114]; A_arbace_pprint_cl_format__init_part0_A_const_8 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[115]); A_arbace_pprint_cl_format__init_part0_A_const_9 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[116]; A_arbace_pprint_cl_format__init_part0_A_const_10 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[117]); A_arbace_pprint_cl_format__init_part0_A_const_11 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[118]; A_arbace_pprint_cl_format__init_part0_A_const_12 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[119]) }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p1() { A_arbace_pprint_cl_format__init_part0_A_const_13 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[120]; A_arbace_pprint_cl_format__init_part0_A_const_14 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[121]); A_arbace_pprint_cl_format__init_part0_A_const_15 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[122]); A_arbace_pprint_cl_format__init_part0_A_const_16 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[123]; A_arbace_pprint_cl_format__init_part0_A_const_17 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[124]); A_arbace_pprint_cl_format__init_part0_A_const_18 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[125]); A_arbace_pprint_cl_format__init_part0_A_const_19 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[126]); A_arbace_pprint_cl_format__init_part0_A_const_20 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[127]; A_arbace_pprint_cl_format__init_part0_A_const_21 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[128]); A_arbace_pprint_cl_format__init_part0_A_const_22 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[129]; A_arbace_pprint_cl_format__init_part0_A_const_23 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[130]); A_arbace_pprint_cl_format__init_part0_A_const_24 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[131]; A_arbace_pprint_cl_format__init_part0_A_const_25 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[132]) }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p2() { A_arbace_pprint_cl_format__init_part0_A_const_26 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[133]; A_arbace_pprint_cl_format__init_part0_A_const_27 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[134]); A_arbace_pprint_cl_format__init_part0_A_const_28 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[135]; A_arbace_pprint_cl_format__init_part0_A_const_29 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[136]); A_arbace_pprint_cl_format__init_part0_A_const_30 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[137]; A_arbace_pprint_cl_format__init_part0_A_const_31 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[138]; A_arbace_pprint_cl_format__init_part0_A_const_32 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[139]); A_arbace_pprint_cl_format__init_part0_A_const_33 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[140]; A_arbace_pprint_cl_format__init_part0_A_const_34 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[141]); A_arbace_pprint_cl_format__init_part0_A_const_35 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[142]); A_arbace_pprint_cl_format__init_part0_A_const_36 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[143]); A_arbace_pprint_cl_format__init_part0_A_const_37 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[144]); A_arbace_pprint_cl_format__init_part0_A_const_38 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[145]) }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p3() { A_arbace_pprint_cl_format__init_part0_A_const_39 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[146]; A_arbace_pprint_cl_format__init_part0_A_const_40 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[147]); A_arbace_pprint_cl_format__init_part0_A_const_41 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[148]; A_arbace_pprint_cl_format__init_part0_A_const_42 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[149]); A_arbace_pprint_cl_format__init_part0_A_const_43 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[150]; A_arbace_pprint_cl_format__init_part0_A_const_44 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[151]); A_arbace_pprint_cl_format__init_part0_A_const_45 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[152]; A_arbace_pprint_cl_format__init_part0_A_const_46 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[153]; A_arbace_pprint_cl_format__init_part0_A_const_47 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[154]); A_arbace_pprint_cl_format__init_part0_A_const_48 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[155]; A_arbace_pprint_cl_format__init_part0_A_const_49 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[156]); A_arbace_pprint_cl_format__init_part0_A_const_50 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[157]; A_arbace_pprint_cl_format__init_part0_A_const_51 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[158]); A_arbace_pprint_cl_format__init_part0_A_const_52 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[159] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p4() { A_arbace_pprint_cl_format__init_part0_A_const_53 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[160]); A_arbace_pprint_cl_format__init_part0_A_const_54 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[161]; A_arbace_pprint_cl_format__init_part0_A_const_55 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[162]); A_arbace_pprint_cl_format__init_part0_A_const_56 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[163]; A_arbace_pprint_cl_format__init_part0_A_const_57 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[164]); A_arbace_pprint_cl_format__init_part0_A_const_58 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[165]; A_arbace_pprint_cl_format__init_part0_A_const_59 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[166]; A_arbace_pprint_cl_format__init_part0_A_const_60 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[167]; A_arbace_pprint_cl_format__init_part0_A_const_61 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[168]); A_arbace_pprint_cl_format__init_part0_A_const_62 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[169]; A_arbace_pprint_cl_format__init_part0_A_const_63 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[170]); A_arbace_pprint_cl_format__init_part0_A_const_64 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[171]; A_arbace_pprint_cl_format__init_part0_A_const_65 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[172]); A_arbace_pprint_cl_format__init_part0_A_const_66 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[173] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p5() { A_arbace_pprint_cl_format__init_part0_A_const_67 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[174]; A_arbace_pprint_cl_format__init_part0_A_const_68 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[175]); A_arbace_pprint_cl_format__init_part0_A_const_69 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[176]; A_arbace_pprint_cl_format__init_part0_A_const_70 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[177]; A_arbace_pprint_cl_format__init_part0_A_const_71 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[178]); A_arbace_pprint_cl_format__init_part0_A_const_72 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[179]; A_arbace_pprint_cl_format__init_part0_A_const_73 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[180]; A_arbace_pprint_cl_format__init_part0_A_const_74 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[181]); A_arbace_pprint_cl_format__init_part0_A_const_75 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[182]; A_arbace_pprint_cl_format__init_part0_A_const_76 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[183]; A_arbace_pprint_cl_format__init_part0_A_const_77 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[184]); A_arbace_pprint_cl_format__init_part0_A_const_78 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[185]; A_arbace_pprint_cl_format__init_part0_A_const_79 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[186]; A_arbace_pprint_cl_format__init_part0_A_const_80 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[187]) }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p6() { A_arbace_pprint_cl_format__init_part0_A_const_81 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[188]; A_arbace_pprint_cl_format__init_part0_A_const_82 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[189]); A_arbace_pprint_cl_format__init_part0_A_const_83 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[190]; A_arbace_pprint_cl_format__init_part0_A_const_84 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[191]); A_arbace_pprint_cl_format__init_part0_A_const_85 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[192]; A_arbace_pprint_cl_format__init_part0_A_const_86 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[193]); A_arbace_pprint_cl_format__init_part0_A_const_87 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[194]; A_arbace_pprint_cl_format__init_part0_A_const_88 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[195]); A_arbace_pprint_cl_format__init_part0_A_const_89 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[196]; A_arbace_pprint_cl_format__init_part0_A_const_90 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[197]); A_arbace_pprint_cl_format__init_part0_A_const_91 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[198]; A_arbace_pprint_cl_format__init_part0_A_const_92 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[199]; A_arbace_pprint_cl_format__init_part0_A_const_93 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[200]); A_arbace_pprint_cl_format__init_part0_A_const_94 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[201] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p7() { A_arbace_pprint_cl_format__init_part0_A_const_95 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[202]; A_arbace_pprint_cl_format__init_part0_A_const_96 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[203]); A_arbace_pprint_cl_format__init_part0_A_const_97 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[204]; A_arbace_pprint_cl_format__init_part0_A_const_98 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[205]); A_arbace_pprint_cl_format__init_part0_A_const_99 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[206]; A_arbace_pprint_cl_format__init_part0_A_const_100 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[207]); A_arbace_pprint_cl_format__init_part0_A_const_101 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[208]; A_arbace_pprint_cl_format__init_part0_A_const_102 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[209]); A_arbace_pprint_cl_format__init_part0_A_const_103 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[210]; A_arbace_pprint_cl_format__init_part0_A_const_104 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[211]; A_arbace_pprint_cl_format__init_part0_A_const_105 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[212]); A_arbace_pprint_cl_format__init_part0_A_const_106 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[213]; A_arbace_pprint_cl_format__init_part0_A_const_107 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[214]); A_arbace_pprint_cl_format__init_part0_A_const_108 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[215] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p8() { A_arbace_pprint_cl_format__init_part0_A_const_109 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[216]); A_arbace_pprint_cl_format__init_part0_A_const_110 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[217]; A_arbace_pprint_cl_format__init_part0_A_const_111 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[218]); A_arbace_pprint_cl_format__init_part0_A_const_112 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[219]; A_arbace_pprint_cl_format__init_part0_A_const_113 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[220]); A_arbace_pprint_cl_format__init_part0_A_const_114 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[221]; A_arbace_pprint_cl_format__init_part0_A_const_115 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[222]); A_arbace_pprint_cl_format__init_part0_A_const_116 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[223]; A_arbace_pprint_cl_format__init_part0_A_const_117 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[224]); A_arbace_pprint_cl_format__init_part0_A_const_118 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[225]; A_arbace_pprint_cl_format__init_part0_A_const_119 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[226]); A_arbace_pprint_cl_format__init_part0_A_const_120 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[227]; A_arbace_pprint_cl_format__init_part0_A_const_121 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[228]) }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p9() { A_arbace_pprint_cl_format__init_part0_A_const_122 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[229]; A_arbace_pprint_cl_format__init_part0_A_const_123 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[230]); A_arbace_pprint_cl_format__init_part0_A_const_124 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[231]; A_arbace_pprint_cl_format__init_part0_A_const_125 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[232]); A_arbace_pprint_cl_format__init_part0_A_const_126 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[233]; A_arbace_pprint_cl_format__init_part0_A_const_127 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[234]); A_arbace_pprint_cl_format__init_part0_A_const_128 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[235]; A_arbace_pprint_cl_format__init_part0_A_const_129 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[236]); A_arbace_pprint_cl_format__init_part0_A_const_130 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[237]; A_arbace_pprint_cl_format__init_part0_A_const_131 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[238]); A_arbace_pprint_cl_format__init_part0_A_const_132 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[239]; A_arbace_pprint_cl_format__init_part0_A_const_133 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[240]); A_arbace_pprint_cl_format__init_part0_A_const_134 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[241] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p10() { A_arbace_pprint_cl_format__init_part0_A_const_135 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[242]); A_arbace_pprint_cl_format__init_part0_A_const_136 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[243]; A_arbace_pprint_cl_format__init_part0_A_const_137 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[244]); A_arbace_pprint_cl_format__init_part0_A_const_138 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[245]; A_arbace_pprint_cl_format__init_part0_A_const_139 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[246]); A_arbace_pprint_cl_format__init_part0_A_const_140 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[247]; A_arbace_pprint_cl_format__init_part0_A_const_141 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[248]); A_arbace_pprint_cl_format__init_part0_A_const_142 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[249]; A_arbace_pprint_cl_format__init_part0_A_const_143 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[250]); A_arbace_pprint_cl_format__init_part0_A_const_144 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[251]; A_arbace_pprint_cl_format__init_part0_A_const_145 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[252]); A_arbace_pprint_cl_format__init_part0_A_const_146 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[253]; A_arbace_pprint_cl_format__init_part0_A_const_147 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[254]) }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p11() { A_arbace_pprint_cl_format__init_part0_A_const_148 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[255]; A_arbace_pprint_cl_format__init_part0_A_const_149 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[256]); A_arbace_pprint_cl_format__init_part0_A_const_150 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[257]; A_arbace_pprint_cl_format__init_part0_A_const_151 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[258]); A_arbace_pprint_cl_format__init_part0_A_const_152 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[259]; A_arbace_pprint_cl_format__init_part0_A_const_153 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[260]); A_arbace_pprint_cl_format__init_part0_A_const_154 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[261]; A_arbace_pprint_cl_format__init_part0_A_const_155 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[262]); A_arbace_pprint_cl_format__init_part0_A_const_156 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[263]; A_arbace_pprint_cl_format__init_part0_A_const_157 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[264]); A_arbace_pprint_cl_format__init_part0_A_const_158 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[265]; A_arbace_pprint_cl_format__init_part0_A_const_159 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[266]); A_arbace_pprint_cl_format__init_part0_A_const_160 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[267] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p12() { A_arbace_pprint_cl_format__init_part0_A_const_161 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[268]); A_arbace_pprint_cl_format__init_part0_A_const_162 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[269]; A_arbace_pprint_cl_format__init_part0_A_const_163 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[270]; A_arbace_pprint_cl_format__init_part0_A_const_164 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[271]); A_arbace_pprint_cl_format__init_part0_A_const_165 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[272]; A_arbace_pprint_cl_format__init_part0_A_const_166 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[273]); A_arbace_pprint_cl_format__init_part0_A_const_167 = jrt.Class_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[274]); A_arbace_pprint_cl_format__init_part0_A_const_168 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[275]); A_arbace_pprint_cl_format__init_part0_A_const_169 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[276]; A_arbace_pprint_cl_format__init_part0_A_const_170 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[277]); A_arbace_pprint_cl_format__init_part0_A_const_171 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[278]; A_arbace_pprint_cl_format__init_part0_A_const_172 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[279]); A_arbace_pprint_cl_format__init_part0_A_const_173 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[280] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p13() { A_arbace_pprint_cl_format__init_part0_A_const_174 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[281]); A_arbace_pprint_cl_format__init_part0_A_const_175 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[282]; A_arbace_pprint_cl_format__init_part0_A_const_176 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[283]); A_arbace_pprint_cl_format__init_part0_A_const_177 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[284]; A_arbace_pprint_cl_format__init_part0_A_const_178 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[285]); A_arbace_pprint_cl_format__init_part0_A_const_179 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[286]; A_arbace_pprint_cl_format__init_part0_A_const_180 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[287]); A_arbace_pprint_cl_format__init_part0_A_const_181 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[288]; A_arbace_pprint_cl_format__init_part0_A_const_182 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[289]); A_arbace_pprint_cl_format__init_part0_A_const_183 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[290]; A_arbace_pprint_cl_format__init_part0_A_const_184 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[291]); A_arbace_pprint_cl_format__init_part0_A_const_185 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[292]; A_arbace_pprint_cl_format__init_part0_A_const_186 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[293] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p14() { A_arbace_pprint_cl_format__init_part0_A_const_187 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[294]); A_arbace_pprint_cl_format__init_part0_A_const_188 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[295]; A_arbace_pprint_cl_format__init_part0_A_const_189 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[296]); A_arbace_pprint_cl_format__init_part0_A_const_190 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[297]; A_arbace_pprint_cl_format__init_part0_A_const_191 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[298]); A_arbace_pprint_cl_format__init_part0_A_const_192 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[299]; A_arbace_pprint_cl_format__init_part0_A_const_193 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[300]); A_arbace_pprint_cl_format__init_part0_A_const_194 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[301]; A_arbace_pprint_cl_format__init_part0_A_const_195 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[302]); A_arbace_pprint_cl_format__init_part0_A_const_196 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[303]); A_arbace_pprint_cl_format__init_part0_A_const_197 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[304]; A_arbace_pprint_cl_format__init_part0_A_const_198 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[305]); A_arbace_pprint_cl_format__init_part0_A_const_199 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[306]) }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p15() { A_arbace_pprint_cl_format__init_part0_A_const_200 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[307]); A_arbace_pprint_cl_format__init_part0_A_const_201 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[308]; A_arbace_pprint_cl_format__init_part0_A_const_202 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[309]); A_arbace_pprint_cl_format__init_part0_A_const_203 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[310]); A_arbace_pprint_cl_format__init_part0_A_const_204 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[311]; A_arbace_pprint_cl_format__init_part0_A_const_205 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[312]; A_arbace_pprint_cl_format__init_part0_A_const_206 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[313]; A_arbace_pprint_cl_format__init_part0_A_const_207 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[314]; A_arbace_pprint_cl_format__init_part0_A_const_208 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[315]; A_arbace_pprint_cl_format__init_part0_A_const_209 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[316]; A_arbace_pprint_cl_format__init_part0_A_const_210 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[317]; A_arbace_pprint_cl_format__init_part0_A_const_211 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[318]; A_arbace_pprint_cl_format__init_part0_A_const_212 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[319]; A_arbace_pprint_cl_format__init_part0_A_const_213 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[320]; A_arbace_pprint_cl_format__init_part0_A_const_214 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[321] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p16() { A_arbace_pprint_cl_format__init_part0_A_const_215 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[322]; A_arbace_pprint_cl_format__init_part0_A_const_216 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[323]; A_arbace_pprint_cl_format__init_part0_A_const_217 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[324]; A_arbace_pprint_cl_format__init_part0_A_const_218 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[325]; A_arbace_pprint_cl_format__init_part0_A_const_219 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[326]; A_arbace_pprint_cl_format__init_part0_A_const_220 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[327]; A_arbace_pprint_cl_format__init_part0_A_const_221 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[328]; A_arbace_pprint_cl_format__init_part0_A_const_222 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[329]; A_arbace_pprint_cl_format__init_part0_A_const_223 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[330]; A_arbace_pprint_cl_format__init_part0_A_const_224 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[331]; A_arbace_pprint_cl_format__init_part0_A_const_225 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[332]; A_arbace_pprint_cl_format__init_part0_A_const_226 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[333]; A_arbace_pprint_cl_format__init_part0_A_const_227 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[334]; A_arbace_pprint_cl_format__init_part0_A_const_228 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[335]; A_arbace_pprint_cl_format__init_part0_A_const_229 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[336]; A_arbace_pprint_cl_format__init_part0_A_const_230 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[337] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p17() { A_arbace_pprint_cl_format__init_part0_A_const_231 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[338]; A_arbace_pprint_cl_format__init_part0_A_const_232 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[339]; A_arbace_pprint_cl_format__init_part0_A_const_233 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[340]; A_arbace_pprint_cl_format__init_part0_A_const_234 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[341]; A_arbace_pprint_cl_format__init_part0_A_const_235 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[342]; A_arbace_pprint_cl_format__init_part0_A_const_236 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[343]; A_arbace_pprint_cl_format__init_part0_A_const_237 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[344]; A_arbace_pprint_cl_format__init_part0_A_const_238 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[345]; A_arbace_pprint_cl_format__init_part0_A_const_239 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[346]; A_arbace_pprint_cl_format__init_part0_A_const_240 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[347]; A_arbace_pprint_cl_format__init_part0_A_const_241 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[348]; A_arbace_pprint_cl_format__init_part0_A_const_242 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[349]; A_arbace_pprint_cl_format__init_part0_A_const_243 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[350]; A_arbace_pprint_cl_format__init_part0_A_const_244 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[351]; A_arbace_pprint_cl_format__init_part0_A_const_245 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[352]; A_arbace_pprint_cl_format__init_part0_A_const_246 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[353] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p18() { A_arbace_pprint_cl_format__init_part0_A_const_247 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[354]; A_arbace_pprint_cl_format__init_part0_A_const_248 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[355]; A_arbace_pprint_cl_format__init_part0_A_const_249 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[356]; A_arbace_pprint_cl_format__init_part0_A_const_250 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[357]; A_arbace_pprint_cl_format__init_part0_A_const_251 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[358]; A_arbace_pprint_cl_format__init_part0_A_const_252 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[359]; A_arbace_pprint_cl_format__init_part0_A_const_253 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[360]; A_arbace_pprint_cl_format__init_part0_A_const_254 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[361]; A_arbace_pprint_cl_format__init_part0_A_const_255 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[362]; A_arbace_pprint_cl_format__init_part0_A_const_256 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[363]; A_arbace_pprint_cl_format__init_part0_A_const_257 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[364]; A_arbace_pprint_cl_format__init_part0_A_const_258 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[365]; A_arbace_pprint_cl_format__init_part0_A_const_259 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[366]; A_arbace_pprint_cl_format__init_part0_A_const_260 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[367]; A_arbace_pprint_cl_format__init_part0_A_const_261 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[368]; A_arbace_pprint_cl_format__init_part0_A_const_262 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[369] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p19() { A_arbace_pprint_cl_format__init_part0_A_const_263 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[370]; A_arbace_pprint_cl_format__init_part0_A_const_264 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[371]; A_arbace_pprint_cl_format__init_part0_A_const_265 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[372]; A_arbace_pprint_cl_format__init_part0_A_const_266 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[373]; A_arbace_pprint_cl_format__init_part0_A_const_267 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[374]; A_arbace_pprint_cl_format__init_part0_A_const_268 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[375]; A_arbace_pprint_cl_format__init_part0_A_const_269 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[376]; A_arbace_pprint_cl_format__init_part0_A_const_270 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[377]; A_arbace_pprint_cl_format__init_part0_A_const_271 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[378]); A_arbace_pprint_cl_format__init_part0_A_const_272 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[379]; A_arbace_pprint_cl_format__init_part0_A_const_273 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[380]); A_arbace_pprint_cl_format__init_part0_A_const_274 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[381]; A_arbace_pprint_cl_format__init_part0_A_const_275 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[382]); A_arbace_pprint_cl_format__init_part0_A_const_276 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[383] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p20() { A_arbace_pprint_cl_format__init_part0_A_const_277 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[384]); A_arbace_pprint_cl_format__init_part0_A_const_278 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[385]; A_arbace_pprint_cl_format__init_part0_A_const_279 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[386]; A_arbace_pprint_cl_format__init_part0_A_const_280 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[387]; A_arbace_pprint_cl_format__init_part0_A_const_281 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[388]; A_arbace_pprint_cl_format__init_part0_A_const_282 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[389]; A_arbace_pprint_cl_format__init_part0_A_const_283 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[390]; A_arbace_pprint_cl_format__init_part0_A_const_284 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[391]; A_arbace_pprint_cl_format__init_part0_A_const_285 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[392]); A_arbace_pprint_cl_format__init_part0_A_const_286 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[393]; A_arbace_pprint_cl_format__init_part0_A_const_287 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[394]); A_arbace_pprint_cl_format__init_part0_A_const_288 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[395]; A_arbace_pprint_cl_format__init_part0_A_const_289 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[396]; A_arbace_pprint_cl_format__init_part0_A_const_290 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[397]; A_arbace_pprint_cl_format__init_part0_A_const_291 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[398] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p21() { A_arbace_pprint_cl_format__init_part0_A_const_292 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[399]; A_arbace_pprint_cl_format__init_part0_A_const_293 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[400]; A_arbace_pprint_cl_format__init_part0_A_const_294 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[401]; A_arbace_pprint_cl_format__init_part0_A_const_295 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[402]; A_arbace_pprint_cl_format__init_part0_A_const_296 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[403]; A_arbace_pprint_cl_format__init_part0_A_const_297 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[404]; A_arbace_pprint_cl_format__init_part0_A_const_298 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[405]; A_arbace_pprint_cl_format__init_part0_A_const_299 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[406]; A_arbace_pprint_cl_format__init_part0_A_const_300 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[407]; A_arbace_pprint_cl_format__init_part0_A_const_301 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[408]); A_arbace_pprint_cl_format__init_part0_A_const_302 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[409]; A_arbace_pprint_cl_format__init_part0_A_const_303 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[410]; A_arbace_pprint_cl_format__init_part0_A_const_304 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[411]; A_arbace_pprint_cl_format__init_part0_A_const_305 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[412]; A_arbace_pprint_cl_format__init_part0_A_const_306 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[413] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p22() { A_arbace_pprint_cl_format__init_part0_A_const_307 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[414]); A_arbace_pprint_cl_format__init_part0_A_const_308 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[415]; A_arbace_pprint_cl_format__init_part0_A_const_309 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[416]); A_arbace_pprint_cl_format__init_part0_A_const_310 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[417]; A_arbace_pprint_cl_format__init_part0_A_const_311 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[418]); A_arbace_pprint_cl_format__init_part0_A_const_312 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[419]; A_arbace_pprint_cl_format__init_part0_A_const_313 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[420]); A_arbace_pprint_cl_format__init_part0_A_const_314 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[421]; A_arbace_pprint_cl_format__init_part0_A_const_315 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[422]); A_arbace_pprint_cl_format__init_part0_A_const_316 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[423]; A_arbace_pprint_cl_format__init_part0_A_const_317 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[424]; A_arbace_pprint_cl_format__init_part0_A_const_318 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[425]; A_arbace_pprint_cl_format__init_part0_A_const_319 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[426]; A_arbace_pprint_cl_format__init_part0_A_const_320 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[427]) }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p23() { A_arbace_pprint_cl_format__init_part0_A_const_321 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[428]; A_arbace_pprint_cl_format__init_part0_A_const_322 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[429]; A_arbace_pprint_cl_format__init_part0_A_const_323 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[430]; A_arbace_pprint_cl_format__init_part0_A_const_324 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[431]; A_arbace_pprint_cl_format__init_part0_A_const_325 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[432]); A_arbace_pprint_cl_format__init_part0_A_const_326 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[433]; A_arbace_pprint_cl_format__init_part0_A_const_327 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[434]; A_arbace_pprint_cl_format__init_part0_A_const_328 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[435]; A_arbace_pprint_cl_format__init_part0_A_const_329 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[436]; A_arbace_pprint_cl_format__init_part0_A_const_330 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[437]; A_arbace_pprint_cl_format__init_part0_A_const_331 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[438]; A_arbace_pprint_cl_format__init_part0_A_const_332 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[439]; A_arbace_pprint_cl_format__init_part0_A_const_333 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[440]; A_arbace_pprint_cl_format__init_part0_A_const_334 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[441]; A_arbace_pprint_cl_format__init_part0_A_const_335 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[442]) }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p24() { A_arbace_pprint_cl_format__init_part0_A_const_336 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[443]; A_arbace_pprint_cl_format__init_part0_A_const_337 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[444]; A_arbace_pprint_cl_format__init_part0_A_const_338 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[445]; A_arbace_pprint_cl_format__init_part0_A_const_339 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[446]); A_arbace_pprint_cl_format__init_part0_A_const_340 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[447]; A_arbace_pprint_cl_format__init_part0_A_const_341 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[448]; A_arbace_pprint_cl_format__init_part0_A_const_342 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[449]; A_arbace_pprint_cl_format__init_part0_A_const_343 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[450]; A_arbace_pprint_cl_format__init_part0_A_const_344 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[451]); A_arbace_pprint_cl_format__init_part0_A_const_345 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[452]; A_arbace_pprint_cl_format__init_part0_A_const_346 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[453]; A_arbace_pprint_cl_format__init_part0_A_const_347 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[454]; A_arbace_pprint_cl_format__init_part0_A_const_348 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[455]); A_arbace_pprint_cl_format__init_part0_A_const_349 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[456] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p25() { A_arbace_pprint_cl_format__init_part0_A_const_350 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[457]); A_arbace_pprint_cl_format__init_part0_A_const_351 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[458]; A_arbace_pprint_cl_format__init_part0_A_const_352 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[459]); A_arbace_pprint_cl_format__init_part0_A_const_353 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[460]; A_arbace_pprint_cl_format__init_part0_A_const_354 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[461]); A_arbace_pprint_cl_format__init_part0_A_const_355 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[462]; A_arbace_pprint_cl_format__init_part0_A_const_356 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[463]; A_arbace_pprint_cl_format__init_part0_A_const_357 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[464]; A_arbace_pprint_cl_format__init_part0_A_const_358 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[465]; A_arbace_pprint_cl_format__init_part0_A_const_359 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[466]; A_arbace_pprint_cl_format__init_part0_A_const_360 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[467]); A_arbace_pprint_cl_format__init_part0_A_const_361 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[468]; A_arbace_pprint_cl_format__init_part0_A_const_362 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[469]); A_arbace_pprint_cl_format__init_part0_A_const_363 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[470] }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p26() { A_arbace_pprint_cl_format__init_part0_A_const_364 = lang.Keyword_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[471]); A_arbace_pprint_cl_format__init_part0_A_const_365 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[472]; A_arbace_pprint_cl_format__init_part0_A_const_366 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[473]; A_arbace_pprint_cl_format__init_part0_A_const_367 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[474]); A_arbace_pprint_cl_format__init_part0_A_const_368 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[475]; A_arbace_pprint_cl_format__init_part0_A_const_369 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[476]; A_arbace_pprint_cl_format__init_part0_A_const_370 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[477]); A_arbace_pprint_cl_format__init_part0_A_const_371 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[478]; A_arbace_pprint_cl_format__init_part0_A_const_372 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[479]; A_arbace_pprint_cl_format__init_part0_A_const_373 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[480]); A_arbace_pprint_cl_format__init_part0_A_const_374 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[481]; A_arbace_pprint_cl_format__init_part0_A_const_375 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[482]); A_arbace_pprint_cl_format__init_part0_A_const_376 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[483]; A_arbace_pprint_cl_format__init_part0_A_const_377 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[484]) }

func A_arbace_pprint_cl_format__init_part0_A_clinit_p27() { A_arbace_pprint_cl_format__init_part0_A_const_378 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[485]; A_arbace_pprint_cl_format__init_part0_A_const_379 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[486]); A_arbace_pprint_cl_format__init_part0_A_const_380 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[487]; A_arbace_pprint_cl_format__init_part0_A_const_381 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[488]; A_arbace_pprint_cl_format__init_part0_A_const_382 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part0_A_const_pool.A[489]); A_arbace_pprint_cl_format__init_part0_A_const_383 = A_arbace_pprint_cl_format__init_part0_A_const_pool.A[490] }

func A_arbace_pprint_cl_format__init_part0_A_New() *A_arbace_pprint_cl_format__init_part0_A { A_arbace_pprint_cl_format__init_part0_A_Init(); t := &A_arbace_pprint_cl_format__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_cl_format__init_part0_A) Ctor() {}

func (t *A_arbace_pprint_cl_format__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_cl_format__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_cl_format__init_part0_A_class }

func (t *A_arbace_pprint_cl_format__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_cl_format__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_pprint_cl_format__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_cl_format__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_cl_format__init_part0_A); return ok }

func A_arbace_pprint_cl_format__init_part0_A_Cast(x any) *A_arbace_pprint_cl_format__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_cl_format__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_cl_format__init_part0_A_class)) }; return v }



type A_arbace_pprint_cl_format__init_part1_A struct{ jrt.Object }

var A_arbace_pprint_cl_format__init_part1_A_const_pool *jrt.RefArray

var A_arbace_pprint_cl_format__init_part1_A_const_0 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_1 any

var A_arbace_pprint_cl_format__init_part1_A_const_2 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_3 any

var A_arbace_pprint_cl_format__init_part1_A_const_4 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_5 any

var A_arbace_pprint_cl_format__init_part1_A_const_6 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_7 any

var A_arbace_pprint_cl_format__init_part1_A_const_8 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_9 any

var A_arbace_pprint_cl_format__init_part1_A_const_10 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_11 any

var A_arbace_pprint_cl_format__init_part1_A_const_12 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_13 any

var A_arbace_pprint_cl_format__init_part1_A_const_14 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_15 any

var A_arbace_pprint_cl_format__init_part1_A_const_16 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_17 any

var A_arbace_pprint_cl_format__init_part1_A_const_18 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_19 any

var A_arbace_pprint_cl_format__init_part1_A_const_20 any

var A_arbace_pprint_cl_format__init_part1_A_const_21 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_22 any

var A_arbace_pprint_cl_format__init_part1_A_const_23 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_24 any

var A_arbace_pprint_cl_format__init_part1_A_const_25 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_26 any

var A_arbace_pprint_cl_format__init_part1_A_const_27 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_28 any

var A_arbace_pprint_cl_format__init_part1_A_const_29 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_30 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_31 any

var A_arbace_pprint_cl_format__init_part1_A_const_32 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_33 any

var A_arbace_pprint_cl_format__init_part1_A_const_34 *lang.Var

var A_arbace_pprint_cl_format__init_part1_A_const_35 any

var A_arbace_pprint_cl_format__init_part1_A_init jrt.ClassInit

func A_arbace_pprint_cl_format__init_part1_A_Init() { if !A_arbace_pprint_cl_format__init_part1_A_init.Done() { A_arbace_pprint_cl_format__init_part1_A_init.Run(A_arbace_pprint_cl_format__init_part1_A_clinit) } }

func A_arbace_pprint_cl_format__init_part1_A_clinit() { A_arbace_pprint_cl_format__init_part1_A_clinit_p0(); A_arbace_pprint_cl_format__init_part1_A_clinit_p1(); A_arbace_pprint_cl_format__init_part1_A_clinit_p2() }

func A_arbace_pprint_cl_format__init_part1_A_clinit_p0() { A_arbace_pprint_cl_format__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_108, 56); A_arbace_pprint_cl_format__init_part1_A_const_0 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[22]); A_arbace_pprint_cl_format__init_part1_A_const_1 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[23]; A_arbace_pprint_cl_format__init_part1_A_const_2 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[24]); A_arbace_pprint_cl_format__init_part1_A_const_3 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[25]; A_arbace_pprint_cl_format__init_part1_A_const_4 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[26]); A_arbace_pprint_cl_format__init_part1_A_const_5 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[27]; A_arbace_pprint_cl_format__init_part1_A_const_6 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[28]); A_arbace_pprint_cl_format__init_part1_A_const_7 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[29]; A_arbace_pprint_cl_format__init_part1_A_const_8 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[30]); A_arbace_pprint_cl_format__init_part1_A_const_9 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[31]; A_arbace_pprint_cl_format__init_part1_A_const_10 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[32]); A_arbace_pprint_cl_format__init_part1_A_const_11 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[33]; A_arbace_pprint_cl_format__init_part1_A_const_12 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[34]) }

func A_arbace_pprint_cl_format__init_part1_A_clinit_p1() { A_arbace_pprint_cl_format__init_part1_A_const_13 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[35]; A_arbace_pprint_cl_format__init_part1_A_const_14 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[36]); A_arbace_pprint_cl_format__init_part1_A_const_15 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[37]; A_arbace_pprint_cl_format__init_part1_A_const_16 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[38]); A_arbace_pprint_cl_format__init_part1_A_const_17 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[39]; A_arbace_pprint_cl_format__init_part1_A_const_18 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[40]); A_arbace_pprint_cl_format__init_part1_A_const_19 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[41]; A_arbace_pprint_cl_format__init_part1_A_const_20 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[42]; A_arbace_pprint_cl_format__init_part1_A_const_21 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[43]); A_arbace_pprint_cl_format__init_part1_A_const_22 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[44] }

func A_arbace_pprint_cl_format__init_part1_A_clinit_p2() { var tmp1 *lang.Var; A_arbace_pprint_cl_format__init_part0_A_Init(); tmp1 = A_arbace_pprint_cl_format__init_part0_A_const_2; A_arbace_pprint_cl_format__init_part1_A_const_23 = tmp1; A_arbace_pprint_cl_format__init_part1_A_const_24 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[45]; A_arbace_pprint_cl_format__init_part1_A_const_25 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[46]); A_arbace_pprint_cl_format__init_part1_A_const_26 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[47]; var tmp2 *lang.Var; A_arbace_pprint_cl_format__init_part0_A_Init(); tmp2 = A_arbace_pprint_cl_format__init_part0_A_const_4; A_arbace_pprint_cl_format__init_part1_A_const_27 = tmp2; A_arbace_pprint_cl_format__init_part1_A_const_28 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[48]; A_arbace_pprint_cl_format__init_part1_A_const_29 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[49]); A_arbace_pprint_cl_format__init_part1_A_const_30 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[50]); A_arbace_pprint_cl_format__init_part1_A_const_31 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[51]; A_arbace_pprint_cl_format__init_part1_A_const_32 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[52]); A_arbace_pprint_cl_format__init_part1_A_const_33 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[53]; A_arbace_pprint_cl_format__init_part1_A_const_34 = lang.Var_Cast(A_arbace_pprint_cl_format__init_part1_A_const_pool.A[54]); A_arbace_pprint_cl_format__init_part1_A_const_35 = A_arbace_pprint_cl_format__init_part1_A_const_pool.A[55] }

func A_arbace_pprint_cl_format__init_part1_A_New() *A_arbace_pprint_cl_format__init_part1_A { A_arbace_pprint_cl_format__init_part1_A_Init(); t := &A_arbace_pprint_cl_format__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_cl_format__init_part1_A) Ctor() {}

func (t *A_arbace_pprint_cl_format__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_cl_format__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_cl_format__init_part1_A_class }

func (t *A_arbace_pprint_cl_format__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_cl_format__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_pprint_cl_format__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_cl_format__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_cl_format__init_part1_A); return ok }

func A_arbace_pprint_cl_format__init_part1_A_Cast(x any) *A_arbace_pprint_cl_format__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_cl_format__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_cl_format__init_part1_A_class)) }; return v }
