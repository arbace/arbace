//line a2g_strings.ae:1
package aot_arbace_pprint_cl_format

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("in-ns")

var Lit_2 *jrt.String = jrt.Intern("arbace.pprint")

var Lit_3 *jrt.String = jrt.Intern("compile-format")

var Lit_4 *jrt.String = jrt.Intern("declared")

var Lit_5 *jrt.String = jrt.Intern("line")

var Lit_6 *jrt.String = jrt.Intern("column")

var Lit_7 *jrt.String = jrt.Intern("file")

var Lit_8 *jrt.String = jrt.Intern("arbace/pprint/cl_format.ae")

var Lit_9 *jrt.String = jrt.Intern("execute-format")

var Lit_10 *jrt.String = jrt.Intern("init-navigator")

var Lit_11 *jrt.String = jrt.Intern("cl-format")

var Lit_12 *jrt.String = jrt.Intern("arglists")

var Lit_13 *jrt.String = jrt.Intern("writer")

var Lit_14 *jrt.String = jrt.Intern("format-in")

var Lit_15 *jrt.String = jrt.Intern("&")

var Lit_16 *jrt.String = jrt.Intern("args")

var Lit_17 *jrt.String = jrt.Intern("doc")

var Lit_18 *jrt.String = jrt.Intern("An implementation of a Common Lisp compatible format function. cl-format formats its\narguments to an output stream or string based on the format control string given. It\nsupports sophisticated formatting of structured data.\n\nWriter is an instance of java.io.Writer, true to output to *out* or nil to output\nto a string, format-in is the format control string and the remaining arguments\nare the data to be formatted.\n\nThe format control string is a string to be output with embedded 'format directives'\ndescribing how to format the various arguments passed in.\n\nIf writer is nil, cl-format returns the formatted result string. Otherwise, cl-format\nreturns nil.\n\nFor example:\n (let [results [46 38 22]]\n        (cl-format true \"There ~[are~;is~:;are~]~:* ~d result~:p: ~{~d~^, ~}~%\"\n                   (count results) results))\n\nPrints to *out*:\n There are 3 results: 46, 38, 22\n\nDetailed documentation on format control strings is available in the \"Common Lisp the\nLanguage, 2nd edition\", Chapter 22 (available online at:\nhttp://www.cs.cmu.edu/afs/cs.cmu.edu/project/ai-repository/ai/html/cltl/clm/node200.html#SECTION002633000000000000000)\nand in the Common Lisp HyperSpec at\nhttp://www.lispworks.com/documentation/HyperSpec/Body/22_c.htm\n")

var Lit_19 *jrt.String = jrt.Intern("added")

var Lit_20 *jrt.String = jrt.Intern("1.2")

var Lit_21 *jrt.String = jrt.Intern("see-also")

var Lit_22 *jrt.String = jrt.Intern("http://www.cs.cmu.edu/afs/cs.cmu.edu/project/ai-repository/ai/html/cltl/clm/node200.html#SECTION002633000000000000000")

var Lit_23 *jrt.String = jrt.Intern("Common Lisp the Language")

var Lit_24 *jrt.String = jrt.Intern("http://www.lispworks.com/documentation/HyperSpec/Body/22_c.htm")

var Lit_25 *jrt.String = jrt.Intern("Common Lisp HyperSpec")

var Lit_26 *jrt.String = jrt.Intern("*format-str*")

var Lit_27 *jrt.String = jrt.Intern("private")

var Lit_28 *jrt.String = jrt.Intern("dynamic")

var Lit_29 *jrt.String = jrt.Intern("format-error")

var Lit_30 *jrt.String = jrt.Intern("message")

var Lit_31 *jrt.String = jrt.Intern("offset")

var Lit_32 *jrt.String = jrt.Intern("arg-navigator")

var Lit_33 *jrt.String = jrt.Intern("create-struct")

var Lit_34 *jrt.String = jrt.Intern("seq")

var Lit_35 *jrt.String = jrt.Intern("rest")

var Lit_36 *jrt.String = jrt.Intern("pos")

var Lit_37 *jrt.String = jrt.Intern("s")

var Lit_38 *jrt.String = jrt.Intern("Create a new arg-navigator from the sequence with the position set to 0")

var Lit_39 *jrt.String = jrt.Intern("skip-wiki")

var Lit_40 *jrt.String = jrt.Intern("next-arg")

var Lit_41 *jrt.String = jrt.Intern("navigator")

var Lit_42 *jrt.String = jrt.Intern("next-arg-or-nil")

var Lit_43 *jrt.String = jrt.Intern("get-format-arg")

var Lit_44 *jrt.String = jrt.Intern("relative-reposition")

var Lit_45 *jrt.String = jrt.Intern("absolute-reposition")

var Lit_46 *jrt.String = jrt.Intern("position")

var Lit_47 *jrt.String = jrt.Intern("compiled-directive")

var Lit_48 *jrt.String = jrt.Intern("func")

var Lit_49 *jrt.String = jrt.Intern("def")

var Lit_50 *jrt.String = jrt.Intern("params")

var Lit_51 *jrt.String = jrt.Intern("realize-parameter")

var Lit_52 *jrt.String = jrt.Intern("param")

var Lit_53 *jrt.String = jrt.Intern("raw-val")

var Lit_54 *jrt.String = jrt.Intern("realize-parameter-list")

var Lit_55 *jrt.String = jrt.Intern("parameter-map")

var Lit_56 *jrt.String = jrt.Intern("opt-base-str")

var Lit_57 *jrt.String = jrt.Intern("special-radix-markers")

var Lit_58 *jrt.String = jrt.Intern("#b")

var Lit_59 *jrt.String = jrt.Intern("#o")

var Lit_60 *jrt.String = jrt.Intern("#x")

var Lit_61 *jrt.String = jrt.Intern("format-simple-number")

var Lit_62 *jrt.String = jrt.Intern("n")

var Lit_63 *jrt.String = jrt.Intern("format-ascii")

var Lit_64 *jrt.String = jrt.Intern("print-func")

var Lit_65 *jrt.String = jrt.Intern("offsets")

var Lit_66 *jrt.String = jrt.Intern("integral?")

var Lit_67 *jrt.String = jrt.Intern("x")

var Lit_68 *jrt.String = jrt.Intern("returns true if a number is actually an integer (that is, has no fractional part)")

var Lit_69 *jrt.String = jrt.Intern("remainders")

var Lit_70 *jrt.String = jrt.Intern("base")

var Lit_71 *jrt.String = jrt.Intern("val")

var Lit_72 *jrt.String = jrt.Intern("Return the list of remainders (essentially the 'digits') of val in the given base")

var Lit_73 *jrt.String = jrt.Intern("base-str")

var Lit_74 *jrt.String = jrt.Intern("Return val as a string in the given base")

var Lit_75 *jrt.String = jrt.Intern("java-base-formats")

var Lit_76 *jrt.String = jrt.Intern("%o")

var Lit_77 *jrt.String = jrt.Intern("%d")

var Lit_78 *jrt.String = jrt.Intern("%x")

var Lit_79 *jrt.String = jrt.Intern("Return val as a string in the given base, using arbace.core/format if supported\nfor improved performance")

var Lit_80 *jrt.String = jrt.Intern("group-by*")

var Lit_81 *jrt.String = jrt.Intern("unit")

var Lit_82 *jrt.String = jrt.Intern("lis")

var Lit_83 *jrt.String = jrt.Intern("format-integer")

var Lit_84 *jrt.String = jrt.Intern("english-cardinal-units")

var Lit_85 *jrt.String = jrt.Intern("english-ordinal-units")

var Lit_86 *jrt.String = jrt.Intern("english-cardinal-tens")

var Lit_87 *jrt.String = jrt.Intern("english-ordinal-tens")

var Lit_88 *jrt.String = jrt.Intern("english-scale-numbers")

var Lit_89 *jrt.String = jrt.Intern("format-simple-cardinal")

var Lit_90 *jrt.String = jrt.Intern("num")

var Lit_91 *jrt.String = jrt.Intern("Convert a number less than 1000 to a cardinal english string")

var Lit_92 *jrt.String = jrt.Intern("add-english-scales")

var Lit_93 *jrt.String = jrt.Intern("parts")

var Lit_94 *jrt.String = jrt.Intern("Take a sequence of parts, add scale numbers (e.g., million) and combine into a string\noffset is a factor of 10^3 to multiply by")

var Lit_95 *jrt.String = jrt.Intern("format-cardinal-english")

var Lit_96 *jrt.String = jrt.Intern("format-simple-ordinal")

var Lit_97 *jrt.String = jrt.Intern("Convert a number less than 1000 to a ordinal english string\nNote this should only be used for the last one in the sequence")

var Lit_98 *jrt.String = jrt.Intern("format-ordinal-english")

var Lit_99 *jrt.String = jrt.Intern("old-roman-table")

var Lit_100 *jrt.String = jrt.Intern("M")

var Lit_101 *jrt.String = jrt.Intern("MM")

var Lit_102 *jrt.String = jrt.Intern("MMM")

var Lit_103 *jrt.String = jrt.Intern("new-roman-table")

var Lit_104 *jrt.String = jrt.Intern("format-roman")

var Lit_105 *jrt.String = jrt.Intern("table")

var Lit_106 *jrt.String = jrt.Intern("Format a roman numeral using the specified look-up table")

var Lit_107 *jrt.String = jrt.Intern("format-old-roman")

var Lit_108 *jrt.String = jrt.Intern("format-new-roman")

var Lit_109 *jrt.String = jrt.Intern("special-chars")

var Lit_110 *jrt.String = jrt.Intern("Backspace")

var Lit_111 *jrt.String = jrt.Intern("Tab")

var Lit_112 *jrt.String = jrt.Intern("Newline")

var Lit_113 *jrt.String = jrt.Intern("Return")

var Lit_114 *jrt.String = jrt.Intern("Space")

var Lit_115 *jrt.String = jrt.Intern("pretty-character")

var Lit_116 *jrt.String = jrt.Intern("readable-character")

var Lit_117 *jrt.String = jrt.Intern("plain-character")

var Lit_118 *jrt.String = jrt.Intern("abort?")

var Lit_119 *jrt.String = jrt.Intern("context")

var Lit_120 *jrt.String = jrt.Intern("execute-sub-format")

var Lit_121 *jrt.String = jrt.Intern("format")

var Lit_122 *jrt.String = jrt.Intern("base-args")

var Lit_123 *jrt.String = jrt.Intern("float-parts-base")

var Lit_124 *jrt.String = jrt.Intern("f")

var Lit_125 *jrt.String = jrt.Intern("tag")

var Lit_126 *jrt.String = jrt.Intern("Object")

var Lit_127 *jrt.String = jrt.Intern("Produce string parts for the mantissa (normalized 1-9) and exponent")

var Lit_128 *jrt.String = jrt.Intern("float-parts")

var Lit_129 *jrt.String = jrt.Intern("Take care of leading and trailing zeros in decomposed floats")

var Lit_130 *jrt.String = jrt.Intern("inc-s")

var Lit_131 *jrt.String = jrt.Intern("java.lang.String")

var Lit_132 *jrt.String = jrt.Intern("String")

var Lit_133 *jrt.String = jrt.Intern("Assumption: The input string consists of one or more decimal digits,\nand no other characters.  Return a string containing one or more\ndecimal digits containing a decimal number one larger than the input\nstring.  The output string will always be the same length as the input\nstring, or one character longer.")

var Lit_134 *jrt.String = jrt.Intern("round-str")

var Lit_135 *jrt.String = jrt.Intern("m")

var Lit_136 *jrt.String = jrt.Intern("e")

var Lit_137 *jrt.String = jrt.Intern("d")

var Lit_138 *jrt.String = jrt.Intern("w")

var Lit_139 *jrt.String = jrt.Intern("expand-fixed")

var Lit_140 *jrt.String = jrt.Intern("insert-decimal")

var Lit_141 *jrt.String = jrt.Intern("Insert the decimal point at the right spot in the number to match an exponent")

var Lit_142 *jrt.String = jrt.Intern("get-fixed")

var Lit_143 *jrt.String = jrt.Intern("insert-scaled-decimal")

var Lit_144 *jrt.String = jrt.Intern("k")

var Lit_145 *jrt.String = jrt.Intern("convert-ratio")

var Lit_146 *jrt.String = jrt.Intern("fixed-float")

var Lit_147 *jrt.String = jrt.Intern("exponential-float")

var Lit_148 *jrt.String = jrt.Intern("general-float")

var Lit_149 *jrt.String = jrt.Intern("dollar-float")

var Lit_150 *jrt.String = jrt.Intern("choice-conditional")

var Lit_151 *jrt.String = jrt.Intern("boolean-conditional")

var Lit_152 *jrt.String = jrt.Intern("check-arg-conditional")

var Lit_153 *jrt.String = jrt.Intern("iterate-sublist")

var Lit_154 *jrt.String = jrt.Intern("iterate-list-of-sublists")

var Lit_155 *jrt.String = jrt.Intern("iterate-main-list")

var Lit_156 *jrt.String = jrt.Intern("iterate-main-sublists")

var Lit_157 *jrt.String = jrt.Intern("format-logical-block")

var Lit_158 *jrt.String = jrt.Intern("justify-clauses")

var Lit_159 *jrt.String = jrt.Intern("logical-block-or-justify")

var Lit_160 *jrt.String = jrt.Intern("render-clauses")

var Lit_161 *jrt.String = jrt.Intern("clauses")

var Lit_162 *jrt.String = jrt.Intern("base-navigator")

var Lit_163 *jrt.String = jrt.Intern("downcase-writer")

var Lit_164 *jrt.String = jrt.Intern("java.io.Writer")

var Lit_165 *jrt.String = jrt.Intern("Returns a proxy that wraps writer, converting all characters to lower case")

var Lit_166 *jrt.String = jrt.Intern("get-proxy-class")

var Lit_167 *jrt.String = jrt.Intern("upcase-writer")

var Lit_168 *jrt.String = jrt.Intern("Returns a proxy that wraps writer, converting all characters to upper case")

var Lit_169 *jrt.String = jrt.Intern("capitalize-string")

var Lit_170 *jrt.String = jrt.Intern("first?")

var Lit_171 *jrt.String = jrt.Intern("Capitalizes the words in a string. If first? is false, don't capitalize the\n                                      first character of the string even if it's a letter.")

var Lit_172 *jrt.String = jrt.Intern("capitalize-word-writer")

var Lit_173 *jrt.String = jrt.Intern("Returns a proxy that wraps writer, capitalizing all words")

var Lit_174 *jrt.String = jrt.Intern("init-cap-writer")

var Lit_175 *jrt.String = jrt.Intern("Returns a proxy that wraps writer, capitalizing the first word")

var Lit_176 *jrt.String = jrt.Intern("modify-case")

var Lit_177 *jrt.String = jrt.Intern("make-writer")

var Lit_178 *jrt.String = jrt.Intern("get-pretty-writer")

var Lit_179 *jrt.String = jrt.Intern("Returns the java.io.Writer passed in wrapped in a pretty writer proxy, unless it's\nalready a pretty writer. Generally, it is unnecessary to call this function, since pprint,\nwrite, and cl-format all call it if they need to. However if you want the state to be\npreserved across calls, you will want to wrap them with this.\n\nFor example, when you want to generate column-aware output with multiple calls to cl-format,\ndo it like in this example:\n\n    (defn print-table [aseq column-width]\n      (binding [*out* (get-pretty-writer *out*)]\n        (doseq [row aseq]\n          (doseq [col row]\n            (cl-format true \"~4D~7,vT\" col column-width))\n          (prn))))\n\nNow when you run:\n\n    user> (print-table (map #(vector % (* % %) (* % % %)) (range 1 11)) 8)\n\nIt prints a table of squares and cubes for the numbers from 1 to 10:\n\n       1      1       1\n       2      4       8\n       3      9      27\n       4     16      64\n       5     25     125\n       6     36     216\n       7     49     343\n       8     64     512\n       9     81     729\n      10    100    1000")

var Lit_180 *jrt.String = jrt.Intern("fresh-line")

var Lit_181 *jrt.String = jrt.Intern("Make a newline if *out* is not already at the beginning of the line. If *out* is\nnot a pretty writer (which keeps track of columns), this function always outputs a newline.")

var Lit_182 *jrt.String = jrt.Intern("absolute-tabulation")

var Lit_183 *jrt.String = jrt.Intern("relative-tabulation")

var Lit_184 *jrt.String = jrt.Intern("set-indent")

var Lit_185 *jrt.String = jrt.Intern("conditional-newline")

var Lit_186 *jrt.String = jrt.Intern("process-directive-table-element")

var Lit_187 *jrt.String = jrt.Intern("char")

var Lit_188 *jrt.String = jrt.Intern("flags")

var Lit_189 *jrt.String = jrt.Intern("bracket-info")

var Lit_190 *jrt.String = jrt.Intern("generator-fn")

var Lit_191 *jrt.String = jrt.Intern("defdirectives")

var Lit_192 *jrt.String = jrt.Intern("directives")

var Lit_193 *jrt.String = jrt.Intern("directive-table")

var Lit_194 *jrt.String = jrt.Intern("hash-map")

var Lit_195 *jrt.String = jrt.Intern("directive")

var Lit_196 *jrt.String = jrt.Intern("array-map")

var Lit_197 *jrt.String = jrt.Intern("colon")

var Lit_198 *jrt.String = jrt.Intern("at")

var Lit_199 *jrt.String = jrt.Intern("both")

var Lit_200 *jrt.String = jrt.Intern("pretty")

var Lit_201 *jrt.String = jrt.Intern("right")

var Lit_202 *jrt.String = jrt.Intern("allows-separator")

var Lit_203 *jrt.String = jrt.Intern("else")

var Lit_204 *jrt.String = jrt.Intern("last")

var Lit_205 *jrt.String = jrt.Intern("separator")

var Lit_206 *jrt.String = jrt.Intern("first")

var Lit_207 *jrt.String = jrt.Intern("mincol")

var Lit_208 *jrt.String = jrt.Intern("java.lang.Integer")

var Lit_209 *jrt.String = jrt.Intern("colinc")

var Lit_210 *jrt.String = jrt.Intern("minpad")

var Lit_211 *jrt.String = jrt.Intern("padchar")

var Lit_212 *jrt.String = jrt.Intern("java.lang.Character")

var Lit_213 *jrt.String = jrt.Intern("commachar")

var Lit_214 *jrt.String = jrt.Intern("commainterval")

var Lit_215 *jrt.String = jrt.Intern("char-format")

var Lit_216 *jrt.String = jrt.Intern("overflowchar")

var Lit_217 *jrt.String = jrt.Intern("exponentchar")

var Lit_218 *jrt.String = jrt.Intern("count")

var Lit_219 *jrt.String = jrt.Intern("colnum")

var Lit_220 *jrt.String = jrt.Intern("selector")

var Lit_221 *jrt.String = jrt.Intern("min-remaining")

var Lit_222 *jrt.String = jrt.Intern("max-columns")

var Lit_223 *jrt.String = jrt.Intern("max-iterations")

var Lit_224 *jrt.String = jrt.Intern("arg1")

var Lit_225 *jrt.String = jrt.Intern("arg2")

var Lit_226 *jrt.String = jrt.Intern("arg3")

var Lit_227 *jrt.String = jrt.Intern("param-pattern")

var Lit_228 *jrt.String = jrt.Intern("^([vV]|#|('.)|([+-]?\\d+)|(?=,))")

var Lit_229 *jrt.String = jrt.Intern("special-params")

var Lit_230 *jrt.String = jrt.Intern("remaining-arg-count")

var Lit_231 *jrt.String = jrt.Intern("parameter-from-args")

var Lit_232 *jrt.String = jrt.Intern("extract-param")

var Lit_233 *jrt.String = jrt.Intern("saw-comma")

var Lit_234 *jrt.String = jrt.Intern("extract-params")

var Lit_235 *jrt.String = jrt.Intern("translate-param")

var Lit_236 *jrt.String = jrt.Intern("p")

var Lit_237 *jrt.String = jrt.Intern("Translate the string representation of a param to the internalized\n                                      representation")

var Lit_238 *jrt.String = jrt.Intern("flag-defs")

var Lit_239 *jrt.String = jrt.Intern("extract-flags")

var Lit_240 *jrt.String = jrt.Intern("check-flags")

var Lit_241 *jrt.String = jrt.Intern("map-params")

var Lit_242 *jrt.String = jrt.Intern("Takes a directive definition and the list of actual parameters and\na map of flags and returns a map of the parameters and flags with defaults\nfilled in. We check to make sure that there are the right types and number\nof parameters as well.")

var Lit_243 *jrt.String = jrt.Intern("compile-directive")

var Lit_244 *jrt.String = jrt.Intern("compile-raw-string")

var Lit_245 *jrt.String = jrt.Intern("right-bracket")

var Lit_246 *jrt.String = jrt.Intern("this")

var Lit_247 *jrt.String = jrt.Intern("separator?")

var Lit_248 *jrt.String = jrt.Intern("else-separator?")

var Lit_249 *jrt.String = jrt.Intern("collect-clauses")

var Lit_250 *jrt.String = jrt.Intern("process-bracket")

var Lit_251 *jrt.String = jrt.Intern("remainder")

var Lit_252 *jrt.String = jrt.Intern("process-clause")

var Lit_253 *jrt.String = jrt.Intern("process-nesting")

var Lit_254 *jrt.String = jrt.Intern("Take a linearly compiled format and process the bracket directives to give it\n   the appropriate tree structure")

var Lit_255 *jrt.String = jrt.Intern("format-str")

var Lit_256 *jrt.String = jrt.Intern("Compiles format-str into a compiled format which can be used as an argument\nto cl-format just like a plain format string. Use this function for improved\nperformance when you're using the same format string repeatedly")

var Lit_257 *jrt.String = jrt.Intern("needs-pretty")

var Lit_258 *jrt.String = jrt.Intern("determine whether a given compiled format has any directives that depend on the\ncolumn number or pretty printing")

var Lit_259 *jrt.String = jrt.Intern("stream")

var Lit_260 *jrt.String = jrt.Intern("Executes the format with the arguments.")

var Lit_261 *jrt.String = jrt.Intern("cached-compile")

var Lit_262 *jrt.String = jrt.Intern("memoize")

var Lit_263 *jrt.String = jrt.Intern("formatter")

var Lit_264 *jrt.String = jrt.Intern("Makes a function which can directly run format-in. The function is\nfn [stream & args] ... and returns nil unless the stream is nil (meaning\noutput to a string) in which case it returns the resulting string.\n\nformat-in can be either a control string or a previously compiled format.")

var Lit_265 *jrt.String = jrt.Intern("formatter-out")

var Lit_266 *jrt.String = jrt.Intern("Makes a function which can directly run format-in. The function is\nfn [& args] ... and returns nil. This version of the formatter macro is\ndesigned to be used with *out* set to an appropriate Writer. In particular,\nthis is meant to be used as part of a pretty printer dispatch method.\n\nformat-in can be either a control string or a previously compiled format.")
