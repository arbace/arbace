//line a2g_strings.ae:1
package aot_arbace_pprint_cl_format

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.pprintkn8,declaredkn4,linekn6,columnkn4,filekn8,arglistsyn6,writeryn9,format-inyn1,&yn4,argskn3,dockn5,addedkn8,see-alsokn7,privatekn7,dynamicyn7,messageyn6,offsetkn3,seqkn4,restkn3,posyn1,skn9,skip-wikiyn9,navigatoryn8,positionkn4,funckn3,defkn6,paramskn6,offsetyn5,paramyn7,raw-valyn13,parameter-mapyn1,nyn10,print-funcyn6,paramsyn13,arg-navigatoryn7,offsetsyn1,xyn4,baseyn3,valyn4,unityn3,lisyn3,numyn5,partsyn5,tableyn7,contextyn6,formatyn9,base-argskn3,tagyn6,Objectyn1,fyn6,Stringyn1,myn1,eyn1,dyn1,wyn1,kyn7,clausesyn14,base-navigatoryn14,java.io.Writeryn6,first?yn11,make-writeryn4,charyn5,flagsyn12,bracket-infoyn12,generator-fnyn10,directiveskn9,directivekn5,flagskn5,colonkn2,atkn4,bothkn12,bracket-infokn12,generator-fnkn6,prettykn5,rightkn16,allows-separatorkn4,elsekn4,lastkn9,separatorkn5,firstkn6,mincolkn6,colinckn6,minpadkn7,padcharkn9,commacharkn13,commaintervalkn4,basekn11,char-formatkn1,wkn1,dkn1,kkn12,overflowcharkn1,ekn12,exponentcharkn1,nkn5,countkn6,colnumkn8,selectorkn13,min-remainingkn11,max-columnskn14,max-iterationskn4,arg1kn4,arg2kn4,arg3kn19,remaining-arg-countkn19,parameter-from-argsyn9,saw-commav11,arbace.core5,in-nsR0,v13,arbace.pprint14,compile-formatm8,R1,TR2,i21,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint14,execute-formatm8,R1,TR2,i22,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint14,init-navigatorm8,R1,TR2,i23,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint9,cl-formatm14,R5,L1,V4,R6,R7,R8,R9,R10,s1240,An implementation of a Common Lisp compatible format function. cl-format formats its\narguments to an output stream or string based on the format control string given. It\nsupports sophisticated formatting of structured data.\n\nWriter is an instance of java.io.Writer, true to output to *out* or nil to output\nto a string, format-in is the format control string and the remaining arguments\nare the data to be formatted.\n\nThe format control string is a string to be output with embedded 'format directives'\ndescribing how to format the various arguments passed in.\n\nIf writer is nil, cl-format returns the formatted result string. Otherwise, cl-format\nreturns nil.\n\nFor example:\n (let [results [46 38 22]]\n        (cl-format true \"There ~[are~;is~:;are~]~:* ~d result~:p: ~{~d~^, ~}~%\"\n                   (count results) results))\n\nPrints to *out*:\n There are 3 results: 46, 38, 22\n\nDetailed documentation on format control strings is available in the \"Common Lisp the\nLanguage, 2nd edition\", Chapter 22 (available online at:\nhttp://www.cs.cmu.edu/afs/cs.cmu.edu/project/ai-repository/ai/html/cltl/clm/node200.html#SECTION002633000000000000000)\nand in the Common Lisp HyperSpec at\nhttp://www.lispworks.com/documentation/HyperSpec/Body/22_c.htm\nR11,s3,1.2R12,V2,V2,s117,http://www.cs.cmu.edu/afs/cs.cmu.edu/project/ai-repository/ai/html/cltl/clm/node200.html#SECTION002633000000000000000s24,Common Lisp the LanguageV2,s62,http://www.lispworks.com/documentation/HyperSpec/Body/22_c.htms21,Common Lisp HyperSpecR2,i26,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint12,*format-str*m10,R13,TR14,TR2,i65,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint12,format-errorm10,R13,TR5,L1,V2,R15,R16,R2,i67,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint13,arg-navigatorv11,arbace.core13,create-structm8,R13,TR2,i78,R3,i1,R4,s26,arbace/pprint/cl_format.aeR17,R18,R19,m14,R13,TR5,L1,V1,R20,R10,s71,Create a new arg-navigator from the sequence with the position set to 0R21,TR2,i81,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint8,next-argm10,R13,TR5,L1,V1,R22,R2,i89,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint15,next-arg-or-nilm10,R13,TR5,L1,V1,R22,R2,i95,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint14,get-format-argm10,R13,TR5,L1,V1,R22,R2,i102,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint19,relative-repositionm8,R1,TR2,i109,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint19,absolute-repositionm10,R13,TR5,L1,V2,R22,R23,R2,i111,R3,i1,R4,s26,arbace/pprint/cl_format.aem10,R13,TR5,L1,V2,R22,R23,R2,i116,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint18,compiled-directivem8,R13,TR2,i122,R3,i1,R4,s26,arbace/pprint/cl_format.aeR24,R25,R26,R27,v13,arbace.pprint17,realize-parameterm10,R13,TR5,L1,V2,V2,R28,V2,R29,R16,R22,R2,i133,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint22,realize-parameter-listm10,R13,TR5,L1,V2,R30,R22,R2,i149,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint12,opt-base-strm8,R1,TR2,i162,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint21,special-radix-markersm6,l2,s2,#bl8,s2,#ol16,s2,#xm8,R13,TR2,i164,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint20,format-simple-numberm10,R13,TR5,L1,V1,R31,R2,i167,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint12,format-asciim10,R13,TR5,L1,V4,R32,R33,R34,R35,R2,i181,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint9,integral?m12,R13,TR5,L1,V1,R36,R10,s81,returns true if a number is actually an integer (that is, has no fractional part)R2,i204,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint10,remaindersm12,R13,TR5,L1,V2,R37,R38,R10,s81,Return the list of remainders (essentially the 'digits') of val in the given baseR2,i215,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint8,base-strm12,R13,TR5,L1,V2,R37,R38,R10,s40,Return val as a string in the given baseR2,i226,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint17,java-base-formatsm6,l8,s2,%ol10,s2,%dl16,s2,%xm8,R13,TR2,i241,R3,i1,R4,s26,arbace/pprint/cl_format.aem12,R13,TR5,L1,V2,R37,R38,R10,s104,Return val as a string in the given base, using arbace.core/format if supported\nfor improved performanceR2,i244,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint9,group-by*m10,R13,TR5,L1,V2,R39,R40,R2,i253,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint14,format-integerm10,R13,TR5,L1,V4,R37,R33,R34,R35,R2,i258,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint22,english-cardinal-unitsV20,s4,zeros3,ones3,twos5,threes4,fours4,fives3,sixs5,sevens5,eights4,nines3,tens6,elevens6,twelves8,thirteens8,fourteens7,fifteens7,sixteens9,seventeens8,eighteens8,nineteenm8,R13,TR2,i288,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint21,english-ordinal-unitsV20,s6,zeroths5,firsts6,seconds5,thirds6,fourths5,fifths5,sixths7,sevenths6,eighths5,ninths5,tenths8,elevenths7,twelfths10,thirteenths10,fourteenths9,fifteenths9,sixteenths11,seventeenths10,eighteenths10,nineteenthm8,R13,TR2,i294,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint21,english-cardinal-tensV10,s0,s0,s6,twentys6,thirtys5,fortys5,fiftys5,sixtys7,seventys6,eightys6,ninetym8,R13,TR2,i300,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint20,english-ordinal-tensV10,s0,s0,s9,twentieths9,thirtieths8,fortieths8,fiftieths8,sixtieths10,seventieths9,eightieths9,ninetiethm8,R13,TR2,i304,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint21,english-scale-numbersV22,s0,s8,thousands7,millions7,billions8,trillions11,quadrillions11,quintillions10,sextillions10,septillions9,octillions9,nonillions9,decillions11,undecillions12,duodecillions12,tredecillions17,quattuordecillions13,quindecillions12,sexdecillions15,septendecillions13,octodecillions14,novemdecillions12,vigintillionm8,R13,TR2,i313,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint22,format-simple-cardinalm12,R13,TR5,L1,V1,R41,R10,s60,Convert a number less than 1000 to a cardinal english stringR2,i321,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint18,add-english-scalesm12,R13,TR5,L1,V2,R42,R16,R10,s127,Take a sequence of parts, add scale numbers (e.g., million) and combine into a string\noffset is a factor of 10^3 to multiply byR2,i339,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint23,format-cardinal-englishm10,R13,TR5,L1,V3,R33,R22,R35,R2,i362,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint21,format-simple-ordinalm12,R13,TR5,L1,V1,R41,R10,s122,Convert a number less than 1000 to a ordinal english string\nNote this should only be used for the last one in the sequenceR2,i379,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint22,format-ordinal-englishm10,R13,TR5,L1,V3,R33,R22,R35,R2,i401,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint15,old-roman-tableV4,V9,s1,Is2,IIs3,IIIs4,IIIIs1,Vs2,VIs3,VIIs4,VIIIs5,VIIIIV9,s1,Xs2,XXs3,XXXs4,XXXXs1,Ls2,LXs3,LXXs4,LXXXs5,LXXXXV9,s1,Cs2,CCs3,CCCs4,CCCCs1,Ds2,DCs3,DCCs4,DCCCs5,DCCCCV3,s1,Ms2,MMs3,MMMm8,R13,TR2,i437,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint15,new-roman-tableV4,V9,s1,Is2,IIs3,IIIs2,IVs1,Vs2,VIs3,VIIs4,VIIIs2,IXV9,s1,Xs2,XXs3,XXXs2,XLs1,Ls2,LXs3,LXXs4,LXXXs2,XCV9,s1,Cs2,CCs3,CCCs2,CDs1,Ds2,DCs3,DCCs4,DCCCs2,CMV3,s1,Ms2,MMs3,MMMm8,R13,TR2,i444,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint12,format-romanm12,R13,TR5,L1,V4,R43,R33,R22,R35,R10,s56,Format a roman numeral using the specified look-up tableR2,i451,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint16,format-old-romanm10,R13,TR5,L1,V3,R33,R22,R35,R2,i475,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint16,format-new-romanm10,R13,TR5,L1,V3,R33,R22,R35,R2,i478,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint13,special-charsm10,l8,s9,Backspacel9,s3,Tabl10,s7,Newlinel13,s6,Returnl32,s5,Spacem8,R13,TR2,i485,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint16,pretty-characterm10,R13,TR5,L1,V3,R33,R22,R35,R2,i488,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint18,readable-characterm10,R13,TR5,L1,V3,R33,R22,R35,R2,i502,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint15,plain-characterm10,R13,TR5,L1,V3,R33,R22,R35,R2,i510,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint6,abort?m10,R13,TR5,L1,V1,R44,R2,i517,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint18,execute-sub-formatm10,R13,TR5,L1,V3,R45,R9,R46,R2,i522,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint16,float-parts-basem12,R13,TR5,L1,V1,Myn1,fm2,R47,R48,R10,s67,Produce string parts for the mantissa (normalized 1-9) and exponentR2,i540,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint11,float-partsm12,R13,TR5,L1,V1,R49,R10,s60,Take care of leading and trailing zeros in decomposed floatsR2,i554,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint5,inc-sm14,R47,C16,java.lang.StringR13,TR5,L1,V1,Myn1,sm2,R47,R50,R10,s306,Assumption: The input string consists of one or more decimal digits,\nand no other characters.  Return a string containing one or more\ndecimal digits containing a decimal number one larger than the input\nstring.  The output string will always be the same length as the input\nstring, or one character longer.R2,i566,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint9,round-strm10,R13,TR5,L1,V4,R51,R52,R53,R54,R2,i582,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint12,expand-fixedm10,R13,TR5,L1,V3,R51,R52,R53,R2,i624,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint14,insert-decimalm12,R13,TR5,L1,V2,R51,R52,R10,s77,Insert the decimal point at the right spot in the number to match an exponentR2,i634,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint9,get-fixedm10,R13,TR5,L1,V3,R51,R52,R53,R2,i642,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint21,insert-scaled-decimalm12,R13,TR5,L1,V2,R51,R55,R10,s77,Insert the decimal point at the right spot in the number to match an exponentR2,i645,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint13,convert-ratiom10,R13,TR5,L1,V1,R36,R2,i652,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint11,fixed-floatm10,R13,TR5,L1,V3,R33,R22,R35,R2,i669,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint17,exponential-floatm10,R13,TR5,L1,V3,R33,R22,R35,R2,i716,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint13,general-floatm10,R13,TR5,L1,V3,R33,R22,R35,R2,i790,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint12,dollar-floatm10,R13,TR5,L1,V3,R33,R22,R35,R2,i813,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint18,choice-conditionalm10,R13,TR5,L1,V3,R33,R34,R35,R2,i839,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint19,boolean-conditionalm10,R13,TR5,L1,V3,R33,R34,R35,R2,i851,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint21,check-arg-conditionalm10,R13,TR5,L1,V3,R33,R34,R35,R2,i863,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint15,iterate-sublistm10,R13,TR5,L1,V3,R33,R22,R35,R2,i880,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint24,iterate-list-of-sublistsm10,R13,TR5,L1,V3,R33,R22,R35,R2,i905,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint17,iterate-main-listm10,R13,TR5,L1,V3,R33,R22,R35,R2,i928,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint21,iterate-main-sublistsm10,R13,TR5,L1,V3,R33,R22,R35,R2,i952,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint20,format-logical-blockm8,R1,TR2,i984,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint15,justify-clausesm8,R1,TR2,i985,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint24,logical-block-or-justifym10,R13,TR5,L1,V3,R33,R22,R35,R2,i987,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint14,render-clausesm10,R13,TR5,L1,V3,R56,R22,R57,R2,i996,R3,i1,R4,s26,arbace/pprint/cl_format.aem10,R13,TR5,L1,V3,R33,R22,R35,R2,i1011,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint15,downcase-writerm12,R13,TR5,L1,V1,Myn6,writerm2,R47,R58,R10,s74,Returns a proxy that wraps writer, converting all characters to lower caseR2,i1066,R3,i1,R4,s26,arbace/pprint/cl_format.aev11,arbace.core15,get-proxy-classC14,java.io.Writerv13,arbace.pprint13,upcase-writerm12,R13,TR5,L1,V1,Myn6,writerm2,R47,R58,R10,s74,Returns a proxy that wraps writer, converting all characters to upper caseR2,i1084,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint17,capitalize-stringm12,R13,TR5,L1,V2,R20,R59,R10,s166,Capitalizes the words in a string. If first? is false, don't capitalize the\n                                      first character of the string even if it's a letter.R2,i1102,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint22,capitalize-word-writerm12,R13,TR5,L1,V1,Myn6,writerm2,R47,R58,R10,s57,Returns a proxy that wraps writer, capitalizing all wordsR2,i1126,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint15,init-cap-writerm12,R13,TR5,L1,V1,Myn6,writerm2,R47,R58,R10,s62,Returns a proxy that wraps writer, capitalizing the first wordR2,i1154,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint11,modify-casem10,R13,TR5,L1,V4,R60,R33,R22,R35,R2,i1188,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint17,get-pretty-writerm12,R5,L1,V1,R6,R10,s1071,Returns the java.io.Writer passed in wrapped in a pretty writer proxy, unless it's\nalready a pretty writer. Generally, it is unnecessary to call this function, since pprint,\nwrite, and cl-format all call it if they need to. However if you want the state to be\npreserved across calls, you will want to wrap them with this.\n\nFor example, when you want to generate column-aware output with multiple calls to cl-format,\ndo it like in this example:\n\n    (defn print-table [aseq column-width]\n      (binding [*out* (get-pretty-writer *out*)]\n        (doseq [row aseq]\n          (doseq [col row]\n            (cl-format true \"~4D~7,vT\" col column-width))\n          (prn))))\n\nNow when you run:\n\n    user> (print-table (map #(vector % (* % %) (* % % %)) (range 1 11)) 8)\n\nIt prints a table of squares and cubes for the numbers from 1 to 10:\n\n       1      1       1\n       2      4       8\n       3      9      27\n       4     16      64\n       5     25     125\n       6     36     216\n       7     49     343\n       8     64     512\n       9     81     729\n      10    100    1000R11,s3,1.2R2,i1197,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint10,fresh-linem12,R5,L1,V0,R10,s172,Make a newline if *out* is not already at the beginning of the line. If *out* is\nnot a pretty writer (which keeps track of columns), this function always outputs a newline.R11,s3,1.2R2,i1239,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint19,absolute-tabulationm10,R13,TR5,L1,V3,R33,R22,R35,R2,i1249,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint19,relative-tabulationm10,R13,TR5,L1,V3,R33,R22,R35,R2,i1260,R3,i1,R4,s26,arbace/pprint/cl_format.aem10,R13,TR5,L1,V3,R33,R22,R35,R2,i1275,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint10,set-indentm10,R13,TR5,L1,V3,R33,R22,R35,R2,i1293,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint19,conditional-newlinem10,R13,TR5,L1,V3,R33,R22,R35,R2,i1300,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint31,process-directive-table-elementm10,R13,TR5,L1,V1,V6,R61,R33,R62,R63,R8,R64,R2,i1313,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint13,defdirectivesm10,R13,TR5,L1,V2,R8,R65,R2,i1321,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint15,directive-tablev11,arbace.core8,hash-mapc65,R66,v11,arbace.core9,array-mapR67,S3,R68,R69,R70,R71,R72,c83,S3,R68,R69,R70,c68,S3,R68,R69,R70,c66,S3,R68,R69,R70,c79,S3,R68,R69,R70,c88,S3,R68,R69,R70,c82,S3,R68,R69,R70,c80,S3,R68,R69,R70,c67,S3,R68,R69,R70,c70,S1,R69,c69,S1,R69,c71,S1,R69,c36,S3,R68,R69,R70,c37,c38,S1,R73,c124,c126,c10,S2,R68,R69,c84,S2,R69,R73,c42,S2,R68,R69,c63,S1,R69,c40,S3,R68,R69,R70,m6,R74,c41,R75,nR76,nc41,c91,S2,R68,R69,m6,R74,c93,R75,TR76,R77,c59,S1,R68,m2,R78,Tc93,c123,S3,R68,R69,R70,m4,R74,c125,R75,Fc125,S1,R68,c60,S4,R68,R69,R70,R73,m6,R74,c62,R75,TR76,R79,c62,S1,R68,c94,S1,R68,c87,S4,R68,R69,R70,R73,c95,S3,R68,R69,R70,c73,S1,R68,m8,R13,TR4,s26,arbace/pprint/cl_format.aeR3,i1,R2,i1327,R80,V2,l0,C17,java.lang.IntegerR81,V2,l1,C17,java.lang.IntegerR82,V2,l0,C17,java.lang.IntegerR83,V2,c32,C19,java.lang.CharacterV2,l0,C17,java.lang.IntegerV2,l1,C17,java.lang.IntegerV2,l0,C17,java.lang.IntegerV2,c32,C19,java.lang.CharacterV2,l0,C17,java.lang.IntegerV2,c32,C19,java.lang.CharacterR84,V2,c44,C19,java.lang.CharacterR85,V2,l3,C17,java.lang.IntegerV2,l0,C17,java.lang.IntegerV2,c32,C19,java.lang.CharacterV2,c44,C19,java.lang.CharacterV2,l3,C17,java.lang.IntegerV2,l0,C17,java.lang.IntegerV2,c32,C19,java.lang.CharacterV2,c44,C19,java.lang.CharacterV2,l3,C17,java.lang.IntegerV2,l0,C17,java.lang.IntegerV2,c32,C19,java.lang.CharacterV2,c44,C19,java.lang.CharacterV2,l3,C17,java.lang.IntegerR86,V2,nC17,java.lang.IntegerV2,l0,C17,java.lang.IntegerV2,c32,C19,java.lang.CharacterV2,c44,C19,java.lang.CharacterV2,l3,C17,java.lang.IntegerR87,V2,nC19,java.lang.CharacterR88,V2,nC17,java.lang.IntegerR89,V2,nC17,java.lang.IntegerR90,V2,l0,C17,java.lang.IntegerR91,V2,nC19,java.lang.CharacterV2,c32,C19,java.lang.CharacterV2,nC17,java.lang.IntegerV2,nC17,java.lang.IntegerR92,V2,nC17,java.lang.IntegerV2,l1,C17,java.lang.IntegerV2,nC19,java.lang.CharacterV2,c32,C19,java.lang.CharacterR93,V2,nC19,java.lang.CharacterV2,nC17,java.lang.IntegerV2,nC17,java.lang.IntegerV2,nC17,java.lang.IntegerV2,l1,C17,java.lang.IntegerV2,nC19,java.lang.CharacterV2,c32,C19,java.lang.CharacterV2,nC19,java.lang.CharacterV2,l2,C17,java.lang.IntegerR94,V2,l1,C17,java.lang.IntegerV2,l0,C17,java.lang.IntegerV2,c32,C19,java.lang.CharacterR95,V2,l1,C17,java.lang.IntegerV2,l1,C17,java.lang.IntegerV2,l1,C17,java.lang.IntegerV2,l1,C17,java.lang.IntegerR96,V2,l1,C17,java.lang.IntegerV2,l1,C17,java.lang.IntegerV2,nC17,java.lang.IntegerR97,V2,nC17,java.lang.IntegerR98,V2,nC17,java.lang.IntegerR99,V2,nC17,java.lang.IntegerR100,V2,nC17,java.lang.IntegerV2,l0,C17,java.lang.IntegerV2,l1,C17,java.lang.IntegerV2,l0,C17,java.lang.IntegerV2,c32,C19,java.lang.CharacterR101,V2,nC17,java.lang.IntegerR102,V2,nC17,java.lang.IntegerR103,V2,nC17,java.lang.IntegerV2,l0,C17,java.lang.Integerv13,arbace.pprint13,param-patternp31,^([vV]|#|('.)|([+-]?\\d+)|(?=,))m8,R13,TR2,i1613,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint14,special-paramsS2,R104,R105,m8,R13,TR2,i1615,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint13,extract-paramm10,R13,TR5,L1,V1,V3,R20,R16,R106,R2,i1618,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint14,extract-paramsm10,R13,TR5,L1,V2,R20,R16,R2,i1632,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint15,translate-paramm12,R13,TR5,L1,V1,V2,Myn1,pm2,R47,R50,R16,R10,s119,Translate the string representation of a param to the internalized\n                                      representationR2,i1635,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint9,flag-defsm4,c58,R68,c64,R69,m8,R13,TR2,i1647,R3,i1,R4,s26,arbace/pprint/cl_format.aev13,arbace.pprint13,extract-flagsm10,R13,TR5,L1,V2,R20,R16,R2,i1650,R3,i1,R4,s26,arbace/pprint/cl_format.ae")

var Lit_1 *jrt.String = jrt.Intern("arbace.pprint$cl_format")

var Lit_2 *jrt.String = jrt.Intern("arbace.pprint$format_error")

var Lit_3 *jrt.String = jrt.Intern("arbace.pprint$init_navigator")

var Lit_4 *jrt.String = jrt.Intern("arbace.pprint$next_arg")

var Lit_5 *jrt.String = jrt.Intern("arbace.pprint$next_arg_or_nil")

var Lit_6 *jrt.String = jrt.Intern("arbace.pprint$get_format_arg")

var Lit_7 *jrt.String = jrt.Intern("arbace.pprint$absolute_reposition")

var Lit_8 *jrt.String = jrt.Intern("arbace.pprint$relative_reposition")

var Lit_9 *jrt.String = jrt.Intern("arbace.pprint$realize_parameter")

var Lit_10 *jrt.String = jrt.Intern("arbace.pprint$realize_parameter_list")

var Lit_11 *jrt.String = jrt.Intern("arbace.pprint$format_simple_number")

var Lit_12 *jrt.String = jrt.Intern("arbace.pprint$format_ascii")

var Lit_13 *jrt.String = jrt.Intern("arbace.pprint$integral_QMARK_")

var Lit_14 *jrt.String = jrt.Intern("arbace.pprint$remainders")

var Lit_15 *jrt.String = jrt.Intern("arbace.pprint$base_str")

var Lit_16 *jrt.String = jrt.Intern("arbace.pprint$opt_base_str")

var Lit_17 *jrt.String = jrt.Intern("arbace.pprint$group_by_STAR_")

var Lit_18 *jrt.String = jrt.Intern("arbace.pprint$format_integer")

var Lit_19 *jrt.String = jrt.Intern("arbace.pprint$format_simple_cardinal")

var Lit_20 *jrt.String = jrt.Intern("arbace.pprint$add_english_scales")

var Lit_21 *jrt.String = jrt.Intern("arbace.pprint$format_cardinal_english")

var Lit_22 *jrt.String = jrt.Intern("arbace.pprint$format_simple_ordinal")

var Lit_23 *jrt.String = jrt.Intern("arbace.pprint$format_ordinal_english")

var Lit_24 *jrt.String = jrt.Intern("arbace.pprint$format_roman")

var Lit_25 *jrt.String = jrt.Intern("arbace.pprint$format_old_roman")

var Lit_26 *jrt.String = jrt.Intern("arbace.pprint$format_new_roman")

var Lit_27 *jrt.String = jrt.Intern("arbace.pprint$pretty_character")

var Lit_28 *jrt.String = jrt.Intern("arbace.pprint$readable_character")

var Lit_29 *jrt.String = jrt.Intern("arbace.pprint$plain_character")

var Lit_30 *jrt.String = jrt.Intern("arbace.pprint$abort_QMARK_")

var Lit_31 *jrt.String = jrt.Intern("arbace.pprint$execute_sub_format")

var Lit_32 *jrt.String = jrt.Intern("arbace.pprint$float_parts_base")

var Lit_33 *jrt.String = jrt.Intern("arbace.pprint$float_parts")

var Lit_34 *jrt.String = jrt.Intern("arbace.pprint$inc_s")

var Lit_35 *jrt.String = jrt.Intern("arbace.pprint$round_str")

var Lit_36 *jrt.String = jrt.Intern("arbace.pprint$expand_fixed")

var Lit_37 *jrt.String = jrt.Intern("arbace.pprint$insert_decimal")

var Lit_38 *jrt.String = jrt.Intern("arbace.pprint$get_fixed")

var Lit_39 *jrt.String = jrt.Intern("arbace.pprint$insert_scaled_decimal")

var Lit_40 *jrt.String = jrt.Intern("arbace.pprint$convert_ratio")

var Lit_41 *jrt.String = jrt.Intern("arbace.pprint$fixed_float")

var Lit_42 *jrt.String = jrt.Intern("arbace.pprint$exponential_float")

var Lit_43 *jrt.String = jrt.Intern("arbace.pprint$general_float")

var Lit_44 *jrt.String = jrt.Intern("arbace.pprint$dollar_float")

var Lit_45 *jrt.String = jrt.Intern("arbace.pprint$choice_conditional")

var Lit_46 *jrt.String = jrt.Intern("arbace.pprint$boolean_conditional")

var Lit_47 *jrt.String = jrt.Intern("arbace.pprint$check_arg_conditional")

var Lit_48 *jrt.String = jrt.Intern("arbace.pprint$iterate_sublist")

var Lit_49 *jrt.String = jrt.Intern("arbace.pprint$iterate_list_of_sublists")

var Lit_50 *jrt.String = jrt.Intern("arbace.pprint$iterate_main_list")

var Lit_51 *jrt.String = jrt.Intern("arbace.pprint$iterate_main_sublists")

var Lit_52 *jrt.String = jrt.Intern("arbace.pprint$logical_block_or_justify")

var Lit_53 *jrt.String = jrt.Intern("arbace.pprint$render_clauses")

var Lit_54 *jrt.String = jrt.Intern("arbace.pprint$justify_clauses")

var Lit_55 *jrt.String = jrt.Intern("arbace.pprint$downcase_writer")

var Lit_56 *jrt.String = jrt.Intern("arbace.pprint$upcase_writer")

var Lit_57 *jrt.String = jrt.Intern("arbace.pprint$capitalize_string")

var Lit_58 *jrt.String = jrt.Intern("arbace.pprint$capitalize_word_writer")

var Lit_59 *jrt.String = jrt.Intern("arbace.pprint$init_cap_writer")

var Lit_60 *jrt.String = jrt.Intern("arbace.pprint$modify_case")

var Lit_61 *jrt.String = jrt.Intern("arbace.pprint$get_pretty_writer")

var Lit_62 *jrt.String = jrt.Intern("arbace.pprint$fresh_line")

var Lit_63 *jrt.String = jrt.Intern("arbace.pprint$absolute_tabulation")

var Lit_64 *jrt.String = jrt.Intern("arbace.pprint$relative_tabulation")

var Lit_65 *jrt.String = jrt.Intern("arbace.pprint$format_logical_block")

var Lit_66 *jrt.String = jrt.Intern("arbace.pprint$set_indent")

var Lit_67 *jrt.String = jrt.Intern("arbace.pprint$conditional_newline")

var Lit_68 *jrt.String = jrt.Intern("arbace.pprint$process_directive_table_element")

var Lit_69 *jrt.String = jrt.Intern("arbace.pprint$defdirectives")

var Lit_70 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000328")

var Lit_71 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000332")

var Lit_72 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000336")

var Lit_73 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000340")

var Lit_74 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000344")

var Lit_75 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000348")

var Lit_76 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000352")

var Lit_77 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000364")

var Lit_78 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000371")

var Lit_79 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000373")

var Lit_80 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000375")

var Lit_81 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000377")

var Lit_82 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000379")

var Lit_83 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000381")

var Lit_84 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000385")

var Lit_85 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000389")

var Lit_86 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000393")

var Lit_87 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000397")

var Lit_88 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000401")

var Lit_89 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000407")

var Lit_90 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000413")

var Lit_91 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000428")

var Lit_92 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000432")

var Lit_93 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000434")

var Lit_94 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000436")

var Lit_95 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000438")

var Lit_96 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000440")

var Lit_97 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000442")

var Lit_98 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000444")

var Lit_99 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000446")

var Lit_100 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000448")

var Lit_101 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000452")

var Lit_102 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000464")

var Lit_103 *jrt.String = jrt.Intern("arbace.pprint$fn__1819000466")

var Lit_104 *jrt.String = jrt.Intern("arbace.pprint$extract_param")

var Lit_105 *jrt.String = jrt.Intern("arbace.pprint$extract_params")

var Lit_106 *jrt.String = jrt.Intern("arbace.pprint$translate_param")

var Lit_107 *jrt.String = jrt.Intern("arbace.pprint$extract_flags")

var Lit_108 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn3,defyn5,flagskn4,linekn6,columnkn4,fileyn6,paramsyn6,offsetkn3,docyn1,syn4,thiskn8,declaredyn9,remainderyn12,bracket-infoyn6,formatyn10,format-stryn6,streamyn4,argskn9,skip-wikiyn9,format-inkn5,addedv13,arbace.pprint11,check-flagsm10,R0,TR1,L1,V2,R2,R3,R4,i1665,R5,i1,R6,s26,arbace/pprint/cl_format.aev13,arbace.pprint10,map-paramsm12,R0,TR1,L1,V4,R2,R7,R3,R8,R9,s239,Takes a directive definition and the list of actual parameters and\na map of flags and returns a map of the parameters and flags with defaults\nfilled in. We check to make sure that there are the right types and number\nof parameters as well.R4,i1678,R5,i1,R6,s26,arbace/pprint/cl_format.aev13,arbace.pprint17,compile-directivem10,R0,TR1,L1,V2,R10,R8,R4,i1708,R5,i1,R6,s26,arbace/pprint/cl_format.aev13,arbace.pprint18,compile-raw-stringm10,R0,TR1,L1,V2,R10,R8,R4,i1728,R5,i1,R6,s26,arbace/pprint/cl_format.aev13,arbace.pprint13,right-bracketm10,R0,TR1,L1,V1,R11,R4,i1731,R5,i1,R6,s26,arbace/pprint/cl_format.aev13,arbace.pprint10,separator?m10,R0,TR1,L1,V1,R11,R4,i1732,R5,i1,R6,s26,arbace/pprint/cl_format.aev13,arbace.pprint15,else-separator?m10,R0,TR1,L1,V1,R11,R4,i1733,R5,i1,R6,s26,arbace/pprint/cl_format.aev13,arbace.pprint15,collect-clausesm8,R12,TR4,i1738,R5,i1,R6,s26,arbace/pprint/cl_format.aev13,arbace.pprint15,process-bracketm10,R0,TR1,L1,V2,R11,R13,R4,i1740,R5,i1,R6,s26,arbace/pprint/cl_format.aev13,arbace.pprint14,process-clausem10,R0,TR1,L1,V3,R14,R8,R13,R4,i1749,R5,i1,R6,s26,arbace/pprint/cl_format.aem10,R0,TR1,L1,V3,R14,R8,R13,R4,i1773,R5,i1,R6,s26,arbace/pprint/cl_format.aev13,arbace.pprint15,process-nestingm12,R0,TR1,L1,V1,R15,R9,s111,Take a linearly compiled format and process the bracket directives to give it\n   the appropriate tree structureR4,i1822,R5,i1,R6,s26,arbace/pprint/cl_format.aem12,R0,TR1,L1,V1,R16,R9,s216,Compiles format-str into a compiled format which can be used as an argument\nto cl-format just like a plain format string. Use this function for improved\nperformance when you're using the same format string repeatedlyR4,i1837,R5,i1,R6,s26,arbace/pprint/cl_format.aev13,arbace.pprint12,needs-prettym12,R0,TR1,L1,V1,R15,R9,s112,determine whether a given compiled format has any directives that depend on the\ncolumn number or pretty printingR4,i1858,R5,i1,R6,s26,arbace/pprint/cl_format.aem14,R0,TR1,L2,V3,R17,R15,R18,V2,R15,R18,R9,s39,Executes the format with the arguments.R19,TR4,i1871,R5,i1,R6,s26,arbace/pprint/cl_format.aev13,arbace.pprint14,cached-compilev11,arbace.core7,memoizem8,R0,TR4,i1906,R5,i1,R6,s26,arbace/pprint/cl_format.aev13,arbace.pprint9,formatterm12,R1,L1,V1,R20,R9,s281,Makes a function which can directly run format-in. The function is\nfn [stream & args] ... and returns nil unless the stream is nil (meaning\noutput to a string) in which case it returns the resulting string.\n\nformat-in can be either a control string or a previously compiled format.R21,s3,1.2R4,i1908,R5,i1,R6,s26,arbace/pprint/cl_format.aev13,arbace.pprint13,formatter-outm12,R1,L1,V1,R20,R9,s359,Makes a function which can directly run format-in. The function is\nfn [& args] ... and returns nil. This version of the formatter macro is\ndesigned to be used with *out* set to an appropriate Writer. In particular,\nthis is meant to be used as part of a pretty printer dispatch method.\n\nformat-in can be either a control string or a previously compiled format.R21,s3,1.2R4,i1928,R5,i1,R6,s26,arbace/pprint/cl_format.ae")

var Lit_109 *jrt.String = jrt.Intern("arbace.pprint$check_flags")

var Lit_110 *jrt.String = jrt.Intern("arbace.pprint$map_params")

var Lit_111 *jrt.String = jrt.Intern("arbace.pprint$compile_directive")

var Lit_112 *jrt.String = jrt.Intern("arbace.pprint$compile_raw_string")

var Lit_113 *jrt.String = jrt.Intern("arbace.pprint$right_bracket")

var Lit_114 *jrt.String = jrt.Intern("arbace.pprint$separator_QMARK_")

var Lit_115 *jrt.String = jrt.Intern("arbace.pprint$else_separator_QMARK_")

var Lit_116 *jrt.String = jrt.Intern("arbace.pprint$process_bracket")

var Lit_117 *jrt.String = jrt.Intern("arbace.pprint$process_clause")

var Lit_118 *jrt.String = jrt.Intern("arbace.pprint$collect_clauses")

var Lit_119 *jrt.String = jrt.Intern("arbace.pprint$process_nesting")

var Lit_120 *jrt.String = jrt.Intern("arbace.pprint$compile_format")

var Lit_121 *jrt.String = jrt.Intern("arbace.pprint$needs_pretty")

var Lit_122 *jrt.String = jrt.Intern("arbace.pprint$execute_format")

var Lit_123 *jrt.String = jrt.Intern("arbace.pprint$formatter")

var Lit_124 *jrt.String = jrt.Intern("arbace.pprint$formatter_out")
