//line a2g_up.ae:1
package aot_arbace_pprint_cl_format

import "arbace/lang"


func Up_ArraySeq_ISeq(p *lang.ArraySeq) lang.ISeq { if p == nil { return nil }; return p }

func Up_Symbol_IObj(p *lang.Symbol) lang.IObj { if p == nil { return nil }; return p }
