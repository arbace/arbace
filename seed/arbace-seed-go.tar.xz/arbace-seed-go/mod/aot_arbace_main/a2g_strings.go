//line a2g_strings.ae:1
package aot_arbace_main

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("exclude")

var Lit_4 *jrt.String = jrt.Intern("with-bindings")

var Lit_5 *jrt.String = jrt.Intern("arbace.spec.alpha")

var Lit_6 *jrt.String = jrt.Intern("as")

var Lit_7 *jrt.String = jrt.Intern("spec")

var Lit_8 *jrt.String = jrt.Intern("commute")

var Lit_9 *jrt.String = jrt.Intern("deref")

var Lit_10 *jrt.String = jrt.Intern("conj")

var Lit_11 *jrt.String = jrt.Intern("arbace.main")

var Lit_12 *jrt.String = jrt.Intern("doc")

var Lit_13 *jrt.String = jrt.Intern("Top-level main function for Clojure REPL and scripts.")

var Lit_14 *jrt.String = jrt.Intern("author")

var Lit_15 *jrt.String = jrt.Intern("Stephen C. Gilardi and Rich Hickey")

var Lit_16 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_17 *jrt.String = jrt.Intern("not=")

var Lit_18 *jrt.String = jrt.Intern("not")

var Lit_19 *jrt.String = jrt.Intern("contains?")

var Lit_20 *jrt.String = jrt.Intern("core-namespaces")

var Lit_21 *jrt.String = jrt.Intern("second")

var Lit_22 *jrt.String = jrt.Intern("re-find")

var Lit_23 *jrt.String = jrt.Intern("^([^$]+)\\$")

var Lit_24 *jrt.String = jrt.Intern("demunge")

var Lit_25 *jrt.String = jrt.Intern("seq")

var Lit_26 *jrt.String = jrt.Intern("concat")

var Lit_27 *jrt.String = jrt.Intern("list")

var Lit_28 *jrt.String = jrt.Intern("binding")

var Lit_29 *jrt.String = jrt.Intern("apply")

var Lit_30 *jrt.String = jrt.Intern("vector")

var Lit_31 *jrt.String = jrt.Intern("*ns*")

var Lit_32 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_33 *jrt.String = jrt.Intern("*math-context*")

var Lit_34 *jrt.String = jrt.Intern("*print-meta*")

var Lit_35 *jrt.String = jrt.Intern("*print-length*")

var Lit_36 *jrt.String = jrt.Intern("*print-level*")

var Lit_37 *jrt.String = jrt.Intern("*print-namespace-maps*")

var Lit_38 *jrt.String = jrt.Intern("*data-readers*")

var Lit_39 *jrt.String = jrt.Intern("*default-data-reader-fn*")

var Lit_40 *jrt.String = jrt.Intern("*compile-path*")

var Lit_41 *jrt.String = jrt.Intern("java.lang.System")

var Lit_42 *jrt.String = jrt.Intern("getProperty")

var Lit_43 *jrt.String = jrt.Intern("*command-line-args*")

var Lit_44 *jrt.String = jrt.Intern("*unchecked-math*")

var Lit_45 *jrt.String = jrt.Intern("*assert*")

var Lit_46 *jrt.String = jrt.Intern("*explain-out*")

var Lit_47 *jrt.String = jrt.Intern("*1")

var Lit_48 *jrt.String = jrt.Intern("*2")

var Lit_49 *jrt.String = jrt.Intern("*3")

var Lit_50 *jrt.String = jrt.Intern("*e")

var Lit_51 *jrt.String = jrt.Intern("printf")

var Lit_52 *jrt.String = jrt.Intern("ns-name")

var Lit_53 *jrt.String = jrt.Intern("line-start")

var Lit_54 *jrt.String = jrt.Intern("stream-end")

var Lit_55 *jrt.String = jrt.Intern("else")

var Lit_56 *jrt.String = jrt.Intern("body")

var Lit_57 *jrt.String = jrt.Intern("read+string")

var Lit_58 *jrt.String = jrt.Intern("next")

var Lit_59 *jrt.String = jrt.Intern("to-array")

var Lit_60 *jrt.String = jrt.Intern("first")

var Lit_61 *jrt.String = jrt.Intern("eval-file")

var Lit_62 *jrt.String = jrt.Intern("line")

var Lit_63 *jrt.String = jrt.Intern("read")

var Lit_64 *jrt.String = jrt.Intern("renumbering-read")

var Lit_65 *jrt.String = jrt.Intern("skip-whitespace")

var Lit_66 *jrt.String = jrt.Intern("*in*")

var Lit_67 *jrt.String = jrt.Intern("read-cond")

var Lit_68 *jrt.String = jrt.Intern("allow")

var Lit_69 *jrt.String = jrt.Intern("skip-if-eol")

var Lit_70 *jrt.String = jrt.Intern("root-cause")

var Lit_71 *jrt.String = jrt.Intern("subs")

var Lit_72 *jrt.String = jrt.Intern("invokeStatic")

var Lit_73 *jrt.String = jrt.Intern("invoke")

var Lit_74 *jrt.String = jrt.Intern("java.lang.String")

var Lit_75 *jrt.String = jrt.Intern("map")

var Lit_76 *jrt.String = jrt.Intern("symbol")

var Lit_77 *jrt.String = jrt.Intern("\\$")

var Lit_78 *jrt.String = jrt.Intern("str")

var Lit_79 *jrt.String = jrt.Intern("into-array")

var Lit_80 *jrt.String = jrt.Intern("cons")

var Lit_81 *jrt.String = jrt.Intern("name")

var Lit_82 *jrt.String = jrt.Intern("execution")

var Lit_83 *jrt.String = jrt.Intern("via")

var Lit_84 *jrt.String = jrt.Intern("trace")

var Lit_85 *jrt.String = jrt.Intern("phase")

var Lit_86 *jrt.String = jrt.Intern("last")

var Lit_87 *jrt.String = jrt.Intern("type")

var Lit_88 *jrt.String = jrt.Intern("message")

var Lit_89 *jrt.String = jrt.Intern("data")

var Lit_90 *jrt.String = jrt.Intern("problems")

var Lit_91 *jrt.String = jrt.Intern("fn")

var Lit_92 *jrt.String = jrt.Intern("arbace.spec.test.alpha")

var Lit_93 *jrt.String = jrt.Intern("caller")

var Lit_94 *jrt.String = jrt.Intern("arbace.error")

var Lit_95 *jrt.String = jrt.Intern("source")

var Lit_96 *jrt.String = jrt.Intern("assoc")

var Lit_97 *jrt.String = jrt.Intern("macro-syntax-check")

var Lit_98 *jrt.String = jrt.Intern("NO_SOURCE_PATH")

var Lit_99 *jrt.String = jrt.Intern("NO_SOURCE_FILE")

var Lit_100 *jrt.String = jrt.Intern("dissoc")

var Lit_101 *jrt.String = jrt.Intern("compile-syntax-check")

var Lit_102 *jrt.String = jrt.Intern("macroexpansion")

var Lit_103 *jrt.String = jrt.Intern("class")

var Lit_104 *jrt.String = jrt.Intern("file-name")

var Lit_105 *jrt.String = jrt.Intern("path")

var Lit_106 *jrt.String = jrt.Intern("file-path")

var Lit_107 *jrt.String = jrt.Intern("cause")

var Lit_108 *jrt.String = jrt.Intern("read-source")

var Lit_109 *jrt.String = jrt.Intern("column")

var Lit_110 *jrt.String = jrt.Intern("merge")

var Lit_111 *jrt.String = jrt.Intern("drop-while")

var Lit_112 *jrt.String = jrt.Intern("core-class?")

var Lit_113 *jrt.String = jrt.Intern("remove")

var Lit_114 *jrt.String = jrt.Intern("file")

var Lit_115 *jrt.String = jrt.Intern("java-loc->source")

var Lit_116 *jrt.String = jrt.Intern("read-eval-result")

var Lit_117 *jrt.String = jrt.Intern("compilation")

var Lit_118 *jrt.String = jrt.Intern("print-eval-result")

var Lit_119 *jrt.String = jrt.Intern("format")

var Lit_120 *jrt.String = jrt.Intern("([^.])++$")

var Lit_121 *jrt.String = jrt.Intern("RuntimeException")

var Lit_122 *jrt.String = jrt.Intern("Exception")

var Lit_123 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_124 *jrt.String = jrt.Intern("explain-out")

var Lit_125 *jrt.String = jrt.Intern("explain-printer")

var Lit_126 *jrt.String = jrt.Intern("update")

var Lit_127 *jrt.String = jrt.Intern("in")

var Lit_128 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_129 *jrt.String = jrt.Intern("hash-map")

var Lit_130 *jrt.String = jrt.Intern("*out*")

var Lit_131 *jrt.String = jrt.Intern("ex-str")

var Lit_132 *jrt.String = jrt.Intern("ex-triage")

var Lit_133 *jrt.String = jrt.Intern("Throwable->map")

var Lit_134 *jrt.String = jrt.Intern("flush")

var Lit_135 *jrt.String = jrt.Intern("*err*")

var Lit_136 *jrt.String = jrt.Intern("print")

var Lit_137 *jrt.String = jrt.Intern("err->msg")

var Lit_138 *jrt.String = jrt.Intern("*read-eval*")

var Lit_139 *jrt.String = jrt.Intern("if")

var Lit_140 *jrt.String = jrt.Intern("=")

var Lit_141 *jrt.String = jrt.Intern("unknown")

var Lit_142 *jrt.String = jrt.Intern("identity")

var Lit_143 *jrt.String = jrt.Intern("repl-prompt")

var Lit_144 *jrt.String = jrt.Intern("repl-read")

var Lit_145 *jrt.String = jrt.Intern("eval")

var Lit_146 *jrt.String = jrt.Intern("prn")

var Lit_147 *jrt.String = jrt.Intern("repl-caught")

var Lit_148 *jrt.String = jrt.Intern("init")

var Lit_149 *jrt.String = jrt.Intern("need-prompt")

var Lit_150 *jrt.String = jrt.Intern("prompt")

var Lit_151 *jrt.String = jrt.Intern("caught")

var Lit_152 *jrt.String = jrt.Intern("ex-info")

var Lit_153 *jrt.String = jrt.Intern("java.lang.Thread")

var Lit_154 *jrt.String = jrt.Intern("*repl*")

var Lit_155 *jrt.String = jrt.Intern("requiring-resolve")

var Lit_156 *jrt.String = jrt.Intern("arbace.box")

var Lit_157 *jrt.String = jrt.Intern("load-ref")

var Lit_158 *jrt.String = jrt.Intern("load-script")

var Lit_159 *jrt.String = jrt.Intern("init-opt")

var Lit_160 *jrt.String = jrt.Intern("eval-opt")

var Lit_161 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_162 *jrt.String = jrt.Intern("chunk-first")

var Lit_163 *jrt.String = jrt.Intern("in-ns")

var Lit_164 *jrt.String = jrt.Intern("user")

var Lit_165 *jrt.String = jrt.Intern("init-dispatch")

var Lit_166 *jrt.String = jrt.Intern("chunk-rest")

var Lit_167 *jrt.String = jrt.Intern("initialize")

var Lit_168 *jrt.String = jrt.Intern("ns-resolve")

var Lit_169 *jrt.String = jrt.Intern("-main")

var Lit_170 *jrt.String = jrt.Intern("some")

var Lit_171 *jrt.String = jrt.Intern("println")

var Lit_172 *jrt.String = jrt.Intern("repl")

var Lit_173 *jrt.String = jrt.Intern("arbace-version")

var Lit_174 *jrt.String = jrt.Intern("commit")

var Lit_175 *jrt.String = jrt.Intern("*arbace-version*")

var Lit_176 *jrt.String = jrt.Intern("repl-requires")

var Lit_177 *jrt.String = jrt.Intern("load-reader")

var Lit_178 *jrt.String = jrt.Intern("main")

var Lit_179 *jrt.String = jrt.Intern("repl-opt")

var Lit_180 *jrt.String = jrt.Intern("main-opt")

var Lit_181 *jrt.String = jrt.Intern("null-opt")

var Lit_182 *jrt.String = jrt.Intern("help-opt")

var Lit_183 *jrt.String = jrt.Intern("script-opt")

var Lit_184 *jrt.String = jrt.Intern("split-with")

var Lit_185 *jrt.String = jrt.Intern("complement")

var Lit_186 *jrt.String = jrt.Intern("--")

var Lit_187 *jrt.String = jrt.Intern("-r")

var Lit_188 *jrt.String = jrt.Intern("repeat")

var Lit_189 *jrt.String = jrt.Intern("target")

var Lit_190 *jrt.String = jrt.Intern("array-map")

var Lit_191 *jrt.String = jrt.Intern("java.nio.file.attribute.FileAttribute")

var Lit_192 *jrt.String = jrt.Intern("triage")

var Lit_193 *jrt.String = jrt.Intern("main-dispatch")

var Lit_194 *jrt.String = jrt.Intern("--report")

var Lit_195 *jrt.String = jrt.Intern("report-error")

var Lit_196 *jrt.String = jrt.Intern("arbace.main$core_class_QMARK_")

var Lit_197 *jrt.String = jrt.Intern("arbace.lang.")

var Lit_198 *jrt.String = jrt.Intern("arbace.main$demunge")

var Lit_199 *jrt.String = jrt.Intern("arbace.main$err__GT_msg")

var Lit_200 *jrt.String = jrt.Intern("arbace.main$eval461000004$loading__1927001464__auto____461000005")

var Lit_201 *jrt.String = jrt.Intern("java.io.StringReader")

var Lit_202 *jrt.String = jrt.Intern("java.io.BufferedWriter")

var Lit_203 *jrt.String = jrt.Intern("java.io.FileWriter")

var Lit_204 *jrt.String = jrt.Intern("java.nio.file.Files")

var Lit_205 *jrt.String = jrt.Intern("arbace.lang.Compiler")

var Lit_206 *jrt.String = jrt.Intern("arbace.lang.Compiler$CompilerException")

var Lit_207 *jrt.String = jrt.Intern("arbace.lang.LineNumberingPushbackReader")

var Lit_208 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_209 *jrt.String = jrt.Intern("arbace.lang.LispReader$ReaderException")

var Lit_210 *jrt.String = jrt.Intern("arbace.main$eval461000008$fn__461000009")

var Lit_211 *jrt.String = jrt.Intern("arbace.main$eval_opt")

var Lit_212 *jrt.String = jrt.Intern("arbace.main$eval_opt$fn__461000135")

var Lit_213 *jrt.String = jrt.Intern("arbace.main$eval_opt$fn__461000137")

var Lit_214 *jrt.String = jrt.Intern("arbace.main$ex_str")

var Lit_215 *jrt.String = jrt.Intern(":")

var Lit_216 *jrt.String = jrt.Intern("REPL")

var Lit_217 *jrt.String = jrt.Intern("")

var Lit_218 *jrt.String = jrt.Intern(" (")

var Lit_219 *jrt.String = jrt.Intern(")")

var Lit_220 *jrt.String = jrt.Intern("Syntax error macroexpanding %sat (%s).%n%s")

var Lit_221 *jrt.String = jrt.Intern(" ")

var Lit_222 *jrt.String = jrt.Intern("%s%n")

var Lit_223 *jrt.String = jrt.Intern("Syntax error%s compiling %sat (%s).%n%s%n")

var Lit_224 *jrt.String = jrt.Intern("Unexpected error%s macroexpanding %sat (%s).%n%s%n")

var Lit_225 *jrt.String = jrt.Intern("Execution error - invalid arguments to %s at (%s).%n%s")

var Lit_226 *jrt.String = jrt.Intern("Execution error%s at %s(%s).%n%s%n")

var Lit_227 *jrt.String = jrt.Intern("Syntax error reading source at (%s).%n%s%n")

var Lit_228 *jrt.String = jrt.Intern("Error reading eval result%s at %s (%s).%n%s%n")

var Lit_229 *jrt.String = jrt.Intern("Unexpected error%s compiling %sat (%s).%n%s%n")

var Lit_230 *jrt.String = jrt.Intern("Error printing return value%s at %s (%s).%n%s%n")

var Lit_231 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_232 *jrt.String = jrt.Intern("arbace.main$ex_str$fn__461000085")

var Lit_233 *jrt.String = jrt.Intern("arbace.main$ex_str$fn__461000085$fn__461000086")

var Lit_234 *jrt.String = jrt.Intern("arbace.main$ex_str$fn__461000085$fn__461000086$fn__461000087")

var Lit_235 *jrt.String = jrt.Intern("arbace.main$ex_str$fn__461000091")

var Lit_236 *jrt.String = jrt.Intern("arbace.main$ex_str$fn__461000091$fn__461000092")

var Lit_237 *jrt.String = jrt.Intern("arbace.main$ex_str$fn__461000091$fn__461000092$fn__461000093")

var Lit_238 *jrt.String = jrt.Intern("arbace.main$ex_triage")

var Lit_239 *jrt.String = jrt.Intern("arbace.main$ex_triage$fn__461000061")

var Lit_240 *jrt.String = jrt.Intern("arbace.main$ex_triage$fn__461000063")

var Lit_241 *jrt.String = jrt.Intern("arbace.main$file_name")

var Lit_242 *jrt.String = jrt.Intern("arbace.main$file_path")

var Lit_243 *jrt.String = jrt.Intern("/")

var Lit_244 *jrt.String = jrt.Intern("arbace.main$help_opt")

var Lit_245 *jrt.String = jrt.Intern("arbace.main$init_dispatch")

var Lit_246 *jrt.String = jrt.Intern("-i")

var Lit_247 *jrt.String = jrt.Intern("--init")

var Lit_248 *jrt.String = jrt.Intern("-e")

var Lit_249 *jrt.String = jrt.Intern("--eval")

var Lit_250 *jrt.String = jrt.Intern("arbace.main$init_opt")

var Lit_251 *jrt.String = jrt.Intern("arbace.main$initialize")

var Lit_252 *jrt.String = jrt.Intern("arbace.main$java_loc__GT_source")

var Lit_253 *jrt.String = jrt.Intern("$")

var Lit_254 *jrt.String = jrt.Intern("arbace.main$java_loc__GT_source$degen__461000039")

var Lit_255 *jrt.String = jrt.Intern("replaceAll")

var Lit_256 *jrt.String = jrt.Intern("--.*$")

var Lit_257 *jrt.String = jrt.Intern("arbace.main$legacy_repl")

var Lit_258 *jrt.String = jrt.Intern("WARNING: arbace.lang.Repl is deprecated.\nInstead, use arbace.lang.Main like this:\njava -cp arbace.jar arbace.lang.Main -i init.ae -r args...")

var Lit_259 *jrt.String = jrt.Intern("arbace.main$legacy_script")

var Lit_260 *jrt.String = jrt.Intern("WARNING: arbace.lang.Script is deprecated.\nInstead, use arbace.lang.Main like this:\njava -cp arbace.jar arbace.lang.Main -i init.ae script.ae args...")

var Lit_261 *jrt.String = jrt.Intern("arbace.main$load_script")

var Lit_262 *jrt.String = jrt.Intern("ref:")

var Lit_263 *jrt.String = jrt.Intern("@")

var Lit_264 *jrt.String = jrt.Intern("@/")

var Lit_265 *jrt.String = jrt.Intern("arbace.main$main")

var Lit_266 *jrt.String = jrt.Intern("report")

var Lit_267 *jrt.String = jrt.Intern("arbace.main.report")

var Lit_268 *jrt.String = jrt.Intern("arbace.main$main_dispatch")

var Lit_269 *jrt.String = jrt.Intern("--repl")

var Lit_270 *jrt.String = jrt.Intern("-m")

var Lit_271 *jrt.String = jrt.Intern("--main")

var Lit_272 *jrt.String = jrt.Intern("-h")

var Lit_273 *jrt.String = jrt.Intern("--help")

var Lit_274 *jrt.String = jrt.Intern("-?")

var Lit_275 *jrt.String = jrt.Intern("arbace.main$main_opt")

var Lit_276 *jrt.String = jrt.Intern("arbace.compile.path")

var Lit_277 *jrt.String = jrt.Intern("classes")

var Lit_278 *jrt.String = jrt.Intern("arbace.main$null_opt")

var Lit_279 *jrt.String = jrt.Intern("arbace.main$renumbering_read")

var Lit_280 *jrt.String = jrt.Intern("arbace.main$repl")

var Lit_281 *jrt.String = jrt.Intern("getContextClassLoader")

var Lit_282 *jrt.String = jrt.Intern("setContextClassLoader")

var Lit_283 *jrt.String = jrt.Intern("arbace.main$repl$default__461000107__461000116")

var Lit_284 *jrt.String = jrt.Intern("arbace.main$repl$fn__461000118")

var Lit_285 *jrt.String = jrt.Intern("arbace.main$repl$fn__461000120")

var Lit_286 *jrt.String = jrt.Intern("arbace.main$repl$fn__461000128")

var Lit_287 *jrt.String = jrt.Intern("arbace.main$repl$fn__461000130")

var Lit_288 *jrt.String = jrt.Intern("arbace.main$repl$read_eval_print__461000122")

var Lit_289 *jrt.String = jrt.Intern("arbace.main$repl$read_eval_print__461000122$fn__461000123")

var Lit_290 *jrt.String = jrt.Intern("arbace.main$repl$read_eval_print__461000122$fn__461000125")

var Lit_291 *jrt.String = jrt.Intern("arbace.main$repl_caught")

var Lit_292 *jrt.String = jrt.Intern("arbace.main$repl_exception")

var Lit_293 *jrt.String = jrt.Intern("arbace.main$repl_opt")

var Lit_294 *jrt.String = jrt.Intern("Arbace ")

var Lit_295 *jrt.String = jrt.Intern("arbace.main$repl_opt$fn__461000163")

var Lit_296 *jrt.String = jrt.Intern("arbace.main$repl_opt$fn__461000165")

var Lit_297 *jrt.String = jrt.Intern("arbace.main$repl_prompt")

var Lit_298 *jrt.String = jrt.Intern("%s=> ")

var Lit_299 *jrt.String = jrt.Intern("arbace.main$repl_read")

var Lit_300 *jrt.String = jrt.Intern("arbace.main$report_error")

var Lit_301 *jrt.String = jrt.Intern("none")

var Lit_302 *jrt.String = jrt.Intern("Full report at:")

var Lit_303 *jrt.String = jrt.Intern("arbace.main$report_error$fn__461000195")

var Lit_304 *jrt.String = jrt.Intern("arbace.main$report_error$fn__461000195$fn__461000196")

var Lit_305 *jrt.String = jrt.Intern("arbace.main$report_error$fn__461000199")

var Lit_306 *jrt.String = jrt.Intern("arbace-")

var Lit_307 *jrt.String = jrt.Intern(".edn")

var Lit_308 *jrt.String = jrt.Intern("arbace.main$report_error$fn__461000199$fn__461000200")

var Lit_309 *jrt.String = jrt.Intern("arbace.main$root_cause")

var Lit_310 *jrt.String = jrt.Intern("arbace.main$script_opt")

var Lit_311 *jrt.String = jrt.Intern("-")

var Lit_312 *jrt.String = jrt.Intern("arbace.main$skip_if_eol")

var Lit_313 *jrt.String = jrt.Intern("unread")

var Lit_314 *jrt.String = jrt.Intern("arbace.main$skip_whitespace")

var Lit_315 *jrt.String = jrt.Intern("readLine")

var Lit_316 *jrt.String = jrt.Intern("arbace.main$stack_element_str")

var Lit_317 *jrt.String = jrt.Intern(".ae")

var Lit_318 *jrt.String = jrt.Intern(".clj")

var Lit_319 *jrt.String = jrt.Intern(".cljc")

var Lit_320 *jrt.String = jrt.Intern(".")

var Lit_321 *jrt.String = jrt.Intern("arbace.main$with_bindings")

var Lit_322 *jrt.String = jrt.Intern("arbace.main$with_read_known")

var Lit_323 *jrt.String = jrt.Intern("declared")

var Lit_324 *jrt.String = jrt.Intern("arbace/main.ae")

var Lit_325 *jrt.String = jrt.Intern("arglists")

var Lit_326 *jrt.String = jrt.Intern("fn-name")

var Lit_327 *jrt.String = jrt.Intern("Given a string representation of a fn class,\n  as in a stack trace element, returns a readable version.")

var Lit_328 *jrt.String = jrt.Intern("added")

var Lit_329 *jrt.String = jrt.Intern("1.3")

var Lit_330 *jrt.String = jrt.Intern("t")

var Lit_331 *jrt.String = jrt.Intern("tag")

var Lit_332 *jrt.String = jrt.Intern("Throwable")

var Lit_333 *jrt.String = jrt.Intern("Returns the initial cause of an exception or error by peeling off all of\n  its wrappers")

var Lit_334 *jrt.String = jrt.Intern("private")

var Lit_335 *jrt.String = jrt.Intern("class-name")

var Lit_336 *jrt.String = jrt.Intern("String")

var Lit_337 *jrt.String = jrt.Intern("stack-element-str")

var Lit_338 *jrt.String = jrt.Intern("el")

var Lit_339 *jrt.String = jrt.Intern("StackTraceElement")

var Lit_340 *jrt.String = jrt.Intern("Returns a (possibly unmunged) string representation of a StackTraceElement")

var Lit_341 *jrt.String = jrt.Intern("&")

var Lit_342 *jrt.String = jrt.Intern("Executes body in the context of thread-local bindings for several vars\n  that often need to be set!: *ns* *warn-on-reflection* *math-context*\n  *print-meta* *print-length* *print-level* *compile-path*\n  *command-line-args* *1 *2 *3 *e")

var Lit_343 *jrt.String = jrt.Intern("Default :prompt hook for repl")

var Lit_344 *jrt.String = jrt.Intern("s")

var Lit_345 *jrt.String = jrt.Intern("If the next character on stream s is a newline, skips it, otherwise\n  leaves the stream untouched. Returns :line-start, :stream-end, or :body\n  to indicate the relative location of the next character on s. The stream\n  must either be an instance of LineNumberingPushbackReader or duplicate\n  its behavior of both supporting .unread and collapsing all of CR, LF, and\n  CRLF to a single \\newline.")

var Lit_346 *jrt.String = jrt.Intern("Skips whitespace characters on stream s. Returns :line-start, :stream-end,\n  or :body to indicate the relative location of the next character on s.\n  Interprets comma as whitespace and semicolon as comment to end of line.\n  Does not interpret #! as comment to end of line because only one\n  character of lookahead is available. The stream must either be an\n  instance of LineNumberingPushbackReader or duplicate its behavior of both\n  supporting .unread and collapsing all of CR, LF, and CRLF to a single\n  \\newline.")

var Lit_347 *jrt.String = jrt.Intern("opts")

var Lit_348 *jrt.String = jrt.Intern("reader")

var Lit_349 *jrt.String = jrt.Intern("LineNumberingPushbackReader")

var Lit_350 *jrt.String = jrt.Intern("line-number")

var Lit_351 *jrt.String = jrt.Intern("Reads from reader, which must be a LineNumberingPushbackReader, while capturing\n  the read string. If the read is successful, reset the line number and re-read.\n  The line number on re-read is the passed line-number unless :line or\n  :arbace.core/eval-file meta are explicitly set on the read value.")

var Lit_352 *jrt.String = jrt.Intern("1.10")

var Lit_353 *jrt.String = jrt.Intern("request-prompt")

var Lit_354 *jrt.String = jrt.Intern("request-exit")

var Lit_355 *jrt.String = jrt.Intern("Default :read hook for repl. Reads from *in* which must either be an\n  instance of LineNumberingPushbackReader or duplicate its behavior of both\n  supporting .unread and collapsing all of CR, LF, and CRLF into a single\n  \\newline. repl-read:\n    - skips whitespace, then\n      - returns request-prompt on start of line, or\n      - returns request-exit on end of stream, or\n      - reads an object from the input stream, then\n        - skips the next input character if it's end of line, then\n        - returns the object.")

var Lit_356 *jrt.String = jrt.Intern("repl-exception")

var Lit_357 *jrt.String = jrt.Intern("throwable")

var Lit_358 *jrt.String = jrt.Intern("Returns the root cause of throwables")

var Lit_359 *jrt.String = jrt.Intern("full-path")

var Lit_360 *jrt.String = jrt.Intern("Helper to get just the file name part of a path or nil")

var Lit_361 *jrt.String = jrt.Intern("Helper to get the relative path to the source file or nil")

var Lit_362 *jrt.String = jrt.Intern("clazz")

var Lit_363 *jrt.String = jrt.Intern("method")

var Lit_364 *jrt.String = jrt.Intern("Convert Java class name and method symbol to source symbol, either a\n  Clojure function or Java class and method.")

var Lit_365 *jrt.String = jrt.Intern("datafied-throwable")

var Lit_366 *jrt.String = jrt.Intern("Returns an analysis of the phase, error, cause, and location of an error that occurred\n  based on Throwable data, as returned by Throwable->map. All attributes other than phase\n  are optional:\n    :arbace.error/phase - keyword phase indicator, one of:\n      :read-source :compile-syntax-check :compilation :macro-syntax-check :macroexpansion\n      :execution :read-eval-result :print-eval-result\n    :arbace.error/source - file name (no path)\n    :arbace.error/path - source path\n    :arbace.error/line - integer line number\n    :arbace.error/column - integer column number\n    :arbace.error/symbol - symbol being expanded/compiled/invoked\n    :arbace.error/class - cause exception class symbol\n    :arbace.error/cause - cause exception message\n    :arbace.error/spec - explain-data for spec error")

var Lit_367 *jrt.String = jrt.Intern("keys")

var Lit_368 *jrt.String = jrt.Intern("triage-data")

var Lit_369 *jrt.String = jrt.Intern("Returns a string from exception data, as produced by ex-triage.\n  The first line summarizes the exception phase and location.\n  The subsequent lines describe the cause.")

var Lit_370 *jrt.String = jrt.Intern("e")

var Lit_371 *jrt.String = jrt.Intern("Helper to return an error message string from an exception.")

var Lit_372 *jrt.String = jrt.Intern("Default :caught hook for repl")

var Lit_373 *jrt.String = jrt.Intern("arbace.repl")

var Lit_374 *jrt.String = jrt.Intern("apropos")

var Lit_375 *jrt.String = jrt.Intern("dir")

var Lit_376 *jrt.String = jrt.Intern("pst")

var Lit_377 *jrt.String = jrt.Intern("find-doc")

var Lit_378 *jrt.String = jrt.Intern("A sequence of lib specs that are applied to `require`\nby default when a new command-line REPL is started.")

var Lit_379 *jrt.String = jrt.Intern("with-read-known")

var Lit_380 *jrt.String = jrt.Intern("Evaluates body with *read-eval* set to a \"known\" value,\n   i.e. substituting true for :unknown if necessary.")

var Lit_381 *jrt.String = jrt.Intern("options")

var Lit_382 *jrt.String = jrt.Intern("Generic, reusable, read-eval-print loop. By default, reads from *in*,\n  writes to *out*, and prints exception summaries to *err*. If you use the\n  default :read hook, *in* must either be an instance of\n  LineNumberingPushbackReader or duplicate its behavior of both supporting\n  .unread and collapsing CR, LF, and CRLF into a single \\newline. Options\n  are sequential keyword-value pairs. Available options and their defaults:\n\n     - :init, function of no arguments, initialization hook called with\n       bindings for set!-able vars in place.\n       default: #()\n\n     - :need-prompt, function of no arguments, called before each\n       read-eval-print except the first, the user will be prompted if it\n       returns true.\n       default: (if (instance? LineNumberingPushbackReader *in*)\n                  #(.atLineStart *in*)\n                  #(identity true))\n\n     - :prompt, function of no arguments, prompts for more input.\n       default: repl-prompt\n\n     - :flush, function of no arguments, flushes output\n       default: flush\n\n     - :read, function of two arguments, reads from *in*:\n         - returns its first argument to request a fresh prompt\n           - depending on need-prompt, this may cause the repl to prompt\n             before reading again\n         - returns its second argument to request an exit from the repl\n         - else returns the next object read from the input stream\n       default: repl-read\n\n     - :eval, function of one argument, returns the evaluation of its\n       argument\n       default: eval\n\n     - :print, function of one argument, prints its argument to the output\n       default: prn\n\n     - :caught, function of one argument, a throwable, called when\n       read, eval, or print throws an exception or error\n       default: repl-caught")

var Lit_383 *jrt.String = jrt.Intern("Loads Clojure source from a file or resource given its path. Paths\n  beginning with @ or @/ are considered relative to classpath; a path\n  ref:NAME is the source the store's ref NAME holds (arbace.box/load-ref).")

var Lit_384 *jrt.String = jrt.Intern("Load a script")

var Lit_385 *jrt.String = jrt.Intern("Evals expressions in str, prints each non-nil result using prn")

var Lit_386 *jrt.String = jrt.Intern("opt")

var Lit_387 *jrt.String = jrt.Intern("Returns the handler associated with an init opt")

var Lit_388 *jrt.String = jrt.Intern("args")

var Lit_389 *jrt.String = jrt.Intern("inits")

var Lit_390 *jrt.String = jrt.Intern("Common initialize routine for repl, script, and null opts")

var Lit_391 *jrt.String = jrt.Intern("_")

var Lit_392 *jrt.String = jrt.Intern("main-ns")

var Lit_393 *jrt.String = jrt.Intern("Call the -main function from a namespace with string arguments from\n  the command line.")

var Lit_394 *jrt.String = jrt.Intern("Start a repl with args and inits. Print greeting if no eval options were\n  present")

var Lit_395 *jrt.String = jrt.Intern("Run a script from a file, resource, or standard in with args and inits")

var Lit_396 *jrt.String = jrt.Intern("No repl or script opt present, just bind args and run inits")

var Lit_397 *jrt.String = jrt.Intern("Print help text for main")

var Lit_398 *jrt.String = jrt.Intern("Returns the handler associated with a main option")

var Lit_399 *jrt.String = jrt.Intern("legacy-repl")

var Lit_400 *jrt.String = jrt.Intern("Called by the arbace.lang.Repl.main stub to run a repl with args\n  specified the old way")

var Lit_401 *jrt.String = jrt.Intern("legacy-script")

var Lit_402 *jrt.String = jrt.Intern("Called by the arbace.lang.Script.main stub to run a script with args\n  specified the old way")

var Lit_403 *jrt.String = jrt.Intern("or")

var Lit_404 *jrt.String = jrt.Intern("Create and output an exception report for a Throwable to target.\n\n  Options:\n    :target - \"file\" (default), \"stderr\", \"none\"\n\n  If file is specified but cannot be written, falls back to stderr.")

var Lit_405 *jrt.String = jrt.Intern("Usage: java -cp arbace.jar arbace.lang.Main [init-opt*] [main-opt] [arg*]\n\n  With no options or args, runs an interactive Read-Eval-Print Loop\n\n  init options:\n    -i, --init path     Load a file or resource\n    -e, --eval string   Evaluate expressions in string; print non-nil values\n    --report target     Report uncaught exception to \"file\" (default), \"stderr\",\n                        or \"none\", overrides System property arbace.main.report\n\n  main options:\n    -m, --main ns-name  Call the -main function from a namespace with args\n    -r, --repl          Run a repl\n    path                Run a script from a file or resource\n    -                   Run a script from standard input\n    -h, -?, --help      Print this help message and exit\n\n  operation:\n\n    - Establishes thread-local bindings for commonly set!-able vars\n    - Enters the user namespace\n    - Binds *command-line-args* to a seq of strings containing command line\n      args that appear after any main option\n    - Runs all init options in order\n    - Calls a -main function or runs a repl or script if requested\n\n  The init options may be repeated and mixed freely, but must appear before\n  any main option. The appearance of any eval option before running a repl\n  suppresses the usual repl greeting message: \"Arbace ~(arbace-version) (~short-commit)\".\n\n  Paths may be absolute or relative in the filesystem or relative to\n  classpath. Classpath-relative paths have prefix of @ or @/")
