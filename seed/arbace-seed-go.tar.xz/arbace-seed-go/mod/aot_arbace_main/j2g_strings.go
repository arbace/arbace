//line j2g_strings.ae:1
package aot_arbace_main

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn7,excludeyn13,with-bindingsyn17,arbace.spec.alphakn2,asyn4,speckn3,dockn6,authorys11,arbace.core7,bindingys11,arbace.core4,*ns*ys11,arbace.core20,*warn-on-reflection*ys11,arbace.core14,*math-context*ys11,arbace.core12,*print-meta*ys11,arbace.core14,*print-length*ys11,arbace.core13,*print-level*ys11,arbace.core22,*print-namespace-maps*ys11,arbace.core14,*data-readers*ys11,arbace.core24,*default-data-reader-fn*ys11,arbace.core14,*compile-path*ys16,java.lang.System11,getPropertyys11,arbace.core19,*command-line-args*ys11,arbace.core16,*unchecked-math*ys11,arbace.core8,*assert*ys17,arbace.spec.alpha13,*explain-out*ys11,arbace.core2,*1ys11,arbace.core2,*2ys11,arbace.core2,*3ys11,arbace.core2,*ekn10,line-startkn10,stream-endkn4,elsekn4,bodyks11,arbace.core9,eval-filekn4,linekn9,read-condkn5,allowyn12,invokeStaticyn6,invokekn9,executionkn3,viakn5,tracekn5,phasekn4,typekn7,messagekn4,dataks17,arbace.spec.alpha8,problemsks17,arbace.spec.alpha2,fnks22,arbace.spec.test.alpha6,callerks12,arbace.error6,sourcekn18,macro-syntax-checkkn20,compile-syntax-checkkn14,macroexpansionks12,arbace.error5,classks12,arbace.error5,phaseks12,arbace.error4,pathks12,arbace.error5,causeks12,arbace.error4,speckn11,read-sourceks12,arbace.error4,lineks12,arbace.error6,columnkn4,fileks12,arbace.error6,symbolkn16,read-eval-resultkn11,compilationkn17,print-eval-resultkn2,inys11,arbace.core11,*read-eval*yn2,ifys11,arbace.core1,=kn7,unknownkn4,initkn11,need-promptkn6,promptkn5,flushkn4,readkn4,evalkn5,printkn6,caughtys10,arbace.box8,load-refyn4,useryn5,-mainkn6,commitkn6,targetks11,arbace.main7,messageks11,arbace.main6,triageks11,arbace.main5,tracekn8,main-optv11,arbace.core5,referv11,arbace.core7,requireR0,R1,V1,R2,V3,R3,R4,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn11,arbace.mainm4,R6,s53,Top-level main function for Clojure REPL and scripts.R7,s34,Stephen C. Gilardi and Rich Hickeyv11,arbace.core13,*loaded-libs*v11,arbace.core4,not=v11,arbace.core3,notv11,arbace.core9,contains?v11,arbace.main15,core-namespacesv11,arbace.core6,secondv11,arbace.core7,re-findp10,^([^$]+)\\$v11,arbace.main7,demungev11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listR8,v11,arbace.core5,applyv11,arbace.core6,vectorR9,R9,R10,R10,R11,R11,R12,R12,R13,R13,R14,R14,R15,R16,R16,R17,R17,R18,R19,R20,R20,R21,R21,R22,R22,R23,R23,R24,R25,R26,R27,v11,arbace.core6,printfv11,arbace.core7,ns-namev11,arbace.core4,*ns*c10,R28,R29,R30,R31,c59,c44,v11,arbace.core11,read+stringv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core5,firstR32,R33,v11,arbace.core4,readv11,arbace.main16,renumbering-readv11,arbace.main15,skip-whitespacev11,arbace.core4,*in*m2,R34,R35,l1,v11,arbace.main11,skip-if-eolv11,arbace.main10,root-causev11,arbace.core4,subsS2,R36,R37,C16,java.lang.Stringv11,arbace.core3,mapv11,arbace.core6,symbolp2,\\$v11,arbace.core3,strv11,arbace.core10,into-arrayv11,arbace.core4,consv11,arbace.core4,nameR38,R39,R40,R41,v11,arbace.core4,lastR42,R43,R44,R45,R46,R47,R48,v11,arbace.core5,assocR49,S2,s14,NO_SOURCE_PATHs14,NO_SOURCE_FILEv11,arbace.core6,dissocR50,S2,s14,NO_SOURCE_PATHs14,NO_SOURCE_FILER51,S2,s14,NO_SOURCE_PATHs14,NO_SOURCE_FILER52,R53,v11,arbace.main9,file-nameR54,v11,arbace.main9,file-pathR55,R56,R57,R58,R59,v11,arbace.core5,mergeS2,s14,NO_SOURCE_PATHs14,NO_SOURCE_FILEv11,arbace.core10,drop-whilev11,arbace.main11,core-class?v11,arbace.core6,removeS2,s14,NO_SOURCE_PATHs14,NO_SOURCE_FILER60,R61,v11,arbace.main16,java-loc->sourceR62,R63,S2,s14,NO_SOURCE_PATHs14,NO_SOURCE_FILER64,v11,arbace.core6,formatp9,([^.])++$S2,s16,RuntimeExceptions9,Exceptionv11,arbace.core19,pop-thread-bindingsv17,arbace.spec.alpha11,explain-outv17,arbace.spec.alpha13,*explain-out*v17,arbace.spec.alpha15,explain-printerv11,arbace.core6,updateR65,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.main6,ex-strv11,arbace.main9,ex-triagev11,arbace.core14,Throwable->mapv11,arbace.core5,flushv11,arbace.core5,*err*v11,arbace.core5,printv11,arbace.main8,err->msgR8,R66,R67,R68,R69,R66,R66,v11,arbace.core8,identityv11,arbace.main11,repl-promptv11,arbace.main9,repl-readv11,arbace.core4,evalv11,arbace.core3,prnv11,arbace.main11,repl-caughtR70,R71,R72,R73,R74,R75,R76,R77,v11,arbace.core11,*read-eval*v11,arbace.core7,ex-infom2,R53,R57,v11,arbace.core2,*3v11,arbace.core2,*2v11,arbace.core2,*1m2,R53,R64,v11,arbace.core2,*eC16,java.lang.Threadv11,arbace.core20,*warn-on-reflection*v11,arbace.core14,*math-context*v11,arbace.core12,*print-meta*v11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v11,arbace.core22,*print-namespace-maps*v11,arbace.core14,*data-readers*v11,arbace.core24,*default-data-reader-fn*v11,arbace.core14,*compile-path*v11,arbace.core19,*command-line-args*v11,arbace.core16,*unchecked-math*v11,arbace.core8,*assert*v11,arbace.core6,*repl*v11,arbace.core17,requiring-resolveR78,v11,arbace.main11,load-scriptv11,arbace.main8,init-optv11,arbace.main8,eval-optv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,in-nsR79,v11,arbace.main13,init-dispatchv11,arbace.core10,chunk-restv11,arbace.main10,initializev11,arbace.core10,ns-resolveR80,v11,arbace.core4,somev11,arbace.core7,printlnv11,arbace.main4,replv11,arbace.core14,arbace-versionR81,v11,arbace.core16,*arbace-version*l0,v11,arbace.main13,repl-requiresv11,arbace.core11,load-readerR6,v11,arbace.main4,mainv11,arbace.main8,repl-optv11,arbace.main8,main-optv11,arbace.main8,null-optv11,arbace.main8,help-optv11,arbace.main10,script-optv11,arbace.core10,split-withv11,arbace.core10,complementS1,s2,--V1,s2,-rv11,arbace.core6,repeatS1,s2,--R82,v11,arbace.core9,array-mapC37,java.nio.file.attribute.FileAttributeR83,R84,R85,R86,v11,arbace.main13,main-dispatchS1,s8,--reportl2,v11,arbace.main12,report-error")

var Lit_1 *jrt.String = jrt.Intern("arbace.lang.")

var Lit_2 *jrt.String = jrt.Intern("java.io.StringReader")

var Lit_3 *jrt.String = jrt.Intern("java.io.BufferedWriter")

var Lit_4 *jrt.String = jrt.Intern("java.io.FileWriter")

var Lit_5 *jrt.String = jrt.Intern("java.nio.file.Files")

var Lit_6 *jrt.String = jrt.Intern("java.nio.file.attribute.FileAttribute")

var Lit_7 *jrt.String = jrt.Intern("arbace.lang.Compiler")

var Lit_8 *jrt.String = jrt.Intern("arbace.lang.Compiler$CompilerException")

var Lit_9 *jrt.String = jrt.Intern("arbace.lang.LineNumberingPushbackReader")

var Lit_10 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_11 *jrt.String = jrt.Intern("arbace.lang.LispReader$ReaderException")

var Lit_12 *jrt.String = jrt.Intern("arbace.main$eval_opt$fn__461000135")

var Lit_13 *jrt.String = jrt.Intern("arbace.main$eval_opt$fn__461000137")

var Lit_14 *jrt.String = jrt.Intern(":")

var Lit_15 *jrt.String = jrt.Intern("REPL")

var Lit_16 *jrt.String = jrt.Intern("")

var Lit_17 *jrt.String = jrt.Intern(" (")

var Lit_18 *jrt.String = jrt.Intern(")")

var Lit_19 *jrt.String = jrt.Intern("Syntax error macroexpanding %sat (%s).%n%s")

var Lit_20 *jrt.String = jrt.Intern(" ")

var Lit_21 *jrt.String = jrt.Intern("arbace.main$ex_str$fn__461000085")

var Lit_22 *jrt.String = jrt.Intern("%s%n")

var Lit_23 *jrt.String = jrt.Intern("Syntax error%s compiling %sat (%s).%n%s%n")

var Lit_24 *jrt.String = jrt.Intern("Unexpected error%s macroexpanding %sat (%s).%n%s%n")

var Lit_25 *jrt.String = jrt.Intern("Execution error - invalid arguments to %s at (%s).%n%s")

var Lit_26 *jrt.String = jrt.Intern("arbace.main$ex_str$fn__461000091")

var Lit_27 *jrt.String = jrt.Intern("Execution error%s at %s(%s).%n%s%n")

var Lit_28 *jrt.String = jrt.Intern("Syntax error reading source at (%s).%n%s%n")

var Lit_29 *jrt.String = jrt.Intern("Error reading eval result%s at %s (%s).%n%s%n")

var Lit_30 *jrt.String = jrt.Intern("Unexpected error%s compiling %sat (%s).%n%s%n")

var Lit_31 *jrt.String = jrt.Intern("Error printing return value%s at %s (%s).%n%s%n")

var Lit_32 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_33 *jrt.String = jrt.Intern("arbace.main$ex_str$fn__461000085$fn__461000086")

var Lit_34 *jrt.String = jrt.Intern("arbace.main$ex_str$fn__461000085$fn__461000086$fn__461000087")

var Lit_35 *jrt.String = jrt.Intern("arbace.main$ex_str$fn__461000091$fn__461000092")

var Lit_36 *jrt.String = jrt.Intern("arbace.main$ex_str$fn__461000091$fn__461000092$fn__461000093")

var Lit_37 *jrt.String = jrt.Intern("arbace.main$ex_triage$fn__461000061")

var Lit_38 *jrt.String = jrt.Intern("arbace.main$ex_triage$fn__461000063")

var Lit_39 *jrt.String = jrt.Intern("/")

var Lit_40 *jrt.String = jrt.Intern("-i")

var Lit_41 *jrt.String = jrt.Intern("--init")

var Lit_42 *jrt.String = jrt.Intern("-e")

var Lit_43 *jrt.String = jrt.Intern("--eval")

var Lit_44 *jrt.String = jrt.Intern("arbace.main$java_loc__GT_source$degen__461000039")

var Lit_45 *jrt.String = jrt.Intern("$")

var Lit_46 *jrt.String = jrt.Intern("replaceAll")

var Lit_47 *jrt.String = jrt.Intern("--.*$")

var Lit_48 *jrt.String = jrt.Intern("WARNING: arbace.lang.Repl is deprecated.\nInstead, use arbace.lang.Main like this:\njava -cp arbace.jar arbace.lang.Main -i init.ae -r args...")

var Lit_49 *jrt.String = jrt.Intern("WARNING: arbace.lang.Script is deprecated.\nInstead, use arbace.lang.Main like this:\njava -cp arbace.jar arbace.lang.Main -i init.ae script.ae args...")

var Lit_50 *jrt.String = jrt.Intern("ref:")

var Lit_51 *jrt.String = jrt.Intern("@")

var Lit_52 *jrt.String = jrt.Intern("@/")

var Lit_53 *jrt.String = jrt.Intern("report")

var Lit_54 *jrt.String = jrt.Intern("arbace.main.report")

var Lit_55 *jrt.String = jrt.Intern("file")

var Lit_56 *jrt.String = jrt.Intern("-r")

var Lit_57 *jrt.String = jrt.Intern("--repl")

var Lit_58 *jrt.String = jrt.Intern("-m")

var Lit_59 *jrt.String = jrt.Intern("--main")

var Lit_60 *jrt.String = jrt.Intern("-h")

var Lit_61 *jrt.String = jrt.Intern("--help")

var Lit_62 *jrt.String = jrt.Intern("-?")

var Lit_63 *jrt.String = jrt.Intern("arbace.compile.path")

var Lit_64 *jrt.String = jrt.Intern("classes")

var Lit_65 *jrt.String = jrt.Intern("getContextClassLoader")

var Lit_66 *jrt.String = jrt.Intern("setContextClassLoader")

var Lit_67 *jrt.String = jrt.Intern("arbace.main$repl$default__461000107__461000116")

var Lit_68 *jrt.String = jrt.Intern("arbace.main$repl$fn__461000118")

var Lit_69 *jrt.String = jrt.Intern("arbace.main$repl$fn__461000120")

var Lit_70 *jrt.String = jrt.Intern("arbace.main$repl$read_eval_print__461000122")

var Lit_71 *jrt.String = jrt.Intern("arbace.main$repl$fn__461000128")

var Lit_72 *jrt.String = jrt.Intern("arbace.main$repl$fn__461000130")

var Lit_73 *jrt.String = jrt.Intern("arbace.main$repl$read_eval_print__461000122$fn__461000123")

var Lit_74 *jrt.String = jrt.Intern("arbace.main$repl$read_eval_print__461000122$fn__461000125")

var Lit_75 *jrt.String = jrt.Intern("arbace.main$repl_opt$fn__461000163")

var Lit_76 *jrt.String = jrt.Intern("Arbace ")

var Lit_77 *jrt.String = jrt.Intern("arbace.main$repl_opt$fn__461000165")

var Lit_78 *jrt.String = jrt.Intern("%s=> ")

var Lit_79 *jrt.String = jrt.Intern("none")

var Lit_80 *jrt.String = jrt.Intern("arbace.main$report_error$fn__461000195")

var Lit_81 *jrt.String = jrt.Intern("arbace.main$report_error$fn__461000199")

var Lit_82 *jrt.String = jrt.Intern("Full report at:")

var Lit_83 *jrt.String = jrt.Intern("arbace.main$report_error$fn__461000195$fn__461000196")

var Lit_84 *jrt.String = jrt.Intern("arbace-")

var Lit_85 *jrt.String = jrt.Intern(".edn")

var Lit_86 *jrt.String = jrt.Intern("arbace.main$report_error$fn__461000199$fn__461000200")

var Lit_87 *jrt.String = jrt.Intern("NO_SOURCE_FILE")

var Lit_88 *jrt.String = jrt.Intern("-")

var Lit_89 *jrt.String = jrt.Intern("read")

var Lit_90 *jrt.String = jrt.Intern("unread")

var Lit_91 *jrt.String = jrt.Intern("readLine")

var Lit_92 *jrt.String = jrt.Intern(".ae")

var Lit_93 *jrt.String = jrt.Intern(".clj")

var Lit_94 *jrt.String = jrt.Intern(".cljc")

var Lit_95 *jrt.String = jrt.Intern(".")

var Lit_96 *jrt.String = jrt.Intern("kn3,dockn6,authoryn11,arbace.corekn8,declaredkn4,linekn6,columnkn4,filekn8,arglistsyn7,fn-namekn5,addedkn3,tagyn9,Throwablekn7,privateyn6,Stringyn17,StackTraceElementyn1,&yn4,bodyyn1,syn4,optsyn27,LineNumberingPushbackReaderyn11,line-numberyn14,request-promptyn12,request-exityn9,throwableyn5,clazzyn6,methodyn18,datafied-throwableks12,arbace.error4,keysyn5,phaseyn6,sourceyn4,pathyn4,lineyn6,columnyn6,symbolyn5,classyn5,causeyn4,speckn2,asyn11,triage-datayn1,eyn11,arbace.replkn5,referyn7,aproposyn3,diryn3,pstyn3,docyn8,find-docyn7,optionsyn3,stryn3,optyn4,argsyn5,initsyn1,_yn7,main-nskn4,keysyn6,targetkn2,orv11,arbace.core5,in-nsMyn11,arbace.mainm4,R0,s53,Top-level main function for Clojure REPL and scripts.R1,s34,Stephen C. Gilardi and Rich Hickeym4,R0,s53,Top-level main function for Clojure REPL and scripts.R1,s34,Stephen C. Gilardi and Rich HickeyR2,v11,arbace.main4,mainm8,R3,TR4,i24,R5,i1,R6,s14,arbace/main.aev11,arbace.main7,demungem12,R7,L1,V1,R8,R0,s103,Given a string representation of a fn class,\n  as in a stack trace element, returns a readable version.R9,s3,1.3R4,i28,R5,i1,R6,s14,arbace/main.aev11,arbace.main10,root-causem12,R7,L1,V1,Myn1,tm2,R10,R11,R0,s87,Returns the initial cause of an exception or error by peeling off all of\n  its wrappersR9,s3,1.3R4,i35,R5,i1,R6,s14,arbace/main.aev11,arbace.main15,core-namespacesS22,s11,arbace.mains10,arbace.xmls20,arbace.core.reducerss14,arbace.java.ios13,arbace.datafys22,arbace.spec.test.alphas11,arbace.datas10,arbace.edns11,arbace.walks14,arbace.instants13,arbace.pprints11,arbace.uuids11,arbace.cores10,arbace.zips17,arbace.spec.alphas21,arbace.spec.gen.alphas15,arbace.templates14,arbace.reflects11,arbace.repls10,arbace.sets13,arbace.strings21,arbace.core.protocolsm8,R12,TR4,i50,R5,i1,R6,s14,arbace/main.aev11,arbace.main11,core-class?m10,R12,TR7,L1,V1,Myn10,class-namem2,R10,R13,R4,i56,R5,i1,R6,s14,arbace/main.aev11,arbace.main17,stack-element-strm12,R7,L1,V1,Myn2,elm2,R10,R14,R0,s74,Returns a (possibly unmunged) string representation of a StackTraceElementR9,s3,1.3R4,i62,R5,i1,R6,s14,arbace/main.aev11,arbace.main13,with-bindingsm10,R7,L1,V2,R15,R16,R0,s234,Executes body in the context of thread-local bindings for several vars\n  that often need to be set!: *ns* *warn-on-reflection* *math-context*\n  *print-meta* *print-length* *print-level* *compile-path*\n  *command-line-args* *1 *2 *3 *eR4,i77,R5,i1,R6,s14,arbace/main.aev11,arbace.main11,repl-promptm10,R7,L1,V0,R0,s29,Default :prompt hook for replR4,i103,R5,i1,R6,s14,arbace/main.aev11,arbace.main11,skip-if-eolm10,R7,L1,V1,R17,R0,s394,If the next character on stream s is a newline, skips it, otherwise\n  leaves the stream untouched. Returns :line-start, :stream-end, or :body\n  to indicate the relative location of the next character on s. The stream\n  must either be an instance of LineNumberingPushbackReader or duplicate\n  its behavior of both supporting .unread and collapsing all of CR, LF, and\n  CRLF to a single \\newline.R4,i108,R5,i1,R6,s14,arbace/main.aev11,arbace.main15,skip-whitespacem10,R7,L1,V1,R17,R0,s516,Skips whitespace characters on stream s. Returns :line-start, :stream-end,\n  or :body to indicate the relative location of the next character on s.\n  Interprets comma as whitespace and semicolon as comment to end of line.\n  Does not interpret #! as comment to end of line because only one\n  character of lookahead is available. The stream must either be an\n  instance of LineNumberingPushbackReader or duplicate its behavior of both\n  supporting .unread and collapsing all of CR, LF, and CRLF to a single\n  \\newline.R4,i122,R5,i1,R6,s14,arbace/main.aev11,arbace.main16,renumbering-readm12,R7,L1,V3,R18,Myn6,readerm2,R10,R19,R20,R0,s299,Reads from reader, which must be a LineNumberingPushbackReader, while capturing\n  the read string. If the read is successful, reset the line number and re-read.\n  The line number on re-read is the passed line-number unless :line or\n  :arbace.core/eval-file meta are explicitly set on the read value.R9,s4,1.10R4,i140,R5,i1,R6,s14,arbace/main.aev11,arbace.main9,repl-readm10,R7,L1,V2,R21,R22,R0,s521,Default :read hook for repl. Reads from *in* which must either be an\n  instance of LineNumberingPushbackReader or duplicate its behavior of both\n  supporting .unread and collapsing all of CR, LF, and CRLF into a single\n  \\newline. repl-read:\n    - skips whitespace, then\n      - returns request-prompt on start of line, or\n      - returns request-exit on end of stream, or\n      - reads an object from the input stream, then\n        - skips the next input character if it's end of line, then\n        - returns the object.R4,i154,R5,i1,R6,s14,arbace/main.aev11,arbace.main14,repl-exceptionm10,R7,L1,V1,R23,R0,s36,Returns the root cause of throwablesR4,i172,R5,i1,R6,s14,arbace/main.aev11,arbace.main9,file-namem12,R12,TR7,L1,V1,Myn9,full-pathm2,R10,R13,R0,s54,Helper to get just the file name part of a path or nilR4,i177,R5,i1,R6,s14,arbace/main.aev11,arbace.main9,file-pathm12,R12,TR7,L1,V1,Myn9,full-pathm2,R10,R13,R0,s57,Helper to get the relative path to the source file or nilR4,i185,R5,i1,R6,s14,arbace/main.aev11,arbace.main16,java-loc->sourcem12,R12,TR7,L1,V2,R24,R25,R0,s113,Convert Java class name and method symbol to source symbol, either a\n  Clojure function or Java class and method.R4,i198,R5,i1,R6,s14,arbace/main.aev11,arbace.main9,ex-triagem12,R7,L1,V1,R26,R0,s797,Returns an analysis of the phase, error, cause, and location of an error that occurred\n  based on Throwable data, as returned by Throwable->map. All attributes other than phase\n  are optional:\n    :arbace.error/phase - keyword phase indicator, one of:\n      :read-source :compile-syntax-check :compilation :macro-syntax-check :macroexpansion\n      :execution :read-eval-result :print-eval-result\n    :arbace.error/source - file name (no path)\n    :arbace.error/path - source path\n    :arbace.error/line - integer line number\n    :arbace.error/column - integer column number\n    :arbace.error/symbol - symbol being expanded/compiled/invoked\n    :arbace.error/class - cause exception class symbol\n    :arbace.error/cause - cause exception message\n    :arbace.error/spec - explain-data for spec errorR9,s4,1.10R4,i208,R5,i1,R6,s14,arbace/main.aev11,arbace.main6,ex-strm12,R7,L1,V1,m4,R27,V9,R28,R29,R30,R31,R32,R33,R34,R35,R36,R37,R38,R0,s168,Returns a string from exception data, as produced by ex-triage.\n  The first line summarizes the exception phase and location.\n  The subsequent lines describe the cause.R9,s4,1.10R4,i269,R5,i1,R6,s14,arbace/main.aev11,arbace.main8,err->msgm10,R7,L1,V1,Myn1,em2,R10,R11,R0,s59,Helper to return an error message string from an exception.R4,i343,R5,i1,R6,s14,arbace/main.aev11,arbace.main11,repl-caughtm10,R7,L1,V1,R39,R0,s29,Default :caught hook for replR4,i348,R5,i1,R6,s14,arbace/main.aev11,arbace.main13,repl-requiresV1,V3,R40,R41,ML6,R29,R42,R43,R44,R45,R46,m4,R4,i357,R5,i25,m8,R0,s105,A sequence of lib specs that are applied to `require`\nby default when a new command-line REPL is started.R4,i355,R5,i1,R6,s14,arbace/main.aev11,arbace.main15,with-read-knownm10,R7,L1,V2,R15,R16,R0,s108,Evaluates body with *read-eval* set to a \"known\" value,\n   i.e. substituting true for :unknown if necessary.R4,i359,R5,i1,R6,s14,arbace/main.aev11,arbace.main4,replm10,R7,L1,V2,R15,R47,R0,s1791,Generic, reusable, read-eval-print loop. By default, reads from *in*,\n  writes to *out*, and prints exception summaries to *err*. If you use the\n  default :read hook, *in* must either be an instance of\n  LineNumberingPushbackReader or duplicate its behavior of both supporting\n  .unread and collapsing CR, LF, and CRLF into a single \\newline. Options\n  are sequential keyword-value pairs. Available options and their defaults:\n\n     - :init, function of no arguments, initialization hook called with\n       bindings for set!-able vars in place.\n       default: #()\n\n     - :need-prompt, function of no arguments, called before each\n       read-eval-print except the first, the user will be prompted if it\n       returns true.\n       default: (if (instance? LineNumberingPushbackReader *in*)\n                  #(.atLineStart *in*)\n                  #(identity true))\n\n     - :prompt, function of no arguments, prompts for more input.\n       default: repl-prompt\n\n     - :flush, function of no arguments, flushes output\n       default: flush\n\n     - :read, function of two arguments, reads from *in*:\n         - returns its first argument to request a fresh prompt\n           - depending on need-prompt, this may cause the repl to prompt\n             before reading again\n         - returns its second argument to request an exit from the repl\n         - else returns the next object read from the input stream\n       default: repl-read\n\n     - :eval, function of one argument, returns the evaluation of its\n       argument\n       default: eval\n\n     - :print, function of one argument, prints its argument to the output\n       default: prn\n\n     - :caught, function of one argument, a throwable, called when\n       read, eval, or print throws an exception or error\n       default: repl-caughtR4,i366,R5,i1,R6,s14,arbace/main.aev11,arbace.main11,load-scriptm10,R7,L1,V1,Myn4,pathm2,R10,R13,R0,s211,Loads Clojure source from a file or resource given its path. Paths\n  beginning with @ or @/ are considered relative to classpath; a path\n  ref:NAME is the source the store's ref NAME holds (arbace.box/load-ref).R4,i467,R5,i1,R6,s14,arbace/main.aev11,arbace.main8,init-optm12,R12,TR7,L1,V1,R30,R0,s13,Load a scriptR4,i482,R5,i1,R6,s14,arbace/main.aev11,arbace.main8,eval-optm12,R12,TR7,L1,V1,R48,R0,s62,Evals expressions in str, prints each non-nil result using prnR4,i487,R5,i1,R6,s14,arbace/main.aev11,arbace.main13,init-dispatchm12,R12,TR7,L1,V1,R49,R0,s47,Returns the handler associated with an init optR4,i499,R5,i1,R6,s14,arbace/main.aev11,arbace.main10,initializem12,R12,TR7,L1,V2,R50,R51,R0,s57,Common initialize routine for repl, script, and null optsR4,i507,R5,i1,R6,s14,arbace/main.aev11,arbace.main8,main-optm12,R12,TR7,L1,V2,V4,R52,R53,R15,R50,R51,R0,s87,Call the -main function from a namespace with string arguments from\n  the command line.R4,i515,R5,i1,R6,s14,arbace/main.aev11,arbace.main8,repl-optm12,R12,TR7,L1,V2,V3,R52,R15,R50,R51,R0,s82,Start a repl with args and inits. Print greeting if no eval options were\n  presentR4,i523,R5,i1,R6,s14,arbace/main.aev11,arbace.main10,script-optm12,R12,TR7,L1,V2,V3,R30,R15,R50,R51,R0,s70,Run a script from a file, resource, or standard in with args and initsR4,i537,R5,i1,R6,s14,arbace/main.aev11,arbace.main8,null-optm12,R12,TR7,L1,V2,R50,R51,R0,s59,No repl or script opt present, just bind args and run initsR4,i546,R5,i1,R6,s14,arbace/main.aev11,arbace.main8,help-optm12,R12,TR7,L1,V2,R52,R52,R0,s24,Print help text for mainR4,i552,R5,i1,R6,s14,arbace/main.aev11,arbace.main13,main-dispatchm12,R12,TR7,L1,V1,R49,R0,s49,Returns the handler associated with a main optionR4,i557,R5,i1,R6,s14,arbace/main.aev11,arbace.main11,legacy-replm12,R12,TR7,L1,V1,R50,R0,s88,Called by the arbace.lang.Repl.main stub to run a repl with args\n  specified the old wayR4,i571,R5,i1,R6,s14,arbace/main.aev11,arbace.main13,legacy-scriptm12,R12,TR7,L1,V1,R50,R0,s92,Called by the arbace.lang.Script.main stub to run a script with args\n  specified the old wayR4,i581,R5,i1,R6,s14,arbace/main.aev11,arbace.main12,report-errorm10,R7,L1,V3,Myn1,tm2,R10,R11,R15,m6,R54,V1,R55,R56,m2,R55,s4,fileR37,R18,R0,s194,Create and output an exception report for a Throwable to target.\n\n  Options:\n    :target - \"file\" (default), \"stderr\", \"none\"\n\n  If file is specified but cannot be written, falls back to stderr.R4,i591,R5,i1,R6,s14,arbace/main.aem10,R7,L1,V2,R15,R50,R0,s1460,Usage: java -cp arbace.jar arbace.lang.Main [init-opt*] [main-opt] [arg*]\n\n  With no options or args, runs an interactive Read-Eval-Print Loop\n\n  init options:\n    -i, --init path     Load a file or resource\n    -e, --eval string   Evaluate expressions in string; print non-nil values\n    --report target     Report uncaught exception to \"file\" (default), \"stderr\",\n                        or \"none\", overrides System property arbace.main.report\n\n  main options:\n    -m, --main ns-name  Call the -main function from a namespace with args\n    -r, --repl          Run a repl\n    path                Run a script from a file or resource\n    -                   Run a script from standard input\n    -h, -?, --help      Print this help message and exit\n\n  operation:\n\n    - Establishes thread-local bindings for commonly set!-able vars\n    - Enters the user namespace\n    - Binds *command-line-args* to a seq of strings containing command line\n      args that appear after any main option\n    - Runs all init options in order\n    - Calls a -main function or runs a repl or script if requested\n\n  The init options may be repeated and mixed freely, but must appear before\n  any main option. The appearance of any eval option before running a repl\n  suppresses the usual repl greeting message: \"Arbace ~(arbace-version) (~short-commit)\".\n\n  Paths may be absolute or relative in the filesystem or relative to\n  classpath. Classpath-relative paths have prefix of @ or @/R4,i623,R5,i1,R6,s14,arbace/main.ae")

var Lit_97 *jrt.String = jrt.Intern("arbace.main$eval461000004$loading__1927001464__auto____461000005")

var Lit_98 *jrt.String = jrt.Intern("arbace.main$eval461000008$fn__461000009")

var Lit_99 *jrt.String = jrt.Intern("arbace.main$demunge")

var Lit_100 *jrt.String = jrt.Intern("arbace.main$root_cause")

var Lit_101 *jrt.String = jrt.Intern("arbace.main$core_class_QMARK_")

var Lit_102 *jrt.String = jrt.Intern("arbace.main$stack_element_str")

var Lit_103 *jrt.String = jrt.Intern("arbace.main$with_bindings")

var Lit_104 *jrt.String = jrt.Intern("arbace.main$repl_prompt")

var Lit_105 *jrt.String = jrt.Intern("arbace.main$skip_if_eol")

var Lit_106 *jrt.String = jrt.Intern("arbace.main$skip_whitespace")

var Lit_107 *jrt.String = jrt.Intern("arbace.main$renumbering_read")

var Lit_108 *jrt.String = jrt.Intern("arbace.main$repl_read")

var Lit_109 *jrt.String = jrt.Intern("arbace.main$repl_exception")

var Lit_110 *jrt.String = jrt.Intern("arbace.main$file_name")

var Lit_111 *jrt.String = jrt.Intern("arbace.main$file_path")

var Lit_112 *jrt.String = jrt.Intern("arbace.main$java_loc__GT_source")

var Lit_113 *jrt.String = jrt.Intern("arbace.main$ex_triage")

var Lit_114 *jrt.String = jrt.Intern("arbace.main$ex_str")

var Lit_115 *jrt.String = jrt.Intern("arbace.main$err__GT_msg")

var Lit_116 *jrt.String = jrt.Intern("arbace.main$repl_caught")

var Lit_117 *jrt.String = jrt.Intern("arbace.main$with_read_known")

var Lit_118 *jrt.String = jrt.Intern("arbace.main$repl")

var Lit_119 *jrt.String = jrt.Intern("arbace.main$load_script")

var Lit_120 *jrt.String = jrt.Intern("arbace.main$init_opt")

var Lit_121 *jrt.String = jrt.Intern("arbace.main$eval_opt")

var Lit_122 *jrt.String = jrt.Intern("arbace.main$init_dispatch")

var Lit_123 *jrt.String = jrt.Intern("arbace.main$initialize")

var Lit_124 *jrt.String = jrt.Intern("arbace.main$main_opt")

var Lit_125 *jrt.String = jrt.Intern("arbace.main$repl_opt")

var Lit_126 *jrt.String = jrt.Intern("arbace.main$script_opt")

var Lit_127 *jrt.String = jrt.Intern("arbace.main$null_opt")

var Lit_128 *jrt.String = jrt.Intern("arbace.main$help_opt")

var Lit_129 *jrt.String = jrt.Intern("arbace.main$main_dispatch")

var Lit_130 *jrt.String = jrt.Intern("arbace.main$legacy_repl")

var Lit_131 *jrt.String = jrt.Intern("arbace.main$legacy_script")

var Lit_132 *jrt.String = jrt.Intern("arbace.main$report_error")

var Lit_133 *jrt.String = jrt.Intern("arbace.main$main")
