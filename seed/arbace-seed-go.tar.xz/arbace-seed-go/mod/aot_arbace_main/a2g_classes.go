//line a2g_classes.ae:1
package aot_arbace_main

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_A_New()}; return nil }

var A_arbace_main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_main_A_new}

var A_arbace_main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_main.A_arbace_main_A"})

func init() { i := A_arbace_main_A_class.Info(); i.IsInstance = A_arbace_main_A_InstanceOf; i.Init = A_arbace_main_A_Init; i.Table = A_arbace_main_A_members; jrt.RegisterGoType(A_arbace_main_A_class, reflect.TypeFor[A_arbace_main_A]()) }

func A_arbace_main_core_class_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_core_class_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_core_class_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_core_class_QMARK__A_New()}; return nil }

func A_arbace_main_core_class_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_core_class_QMARK__A_fn_class)}; return nil }

var A_arbace_main_core_class_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_core_class_QMARK__A_invoke, New: A_arbace_main_core_class_QMARK__A_new, Get: A_arbace_main_core_class_QMARK__A_get}

var A_arbace_main_core_class_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$core_class_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "core_class_QMARK_", Go: "arbace/aot_arbace_main.A_arbace_main_core_class_QMARK__A", Source: "main.ae"})

func init() { i := A_arbace_main_core_class_QMARK__A_class.Info(); i.IsInstance = A_arbace_main_core_class_QMARK__A_InstanceOf; i.Init = A_arbace_main_core_class_QMARK__A_Init; i.Table = A_arbace_main_core_class_QMARK__A_members; jrt.RegisterGoType(A_arbace_main_core_class_QMARK__A_class, reflect.TypeFor[A_arbace_main_core_class_QMARK__A]()) }

func A_arbace_main_demunge_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_demunge_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_demunge_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_demunge_A_New()}; return nil }

func A_arbace_main_demunge_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_demunge_A_fn_class)}; return nil }

var A_arbace_main_demunge_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_demunge_A_invoke, New: A_arbace_main_demunge_A_new, Get: A_arbace_main_demunge_A_get}

var A_arbace_main_demunge_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$demunge", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "demunge", Go: "arbace/aot_arbace_main.A_arbace_main_demunge_A", Source: "main.ae"})

func init() { i := A_arbace_main_demunge_A_class.Info(); i.IsInstance = A_arbace_main_demunge_A_InstanceOf; i.Init = A_arbace_main_demunge_A_Init; i.Table = A_arbace_main_demunge_A_members; jrt.RegisterGoType(A_arbace_main_demunge_A_class, reflect.TypeFor[A_arbace_main_demunge_A]()) }

func A_arbace_main_err__GT_msg_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_err__GT_msg_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_err__GT_msg_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_err__GT_msg_A_New()}; return nil }

func A_arbace_main_err__GT_msg_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_err__GT_msg_A_fn_class)}; return nil }

var A_arbace_main_err__GT_msg_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_err__GT_msg_A_invoke, New: A_arbace_main_err__GT_msg_A_new, Get: A_arbace_main_err__GT_msg_A_get}

var A_arbace_main_err__GT_msg_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$err__GT_msg", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "err__GT_msg", Go: "arbace/aot_arbace_main.A_arbace_main_err__GT_msg_A", Source: "main.ae"})

func init() { i := A_arbace_main_err__GT_msg_A_class.Info(); i.IsInstance = A_arbace_main_err__GT_msg_A_InstanceOf; i.Init = A_arbace_main_err__GT_msg_A_Init; i.Table = A_arbace_main_err__GT_msg_A_members; jrt.RegisterGoType(A_arbace_main_err__GT_msg_A_class, reflect.TypeFor[A_arbace_main_err__GT_msg_A]()) }

func A_arbace_main_eval461000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_eval461000004_A_New()}; return nil }

var A_arbace_main_eval461000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_main_eval461000004_A_new}

var A_arbace_main_eval461000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$eval461000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_main_A_class, Simple: "eval461000004", Go: "arbace/aot_arbace_main.A_arbace_main_eval461000004_A"})

func init() { i := A_arbace_main_eval461000004_A_class.Info(); i.IsInstance = A_arbace_main_eval461000004_A_InstanceOf; i.Table = A_arbace_main_eval461000004_A_members; jrt.RegisterGoType(A_arbace_main_eval461000004_A_class, reflect.TypeFor[A_arbace_main_eval461000004_A]()) }

func A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_New()}; return nil }

func A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_fn_class)}; return nil }

var A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_invoke, New: A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_new, Get: A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_get}

var A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$eval461000004$loading__1927001464__auto____461000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_eval461000004_A_class, Simple: "loading__1927001464__auto____461000005", Go: "arbace/aot_arbace_main.A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A", Source: "main.ae"})

func init() { i := A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_class.Info(); i.IsInstance = A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_InstanceOf; i.Init = A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_Init; i.Table = A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_members; jrt.RegisterGoType(A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_class, reflect.TypeFor[A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A]()) }

func A_arbace_main_eval461000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_eval461000008_A_New()}; return nil }

var A_arbace_main_eval461000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_main_eval461000008_A_new}

var A_arbace_main_eval461000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$eval461000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_main_A_class, Simple: "eval461000008", Go: "arbace/aot_arbace_main.A_arbace_main_eval461000008_A"})

func init() { i := A_arbace_main_eval461000008_A_class.Info(); i.IsInstance = A_arbace_main_eval461000008_A_InstanceOf; i.Table = A_arbace_main_eval461000008_A_members; jrt.RegisterGoType(A_arbace_main_eval461000008_A_class, reflect.TypeFor[A_arbace_main_eval461000008_A]()) }

func A_arbace_main_eval461000008_fn__461000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_eval461000008_fn__461000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_eval461000008_fn__461000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_eval461000008_fn__461000009_A_New()}; return nil }

func A_arbace_main_eval461000008_fn__461000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_eval461000008_fn__461000009_A_fn_class)}; return nil }

var A_arbace_main_eval461000008_fn__461000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_eval461000008_fn__461000009_A_invoke, New: A_arbace_main_eval461000008_fn__461000009_A_new, Get: A_arbace_main_eval461000008_fn__461000009_A_get}

var A_arbace_main_eval461000008_fn__461000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$eval461000008$fn__461000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_eval461000008_A_class, Simple: "fn__461000009", Go: "arbace/aot_arbace_main.A_arbace_main_eval461000008_fn__461000009_A", Source: "main.ae"})

func init() { i := A_arbace_main_eval461000008_fn__461000009_A_class.Info(); i.IsInstance = A_arbace_main_eval461000008_fn__461000009_A_InstanceOf; i.Init = A_arbace_main_eval461000008_fn__461000009_A_Init; i.Table = A_arbace_main_eval461000008_fn__461000009_A_members; jrt.RegisterGoType(A_arbace_main_eval461000008_fn__461000009_A_class, reflect.TypeFor[A_arbace_main_eval461000008_fn__461000009_A]()) }

func A_arbace_main_eval_opt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_eval_opt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_eval_opt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_eval_opt_A_New()}; return nil }

func A_arbace_main_eval_opt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_eval_opt_A_fn_class)}; return nil }

var A_arbace_main_eval_opt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_eval_opt_A_invoke, New: A_arbace_main_eval_opt_A_new, Get: A_arbace_main_eval_opt_A_get}

var A_arbace_main_eval_opt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$eval_opt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "eval_opt", Go: "arbace/aot_arbace_main.A_arbace_main_eval_opt_A", Source: "main.ae"})

func init() { i := A_arbace_main_eval_opt_A_class.Info(); i.IsInstance = A_arbace_main_eval_opt_A_InstanceOf; i.Init = A_arbace_main_eval_opt_A_Init; i.Table = A_arbace_main_eval_opt_A_members; jrt.RegisterGoType(A_arbace_main_eval_opt_A_class, reflect.TypeFor[A_arbace_main_eval_opt_A]()) }

func A_arbace_main_eval_opt_fn__461000135_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_eval_opt_fn__461000135_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_eval_opt_fn__461000135_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_eval_opt_fn__461000135_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_main_eval_opt_fn__461000135_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_eval_opt_fn__461000135_A_fn_class)}; return nil }

var A_arbace_main_eval_opt_fn__461000135_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_eval_opt_fn__461000135_A_invoke, New: A_arbace_main_eval_opt_fn__461000135_A_new, Get: A_arbace_main_eval_opt_fn__461000135_A_get}

var A_arbace_main_eval_opt_fn__461000135_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$eval_opt$fn__461000135", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_eval_opt_A_class, Simple: "fn__461000135", Go: "arbace/aot_arbace_main.A_arbace_main_eval_opt_fn__461000135_A", Source: "main.ae"})

func init() { i := A_arbace_main_eval_opt_fn__461000135_A_class.Info(); i.IsInstance = A_arbace_main_eval_opt_fn__461000135_A_InstanceOf; i.Init = A_arbace_main_eval_opt_fn__461000135_A_Init; i.Table = A_arbace_main_eval_opt_fn__461000135_A_members; jrt.RegisterGoType(A_arbace_main_eval_opt_fn__461000135_A_class, reflect.TypeFor[A_arbace_main_eval_opt_fn__461000135_A]()) }

func A_arbace_main_eval_opt_fn__461000137_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_eval_opt_fn__461000137_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_eval_opt_fn__461000137_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_eval_opt_fn__461000137_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_main_eval_opt_fn__461000137_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_eval_opt_fn__461000137_A_fn_class)}; return nil }

var A_arbace_main_eval_opt_fn__461000137_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_eval_opt_fn__461000137_A_invoke, New: A_arbace_main_eval_opt_fn__461000137_A_new, Get: A_arbace_main_eval_opt_fn__461000137_A_get}

var A_arbace_main_eval_opt_fn__461000137_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$eval_opt$fn__461000137", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_eval_opt_A_class, Simple: "fn__461000137", Go: "arbace/aot_arbace_main.A_arbace_main_eval_opt_fn__461000137_A", Source: "main.ae"})

func init() { i := A_arbace_main_eval_opt_fn__461000137_A_class.Info(); i.IsInstance = A_arbace_main_eval_opt_fn__461000137_A_InstanceOf; i.Init = A_arbace_main_eval_opt_fn__461000137_A_Init; i.Table = A_arbace_main_eval_opt_fn__461000137_A_members; jrt.RegisterGoType(A_arbace_main_eval_opt_fn__461000137_A_class, reflect.TypeFor[A_arbace_main_eval_opt_fn__461000137_A]()) }

func A_arbace_main_ex_str_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_ex_str_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_ex_str_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_ex_str_A_New()}; return nil }

func A_arbace_main_ex_str_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_ex_str_A_fn_class)}; return nil }

var A_arbace_main_ex_str_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_ex_str_A_invoke, New: A_arbace_main_ex_str_A_new, Get: A_arbace_main_ex_str_A_get}

var A_arbace_main_ex_str_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$ex_str", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "ex_str", Go: "arbace/aot_arbace_main.A_arbace_main_ex_str_A", Source: "main.ae"})

func init() { i := A_arbace_main_ex_str_A_class.Info(); i.IsInstance = A_arbace_main_ex_str_A_InstanceOf; i.Init = A_arbace_main_ex_str_A_Init; i.Table = A_arbace_main_ex_str_A_members; jrt.RegisterGoType(A_arbace_main_ex_str_A_class, reflect.TypeFor[A_arbace_main_ex_str_A]()) }

func A_arbace_main_ex_str_fn__461000085_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_ex_str_fn__461000085_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_ex_str_fn__461000085_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_ex_str_fn__461000085_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_main_ex_str_fn__461000085_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_ex_str_fn__461000085_A_fn_class)}; return nil }

var A_arbace_main_ex_str_fn__461000085_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_ex_str_fn__461000085_A_invoke, New: A_arbace_main_ex_str_fn__461000085_A_new, Get: A_arbace_main_ex_str_fn__461000085_A_get}

var A_arbace_main_ex_str_fn__461000085_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$ex_str$fn__461000085", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_ex_str_A_class, Simple: "fn__461000085", Go: "arbace/aot_arbace_main.A_arbace_main_ex_str_fn__461000085_A", Source: "main.ae"})

func init() { i := A_arbace_main_ex_str_fn__461000085_A_class.Info(); i.IsInstance = A_arbace_main_ex_str_fn__461000085_A_InstanceOf; i.Init = A_arbace_main_ex_str_fn__461000085_A_Init; i.Table = A_arbace_main_ex_str_fn__461000085_A_members; jrt.RegisterGoType(A_arbace_main_ex_str_fn__461000085_A_class, reflect.TypeFor[A_arbace_main_ex_str_fn__461000085_A]()) }

func A_arbace_main_ex_str_fn__461000085_fn__461000086_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_ex_str_fn__461000085_fn__461000086_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_ex_str_fn__461000085_fn__461000086_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_ex_str_fn__461000085_fn__461000086_A_New()}; return nil }

func A_arbace_main_ex_str_fn__461000085_fn__461000086_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_ex_str_fn__461000085_fn__461000086_A_fn_class)}; return nil }

var A_arbace_main_ex_str_fn__461000085_fn__461000086_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_ex_str_fn__461000085_fn__461000086_A_invoke, New: A_arbace_main_ex_str_fn__461000085_fn__461000086_A_new, Get: A_arbace_main_ex_str_fn__461000085_fn__461000086_A_get}

var A_arbace_main_ex_str_fn__461000085_fn__461000086_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$ex_str$fn__461000085$fn__461000086", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_ex_str_fn__461000085_A_class, Simple: "fn__461000086", Go: "arbace/aot_arbace_main.A_arbace_main_ex_str_fn__461000085_fn__461000086_A", Source: "main.ae"})

func init() { i := A_arbace_main_ex_str_fn__461000085_fn__461000086_A_class.Info(); i.IsInstance = A_arbace_main_ex_str_fn__461000085_fn__461000086_A_InstanceOf; i.Init = A_arbace_main_ex_str_fn__461000085_fn__461000086_A_Init; i.Table = A_arbace_main_ex_str_fn__461000085_fn__461000086_A_members; jrt.RegisterGoType(A_arbace_main_ex_str_fn__461000085_fn__461000086_A_class, reflect.TypeFor[A_arbace_main_ex_str_fn__461000085_fn__461000086_A]()) }

func A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_New()}; return nil }

func A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_fn_class)}; return nil }

var A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_invoke, New: A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_new, Get: A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_get}

var A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$ex_str$fn__461000085$fn__461000086$fn__461000087", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_ex_str_fn__461000085_fn__461000086_A_class, Simple: "fn__461000087", Go: "arbace/aot_arbace_main.A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A", Source: "main.ae"})

func init() { i := A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_class.Info(); i.IsInstance = A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_InstanceOf; i.Init = A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_Init; i.Table = A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_members; jrt.RegisterGoType(A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_class, reflect.TypeFor[A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A]()) }

func A_arbace_main_ex_str_fn__461000091_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_ex_str_fn__461000091_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_ex_str_fn__461000091_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_ex_str_fn__461000091_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_main_ex_str_fn__461000091_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_ex_str_fn__461000091_A_fn_class)}; return nil }

var A_arbace_main_ex_str_fn__461000091_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_ex_str_fn__461000091_A_invoke, New: A_arbace_main_ex_str_fn__461000091_A_new, Get: A_arbace_main_ex_str_fn__461000091_A_get}

var A_arbace_main_ex_str_fn__461000091_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$ex_str$fn__461000091", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_ex_str_A_class, Simple: "fn__461000091", Go: "arbace/aot_arbace_main.A_arbace_main_ex_str_fn__461000091_A", Source: "main.ae"})

func init() { i := A_arbace_main_ex_str_fn__461000091_A_class.Info(); i.IsInstance = A_arbace_main_ex_str_fn__461000091_A_InstanceOf; i.Init = A_arbace_main_ex_str_fn__461000091_A_Init; i.Table = A_arbace_main_ex_str_fn__461000091_A_members; jrt.RegisterGoType(A_arbace_main_ex_str_fn__461000091_A_class, reflect.TypeFor[A_arbace_main_ex_str_fn__461000091_A]()) }

func A_arbace_main_ex_str_fn__461000091_fn__461000092_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_ex_str_fn__461000091_fn__461000092_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_ex_str_fn__461000091_fn__461000092_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_ex_str_fn__461000091_fn__461000092_A_New()}; return nil }

func A_arbace_main_ex_str_fn__461000091_fn__461000092_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_ex_str_fn__461000091_fn__461000092_A_fn_class)}; return nil }

var A_arbace_main_ex_str_fn__461000091_fn__461000092_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_ex_str_fn__461000091_fn__461000092_A_invoke, New: A_arbace_main_ex_str_fn__461000091_fn__461000092_A_new, Get: A_arbace_main_ex_str_fn__461000091_fn__461000092_A_get}

var A_arbace_main_ex_str_fn__461000091_fn__461000092_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$ex_str$fn__461000091$fn__461000092", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_ex_str_fn__461000091_A_class, Simple: "fn__461000092", Go: "arbace/aot_arbace_main.A_arbace_main_ex_str_fn__461000091_fn__461000092_A", Source: "main.ae"})

func init() { i := A_arbace_main_ex_str_fn__461000091_fn__461000092_A_class.Info(); i.IsInstance = A_arbace_main_ex_str_fn__461000091_fn__461000092_A_InstanceOf; i.Init = A_arbace_main_ex_str_fn__461000091_fn__461000092_A_Init; i.Table = A_arbace_main_ex_str_fn__461000091_fn__461000092_A_members; jrt.RegisterGoType(A_arbace_main_ex_str_fn__461000091_fn__461000092_A_class, reflect.TypeFor[A_arbace_main_ex_str_fn__461000091_fn__461000092_A]()) }

func A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_New()}; return nil }

func A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_fn_class)}; return nil }

var A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_invoke, New: A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_new, Get: A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_get}

var A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$ex_str$fn__461000091$fn__461000092$fn__461000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_ex_str_fn__461000091_fn__461000092_A_class, Simple: "fn__461000093", Go: "arbace/aot_arbace_main.A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A", Source: "main.ae"})

func init() { i := A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_class.Info(); i.IsInstance = A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_InstanceOf; i.Init = A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_Init; i.Table = A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_members; jrt.RegisterGoType(A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_class, reflect.TypeFor[A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A]()) }

func A_arbace_main_ex_triage_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_ex_triage_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_ex_triage_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_ex_triage_A_New()}; return nil }

func A_arbace_main_ex_triage_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_ex_triage_A_fn_class)}; return nil }

var A_arbace_main_ex_triage_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_ex_triage_A_invoke, New: A_arbace_main_ex_triage_A_new, Get: A_arbace_main_ex_triage_A_get}

var A_arbace_main_ex_triage_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$ex_triage", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "ex_triage", Go: "arbace/aot_arbace_main.A_arbace_main_ex_triage_A", Source: "main.ae"})

func init() { i := A_arbace_main_ex_triage_A_class.Info(); i.IsInstance = A_arbace_main_ex_triage_A_InstanceOf; i.Init = A_arbace_main_ex_triage_A_Init; i.Table = A_arbace_main_ex_triage_A_members; jrt.RegisterGoType(A_arbace_main_ex_triage_A_class, reflect.TypeFor[A_arbace_main_ex_triage_A]()) }

func A_arbace_main_ex_triage_fn__461000061_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_ex_triage_fn__461000061_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_ex_triage_fn__461000061_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_ex_triage_fn__461000061_A_New()}; return nil }

func A_arbace_main_ex_triage_fn__461000061_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_ex_triage_fn__461000061_A_fn_class)}; return nil }

var A_arbace_main_ex_triage_fn__461000061_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_ex_triage_fn__461000061_A_invoke, New: A_arbace_main_ex_triage_fn__461000061_A_new, Get: A_arbace_main_ex_triage_fn__461000061_A_get}

var A_arbace_main_ex_triage_fn__461000061_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$ex_triage$fn__461000061", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_ex_triage_A_class, Simple: "fn__461000061", Go: "arbace/aot_arbace_main.A_arbace_main_ex_triage_fn__461000061_A", Source: "main.ae"})

func init() { i := A_arbace_main_ex_triage_fn__461000061_A_class.Info(); i.IsInstance = A_arbace_main_ex_triage_fn__461000061_A_InstanceOf; i.Init = A_arbace_main_ex_triage_fn__461000061_A_Init; i.Table = A_arbace_main_ex_triage_fn__461000061_A_members; jrt.RegisterGoType(A_arbace_main_ex_triage_fn__461000061_A_class, reflect.TypeFor[A_arbace_main_ex_triage_fn__461000061_A]()) }

func A_arbace_main_ex_triage_fn__461000063_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_ex_triage_fn__461000063_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_ex_triage_fn__461000063_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_ex_triage_fn__461000063_A_New()}; return nil }

func A_arbace_main_ex_triage_fn__461000063_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_ex_triage_fn__461000063_A_fn_class)}; return nil }

var A_arbace_main_ex_triage_fn__461000063_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_ex_triage_fn__461000063_A_invoke, New: A_arbace_main_ex_triage_fn__461000063_A_new, Get: A_arbace_main_ex_triage_fn__461000063_A_get}

var A_arbace_main_ex_triage_fn__461000063_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$ex_triage$fn__461000063", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_ex_triage_A_class, Simple: "fn__461000063", Go: "arbace/aot_arbace_main.A_arbace_main_ex_triage_fn__461000063_A", Source: "main.ae"})

func init() { i := A_arbace_main_ex_triage_fn__461000063_A_class.Info(); i.IsInstance = A_arbace_main_ex_triage_fn__461000063_A_InstanceOf; i.Init = A_arbace_main_ex_triage_fn__461000063_A_Init; i.Table = A_arbace_main_ex_triage_fn__461000063_A_members; jrt.RegisterGoType(A_arbace_main_ex_triage_fn__461000063_A_class, reflect.TypeFor[A_arbace_main_ex_triage_fn__461000063_A]()) }

func A_arbace_main_file_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_file_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_file_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_file_name_A_New()}; return nil }

func A_arbace_main_file_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_file_name_A_fn_class)}; return nil }

var A_arbace_main_file_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_file_name_A_invoke, New: A_arbace_main_file_name_A_new, Get: A_arbace_main_file_name_A_get}

var A_arbace_main_file_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$file_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "file_name", Go: "arbace/aot_arbace_main.A_arbace_main_file_name_A", Source: "main.ae"})

func init() { i := A_arbace_main_file_name_A_class.Info(); i.IsInstance = A_arbace_main_file_name_A_InstanceOf; i.Init = A_arbace_main_file_name_A_Init; i.Table = A_arbace_main_file_name_A_members; jrt.RegisterGoType(A_arbace_main_file_name_A_class, reflect.TypeFor[A_arbace_main_file_name_A]()) }

func A_arbace_main_file_path_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_file_path_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_file_path_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_file_path_A_New()}; return nil }

func A_arbace_main_file_path_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_file_path_A_fn_class)}; return nil }

var A_arbace_main_file_path_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_file_path_A_invoke, New: A_arbace_main_file_path_A_new, Get: A_arbace_main_file_path_A_get}

var A_arbace_main_file_path_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$file_path", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "file_path", Go: "arbace/aot_arbace_main.A_arbace_main_file_path_A", Source: "main.ae"})

func init() { i := A_arbace_main_file_path_A_class.Info(); i.IsInstance = A_arbace_main_file_path_A_InstanceOf; i.Init = A_arbace_main_file_path_A_Init; i.Table = A_arbace_main_file_path_A_members; jrt.RegisterGoType(A_arbace_main_file_path_A_class, reflect.TypeFor[A_arbace_main_file_path_A]()) }

func A_arbace_main_help_opt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_help_opt_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_main_help_opt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_help_opt_A_New()}; return nil }

func A_arbace_main_help_opt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_help_opt_A_fn_class)}; return nil }

var A_arbace_main_help_opt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_help_opt_A_invoke, New: A_arbace_main_help_opt_A_new, Get: A_arbace_main_help_opt_A_get}

var A_arbace_main_help_opt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$help_opt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_main_A_class, Simple: "help_opt", Go: "arbace/aot_arbace_main.A_arbace_main_help_opt_A", Source: "main.ae"})

func init() { i := A_arbace_main_help_opt_A_class.Info(); i.IsInstance = A_arbace_main_help_opt_A_InstanceOf; i.Init = A_arbace_main_help_opt_A_Init; i.Table = A_arbace_main_help_opt_A_members; jrt.RegisterGoType(A_arbace_main_help_opt_A_class, reflect.TypeFor[A_arbace_main_help_opt_A]()) }

func A_arbace_main_init_dispatch_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_init_dispatch_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_init_dispatch_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_init_dispatch_A_New()}; return nil }

func A_arbace_main_init_dispatch_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_init_dispatch_A_fn_class)}; return nil }

var A_arbace_main_init_dispatch_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_init_dispatch_A_invoke, New: A_arbace_main_init_dispatch_A_new, Get: A_arbace_main_init_dispatch_A_get}

var A_arbace_main_init_dispatch_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$init_dispatch", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "init_dispatch", Go: "arbace/aot_arbace_main.A_arbace_main_init_dispatch_A", Source: "main.ae"})

func init() { i := A_arbace_main_init_dispatch_A_class.Info(); i.IsInstance = A_arbace_main_init_dispatch_A_InstanceOf; i.Init = A_arbace_main_init_dispatch_A_Init; i.Table = A_arbace_main_init_dispatch_A_members; jrt.RegisterGoType(A_arbace_main_init_dispatch_A_class, reflect.TypeFor[A_arbace_main_init_dispatch_A]()) }

func A_arbace_main_init_opt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_init_opt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_init_opt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_init_opt_A_New()}; return nil }

func A_arbace_main_init_opt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_init_opt_A_fn_class)}; return nil }

var A_arbace_main_init_opt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_init_opt_A_invoke, New: A_arbace_main_init_opt_A_new, Get: A_arbace_main_init_opt_A_get}

var A_arbace_main_init_opt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$init_opt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "init_opt", Go: "arbace/aot_arbace_main.A_arbace_main_init_opt_A", Source: "main.ae"})

func init() { i := A_arbace_main_init_opt_A_class.Info(); i.IsInstance = A_arbace_main_init_opt_A_InstanceOf; i.Init = A_arbace_main_init_opt_A_Init; i.Table = A_arbace_main_init_opt_A_members; jrt.RegisterGoType(A_arbace_main_init_opt_A_class, reflect.TypeFor[A_arbace_main_init_opt_A]()) }

func A_arbace_main_initialize_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_initialize_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_main_initialize_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_initialize_A_New()}; return nil }

func A_arbace_main_initialize_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_initialize_A_fn_class)}; return nil }

var A_arbace_main_initialize_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_initialize_A_invoke, New: A_arbace_main_initialize_A_new, Get: A_arbace_main_initialize_A_get}

var A_arbace_main_initialize_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$initialize", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_main_A_class, Simple: "initialize", Go: "arbace/aot_arbace_main.A_arbace_main_initialize_A", Source: "main.ae"})

func init() { i := A_arbace_main_initialize_A_class.Info(); i.IsInstance = A_arbace_main_initialize_A_InstanceOf; i.Init = A_arbace_main_initialize_A_Init; i.Table = A_arbace_main_initialize_A_members; jrt.RegisterGoType(A_arbace_main_initialize_A_class, reflect.TypeFor[A_arbace_main_initialize_A]()) }

func A_arbace_main_java_loc__GT_source_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_java_loc__GT_source_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_main_java_loc__GT_source_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_java_loc__GT_source_A_New()}; return nil }

func A_arbace_main_java_loc__GT_source_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_java_loc__GT_source_A_fn_class)}; return nil }

var A_arbace_main_java_loc__GT_source_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_java_loc__GT_source_A_invoke, New: A_arbace_main_java_loc__GT_source_A_new, Get: A_arbace_main_java_loc__GT_source_A_get}

var A_arbace_main_java_loc__GT_source_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$java_loc__GT_source", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_main_A_class, Simple: "java_loc__GT_source", Go: "arbace/aot_arbace_main.A_arbace_main_java_loc__GT_source_A", Source: "main.ae"})

func init() { i := A_arbace_main_java_loc__GT_source_A_class.Info(); i.IsInstance = A_arbace_main_java_loc__GT_source_A_InstanceOf; i.Init = A_arbace_main_java_loc__GT_source_A_Init; i.Table = A_arbace_main_java_loc__GT_source_A_members; jrt.RegisterGoType(A_arbace_main_java_loc__GT_source_A_class, reflect.TypeFor[A_arbace_main_java_loc__GT_source_A]()) }

func A_arbace_main_java_loc__GT_source_degen__461000039_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_java_loc__GT_source_degen__461000039_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_java_loc__GT_source_degen__461000039_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_java_loc__GT_source_degen__461000039_A_New()}; return nil }

func A_arbace_main_java_loc__GT_source_degen__461000039_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_java_loc__GT_source_degen__461000039_A_fn_class)}; return nil }

var A_arbace_main_java_loc__GT_source_degen__461000039_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_java_loc__GT_source_degen__461000039_A_invoke, New: A_arbace_main_java_loc__GT_source_degen__461000039_A_new, Get: A_arbace_main_java_loc__GT_source_degen__461000039_A_get}

var A_arbace_main_java_loc__GT_source_degen__461000039_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$java_loc__GT_source$degen__461000039", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_java_loc__GT_source_A_class, Simple: "degen__461000039", Go: "arbace/aot_arbace_main.A_arbace_main_java_loc__GT_source_degen__461000039_A", Source: "main.ae"})

func init() { i := A_arbace_main_java_loc__GT_source_degen__461000039_A_class.Info(); i.IsInstance = A_arbace_main_java_loc__GT_source_degen__461000039_A_InstanceOf; i.Init = A_arbace_main_java_loc__GT_source_degen__461000039_A_Init; i.Table = A_arbace_main_java_loc__GT_source_degen__461000039_A_members; jrt.RegisterGoType(A_arbace_main_java_loc__GT_source_degen__461000039_A_class, reflect.TypeFor[A_arbace_main_java_loc__GT_source_degen__461000039_A]()) }

func A_arbace_main_legacy_repl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_legacy_repl_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_legacy_repl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_legacy_repl_A_New()}; return nil }

func A_arbace_main_legacy_repl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_legacy_repl_A_fn_class)}; return nil }

var A_arbace_main_legacy_repl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_legacy_repl_A_invoke, New: A_arbace_main_legacy_repl_A_new, Get: A_arbace_main_legacy_repl_A_get}

var A_arbace_main_legacy_repl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$legacy_repl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "legacy_repl", Go: "arbace/aot_arbace_main.A_arbace_main_legacy_repl_A", Source: "main.ae"})

func init() { i := A_arbace_main_legacy_repl_A_class.Info(); i.IsInstance = A_arbace_main_legacy_repl_A_InstanceOf; i.Init = A_arbace_main_legacy_repl_A_Init; i.Table = A_arbace_main_legacy_repl_A_members; jrt.RegisterGoType(A_arbace_main_legacy_repl_A_class, reflect.TypeFor[A_arbace_main_legacy_repl_A]()) }

func A_arbace_main_legacy_script_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_legacy_script_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_legacy_script_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_legacy_script_A_New()}; return nil }

func A_arbace_main_legacy_script_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_legacy_script_A_fn_class)}; return nil }

var A_arbace_main_legacy_script_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_legacy_script_A_invoke, New: A_arbace_main_legacy_script_A_new, Get: A_arbace_main_legacy_script_A_get}

var A_arbace_main_legacy_script_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$legacy_script", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "legacy_script", Go: "arbace/aot_arbace_main.A_arbace_main_legacy_script_A", Source: "main.ae"})

func init() { i := A_arbace_main_legacy_script_A_class.Info(); i.IsInstance = A_arbace_main_legacy_script_A_InstanceOf; i.Init = A_arbace_main_legacy_script_A_Init; i.Table = A_arbace_main_legacy_script_A_members; jrt.RegisterGoType(A_arbace_main_legacy_script_A_class, reflect.TypeFor[A_arbace_main_legacy_script_A]()) }

func A_arbace_main_load_script_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_load_script_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_load_script_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_load_script_A_New()}; return nil }

func A_arbace_main_load_script_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_load_script_A_fn_class)}; return nil }

var A_arbace_main_load_script_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_load_script_A_invoke, New: A_arbace_main_load_script_A_new, Get: A_arbace_main_load_script_A_get}

var A_arbace_main_load_script_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$load_script", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "load_script", Go: "arbace/aot_arbace_main.A_arbace_main_load_script_A", Source: "main.ae"})

func init() { i := A_arbace_main_load_script_A_class.Info(); i.IsInstance = A_arbace_main_load_script_A_InstanceOf; i.Init = A_arbace_main_load_script_A_Init; i.Table = A_arbace_main_load_script_A_members; jrt.RegisterGoType(A_arbace_main_load_script_A_class, reflect.TypeFor[A_arbace_main_load_script_A]()) }

func A_arbace_main_main_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_main_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_main_A_New()}; return nil }

func A_arbace_main_main_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_main_A_fn_class)}; return nil }

var A_arbace_main_main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_main_A_invoke, New: A_arbace_main_main_A_new, Get: A_arbace_main_main_A_get}

var A_arbace_main_main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$main", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_main_A_class, Simple: "main", Go: "arbace/aot_arbace_main.A_arbace_main_main_A", Source: "main.ae"})

func init() { i := A_arbace_main_main_A_class.Info(); i.IsInstance = A_arbace_main_main_A_InstanceOf; i.Init = A_arbace_main_main_A_Init; i.Table = A_arbace_main_main_A_members; jrt.RegisterGoType(A_arbace_main_main_A_class, reflect.TypeFor[A_arbace_main_main_A]()) }

func A_arbace_main_main_dispatch_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_main_dispatch_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_main_dispatch_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_main_dispatch_A_New()}; return nil }

func A_arbace_main_main_dispatch_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_main_dispatch_A_fn_class)}; return nil }

var A_arbace_main_main_dispatch_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_main_dispatch_A_invoke, New: A_arbace_main_main_dispatch_A_new, Get: A_arbace_main_main_dispatch_A_get}

var A_arbace_main_main_dispatch_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$main_dispatch", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "main_dispatch", Go: "arbace/aot_arbace_main.A_arbace_main_main_dispatch_A", Source: "main.ae"})

func init() { i := A_arbace_main_main_dispatch_A_class.Info(); i.IsInstance = A_arbace_main_main_dispatch_A_InstanceOf; i.Init = A_arbace_main_main_dispatch_A_Init; i.Table = A_arbace_main_main_dispatch_A_members; jrt.RegisterGoType(A_arbace_main_main_dispatch_A_class, reflect.TypeFor[A_arbace_main_main_dispatch_A]()) }

func A_arbace_main_main_opt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_main_opt_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_main_main_opt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_main_opt_A_New()}; return nil }

func A_arbace_main_main_opt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_main_opt_A_fn_class)}; return nil }

var A_arbace_main_main_opt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_main_opt_A_invoke, New: A_arbace_main_main_opt_A_new, Get: A_arbace_main_main_opt_A_get}

var A_arbace_main_main_opt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$main_opt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_main_A_class, Simple: "main_opt", Go: "arbace/aot_arbace_main.A_arbace_main_main_opt_A", Source: "main.ae"})

func init() { i := A_arbace_main_main_opt_A_class.Info(); i.IsInstance = A_arbace_main_main_opt_A_InstanceOf; i.Init = A_arbace_main_main_opt_A_Init; i.Table = A_arbace_main_main_opt_A_members; jrt.RegisterGoType(A_arbace_main_main_opt_A_class, reflect.TypeFor[A_arbace_main_main_opt_A]()) }

func A_arbace_main_null_opt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_null_opt_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_main_null_opt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_null_opt_A_New()}; return nil }

func A_arbace_main_null_opt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_null_opt_A_fn_class)}; return nil }

var A_arbace_main_null_opt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_null_opt_A_invoke, New: A_arbace_main_null_opt_A_new, Get: A_arbace_main_null_opt_A_get}

var A_arbace_main_null_opt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$null_opt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_main_A_class, Simple: "null_opt", Go: "arbace/aot_arbace_main.A_arbace_main_null_opt_A", Source: "main.ae"})

func init() { i := A_arbace_main_null_opt_A_class.Info(); i.IsInstance = A_arbace_main_null_opt_A_InstanceOf; i.Init = A_arbace_main_null_opt_A_Init; i.Table = A_arbace_main_null_opt_A_members; jrt.RegisterGoType(A_arbace_main_null_opt_A_class, reflect.TypeFor[A_arbace_main_null_opt_A]()) }

func A_arbace_main_renumbering_read_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_renumbering_read_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_main_renumbering_read_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_renumbering_read_A_New()}; return nil }

func A_arbace_main_renumbering_read_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_renumbering_read_A_fn_class)}; return nil }

var A_arbace_main_renumbering_read_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_renumbering_read_A_invoke, New: A_arbace_main_renumbering_read_A_new, Get: A_arbace_main_renumbering_read_A_get}

var A_arbace_main_renumbering_read_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$renumbering_read", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_main_A_class, Simple: "renumbering_read", Go: "arbace/aot_arbace_main.A_arbace_main_renumbering_read_A", Source: "main.ae"})

func init() { i := A_arbace_main_renumbering_read_A_class.Info(); i.IsInstance = A_arbace_main_renumbering_read_A_InstanceOf; i.Init = A_arbace_main_renumbering_read_A_Init; i.Table = A_arbace_main_renumbering_read_A_members; jrt.RegisterGoType(A_arbace_main_renumbering_read_A_class, reflect.TypeFor[A_arbace_main_renumbering_read_A]()) }

func A_arbace_main_repl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_repl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_A_New()}; return nil }

func A_arbace_main_repl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_A_fn_class)}; return nil }

var A_arbace_main_repl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_A_invoke, New: A_arbace_main_repl_A_new, Get: A_arbace_main_repl_A_get}

var A_arbace_main_repl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_main_A_class, Simple: "repl", Go: "arbace/aot_arbace_main.A_arbace_main_repl_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_A_class.Info(); i.IsInstance = A_arbace_main_repl_A_InstanceOf; i.Init = A_arbace_main_repl_A_Init; i.Table = A_arbace_main_repl_A_members; jrt.RegisterGoType(A_arbace_main_repl_A_class, reflect.TypeFor[A_arbace_main_repl_A]()) }

func A_arbace_main_repl_default__461000107__461000116_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_default__461000107__461000116_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_repl_default__461000107__461000116_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_default__461000107__461000116_A_New()}; return nil }

func A_arbace_main_repl_default__461000107__461000116_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_default__461000107__461000116_A_fn_class)}; return nil }

var A_arbace_main_repl_default__461000107__461000116_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_default__461000107__461000116_A_invoke, New: A_arbace_main_repl_default__461000107__461000116_A_new, Get: A_arbace_main_repl_default__461000107__461000116_A_get}

var A_arbace_main_repl_default__461000107__461000116_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl$default__461000107__461000116", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_repl_A_class, Simple: "default__461000107__461000116", Go: "arbace/aot_arbace_main.A_arbace_main_repl_default__461000107__461000116_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_default__461000107__461000116_A_class.Info(); i.IsInstance = A_arbace_main_repl_default__461000107__461000116_A_InstanceOf; i.Init = A_arbace_main_repl_default__461000107__461000116_A_Init; i.Table = A_arbace_main_repl_default__461000107__461000116_A_members; jrt.RegisterGoType(A_arbace_main_repl_default__461000107__461000116_A_class, reflect.TypeFor[A_arbace_main_repl_default__461000107__461000116_A]()) }

func A_arbace_main_repl_fn__461000118_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_fn__461000118_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_repl_fn__461000118_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_fn__461000118_A_New()}; return nil }

func A_arbace_main_repl_fn__461000118_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_fn__461000118_A_fn_class)}; return nil }

var A_arbace_main_repl_fn__461000118_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_fn__461000118_A_invoke, New: A_arbace_main_repl_fn__461000118_A_new, Get: A_arbace_main_repl_fn__461000118_A_get}

var A_arbace_main_repl_fn__461000118_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl$fn__461000118", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_repl_A_class, Simple: "fn__461000118", Go: "arbace/aot_arbace_main.A_arbace_main_repl_fn__461000118_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_fn__461000118_A_class.Info(); i.IsInstance = A_arbace_main_repl_fn__461000118_A_InstanceOf; i.Init = A_arbace_main_repl_fn__461000118_A_Init; i.Table = A_arbace_main_repl_fn__461000118_A_members; jrt.RegisterGoType(A_arbace_main_repl_fn__461000118_A_class, reflect.TypeFor[A_arbace_main_repl_fn__461000118_A]()) }

func A_arbace_main_repl_fn__461000120_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_fn__461000120_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_repl_fn__461000120_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_fn__461000120_A_New()}; return nil }

func A_arbace_main_repl_fn__461000120_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_fn__461000120_A_fn_class)}; return nil }

var A_arbace_main_repl_fn__461000120_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_fn__461000120_A_invoke, New: A_arbace_main_repl_fn__461000120_A_new, Get: A_arbace_main_repl_fn__461000120_A_get}

var A_arbace_main_repl_fn__461000120_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl$fn__461000120", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_repl_A_class, Simple: "fn__461000120", Go: "arbace/aot_arbace_main.A_arbace_main_repl_fn__461000120_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_fn__461000120_A_class.Info(); i.IsInstance = A_arbace_main_repl_fn__461000120_A_InstanceOf; i.Init = A_arbace_main_repl_fn__461000120_A_Init; i.Table = A_arbace_main_repl_fn__461000120_A_members; jrt.RegisterGoType(A_arbace_main_repl_fn__461000120_A_class, reflect.TypeFor[A_arbace_main_repl_fn__461000120_A]()) }

func A_arbace_main_repl_fn__461000128_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_fn__461000128_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_repl_fn__461000128_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_fn__461000128_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_main_repl_fn__461000128_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_fn__461000128_A_fn_class)}; return nil }

var A_arbace_main_repl_fn__461000128_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_fn__461000128_A_invoke, New: A_arbace_main_repl_fn__461000128_A_new, Get: A_arbace_main_repl_fn__461000128_A_get}

var A_arbace_main_repl_fn__461000128_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl$fn__461000128", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_repl_A_class, Simple: "fn__461000128", Go: "arbace/aot_arbace_main.A_arbace_main_repl_fn__461000128_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_fn__461000128_A_class.Info(); i.IsInstance = A_arbace_main_repl_fn__461000128_A_InstanceOf; i.Init = A_arbace_main_repl_fn__461000128_A_Init; i.Table = A_arbace_main_repl_fn__461000128_A_members; jrt.RegisterGoType(A_arbace_main_repl_fn__461000128_A_class, reflect.TypeFor[A_arbace_main_repl_fn__461000128_A]()) }

func A_arbace_main_repl_fn__461000130_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_fn__461000130_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_repl_fn__461000130_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_fn__461000130_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_main_repl_fn__461000130_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_fn__461000130_A_fn_class)}; return nil }

var A_arbace_main_repl_fn__461000130_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_fn__461000130_A_invoke, New: A_arbace_main_repl_fn__461000130_A_new, Get: A_arbace_main_repl_fn__461000130_A_get}

var A_arbace_main_repl_fn__461000130_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl$fn__461000130", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_repl_A_class, Simple: "fn__461000130", Go: "arbace/aot_arbace_main.A_arbace_main_repl_fn__461000130_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_fn__461000130_A_class.Info(); i.IsInstance = A_arbace_main_repl_fn__461000130_A_InstanceOf; i.Init = A_arbace_main_repl_fn__461000130_A_Init; i.Table = A_arbace_main_repl_fn__461000130_A_members; jrt.RegisterGoType(A_arbace_main_repl_fn__461000130_A_class, reflect.TypeFor[A_arbace_main_repl_fn__461000130_A]()) }

func A_arbace_main_repl_read_eval_print__461000122_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_read_eval_print__461000122_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_repl_read_eval_print__461000122_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_read_eval_print__461000122_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_main_repl_read_eval_print__461000122_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_read_eval_print__461000122_A_fn_class)}; return nil }

var A_arbace_main_repl_read_eval_print__461000122_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_read_eval_print__461000122_A_invoke, New: A_arbace_main_repl_read_eval_print__461000122_A_new, Get: A_arbace_main_repl_read_eval_print__461000122_A_get}

var A_arbace_main_repl_read_eval_print__461000122_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl$read_eval_print__461000122", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_repl_A_class, Simple: "read_eval_print__461000122", Go: "arbace/aot_arbace_main.A_arbace_main_repl_read_eval_print__461000122_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_read_eval_print__461000122_A_class.Info(); i.IsInstance = A_arbace_main_repl_read_eval_print__461000122_A_InstanceOf; i.Init = A_arbace_main_repl_read_eval_print__461000122_A_Init; i.Table = A_arbace_main_repl_read_eval_print__461000122_A_members; jrt.RegisterGoType(A_arbace_main_repl_read_eval_print__461000122_A_class, reflect.TypeFor[A_arbace_main_repl_read_eval_print__461000122_A]()) }

func A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_fn_class)}; return nil }

var A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_invoke, New: A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_new, Get: A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_get}

var A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl$read_eval_print__461000122$fn__461000123", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_repl_read_eval_print__461000122_A_class, Simple: "fn__461000123", Go: "arbace/aot_arbace_main.A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_class.Info(); i.IsInstance = A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_InstanceOf; i.Init = A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_Init; i.Table = A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_members; jrt.RegisterGoType(A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_class, reflect.TypeFor[A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A]()) }

func A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_fn_class)}; return nil }

var A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_invoke, New: A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_new, Get: A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_get}

var A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl$read_eval_print__461000122$fn__461000125", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_repl_read_eval_print__461000122_A_class, Simple: "fn__461000125", Go: "arbace/aot_arbace_main.A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_class.Info(); i.IsInstance = A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_InstanceOf; i.Init = A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_Init; i.Table = A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_members; jrt.RegisterGoType(A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_class, reflect.TypeFor[A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A]()) }

func A_arbace_main_repl_caught_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_caught_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_repl_caught_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_caught_A_New()}; return nil }

func A_arbace_main_repl_caught_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_caught_A_fn_class)}; return nil }

var A_arbace_main_repl_caught_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_caught_A_invoke, New: A_arbace_main_repl_caught_A_new, Get: A_arbace_main_repl_caught_A_get}

var A_arbace_main_repl_caught_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl_caught", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "repl_caught", Go: "arbace/aot_arbace_main.A_arbace_main_repl_caught_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_caught_A_class.Info(); i.IsInstance = A_arbace_main_repl_caught_A_InstanceOf; i.Init = A_arbace_main_repl_caught_A_Init; i.Table = A_arbace_main_repl_caught_A_members; jrt.RegisterGoType(A_arbace_main_repl_caught_A_class, reflect.TypeFor[A_arbace_main_repl_caught_A]()) }

func A_arbace_main_repl_exception_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_exception_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_repl_exception_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_exception_A_New()}; return nil }

func A_arbace_main_repl_exception_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_exception_A_fn_class)}; return nil }

var A_arbace_main_repl_exception_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_exception_A_invoke, New: A_arbace_main_repl_exception_A_new, Get: A_arbace_main_repl_exception_A_get}

var A_arbace_main_repl_exception_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl_exception", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "repl_exception", Go: "arbace/aot_arbace_main.A_arbace_main_repl_exception_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_exception_A_class.Info(); i.IsInstance = A_arbace_main_repl_exception_A_InstanceOf; i.Init = A_arbace_main_repl_exception_A_Init; i.Table = A_arbace_main_repl_exception_A_members; jrt.RegisterGoType(A_arbace_main_repl_exception_A_class, reflect.TypeFor[A_arbace_main_repl_exception_A]()) }

func A_arbace_main_repl_opt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_opt_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_main_repl_opt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_opt_A_New()}; return nil }

func A_arbace_main_repl_opt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_opt_A_fn_class)}; return nil }

var A_arbace_main_repl_opt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_opt_A_invoke, New: A_arbace_main_repl_opt_A_new, Get: A_arbace_main_repl_opt_A_get}

var A_arbace_main_repl_opt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl_opt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_main_A_class, Simple: "repl_opt", Go: "arbace/aot_arbace_main.A_arbace_main_repl_opt_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_opt_A_class.Info(); i.IsInstance = A_arbace_main_repl_opt_A_InstanceOf; i.Init = A_arbace_main_repl_opt_A_Init; i.Table = A_arbace_main_repl_opt_A_members; jrt.RegisterGoType(A_arbace_main_repl_opt_A_class, reflect.TypeFor[A_arbace_main_repl_opt_A]()) }

func A_arbace_main_repl_opt_fn__461000163_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_opt_fn__461000163_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_repl_opt_fn__461000163_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_opt_fn__461000163_A_New()}; return nil }

func A_arbace_main_repl_opt_fn__461000163_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_opt_fn__461000163_A_fn_class)}; return nil }

var A_arbace_main_repl_opt_fn__461000163_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_opt_fn__461000163_A_invoke, New: A_arbace_main_repl_opt_fn__461000163_A_new, Get: A_arbace_main_repl_opt_fn__461000163_A_get}

var A_arbace_main_repl_opt_fn__461000163_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl_opt$fn__461000163", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_repl_opt_A_class, Simple: "fn__461000163", Go: "arbace/aot_arbace_main.A_arbace_main_repl_opt_fn__461000163_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_opt_fn__461000163_A_class.Info(); i.IsInstance = A_arbace_main_repl_opt_fn__461000163_A_InstanceOf; i.Init = A_arbace_main_repl_opt_fn__461000163_A_Init; i.Table = A_arbace_main_repl_opt_fn__461000163_A_members; jrt.RegisterGoType(A_arbace_main_repl_opt_fn__461000163_A_class, reflect.TypeFor[A_arbace_main_repl_opt_fn__461000163_A]()) }

func A_arbace_main_repl_opt_fn__461000165_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_opt_fn__461000165_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_repl_opt_fn__461000165_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_opt_fn__461000165_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_main_repl_opt_fn__461000165_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_opt_fn__461000165_A_fn_class)}; return nil }

var A_arbace_main_repl_opt_fn__461000165_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_opt_fn__461000165_A_invoke, New: A_arbace_main_repl_opt_fn__461000165_A_new, Get: A_arbace_main_repl_opt_fn__461000165_A_get}

var A_arbace_main_repl_opt_fn__461000165_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl_opt$fn__461000165", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_repl_opt_A_class, Simple: "fn__461000165", Go: "arbace/aot_arbace_main.A_arbace_main_repl_opt_fn__461000165_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_opt_fn__461000165_A_class.Info(); i.IsInstance = A_arbace_main_repl_opt_fn__461000165_A_InstanceOf; i.Init = A_arbace_main_repl_opt_fn__461000165_A_Init; i.Table = A_arbace_main_repl_opt_fn__461000165_A_members; jrt.RegisterGoType(A_arbace_main_repl_opt_fn__461000165_A_class, reflect.TypeFor[A_arbace_main_repl_opt_fn__461000165_A]()) }

func A_arbace_main_repl_prompt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_prompt_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_repl_prompt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_prompt_A_New()}; return nil }

func A_arbace_main_repl_prompt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_prompt_A_fn_class)}; return nil }

var A_arbace_main_repl_prompt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_prompt_A_invoke, New: A_arbace_main_repl_prompt_A_new, Get: A_arbace_main_repl_prompt_A_get}

var A_arbace_main_repl_prompt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl_prompt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_A_class, Simple: "repl_prompt", Go: "arbace/aot_arbace_main.A_arbace_main_repl_prompt_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_prompt_A_class.Info(); i.IsInstance = A_arbace_main_repl_prompt_A_InstanceOf; i.Init = A_arbace_main_repl_prompt_A_Init; i.Table = A_arbace_main_repl_prompt_A_members; jrt.RegisterGoType(A_arbace_main_repl_prompt_A_class, reflect.TypeFor[A_arbace_main_repl_prompt_A]()) }

func A_arbace_main_repl_read_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_repl_read_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_main_repl_read_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_repl_read_A_New()}; return nil }

func A_arbace_main_repl_read_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_repl_read_A_fn_class)}; return nil }

var A_arbace_main_repl_read_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_repl_read_A_invoke, New: A_arbace_main_repl_read_A_new, Get: A_arbace_main_repl_read_A_get}

var A_arbace_main_repl_read_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$repl_read", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_main_A_class, Simple: "repl_read", Go: "arbace/aot_arbace_main.A_arbace_main_repl_read_A", Source: "main.ae"})

func init() { i := A_arbace_main_repl_read_A_class.Info(); i.IsInstance = A_arbace_main_repl_read_A_InstanceOf; i.Init = A_arbace_main_repl_read_A_Init; i.Table = A_arbace_main_repl_read_A_members; jrt.RegisterGoType(A_arbace_main_repl_read_A_class, reflect.TypeFor[A_arbace_main_repl_read_A]()) }

func A_arbace_main_report_error_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_report_error_A).DoInvoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_main_report_error_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_report_error_A_New()}; return nil }

func A_arbace_main_report_error_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_report_error_A_fn_class)}; return nil }

var A_arbace_main_report_error_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_report_error_A_invoke, New: A_arbace_main_report_error_A_new, Get: A_arbace_main_report_error_A_get}

var A_arbace_main_report_error_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$report_error", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR1_class}, Declaring: A_arbace_main_A_class, Simple: "report_error", Go: "arbace/aot_arbace_main.A_arbace_main_report_error_A", Source: "main.ae"})

func init() { i := A_arbace_main_report_error_A_class.Info(); i.IsInstance = A_arbace_main_report_error_A_InstanceOf; i.Init = A_arbace_main_report_error_A_Init; i.Table = A_arbace_main_report_error_A_members; jrt.RegisterGoType(A_arbace_main_report_error_A_class, reflect.TypeFor[A_arbace_main_report_error_A]()) }

func A_arbace_main_report_error_fn__461000195_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_report_error_fn__461000195_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_report_error_fn__461000195_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_report_error_fn__461000195_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_main_report_error_fn__461000195_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_report_error_fn__461000195_A_fn_class)}; return nil }

var A_arbace_main_report_error_fn__461000195_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_report_error_fn__461000195_A_invoke, New: A_arbace_main_report_error_fn__461000195_A_new, Get: A_arbace_main_report_error_fn__461000195_A_get}

var A_arbace_main_report_error_fn__461000195_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$report_error$fn__461000195", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_report_error_A_class, Simple: "fn__461000195", Go: "arbace/aot_arbace_main.A_arbace_main_report_error_fn__461000195_A", Source: "main.ae"})

func init() { i := A_arbace_main_report_error_fn__461000195_A_class.Info(); i.IsInstance = A_arbace_main_report_error_fn__461000195_A_InstanceOf; i.Init = A_arbace_main_report_error_fn__461000195_A_Init; i.Table = A_arbace_main_report_error_fn__461000195_A_members; jrt.RegisterGoType(A_arbace_main_report_error_fn__461000195_A_class, reflect.TypeFor[A_arbace_main_report_error_fn__461000195_A]()) }

func A_arbace_main_report_error_fn__461000195_fn__461000196_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_report_error_fn__461000195_fn__461000196_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_report_error_fn__461000195_fn__461000196_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_report_error_fn__461000195_fn__461000196_A_New_O(args[0])}; return nil }

func A_arbace_main_report_error_fn__461000195_fn__461000196_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_report_error_fn__461000195_fn__461000196_A_fn_class)}; return nil }

var A_arbace_main_report_error_fn__461000195_fn__461000196_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_report_error_fn__461000195_fn__461000196_A_invoke, New: A_arbace_main_report_error_fn__461000195_fn__461000196_A_new, Get: A_arbace_main_report_error_fn__461000195_fn__461000196_A_get}

var A_arbace_main_report_error_fn__461000195_fn__461000196_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$report_error$fn__461000195$fn__461000196", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_report_error_fn__461000195_A_class, Simple: "fn__461000196", Go: "arbace/aot_arbace_main.A_arbace_main_report_error_fn__461000195_fn__461000196_A", Source: "main.ae"})

func init() { i := A_arbace_main_report_error_fn__461000195_fn__461000196_A_class.Info(); i.IsInstance = A_arbace_main_report_error_fn__461000195_fn__461000196_A_InstanceOf; i.Init = A_arbace_main_report_error_fn__461000195_fn__461000196_A_Init; i.Table = A_arbace_main_report_error_fn__461000195_fn__461000196_A_members; jrt.RegisterGoType(A_arbace_main_report_error_fn__461000195_fn__461000196_A_class, reflect.TypeFor[A_arbace_main_report_error_fn__461000195_fn__461000196_A]()) }

func A_arbace_main_report_error_fn__461000199_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_report_error_fn__461000199_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_report_error_fn__461000199_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_report_error_fn__461000199_A_New_O(args[0])}; return nil }

func A_arbace_main_report_error_fn__461000199_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_report_error_fn__461000199_A_fn_class)}; return nil }

var A_arbace_main_report_error_fn__461000199_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_report_error_fn__461000199_A_invoke, New: A_arbace_main_report_error_fn__461000199_A_new, Get: A_arbace_main_report_error_fn__461000199_A_get}

var A_arbace_main_report_error_fn__461000199_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$report_error$fn__461000199", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_report_error_A_class, Simple: "fn__461000199", Go: "arbace/aot_arbace_main.A_arbace_main_report_error_fn__461000199_A", Source: "main.ae"})

func init() { i := A_arbace_main_report_error_fn__461000199_A_class.Info(); i.IsInstance = A_arbace_main_report_error_fn__461000199_A_InstanceOf; i.Init = A_arbace_main_report_error_fn__461000199_A_Init; i.Table = A_arbace_main_report_error_fn__461000199_A_members; jrt.RegisterGoType(A_arbace_main_report_error_fn__461000199_A_class, reflect.TypeFor[A_arbace_main_report_error_fn__461000199_A]()) }

func A_arbace_main_report_error_fn__461000199_fn__461000200_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_report_error_fn__461000199_fn__461000200_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_main_report_error_fn__461000199_fn__461000200_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_report_error_fn__461000199_fn__461000200_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_main_report_error_fn__461000199_fn__461000200_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_report_error_fn__461000199_fn__461000200_A_fn_class)}; return nil }

var A_arbace_main_report_error_fn__461000199_fn__461000200_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_report_error_fn__461000199_fn__461000200_A_invoke, New: A_arbace_main_report_error_fn__461000199_fn__461000200_A_new, Get: A_arbace_main_report_error_fn__461000199_fn__461000200_A_get}

var A_arbace_main_report_error_fn__461000199_fn__461000200_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$report_error$fn__461000199$fn__461000200", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_main_report_error_fn__461000199_A_class, Simple: "fn__461000200", Go: "arbace/aot_arbace_main.A_arbace_main_report_error_fn__461000199_fn__461000200_A", Source: "main.ae"})

func init() { i := A_arbace_main_report_error_fn__461000199_fn__461000200_A_class.Info(); i.IsInstance = A_arbace_main_report_error_fn__461000199_fn__461000200_A_InstanceOf; i.Init = A_arbace_main_report_error_fn__461000199_fn__461000200_A_Init; i.Table = A_arbace_main_report_error_fn__461000199_fn__461000200_A_members; jrt.RegisterGoType(A_arbace_main_report_error_fn__461000199_fn__461000200_A_class, reflect.TypeFor[A_arbace_main_report_error_fn__461000199_fn__461000200_A]()) }

func A_arbace_main_root_cause_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_root_cause_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_root_cause_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_root_cause_A_New()}; return nil }

func A_arbace_main_root_cause_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_root_cause_A_fn_class)}; return nil }

var A_arbace_main_root_cause_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_root_cause_A_invoke, New: A_arbace_main_root_cause_A_new, Get: A_arbace_main_root_cause_A_get}

var A_arbace_main_root_cause_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$root_cause", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "root_cause", Go: "arbace/aot_arbace_main.A_arbace_main_root_cause_A", Source: "main.ae"})

func init() { i := A_arbace_main_root_cause_A_class.Info(); i.IsInstance = A_arbace_main_root_cause_A_InstanceOf; i.Init = A_arbace_main_root_cause_A_Init; i.Table = A_arbace_main_root_cause_A_members; jrt.RegisterGoType(A_arbace_main_root_cause_A_class, reflect.TypeFor[A_arbace_main_root_cause_A]()) }

func A_arbace_main_script_opt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_script_opt_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_main_script_opt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_script_opt_A_New()}; return nil }

func A_arbace_main_script_opt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_script_opt_A_fn_class)}; return nil }

var A_arbace_main_script_opt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_script_opt_A_invoke, New: A_arbace_main_script_opt_A_new, Get: A_arbace_main_script_opt_A_get}

var A_arbace_main_script_opt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$script_opt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_main_A_class, Simple: "script_opt", Go: "arbace/aot_arbace_main.A_arbace_main_script_opt_A", Source: "main.ae"})

func init() { i := A_arbace_main_script_opt_A_class.Info(); i.IsInstance = A_arbace_main_script_opt_A_InstanceOf; i.Init = A_arbace_main_script_opt_A_Init; i.Table = A_arbace_main_script_opt_A_members; jrt.RegisterGoType(A_arbace_main_script_opt_A_class, reflect.TypeFor[A_arbace_main_script_opt_A]()) }

func A_arbace_main_skip_if_eol_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_skip_if_eol_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_skip_if_eol_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_skip_if_eol_A_New()}; return nil }

func A_arbace_main_skip_if_eol_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_skip_if_eol_A_fn_class)}; return nil }

var A_arbace_main_skip_if_eol_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_skip_if_eol_A_invoke, New: A_arbace_main_skip_if_eol_A_new, Get: A_arbace_main_skip_if_eol_A_get}

var A_arbace_main_skip_if_eol_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$skip_if_eol", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "skip_if_eol", Go: "arbace/aot_arbace_main.A_arbace_main_skip_if_eol_A", Source: "main.ae"})

func init() { i := A_arbace_main_skip_if_eol_A_class.Info(); i.IsInstance = A_arbace_main_skip_if_eol_A_InstanceOf; i.Init = A_arbace_main_skip_if_eol_A_Init; i.Table = A_arbace_main_skip_if_eol_A_members; jrt.RegisterGoType(A_arbace_main_skip_if_eol_A_class, reflect.TypeFor[A_arbace_main_skip_if_eol_A]()) }

func A_arbace_main_skip_whitespace_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_skip_whitespace_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_skip_whitespace_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_skip_whitespace_A_New()}; return nil }

func A_arbace_main_skip_whitespace_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_skip_whitespace_A_fn_class)}; return nil }

var A_arbace_main_skip_whitespace_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_skip_whitespace_A_invoke, New: A_arbace_main_skip_whitespace_A_new, Get: A_arbace_main_skip_whitespace_A_get}

var A_arbace_main_skip_whitespace_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$skip_whitespace", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "skip_whitespace", Go: "arbace/aot_arbace_main.A_arbace_main_skip_whitespace_A", Source: "main.ae"})

func init() { i := A_arbace_main_skip_whitespace_A_class.Info(); i.IsInstance = A_arbace_main_skip_whitespace_A_InstanceOf; i.Init = A_arbace_main_skip_whitespace_A_Init; i.Table = A_arbace_main_skip_whitespace_A_members; jrt.RegisterGoType(A_arbace_main_skip_whitespace_A_class, reflect.TypeFor[A_arbace_main_skip_whitespace_A]()) }

func A_arbace_main_stack_element_str_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_stack_element_str_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_main_stack_element_str_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_stack_element_str_A_New()}; return nil }

func A_arbace_main_stack_element_str_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_stack_element_str_A_fn_class)}; return nil }

var A_arbace_main_stack_element_str_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_stack_element_str_A_invoke, New: A_arbace_main_stack_element_str_A_new, Get: A_arbace_main_stack_element_str_A_get}

var A_arbace_main_stack_element_str_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$stack_element_str", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_main_A_class, Simple: "stack_element_str", Go: "arbace/aot_arbace_main.A_arbace_main_stack_element_str_A", Source: "main.ae"})

func init() { i := A_arbace_main_stack_element_str_A_class.Info(); i.IsInstance = A_arbace_main_stack_element_str_A_InstanceOf; i.Init = A_arbace_main_stack_element_str_A_Init; i.Table = A_arbace_main_stack_element_str_A_members; jrt.RegisterGoType(A_arbace_main_stack_element_str_A_class, reflect.TypeFor[A_arbace_main_stack_element_str_A]()) }

func A_arbace_main_with_bindings_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_with_bindings_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_main_with_bindings_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_with_bindings_A_New()}; return nil }

func A_arbace_main_with_bindings_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_with_bindings_A_fn_class)}; return nil }

var A_arbace_main_with_bindings_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_with_bindings_A_invoke, New: A_arbace_main_with_bindings_A_new, Get: A_arbace_main_with_bindings_A_get}

var A_arbace_main_with_bindings_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$with_bindings", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_main_A_class, Simple: "with_bindings", Go: "arbace/aot_arbace_main.A_arbace_main_with_bindings_A", Source: "main.ae"})

func init() { i := A_arbace_main_with_bindings_A_class.Info(); i.IsInstance = A_arbace_main_with_bindings_A_InstanceOf; i.Init = A_arbace_main_with_bindings_A_Init; i.Table = A_arbace_main_with_bindings_A_members; jrt.RegisterGoType(A_arbace_main_with_bindings_A_class, reflect.TypeFor[A_arbace_main_with_bindings_A]()) }

func A_arbace_main_with_read_known_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_main_with_read_known_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_main_with_read_known_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_with_read_known_A_New()}; return nil }

func A_arbace_main_with_read_known_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_main_with_read_known_A_fn_class)}; return nil }

var A_arbace_main_with_read_known_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_main_with_read_known_A_invoke, New: A_arbace_main_with_read_known_A_new, Get: A_arbace_main_with_read_known_A_get}

var A_arbace_main_with_read_known_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$with_read_known", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_main_A_class, Simple: "with_read_known", Go: "arbace/aot_arbace_main.A_arbace_main_with_read_known_A", Source: "main.ae"})

func init() { i := A_arbace_main_with_read_known_A_class.Info(); i.IsInstance = A_arbace_main_with_read_known_A_InstanceOf; i.Init = A_arbace_main_with_read_known_A_Init; i.Table = A_arbace_main_with_read_known_A_members; jrt.RegisterGoType(A_arbace_main_with_read_known_A_class, reflect.TypeFor[A_arbace_main_with_read_known_A]()) }

func A_arbace_main__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_main__init_A_Load__O(); case 1: return A_arbace_main__init_A_Unit0__O(); case 2: return A_arbace_main__init_A_Unit1__O(); case 3: return A_arbace_main__init_A_Unit10__O(); case 4: return A_arbace_main__init_A_Unit11__O(); case 5: return A_arbace_main__init_A_Unit12__O(); case 6: return A_arbace_main__init_A_Unit13__O(); case 7: return A_arbace_main__init_A_Unit14__O(); case 8: return A_arbace_main__init_A_Unit15__O(); case 9: return A_arbace_main__init_A_Unit16__O(); case 10: return A_arbace_main__init_A_Unit17__O(); case 11: return A_arbace_main__init_A_Unit18__O(); case 12: return A_arbace_main__init_A_Unit19__O(); case 13: return A_arbace_main__init_A_Unit2__O(); case 14: return A_arbace_main__init_A_Unit20__O(); case 15: return A_arbace_main__init_A_Unit21__O(); case 16: return A_arbace_main__init_A_Unit22__O(); case 17: return A_arbace_main__init_A_Unit23__O(); case 18: return A_arbace_main__init_A_Unit24__O(); case 19: return A_arbace_main__init_A_Unit25__O(); case 20: return A_arbace_main__init_A_Unit26__O(); case 21: return A_arbace_main__init_A_Unit27__O(); case 22: return A_arbace_main__init_A_Unit28__O(); case 23: return A_arbace_main__init_A_Unit29__O(); case 24: return A_arbace_main__init_A_Unit3__O(); case 25: return A_arbace_main__init_A_Unit30__O(); case 26: return A_arbace_main__init_A_Unit31__O(); case 27: return A_arbace_main__init_A_Unit32__O(); case 28: return A_arbace_main__init_A_Unit33__O(); case 29: return A_arbace_main__init_A_Unit34__O(); case 30: return A_arbace_main__init_A_Unit35__O(); case 31: return A_arbace_main__init_A_Unit36__O(); case 32: return A_arbace_main__init_A_Unit37__O(); case 33: return A_arbace_main__init_A_Unit38__O(); case 34: return A_arbace_main__init_A_Unit39__O(); case 35: return A_arbace_main__init_A_Unit4__O(); case 36: return A_arbace_main__init_A_Unit40__O(); case 37: return A_arbace_main__init_A_Unit41__O(); case 38: return A_arbace_main__init_A_Unit42__O(); case 39: return A_arbace_main__init_A_Unit43__O(); case 40: return A_arbace_main__init_A_Unit44__O(); case 41: return A_arbace_main__init_A_Unit45__O(); case 42: return A_arbace_main__init_A_Unit5__O(); case 43: return A_arbace_main__init_A_Unit6__O(); case 44: return A_arbace_main__init_A_Unit7__O(); case 45: return A_arbace_main__init_A_Unit8__O(); case 46: return A_arbace_main__init_A_Unit9__O()}; return nil }

func A_arbace_main__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main__init_A_New()}; return nil }

var A_arbace_main__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_main__init_A_invoke, New: A_arbace_main__init_A_new}

var A_arbace_main__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_main.A_arbace_main__init_A", Source: "main.ae"})

func init() { i := A_arbace_main__init_A_class.Info(); i.IsInstance = A_arbace_main__init_A_InstanceOf; i.Init = A_arbace_main__init_A_Init; i.Table = A_arbace_main__init_A_members; jrt.RegisterGoType(A_arbace_main__init_A_class, reflect.TypeFor[A_arbace_main__init_A]()) }
