//line a2g_classes.ae:1
package aot_arbace_main

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_main_core_class_QMARK__A_class, Name: "arbace.main$core_class_QMARK_", Modifiers: 25, Simple: "core_class_QMARK_", Go: "arbace/aot_arbace_main.A_arbace_main_core_class_QMARK__A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_demunge_A_class, Name: "arbace.main$demunge", Modifiers: 25, Simple: "demunge", Go: "arbace/aot_arbace_main.A_arbace_main_demunge_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_err__GT_msg_A_class, Name: "arbace.main$err__GT_msg", Modifiers: 25, Simple: "err__GT_msg", Go: "arbace/aot_arbace_main.A_arbace_main_err__GT_msg_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_class, Name: "arbace.main$eval461000004$loading__1927001464__auto____461000005", Modifiers: 25, Simple: "loading__1927001464__auto____461000005", Go: "arbace/aot_arbace_main.A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A", Source: "main.ae", Declaring: &A_arbace_main_eval461000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_eval461000008_fn__461000009_A_class, Name: "arbace.main$eval461000008$fn__461000009", Modifiers: 25, Simple: "fn__461000009", Go: "arbace/aot_arbace_main.A_arbace_main_eval461000008_fn__461000009_A", Source: "main.ae", Declaring: &A_arbace_main_eval461000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_eval_opt_A_class, Name: "arbace.main$eval_opt", Modifiers: 25, Simple: "eval_opt", Go: "arbace/aot_arbace_main.A_arbace_main_eval_opt_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_eval_opt_fn__461000135_A_class, Name: "arbace.main$eval_opt$fn__461000135", Modifiers: 25, Simple: "fn__461000135", Go: "arbace/aot_arbace_main.A_arbace_main_eval_opt_fn__461000135_A", Source: "main.ae", Declaring: &A_arbace_main_eval_opt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_eval_opt_fn__461000137_A_class, Name: "arbace.main$eval_opt$fn__461000137", Modifiers: 25, Simple: "fn__461000137", Go: "arbace/aot_arbace_main.A_arbace_main_eval_opt_fn__461000137_A", Source: "main.ae", Declaring: &A_arbace_main_eval_opt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_ex_str_A_class, Name: "arbace.main$ex_str", Modifiers: 25, Simple: "ex_str", Go: "arbace/aot_arbace_main.A_arbace_main_ex_str_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_ex_str_fn__461000085_A_class, Name: "arbace.main$ex_str$fn__461000085", Modifiers: 25, Simple: "fn__461000085", Go: "arbace/aot_arbace_main.A_arbace_main_ex_str_fn__461000085_A", Source: "main.ae", Declaring: &A_arbace_main_ex_str_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_ex_str_fn__461000085_fn__461000086_A_class, Name: "arbace.main$ex_str$fn__461000085$fn__461000086", Modifiers: 25, Simple: "fn__461000086", Go: "arbace/aot_arbace_main.A_arbace_main_ex_str_fn__461000085_fn__461000086_A", Source: "main.ae", Declaring: &A_arbace_main_ex_str_fn__461000085_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_class, Name: "arbace.main$ex_str$fn__461000085$fn__461000086$fn__461000087", Modifiers: 25, Simple: "fn__461000087", Go: "arbace/aot_arbace_main.A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A", Source: "main.ae", Declaring: &A_arbace_main_ex_str_fn__461000085_fn__461000086_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_ex_str_fn__461000091_A_class, Name: "arbace.main$ex_str$fn__461000091", Modifiers: 25, Simple: "fn__461000091", Go: "arbace/aot_arbace_main.A_arbace_main_ex_str_fn__461000091_A", Source: "main.ae", Declaring: &A_arbace_main_ex_str_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_ex_str_fn__461000091_fn__461000092_A_class, Name: "arbace.main$ex_str$fn__461000091$fn__461000092", Modifiers: 25, Simple: "fn__461000092", Go: "arbace/aot_arbace_main.A_arbace_main_ex_str_fn__461000091_fn__461000092_A", Source: "main.ae", Declaring: &A_arbace_main_ex_str_fn__461000091_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_class, Name: "arbace.main$ex_str$fn__461000091$fn__461000092$fn__461000093", Modifiers: 25, Simple: "fn__461000093", Go: "arbace/aot_arbace_main.A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A", Source: "main.ae", Declaring: &A_arbace_main_ex_str_fn__461000091_fn__461000092_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_ex_triage_A_class, Name: "arbace.main$ex_triage", Modifiers: 25, Simple: "ex_triage", Go: "arbace/aot_arbace_main.A_arbace_main_ex_triage_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_ex_triage_fn__461000061_A_class, Name: "arbace.main$ex_triage$fn__461000061", Modifiers: 25, Simple: "fn__461000061", Go: "arbace/aot_arbace_main.A_arbace_main_ex_triage_fn__461000061_A", Source: "main.ae", Declaring: &A_arbace_main_ex_triage_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_ex_triage_fn__461000063_A_class, Name: "arbace.main$ex_triage$fn__461000063", Modifiers: 25, Simple: "fn__461000063", Go: "arbace/aot_arbace_main.A_arbace_main_ex_triage_fn__461000063_A", Source: "main.ae", Declaring: &A_arbace_main_ex_triage_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_file_name_A_class, Name: "arbace.main$file_name", Modifiers: 25, Simple: "file_name", Go: "arbace/aot_arbace_main.A_arbace_main_file_name_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_file_path_A_class, Name: "arbace.main$file_path", Modifiers: 25, Simple: "file_path", Go: "arbace/aot_arbace_main.A_arbace_main_file_path_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_help_opt_A_class, Name: "arbace.main$help_opt", Modifiers: 25, Simple: "help_opt", Go: "arbace/aot_arbace_main.A_arbace_main_help_opt_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_main_init_dispatch_A_class, Name: "arbace.main$init_dispatch", Modifiers: 25, Simple: "init_dispatch", Go: "arbace/aot_arbace_main.A_arbace_main_init_dispatch_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_init_opt_A_class, Name: "arbace.main$init_opt", Modifiers: 25, Simple: "init_opt", Go: "arbace/aot_arbace_main.A_arbace_main_init_opt_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_initialize_A_class, Name: "arbace.main$initialize", Modifiers: 25, Simple: "initialize", Go: "arbace/aot_arbace_main.A_arbace_main_initialize_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_main_java_loc__GT_source_A_class, Name: "arbace.main$java_loc__GT_source", Modifiers: 25, Simple: "java_loc__GT_source", Go: "arbace/aot_arbace_main.A_arbace_main_java_loc__GT_source_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_main_java_loc__GT_source_degen__461000039_A_class, Name: "arbace.main$java_loc__GT_source$degen__461000039", Modifiers: 25, Simple: "degen__461000039", Go: "arbace/aot_arbace_main.A_arbace_main_java_loc__GT_source_degen__461000039_A", Source: "main.ae", Declaring: &A_arbace_main_java_loc__GT_source_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_legacy_repl_A_class, Name: "arbace.main$legacy_repl", Modifiers: 25, Simple: "legacy_repl", Go: "arbace/aot_arbace_main.A_arbace_main_legacy_repl_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_legacy_script_A_class, Name: "arbace.main$legacy_script", Modifiers: 25, Simple: "legacy_script", Go: "arbace/aot_arbace_main.A_arbace_main_legacy_script_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_load_script_A_class, Name: "arbace.main$load_script", Modifiers: 25, Simple: "load_script", Go: "arbace/aot_arbace_main.A_arbace_main_load_script_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_main_A_class, Name: "arbace.main$main", Modifiers: 25, Simple: "main", Go: "arbace/aot_arbace_main.A_arbace_main_main_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_main_main_dispatch_A_class, Name: "arbace.main$main_dispatch", Modifiers: 25, Simple: "main_dispatch", Go: "arbace/aot_arbace_main.A_arbace_main_main_dispatch_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_main_opt_A_class, Name: "arbace.main$main_opt", Modifiers: 25, Simple: "main_opt", Go: "arbace/aot_arbace_main.A_arbace_main_main_opt_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_main_null_opt_A_class, Name: "arbace.main$null_opt", Modifiers: 25, Simple: "null_opt", Go: "arbace/aot_arbace_main.A_arbace_main_null_opt_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_main_renumbering_read_A_class, Name: "arbace.main$renumbering_read", Modifiers: 25, Simple: "renumbering_read", Go: "arbace/aot_arbace_main.A_arbace_main_renumbering_read_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_A_class, Name: "arbace.main$repl", Modifiers: 25, Simple: "repl", Go: "arbace/aot_arbace_main.A_arbace_main_repl_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_default__461000107__461000116_A_class, Name: "arbace.main$repl$default__461000107__461000116", Modifiers: 25, Simple: "default__461000107__461000116", Go: "arbace/aot_arbace_main.A_arbace_main_repl_default__461000107__461000116_A", Source: "main.ae", Declaring: &A_arbace_main_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_fn__461000118_A_class, Name: "arbace.main$repl$fn__461000118", Modifiers: 25, Simple: "fn__461000118", Go: "arbace/aot_arbace_main.A_arbace_main_repl_fn__461000118_A", Source: "main.ae", Declaring: &A_arbace_main_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_fn__461000120_A_class, Name: "arbace.main$repl$fn__461000120", Modifiers: 25, Simple: "fn__461000120", Go: "arbace/aot_arbace_main.A_arbace_main_repl_fn__461000120_A", Source: "main.ae", Declaring: &A_arbace_main_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_fn__461000128_A_class, Name: "arbace.main$repl$fn__461000128", Modifiers: 25, Simple: "fn__461000128", Go: "arbace/aot_arbace_main.A_arbace_main_repl_fn__461000128_A", Source: "main.ae", Declaring: &A_arbace_main_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_fn__461000130_A_class, Name: "arbace.main$repl$fn__461000130", Modifiers: 25, Simple: "fn__461000130", Go: "arbace/aot_arbace_main.A_arbace_main_repl_fn__461000130_A", Source: "main.ae", Declaring: &A_arbace_main_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_read_eval_print__461000122_A_class, Name: "arbace.main$repl$read_eval_print__461000122", Modifiers: 25, Simple: "read_eval_print__461000122", Go: "arbace/aot_arbace_main.A_arbace_main_repl_read_eval_print__461000122_A", Source: "main.ae", Declaring: &A_arbace_main_repl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_class, Name: "arbace.main$repl$read_eval_print__461000122$fn__461000123", Modifiers: 25, Simple: "fn__461000123", Go: "arbace/aot_arbace_main.A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A", Source: "main.ae", Declaring: &A_arbace_main_repl_read_eval_print__461000122_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_class, Name: "arbace.main$repl$read_eval_print__461000122$fn__461000125", Modifiers: 25, Simple: "fn__461000125", Go: "arbace/aot_arbace_main.A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A", Source: "main.ae", Declaring: &A_arbace_main_repl_read_eval_print__461000122_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_caught_A_class, Name: "arbace.main$repl_caught", Modifiers: 25, Simple: "repl_caught", Go: "arbace/aot_arbace_main.A_arbace_main_repl_caught_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_exception_A_class, Name: "arbace.main$repl_exception", Modifiers: 25, Simple: "repl_exception", Go: "arbace/aot_arbace_main.A_arbace_main_repl_exception_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_opt_A_class, Name: "arbace.main$repl_opt", Modifiers: 25, Simple: "repl_opt", Go: "arbace/aot_arbace_main.A_arbace_main_repl_opt_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_opt_fn__461000163_A_class, Name: "arbace.main$repl_opt$fn__461000163", Modifiers: 25, Simple: "fn__461000163", Go: "arbace/aot_arbace_main.A_arbace_main_repl_opt_fn__461000163_A", Source: "main.ae", Declaring: &A_arbace_main_repl_opt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_opt_fn__461000165_A_class, Name: "arbace.main$repl_opt$fn__461000165", Modifiers: 25, Simple: "fn__461000165", Go: "arbace/aot_arbace_main.A_arbace_main_repl_opt_fn__461000165_A", Source: "main.ae", Declaring: &A_arbace_main_repl_opt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_prompt_A_class, Name: "arbace.main$repl_prompt", Modifiers: 25, Simple: "repl_prompt", Go: "arbace/aot_arbace_main.A_arbace_main_repl_prompt_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_repl_read_A_class, Name: "arbace.main$repl_read", Modifiers: 25, Simple: "repl_read", Go: "arbace/aot_arbace_main.A_arbace_main_repl_read_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_main_report_error_A_class, Name: "arbace.main$report_error", Modifiers: 25, Simple: "report_error", Go: "arbace/aot_arbace_main.A_arbace_main_report_error_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_main_report_error_fn__461000195_A_class, Name: "arbace.main$report_error$fn__461000195", Modifiers: 25, Simple: "fn__461000195", Go: "arbace/aot_arbace_main.A_arbace_main_report_error_fn__461000195_A", Source: "main.ae", Declaring: &A_arbace_main_report_error_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_report_error_fn__461000195_fn__461000196_A_class, Name: "arbace.main$report_error$fn__461000195$fn__461000196", Modifiers: 25, Simple: "fn__461000196", Go: "arbace/aot_arbace_main.A_arbace_main_report_error_fn__461000195_fn__461000196_A", Source: "main.ae", Declaring: &A_arbace_main_report_error_fn__461000195_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_report_error_fn__461000199_A_class, Name: "arbace.main$report_error$fn__461000199", Modifiers: 25, Simple: "fn__461000199", Go: "arbace/aot_arbace_main.A_arbace_main_report_error_fn__461000199_A", Source: "main.ae", Declaring: &A_arbace_main_report_error_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_report_error_fn__461000199_fn__461000200_A_class, Name: "arbace.main$report_error$fn__461000199$fn__461000200", Modifiers: 25, Simple: "fn__461000200", Go: "arbace/aot_arbace_main.A_arbace_main_report_error_fn__461000199_fn__461000200_A", Source: "main.ae", Declaring: &A_arbace_main_report_error_fn__461000199_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_main_root_cause_A_class, Name: "arbace.main$root_cause", Modifiers: 25, Simple: "root_cause", Go: "arbace/aot_arbace_main.A_arbace_main_root_cause_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_script_opt_A_class, Name: "arbace.main$script_opt", Modifiers: 25, Simple: "script_opt", Go: "arbace/aot_arbace_main.A_arbace_main_script_opt_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_main_skip_if_eol_A_class, Name: "arbace.main$skip_if_eol", Modifiers: 25, Simple: "skip_if_eol", Go: "arbace/aot_arbace_main.A_arbace_main_skip_if_eol_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_skip_whitespace_A_class, Name: "arbace.main$skip_whitespace", Modifiers: 25, Simple: "skip_whitespace", Go: "arbace/aot_arbace_main.A_arbace_main_skip_whitespace_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_stack_element_str_A_class, Name: "arbace.main$stack_element_str", Modifiers: 25, Simple: "stack_element_str", Go: "arbace/aot_arbace_main.A_arbace_main_stack_element_str_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_main_with_bindings_A_class, Name: "arbace.main$with_bindings", Modifiers: 25, Simple: "with_bindings", Go: "arbace/aot_arbace_main.A_arbace_main_with_bindings_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_main_with_read_known_A_class, Name: "arbace.main$with_read_known", Modifiers: 25, Simple: "with_read_known", Go: "arbace/aot_arbace_main.A_arbace_main_with_read_known_A", Source: "main.ae", Declaring: &A_arbace_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_A_New()}; return nil }

var A_arbace_main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_main_A_new}

var A_arbace_main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_main.A_arbace_main_A"})

func init() { i := A_arbace_main_A_class.Info(); i.IsInstance = A_arbace_main_A_InstanceOf; i.Init = A_arbace_main_A_Init; i.Table = A_arbace_main_A_members }

var A_arbace_main_core_class_QMARK__A_class *jrt.Class

var A_arbace_main_demunge_A_class *jrt.Class

var A_arbace_main_err__GT_msg_A_class *jrt.Class

func A_arbace_main_eval461000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_eval461000004_A_New()}; return nil }

var A_arbace_main_eval461000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_main_eval461000004_A_new}

var A_arbace_main_eval461000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$eval461000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_main_A_class, Simple: "eval461000004", Go: "arbace/aot_arbace_main.A_arbace_main_eval461000004_A"})

func init() { i := A_arbace_main_eval461000004_A_class.Info(); i.IsInstance = A_arbace_main_eval461000004_A_InstanceOf; i.Table = A_arbace_main_eval461000004_A_members }

var A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_class *jrt.Class

func A_arbace_main_eval461000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main_eval461000008_A_New()}; return nil }

var A_arbace_main_eval461000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_main_eval461000008_A_new}

var A_arbace_main_eval461000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main$eval461000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_main_A_class, Simple: "eval461000008", Go: "arbace/aot_arbace_main.A_arbace_main_eval461000008_A"})

func init() { i := A_arbace_main_eval461000008_A_class.Info(); i.IsInstance = A_arbace_main_eval461000008_A_InstanceOf; i.Table = A_arbace_main_eval461000008_A_members }

var A_arbace_main_eval461000008_fn__461000009_A_class *jrt.Class

var A_arbace_main_eval_opt_A_class *jrt.Class

var A_arbace_main_eval_opt_fn__461000135_A_class *jrt.Class

var A_arbace_main_eval_opt_fn__461000137_A_class *jrt.Class

var A_arbace_main_ex_str_A_class *jrt.Class

var A_arbace_main_ex_str_fn__461000085_A_class *jrt.Class

var A_arbace_main_ex_str_fn__461000085_fn__461000086_A_class *jrt.Class

var A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_class *jrt.Class

var A_arbace_main_ex_str_fn__461000091_A_class *jrt.Class

var A_arbace_main_ex_str_fn__461000091_fn__461000092_A_class *jrt.Class

var A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_class *jrt.Class

var A_arbace_main_ex_triage_A_class *jrt.Class

var A_arbace_main_ex_triage_fn__461000061_A_class *jrt.Class

var A_arbace_main_ex_triage_fn__461000063_A_class *jrt.Class

var A_arbace_main_file_name_A_class *jrt.Class

var A_arbace_main_file_path_A_class *jrt.Class

var A_arbace_main_help_opt_A_class *jrt.Class

var A_arbace_main_init_dispatch_A_class *jrt.Class

var A_arbace_main_init_opt_A_class *jrt.Class

var A_arbace_main_initialize_A_class *jrt.Class

var A_arbace_main_java_loc__GT_source_A_class *jrt.Class

var A_arbace_main_java_loc__GT_source_degen__461000039_A_class *jrt.Class

var A_arbace_main_legacy_repl_A_class *jrt.Class

var A_arbace_main_legacy_script_A_class *jrt.Class

var A_arbace_main_load_script_A_class *jrt.Class

var A_arbace_main_main_A_class *jrt.Class

var A_arbace_main_main_dispatch_A_class *jrt.Class

var A_arbace_main_main_opt_A_class *jrt.Class

var A_arbace_main_null_opt_A_class *jrt.Class

var A_arbace_main_renumbering_read_A_class *jrt.Class

var A_arbace_main_repl_A_class *jrt.Class

var A_arbace_main_repl_default__461000107__461000116_A_class *jrt.Class

var A_arbace_main_repl_fn__461000118_A_class *jrt.Class

var A_arbace_main_repl_fn__461000120_A_class *jrt.Class

var A_arbace_main_repl_fn__461000128_A_class *jrt.Class

var A_arbace_main_repl_fn__461000130_A_class *jrt.Class

var A_arbace_main_repl_read_eval_print__461000122_A_class *jrt.Class

var A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_class *jrt.Class

var A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_class *jrt.Class

var A_arbace_main_repl_caught_A_class *jrt.Class

var A_arbace_main_repl_exception_A_class *jrt.Class

var A_arbace_main_repl_opt_A_class *jrt.Class

var A_arbace_main_repl_opt_fn__461000163_A_class *jrt.Class

var A_arbace_main_repl_opt_fn__461000165_A_class *jrt.Class

var A_arbace_main_repl_prompt_A_class *jrt.Class

var A_arbace_main_repl_read_A_class *jrt.Class

var A_arbace_main_report_error_A_class *jrt.Class

var A_arbace_main_report_error_fn__461000195_A_class *jrt.Class

var A_arbace_main_report_error_fn__461000195_fn__461000196_A_class *jrt.Class

var A_arbace_main_report_error_fn__461000199_A_class *jrt.Class

var A_arbace_main_report_error_fn__461000199_fn__461000200_A_class *jrt.Class

var A_arbace_main_root_cause_A_class *jrt.Class

var A_arbace_main_script_opt_A_class *jrt.Class

var A_arbace_main_skip_if_eol_A_class *jrt.Class

var A_arbace_main_skip_whitespace_A_class *jrt.Class

var A_arbace_main_stack_element_str_A_class *jrt.Class

var A_arbace_main_with_bindings_A_class *jrt.Class

var A_arbace_main_with_read_known_A_class *jrt.Class

func A_arbace_main__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_main__init_A_Load__O()}; return nil }

func A_arbace_main__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_main__init_A_New()}; return nil }

var A_arbace_main__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_main__init_A_invoke, New: A_arbace_main__init_A_new}

var A_arbace_main__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.main__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_main.A_arbace_main__init_A", Source: "main.ae"})

func init() { i := A_arbace_main__init_A_class.Info(); i.IsInstance = A_arbace_main__init_A_InstanceOf; i.Init = A_arbace_main__init_A_Init; i.Table = A_arbace_main__init_A_members }
