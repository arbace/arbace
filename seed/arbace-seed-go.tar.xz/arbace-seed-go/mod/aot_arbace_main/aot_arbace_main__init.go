//line aot_arbace_main__init.ae:1
package aot_arbace_main

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_main__init_A_Load__O() any { A_arbace_main__init_A_Init(); A_arbace_main__init_A_Unit0__O(); A_arbace_main__init_A_Unit1__O(); A_arbace_main__init_A_Unit2__O(); A_arbace_main__init_A_Unit3__O(); A_arbace_main__init_A_Unit4__O(); A_arbace_main__init_A_Unit5__O(); A_arbace_main__init_A_Unit6__O(); A_arbace_main__init_A_Unit7__O(); A_arbace_main__init_A_Unit8__O(); A_arbace_main__init_A_Unit9__O(); A_arbace_main__init_A_Unit10__O(); A_arbace_main__init_A_Unit11__O(); A_arbace_main__init_A_Unit12__O(); A_arbace_main__init_A_Unit13__O(); A_arbace_main__init_A_Unit14__O(); A_arbace_main__init_A_Unit15__O(); A_arbace_main__init_A_Unit16__O(); A_arbace_main__init_A_Unit17__O(); A_arbace_main__init_A_Unit18__O(); A_arbace_main__init_A_Unit19__O(); A_arbace_main__init_A_Unit20__O(); A_arbace_main__init_A_Unit21__O(); A_arbace_main__init_A_Unit22__O(); A_arbace_main__init_A_Unit23__O(); A_arbace_main__init_A_Unit24__O(); A_arbace_main__init_A_Unit25__O(); A_arbace_main__init_A_Unit26__O(); A_arbace_main__init_A_Unit27__O(); A_arbace_main__init_A_Unit28__O(); A_arbace_main__init_A_Unit29__O(); A_arbace_main__init_A_Unit30__O(); A_arbace_main__init_A_Unit31__O(); A_arbace_main__init_A_Unit32__O(); A_arbace_main__init_A_Unit33__O(); A_arbace_main__init_A_Unit34__O(); A_arbace_main__init_A_Unit35__O(); A_arbace_main__init_A_Unit36__O(); A_arbace_main__init_A_Unit37__O(); A_arbace_main__init_A_Unit38__O(); A_arbace_main__init_A_Unit39__O(); A_arbace_main__init_A_Unit40__O(); A_arbace_main__init_A_Unit41__O(); A_arbace_main__init_A_Unit42__O(); A_arbace_main__init_A_Unit43__O(); A_arbace_main__init_A_Unit44__O(); A_arbace_main__init_A_Unit45__O(); return nil }





func A_arbace_main__init_A_Unit0__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); return lang.IFn_Cast(jrt.NN(A_arbace_main__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_main__init_A_const_1) }
//line :11:1
func A_arbace_main__init_A_Unit1__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_main__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_2)) }
//line :11:1
func A_arbace_main__init_A_Unit2__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); var tmp1 any = A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_New(); var tmp2 *jrt.Class; A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_Init(); tmp2 = A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :11:1
func A_arbace_main__init_A_Unit3__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_main__init_A_const_1)).Equals_O__Z(A_arbace_main__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_main_eval461000008_fn__461000009_A_New(); var tmp2 *jrt.Class; A_arbace_main_eval461000008_fn__461000009_A_Init(); tmp2 = A_arbace_main_eval461000008_fn__461000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }












func A_arbace_main__init_A_Unit4__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_5)); return A_arbace_main__init_A_const_4.Ref() }



func A_arbace_main__init_A_Unit5__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(28, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_6; var tmp2 any = A_arbace_main_demunge_A_New(); var tmp3 *jrt.Class; A_arbace_main_demunge_A_Init(); tmp3 = A_arbace_main_demunge_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_7)); return A_arbace_main__init_A_const_6.Ref() }






func A_arbace_main__init_A_Unit6__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(35, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_8; var tmp2 any = A_arbace_main_root_cause_A_New(); var tmp3 *jrt.Class; A_arbace_main_root_cause_A_Init(); tmp3 = A_arbace_main_root_cause_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_9)); return A_arbace_main__init_A_const_8.Ref() }














func A_arbace_main__init_A_Unit7__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(50, 1); jrt.NN(A_arbace_main__init_A_const_10).BindRoot_O__V(A_arbace_main__init_A_const_11); var tmp1 *lang.Var = A_arbace_main__init_A_const_10; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_12)); return A_arbace_main__init_A_const_10.Ref() }





func A_arbace_main__init_A_Unit8__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(56, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_13; var tmp2 any = A_arbace_main_core_class_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_main_core_class_QMARK__A_Init(); tmp3 = A_arbace_main_core_class_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_13; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_14)); return A_arbace_main__init_A_const_13.Ref() }





func A_arbace_main__init_A_Unit9__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(62, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_15; var tmp2 any = A_arbace_main_stack_element_str_A_New(); var tmp3 *jrt.Class; A_arbace_main_stack_element_str_A_Init(); tmp3 = A_arbace_main_stack_element_str_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_16)); return A_arbace_main__init_A_const_15.Ref() }














func A_arbace_main__init_A_Unit10__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(77, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_17; var tmp2 any = A_arbace_main_with_bindings_A_New(); var tmp3 *jrt.Class; A_arbace_main_with_bindings_A_Init(); tmp3 = A_arbace_main_with_bindings_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_main__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_18)); return A_arbace_main__init_A_const_17.Ref() }
//line :77:1
func A_arbace_main__init_A_Unit11__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(77, 1); jrt.NN(A_arbace_main__init_A_const_17).SetMacro__V(); return nil }
//line :77:1
func A_arbace_main__init_A_Unit12__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(77, 1); return A_arbace_main__init_A_const_17.Ref() }

























func A_arbace_main__init_A_Unit13__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(103, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_19; var tmp2 any = A_arbace_main_repl_prompt_A_New(); var tmp3 *jrt.Class; A_arbace_main_repl_prompt_A_Init(); tmp3 = A_arbace_main_repl_prompt_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_20)); return A_arbace_main__init_A_const_19.Ref() }




func A_arbace_main__init_A_Unit14__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(108, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_21; var tmp2 any = A_arbace_main_skip_if_eol_A_New(); var tmp3 *jrt.Class; A_arbace_main_skip_if_eol_A_Init(); tmp3 = A_arbace_main_skip_if_eol_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_21; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_22)); return A_arbace_main__init_A_const_21.Ref() }













func A_arbace_main__init_A_Unit15__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(122, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_23; var tmp2 any = A_arbace_main_skip_whitespace_A_New(); var tmp3 *jrt.Class; A_arbace_main_skip_whitespace_A_Init(); tmp3 = A_arbace_main_skip_whitespace_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_23; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_24)); return A_arbace_main__init_A_const_23.Ref() }

















func A_arbace_main__init_A_Unit16__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(140, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_25; var tmp2 any = A_arbace_main_renumbering_read_A_New(); var tmp3 *jrt.Class; A_arbace_main_renumbering_read_A_Init(); tmp3 = A_arbace_main_renumbering_read_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_25; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_26)); return A_arbace_main__init_A_const_25.Ref() }













func A_arbace_main__init_A_Unit17__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(154, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_27; var tmp2 any = A_arbace_main_repl_read_A_New(); var tmp3 *jrt.Class; A_arbace_main_repl_read_A_Init(); tmp3 = A_arbace_main_repl_read_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_27; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_28)); return A_arbace_main__init_A_const_27.Ref() }

















func A_arbace_main__init_A_Unit18__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(172, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_29; var tmp2 any = A_arbace_main_repl_exception_A_New(); var tmp3 *jrt.Class; A_arbace_main_repl_exception_A_Init(); tmp3 = A_arbace_main_repl_exception_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_29; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_30)); return A_arbace_main__init_A_const_29.Ref() }




func A_arbace_main__init_A_Unit19__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(177, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_31; var tmp2 any = A_arbace_main_file_name_A_New(); var tmp3 *jrt.Class; A_arbace_main_file_name_A_Init(); tmp3 = A_arbace_main_file_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_31; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_32)); return A_arbace_main__init_A_const_31.Ref() }







func A_arbace_main__init_A_Unit20__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(185, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_33; var tmp2 any = A_arbace_main_file_path_A_New(); var tmp3 *jrt.Class; A_arbace_main_file_path_A_Init(); tmp3 = A_arbace_main_file_path_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_33; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_34)); return A_arbace_main__init_A_const_33.Ref() }












func A_arbace_main__init_A_Unit21__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_35; var tmp2 any = A_arbace_main_java_loc__GT_source_A_New(); var tmp3 *jrt.Class; A_arbace_main_java_loc__GT_source_A_Init(); tmp3 = A_arbace_main_java_loc__GT_source_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_35; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_36)); return A_arbace_main__init_A_const_35.Ref() }









func A_arbace_main__init_A_Unit22__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(208, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_37; var tmp2 any = A_arbace_main_ex_triage_A_New(); var tmp3 *jrt.Class; A_arbace_main_ex_triage_A_Init(); tmp3 = A_arbace_main_ex_triage_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_37; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_38)); return A_arbace_main__init_A_const_37.Ref() }




























































func A_arbace_main__init_A_Unit23__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(269, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_39; var tmp2 any = A_arbace_main_ex_str_A_New(); var tmp3 *jrt.Class; A_arbace_main_ex_str_A_Init(); tmp3 = A_arbace_main_ex_str_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_39; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_40)); return A_arbace_main__init_A_const_39.Ref() }









































































func A_arbace_main__init_A_Unit24__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(343, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_41; var tmp2 any = A_arbace_main_err__GT_msg_A_New(); var tmp3 *jrt.Class; A_arbace_main_err__GT_msg_A_Init(); tmp3 = A_arbace_main_err__GT_msg_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_41; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_42)); return A_arbace_main__init_A_const_41.Ref() }




func A_arbace_main__init_A_Unit25__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(348, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_43; var tmp2 any = A_arbace_main_repl_caught_A_New(); var tmp3 *jrt.Class; A_arbace_main_repl_caught_A_Init(); tmp3 = A_arbace_main_repl_caught_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_44)); return A_arbace_main__init_A_const_43.Ref() }






func A_arbace_main__init_A_Unit26__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(355, 1); jrt.NN(A_arbace_main__init_A_const_45).BindRoot_O__V(A_arbace_main__init_A_const_46); var tmp1 *lang.Var = A_arbace_main__init_A_const_45; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_47)); return A_arbace_main__init_A_const_45.Ref() }



func A_arbace_main__init_A_Unit27__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(359, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_48; var tmp2 any = A_arbace_main_with_read_known_A_New(); var tmp3 *jrt.Class; A_arbace_main_with_read_known_A_Init(); tmp3 = A_arbace_main_with_read_known_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_main__init_A_const_48; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_49)); return A_arbace_main__init_A_const_48.Ref() }
//line :359:1
func A_arbace_main__init_A_Unit28__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(359, 1); jrt.NN(A_arbace_main__init_A_const_48).SetMacro__V(); return nil }
//line :359:1
func A_arbace_main__init_A_Unit29__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(359, 1); return A_arbace_main__init_A_const_48.Ref() }






func A_arbace_main__init_A_Unit30__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(366, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_50; var tmp2 any = A_arbace_main_repl_A_New(); var tmp3 *jrt.Class; A_arbace_main_repl_A_Init(); tmp3 = A_arbace_main_repl_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_main__init_A_const_50; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_51)); return A_arbace_main__init_A_const_50.Ref() }




































































































func A_arbace_main__init_A_Unit31__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(467, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_52; var tmp2 any = A_arbace_main_load_script_A_New(); var tmp3 *jrt.Class; A_arbace_main_load_script_A_Init(); tmp3 = A_arbace_main_load_script_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_52; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_53)); return A_arbace_main__init_A_const_52.Ref() }














func A_arbace_main__init_A_Unit32__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(482, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_54; var tmp2 any = A_arbace_main_init_opt_A_New(); var tmp3 *jrt.Class; A_arbace_main_init_opt_A_Init(); tmp3 = A_arbace_main_init_opt_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_54; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_55)); return A_arbace_main__init_A_const_54.Ref() }




func A_arbace_main__init_A_Unit33__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(487, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_56; var tmp2 any = A_arbace_main_eval_opt_A_New(); var tmp3 *jrt.Class; A_arbace_main_eval_opt_A_Init(); tmp3 = A_arbace_main_eval_opt_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_56; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_57)); return A_arbace_main__init_A_const_56.Ref() }











func A_arbace_main__init_A_Unit34__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(499, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_58; var tmp2 any = A_arbace_main_init_dispatch_A_New(); var tmp3 *jrt.Class; A_arbace_main_init_dispatch_A_Init(); tmp3 = A_arbace_main_init_dispatch_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_58; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_59)); return A_arbace_main__init_A_const_58.Ref() }







func A_arbace_main__init_A_Unit35__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(507, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_60; var tmp2 any = A_arbace_main_initialize_A_New(); var tmp3 *jrt.Class; A_arbace_main_initialize_A_Init(); tmp3 = A_arbace_main_initialize_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_60; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_61)); return A_arbace_main__init_A_const_60.Ref() }







func A_arbace_main__init_A_Unit36__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(515, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_62; var tmp2 any = A_arbace_main_main_opt_A_New(); var tmp3 *jrt.Class; A_arbace_main_main_opt_A_Init(); tmp3 = A_arbace_main_main_opt_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_62; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_63)); return A_arbace_main__init_A_const_62.Ref() }







func A_arbace_main__init_A_Unit37__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(523, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_64; var tmp2 any = A_arbace_main_repl_opt_A_New(); var tmp3 *jrt.Class; A_arbace_main_repl_opt_A_Init(); tmp3 = A_arbace_main_repl_opt_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_64; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_65)); return A_arbace_main__init_A_const_64.Ref() }













func A_arbace_main__init_A_Unit38__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(537, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_66; var tmp2 any = A_arbace_main_script_opt_A_New(); var tmp3 *jrt.Class; A_arbace_main_script_opt_A_Init(); tmp3 = A_arbace_main_script_opt_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_66; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_67)); return A_arbace_main__init_A_const_66.Ref() }








func A_arbace_main__init_A_Unit39__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(546, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_68; var tmp2 any = A_arbace_main_null_opt_A_New(); var tmp3 *jrt.Class; A_arbace_main_null_opt_A_Init(); tmp3 = A_arbace_main_null_opt_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_68; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_69)); return A_arbace_main__init_A_const_68.Ref() }





func A_arbace_main__init_A_Unit40__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(552, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_70; var tmp2 any = A_arbace_main_help_opt_A_New(); var tmp3 *jrt.Class; A_arbace_main_help_opt_A_Init(); tmp3 = A_arbace_main_help_opt_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_70; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_71)); return A_arbace_main__init_A_const_70.Ref() }




func A_arbace_main__init_A_Unit41__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(557, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_72; var tmp2 any = A_arbace_main_main_dispatch_A_New(); var tmp3 *jrt.Class; A_arbace_main_main_dispatch_A_Init(); tmp3 = A_arbace_main_main_dispatch_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_72; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_73)); return A_arbace_main__init_A_const_72.Ref() }













func A_arbace_main__init_A_Unit42__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(571, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_74; var tmp2 any = A_arbace_main_legacy_repl_A_New(); var tmp3 *jrt.Class; A_arbace_main_legacy_repl_A_Init(); tmp3 = A_arbace_main_legacy_repl_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_74; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_75)); return A_arbace_main__init_A_const_74.Ref() }









func A_arbace_main__init_A_Unit43__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(581, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_76; var tmp2 any = A_arbace_main_legacy_script_A_New(); var tmp3 *jrt.Class; A_arbace_main_legacy_script_A_Init(); tmp3 = A_arbace_main_legacy_script_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_main__init_A_const_76; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_77)); return A_arbace_main__init_A_const_76.Ref() }









func A_arbace_main__init_A_Unit44__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(591, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_78; var tmp2 any = A_arbace_main_report_error_A_New(); var tmp3 *jrt.Class; A_arbace_main_report_error_A_Init(); tmp3 = A_arbace_main_report_error_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_main__init_A_const_78; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_79)); return A_arbace_main__init_A_const_78.Ref() }































func A_arbace_main__init_A_Unit45__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(623, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_4; var tmp2 any = A_arbace_main_main_A_New(); var tmp3 *jrt.Class; A_arbace_main_main_A_Init(); tmp3 = A_arbace_main_main_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_main__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_80)); return A_arbace_main__init_A_const_4.Ref() }



type A_arbace_main__init_A struct{ jrt.Object }

var A_arbace_main__init_A_const_0 *lang.Var

var A_arbace_main__init_A_const_1 any

var A_arbace_main__init_A_const_2 any

var A_arbace_main__init_A_const_3 any

var A_arbace_main__init_A_const_4 *lang.Var

var A_arbace_main__init_A_const_5 any

var A_arbace_main__init_A_const_6 *lang.Var

var A_arbace_main__init_A_const_7 any

var A_arbace_main__init_A_const_8 *lang.Var

var A_arbace_main__init_A_const_9 any

var A_arbace_main__init_A_const_10 *lang.Var

var A_arbace_main__init_A_const_11 any

var A_arbace_main__init_A_const_12 any

var A_arbace_main__init_A_const_13 *lang.Var

var A_arbace_main__init_A_const_14 any

var A_arbace_main__init_A_const_15 *lang.Var

var A_arbace_main__init_A_const_16 any

var A_arbace_main__init_A_const_17 *lang.Var

var A_arbace_main__init_A_const_18 any

var A_arbace_main__init_A_const_19 *lang.Var

var A_arbace_main__init_A_const_20 any

var A_arbace_main__init_A_const_21 *lang.Var

var A_arbace_main__init_A_const_22 any

var A_arbace_main__init_A_const_23 *lang.Var

var A_arbace_main__init_A_const_24 any

var A_arbace_main__init_A_const_25 *lang.Var

var A_arbace_main__init_A_const_26 any

var A_arbace_main__init_A_const_27 *lang.Var

var A_arbace_main__init_A_const_28 any

var A_arbace_main__init_A_const_29 *lang.Var

var A_arbace_main__init_A_const_30 any

var A_arbace_main__init_A_const_31 *lang.Var

var A_arbace_main__init_A_const_32 any

var A_arbace_main__init_A_const_33 *lang.Var

var A_arbace_main__init_A_const_34 any

var A_arbace_main__init_A_const_35 *lang.Var

var A_arbace_main__init_A_const_36 any

var A_arbace_main__init_A_const_37 *lang.Var

var A_arbace_main__init_A_const_38 any

var A_arbace_main__init_A_const_39 *lang.Var

var A_arbace_main__init_A_const_40 any

var A_arbace_main__init_A_const_41 *lang.Var

var A_arbace_main__init_A_const_42 any

var A_arbace_main__init_A_const_43 *lang.Var

var A_arbace_main__init_A_const_44 any

var A_arbace_main__init_A_const_45 *lang.Var

var A_arbace_main__init_A_const_46 any

var A_arbace_main__init_A_const_47 any

var A_arbace_main__init_A_const_48 *lang.Var

var A_arbace_main__init_A_const_49 any

var A_arbace_main__init_A_const_50 *lang.Var

var A_arbace_main__init_A_const_51 any

var A_arbace_main__init_A_const_52 *lang.Var

var A_arbace_main__init_A_const_53 any

var A_arbace_main__init_A_const_54 *lang.Var

var A_arbace_main__init_A_const_55 any

var A_arbace_main__init_A_const_56 *lang.Var

var A_arbace_main__init_A_const_57 any

var A_arbace_main__init_A_const_58 *lang.Var

var A_arbace_main__init_A_const_59 any

var A_arbace_main__init_A_const_60 *lang.Var

var A_arbace_main__init_A_const_61 any

var A_arbace_main__init_A_const_62 *lang.Var

var A_arbace_main__init_A_const_63 any

var A_arbace_main__init_A_const_64 *lang.Var

var A_arbace_main__init_A_const_65 any

var A_arbace_main__init_A_const_66 *lang.Var

var A_arbace_main__init_A_const_67 any

var A_arbace_main__init_A_const_68 *lang.Var

var A_arbace_main__init_A_const_69 any

var A_arbace_main__init_A_const_70 *lang.Var

var A_arbace_main__init_A_const_71 any

var A_arbace_main__init_A_const_72 *lang.Var

var A_arbace_main__init_A_const_73 any

var A_arbace_main__init_A_const_74 *lang.Var

var A_arbace_main__init_A_const_75 any

var A_arbace_main__init_A_const_76 *lang.Var

var A_arbace_main__init_A_const_77 any

var A_arbace_main__init_A_const_78 *lang.Var

var A_arbace_main__init_A_const_79 any

var A_arbace_main__init_A_const_80 any

var A_arbace_main__init_A_init jrt.ClassInit

func A_arbace_main__init_A_Init() { if !A_arbace_main__init_A_init.Done() { A_arbace_main__init_A_init.Run(A_arbace_main__init_A_clinit) } }

func A_arbace_main__init_A_clinit() { A_arbace_main__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_163); A_arbace_main__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_main__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15)); A_arbace_main__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_main__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_11, Lit_178); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_323).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_main__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(24).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_11, Lit_24); A_arbace_main__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_326).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_327, lang.RT_Keyword_String_String__Keyword(nil, Lit_328).Ref(), Lit_329, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(28).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_11, Lit_70); A_arbace_main__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_330)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_331).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_332).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_333, lang.RT_Keyword_String_String__Keyword(nil, Lit_328).Ref(), Lit_329, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(35).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_11, Lit_20); A_arbace_main__init_A_const_11 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,22,s11:arbace.mains10:arbace.xmls20:arbace.core.reducerss14:arbace.java.ios13:arbace.datafys22:arbace.spec.test.alphas11:arbace.datas10:arbace.edns11:arbace.walks14:arbace.instants13:arbace.pprints11:arbace.uuids11:arbace.cores10:arbace.zips17:arbace.spec.alphas21:arbace.spec.gen.alphas15:arbace.templates14:arbace.reflects11:arbace.repls10:arbace.sets13:arbace.strings21:arbace.core.protocols", []*jrt.Class{jrt.Object_class})).Ref(); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_main__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(50).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_11, Lit_112); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_main__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_335)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_331).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_336).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(56).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_11, Lit_337); A_arbace_main__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_338)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_331).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_339).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_340, lang.RT_Keyword_String_String__Keyword(nil, Lit_328).Ref(), Lit_329, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(62).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_11, Lit_4); A_arbace_main__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_342, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(77).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_11, Lit_143); A_arbace_main__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_343, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(103).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_11, Lit_69); A_arbace_main__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_344).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_345, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(108).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_11, Lit_65); A_arbace_main__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_344).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_346, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(122).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_11, Lit_64); A_arbace_main__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_347).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_348)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_331).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_349).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_350).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_351, lang.RT_Keyword_String_String__Keyword(nil, Lit_328).Ref(), Lit_352, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(140).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_11, Lit_144); A_arbace_main__init_A_const_28 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_353).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_354).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_355, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(154).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_29 = lang.RT_Var_String_String__Var(Lit_11, Lit_356); A_arbace_main__init_A_const_30 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_357).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_358, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(172).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_31 = lang.RT_Var_String_String__Var(Lit_11, Lit_104); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_main__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_359)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_331).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_336).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_360, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(177).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_33 = lang.RT_Var_String_String__Var(Lit_11, Lit_106); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_main__init_A_const_34 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_359)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_331).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_336).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_361, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(185).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_35 = lang.RT_Var_String_String__Var(Lit_11, Lit_115); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_main__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_362).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_363).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_364, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(198).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_37 = lang.RT_Var_String_String__Var(Lit_11, Lit_132); A_arbace_main__init_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_365).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_366, lang.RT_Keyword_String_String__Keyword(nil, Lit_328).Ref(), Lit_352, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(208).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_39 = lang.RT_Var_String_String__Var(Lit_11, Lit_131); A_arbace_main__init_A_const_40 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(Lit_94, Lit_367).Ref(), lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_105).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref())), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_368).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_369, lang.RT_Keyword_String_String__Keyword(nil, Lit_328).Ref(), Lit_352, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(269).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_11, Lit_137); A_arbace_main__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_370)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_331).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_332).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_371, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(343).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_11, Lit_147); A_arbace_main__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_370).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_372, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(348).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_11, Lit_176); A_arbace_main__init_A_const_46 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_373).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_1).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_374).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_375).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_376).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_377).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(357).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(25).Ref()))))); A_arbace_main__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_378, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(355).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_11, Lit_379); A_arbace_main__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_380, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(359).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_50 = lang.RT_Var_String_String__Var(Lit_11, Lit_172); A_arbace_main__init_A_const_51 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_381).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_382, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(366).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_52 = lang.RT_Var_String_String__Var(Lit_11, Lit_158); A_arbace_main__init_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_105)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_331).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_336).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_383, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(467).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_54 = lang.RT_Var_String_String__Var(Lit_11, Lit_159); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_main__init_A_const_55 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_105).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_384, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(482).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_56 = lang.RT_Var_String_String__Var(Lit_11, Lit_160); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_main__init_A_const_57 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_385, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(487).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_58 = lang.RT_Var_String_String__Var(Lit_11, Lit_165); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_main__init_A_const_59 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_386).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_387, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(499).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_60 = lang.RT_Var_String_String__Var(Lit_11, Lit_167); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_main__init_A_const_61 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_388).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_389).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_390, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(507).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_62 = lang.RT_Var_String_String__Var(Lit_11, Lit_180); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_main__init_A_const_63 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_391).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_392).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_388).Ref()), lang.Symbol_Intern_String_String__Symbol(nil, Lit_389).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_393, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(515).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_64 = lang.RT_Var_String_String__Var(Lit_11, Lit_179); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_main__init_A_const_65 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_391).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_388).Ref()), lang.Symbol_Intern_String_String__Symbol(nil, Lit_389).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_394, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(523).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_66 = lang.RT_Var_String_String__Var(Lit_11, Lit_183); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_main__init_A_const_67 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_105).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_388).Ref()), lang.Symbol_Intern_String_String__Symbol(nil, Lit_389).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_395, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(537).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_68 = lang.RT_Var_String_String__Var(Lit_11, Lit_181); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_main__init_A_const_69 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_388).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_389).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_396, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(546).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_70 = lang.RT_Var_String_String__Var(Lit_11, Lit_182); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_main__init_A_const_71 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_391).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_391).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_397, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(552).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_72 = lang.RT_Var_String_String__Var(Lit_11, Lit_193); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_main__init_A_const_73 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_386).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_398, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(557).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_74 = lang.RT_Var_String_String__Var(Lit_11, Lit_399); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_main__init_A_const_75 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_388).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_400, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(571).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_76 = lang.RT_Var_String_String__Var(Lit_11, Lit_401); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp53.Ref(); A_arbace_main__init_A_const_77 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_388).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_402, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(581).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_78 = lang.RT_Var_String_String__Var(Lit_11, Lit_195); A_arbace_main__init_A_const_79 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_330)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_331).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_332).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_367).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_189).Ref()), lang.RT_Keyword_String_String__Keyword(nil, Lit_403).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_189).Ref(), Lit_114)), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_347).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_404, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(591).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)); A_arbace_main__init_A_const_80 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_325).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_388).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_405, lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Integer_ValueOf_I__Integer(623).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_114).Ref(), Lit_324)) }

func A_arbace_main__init_A_New() *A_arbace_main__init_A { A_arbace_main__init_A_Init(); t := &A_arbace_main__init_A{}; t.Ctor(); return t }

func (t *A_arbace_main__init_A) Ctor() {}

func (t *A_arbace_main__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main__init_A) GetClass__Class() *jrt.Class { return A_arbace_main__init_A_class }

func (t *A_arbace_main__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main__init_A); return ok }

func A_arbace_main__init_A_Cast(x any) *A_arbace_main__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main__init_A_class)) }; return v }
