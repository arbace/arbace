//line aot_arbace_main__init.ae:1
package aot_arbace_main

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_main__init_A_Load__O() any { A_arbace_main__init_A_Init(); jrt.StartCheck(); A_arbace_main__init_A_Unit0__O(); A_arbace_main__init_A_Unit1__O(); A_arbace_main__init_A_Unit2__O(); A_arbace_main__init_A_Unit3__O(); A_arbace_main__init_A_Unit4__O(); A_arbace_main__init_A_Unit5__O(); A_arbace_main__init_A_Unit6__O(); A_arbace_main__init_A_Unit7__O(); A_arbace_main__init_A_Unit8__O(); A_arbace_main__init_A_Unit9__O(); A_arbace_main__init_A_Unit10__O(); A_arbace_main__init_A_Unit11__O(); A_arbace_main__init_A_Unit12__O(); A_arbace_main__init_A_Unit13__O(); A_arbace_main__init_A_Unit14__O(); A_arbace_main__init_A_Unit15__O(); A_arbace_main__init_A_Unit16__O(); A_arbace_main__init_A_Unit17__O(); A_arbace_main__init_A_Unit18__O(); A_arbace_main__init_A_Unit19__O(); A_arbace_main__init_A_Unit20__O(); A_arbace_main__init_A_Unit21__O(); A_arbace_main__init_A_Unit22__O(); A_arbace_main__init_A_Unit23__O(); A_arbace_main__init_A_Unit24__O(); A_arbace_main__init_A_Unit25__O(); A_arbace_main__init_A_Unit26__O(); A_arbace_main__init_A_Unit27__O(); A_arbace_main__init_A_Unit28__O(); A_arbace_main__init_A_Unit29__O(); A_arbace_main__init_A_Unit30__O(); A_arbace_main__init_A_Unit31__O(); A_arbace_main__init_A_Unit32__O(); A_arbace_main__init_A_Unit33__O(); A_arbace_main__init_A_Unit34__O(); A_arbace_main__init_A_Unit35__O(); A_arbace_main__init_A_Unit36__O(); A_arbace_main__init_A_Unit37__O(); A_arbace_main__init_A_Unit38__O(); A_arbace_main__init_A_Unit39__O(); A_arbace_main__init_A_Unit40__O(); A_arbace_main__init_A_Unit41__O(); A_arbace_main__init_A_Unit42__O(); A_arbace_main__init_A_Unit43__O(); A_arbace_main__init_A_Unit44__O(); A_arbace_main__init_A_Unit45__O(); return nil }





func A_arbace_main__init_A_Unit0__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(11, 1); return lang.IFn_Cast(A_arbace_main__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_main__init_A_const_1) }
//line :11:1
func A_arbace_main__init_A_Unit1__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(11, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_main__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_2)) }
//line :11:1
func A_arbace_main__init_A_Unit2__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(11, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, nil); A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :11:1
func A_arbace_main__init_A_Unit3__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(11, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_main__init_A_const_1)).Equals_O__Z(A_arbace_main__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_main_eval461000008_fn__461000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_main_eval461000008_fn__461000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, nil); A_arbace_main_eval461000008_fn__461000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }












func A_arbace_main__init_A_Unit4__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_5)); return A_arbace_main__init_A_const_4 }



func A_arbace_main__init_A_Unit5__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_main_demunge_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_main_demunge_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, false, nil); A_arbace_main_demunge_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_7)); return A_arbace_main__init_A_const_6 }






func A_arbace_main__init_A_Unit6__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_main_root_cause_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_main_root_cause_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, nil); A_arbace_main_root_cause_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_9)); return A_arbace_main__init_A_const_8 }














func A_arbace_main__init_A_Unit7__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); A_arbace_main__init_A_const_10.BindRoot_O__V(A_arbace_main__init_A_const_11); var tmp1 *lang.Var = A_arbace_main__init_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_12)); return A_arbace_main__init_A_const_10 }





func A_arbace_main__init_A_Unit8__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_main_core_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_main_core_class_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, nil); A_arbace_main_core_class_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_14)); return A_arbace_main__init_A_const_13 }





func A_arbace_main__init_A_Unit9__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_main_stack_element_str_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_main_stack_element_str_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_103, false, nil); A_arbace_main_stack_element_str_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_16)); return A_arbace_main__init_A_const_15 }














func A_arbace_main__init_A_Unit10__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(77, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_17; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__14 any = A_arbace_main_with_bindings_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_main_with_bindings_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_104, true, nil); A_arbace_main_with_bindings_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__14, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_18)); return A_arbace_main__init_A_const_17 }
//line :77:1
func A_arbace_main__init_A_Unit11__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(77, 1); A_arbace_main__init_A_const_17.SetMacro__V(); return nil }
//line :77:1
func A_arbace_main__init_A_Unit12__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(77, 1); return A_arbace_main__init_A_const_17 }

























func A_arbace_main__init_A_Unit13__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_main_repl_prompt_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_main_repl_prompt_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, nil); A_arbace_main_repl_prompt_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_20)); return A_arbace_main__init_A_const_19 }




func A_arbace_main__init_A_Unit14__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(108, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_main_skip_if_eol_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_main_skip_if_eol_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, nil); A_arbace_main_skip_if_eol_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_22)); return A_arbace_main__init_A_const_21 }













func A_arbace_main__init_A_Unit15__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(122, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_main_skip_whitespace_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_main_skip_whitespace_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_107, false, nil); A_arbace_main_skip_whitespace_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_24)); return A_arbace_main__init_A_const_23 }

















func A_arbace_main__init_A_Unit16__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(140, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_main_renumbering_read_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_main_renumbering_read_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_108, false, nil); A_arbace_main_renumbering_read_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_26)); return A_arbace_main__init_A_const_25 }













func A_arbace_main__init_A_Unit17__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(154, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_main_repl_read_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_main_repl_read_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_109, false, nil); A_arbace_main_repl_read_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_28)); return A_arbace_main__init_A_const_27 }

















func A_arbace_main__init_A_Unit18__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(172, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_main_repl_exception_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_main_repl_exception_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_110, false, nil); A_arbace_main_repl_exception_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_30)); return A_arbace_main__init_A_const_29 }




func A_arbace_main__init_A_Unit19__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_main_file_name_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_main_file_name_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_111, false, nil); A_arbace_main_file_name_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_32)); return A_arbace_main__init_A_const_31 }







func A_arbace_main__init_A_Unit20__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(185, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_main_file_path_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_main_file_path_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_112, false, nil); A_arbace_main_file_path_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_34)); return A_arbace_main__init_A_const_33 }












func A_arbace_main__init_A_Unit21__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_main_java_loc__GT_source_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_main_java_loc__GT_source_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_113, false, nil); A_arbace_main_java_loc__GT_source_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_36)); return A_arbace_main__init_A_const_35 }









func A_arbace_main__init_A_Unit22__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(208, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_main_ex_triage_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_main_ex_triage_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_114, false, nil); A_arbace_main_ex_triage_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_38)); return A_arbace_main__init_A_const_37 }


































































func A_arbace_main__init_A_Unit23__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(275, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_main_ex_str_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_main_ex_str_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_115, false, nil); A_arbace_main_ex_str_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_40)); return A_arbace_main__init_A_const_39 }









































































func A_arbace_main__init_A_Unit24__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(349, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_main_err__GT_msg_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_main_err__GT_msg_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_116, false, nil); A_arbace_main_err__GT_msg_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_42)); return A_arbace_main__init_A_const_41 }




func A_arbace_main__init_A_Unit25__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(354, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_main_repl_caught_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_main_repl_caught_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_117, false, nil); A_arbace_main_repl_caught_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_44)); return A_arbace_main__init_A_const_43 }






func A_arbace_main__init_A_Unit26__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(361, 1); A_arbace_main__init_A_const_45.BindRoot_O__V(A_arbace_main__init_A_const_46); var tmp1 *lang.Var = A_arbace_main__init_A_const_45; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_47)); return A_arbace_main__init_A_const_45 }



func A_arbace_main__init_A_Unit27__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(365, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_48; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__42 any = A_arbace_main_with_read_known_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_main_with_read_known_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_118, true, nil); A_arbace_main_with_read_known_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__42, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_49)); return A_arbace_main__init_A_const_48 }
//line :365:1
func A_arbace_main__init_A_Unit28__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(365, 1); A_arbace_main__init_A_const_48.SetMacro__V(); return nil }
//line :365:1
func A_arbace_main__init_A_Unit29__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(365, 1); return A_arbace_main__init_A_const_48 }






func A_arbace_main__init_A_Unit30__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(372, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_50; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__44 any = A_arbace_main_repl_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_main_repl_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, true, nil); A_arbace_main_repl_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__44, tmp3, nil, 0); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_51)); return A_arbace_main__init_A_const_50 }




































































































func A_arbace_main__init_A_Unit31__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(473, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_main_load_script_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_main_load_script_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, nil); A_arbace_main_load_script_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_53)); return A_arbace_main__init_A_const_52 }














func A_arbace_main__init_A_Unit32__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(488, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_main_init_opt_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_main_init_opt_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, nil); A_arbace_main_init_opt_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_55)); return A_arbace_main__init_A_const_54 }




func A_arbace_main__init_A_Unit33__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(493, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_main_eval_opt_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_main_eval_opt_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, nil); A_arbace_main_eval_opt_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_57)); return A_arbace_main__init_A_const_56 }











func A_arbace_main__init_A_Unit34__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(505, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_main_init_dispatch_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_main_init_dispatch_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_123, false, nil); A_arbace_main_init_dispatch_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_59)); return A_arbace_main__init_A_const_58 }







func A_arbace_main__init_A_Unit35__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_main_initialize_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_main_initialize_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, nil); A_arbace_main_initialize_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_61)); return A_arbace_main__init_A_const_60 }







func A_arbace_main__init_A_Unit36__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(521, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_main_main_opt_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_main_main_opt_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_125, false, nil); A_arbace_main_main_opt_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_63)); return A_arbace_main__init_A_const_62 }







func A_arbace_main__init_A_Unit37__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(529, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_main_repl_opt_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_main_repl_opt_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_126, false, nil); A_arbace_main_repl_opt_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_65)); return A_arbace_main__init_A_const_64 }













func A_arbace_main__init_A_Unit38__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(543, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_main_script_opt_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_main_script_opt_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_127, false, nil); A_arbace_main_script_opt_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_67)); return A_arbace_main__init_A_const_66 }








func A_arbace_main__init_A_Unit39__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(552, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_main_null_opt_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_main_null_opt_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_128, false, nil); A_arbace_main_null_opt_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_69)); return A_arbace_main__init_A_const_68 }





func A_arbace_main__init_A_Unit40__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(558, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_main_help_opt_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_main_help_opt_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_129, false, nil); A_arbace_main_help_opt_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_71)); return A_arbace_main__init_A_const_70 }




func A_arbace_main__init_A_Unit41__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(563, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_main_main_dispatch_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_main_main_dispatch_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_130, false, nil); A_arbace_main_main_dispatch_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_73)); return A_arbace_main__init_A_const_72 }













func A_arbace_main__init_A_Unit42__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(577, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_main_legacy_repl_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_main_legacy_repl_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_131, false, nil); A_arbace_main_legacy_repl_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_75)); return A_arbace_main__init_A_const_74 }









func A_arbace_main__init_A_Unit43__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(587, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_main_legacy_script_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_main_legacy_script_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_132, false, nil); A_arbace_main_legacy_script_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_77)); return A_arbace_main__init_A_const_76 }









func A_arbace_main__init_A_Unit44__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(597, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_78; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__72 any = A_arbace_main_report_error_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_main_report_error_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_133, true, nil); A_arbace_main_report_error_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__72, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_79)); return A_arbace_main__init_A_const_78 }































func A_arbace_main__init_A_Unit45__O() any { A_arbace_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(629, 1); var tmp1 *lang.Var = A_arbace_main__init_A_const_4; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__74 any = A_arbace_main_main_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_main_main_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, true, nil); A_arbace_main_main_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__74, tmp3, nil, 0); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_main__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_main__init_A_const_80)); return A_arbace_main__init_A_const_4 }



type A_arbace_main__init_A struct{ jrt.Object }

var A_arbace_main__init_A_const_pool *jrt.RefArray

var A_arbace_main__init_A_const_0 *lang.Var

var A_arbace_main__init_A_const_1 any

var A_arbace_main__init_A_const_2 any

var A_arbace_main__init_A_const_3 any

var A_arbace_main__init_A_const_4 *lang.Var

var A_arbace_main__init_A_const_5 any

var A_arbace_main__init_A_const_6 *lang.Var

var A_arbace_main__init_A_const_7 any

var A_arbace_main__init_A_const_8 *lang.Var

var A_arbace_main__init_A_const_9 any

var A_arbace_main__init_A_const_10 *lang.Var

var A_arbace_main__init_A_const_11 any

var A_arbace_main__init_A_const_12 any

var A_arbace_main__init_A_const_13 *lang.Var

var A_arbace_main__init_A_const_14 any

var A_arbace_main__init_A_const_15 *lang.Var

var A_arbace_main__init_A_const_16 any

var A_arbace_main__init_A_const_17 *lang.Var

var A_arbace_main__init_A_const_18 any

var A_arbace_main__init_A_const_19 *lang.Var

var A_arbace_main__init_A_const_20 any

var A_arbace_main__init_A_const_21 *lang.Var

var A_arbace_main__init_A_const_22 any

var A_arbace_main__init_A_const_23 *lang.Var

var A_arbace_main__init_A_const_24 any

var A_arbace_main__init_A_const_25 *lang.Var

var A_arbace_main__init_A_const_26 any

var A_arbace_main__init_A_const_27 *lang.Var

var A_arbace_main__init_A_const_28 any

var A_arbace_main__init_A_const_29 *lang.Var

var A_arbace_main__init_A_const_30 any

var A_arbace_main__init_A_const_31 *lang.Var

var A_arbace_main__init_A_const_32 any

var A_arbace_main__init_A_const_33 *lang.Var

var A_arbace_main__init_A_const_34 any

var A_arbace_main__init_A_const_35 *lang.Var

var A_arbace_main__init_A_const_36 any

var A_arbace_main__init_A_const_37 *lang.Var

var A_arbace_main__init_A_const_38 any

var A_arbace_main__init_A_const_39 *lang.Var

var A_arbace_main__init_A_const_40 any

var A_arbace_main__init_A_const_41 *lang.Var

var A_arbace_main__init_A_const_42 any

var A_arbace_main__init_A_const_43 *lang.Var

var A_arbace_main__init_A_const_44 any

var A_arbace_main__init_A_const_45 *lang.Var

var A_arbace_main__init_A_const_46 any

var A_arbace_main__init_A_const_47 any

var A_arbace_main__init_A_const_48 *lang.Var

var A_arbace_main__init_A_const_49 any

var A_arbace_main__init_A_const_50 *lang.Var

var A_arbace_main__init_A_const_51 any

var A_arbace_main__init_A_const_52 *lang.Var

var A_arbace_main__init_A_const_53 any

var A_arbace_main__init_A_const_54 *lang.Var

var A_arbace_main__init_A_const_55 any

var A_arbace_main__init_A_const_56 *lang.Var

var A_arbace_main__init_A_const_57 any

var A_arbace_main__init_A_const_58 *lang.Var

var A_arbace_main__init_A_const_59 any

var A_arbace_main__init_A_const_60 *lang.Var

var A_arbace_main__init_A_const_61 any

var A_arbace_main__init_A_const_62 *lang.Var

var A_arbace_main__init_A_const_63 any

var A_arbace_main__init_A_const_64 *lang.Var

var A_arbace_main__init_A_const_65 any

var A_arbace_main__init_A_const_66 *lang.Var

var A_arbace_main__init_A_const_67 any

var A_arbace_main__init_A_const_68 *lang.Var

var A_arbace_main__init_A_const_69 any

var A_arbace_main__init_A_const_70 *lang.Var

var A_arbace_main__init_A_const_71 any

var A_arbace_main__init_A_const_72 *lang.Var

var A_arbace_main__init_A_const_73 any

var A_arbace_main__init_A_const_74 *lang.Var

var A_arbace_main__init_A_const_75 any

var A_arbace_main__init_A_const_76 *lang.Var

var A_arbace_main__init_A_const_77 any

var A_arbace_main__init_A_const_78 *lang.Var

var A_arbace_main__init_A_const_79 any

var A_arbace_main__init_A_const_80 any

var A_arbace_main__init_A_init jrt.ClassInit

func A_arbace_main__init_A_Init() { if !A_arbace_main__init_A_init.Done() { A_arbace_main__init_A_init.Run(A_arbace_main__init_A_clinit) } }

func A_arbace_main__init_A_clinit() { A_arbace_main__init_A_clinit_p0(); A_arbace_main__init_A_clinit_p1(); A_arbace_main__init_A_clinit_p2(); A_arbace_main__init_A_clinit_p3(); A_arbace_main__init_A_clinit_p4(); A_arbace_main__init_A_clinit_p5(); A_arbace_main__init_A_clinit_p6() }

func A_arbace_main__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_main__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_97, 138); A_arbace_main__init_A_const_0 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[57]); A_arbace_main__init_A_const_1 = A_arbace_main__init_A_const_pool.A[58]; A_arbace_main__init_A_const_2 = A_arbace_main__init_A_const_pool.A[59]; A_arbace_main__init_A_const_3 = A_arbace_main__init_A_const_pool.A[60]; A_arbace_main__init_A_const_4 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[61]); A_arbace_main__init_A_const_5 = A_arbace_main__init_A_const_pool.A[62]; A_arbace_main__init_A_const_6 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[63]); A_arbace_main__init_A_const_7 = A_arbace_main__init_A_const_pool.A[64]; A_arbace_main__init_A_const_8 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[65]); A_arbace_main__init_A_const_9 = A_arbace_main__init_A_const_pool.A[66]; A_arbace_main__init_A_const_10 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[67]); A_arbace_main__init_A_const_11 = A_arbace_main__init_A_const_pool.A[68]; A_arbace_main__init_A_const_12 = A_arbace_main__init_A_const_pool.A[69] }

func A_arbace_main__init_A_clinit_p1() { A_arbace_main__init_A_const_13 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[70]); A_arbace_main__init_A_const_14 = A_arbace_main__init_A_const_pool.A[71]; A_arbace_main__init_A_const_15 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[72]); A_arbace_main__init_A_const_16 = A_arbace_main__init_A_const_pool.A[73]; A_arbace_main__init_A_const_17 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[74]); A_arbace_main__init_A_const_18 = A_arbace_main__init_A_const_pool.A[75]; A_arbace_main__init_A_const_19 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[76]); A_arbace_main__init_A_const_20 = A_arbace_main__init_A_const_pool.A[77]; A_arbace_main__init_A_const_21 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[78]); A_arbace_main__init_A_const_22 = A_arbace_main__init_A_const_pool.A[79]; A_arbace_main__init_A_const_23 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[80]); A_arbace_main__init_A_const_24 = A_arbace_main__init_A_const_pool.A[81]; A_arbace_main__init_A_const_25 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[82]) }

func A_arbace_main__init_A_clinit_p2() { A_arbace_main__init_A_const_26 = A_arbace_main__init_A_const_pool.A[83]; A_arbace_main__init_A_const_27 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[84]); A_arbace_main__init_A_const_28 = A_arbace_main__init_A_const_pool.A[85]; A_arbace_main__init_A_const_29 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[86]); A_arbace_main__init_A_const_30 = A_arbace_main__init_A_const_pool.A[87]; A_arbace_main__init_A_const_31 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[88]); A_arbace_main__init_A_const_32 = A_arbace_main__init_A_const_pool.A[89]; A_arbace_main__init_A_const_33 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[90]); A_arbace_main__init_A_const_34 = A_arbace_main__init_A_const_pool.A[91]; A_arbace_main__init_A_const_35 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[92]); A_arbace_main__init_A_const_36 = A_arbace_main__init_A_const_pool.A[93]; A_arbace_main__init_A_const_37 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[94]); A_arbace_main__init_A_const_38 = A_arbace_main__init_A_const_pool.A[95] }

func A_arbace_main__init_A_clinit_p3() { A_arbace_main__init_A_const_39 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[96]); A_arbace_main__init_A_const_40 = A_arbace_main__init_A_const_pool.A[97]; A_arbace_main__init_A_const_41 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[98]); A_arbace_main__init_A_const_42 = A_arbace_main__init_A_const_pool.A[99]; A_arbace_main__init_A_const_43 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[100]); A_arbace_main__init_A_const_44 = A_arbace_main__init_A_const_pool.A[101]; A_arbace_main__init_A_const_45 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[102]); A_arbace_main__init_A_const_46 = A_arbace_main__init_A_const_pool.A[103]; A_arbace_main__init_A_const_47 = A_arbace_main__init_A_const_pool.A[104]; A_arbace_main__init_A_const_48 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[105]); A_arbace_main__init_A_const_49 = A_arbace_main__init_A_const_pool.A[106]; A_arbace_main__init_A_const_50 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[107]); A_arbace_main__init_A_const_51 = A_arbace_main__init_A_const_pool.A[108] }

func A_arbace_main__init_A_clinit_p4() { A_arbace_main__init_A_const_52 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[109]); A_arbace_main__init_A_const_53 = A_arbace_main__init_A_const_pool.A[110]; A_arbace_main__init_A_const_54 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[111]); A_arbace_main__init_A_const_55 = A_arbace_main__init_A_const_pool.A[112]; A_arbace_main__init_A_const_56 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[113]); A_arbace_main__init_A_const_57 = A_arbace_main__init_A_const_pool.A[114]; A_arbace_main__init_A_const_58 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[115]); A_arbace_main__init_A_const_59 = A_arbace_main__init_A_const_pool.A[116]; A_arbace_main__init_A_const_60 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[117]); A_arbace_main__init_A_const_61 = A_arbace_main__init_A_const_pool.A[118]; A_arbace_main__init_A_const_62 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[119]); A_arbace_main__init_A_const_63 = A_arbace_main__init_A_const_pool.A[120]; A_arbace_main__init_A_const_64 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[121]) }

func A_arbace_main__init_A_clinit_p5() { A_arbace_main__init_A_const_65 = A_arbace_main__init_A_const_pool.A[122]; A_arbace_main__init_A_const_66 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[123]); A_arbace_main__init_A_const_67 = A_arbace_main__init_A_const_pool.A[124]; A_arbace_main__init_A_const_68 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[125]); A_arbace_main__init_A_const_69 = A_arbace_main__init_A_const_pool.A[126]; A_arbace_main__init_A_const_70 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[127]); A_arbace_main__init_A_const_71 = A_arbace_main__init_A_const_pool.A[128]; A_arbace_main__init_A_const_72 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[129]); A_arbace_main__init_A_const_73 = A_arbace_main__init_A_const_pool.A[130]; A_arbace_main__init_A_const_74 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[131]); A_arbace_main__init_A_const_75 = A_arbace_main__init_A_const_pool.A[132]; A_arbace_main__init_A_const_76 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[133]); A_arbace_main__init_A_const_77 = A_arbace_main__init_A_const_pool.A[134] }

func A_arbace_main__init_A_clinit_p6() { A_arbace_main__init_A_const_78 = lang.Var_Cast(A_arbace_main__init_A_const_pool.A[135]); A_arbace_main__init_A_const_79 = A_arbace_main__init_A_const_pool.A[136]; A_arbace_main__init_A_const_80 = A_arbace_main__init_A_const_pool.A[137] }

func A_arbace_main__init_A_New() *A_arbace_main__init_A { A_arbace_main__init_A_Init(); t := &A_arbace_main__init_A{}; t.Ctor(); return t }

func (t *A_arbace_main__init_A) Ctor() {}

func (t *A_arbace_main__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main__init_A) GetClass__Class() *jrt.Class { return A_arbace_main__init_A_class }

func (t *A_arbace_main__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_main__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main__init_A); return ok }

func A_arbace_main__init_A_Cast(x any) *A_arbace_main__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main__init_A_class)) }; return v }
