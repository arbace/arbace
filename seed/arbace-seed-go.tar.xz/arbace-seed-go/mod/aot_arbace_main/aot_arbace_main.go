//line aot_arbace_main.ae:1
package aot_arbace_main

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_spec_alpha"
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_New() *A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A { A_arbace_main_A_Init(); t := &A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A) Ctor() {}
//line :11:1
func (t *A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_main_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_main_A_const_1, A_arbace_main_A_const_2, A_arbace_main_A_const_3); lang.IFn_Cast(A_arbace_main_A_const_4.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_5); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_2)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_4)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :11:1
func A_arbace_main_eval461000008_fn__461000009_A_New() *A_arbace_main_eval461000008_fn__461000009_A { A_arbace_main_A_Init(); t := &A_arbace_main_eval461000008_fn__461000009_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_main_eval461000008_fn__461000009_A) Ctor() {}
//line :11:1
func (t *A_arbace_main_eval461000008_fn__461000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_main_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_main_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_main_A_const_9.GetRawRoot__O(), A_arbace_main_A_const_10) }
















func A_arbace_main_demunge_A_New() *A_arbace_main_demunge_A { A_arbace_main_A_Init(); t := &A_arbace_main_demunge_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_main_demunge_A) Ctor() {}
//line :28:1
func (t *A_arbace_main_demunge_A) Invoke_O_O__O(self, fn_name__0 any) any {




	return lang.Compiler_Demunge_String__String_NoInit(jrt.String_Cast(fn_name__0)).Ref()
}
func A_arbace_main_root_cause_A_New() *A_arbace_main_root_cause_A { A_arbace_main_A_Init(); t := &A_arbace_main_root_cause_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_main_root_cause_A) Ctor() {}
//line :35:1
func (t *A_arbace_main_root_cause_A) Invoke_O_O__O(self, t__0 any) any { { var cause__2 any = t__0; L1: for {





	var tmp1 any; var and__1927000168__auto____3 bool = lang.Compiler_CompilerException_InstanceOf(cause__2); if and__1927000168__auto____3 {
		var root_21 any = A_arbace_main_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = lang.Compiler_CompilerException_Cast(cause__2).F_source.Ref(); var arg_25 any = Lit_87; if linked_22 == nil { tmp1 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { tmp1 = linked_22.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_21, arg_24, arg_25) } } else {
//line :41:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return cause__2 } else { var temp__1927000408__auto____3 any = jrt.Throwable_Cast(cause__2).GetCause__Throwable()


				if jrt.J2g_Truth(temp__1927000408__auto____3) { var cause__4 any = temp__1927000408__auto____3
					cause__2 = cause__4; continue L1 } else {
//line :44:1
						return cause__2 } } } }; /*line :35:1*/panic("j2g: unreachable") }




















func A_arbace_main_core_class_QMARK__A_New() *A_arbace_main_core_class_QMARK__A { A_arbace_main_A_Init(); t := &A_arbace_main_core_class_QMARK__A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_main_core_class_QMARK__A) Ctor() {}
//line :56:1
func (t *A_arbace_main_core_class_QMARK__A) Invoke_O_O__O(self, class_name__0 any) any { var and__1927000168__auto____2 any; var root_26 any = A_arbace_main_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_28 lang.IFn; if

	linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(class_name__0, nil)).Ref(); if linked_27 == nil { and__1927000168__auto____2 = ifn_28.Invoke_O__O(arg_29) } else { and__1927000168__auto____2 = linked_27.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_26, arg_29) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var or__1927000174__auto____3 bool = jrt.NN(jrt.String_Cast(class_name__0)).StartsWith_String__Z(Lit_1)
		if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else {
			var root_30 any = A_arbace_main_A_const_13.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = A_arbace_main_A_const_14.GetRawRoot__O(); var arg_34 any; var root_35 any = A_arbace_main_A_const_15.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any; var root_39 any = A_arbace_main_A_const_16.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = A_arbace_main_A_const_17; var arg_43 any = class_name__0; if linked_40 == nil { arg_38 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_38 = linked_40.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; if linked_36 == nil { arg_34 = ifn_37.Invoke_O__O(arg_38) } else { arg_34 = linked_36.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_35, arg_38) }; if linked_31 == nil { return ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { return linked_31.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_30, arg_33, arg_34) } } } else {
//line :58:1
				return and__1927000168__auto____2 } }



func A_arbace_main_stack_element_str_A_New() *A_arbace_main_stack_element_str_A { A_arbace_main_A_Init(); t := &A_arbace_main_stack_element_str_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_main_stack_element_str_A) Ctor() {}
//line :62:1
func (t *A_arbace_main_stack_element_str_A) Invoke_O_O__O(self, el__0 any) any { var file__2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetFileName__String().Ref(); var clojure_fn_QMARK___3 any; var and__1927000168__auto____3 any = file__2; if




	jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_92); if or__1927000174__auto____4 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_93); if or__1927000174__auto____5 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_94); if or__1927000174__auto____6 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else {


		clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(file__2, Lit_87)).Ref() } } } } else {
//line :67:1
			clojure_fn_QMARK___3 = and__1927000168__auto____3 }; var tmp1 /*line :71:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil, Lit_14, nil, Lit_18); var tmp2 any; if jrt.J2g_Truth(clojure_fn_QMARK___3) {
				var root_44 any = A_arbace_main_A_const_18.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, A_arbace_main_demunge_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetClassName__String().Ref(); if linked_45 == nil { tmp2 = ifn_46.Invoke_O__O(arg_47) } else { tmp2 = linked_45.(*A_arbace_main_demunge_A).Invoke_O_O__O(root_44, arg_47) } } else {
					tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_95, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetClassName__String().Ref(), nil, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetMethodName__String().Ref())).Ref() }; return /*line :71:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetFileName__String().Ref(), nil, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetLineNumber__I()).Ref(), nil)).Ref() }





func A_arbace_main_with_bindings_A_New() *A_arbace_main_with_bindings_A { A_arbace_main_A_Init(); t := &A_arbace_main_with_bindings_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_main_with_bindings_A) Ctor() {}
//line :77:1
func (t *A_arbace_main_with_bindings_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { var root_48 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_20.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_22); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()); var tmp4 any; var root_58 any = A_arbace_main_A_const_23.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = A_arbace_main_A_const_24.GetRawRoot__O(); var arg_62 any; var root_63 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_20.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_25); var tmp7 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_26); var tmp8 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_27); var tmp9 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_28); var tmp10 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_29); var tmp11 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_30); var tmp12 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_31); var tmp13 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_32); var tmp14 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_33); var tmp15 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_34); var tmp16 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_35); var tmp17 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_36); var tmp18 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_37); var tmp19 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_TRUE.Ref()); var tmp20 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_38); var tmp21 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_39); var tmp22 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_40); var tmp23 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_41); var tmp24 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_42); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()); var tmp26 any; var root_67 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = lang.IFn_Cast(A_arbace_main_A_const_20.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_43), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(Lit_63), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(Lit_64)); if linked_68 == nil { tmp26 = ifn_69.Invoke_O__O(arg_70) } else { tmp26 = linked_68.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_67, arg_70) }; arg_66 = tmp5.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25.Invoke_O__O(tmp26), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_44), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_45), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_46), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_47), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_48), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_49), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_50), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_51), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_52), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(nil), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_53), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(nil), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_54), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(nil), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_55), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(nil))))); if linked_64 == nil { arg_62 = ifn_65.Invoke_O__O(arg_66) } else { arg_62 = linked_64.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_63, arg_66) }; if linked_59 == nil { tmp4 = ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { tmp4 = linked_59.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_58, arg_61, arg_62) }; arg_51 = tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4), body__2); if linked_49 == nil { return ifn_50.Invoke_O__O(arg_51) } else { return linked_49.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_48, arg_51) } }

























func A_arbace_main_repl_prompt_A_New() *A_arbace_main_repl_prompt_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_prompt_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_main_repl_prompt_A) Ctor() {}
//line :103:1
func (t *A_arbace_main_repl_prompt_A) Invoke_O__O(self any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_56.GetRawRoot__O()); var tmp2 any; var root_82 any = A_arbace_main_A_const_57.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = A_arbace_main_A_const_58.Get__O(); if linked_83 == nil { tmp2 = ifn_84.Invoke_O__O(arg_85) } else { tmp2 = linked_83.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_82, arg_85) }; return tmp1.Invoke_O_O__O(Lit_78, tmp2)
}
func A_arbace_main_skip_if_eol_A_New() *A_arbace_main_skip_if_eol_A { A_arbace_main_A_Init(); t := &A_arbace_main_skip_if_eol_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_main_skip_if_eol_A) Ctor() {}
//line :108:1
func (t *A_arbace_main_skip_if_eol_A) Invoke_O_O__O(self, s__0 any) any { var c__2 any = lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(s__0, Lit_89, false); if








	lang.Util_Equiv_O_J__Z_NoInit(c__2, int64(lang.RT_IntCast_O__I_NoInit(A_arbace_main_A_const_59))) { return A_arbace_main_A_const_60 } else { if lang.Util_Equiv_O_J__Z_NoInit(c__2, -1) { return A_arbace_main_A_const_61 } else { if A_arbace_main_A_const_62 != nil {


		lang.Reflector_InvokeInstanceMethod_O_String_O1__O(s__0, Lit_90, jrt.RefArrayOf(jrt.Object_class, c__2))
//line :117:1
		return A_arbace_main_A_const_63 } else { return nil } } } }




func A_arbace_main_skip_whitespace_A_New() *A_arbace_main_skip_whitespace_A { A_arbace_main_A_Init(); t := &A_arbace_main_skip_whitespace_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_main_skip_whitespace_A) Ctor() {}
//line :122:1
func (t *A_arbace_main_skip_whitespace_A) Invoke_O_O__O(self, s__0 any) any { { var c__2 any = lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(s__0, Lit_89, false); L1: for {










	if lang.Util_Equiv_O_J__Z_NoInit(c__2, int64(lang.RT_IntCast_O__I_NoInit(A_arbace_main_A_const_59))) { return A_arbace_main_A_const_60 } else { if lang.Util_Equiv_O_J__Z_NoInit(c__2, -1) { return A_arbace_main_A_const_61 } else { if lang.Util_Equiv_O_J__Z_NoInit(c__2, int64(lang.RT_IntCast_O__I_NoInit(A_arbace_main_A_const_64))) {


		lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(s__0, Lit_91, false)
//line :133:1
		return A_arbace_main_A_const_60 } else { var tmp1 bool; var or__1927000174__auto____3 bool = jrt.Character_IsWhitespace_C__Z_NoInit(lang.RT_CharCast_O__C_NoInit(c__2))



			if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_J__Z_NoInit(c__2, int64(lang.RT_IntCast_O__I_NoInit(A_arbace_main_A_const_65))) }
//line :133:1
			if tmp1 {



				c__2 = lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(s__0, Lit_89, false); continue L1 } else {
//line :133:1
					if A_arbace_main_A_const_62 != nil {




						lang.Reflector_InvokeInstanceMethod_O_String_O1__O(s__0, Lit_90, jrt.RefArrayOf(jrt.Object_class, c__2))
//line :133:1
						return A_arbace_main_A_const_63 } else { return nil } } } } } } }; /*line :122:1*/panic("j2g: unreachable") }

















func A_arbace_main_renumbering_read_A_New() *A_arbace_main_renumbering_read_A { A_arbace_main_A_Init(); t := &A_arbace_main_renumbering_read_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_main_renumbering_read_A) Ctor() {}
//line :140:1
func (t *A_arbace_main_renumbering_read_A) Invoke_O_O_O_O__O(self, opts__0, reader__1, line_number__2 any) any { var pre_line__4 int32 = jrt.NN(lang.LineNumberingPushbackReader_Cast(reader__1)).GetLineNumber__I(); var vec__461000024__5 any; var root_86 any = A_arbace_main_A_const_66.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_read_PLUS_string_A_fn_class); var ifn_88 lang.IFn; if







	linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = opts__0; var arg_90 any = reader__1; if linked_87 == nil { vec__461000024__5 = ifn_88.Invoke_O_O__O(arg_89, arg_90) } else { vec__461000024__5 = linked_87.(*aot_arbace_core.A_arbace_core_read_PLUS_string_A).Invoke_O_O_O__O(root_86, arg_89, arg_90) }; var pre_read__6 any = /*line :140:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__461000024__5, lang.RT_IntCast_J__I_NoInit(0), nil); var s__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000024__5, lang.RT_IntCast_J__I_NoInit(1), nil); var map__461000027__8 any = lang.RT_Meta_O__IPersistentMap_NoInit(pre_read__6); var map__461000027__9 any; if






	lang.ISeq_InstanceOf(map__461000027__8) { var tmp1 any; var root_91 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = map__461000027__8; if linked_92 == nil { tmp1 = ifn_93.Invoke_O__O(arg_94) } else { tmp1 = linked_92.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_91, arg_94) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_95 any = A_arbace_main_A_const_68.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = map__461000027__8; if linked_96 == nil { tmp2 = ifn_97.Invoke_O__O(arg_98) } else { tmp2 = linked_96.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_95, arg_98) }; map__461000027__9 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_99 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = map__461000027__8; if linked_100 == nil { tmp3 = ifn_101.Invoke_O__O(arg_102) } else { tmp3 = linked_100.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_99, arg_102) }; if jrt.J2g_Truth(tmp3) { var root_103 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = map__461000027__8; if linked_104 == nil { map__461000027__9 = ifn_105.Invoke_O__O(arg_106) } else { map__461000027__9 = linked_104.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_103, arg_106) } } else { map__461000027__9 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000027__9 = map__461000027__8 }; var eval_file__10 any = /*line :140:1*/lang.RT_Get_O_O__O_NoInit(map__461000027__9, A_arbace_main_A_const_70); var line__11 any = lang.RT_Get_O_O__O_NoInit(map__461000027__9, A_arbace_main_A_const_71); var re_reader__12 any; var G__461000029__12_ any = lang.LineNumberingPushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(s__7))); var tmp4 *lang.LineNumberingPushbackReader = lang.LineNumberingPushbackReader_Cast(G__461000029__12_); var tmp5 any; var tmp6 any; var and__1927000168__auto____13 any = line__11; if










	jrt.J2g_Truth(and__1927000168__auto____13) { var or__1927000174__auto____14 any = eval_file__10; if jrt.J2g_Truth(or__1927000174__auto____14) { tmp6 = or__1927000174__auto____14 } else { var root_112 any = A_arbace_main_A_const_11.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = jrt.Integer_ValueOf_I__Integer_NoInit(pre_line__4).Ref(); var arg_116 any = line__11; if linked_113 == nil { tmp6 = ifn_114.Invoke_O_O__O(arg_115, arg_116) } else { tmp6 = linked_113.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_112, arg_115, arg_116) } } } else { tmp6 = and__1927000168__auto____13 }; if jrt.J2g_Truth(tmp6) { tmp5 = line__11 } else { tmp5 = line_number__2 }; jrt.NN(tmp4).SetLineNumber_I__V(lang.RT_IntCast_O__I_NoInit(tmp5)); re_reader__12 = G__461000029__12_; var root_107 any =
	A_arbace_main_A_const_72.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = opts__0; var arg_111 any = re_reader__12; if linked_108 == nil { return ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { return linked_108.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_107, arg_110, arg_111) } }

func A_arbace_main_repl_read_A_New() *A_arbace_main_repl_read_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_read_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_main_repl_read_A) Ctor() {}
//line :154:1
func (t *A_arbace_main_repl_read_A) Invoke_O_O_O__O(self, request_prompt__0, request_exit__1 any) any { var or__1927000174__auto____3 any; var tmp1 lang.IFn = lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_main_A_const_60, request_prompt__0, A_arbace_main_A_const_61, request_exit__1))); var tmp2 any; var root_123 any = A_arbace_main_A_const_77.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, A_arbace_main_skip_whitespace_A_fn_class); var ifn_125 lang.IFn; if












	linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = A_arbace_main_A_const_75.Get__O(); if linked_124 == nil { tmp2 = ifn_125.Invoke_O__O(arg_126) } else { tmp2 = linked_124.(*A_arbace_main_skip_whitespace_A).Invoke_O_O__O(root_123, arg_126) }; or__1927000174__auto____3 = /*line :166:1*/tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var input__4 any; var root_117 any = A_arbace_main_A_const_73.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, A_arbace_main_renumbering_read_A_fn_class); var ifn_119 lang.IFn

		if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = A_arbace_main_A_const_74; var arg_121 any = A_arbace_main_A_const_75.Get__O(); var arg_122 any = A_arbace_main_A_const_76; if linked_118 == nil { input__4 = ifn_119.Invoke_O_O_O__O(arg_120, arg_121, arg_122) } else { input__4 = linked_118.(*A_arbace_main_renumbering_read_A).Invoke_O_O_O_O__O(root_117, arg_120, arg_121, arg_122) }
		var root_127 any = A_arbace_main_A_const_78.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, A_arbace_main_skip_if_eol_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = A_arbace_main_A_const_75.Get__O(); if linked_128 == nil { ifn_129.Invoke_O__O(arg_130) } else { linked_128.(*A_arbace_main_skip_if_eol_A).Invoke_O_O__O(root_127, arg_130) }
//line :166:1
		return input__4 } }





func A_arbace_main_repl_exception_A_New() *A_arbace_main_repl_exception_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_exception_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_main_repl_exception_A) Ctor() {}
//line :172:1
func (t *A_arbace_main_repl_exception_A) Invoke_O_O__O(self, throwable__0 any) any {


	var root_131 any = A_arbace_main_A_const_79.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, A_arbace_main_root_cause_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = throwable__0; if linked_132 == nil { return ifn_133.Invoke_O__O(arg_134) } else { return linked_132.(*A_arbace_main_root_cause_A).Invoke_O_O__O(root_131, arg_134)
	} }
func A_arbace_main_file_name_A_New() *A_arbace_main_file_name_A { A_arbace_main_A_Init(); t := &A_arbace_main_file_name_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_main_file_name_A) Ctor() {}
//line :177:1
func (t *A_arbace_main_file_name_A) Invoke_O_O__O(self, full_path__0 any) any {


	if jrt.J2g_Truth(full_path__0) { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		tmp1 = jrt.File_New_String(jrt.String_Cast(full_path__0)).GetName__String().Ref()
//line :180:1
		return nil }(); if tmp2 != nil { if true { var t__4 jrt.Throwable_I = tmp2; _ = t__4; tmp1 = nil } }; return tmp1 } else { return nil
		}
}


func A_arbace_main_file_path_A_New() *A_arbace_main_file_path_A { A_arbace_main_A_Init(); t := &A_arbace_main_file_path_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_main_file_path_A) Ctor() {}
//line :185:1
func (t *A_arbace_main_file_path_A) Invoke_O_O__O(self, full_path__0 any) any {


	if jrt.J2g_Truth(full_path__0) { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var path__4 any = jrt.File_New_String(jrt.String_Cast(full_path__0)).GetPath__String().Ref(); var cd_path__5 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_39), jrt.RefArrayOf(jrt.Object_class, jrt.File_New_String(Lit_16).GetAbsolutePath__String().Ref(), nil)).Ref()



		if jrt.NN(jrt.String_Cast(path__4)).StartsWith_String__Z(jrt.String_Cast(cd_path__5)) {
			var root_135 any = A_arbace_main_A_const_80.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = path__4; var arg_139 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(cd_path__5)).Ref(); if linked_136 == nil { tmp1 = ifn_137.Invoke_O_O__O(arg_138, arg_139) } else { tmp1 = linked_136.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_135, arg_138, arg_139) } } else {
//line :192:1
				tmp1 = path__4 } }; return nil }()
//line :188:1
		if tmp2 != nil { if true { var t__4 jrt.Throwable_I = tmp2; _ = t__4; tmp1 = full_path__0 } }; return tmp1 } else { return nil
		}
}







func A_arbace_main_java_loc__GT_source_A_New() *A_arbace_main_java_loc__GT_source_A { A_arbace_main_A_Init(); t := &A_arbace_main_java_loc__GT_source_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_main_java_loc__GT_source_A) Ctor() {}
//line :198:1
func (t *A_arbace_main_java_loc__GT_source_A) Invoke_O_O_O__O(self, clazz__0, method__1 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_main_A_const_81).Invoke_O__O(method__1)) { var degen__3 any; var tmp1 any = A_arbace_main_java_loc__GT_source_degen__461000039_A_New(); var tmp2 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_main_java_loc__GT_source_degen__461000039_A_fn_class
		if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_main_java_loc__GT_source_degen__461000039_A_fn_class = fncls__140d; tmp2 = fncls__140d } else { tmp2 = fncls__140 }; degen__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :202:1
		var vec__461000036__4 any; var root_141 any = A_arbace_main_A_const_83.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_143 lang.IFn

		if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = degen__3; var arg_145 any; var root_146 any = A_arbace_main_A_const_83.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = A_arbace_main_A_const_18.GetRawRoot__O(); var arg_150 any; var tmp3 *jrt.Pattern = jrt.Pattern_Cast(A_arbace_main_A_const_84); var tmp4 any; var root_151 any = A_arbace_main_A_const_85.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = clazz__0; if linked_152 == nil { tmp4 = ifn_153.Invoke_O__O(arg_154) } else { tmp4 = linked_152.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_151, arg_154) }; arg_150 = jrt.NN(tmp3).Split_CharSequence__String1(jrt.CharSequence_Cast(tmp4)).Ref(); if linked_147 == nil { arg_145 = ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { arg_145 = linked_147.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) }; if linked_142 == nil { vec__461000036__4 = ifn_143.Invoke_O_O__O(arg_144, arg_145) } else { vec__461000036__4 = linked_142.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_141, arg_144, arg_145) }
//line :202:1
		var seq__461000037__5 any; var root_155 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_157 lang.IFn
		if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = vec__461000036__4; if linked_156 == nil { seq__461000037__5 = ifn_157.Invoke_O__O(arg_158) } else { seq__461000037__5 = linked_156.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_155, arg_158) }
//line :202:1
		var first__461000038__6 any; var root_159 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_161 lang.IFn
		if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = seq__461000037__5; if linked_160 == nil { first__461000038__6 = ifn_161.Invoke_O__O(arg_162) } else { first__461000038__6 = linked_160.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_159, arg_162) }
//line :202:1
		var seq__461000037__7 any; var root_163 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_165 lang.IFn
		if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = seq__461000037__5; if linked_164 == nil { seq__461000037__7 = ifn_165.Invoke_O__O(arg_166) } else { seq__461000037__7 = linked_164.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_163, arg_166) }
//line :202:1
		var ns_name__8 any = first__461000038__6; var first__461000038__9 any; var root_167 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_169 lang.IFn
		if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = seq__461000037__7; if linked_168 == nil { first__461000038__9 = ifn_169.Invoke_O__O(arg_170) } else { first__461000038__9 = linked_168.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_167, arg_170) }
//line :202:1
		var seq__461000037__10 any; var root_171 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_173 lang.IFn
		if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = seq__461000037__7; if linked_172 == nil { seq__461000037__10 = ifn_173.Invoke_O__O(arg_174) } else { seq__461000037__10 = linked_172.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_171, arg_174) }
//line :202:1
		var fn_name__11 any = first__461000038__9; var nested__12 any = seq__461000037__10; var root_175 any = A_arbace_main_A_const_86.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_177 lang.IFn


		if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = ns_name__8; var arg_179 any; var tmp5 jrt.CharSequence = Lit_45; var tmp6 any; var root_180 any = A_arbace_main_A_const_87.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_into_array_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = A_arbace_main_A_const_82; var arg_184 any; var root_185 any = A_arbace_main_A_const_88.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = fn_name__11; var arg_189 any = nested__12; if linked_186 == nil { arg_184 = ifn_187.Invoke_O_O__O(arg_188, arg_189) } else { arg_184 = linked_186.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_185, arg_188, arg_189) }; if linked_181 == nil { tmp6 = ifn_182.Invoke_O_O__O(arg_183, arg_184) } else { tmp6 = linked_181.(*aot_arbace_core.A_arbace_core_into_array_A).Invoke_O_O_O__O(root_180, arg_183, arg_184) }; arg_179 = jrt.String_Join_CharSequence_CharSequence1__String(tmp5, jrt.J2g_CastArray[*jrt.RefArray](tmp6, jrt.CharSequence_class.ArrayClass())).Ref(); if linked_176 == nil { return ifn_177.Invoke_O_O__O(arg_178, arg_179) } else { return linked_176.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_175, arg_178, arg_179) } } else {
			var root_190 any = A_arbace_main_A_const_86.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any; var root_195 any = A_arbace_main_A_const_89.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = clazz__0; if linked_196 == nil { arg_193 = ifn_197.Invoke_O__O(arg_198) } else { arg_193 = linked_196.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_195, arg_198) }; var arg_194 any; var root_199 any = A_arbace_main_A_const_89.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = method__1; if linked_200 == nil { arg_194 = ifn_201.Invoke_O__O(arg_202) } else { arg_194 = linked_200.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_199, arg_202) }; if linked_191 == nil { return ifn_192.Invoke_O_O__O(arg_193, arg_194) } else { return linked_191.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_190, arg_193, arg_194) } } }
//line :203:1
func A_arbace_main_java_loc__GT_source_degen__461000039_A_New() *A_arbace_main_java_loc__GT_source_degen__461000039_A { A_arbace_main_A_Init(); t := &A_arbace_main_java_loc__GT_source_degen__461000039_A{}; t.Ctor(); return t }
//line :203:1
func (t *A_arbace_main_java_loc__GT_source_degen__461000039_A) Ctor() {}
//line :203:1
func (t *A_arbace_main_java_loc__GT_source_degen__461000039_A) Invoke_O_O__O(self, p1__461000035_SHARP___1 any) any { var tmp1 *jrt.Class = A_arbace_main_A_const_82; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p1__461000035_SHARP___1, tmp1, Lit_46, jrt.RefArrayOf(jrt.Object_class, Lit_47, Lit_16)) }




func A_arbace_main_ex_triage_A_New() *A_arbace_main_ex_triage_A { A_arbace_main_A_Init(); t := &A_arbace_main_ex_triage_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_main_ex_triage_A) Ctor() {}
//line :208:1
func (t *A_arbace_main_ex_triage_A) Invoke_O_O__O(self, datafied_throwable__0 any) any { var default__461000046__2 any = A_arbace_main_A_const_90; var map__461000044__3 any = datafied_throwable__0; var map__461000044__4 any; if
















	lang.ISeq_InstanceOf(map__461000044__3) { var tmp1 any; var root_203 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = map__461000044__3; if linked_204 == nil { tmp1 = ifn_205.Invoke_O__O(arg_206) } else { tmp1 = linked_204.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_203, arg_206) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_207 any = A_arbace_main_A_const_68.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = map__461000044__3; if linked_208 == nil { tmp2 = ifn_209.Invoke_O__O(arg_210) } else { tmp2 = linked_208.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_207, arg_210) }; map__461000044__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_211 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = map__461000044__3; if linked_212 == nil { tmp3 = ifn_213.Invoke_O__O(arg_214) } else { tmp3 = linked_212.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_211, arg_214) }; if jrt.J2g_Truth(tmp3) { var root_215 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = map__461000044__3; if linked_216 == nil { map__461000044__4 = ifn_217.Invoke_O__O(arg_218) } else { map__461000044__4 = linked_216.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_215, arg_218) } } else { map__461000044__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000044__4 = map__461000044__3 }; var via__5 any = /*line :208:1*/lang.RT_Get_O_O__O_NoInit(map__461000044__4, A_arbace_main_A_const_91); var trace__6 any = lang.RT_Get_O_O__O_NoInit(map__461000044__4, A_arbace_main_A_const_92); var phase__7 any = lang.RT_Get_O_O_O__O_NoInit(map__461000044__4, A_arbace_main_A_const_93, default__461000046__2); var map__461000048__8 any; var root_219 any = A_arbace_main_A_const_94.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_221 lang.IFn; if

















	linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = via__5; if linked_220 == nil { map__461000048__8 = ifn_221.Invoke_O__O(arg_222) } else { map__461000048__8 = linked_220.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_219, arg_222) }; var map__461000048__9 any; if /*line :225:1*/ lang.ISeq_InstanceOf(map__461000048__8) { var tmp4 any; var root_223 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = map__461000048__8; if linked_224 == nil { tmp4 = ifn_225.Invoke_O__O(arg_226) } else { tmp4 = linked_224.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_223, arg_226) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_227 any = A_arbace_main_A_const_68.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = map__461000048__8; if linked_228 == nil { tmp5 = ifn_229.Invoke_O__O(arg_230) } else { tmp5 = linked_228.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_227, arg_230) }; map__461000048__9 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp5, jrt.Object_class.ArrayClass())).Ref() } else { var tmp6 any; var root_231 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = map__461000048__8; if linked_232 == nil { tmp6 = ifn_233.Invoke_O__O(arg_234) } else { tmp6 = linked_232.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_231, arg_234) }; if jrt.J2g_Truth(tmp6) { var root_235 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = map__461000048__8; if linked_236 == nil { map__461000048__9 = ifn_237.Invoke_O__O(arg_238) } else { map__461000048__9 = linked_236.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_235, arg_238) } } else { map__461000048__9 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000048__9 = map__461000048__8 }; var type__10 any = /*line :208:1*/lang.RT_Get_O_O__O_NoInit(map__461000048__9, A_arbace_main_A_const_95); var message__11 any = lang.RT_Get_O_O__O_NoInit(map__461000048__9, A_arbace_main_A_const_96); var data__12 any = lang.RT_Get_O_O__O_NoInit(map__461000048__9, A_arbace_main_A_const_97); var map__461000050__13 any = data__12; var map__461000050__14 any; if
















	lang.ISeq_InstanceOf(map__461000050__13) { var tmp7 any; var root_239 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = map__461000050__13; if linked_240 == nil { tmp7 = ifn_241.Invoke_O__O(arg_242) } else { tmp7 = linked_240.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_239, arg_242) }; if jrt.J2g_Truth(tmp7) { var tmp8 any; var root_243 any = A_arbace_main_A_const_68.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = map__461000050__13; if linked_244 == nil { tmp8 = ifn_245.Invoke_O__O(arg_246) } else { tmp8 = linked_244.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_243, arg_246) }; map__461000050__14 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp8, jrt.Object_class.ArrayClass())).Ref() } else { var tmp9 any; var root_247 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = map__461000050__13; if linked_248 == nil { tmp9 = ifn_249.Invoke_O__O(arg_250) } else { tmp9 = linked_248.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_247, arg_250) }; if jrt.J2g_Truth(tmp9) { var root_251 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any = map__461000050__13; if linked_252 == nil { map__461000050__14 = ifn_253.Invoke_O__O(arg_254) } else { map__461000050__14 = linked_252.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_251, arg_254) } } else { map__461000050__14 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000050__14 = map__461000050__13 }; var problems__15 any = /*line :208:1*/lang.RT_Get_O_O__O_NoInit(map__461000050__14, A_arbace_main_A_const_98); var fn__16 any = lang.RT_Get_O_O__O_NoInit(map__461000050__14, A_arbace_main_A_const_99); var caller__17 any = lang.RT_Get_O_O__O_NoInit(map__461000050__14, A_arbace_main_A_const_100); var map__461000052__18 any; var tmp10 *lang.Keyword = A_arbace_main_A_const_97; var tmp11 any; var root_255 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_255, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_257 lang.IFn; if



















	linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any = via__5; if linked_256 == nil { tmp11 = ifn_257.Invoke_O__O(arg_258) } else { tmp11 = linked_256.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_255, arg_258) }; map__461000052__18 = tmp10.Invoke_O__O(tmp11); var map__461000052__19 any; if /*line :225:1*/ lang.ISeq_InstanceOf(map__461000052__18) { var tmp12 any; var root_259 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = map__461000052__18; if linked_260 == nil { tmp12 = ifn_261.Invoke_O__O(arg_262) } else { tmp12 = linked_260.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_259, arg_262) }; if jrt.J2g_Truth(tmp12) { var tmp13 any; var root_263 any = A_arbace_main_A_const_68.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = map__461000052__18; if linked_264 == nil { tmp13 = ifn_265.Invoke_O__O(arg_266) } else { tmp13 = linked_264.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_263, arg_266) }; map__461000052__19 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp13, jrt.Object_class.ArrayClass())).Ref() } else { var tmp14 any; var root_267 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = map__461000052__18; if linked_268 == nil { tmp14 = ifn_269.Invoke_O__O(arg_270) } else { tmp14 = linked_268.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_267, arg_270) }; if jrt.J2g_Truth(tmp14) { var root_271 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = map__461000052__18; if linked_272 == nil { map__461000052__19 = ifn_273.Invoke_O__O(arg_274) } else { map__461000052__19 = linked_272.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_271, arg_274) } } else { map__461000052__19 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000052__19 = map__461000052__18 }; var top_data__20 any = map__461000052__19; var source__21 any = /*line :208:1*/lang.RT_Get_O_O__O_NoInit(map__461000052__19, A_arbace_main_A_const_101); var root_275 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_277 lang.IFn; if




















	linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any; var G__461000054__22_ any = phase__7; L1:
	switch { default: switch lang.Util_Hash_O__I_NoInit(G__461000054__22_) >> 3 & 15 { case 0: if any(G__461000054__22_) == any(A_arbace_main_A_const_103) { var G__461000055__23_ any = top_data__20; var G__461000055__24_ any









		if jrt.J2g_Truth(source__21) {
			var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_102.GetRawRoot__O()); var tmp16 any = A_arbace_main_A_const_101; var tmp17 any; var root_290 any = A_arbace_main_A_const_104.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, A_arbace_main_file_name_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = source__21; if linked_291 == nil { tmp17 = ifn_292.Invoke_O__O(arg_293) } else { tmp17 = linked_291.(*A_arbace_main_file_name_A).Invoke_O_O__O(root_290, arg_293) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_main_A_const_105; var tmp20 any; var root_294 any = A_arbace_main_A_const_106.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, A_arbace_main_file_path_A_fn_class); var ifn_296 lang.IFn
			if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = source__21; if linked_295 == nil { tmp20 = ifn_296.Invoke_O__O(arg_297) } else { tmp20 = linked_295.(*A_arbace_main_file_path_A).Invoke_O_O__O(root_294, arg_297) }
//line :241:1
			G__461000055__24_ = tmp15.Invoke_O_O_O_O_O__O(G__461000055__23_, tmp16, tmp18, tmp19, tmp20) } else {
//line :240:1
				G__461000055__24_ = G__461000055__23_ }
//line :230:1
		var G__461000055__25_ any









		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_main_A_const_107).Invoke_O__O(source__21)) {


			G__461000055__25_ = lang.IFn_Cast(A_arbace_main_A_const_108.GetRawRoot__O()).Invoke_O_O_O__O(G__461000055__24_, A_arbace_main_A_const_101, A_arbace_main_A_const_105) } else {
//line :240:1
				G__461000055__25_ = G__461000055__24_ }
//line :230:1
		var G__461000055__26_ any









		if jrt.J2g_Truth(type__10) {



			var root_304 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = G__461000055__25_; var arg_308 any = A_arbace_main_A_const_109; var arg_309 any = type__10; if linked_305 == nil { G__461000055__26_ = ifn_306.Invoke_O_O_O__O(arg_307, arg_308, arg_309) } else { G__461000055__26_ = linked_305.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_304, arg_307, arg_308, arg_309) } } else {
//line :240:1
				G__461000055__26_ = G__461000055__25_ }
//line :230:1
		var G__461000055__27_ any









		if jrt.J2g_Truth(message__11) {




			var root_310 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = G__461000055__26_; var arg_314 any = A_arbace_main_A_const_110; var arg_315 any = message__11; if linked_311 == nil { G__461000055__27_ = ifn_312.Invoke_O_O_O__O(arg_313, arg_314, arg_315) } else { G__461000055__27_ = linked_311.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_310, arg_313, arg_314, arg_315) } } else {
//line :240:1
				G__461000055__27_ = G__461000055__26_ }; if jrt.J2g_Truth(problems__15) {





					var root_316 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = G__461000055__27_; var arg_320 any = A_arbace_main_A_const_111; var arg_321 any = data__12; if linked_317 == nil { arg_278 = ifn_318.Invoke_O_O_O__O(arg_319, arg_320, arg_321) } else { arg_278 = linked_317.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_316, arg_319, arg_320, arg_321) } } else {
//line :240:1
						arg_278 = G__461000055__27_ }
//line :230:1
		break L1 }; case 1: if any(G__461000054__22_) == any(A_arbace_main_A_const_112) { var G__461000056__23_ any = top_data__20; var G__461000056__24_ any









			if jrt.J2g_Truth(source__21) {
				var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_102.GetRawRoot__O()); var tmp22 any = A_arbace_main_A_const_101; var tmp23 any; var root_330 any = A_arbace_main_A_const_104.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, A_arbace_main_file_name_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = source__21; if linked_331 == nil { tmp23 = ifn_332.Invoke_O__O(arg_333) } else { tmp23 = linked_331.(*A_arbace_main_file_name_A).Invoke_O_O__O(root_330, arg_333) }; var tmp24 any = tmp23; var tmp25 any = A_arbace_main_A_const_105; var tmp26 any; var root_334 any = A_arbace_main_A_const_106.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, A_arbace_main_file_path_A_fn_class); var ifn_336 lang.IFn
				if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = source__21; if linked_335 == nil { tmp26 = ifn_336.Invoke_O__O(arg_337) } else { tmp26 = linked_335.(*A_arbace_main_file_path_A).Invoke_O_O__O(root_334, arg_337) }
//line :241:1
				G__461000056__24_ = tmp21.Invoke_O_O_O_O_O__O(G__461000056__23_, tmp22, tmp24, tmp25, tmp26) } else {
//line :240:1
					G__461000056__24_ = G__461000056__23_ }
//line :230:1
			var G__461000056__25_ any









			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_main_A_const_113).Invoke_O__O(source__21)) {


				G__461000056__25_ = lang.IFn_Cast(A_arbace_main_A_const_108.GetRawRoot__O()).Invoke_O_O_O__O(G__461000056__24_, A_arbace_main_A_const_101, A_arbace_main_A_const_105) } else {
//line :240:1
					G__461000056__25_ = G__461000056__24_ }
//line :230:1
			var G__461000056__26_ any









			if jrt.J2g_Truth(type__10) {



				var root_344 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = G__461000056__25_; var arg_348 any = A_arbace_main_A_const_109; var arg_349 any = type__10; if linked_345 == nil { G__461000056__26_ = ifn_346.Invoke_O_O_O__O(arg_347, arg_348, arg_349) } else { G__461000056__26_ = linked_345.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_344, arg_347, arg_348, arg_349) } } else {
//line :240:1
					G__461000056__26_ = G__461000056__25_ }
//line :230:1
			var G__461000056__27_ any









			if jrt.J2g_Truth(message__11) {




				var root_350 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = G__461000056__26_; var arg_354 any = A_arbace_main_A_const_110; var arg_355 any = message__11; if linked_351 == nil { G__461000056__27_ = ifn_352.Invoke_O_O_O__O(arg_353, arg_354, arg_355) } else { G__461000056__27_ = linked_351.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_350, arg_353, arg_354, arg_355) } } else {
//line :240:1
					G__461000056__27_ = G__461000056__26_ }; if jrt.J2g_Truth(problems__15) {





						var root_356 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = G__461000056__27_; var arg_360 any = A_arbace_main_A_const_111; var arg_361 any = data__12; if linked_357 == nil { arg_278 = ifn_358.Invoke_O_O_O__O(arg_359, arg_360, arg_361) } else { arg_278 = linked_357.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_356, arg_359, arg_360, arg_361) } } else {
//line :240:1
							arg_278 = G__461000056__27_ }
//line :230:1
			break L1 }; case 3: if any(G__461000054__22_) == any(A_arbace_main_A_const_114) { var G__461000057__23_ any = top_data__20; var G__461000057__24_ any









				if jrt.J2g_Truth(source__21) {
					var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_102.GetRawRoot__O()); var tmp28 any = A_arbace_main_A_const_101; var tmp29 any; var root_370 any = A_arbace_main_A_const_104.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, A_arbace_main_file_name_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = source__21; if linked_371 == nil { tmp29 = ifn_372.Invoke_O__O(arg_373) } else { tmp29 = linked_371.(*A_arbace_main_file_name_A).Invoke_O_O__O(root_370, arg_373) }; var tmp30 any = tmp29; var tmp31 any = A_arbace_main_A_const_105; var tmp32 any; var root_374 any = A_arbace_main_A_const_106.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, A_arbace_main_file_path_A_fn_class); var ifn_376 lang.IFn
					if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = source__21; if linked_375 == nil { tmp32 = ifn_376.Invoke_O__O(arg_377) } else { tmp32 = linked_375.(*A_arbace_main_file_path_A).Invoke_O_O__O(root_374, arg_377) }
//line :241:1
					G__461000057__24_ = tmp27.Invoke_O_O_O_O_O__O(G__461000057__23_, tmp28, tmp30, tmp31, tmp32) } else {
//line :240:1
						G__461000057__24_ = G__461000057__23_ }
//line :230:1
				var G__461000057__25_ any









				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_main_A_const_115).Invoke_O__O(source__21)) {


					G__461000057__25_ = lang.IFn_Cast(A_arbace_main_A_const_108.GetRawRoot__O()).Invoke_O_O_O__O(G__461000057__24_, A_arbace_main_A_const_101, A_arbace_main_A_const_105) } else {
//line :240:1
						G__461000057__25_ = G__461000057__24_ }
//line :230:1
				var G__461000057__26_ any









				if jrt.J2g_Truth(type__10) {



					var root_384 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = G__461000057__25_; var arg_388 any = A_arbace_main_A_const_109; var arg_389 any = type__10; if linked_385 == nil { G__461000057__26_ = ifn_386.Invoke_O_O_O__O(arg_387, arg_388, arg_389) } else { G__461000057__26_ = linked_385.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_384, arg_387, arg_388, arg_389) } } else {
//line :240:1
						G__461000057__26_ = G__461000057__25_ }
//line :230:1
				var G__461000057__27_ any









				if jrt.J2g_Truth(message__11) {




					var root_390 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = G__461000057__26_; var arg_394 any = A_arbace_main_A_const_110; var arg_395 any = message__11; if linked_391 == nil { G__461000057__27_ = ifn_392.Invoke_O_O_O__O(arg_393, arg_394, arg_395) } else { G__461000057__27_ = linked_391.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_390, arg_393, arg_394, arg_395) } } else {
//line :240:1
						G__461000057__27_ = G__461000057__26_ }; if jrt.J2g_Truth(problems__15) {





							var root_396 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = G__461000057__27_; var arg_400 any = A_arbace_main_A_const_111; var arg_401 any = data__12; if linked_397 == nil { arg_278 = ifn_398.Invoke_O_O_O__O(arg_399, arg_400, arg_401) } else { arg_278 = linked_397.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_396, arg_399, arg_400, arg_401) } } else {
//line :240:1
								arg_278 = G__461000057__27_ }
//line :230:1
				break L1 }; case 4: if any(G__461000054__22_) == any(A_arbace_main_A_const_90) { var vec__461000058__23 any; var root_402 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_404 lang.IFn



























					if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; var root_406 any = A_arbace_main_A_const_116.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_drop_while_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any; var tmp33 any = A_arbace_main_ex_triage_fn__461000061_A_New(); var tmp34 *jrt.Class; var fncls__423 *jrt.Class = A_arbace_main_ex_triage_fn__461000061_A_fn_class; if fncls__423 == nil { var fncls__423d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_main_ex_triage_fn__461000061_A_fn_class = fncls__423d; tmp34 = fncls__423d } else { tmp34 = fncls__423 }; arg_409 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var arg_410 any = trace__6; if linked_407 == nil { arg_405 = ifn_408.Invoke_O_O__O(arg_409, arg_410) } else { arg_405 = linked_407.(*aot_arbace_core.A_arbace_core_drop_while_A).Invoke_O_O_O__O(root_406, arg_409, arg_410) }; if linked_403 == nil { vec__461000058__23 = ifn_404.Invoke_O__O(arg_405) } else { vec__461000058__23 = linked_403.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_402, arg_405) }
//line :230:1
					var source__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000058__23, lang.RT_IntCast_J__I_NoInit(0), nil); var method__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000058__23, lang.RT_IntCast_J__I_NoInit(1), nil); var file__26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000058__23, lang.RT_IntCast_J__I_NoInit(2), nil); var line__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000058__23, lang.RT_IntCast_J__I_NoInit(3), nil); var file__28 any; var root_424 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_426 lang.IFn




























					if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any; var root_428 any = A_arbace_main_A_const_118.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any; var tmp35 any = A_arbace_main_ex_triage_fn__461000063_A_New(); var tmp36 *jrt.Class; var fncls__433 *jrt.Class = A_arbace_main_ex_triage_fn__461000063_A_fn_class; if fncls__433 == nil { var fncls__433d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_main_ex_triage_fn__461000063_A_fn_class = fncls__433d; tmp36 = fncls__433d } else { tmp36 = fncls__433 }; arg_431 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil); var arg_432 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_main_A_const_120.Invoke_O__O(caller__17), file__26); if linked_429 == nil { arg_427 = ifn_430.Invoke_O_O__O(arg_431, arg_432) } else { arg_427 = linked_429.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_428, arg_431, arg_432) }; if linked_425 == nil { file__28 = ifn_426.Invoke_O__O(arg_427) } else { file__28 = linked_425.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_424, arg_427) }
//line :230:1
					var err_line__29 any; var or__1927000174__auto____29 any = A_arbace_main_A_const_71.Invoke_O__O(caller__17)





























					if jrt.J2g_Truth(or__1927000174__auto____29) { err_line__29 = or__1927000174__auto____29 } else { err_line__29 = line__27 }
//line :230:1
					var G__461000065__30_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_main_A_const_109, type__10)); var G__461000065__31_ any






























					if jrt.J2g_Truth(err_line__29) {
						var root_434 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = G__461000065__30_; var arg_438 any = A_arbace_main_A_const_121; var arg_439 any = err_line__29; if linked_435 == nil { G__461000065__31_ = ifn_436.Invoke_O_O_O__O(arg_437, arg_438, arg_439) } else { G__461000065__31_ = linked_435.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_434, arg_437, arg_438, arg_439) } } else {
//line :261:1
							G__461000065__31_ = G__461000065__30_ }
//line :230:1
					var G__461000065__32_ any






























					if jrt.J2g_Truth(message__11) {

						var root_440 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = G__461000065__31_; var arg_444 any = A_arbace_main_A_const_110; var arg_445 any = message__11; if linked_441 == nil { G__461000065__32_ = ifn_442.Invoke_O_O_O__O(arg_443, arg_444, arg_445) } else { G__461000065__32_ = linked_441.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_440, arg_443, arg_444, arg_445) } } else {
//line :261:1
							G__461000065__32_ = G__461000065__31_ }
//line :230:1
					var G__461000065__33_ any; var tmp37 any
					var or__1927000174__auto____33 any = fn__16
































					if jrt.J2g_Truth(or__1927000174__auto____33) { tmp37 = or__1927000174__auto____33 } else { var and__1927000168__auto____34 any = source__24; if jrt.J2g_Truth(and__1927000168__auto____34) { tmp37 = method__25 } else { tmp37 = and__1927000168__auto____34 } }
//line :261:1
					if jrt.J2g_Truth(tmp37) {


						var root_446 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = G__461000065__32_; var arg_450 any = A_arbace_main_A_const_122; var arg_451 any; var or__1927000174__auto____33_2 any = fn__16; if jrt.J2g_Truth(or__1927000174__auto____33_2) { arg_451 = or__1927000174__auto____33_2 } else { var root_452 any = A_arbace_main_A_const_123.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, A_arbace_main_java_loc__GT_source_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = source__24; var arg_456 any = method__25; if linked_453 == nil { arg_451 = ifn_454.Invoke_O_O__O(arg_455, arg_456) } else { arg_451 = linked_453.(*A_arbace_main_java_loc__GT_source_A).Invoke_O_O_O__O(root_452, arg_455, arg_456) } }; if linked_447 == nil { G__461000065__33_ = ifn_448.Invoke_O_O_O__O(arg_449, arg_450, arg_451) } else { G__461000065__33_ = linked_447.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_446, arg_449, arg_450, arg_451) } } else {
//line :261:1
							G__461000065__33_ = G__461000065__32_ }
//line :230:1
					var G__461000065__34_ any






























					if jrt.J2g_Truth(file__28) {



						var root_457 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = G__461000065__33_; var arg_461 any = A_arbace_main_A_const_101; var arg_462 any = file__28; if linked_458 == nil { G__461000065__34_ = ifn_459.Invoke_O_O_O__O(arg_460, arg_461, arg_462) } else { G__461000065__34_ = linked_458.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_457, arg_460, arg_461, arg_462) } } else {
//line :261:1
							G__461000065__34_ = G__461000065__33_ }; if jrt.J2g_Truth(problems__15) {




								var root_463 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = G__461000065__34_; var arg_467 any = A_arbace_main_A_const_111; var arg_468 any = data__12; if linked_464 == nil { arg_278 = ifn_465.Invoke_O_O_O__O(arg_466, arg_467, arg_468) } else { arg_278 = linked_464.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_463, arg_466, arg_467, arg_468) } } else {
//line :261:1
									arg_278 = G__461000065__34_ }
//line :230:1
					break L1 }; case 6: if any(G__461000054__22_) == any(A_arbace_main_A_const_124) { var map__461000066__23 any = data__12; var map__461000066__24 any

						if lang.ISeq_InstanceOf(map__461000066__23) { var tmp38 any; var root_469 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = map__461000066__23; if linked_470 == nil { tmp38 = ifn_471.Invoke_O__O(arg_472) } else { tmp38 = linked_470.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_469, arg_472) }; if jrt.J2g_Truth(tmp38) { var tmp39 any; var root_473 any = A_arbace_main_A_const_68.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_475 lang.IFn; if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = map__461000066__23; if linked_474 == nil { tmp39 = ifn_475.Invoke_O__O(arg_476) } else { tmp39 = linked_474.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_473, arg_476) }; map__461000066__24 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp39, jrt.Object_class.ArrayClass())).Ref() } else { var tmp40 any; var root_477 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_479 lang.IFn; if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = map__461000066__23; if linked_478 == nil { tmp40 = ifn_479.Invoke_O__O(arg_480) } else { tmp40 = linked_478.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_477, arg_480) }; if jrt.J2g_Truth(tmp40) { var root_481 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = map__461000066__23; if linked_482 == nil { map__461000066__24 = ifn_483.Invoke_O__O(arg_484) } else { map__461000066__24 = linked_482.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_481, arg_484) } } else { map__461000066__24 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000066__24 = map__461000066__23 }
//line :230:1
						var line__25 any = lang.RT_Get_O_O__O_NoInit(map__461000066__24, A_arbace_main_A_const_121); var column__26 any = lang.RT_Get_O_O__O_NoInit(map__461000066__24, A_arbace_main_A_const_125); var G__461000068__27_ any; var root_485 any = A_arbace_main_A_const_126.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_487 lang.IFn; _ = line__25; _ = column__26


						if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any; var tmp41 *lang.Keyword = A_arbace_main_A_const_97; var tmp42 any; var root_490 any = A_arbace_main_A_const_15.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = via__5; if linked_491 == nil { tmp42 = ifn_492.Invoke_O__O(arg_493) } else { tmp42 = linked_491.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_490, arg_493) }; arg_488 = tmp41.Invoke_O__O(tmp42); var arg_489 any = top_data__20; if linked_486 == nil { G__461000068__27_ = ifn_487.Invoke_O_O__O(arg_488, arg_489) } else { G__461000068__27_ = linked_486.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_485, arg_488, arg_489) }
//line :230:1
						var G__461000068__28_ any


						if jrt.J2g_Truth(source__21) {
							var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_102.GetRawRoot__O()); var tmp44 any = A_arbace_main_A_const_101; var tmp45 any; var root_502 any = A_arbace_main_A_const_104.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, A_arbace_main_file_name_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = source__21; if linked_503 == nil { tmp45 = ifn_504.Invoke_O__O(arg_505) } else { tmp45 = linked_503.(*A_arbace_main_file_name_A).Invoke_O_O__O(root_502, arg_505) }; var tmp46 any = tmp45; var tmp47 any = A_arbace_main_A_const_105; var tmp48 any; var root_506 any = A_arbace_main_A_const_106.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, A_arbace_main_file_path_A_fn_class); var ifn_508 lang.IFn
							if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = source__21; if linked_507 == nil { tmp48 = ifn_508.Invoke_O__O(arg_509) } else { tmp48 = linked_507.(*A_arbace_main_file_path_A).Invoke_O_O__O(root_506, arg_509) }
//line :234:1
							G__461000068__28_ = tmp43.Invoke_O_O_O_O_O__O(G__461000068__27_, tmp44, tmp46, tmp47, tmp48) } else {
//line :233:1
								G__461000068__28_ = G__461000068__27_ }
//line :230:1
						var G__461000068__29_ any


						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_main_A_const_127).Invoke_O__O(source__21)) {


							G__461000068__29_ = lang.IFn_Cast(A_arbace_main_A_const_108.GetRawRoot__O()).Invoke_O_O_O__O(G__461000068__28_, A_arbace_main_A_const_101, A_arbace_main_A_const_105) } else {
//line :233:1
								G__461000068__29_ = G__461000068__28_ }; if jrt.J2g_Truth(message__11) {



									var root_516 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = G__461000068__29_; var arg_520 any = A_arbace_main_A_const_110; var arg_521 any = message__11; if linked_517 == nil { arg_278 = ifn_518.Invoke_O_O_O__O(arg_519, arg_520, arg_521) } else { arg_278 = linked_517.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_516, arg_519, arg_520, arg_521) } } else {
//line :233:1
										arg_278 = G__461000068__29_ }
//line :230:1
						break L1 }; case 9: if any(G__461000054__22_) == any(A_arbace_main_A_const_128) { var vec__461000069__23 any; var root_522 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_524 lang.IFn


















							if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = trace__6; if linked_523 == nil { vec__461000069__23 = ifn_524.Invoke_O__O(arg_525) } else { vec__461000069__23 = linked_523.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_522, arg_525) }
//line :230:1
							var source__24_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000069__23, lang.RT_IntCast_J__I_NoInit(0), nil); var method__25_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000069__23, lang.RT_IntCast_J__I_NoInit(1), nil); var file__26_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000069__23, lang.RT_IntCast_J__I_NoInit(2), nil); var line__27_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000069__23, lang.RT_IntCast_J__I_NoInit(3), nil); var G__461000072__28_ any = top_data__20; var G__461000072__29_ any



















							if jrt.J2g_Truth(line__27_2) {
								var root_526 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_528 lang.IFn; if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = G__461000072__28_; var arg_530 any = A_arbace_main_A_const_121; var arg_531 any = line__27_2; if linked_527 == nil { G__461000072__29_ = ifn_528.Invoke_O_O_O__O(arg_529, arg_530, arg_531) } else { G__461000072__29_ = linked_527.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_526, arg_529, arg_530, arg_531) } } else {
//line :250:1
									G__461000072__29_ = G__461000072__28_ }
//line :230:1
							var G__461000072__30_ any



















							if jrt.J2g_Truth(file__26_2) {

								var root_532 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = G__461000072__29_; var arg_536 any = A_arbace_main_A_const_101; var arg_537 any = file__26_2; if linked_533 == nil { G__461000072__30_ = ifn_534.Invoke_O_O_O__O(arg_535, arg_536, arg_537) } else { G__461000072__30_ = linked_533.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_532, arg_535, arg_536, arg_537) } } else {
//line :250:1
									G__461000072__30_ = G__461000072__29_ }
//line :230:1
							var G__461000072__31_ any; var tmp49 any
							var and__1927000168__auto____31 any = source__24_2





















							if jrt.J2g_Truth(and__1927000168__auto____31) { tmp49 = method__25_2 } else { tmp49 = and__1927000168__auto____31 }
//line :250:1
							if jrt.J2g_Truth(tmp49) {


								var root_538 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = G__461000072__30_; var arg_542 any = A_arbace_main_A_const_122; var arg_543 any; var root_544 any = A_arbace_main_A_const_123.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, A_arbace_main_java_loc__GT_source_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = source__24_2; var arg_548 any = method__25_2; if linked_545 == nil { arg_543 = ifn_546.Invoke_O_O__O(arg_547, arg_548) } else { arg_543 = linked_545.(*A_arbace_main_java_loc__GT_source_A).Invoke_O_O_O__O(root_544, arg_547, arg_548) }; if linked_539 == nil { G__461000072__31_ = ifn_540.Invoke_O_O_O__O(arg_541, arg_542, arg_543) } else { G__461000072__31_ = linked_539.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_538, arg_541, arg_542, arg_543) } } else {
//line :250:1
									G__461000072__31_ = G__461000072__30_ }
//line :230:1
							var G__461000072__32_ any



















							if jrt.J2g_Truth(type__10) {



								var root_549 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = G__461000072__31_; var arg_553 any = A_arbace_main_A_const_109; var arg_554 any = type__10; if linked_550 == nil { G__461000072__32_ = ifn_551.Invoke_O_O_O__O(arg_552, arg_553, arg_554) } else { G__461000072__32_ = linked_550.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_549, arg_552, arg_553, arg_554) } } else {
//line :250:1
									G__461000072__32_ = G__461000072__31_ }; if jrt.J2g_Truth(message__11) {




										var root_555 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = G__461000072__32_; var arg_559 any = A_arbace_main_A_const_110; var arg_560 any = message__11; if linked_556 == nil { arg_278 = ifn_557.Invoke_O_O_O__O(arg_558, arg_559, arg_560) } else { arg_278 = linked_556.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_555, arg_558, arg_559, arg_560) } } else {
//line :250:1
											arg_278 = G__461000072__32_ }
//line :230:1
							break L1 }; case 12: if any(G__461000054__22_) == any(A_arbace_main_A_const_129) { var G__461000073__23_ any = top_data__20; var G__461000073__24_ any









								if jrt.J2g_Truth(source__21) {
									var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_102.GetRawRoot__O()); var tmp51 any = A_arbace_main_A_const_101; var tmp52 any; var root_569 any = A_arbace_main_A_const_104.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, A_arbace_main_file_name_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = source__21; if linked_570 == nil { tmp52 = ifn_571.Invoke_O__O(arg_572) } else { tmp52 = linked_570.(*A_arbace_main_file_name_A).Invoke_O_O__O(root_569, arg_572) }; var tmp53 any = tmp52; var tmp54 any = A_arbace_main_A_const_105; var tmp55 any; var root_573 any = A_arbace_main_A_const_106.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, A_arbace_main_file_path_A_fn_class); var ifn_575 lang.IFn
									if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = source__21; if linked_574 == nil { tmp55 = ifn_575.Invoke_O__O(arg_576) } else { tmp55 = linked_574.(*A_arbace_main_file_path_A).Invoke_O_O__O(root_573, arg_576) }
//line :241:1
									G__461000073__24_ = tmp50.Invoke_O_O_O_O_O__O(G__461000073__23_, tmp51, tmp53, tmp54, tmp55) } else {
//line :240:1
										G__461000073__24_ = G__461000073__23_ }
//line :230:1
								var G__461000073__25_ any









								if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_main_A_const_130).Invoke_O__O(source__21)) {


									G__461000073__25_ = lang.IFn_Cast(A_arbace_main_A_const_108.GetRawRoot__O()).Invoke_O_O_O__O(G__461000073__24_, A_arbace_main_A_const_101, A_arbace_main_A_const_105) } else {
//line :240:1
										G__461000073__25_ = G__461000073__24_ }
//line :230:1
								var G__461000073__26_ any









								if jrt.J2g_Truth(type__10) {



									var root_583 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = G__461000073__25_; var arg_587 any = A_arbace_main_A_const_109; var arg_588 any = type__10; if linked_584 == nil { G__461000073__26_ = ifn_585.Invoke_O_O_O__O(arg_586, arg_587, arg_588) } else { G__461000073__26_ = linked_584.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_583, arg_586, arg_587, arg_588) } } else {
//line :240:1
										G__461000073__26_ = G__461000073__25_ }
//line :230:1
								var G__461000073__27_ any









								if jrt.J2g_Truth(message__11) {




									var root_589 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = G__461000073__26_; var arg_593 any = A_arbace_main_A_const_110; var arg_594 any = message__11; if linked_590 == nil { G__461000073__27_ = ifn_591.Invoke_O_O_O__O(arg_592, arg_593, arg_594) } else { G__461000073__27_ = linked_590.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_589, arg_592, arg_593, arg_594) } } else {
//line :240:1
										G__461000073__27_ = G__461000073__26_ }; if jrt.J2g_Truth(problems__15) {





											var root_595 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = G__461000073__27_; var arg_599 any = A_arbace_main_A_const_111; var arg_600 any = data__12; if linked_596 == nil { arg_278 = ifn_597.Invoke_O_O_O__O(arg_598, arg_599, arg_600) } else { arg_278 = linked_596.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_595, arg_598, arg_599, arg_600) } } else {
//line :240:1
												arg_278 = G__461000073__27_ }
//line :230:1
								break L1 }; case 15: if any(G__461000054__22_) == any(A_arbace_main_A_const_131) { var vec__461000074__23 any; var root_601 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_603 lang.IFn


















									if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = trace__6; if linked_602 == nil { vec__461000074__23 = ifn_603.Invoke_O__O(arg_604) } else { vec__461000074__23 = linked_602.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_601, arg_604) }
//line :230:1
									var source__24_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000074__23, lang.RT_IntCast_J__I_NoInit(0), nil); var method__25_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000074__23, lang.RT_IntCast_J__I_NoInit(1), nil); var file__26_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000074__23, lang.RT_IntCast_J__I_NoInit(2), nil); var line__27_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000074__23, lang.RT_IntCast_J__I_NoInit(3), nil); var G__461000077__28_ any = top_data__20; var G__461000077__29_ any



















									if jrt.J2g_Truth(line__27_3) {
										var root_605 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = G__461000077__28_; var arg_609 any = A_arbace_main_A_const_121; var arg_610 any = line__27_3; if linked_606 == nil { G__461000077__29_ = ifn_607.Invoke_O_O_O__O(arg_608, arg_609, arg_610) } else { G__461000077__29_ = linked_606.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_605, arg_608, arg_609, arg_610) } } else {
//line :250:1
											G__461000077__29_ = G__461000077__28_ }
//line :230:1
									var G__461000077__30_ any



















									if jrt.J2g_Truth(file__26_3) {

										var root_611 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = G__461000077__29_; var arg_615 any = A_arbace_main_A_const_101; var arg_616 any = file__26_3; if linked_612 == nil { G__461000077__30_ = ifn_613.Invoke_O_O_O__O(arg_614, arg_615, arg_616) } else { G__461000077__30_ = linked_612.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_611, arg_614, arg_615, arg_616) } } else {
//line :250:1
											G__461000077__30_ = G__461000077__29_ }
//line :230:1
									var G__461000077__31_ any; var tmp56 any
									var and__1927000168__auto____31_2 any = source__24_3





















									if jrt.J2g_Truth(and__1927000168__auto____31_2) { tmp56 = method__25_3 } else { tmp56 = and__1927000168__auto____31_2 }
//line :250:1
									if jrt.J2g_Truth(tmp56) {


										var root_617 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = G__461000077__30_; var arg_621 any = A_arbace_main_A_const_122; var arg_622 any; var root_623 any = A_arbace_main_A_const_123.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, A_arbace_main_java_loc__GT_source_A_fn_class); var ifn_625 lang.IFn; if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = source__24_3; var arg_627 any = method__25_3; if linked_624 == nil { arg_622 = ifn_625.Invoke_O_O__O(arg_626, arg_627) } else { arg_622 = linked_624.(*A_arbace_main_java_loc__GT_source_A).Invoke_O_O_O__O(root_623, arg_626, arg_627) }; if linked_618 == nil { G__461000077__31_ = ifn_619.Invoke_O_O_O__O(arg_620, arg_621, arg_622) } else { G__461000077__31_ = linked_618.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_617, arg_620, arg_621, arg_622) } } else {
//line :250:1
											G__461000077__31_ = G__461000077__30_ }
//line :230:1
									var G__461000077__32_ any



















									if jrt.J2g_Truth(type__10) {



										var root_628 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = G__461000077__31_; var arg_632 any = A_arbace_main_A_const_109; var arg_633 any = type__10; if linked_629 == nil { G__461000077__32_ = ifn_630.Invoke_O_O_O__O(arg_631, arg_632, arg_633) } else { G__461000077__32_ = linked_629.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_628, arg_631, arg_632, arg_633) } } else {
//line :250:1
											G__461000077__32_ = G__461000077__31_ }; if jrt.J2g_Truth(message__11) {




												var root_634 any = A_arbace_main_A_const_102.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = G__461000077__32_; var arg_638 any = A_arbace_main_A_const_110; var arg_639 any = message__11; if linked_635 == nil { arg_278 = ifn_636.Invoke_O_O_O__O(arg_637, arg_638, arg_639) } else { arg_278 = linked_635.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_634, arg_637, arg_638, arg_639) } } else {
//line :250:1
													arg_278 = G__461000077__32_ }
//line :230:1
									break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_32, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__461000054__22_)))))}; var arg_279 any = A_arbace_main_A_const_132; var arg_280 any = phase__7; if /*line :229:1*/ linked_276 == nil { return ifn_277.Invoke_O_O_O__O(arg_278, arg_279, arg_280) } else { return linked_276.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_275, arg_278, arg_279, arg_280) } }




























func A_arbace_main_ex_triage_fn__461000061_A_New() *A_arbace_main_ex_triage_fn__461000061_A { A_arbace_main_A_Init(); t := &A_arbace_main_ex_triage_fn__461000061_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_main_ex_triage_fn__461000061_A) Ctor() {}
//line :258:1
func (t *A_arbace_main_ex_triage_fn__461000061_A) Invoke_O_O__O(self, p1__461000042_SHARP___1 any) any { var root_411 any = A_arbace_main_A_const_117.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, A_arbace_main_core_class_QMARK__A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any; var root_415 any = A_arbace_main_A_const_89.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any; var root_419 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = p1__461000042_SHARP___1; if linked_420 == nil { arg_418 = ifn_421.Invoke_O__O(arg_422) } else { arg_418 = linked_420.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_419, arg_422) }; if linked_416 == nil { arg_414 = ifn_417.Invoke_O__O(arg_418) } else { arg_414 = linked_416.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_415, arg_418) }; if linked_412 == nil { return ifn_413.Invoke_O__O(arg_414) } else { return linked_412.(*A_arbace_main_core_class_QMARK__A).Invoke_O_O__O(root_411, arg_414) } }
func A_arbace_main_ex_triage_fn__461000063_A_New() *A_arbace_main_ex_triage_fn__461000063_A { A_arbace_main_A_Init(); t := &A_arbace_main_ex_triage_fn__461000063_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_main_ex_triage_fn__461000063_A) Ctor() {}
//line :259:1
func (t *A_arbace_main_ex_triage_fn__461000063_A) Invoke_O_O__O(self, p1__461000043_SHARP___1 any) any { var or__1927000174__auto____2 bool = lang.Util_Identical_O_O__Z_NoInit(p1__461000043_SHARP___1, nil); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { return lang.IFn_Cast(A_arbace_main_A_const_119).Invoke_O__O(p1__461000043_SHARP___1) } }









func A_arbace_main_ex_str_A_New() *A_arbace_main_ex_str_A { A_arbace_main_A_Init(); t := &A_arbace_main_ex_str_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_main_ex_str_A) Ctor() {}
//line :269:1
func (t *A_arbace_main_ex_str_A) Invoke_O_O__O(self, p__461000081__0 any) any { var map__461000082__2 any = p__461000081__0; var map__461000082__3 any; if lang.ISeq_InstanceOf(map__461000082__2) { var tmp1 any; var root_640 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = map__461000082__2; if linked_641 == nil { tmp1 = ifn_642.Invoke_O__O(arg_643) } else { tmp1 = linked_641.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_640, arg_643) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_644 any = A_arbace_main_A_const_68.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = map__461000082__2; if linked_645 == nil { tmp2 = ifn_646.Invoke_O__O(arg_647) } else { tmp2 = linked_645.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_644, arg_647) }; map__461000082__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_648 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = map__461000082__2; if linked_649 == nil { tmp3 = ifn_650.Invoke_O__O(arg_651) } else { tmp3 = linked_649.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_648, arg_651) }; if jrt.J2g_Truth(tmp3) { var root_652 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = map__461000082__2; if linked_653 == nil { map__461000082__3 = ifn_654.Invoke_O__O(arg_655) } else { map__461000082__3 = linked_653.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_652, arg_655) } } else { map__461000082__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000082__3 = map__461000082__2 }; var triage_data__4 any = map__461000082__3; var phase__5 any = lang.RT_Get_O_O__O_NoInit(map__461000082__3, A_arbace_main_A_const_132); var source__6 any = lang.RT_Get_O_O__O_NoInit(map__461000082__3, A_arbace_main_A_const_101); var path__7 any = lang.RT_Get_O_O__O_NoInit(map__461000082__3, A_arbace_main_A_const_105); var line__8 any = lang.RT_Get_O_O__O_NoInit(map__461000082__3, A_arbace_main_A_const_121); var column__9 any = lang.RT_Get_O_O__O_NoInit(map__461000082__3, A_arbace_main_A_const_125); var symbol__10 any = lang.RT_Get_O_O__O_NoInit(map__461000082__3, A_arbace_main_A_const_122); var class__11 any = lang.RT_Get_O_O__O_NoInit(map__461000082__3, A_arbace_main_A_const_109); var cause__12 any = lang.RT_Get_O_O__O_NoInit(map__461000082__3, A_arbace_main_A_const_110); var spec__13 any = lang.RT_Get_O_O__O_NoInit(map__461000082__3, A_arbace_main_A_const_111); var loc__14 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_14, nil, nil); var tmp5 any; var or__1927000174__auto____18 any = path__7; _ = triage_data__4; if






	jrt.J2g_Truth(or__1927000174__auto____18) { tmp5 = or__1927000174__auto____18 } else { var or__1927000174__auto____19 any = source__6; if jrt.J2g_Truth(or__1927000174__auto____19) { tmp5 = or__1927000174__auto____19 } else { tmp5 = Lit_15 } }; var tmp6 any = tmp5; var tmp7 any; var or__1927000174__auto____18_2 any = line__8; if jrt.J2g_Truth(or__1927000174__auto____18_2) { tmp7 = or__1927000174__auto____18_2 } else { tmp7 = A_arbace_main_A_const_76 }; var tmp8 any = tmp7; var tmp9 *jrt.String; if jrt.J2g_Truth(column__9) { tmp9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, nil, column__9)) } else { tmp9 = Lit_16 }; loc__14 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp6, nil, tmp8, tmp9.Ref())).Ref(); var class_name__15 any; var root_656 any = /*line :269:1*/A_arbace_main_A_const_89.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_658 lang.IFn; if







	linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any; var or__1927000174__auto____15 any = class__11; if jrt.J2g_Truth(or__1927000174__auto____15) { arg_659 = or__1927000174__auto____15 } else { arg_659 = Lit_16 }; if linked_657 == nil { class_name__15 = ifn_658.Invoke_O__O(arg_659) } else { class_name__15 = linked_657.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_656, arg_659) }; var simple_class__16 any; if
	jrt.J2g_Truth(class__11) { var or__1927000174__auto____16 any; var root_660 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any; var root_664 any = A_arbace_main_A_const_16.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = A_arbace_main_A_const_133; var arg_668 any = class_name__15; if linked_665 == nil { arg_663 = ifn_666.Invoke_O_O__O(arg_667, arg_668) } else { arg_663 = linked_665.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_664, arg_667, arg_668) }; if linked_661 == nil { or__1927000174__auto____16 = ifn_662.Invoke_O__O(arg_663) } else { or__1927000174__auto____16 = linked_661.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_660, arg_663) }; if jrt.J2g_Truth(or__1927000174__auto____16) { simple_class__16 = or__1927000174__auto____16 } else { simple_class__16 = class_name__15 } } else { simple_class__16 = nil }; var cause_type__17 any; var tmp10 any; var root_669 any = /*line :269:1*/A_arbace_main_A_const_13.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_671 lang.IFn; if









	linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = A_arbace_main_A_const_134; var arg_673 any = simple_class__16; if linked_670 == nil { tmp10 = ifn_671.Invoke_O_O__O(arg_672, arg_673) } else { tmp10 = linked_670.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_669, arg_672, arg_673) }; if jrt.J2g_Truth(tmp10) { cause_type__17 = Lit_16 } else {

		cause_type__17 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil, Lit_18), jrt.RefArrayOf(jrt.Object_class, nil, simple_class__16, nil)).Ref() }; var G__461000084__18_ any = phase__5; switch
	lang.Util_Hash_O__I_NoInit(G__461000084__18_) >> 3 & 15 { case 0: if any(G__461000084__18_) == any(A_arbace_main_A_const_103) {




		var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_135.GetRawRoot__O()); var tmp12 *jrt.String
		if jrt.J2g_Truth(symbol__10) { tmp12 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_20), jrt.RefArrayOf(jrt.Object_class, symbol__10, nil)) } else { tmp12 = Lit_16 }
//line :287:1
		var tmp13 any = tmp12.Ref(); var tmp14 any


		if jrt.J2g_Truth(spec__13) { var s__1927001093__auto____19 any = jrt.StringWriter_New(); var root_717 any = A_arbace_main_A_const_142.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_719 lang.IFn
			if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()).Invoke_O_O__O(A_arbace_main_A_const_144, s__1927001093__auto____19); if linked_718 == nil { ifn_719.Invoke_O__O(arg_720) } else { linked_718.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_717, arg_720) }; var tmp15 any = A_arbace_main_ex_str_fn__461000085_A_New_O_O(spec__13, s__1927001093__auto____19); var tmp16 *jrt.Class; var fncls__711 *jrt.Class = A_arbace_main_ex_str_fn__461000085_A_fn_class; if fncls__711 == nil { var fncls__711d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_main_ex_str_fn__461000085_A_fn_class = fncls__711d; tmp16 = fncls__711d } else { tmp16 = fncls__711 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O() } else {





				tmp14 = lang.IFn_Cast(A_arbace_main_A_const_135.GetRawRoot__O()).Invoke_O_O__O(Lit_22, cause__12) }
//line :287:1
		return tmp11.Invoke_O_O_O_O__O(Lit_19, tmp13, loc__14, tmp14) }
//line :282:1
	case 1: if any(G__461000084__18_) == any(A_arbace_main_A_const_112) {
























		var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_135.GetRawRoot__O()); var tmp18 *jrt.String

		if jrt.J2g_Truth(symbol__10) { tmp18 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_20), jrt.RefArrayOf(jrt.Object_class, symbol__10, nil)) } else { tmp18 = Lit_16 }
//line :307:1
		return tmp17.Invoke_O_O_O_O_O__O(Lit_23, cause_type__17, tmp18.Ref(), loc__14, cause__12) }
//line :282:1
	case 3: if any(G__461000084__18_) == any(A_arbace_main_A_const_114) {

















		var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_135.GetRawRoot__O()); var tmp20 *jrt.String

		if jrt.J2g_Truth(symbol__10) { tmp20 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_20), jrt.RefArrayOf(jrt.Object_class, symbol__10, nil)) } else { tmp20 = Lit_16 }
//line :300:1
		return tmp19.Invoke_O_O_O_O_O__O(Lit_24, cause_type__17, tmp20.Ref(), loc__14, cause__12) }
//line :282:1
	case 4: if any(G__461000084__18_) == any(A_arbace_main_A_const_90) {












































		if jrt.J2g_Truth(spec__13) {
			var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_135.GetRawRoot__O()); var tmp22 any; var s__1927001093__auto____19_2 any = jrt.StringWriter_New(); var root_779 any = A_arbace_main_A_const_142.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_781 lang.IFn


			if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()).Invoke_O_O__O(A_arbace_main_A_const_144, s__1927001093__auto____19_2); if linked_780 == nil { ifn_781.Invoke_O__O(arg_782) } else { linked_780.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_779, arg_782) }; var tmp23 any = A_arbace_main_ex_str_fn__461000091_A_New_O_O(spec__13, s__1927001093__auto____19_2); var tmp24 *jrt.Class; var fncls__778 *jrt.Class = A_arbace_main_ex_str_fn__461000091_A_fn_class; if fncls__778 == nil { var fncls__778d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_main_ex_str_fn__461000091_A_fn_class = fncls__778d; tmp24 = fncls__778d } else { tmp24 = fncls__778 }; tmp22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil).Invoke__O()
//line :328:1
			return tmp21.Invoke_O_O_O_O__O(Lit_25, symbol__10, loc__14, tmp22) } else {








				var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_135.GetRawRoot__O()); var tmp26 *jrt.String

				if jrt.J2g_Truth(symbol__10) { tmp26 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_20), jrt.RefArrayOf(jrt.Object_class, symbol__10, nil)) } else { tmp26 = Lit_16 }
//line :337:1
				return tmp25.Invoke_O_O_O_O_O__O(Lit_27, cause_type__17, tmp26.Ref(), loc__14, cause__12) } }
//line :282:1
	case 6: if any(G__461000084__18_) == any(A_arbace_main_A_const_124) {

		return lang.IFn_Cast(A_arbace_main_A_const_135.GetRawRoot__O()).Invoke_O_O_O__O(Lit_28, loc__14, cause__12) }
//line :282:1
	case 9: if any(G__461000084__18_) == any(A_arbace_main_A_const_128) {






































		return lang.IFn_Cast(A_arbace_main_A_const_135.GetRawRoot__O()).Invoke_O_O_O_O_O__O(Lit_29, cause_type__17, symbol__10, loc__14, cause__12) }
//line :282:1
	case 12: if any(G__461000084__18_) == any(A_arbace_main_A_const_129) {































		var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_135.GetRawRoot__O()); var tmp28 *jrt.String

		if jrt.J2g_Truth(symbol__10) { tmp28 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_20), jrt.RefArrayOf(jrt.Object_class, symbol__10, nil)) } else { tmp28 = Lit_16 }
//line :314:1
		return tmp27.Invoke_O_O_O_O_O__O(Lit_30, cause_type__17, tmp28.Ref(), loc__14, cause__12) }
//line :282:1
	case 15: if any(G__461000084__18_) == any(A_arbace_main_A_const_131) {









































		return lang.IFn_Cast(A_arbace_main_A_const_135.GetRawRoot__O()).Invoke_O_O_O_O_O__O(Lit_31, cause_type__17, symbol__10, loc__14, cause__12) }
//line :282:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_32, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__461000084__18_))))) }








func A_arbace_main_ex_str_fn__461000085_A_New_O_O(p0, p1 any) *A_arbace_main_ex_str_fn__461000085_A { A_arbace_main_A_Init(); t := &A_arbace_main_ex_str_fn__461000085_A{}; t.Ctor_O_O(p0, p1); return t }
//line :291:1
func (t *A_arbace_main_ex_str_fn__461000085_A) Ctor_O_O(c__spec, c__s__1927001093__auto__ any) { t.F_spec = c__spec; t.F_s__1927001093__auto__ = c__s__1927001093__auto__ }
//line :291:1
func (t *A_arbace_main_ex_str_fn__461000085_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var root_689 any = A_arbace_main_A_const_137.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_out_A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any
											if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_main_A_const_138.Get__O(), A_arbace_main_A_const_139.GetRawRoot__O()) {
												var root_693 any = A_arbace_main_A_const_140.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any; var t_ any = t.F_spec; t.F_spec = nil; arg_696 = t_; var arg_697 any = A_arbace_main_A_const_98; var arg_698 any; var tmp2 any = A_arbace_main_ex_str_fn__461000085_fn__461000086_A_New(); var tmp3 *jrt.Class; var fncls__710 *jrt.Class = A_arbace_main_ex_str_fn__461000085_fn__461000086_A_fn_class
												if fncls__710 == nil { var fncls__710d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_main_ex_str_fn__461000085_fn__461000086_A_fn_class = fncls__710d; tmp3 = fncls__710d } else { tmp3 = fncls__710 }; arg_698 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :294:1
			if linked_694 == nil { arg_692 = ifn_695.Invoke_O_O_O__O(arg_696, arg_697, arg_698) } else { arg_692 = linked_694.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_693, arg_696, arg_697, arg_698) } } else {
//line :293:1
				var t__2 any = t.F_spec; t.F_spec = nil; arg_692 = t__2 }
//line :292:1
		if linked_690 == nil { ifn_691.Invoke_O__O(arg_692) } else { linked_690.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_out_A).Invoke_O_O__O(root_689, arg_692) }
//line :291:1
		var root_682 any = A_arbace_main_A_const_85.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any; var t__3 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; arg_685 = t__3; if linked_683 == nil { tmp1 = ifn_684.Invoke_O__O(arg_685) } else { tmp1 = linked_683.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_682, arg_685) } }; return nil }(); var root_686 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; if linked_687 == nil { ifn_688.Invoke__O() } else { linked_687.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_686) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }



func A_arbace_main_ex_str_fn__461000085_fn__461000086_A_New() *A_arbace_main_ex_str_fn__461000085_fn__461000086_A { A_arbace_main_A_Init(); t := &A_arbace_main_ex_str_fn__461000085_fn__461000086_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_A) Ctor() {}
//line :295:1
func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_A) Invoke_O_O__O(self, probs__1 any) any { var root_699 any = A_arbace_main_A_const_83.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any; var tmp1 any = A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_New(); var tmp2 *jrt.Class; var fncls__709 *jrt.Class = A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_fn_class; if fncls__709 == nil { var fncls__709d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_fn_class = fncls__709d; tmp2 = fncls__709d } else { tmp2 = fncls__709 }; arg_702 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_703 any = probs__1; if linked_700 == nil { return ifn_701.Invoke_O_O__O(arg_702, arg_703) } else { return linked_700.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_699, arg_702, arg_703) } }
//line :295:1
func A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_New() *A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A { A_arbace_main_A_Init(); t := &A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A) Ctor() {}
//line :295:1
func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A) Invoke_O_O__O(self, p1__461000079_SHARP___1 any) any { var root_704 any = A_arbace_main_A_const_108.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_704, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_706 lang.IFn; if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = p1__461000079_SHARP___1; var arg_708 any = A_arbace_main_A_const_141; if linked_705 == nil { return ifn_706.Invoke_O_O__O(arg_707, arg_708) } else { return linked_705.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_704, arg_707, arg_708) } }



































func A_arbace_main_ex_str_fn__461000091_A_New_O_O(p0, p1 any) *A_arbace_main_ex_str_fn__461000091_A { A_arbace_main_A_Init(); t := &A_arbace_main_ex_str_fn__461000091_A{}; t.Ctor_O_O(p0, p1); return t }
//line :331:1
func (t *A_arbace_main_ex_str_fn__461000091_A) Ctor_O_O(c__spec, c__s__1927001093__auto__ any) { t.F_spec = c__spec; t.F_s__1927001093__auto__ = c__s__1927001093__auto__ }
//line :331:1
func (t *A_arbace_main_ex_str_fn__461000091_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var root_756 any = A_arbace_main_A_const_137.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_out_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any
											if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_main_A_const_138.Get__O(), A_arbace_main_A_const_139.GetRawRoot__O()) {
												var root_760 any = A_arbace_main_A_const_140.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any; var t_ any = t.F_spec; t.F_spec = nil; arg_763 = t_; var arg_764 any = A_arbace_main_A_const_98; var arg_765 any; var tmp2 any = A_arbace_main_ex_str_fn__461000091_fn__461000092_A_New(); var tmp3 *jrt.Class; var fncls__777 *jrt.Class = A_arbace_main_ex_str_fn__461000091_fn__461000092_A_fn_class
												if fncls__777 == nil { var fncls__777d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_main_ex_str_fn__461000091_fn__461000092_A_fn_class = fncls__777d; tmp3 = fncls__777d } else { tmp3 = fncls__777 }; arg_765 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :334:1
			if linked_761 == nil { arg_759 = ifn_762.Invoke_O_O_O__O(arg_763, arg_764, arg_765) } else { arg_759 = linked_761.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_760, arg_763, arg_764, arg_765) } } else {
//line :333:1
				var t__2 any = t.F_spec; t.F_spec = nil; arg_759 = t__2 }
//line :332:1
		if linked_757 == nil { ifn_758.Invoke_O__O(arg_759) } else { linked_757.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_out_A).Invoke_O_O__O(root_756, arg_759) }
//line :331:1
		var root_749 any = A_arbace_main_A_const_85.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any; var t__3 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; arg_752 = t__3; if linked_750 == nil { tmp1 = ifn_751.Invoke_O__O(arg_752) } else { tmp1 = linked_750.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_749, arg_752) } }; return nil }(); var root_753 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; if linked_754 == nil { ifn_755.Invoke__O() } else { linked_754.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_753) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }



func A_arbace_main_ex_str_fn__461000091_fn__461000092_A_New() *A_arbace_main_ex_str_fn__461000091_fn__461000092_A { A_arbace_main_A_Init(); t := &A_arbace_main_ex_str_fn__461000091_fn__461000092_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_A) Ctor() {}
//line :335:1
func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_A) Invoke_O_O__O(self, probs__1 any) any { var root_766 any = A_arbace_main_A_const_83.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_766, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any; var tmp1 any = A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_New(); var tmp2 *jrt.Class; var fncls__776 *jrt.Class = A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_fn_class; if fncls__776 == nil { var fncls__776d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_fn_class = fncls__776d; tmp2 = fncls__776d } else { tmp2 = fncls__776 }; arg_769 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_770 any = probs__1; if linked_767 == nil { return ifn_768.Invoke_O_O__O(arg_769, arg_770) } else { return linked_767.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_766, arg_769, arg_770) } }
//line :335:1
func A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_New() *A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A { A_arbace_main_A_Init(); t := &A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A) Ctor() {}
//line :335:1
func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A) Invoke_O_O__O(self, p1__461000080_SHARP___1 any) any { var root_771 any = A_arbace_main_A_const_108.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = p1__461000080_SHARP___1; var arg_775 any = A_arbace_main_A_const_141; if linked_772 == nil { return ifn_773.Invoke_O_O__O(arg_774, arg_775) } else { return linked_772.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_771, arg_774, arg_775) } }







func A_arbace_main_err__GT_msg_A_New() *A_arbace_main_err__GT_msg_A { A_arbace_main_A_Init(); t := &A_arbace_main_err__GT_msg_A{}; t.Ctor(); return t }
//line :343:1
func (t *A_arbace_main_err__GT_msg_A) Ctor() {}
//line :343:1
func (t *A_arbace_main_err__GT_msg_A) Invoke_O_O__O(self, e__0 any) any {


	var root_826 any = A_arbace_main_A_const_145.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, A_arbace_main_ex_str_A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any; var root_830 any = A_arbace_main_A_const_146.GetRawRoot__O(); var linked_831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_830, A_arbace_main_ex_triage_A_fn_class); var ifn_832 lang.IFn; if linked_831 == nil { ifn_832 = lang.IFn_Cast(root_830) } else { ifn_832 = nil }; var arg_833 any; var root_834 any = A_arbace_main_A_const_147.GetRawRoot__O(); var linked_835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_834, aot_arbace_core.A_arbace_core_Throwable__GT_map_A_fn_class); var ifn_836 lang.IFn; if linked_835 == nil { ifn_836 = lang.IFn_Cast(root_834) } else { ifn_836 = nil }; var arg_837 any = e__0; if linked_835 == nil { arg_833 = ifn_836.Invoke_O__O(arg_837) } else { arg_833 = linked_835.(*aot_arbace_core.A_arbace_core_Throwable__GT_map_A).Invoke_O_O__O(root_834, arg_837) }; if linked_831 == nil { arg_829 = ifn_832.Invoke_O__O(arg_833) } else { arg_829 = linked_831.(*A_arbace_main_ex_triage_A).Invoke_O_O__O(root_830, arg_833) }; if linked_827 == nil { return ifn_828.Invoke_O__O(arg_829) } else { return linked_827.(*A_arbace_main_ex_str_A).Invoke_O_O__O(root_826, arg_829)
	} }
func A_arbace_main_repl_caught_A_New() *A_arbace_main_repl_caught_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_caught_A{}; t.Ctor(); return t }
//line :348:1
func (t *A_arbace_main_repl_caught_A) Ctor() {}
//line :348:1
func (t *A_arbace_main_repl_caught_A) Invoke_O_O__O(self, e__0 any) any {


	var root_844 any = A_arbace_main_A_const_142.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()); var tmp2 any = A_arbace_main_A_const_144; var arg_847 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_main_A_const_149.Get__O()); if linked_845 == nil { ifn_846.Invoke_O__O(arg_847) } else { linked_845.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_844, arg_847) }
//line :348:1
	var tmp3 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_150.GetRawRoot__O()); var tmp5 any; var root_857 any = A_arbace_main_A_const_151.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, A_arbace_main_err__GT_msg_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = e__0; if linked_858 == nil { tmp5 = ifn_859.Invoke_O__O(arg_860) } else { tmp5 = linked_858.(*A_arbace_main_err__GT_msg_A).Invoke_O_O__O(root_857, arg_860) }; tmp4.Invoke_O__O(tmp5)
			var root_838 any = A_arbace_main_A_const_148.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; if linked_839 == nil { tmp3 = ifn_840.Invoke__O() } else { tmp3 = linked_839.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_838) } }
//line :348:1
		return nil }(); var root_841 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_843 lang.IFn


	if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; if linked_842 == nil { ifn_843.Invoke__O() } else { linked_842.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_841) }
//line :348:1
	if tmp6 != nil { panic(tmp6) }; return tmp3
}









func A_arbace_main_with_read_known_A_New() *A_arbace_main_with_read_known_A { A_arbace_main_A_Init(); t := &A_arbace_main_with_read_known_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_main_with_read_known_A) Ctor() {}
//line :359:1
func (t *A_arbace_main_with_read_known_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { var root_861 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_20.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_152); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()); var tmp4 any; var root_871 any = A_arbace_main_A_const_23.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_871, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any = A_arbace_main_A_const_24.GetRawRoot__O(); var arg_875 any; var root_876 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any; var root_880 any = A_arbace_main_A_const_20.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_153); var arg_884 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()); var tmp6 any; var root_885 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_20.GetRawRoot__O()); var tmp8 any = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_154); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()); var tmp10 any; var root_896 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_896, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_898 lang.IFn; if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = lang.IFn_Cast(A_arbace_main_A_const_20.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_155), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_156), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_157)); if linked_897 == nil { tmp10 = ifn_898.Invoke_O__O(arg_899) } else { tmp10 = linked_897.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_896, arg_899) }; arg_888 = tmp7.Invoke_O_O_O_O__O(tmp8, tmp9.Invoke_O__O(tmp10), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_TRUE.Ref()), lang.IFn_Cast(A_arbace_main_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_158)); if linked_886 == nil { tmp6 = ifn_887.Invoke_O__O(arg_888) } else { tmp6 = linked_886.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_885, arg_888) }; arg_884 = tmp5.Invoke_O__O(tmp6); if linked_881 == nil { arg_879 = ifn_882.Invoke_O_O__O(arg_883, arg_884) } else { arg_879 = linked_881.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_880, arg_883, arg_884) }; if linked_877 == nil { arg_875 = ifn_878.Invoke_O__O(arg_879) } else { arg_875 = linked_877.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_876, arg_879) }; if linked_872 == nil { tmp4 = ifn_873.Invoke_O_O__O(arg_874, arg_875) } else { tmp4 = linked_872.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_871, arg_874, arg_875) }; arg_864 = tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4), body__2); if linked_862 == nil { return ifn_863.Invoke_O__O(arg_864) } else { return linked_862.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_861, arg_864) } }






func A_arbace_main_repl_A_New() *A_arbace_main_repl_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_main_repl_A) Ctor() {}
//line :366:1
func (t *A_arbace_main_repl_A) DoInvoke_O_O__O(self, options__0 any) any { var tmp1 any = jrt.Thread_CurrentThread__Thread(); var tmp2 *jrt.Class = A_arbace_main_A_const_181; var cl__2 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp1, tmp2, Lit_65, jrt.RefArrayOf(jrt.Object_class)); var tmp3 any = jrt.Thread_CurrentThread__Thread(); var tmp4 *jrt.Class = A_arbace_main_A_const_181;












































	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp3, tmp4, Lit_66, jrt.RefArrayOf(jrt.Object_class, cl__2)); var default__461000107__2 any; var tmp5 any = /*line :366:1*/A_arbace_main_repl_default__461000107__461000116_A_New(); var tmp6 *jrt.Class; var fncls__906 *jrt.Class = A_arbace_main_repl_default__461000107__461000116_A_fn_class; if













































	fncls__906 == nil { var fncls__906d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_main_repl_default__461000107__461000116_A_fn_class = fncls__906d; tmp6 = fncls__906d } else { tmp6 = fncls__906 }; default__461000107__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var default__461000108__3 any; if

	lang.LineNumberingPushbackReader_InstanceOf(A_arbace_main_A_const_75.Get__O()) { var tmp7 any = A_arbace_main_repl_fn__461000118_A_New(); var tmp8 *jrt.Class; var fncls__907 *jrt.Class = A_arbace_main_repl_fn__461000118_A_fn_class; if fncls__907 == nil { var fncls__907d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_main_repl_fn__461000118_A_fn_class = fncls__907d; tmp8 = fncls__907d } else { tmp8 = fncls__907 }; default__461000108__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil) } else { var tmp9 any = A_arbace_main_repl_fn__461000120_A_New(); var tmp10 *jrt.Class; var fncls__912 *jrt.Class = A_arbace_main_repl_fn__461000120_A_fn_class; if fncls__912 == nil { var fncls__912d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_main_repl_fn__461000120_A_fn_class = fncls__912d; tmp10 = fncls__912d } else { tmp10 = fncls__912 }; default__461000108__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil) }; var default__461000109__4 any = /*line :366:1*/A_arbace_main_A_const_160.GetRawRoot__O(); var default__461000110__5 any = A_arbace_main_A_const_148.GetRawRoot__O(); var default__461000111__6 any = A_arbace_main_A_const_161.GetRawRoot__O(); var default__461000112__7 any = A_arbace_main_A_const_162.GetRawRoot__O(); var default__461000113__8 any = A_arbace_main_A_const_163.GetRawRoot__O(); var default__461000114__9 any = A_arbace_main_A_const_164.GetRawRoot__O(); var map__461000105__10 any; var root_913 any = A_arbace_main_A_const_23.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_913, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_915 lang.IFn; if
























































	linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = A_arbace_main_A_const_143.GetRawRoot__O(); var arg_917 any = options__0; if linked_914 == nil { map__461000105__10 = ifn_915.Invoke_O_O__O(arg_916, arg_917) } else { map__461000105__10 = linked_914.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_913, arg_916, arg_917) }; var map__461000105__11 any; if /*line :412:1*/ lang.ISeq_InstanceOf(map__461000105__10) { var tmp11 any; var root_918 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = map__461000105__10; if linked_919 == nil { tmp11 = ifn_920.Invoke_O__O(arg_921) } else { tmp11 = linked_919.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_918, arg_921) }; if jrt.J2g_Truth(tmp11) { var tmp12 any; var root_922 any = A_arbace_main_A_const_68.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = map__461000105__10; if linked_923 == nil { tmp12 = ifn_924.Invoke_O__O(arg_925) } else { tmp12 = linked_923.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_922, arg_925) }; map__461000105__11 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp12, jrt.Object_class.ArrayClass())).Ref() } else { var tmp13 any; var root_926 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = map__461000105__10; if linked_927 == nil { tmp13 = ifn_928.Invoke_O__O(arg_929) } else { tmp13 = linked_927.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_926, arg_929) }; if jrt.J2g_Truth(tmp13) { var root_930 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = map__461000105__10; if linked_931 == nil { map__461000105__11 = ifn_932.Invoke_O__O(arg_933) } else { map__461000105__11 = linked_931.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_930, arg_933) } } else { map__461000105__11 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000105__11 = map__461000105__10 }; var init__12 any = /*line :366:1*/lang.RT_Get_O_O_O__O_NoInit(map__461000105__11, A_arbace_main_A_const_165, default__461000107__2); var need_prompt__13 any = lang.RT_Get_O_O_O__O_NoInit(map__461000105__11, A_arbace_main_A_const_166, default__461000108__3); var prompt__14 any = lang.RT_Get_O_O_O__O_NoInit(map__461000105__11, A_arbace_main_A_const_167, default__461000109__4); var flush__15 any = lang.RT_Get_O_O_O__O_NoInit(map__461000105__11, A_arbace_main_A_const_168, default__461000110__5); var read__16 any = lang.RT_Get_O_O_O__O_NoInit(map__461000105__11, A_arbace_main_A_const_169, default__461000111__6); var eval__17 any = lang.RT_Get_O_O_O__O_NoInit(map__461000105__11, A_arbace_main_A_const_170, default__461000112__7); var print__18 any = lang.RT_Get_O_O_O__O_NoInit(map__461000105__11, A_arbace_main_A_const_171, default__461000113__8); var caught__19 any = lang.RT_Get_O_O_O__O_NoInit(map__461000105__11, A_arbace_main_A_const_172, default__461000114__9); var request_prompt__20 any = jrt.Object_New(); var request_exit__21 any = jrt.Object_New(); var read_eval_print__22 any; var tmp14 any = A_arbace_main_repl_read_eval_print__461000122_A_New_O_O_O_O_O_O(request_prompt__20, read__16, caught__19, eval__17, request_exit__21, print__18); var tmp15 *jrt.Class; var fncls__972 *jrt.Class = A_arbace_main_repl_read_eval_print__461000122_A_fn_class; if




























































	fncls__972 == nil { var fncls__972d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_main_repl_read_eval_print__461000122_A_fn_class = fncls__972d; tmp15 = fncls__972d } else { tmp15 = fncls__972 }; read_eval_print__22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var root_980 any =


















	A_arbace_main_A_const_142.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var tmp16 any = A_arbace_main_A_const_58; var tmp17 any = A_arbace_main_A_const_58.Get__O(); var tmp18 any = A_arbace_main_A_const_182; var tmp19 any = A_arbace_main_A_const_182.Get__O(); var tmp20 any = A_arbace_main_A_const_183; var tmp21 any = A_arbace_main_A_const_183.Get__O(); var tmp22 any = A_arbace_main_A_const_184; var tmp23 any = A_arbace_main_A_const_184.Get__O(); var tmp24 any = A_arbace_main_A_const_185; var tmp25 any = A_arbace_main_A_const_185.Get__O(); var tmp26 any = A_arbace_main_A_const_186; var tmp27 any = A_arbace_main_A_const_186.Get__O(); var tmp28 any = A_arbace_main_A_const_187; var tmp29 any = jrt.Boolean_TRUE.Ref(); var tmp30 any = A_arbace_main_A_const_188; var tmp31 any = A_arbace_main_A_const_188.Get__O(); var tmp32 any = A_arbace_main_A_const_189; var tmp33 any = A_arbace_main_A_const_189.Get__O(); var tmp34 any = A_arbace_main_A_const_190; var tmp35 any = jrt.System_GetProperty_String_String__String(Lit_63, Lit_64).Ref(); var tmp36 any = A_arbace_main_A_const_191; var tmp37 any = A_arbace_main_A_const_191.Get__O(); var tmp38 any = A_arbace_main_A_const_192; var tmp39 any = A_arbace_main_A_const_192.Get__O(); var tmp40 any = A_arbace_main_A_const_193; var tmp41 any = A_arbace_main_A_const_193.Get__O(); var tmp42 any = A_arbace_main_A_const_138; var arg_983 any = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()).ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, A_arbace_main_A_const_138.Get__O(), A_arbace_main_A_const_178, nil, A_arbace_main_A_const_177, nil, A_arbace_main_A_const_176, nil, A_arbace_main_A_const_180, nil)))); if linked_981 == nil { ifn_982.Invoke_O__O(arg_983) } else { linked_981.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_980, arg_983) }; var tmp43 any; tmp49 := /*line :366:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
















































































		{ var root_984 any = A_arbace_main_A_const_142.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()).Invoke_O_O__O(A_arbace_main_A_const_194, jrt.Boolean_TRUE.Ref()); if linked_985 == nil { ifn_986.Invoke_O__O(arg_987) } else { linked_985.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_984, arg_987) }; tmp48 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
			{ var tmp44 any = A_arbace_main_repl_fn__461000128_A_New_O_O(init__12, caught__19); var tmp45 *jrt.Class; var fncls__993 *jrt.Class = A_arbace_main_repl_fn__461000128_A_fn_class; if fncls__993 == nil { var fncls__993d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_main_repl_fn__461000128_A_fn_class = fncls__993d; tmp45 = fncls__993d } else { tmp45 = fncls__993 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp44, tmp45, nil).Invoke__O()




				lang.IFn_Cast(prompt__14).Invoke__O()
				lang.IFn_Cast(flush__15).Invoke__O()
//line :366:1
			L1: for {

























































































				var tmp46 any = A_arbace_main_repl_fn__461000130_A_New_O_O_O(caught__19, request_exit__21, read_eval_print__22); var tmp47 *jrt.Class; var fncls__973 *jrt.Class = A_arbace_main_repl_fn__461000130_A_fn_class
				if fncls__973 == nil { var fncls__973d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_main_repl_fn__461000130_A_fn_class = fncls__973d; tmp47 = fncls__973d } else { tmp47 = fncls__973 }
//line :456:1
				if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil).Invoke__O()) { tmp43 = nil } else {





					if jrt.J2g_Truth(lang.IFn_Cast(need_prompt__13).Invoke__O()) {
						lang.IFn_Cast(prompt__14).Invoke__O()
						lang.IFn_Cast(flush__15).Invoke__O() }
					continue L1 }
//line :366:1
				break L1
			}
			}














































































			return nil }(); var root_974 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_976 lang.IFn; if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; if linked_975 == nil { ifn_976.Invoke__O() } else { linked_975.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_974) }
//line :366:1
			if tmp48 != nil { panic(tmp48) } }; return nil }(); var root_977 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_977, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_979 lang.IFn; if















































































	linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; if linked_978 == nil { ifn_979.Invoke__O() } else { linked_978.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_977) }; if /*line :366:1*/ tmp49 != nil { panic(tmp49) }; return tmp43 }













































func A_arbace_main_repl_default__461000107__461000116_A_New() *A_arbace_main_repl_default__461000107__461000116_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_default__461000107__461000116_A{}; t.Ctor(); return t }
//line :412:1
func (t *A_arbace_main_repl_default__461000107__461000116_A) Ctor() {}
//line :412:1
func (t *A_arbace_main_repl_default__461000107__461000116_A) Invoke_O__O(self any) any { return lang.PersistentList_EMPTY.Ref() }

func A_arbace_main_repl_fn__461000118_A_New() *A_arbace_main_repl_fn__461000118_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_fn__461000118_A{}; t.Ctor(); return t }
//line :414:1
func (t *A_arbace_main_repl_fn__461000118_A) Ctor() {}
//line :414:1
func (t *A_arbace_main_repl_fn__461000118_A) Invoke_O__O(self any) any {
	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(lang.LineNumberingPushbackReader_Cast(A_arbace_main_A_const_75.Get__O())).AtLineStart__Z()).Ref() }
//line :414:1
func A_arbace_main_repl_fn__461000120_A_New() *A_arbace_main_repl_fn__461000120_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_fn__461000120_A{}; t.Ctor(); return t }
//line :414:1
func (t *A_arbace_main_repl_fn__461000120_A) Ctor() {}
//line :414:1
func (t *A_arbace_main_repl_fn__461000120_A) Invoke_O__O(self any) any {

	var root_908 any = A_arbace_main_A_const_159.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_core.A_arbace_core_identity_A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = jrt.Boolean_TRUE.Ref(); if linked_909 == nil { return ifn_910.Invoke_O__O(arg_911) } else { return linked_909.(*aot_arbace_core.A_arbace_core_identity_A).Invoke_O_O__O(root_908, arg_911)
	}
}








func A_arbace_main_repl_read_eval_print__461000122_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_main_repl_read_eval_print__461000122_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_read_eval_print__461000122_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :427:1
func (t *A_arbace_main_repl_read_eval_print__461000122_A) Ctor_O_O_O_O_O_O(c__request_prompt, c__read, c__caught, c__eval, c__request_exit, c__print any) { t.F_request_prompt = c__request_prompt; t.F_read = c__read; t.F_caught = c__caught; t.F_eval = c__eval; t.F_request_exit = c__request_exit; t.F_print = c__print }
//line :427:1
func (t *A_arbace_main_repl_read_eval_print__461000122_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var read_eval__3 any = A_arbace_main_A_const_173.Get__O(); var input__4 any; var tmp2 any = A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_New_O_O_O(t.F_request_prompt, t.F_read, t.F_request_exit); var tmp3 *jrt.Class
											var fncls__952 /*line :427:1*/*jrt.Class = A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_fn_class


	if fncls__952 == nil { var fncls__952d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_fn_class = fncls__952d; tmp3 = fncls__952d } else { tmp3 = fncls__952 }; input__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :427:1
	var or__1927000174__auto____5 any = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, t.F_request_exit, t.F_request_prompt))).Invoke_O__O(input__4)






	if jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { var value__6 any; var root_957 any = A_arbace_main_A_const_142.GetRawRoot__O(); var linked_958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_957, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_959 lang.IFn
		if linked_958 == nil { ifn_959 = lang.IFn_Cast(root_957) } else { ifn_959 = nil }; var arg_960 any = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()).Invoke_O_O__O(A_arbace_main_A_const_173, read_eval__3); if linked_958 == nil { ifn_959.Invoke_O__O(arg_960) } else { linked_958.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_957, arg_960) }; var tmp4 any = A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_New_O_O(input__4, t.F_eval); var tmp5 *jrt.Class; var fncls__956 *jrt.Class = A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_fn_class; if fncls__956 == nil { var fncls__956d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_fn_class = fncls__956d; tmp5 = fncls__956d } else { tmp5 = fncls__956 }; value__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O()
//line :434:1
		var tmp6 *lang.Var = A_arbace_main_A_const_176; tmp6.Set_O__O(A_arbace_main_A_const_177.Get__O()); var tmp7 *lang.Var = A_arbace_main_A_const_177; tmp7.Set_O__O(A_arbace_main_A_const_178.Get__O()); A_arbace_main_A_const_178.Set_O__O(value__6); tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





			tmp1 = lang.IFn_Cast(t.F_print).Invoke_O__O(value__6)
//line :434:1
			return nil }(); if tmp8 != nil { if true { var e__9 jrt.Throwable_I = tmp8; var tmp9 any; var root_966 any = A_arbace_main_A_const_174.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_968 lang.IFn







				if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any; var arg_970 any = A_arbace_main_A_const_179; var arg_971 any = e__9; if linked_967 == nil { tmp9 = ifn_968.Invoke_O_O_O__O(arg_969, arg_970, arg_971) } else { tmp9 = linked_967.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O_O__O(root_966, arg_969, arg_970, arg_971) }
//line :434:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp9))) } } } }; return nil }(); if /*line :427:1*/ tmp10 != nil { if true { var e__3 jrt.Throwable_I = tmp10
















					lang.IFn_Cast(t.F_caught).Invoke_O__O(e__3)
//line :427:1
					tmp1 = A_arbace_main_A_const_180.Set_O__O(e__3) } }; return tmp1 }


func A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_New_O_O_O(p0, p1, p2 any) *A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :430:1
func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A) Ctor_O_O_O(c__request_prompt, c__read, c__request_exit any) { t.F_request_prompt = c__request_prompt; t.F_read = c__read; t.F_request_exit = c__request_exit }
//line :430:1
func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var root_937 any = A_arbace_main_A_const_142.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()); var tmp3 any = A_arbace_main_A_const_173; var tmp4 any; var tmp5 any = A_arbace_main_A_const_156; if lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_main_A_const_173.Get__O()) { tmp4 = jrt.Boolean_TRUE.Ref() } else { tmp4 = A_arbace_main_A_const_173.Get__O() }; arg_940 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_938 == nil { ifn_939.Invoke_O__O(arg_940) } else { linked_938.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_937, arg_940) }; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp6 any; var t_ any = t.F_read; t.F_read = nil; tmp6 = t_; var tmp7 lang.IFn = lang.IFn_Cast(tmp6); var tmp8 any; var t__2 any = t.F_request_prompt; t.F_request_prompt = nil; tmp8 = t__2; var tmp9 any = tmp8; var tmp10 any; var t__3 any = t.F_request_exit; t.F_request_exit = nil; tmp10 = t__3; tmp1 = tmp7.Invoke_O_O__O(tmp9, tmp10) }; return nil }(); var root_934 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; if linked_935 == nil { ifn_936.Invoke__O() } else { linked_935.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_934) }
//line :430:1
		if tmp11 != nil { panic(tmp11) } }; return nil }(); if tmp12 != nil { if lang.LispReader_ReaderException_InstanceOf(tmp12) { var e__3 *lang.LispReader_ReaderException = lang.LispReader_ReaderException_Cast(tmp12); var tmp13 any; var root_946 any = A_arbace_main_A_const_174.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_948 lang.IFn


			if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any; var arg_950 any = A_arbace_main_A_const_175; var arg_951 any = e__3.Ref(); if linked_947 == nil { tmp13 = ifn_948.Invoke_O_O_O__O(arg_949, arg_950, arg_951) } else { tmp13 = linked_947.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O_O__O(root_946, arg_949, arg_950, arg_951) }
//line :430:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp13))) } else { panic(tmp12) } }; return tmp1 }




func A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_New_O_O(p0, p1 any) *A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A{}; t.Ctor_O_O(p0, p1); return t }
//line :435:1
func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A) Ctor_O_O(c__input, c__eval any) { t.F_input = c__input; t.F_eval = c__eval }
//line :435:1
func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_eval; t.F_eval = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_input; t.F_input = nil; tmp4 = t__2; tmp1 = tmp3.Invoke_O__O(tmp4) }; return nil }(); var root_953 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_953, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_955 lang.IFn; if linked_954 == nil { ifn_955 = lang.IFn_Cast(root_953) } else { ifn_955 = nil }; if linked_954 == nil { ifn_955.Invoke__O() } else { linked_954.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_953) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }












func A_arbace_main_repl_fn__461000128_A_New_O_O(p0, p1 any) *A_arbace_main_repl_fn__461000128_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_fn__461000128_A{}; t.Ctor_O_O(p0, p1); return t }
//line :448:1
func (t *A_arbace_main_repl_fn__461000128_A) Ctor_O_O(c__init, c__caught any) { t.F_init = c__init; t.F_caught = c__caught }
//line :448:1
func (t *A_arbace_main_repl_fn__461000128_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
									{ var tmp2 any; var t_ any = t.F_init; t.F_init = nil; tmp2 = t_; tmp1 = lang.IFn_Cast(tmp2).Invoke__O() }
//line :448:1
	return nil }(); if tmp3 != nil { if true { var e__3 jrt.Throwable_I = tmp3; var tmp4 any; var t__2 any = t.F_caught


		t.F_caught = nil; tmp4 = t__2; lang.IFn_Cast(tmp4).Invoke_O__O(e__3)
//line :448:1
		tmp1 = A_arbace_main_A_const_180.Set_O__O(e__3) } }; return tmp1 }








func A_arbace_main_repl_fn__461000130_A_New_O_O_O(p0, p1, p2 any) *A_arbace_main_repl_fn__461000130_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_fn__461000130_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :457:1
func (t *A_arbace_main_repl_fn__461000130_A) Ctor_O_O_O(c__caught, c__request_exit, c__read_eval_print any) { t.F_caught = c__caught; t.F_request_exit = c__request_exit; t.F_read_eval_print = c__read_eval_print }
//line :457:1
func (t *A_arbace_main_repl_fn__461000130_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_read_eval_print; t.F_read_eval_print = nil; tmp2 = t_; var tmp3 any = lang.IFn_Cast(tmp2).Invoke__O(); var tmp4 any; var t__2 any = t.F_request_exit; t.F_request_exit = nil; tmp4 = t__2; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp3, tmp4)).Ref() }; return nil }(); if tmp5 != nil { if true { var e__3 jrt.Throwable_I = tmp5; var tmp6 any; var t__3 any = t.F_caught

	t.F_caught = nil; tmp6 = t__3; lang.IFn_Cast(tmp6).Invoke_O__O(e__3)
//line :457:1
	A_arbace_main_A_const_180.Set_O__O(e__3); tmp1 = nil } }; return tmp1 }









func A_arbace_main_load_script_A_New() *A_arbace_main_load_script_A { A_arbace_main_A_Init(); t := &A_arbace_main_load_script_A{}; t.Ctor(); return t }
//line :467:1
func (t *A_arbace_main_load_script_A) Ctor() {}
//line :467:1
func (t *A_arbace_main_load_script_A) Invoke_O_O__O(self, path__0 any) any {





	if jrt.NN(jrt.String_Cast(path__0)).StartsWith_String__Z(Lit_50) {

		var tmp1 any; var root_994 any = A_arbace_main_A_const_195.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = A_arbace_main_A_const_196; if linked_995 == nil { tmp1 = ifn_996.Invoke_O__O(arg_997) } else { tmp1 = linked_995.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_994, arg_997) }; return lang.IFn_Cast(tmp1).Invoke_O__O(jrt.NN(jrt.String_Cast(path__0)).Substring_I__String(lang.RT_IntCast_J__I_NoInit(4)).Ref()) } else {
//line :473:1
			if jrt.NN(jrt.String_Cast(path__0)).StartsWith_String__Z(Lit_51) {



				var tmp2 *jrt.String = jrt.String_Cast(path__0); var tmp3 int64
				if jrt.NN(jrt.String_Cast(path__0)).StartsWith_String__Z(Lit_52) { tmp3 = 2 } else { tmp3 = 1 }
//line :477:1
				lang.RT_LoadResourceScript_String__V_NoInit(jrt.NN(tmp2).Substring_I__String(lang.RT_IntCast_J__I_NoInit(tmp3))); return nil } else {
//line :473:1
					if A_arbace_main_A_const_62 != nil {






						return lang.Compiler_LoadFile_String__O_NoInit(jrt.String_Cast(path__0)) } else {
//line :473:1
							return nil
						}
				}
		}
}




func A_arbace_main_init_opt_A_New() *A_arbace_main_init_opt_A { A_arbace_main_A_Init(); t := &A_arbace_main_init_opt_A{}; t.Ctor(); return t }
//line :482:1
func (t *A_arbace_main_init_opt_A) Ctor() {}
//line :482:1
func (t *A_arbace_main_init_opt_A) Invoke_O_O__O(self, path__0 any) any {


	var root_998 any = A_arbace_main_A_const_197.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, A_arbace_main_load_script_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = path__0; if linked_999 == nil { return ifn_1000.Invoke_O__O(arg_1001) } else { return linked_999.(*A_arbace_main_load_script_A).Invoke_O_O__O(root_998, arg_1001)
	} }
func A_arbace_main_eval_opt_A_New() *A_arbace_main_eval_opt_A { A_arbace_main_A_Init(); t := &A_arbace_main_eval_opt_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_main_eval_opt_A) Ctor() {}
//line :487:1
func (t *A_arbace_main_eval_opt_A) Invoke_O_O__O(self, str__0 any) any { { var eof__2 any = jrt.Object_New(); var reader__3 any = lang.LineNumberingPushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(str__0))); var input__4 any; var root_1016 any = A_arbace_main_A_const_142.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1018 lang.IFn




	if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()); var tmp2 any = A_arbace_main_A_const_173; var tmp3 any; var tmp4 any = A_arbace_main_A_const_156; if lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_main_A_const_173.Get__O()) { tmp3 = jrt.Boolean_TRUE.Ref() } else { tmp3 = A_arbace_main_A_const_173.Get__O() }; arg_1019 = tmp1.Invoke_O_O__O(tmp2, tmp3); if linked_1017 == nil { ifn_1018.Invoke_O__O(arg_1019) } else { linked_1017.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1016, arg_1019) }; var tmp5 any = A_arbace_main_eval_opt_fn__461000135_A_New_O_O(reader__3, eof__2); var tmp6 *jrt.Class; var fncls__1011 *jrt.Class = A_arbace_main_eval_opt_fn__461000135_A_fn_class; if fncls__1011 == nil { var fncls__1011d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_main_eval_opt_fn__461000135_A_fn_class = fncls__1011d; tmp6 = fncls__1011d } else { tmp6 = fncls__1011 }; input__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
//line :487:1
L1: for {





	if lang.Util_Equiv_O_O__Z_NoInit(input__4, eof__2) { return nil } else { var value__5 any; var root_1012 any = A_arbace_main_A_const_162.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_eval_A_fn_class); var ifn_1014 lang.IFn
		if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = input__4; if linked_1013 == nil { value__5 = ifn_1014.Invoke_O__O(arg_1015) } else { value__5 = linked_1013.(*aot_arbace_core.A_arbace_core_eval_A).Invoke_O_O__O(root_1012, arg_1015) }
		if lang.Util_Identical_O_O__Z_NoInit(value__5, nil) { } else {
			lang.IFn_Cast(A_arbace_main_A_const_163.GetRawRoot__O()).Invoke_O__O(value__5) }
		var tmp7 any; var root_1039 any = A_arbace_main_A_const_142.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1041 lang.IFn; if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()); var tmp9 any = A_arbace_main_A_const_173; var tmp10 any; var tmp11 any = A_arbace_main_A_const_156; if lang.Util_Equiv_O_O__Z_NoInit(tmp11, A_arbace_main_A_const_173.Get__O()) { tmp10 = jrt.Boolean_TRUE.Ref() } else { tmp10 = A_arbace_main_A_const_173.Get__O() }; arg_1042 = tmp8.Invoke_O_O__O(tmp9, tmp10); if linked_1040 == nil { ifn_1041.Invoke_O__O(arg_1042) } else { linked_1040.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1039, arg_1042) }; var tmp12 any = A_arbace_main_eval_opt_fn__461000137_A_New_O_O(reader__3, eof__2); var tmp13 *jrt.Class; var fncls__1038 *jrt.Class = A_arbace_main_eval_opt_fn__461000137_A_fn_class; if fncls__1038 == nil { var fncls__1038d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_main_eval_opt_fn__461000137_A_fn_class = fncls__1038d; tmp13 = fncls__1038d } else { tmp13 = fncls__1038 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil).Invoke__O(); input__4 = tmp7; continue L1 } } }; /*line :487:1*/panic("j2g: unreachable") }




func A_arbace_main_eval_opt_fn__461000135_A_New_O_O(p0, p1 any) *A_arbace_main_eval_opt_fn__461000135_A { A_arbace_main_A_Init(); t := &A_arbace_main_eval_opt_fn__461000135_A{}; t.Ctor_O_O(p0, p1); return t }
//line :492:1
func (t *A_arbace_main_eval_opt_fn__461000135_A) Ctor_O_O(c__reader, c__eof any) { t.F_reader = c__reader; t.F_eof = c__eof }
//line :492:1
func (t *A_arbace_main_eval_opt_fn__461000135_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1002 any = A_arbace_main_A_const_72.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any; var t_ any = t.F_reader; t.F_reader = nil; arg_1005 = t_; var arg_1006 any = jrt.Boolean_FALSE.Ref(); var arg_1007 any; var t__2 any = t.F_eof; t.F_eof = nil; arg_1007 = t__2; if linked_1003 == nil { tmp1 = ifn_1004.Invoke_O_O_O__O(arg_1005, arg_1006, arg_1007) } else { tmp1 = linked_1003.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_1002, arg_1005, arg_1006, arg_1007) } }; return nil }(); var root_1008 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1010 lang.IFn; if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; if linked_1009 == nil { ifn_1010.Invoke__O() } else { linked_1009.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1008) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }




func A_arbace_main_eval_opt_fn__461000137_A_New_O_O(p0, p1 any) *A_arbace_main_eval_opt_fn__461000137_A { A_arbace_main_A_Init(); t := &A_arbace_main_eval_opt_fn__461000137_A{}; t.Ctor_O_O(p0, p1); return t }
//line :497:1
func (t *A_arbace_main_eval_opt_fn__461000137_A) Ctor_O_O(c__reader, c__eof any) { t.F_reader = c__reader; t.F_eof = c__eof }
//line :497:1
func (t *A_arbace_main_eval_opt_fn__461000137_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1029 any = A_arbace_main_A_const_72.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any; var t_ any = t.F_reader; t.F_reader = nil; arg_1032 = t_; var arg_1033 any = jrt.Boolean_FALSE.Ref(); var arg_1034 any; var t__2 any = t.F_eof; t.F_eof = nil; arg_1034 = t__2; if linked_1030 == nil { tmp1 = ifn_1031.Invoke_O_O_O__O(arg_1032, arg_1033, arg_1034) } else { tmp1 = linked_1030.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_1029, arg_1032, arg_1033, arg_1034) } }; return nil }(); var root_1035 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; if linked_1036 == nil { ifn_1037.Invoke__O() } else { linked_1036.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1035) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }

func A_arbace_main_init_dispatch_A_New() *A_arbace_main_init_dispatch_A { A_arbace_main_A_Init(); t := &A_arbace_main_init_dispatch_A{}; t.Ctor(); return t }
//line :499:1
func (t *A_arbace_main_init_dispatch_A) Ctor() {}
//line :499:1
func (t *A_arbace_main_init_dispatch_A) Invoke_O_O__O(self, opt__0 any) any {


	return lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_40, A_arbace_main_A_const_198.GetRawRoot__O(), Lit_41, A_arbace_main_A_const_198.GetRawRoot__O(), Lit_42, A_arbace_main_A_const_199.GetRawRoot__O(), Lit_43, A_arbace_main_A_const_199.GetRawRoot__O()))).Invoke_O__O(opt__0)
}



func A_arbace_main_initialize_A_New() *A_arbace_main_initialize_A { A_arbace_main_A_Init(); t := &A_arbace_main_initialize_A{}; t.Ctor(); return t }
//line :507:1
func (t *A_arbace_main_initialize_A) Ctor() {}
//line :507:1
func (t *A_arbace_main_initialize_A) Invoke_O_O_O__O(self, args__0, inits__1 any) any {


	lang.IFn_Cast(A_arbace_main_A_const_202.GetRawRoot__O()).Invoke_O__O(A_arbace_main_A_const_203)
//line :507:1
	A_arbace_main_A_const_191.Set_O__O(args__0); { var seq_461000141__3 any; var root_1048 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1050 lang.IFn




		if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = inits__1; if linked_1049 == nil { seq_461000141__3 = ifn_1050.Invoke_O__O(arg_1051) } else { seq_461000141__3 = linked_1049.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1048, arg_1051) }
//line :507:1
		var chunk_461000142__4 any; var count_461000143__5 int64 = 0; var i_461000144__6 int64 = 0; L1: for {




			if lang.Numbers_Lt_J_J__Z_NoInit(i_461000144__6, count_461000143__5) { var vec__461000145__7 any = lang.Indexed_Cast(chunk_461000142__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_461000144__6)); var opt__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000145__7, lang.RT_IntCast_J__I_NoInit(0), nil); var arg__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000145__7, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_1068 any = A_arbace_main_A_const_204.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1068, A_arbace_main_init_dispatch_A_fn_class); var ifn_1070 lang.IFn
				if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any = opt__8; if linked_1069 == nil { tmp1 = ifn_1070.Invoke_O__O(arg_1071) } else { tmp1 = linked_1069.(*A_arbace_main_init_dispatch_A).Invoke_O_O__O(root_1068, arg_1071) }; lang.IFn_Cast(tmp1).Invoke_O__O(arg__9)
//line :512:1
				seq_461000141__3, chunk_461000142__4, count_461000143__5, i_461000144__6 = seq_461000141__3, chunk_461000142__4, count_461000143__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_461000144__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_1052 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1054 lang.IFn; if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any = seq_461000141__3; if linked_1053 == nil { temp__1927000414__auto____7 = ifn_1054.Invoke_O__O(arg_1055) } else { temp__1927000414__auto____7 = linked_1053.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1052, arg_1055) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_461000141__8 any = temp__1927000414__auto____7; var tmp2 any; var root_1056 any = A_arbace_main_A_const_200.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = seq_461000141__8; if linked_1057 == nil { tmp2 = ifn_1058.Invoke_O__O(arg_1059) } else { tmp2 = linked_1057.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1056, arg_1059) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____9 any; var root_1060 any = A_arbace_main_A_const_201.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1060, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = seq_461000141__8; if linked_1061 == nil { c__1927000678__auto____9 = ifn_1062.Invoke_O__O(arg_1063) } else { c__1927000678__auto____9 = linked_1061.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1060, arg_1063) }; var tmp3 any; var root_1072 any = A_arbace_main_A_const_205.GetRawRoot__O(); var linked_1073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1072, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1074 lang.IFn; if linked_1073 == nil { ifn_1074 = lang.IFn_Cast(root_1072) } else { ifn_1074 = nil }; var arg_1075 any = seq_461000141__8; if linked_1073 == nil { tmp3 = ifn_1074.Invoke_O__O(arg_1075) } else { tmp3 = linked_1073.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1072, arg_1075) }; seq_461000141__3, chunk_461000142__4, count_461000143__5, i_461000144__6 = tmp3, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__461000148__9 any; var root_1064 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = seq_461000141__8; if linked_1065 == nil { vec__461000148__9 = ifn_1066.Invoke_O__O(arg_1067) } else { vec__461000148__9 = linked_1065.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1064, arg_1067) }; var opt__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000148__9, lang.RT_IntCast_J__I_NoInit(0), nil); var arg__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000148__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp4 any; var root_1076 any = A_arbace_main_A_const_204.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1076, A_arbace_main_init_dispatch_A_fn_class); var ifn_1078 lang.IFn
					if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any = opt__10; if linked_1077 == nil { tmp4 = ifn_1078.Invoke_O__O(arg_1079) } else { tmp4 = linked_1077.(*A_arbace_main_init_dispatch_A).Invoke_O_O__O(root_1076, arg_1079) }; lang.IFn_Cast(tmp4).Invoke_O__O(arg__11)
//line :512:1
					var tmp5 any; var root_1080 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1080, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1082 lang.IFn; if linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any = seq_461000141__8; if linked_1081 == nil { tmp5 = ifn_1082.Invoke_O__O(arg_1083) } else { tmp5 = linked_1081.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1080, arg_1083) }; seq_461000141__3, chunk_461000142__4, count_461000143__5, i_461000144__6 = tmp5, nil, 0, 0; continue L1 } } else { return nil } } } }
//line :507:1
	panic("j2g: unreachable")
}






func A_arbace_main_main_opt_A_New() *A_arbace_main_main_opt_A { A_arbace_main_A_Init(); t := &A_arbace_main_main_opt_A{}; t.Ctor(); return t }
//line :515:1
func (t *A_arbace_main_main_opt_A) Ctor() {}
//line :515:1
func (t *A_arbace_main_main_opt_A) Invoke_O_O_O__O(self, p__461000152__0, inits__1 any) any { var vec__461000153__3 any = p__461000152__0; var seq__461000154__4 any; var root_1084 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1084, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1086 lang.IFn; if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = vec__461000153__3; if linked_1085 == nil { seq__461000154__4 = ifn_1086.Invoke_O__O(arg_1087) } else { seq__461000154__4 = linked_1085.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1084, arg_1087) }; var first__461000155__5 any; var root_1088 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = seq__461000154__4; if linked_1089 == nil { first__461000155__5 = ifn_1090.Invoke_O__O(arg_1091) } else { first__461000155__5 = linked_1089.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1088, arg_1091) }; var seq__461000154__6 any; var root_1092 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = seq__461000154__4; if linked_1093 == nil { seq__461000154__6 = ifn_1094.Invoke_O__O(arg_1095) } else { seq__461000154__6 = linked_1093.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1092, arg_1095) }; var ___7 any = first__461000155__5; var first__461000155__8 any; var root_1096 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1098 lang.IFn; _ = ___7; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = seq__461000154__6; if linked_1097 == nil { first__461000155__8 = ifn_1098.Invoke_O__O(arg_1099) } else { first__461000155__8 = linked_1097.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1096, arg_1099) }; var seq__461000154__9 any; var root_1100 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1102 lang.IFn; if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = seq__461000154__6; if linked_1101 == nil { seq__461000154__9 = ifn_1102.Invoke_O__O(arg_1103) } else { seq__461000154__9 = linked_1101.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1100, arg_1103) }; var main_ns__10 any = first__461000155__8; var args__11 any = seq__461000154__9; var root_1125 any = A_arbace_main_A_const_142.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1127 lang.IFn; if



	linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var tmp1 any = A_arbace_main_A_const_58; var tmp2 any = A_arbace_main_A_const_58.Get__O(); var tmp3 any = A_arbace_main_A_const_182; var tmp4 any = A_arbace_main_A_const_182.Get__O(); var tmp5 any = A_arbace_main_A_const_183; var tmp6 any = A_arbace_main_A_const_183.Get__O(); var tmp7 any = A_arbace_main_A_const_184; var tmp8 any = A_arbace_main_A_const_184.Get__O(); var tmp9 any = A_arbace_main_A_const_185; var tmp10 any = A_arbace_main_A_const_185.Get__O(); var tmp11 any = A_arbace_main_A_const_186; var tmp12 any = A_arbace_main_A_const_186.Get__O(); var tmp13 any = A_arbace_main_A_const_187; var tmp14 any = jrt.Boolean_TRUE.Ref(); var tmp15 any = A_arbace_main_A_const_188; var tmp16 any = A_arbace_main_A_const_188.Get__O(); var tmp17 any = A_arbace_main_A_const_189; var tmp18 any = A_arbace_main_A_const_189.Get__O(); var tmp19 any = A_arbace_main_A_const_190; var tmp20 any = jrt.System_GetProperty_String_String__String(Lit_63, Lit_64).Ref(); var tmp21 any = A_arbace_main_A_const_191; var tmp22 any = A_arbace_main_A_const_191.Get__O(); var tmp23 any = A_arbace_main_A_const_192; var tmp24 any = A_arbace_main_A_const_192.Get__O(); var tmp25 any = A_arbace_main_A_const_193; var tmp26 any = A_arbace_main_A_const_193.Get__O(); var tmp27 any = A_arbace_main_A_const_138; var arg_1128 any = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()).ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, A_arbace_main_A_const_138.Get__O(), A_arbace_main_A_const_178, nil, A_arbace_main_A_const_177, nil, A_arbace_main_A_const_176, nil, A_arbace_main_A_const_180, nil)))); if linked_1126 == nil { ifn_1127.Invoke_O__O(arg_1128) } else { linked_1126.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1125, arg_1128) }; var tmp28 any; tmp29 := /*line :515:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




		{ var root_1129 any = A_arbace_main_A_const_208.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, A_arbace_main_initialize_A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = args__11; var arg_1133 any = inits__1; if linked_1130 == nil { ifn_1131.Invoke_O_O__O(arg_1132, arg_1133) } else { linked_1130.(*A_arbace_main_initialize_A).Invoke_O_O_O__O(root_1129, arg_1132, arg_1133) }
			var root_1104 any = A_arbace_main_A_const_23.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1104, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any; var root_1109 any = A_arbace_main_A_const_206.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_ns_resolve_A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any; var G__461000156__14_ any; var root_1114 any = A_arbace_main_A_const_86.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1114, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1116 lang.IFn; if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any = main_ns__10; if linked_1115 == nil { G__461000156__14_ = ifn_1116.Invoke_O__O(arg_1117) } else { G__461000156__14_ = linked_1115.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1114, arg_1117) }; lang.IFn_Cast(A_arbace_main_A_const_4.GetRawRoot__O()).Invoke_O__O(G__461000156__14_); arg_1112 = G__461000156__14_; var arg_1113 any = A_arbace_main_A_const_207; if linked_1110 == nil { arg_1107 = ifn_1111.Invoke_O_O__O(arg_1112, arg_1113) } else { arg_1107 = linked_1110.(*aot_arbace_core.A_arbace_core_ns_resolve_A).Invoke_O_O_O__O(root_1109, arg_1112, arg_1113) }; var arg_1108 any = args__11; if linked_1105 == nil { tmp28 = ifn_1106.Invoke_O_O__O(arg_1107, arg_1108) } else { tmp28 = linked_1105.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1104, arg_1107, arg_1108) } }
//line :515:1
		return nil }(); var root_1122 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_1123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1122, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1124 lang.IFn; if



	linked_1123 == nil { ifn_1124 = lang.IFn_Cast(root_1122) } else { ifn_1124 = nil }; if linked_1123 == nil { ifn_1124.Invoke__O() } else { linked_1123.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1122) }; if /*line :515:1*/ tmp29 != nil { panic(tmp29) }; return tmp28 }







func A_arbace_main_repl_opt_A_New() *A_arbace_main_repl_opt_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_opt_A{}; t.Ctor(); return t }
//line :523:1
func (t *A_arbace_main_repl_opt_A) Ctor() {}
//line :523:1
func (t *A_arbace_main_repl_opt_A) Invoke_O_O_O__O(self, p__461000159__0, inits__1 any) any { var vec__461000160__3 any = p__461000159__0; var seq__461000161__4 any; var root_1134 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = vec__461000160__3; if linked_1135 == nil { seq__461000161__4 = ifn_1136.Invoke_O__O(arg_1137) } else { seq__461000161__4 = linked_1135.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1134, arg_1137) }; var first__461000162__5 any; var root_1138 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = seq__461000161__4; if linked_1139 == nil { first__461000162__5 = ifn_1140.Invoke_O__O(arg_1141) } else { first__461000162__5 = linked_1139.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1138, arg_1141) }; var seq__461000161__6 any; var root_1142 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1142, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1144 lang.IFn; if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = seq__461000161__4; if linked_1143 == nil { seq__461000161__6 = ifn_1144.Invoke_O__O(arg_1145) } else { seq__461000161__6 = linked_1143.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1142, arg_1145) }; var ___7 any = first__461000162__5; var args__8 any = seq__461000161__6; var tmp1 any; var root_1146 any = A_arbace_main_A_const_209.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1148 lang.IFn; _ = ___7; if



	linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any; var tmp2 any = A_arbace_main_repl_opt_fn__461000163_A_New(); var tmp3 *jrt.Class; var fncls__1159 *jrt.Class = A_arbace_main_repl_opt_fn__461000163_A_fn_class; if fncls__1159 == nil { var fncls__1159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_main_repl_opt_fn__461000163_A_fn_class = fncls__1159d; tmp3 = fncls__1159d } else { tmp3 = fncls__1159 }; arg_1149 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_1150 any = inits__1; if linked_1147 == nil { tmp1 = ifn_1148.Invoke_O_O__O(arg_1149, arg_1150) } else { tmp1 = linked_1147.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1146, arg_1149, arg_1150) }; if jrt.J2g_Truth(tmp1) { } else {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_210.GetRawRoot__O()); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_76, nil, nil); var tmp6 any; var root_1164 any = A_arbace_main_A_const_211.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, aot_arbace_core.A_arbace_core_arbace_version_A_fn_class); var ifn_1166 lang.IFn; if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; if linked_1165 == nil { tmp6 = ifn_1166.Invoke__O() } else { tmp6 = linked_1165.(*aot_arbace_core.A_arbace_core_arbace_version_A).Invoke_O__O(root_1164) }; var tmp7 any = tmp6; var tmp8 *jrt.String; var tmp9 *lang.Keyword = A_arbace_main_A_const_212; var temp__1927000414__auto____12 any = tmp9.Invoke_O__O(A_arbace_main_A_const_213.Get__O())
		if jrt.J2g_Truth(temp__1927000414__auto____12) { var c__13 any = temp__1927000414__auto____12; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_17, nil, Lit_18); var tmp11 any; var root_1167 any = A_arbace_main_A_const_80.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1169 lang.IFn
			if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = c__13; var arg_1171 any = A_arbace_main_A_const_214; var arg_1172 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Min_J_J__J_NoInit(7, int64(lang.RT_Count_O__I_NoInit(c__13)))).Ref(); if linked_1168 == nil { tmp11 = ifn_1169.Invoke_O_O_O__O(arg_1170, arg_1171, arg_1172) } else { tmp11 = linked_1168.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1167, arg_1170, arg_1171, arg_1172) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11, nil)) } else {
//line :529:1
				tmp8 = nil }
//line :528:1
		tmp4.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, tmp8.Ref())).Ref()) }; var tmp12 lang.IFn =


	lang.IFn_Cast(A_arbace_main_A_const_215.GetRawRoot__O()); var tmp13 any = A_arbace_main_A_const_165; var tmp14 any = A_arbace_main_repl_opt_fn__461000165_A_New_O_O(inits__1, args__8); var tmp15 *jrt.Class; var fncls__1188 *jrt.Class = A_arbace_main_repl_opt_fn__461000165_A_fn_class; if fncls__1188 == nil { var fncls__1188d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_main_repl_opt_fn__461000165_A_fn_class = fncls__1188d; tmp15 = fncls__1188d } else { tmp15 = fncls__1188 }; tmp12.Invoke_O_O__O(tmp13, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil));


	lang.IFn_Cast(A_arbace_main_A_const_163.GetRawRoot__O()).Invoke__O();
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(0)); return nil }
//line :527:1
func A_arbace_main_repl_opt_fn__461000163_A_New() *A_arbace_main_repl_opt_fn__461000163_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_opt_fn__461000163_A{}; t.Ctor(); return t }
//line :527:1
func (t *A_arbace_main_repl_opt_fn__461000163_A) Ctor() {}
//line :527:1
func (t *A_arbace_main_repl_opt_fn__461000163_A) Invoke_O_O__O(self, p1__461000158_SHARP___1 any) any { var tmp1 any = A_arbace_main_A_const_199.GetRawRoot__O(); var tmp2 any; var root_1151 any = A_arbace_main_A_const_204.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, A_arbace_main_init_dispatch_A_fn_class); var ifn_1153 lang.IFn; if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any; var root_1155 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1157 lang.IFn; if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any = p1__461000158_SHARP___1; if linked_1156 == nil { arg_1154 = ifn_1157.Invoke_O__O(arg_1158) } else { arg_1154 = linked_1156.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1155, arg_1158) }; if linked_1152 == nil { tmp2 = ifn_1153.Invoke_O__O(arg_1154) } else { tmp2 = linked_1152.(*A_arbace_main_init_dispatch_A).Invoke_O_O__O(root_1151, arg_1154) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }



func A_arbace_main_repl_opt_fn__461000165_A_New_O_O(p0, p1 any) *A_arbace_main_repl_opt_fn__461000165_A { A_arbace_main_A_Init(); t := &A_arbace_main_repl_opt_fn__461000165_A{}; t.Ctor_O_O(p0, p1); return t }
//line :531:1
func (t *A_arbace_main_repl_opt_fn__461000165_A) Ctor_O_O(c__inits, c__args any) { t.F_inits = c__inits; t.F_args = c__args }
//line :531:1
func (t *A_arbace_main_repl_opt_fn__461000165_A) Invoke_O__O(self any) any {
	var root_1183 any = A_arbace_main_A_const_208.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1183, A_arbace_main_initialize_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any = t.F_args; var arg_1187 any = t.F_inits; if linked_1184 == nil { ifn_1185.Invoke_O_O__O(arg_1186, arg_1187) } else { linked_1184.(*A_arbace_main_initialize_A).Invoke_O_O_O__O(root_1183, arg_1186, arg_1187) }
	var root_1178 any = A_arbace_main_A_const_23.GetRawRoot__O(); var linked_1179 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1178, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1180 lang.IFn; if linked_1179 == nil { ifn_1180 = lang.IFn_Cast(root_1178) } else { ifn_1180 = nil }; var arg_1181 any = A_arbace_main_A_const_4.GetRawRoot__O(); var arg_1182 any = A_arbace_main_A_const_216.GetRawRoot__O(); if linked_1179 == nil { return ifn_1180.Invoke_O_O__O(arg_1181, arg_1182) } else { return linked_1179.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1178, arg_1181, arg_1182)
	}
}

func A_arbace_main_script_opt_A_New() *A_arbace_main_script_opt_A { A_arbace_main_A_Init(); t := &A_arbace_main_script_opt_A{}; t.Ctor(); return t }
//line :537:1
func (t *A_arbace_main_script_opt_A) Ctor() {}
//line :537:1
func (t *A_arbace_main_script_opt_A) Invoke_O_O_O__O(self, p__461000168__0, inits__1 any) any { var vec__461000169__3 any = p__461000168__0; var seq__461000170__4 any; var root_1192 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1194 lang.IFn; if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = vec__461000169__3; if linked_1193 == nil { seq__461000170__4 = ifn_1194.Invoke_O__O(arg_1195) } else { seq__461000170__4 = linked_1193.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1192, arg_1195) }; var first__461000171__5 any; var root_1196 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = seq__461000170__4; if linked_1197 == nil { first__461000171__5 = ifn_1198.Invoke_O__O(arg_1199) } else { first__461000171__5 = linked_1197.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1196, arg_1199) }; var seq__461000170__6 any; var root_1200 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = seq__461000170__4; if linked_1201 == nil { seq__461000170__6 = ifn_1202.Invoke_O__O(arg_1203) } else { seq__461000170__6 = linked_1201.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1200, arg_1203) }; var path__7 any = first__461000171__5; var args__8 any = seq__461000170__6; var root_1215 any = A_arbace_main_A_const_142.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1217 lang.IFn; if


	linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var tmp1 any = A_arbace_main_A_const_58; var tmp2 any = A_arbace_main_A_const_58.Get__O(); var tmp3 any = A_arbace_main_A_const_182; var tmp4 any = A_arbace_main_A_const_182.Get__O(); var tmp5 any = A_arbace_main_A_const_183; var tmp6 any = A_arbace_main_A_const_183.Get__O(); var tmp7 any = A_arbace_main_A_const_184; var tmp8 any = A_arbace_main_A_const_184.Get__O(); var tmp9 any = A_arbace_main_A_const_185; var tmp10 any = A_arbace_main_A_const_185.Get__O(); var tmp11 any = A_arbace_main_A_const_186; var tmp12 any = A_arbace_main_A_const_186.Get__O(); var tmp13 any = A_arbace_main_A_const_187; var tmp14 any = jrt.Boolean_TRUE.Ref(); var tmp15 any = A_arbace_main_A_const_188; var tmp16 any = A_arbace_main_A_const_188.Get__O(); var tmp17 any = A_arbace_main_A_const_189; var tmp18 any = A_arbace_main_A_const_189.Get__O(); var tmp19 any = A_arbace_main_A_const_190; var tmp20 any = jrt.System_GetProperty_String_String__String(Lit_63, Lit_64).Ref(); var tmp21 any = A_arbace_main_A_const_191; var tmp22 any = A_arbace_main_A_const_191.Get__O(); var tmp23 any = A_arbace_main_A_const_192; var tmp24 any = A_arbace_main_A_const_192.Get__O(); var tmp25 any = A_arbace_main_A_const_193; var tmp26 any = A_arbace_main_A_const_193.Get__O(); var tmp27 any = A_arbace_main_A_const_138; var arg_1218 any = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()).ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, A_arbace_main_A_const_138.Get__O(), A_arbace_main_A_const_178, nil, A_arbace_main_A_const_177, nil, A_arbace_main_A_const_176, nil, A_arbace_main_A_const_180, nil)))); if linked_1216 == nil { ifn_1217.Invoke_O__O(arg_1218) } else { linked_1216.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1215, arg_1218) }; var tmp28 any; tmp29 := /*line :537:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		{ var root_1219 any = A_arbace_main_A_const_208.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, A_arbace_main_initialize_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = args__8; var arg_1223 any = inits__1; if linked_1220 == nil { ifn_1221.Invoke_O_O__O(arg_1222, arg_1223) } else { linked_1220.(*A_arbace_main_initialize_A).Invoke_O_O_O__O(root_1219, arg_1222, arg_1223) }
			if lang.Util_Equiv_O_O__Z_NoInit(path__7, Lit_88) {
				var root_1204 any = A_arbace_main_A_const_217.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_load_reader_A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = A_arbace_main_A_const_75.Get__O(); if linked_1205 == nil { tmp28 = ifn_1206.Invoke_O__O(arg_1207) } else { tmp28 = linked_1205.(*aot_arbace_core.A_arbace_core_load_reader_A).Invoke_O_O__O(root_1204, arg_1207) } } else {
					var root_1208 any = A_arbace_main_A_const_197.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, A_arbace_main_load_script_A_fn_class); var ifn_1210 lang.IFn; if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any = path__7; if linked_1209 == nil { tmp28 = ifn_1210.Invoke_O__O(arg_1211) } else { tmp28 = linked_1209.(*A_arbace_main_load_script_A).Invoke_O_O__O(root_1208, arg_1211) } } }
//line :537:1
		return nil }(); var root_1212 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1212, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1214 lang.IFn; if


	linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; if linked_1213 == nil { ifn_1214.Invoke__O() } else { linked_1213.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1212) }; if /*line :537:1*/ tmp29 != nil { panic(tmp29) }; return tmp28 }








func A_arbace_main_null_opt_A_New() *A_arbace_main_null_opt_A { A_arbace_main_A_Init(); t := &A_arbace_main_null_opt_A{}; t.Ctor(); return t }
//line :546:1
func (t *A_arbace_main_null_opt_A) Ctor() {}
//line :546:1
func (t *A_arbace_main_null_opt_A) Invoke_O_O_O__O(self, args__0, inits__1 any) any {


	var root_1232 any = A_arbace_main_A_const_142.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var tmp1 any = A_arbace_main_A_const_58; var tmp2 any = A_arbace_main_A_const_58.Get__O(); var tmp3 any = A_arbace_main_A_const_182; var tmp4 any = A_arbace_main_A_const_182.Get__O(); var tmp5 any = A_arbace_main_A_const_183; var tmp6 any = A_arbace_main_A_const_183.Get__O(); var tmp7 any = A_arbace_main_A_const_184; var tmp8 any = A_arbace_main_A_const_184.Get__O(); var tmp9 any = A_arbace_main_A_const_185; var tmp10 any = A_arbace_main_A_const_185.Get__O(); var tmp11 any = A_arbace_main_A_const_186; var tmp12 any = A_arbace_main_A_const_186.Get__O(); var tmp13 any = A_arbace_main_A_const_187; var tmp14 any = jrt.Boolean_TRUE.Ref(); var tmp15 any = A_arbace_main_A_const_188; var tmp16 any = A_arbace_main_A_const_188.Get__O(); var tmp17 any = A_arbace_main_A_const_189; var tmp18 any = A_arbace_main_A_const_189.Get__O(); var tmp19 any = A_arbace_main_A_const_190; var tmp20 any = jrt.System_GetProperty_String_String__String(Lit_63, Lit_64).Ref(); var tmp21 any = A_arbace_main_A_const_191; var tmp22 any = A_arbace_main_A_const_191.Get__O(); var tmp23 any = A_arbace_main_A_const_192; var tmp24 any = A_arbace_main_A_const_192.Get__O(); var tmp25 any = A_arbace_main_A_const_193; var tmp26 any = A_arbace_main_A_const_193.Get__O(); var tmp27 any = A_arbace_main_A_const_138; var arg_1235 any = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()).ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, A_arbace_main_A_const_138.Get__O(), A_arbace_main_A_const_178, nil, A_arbace_main_A_const_177, nil, A_arbace_main_A_const_176, nil, A_arbace_main_A_const_180, nil)))); if linked_1233 == nil { ifn_1234.Invoke_O__O(arg_1235) } else { linked_1233.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1232, arg_1235) }
//line :546:1
	var tmp28 any; tmp29 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		{ var root_1224 any = A_arbace_main_A_const_208.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, A_arbace_main_initialize_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = args__0; var arg_1228 any = inits__1; if linked_1225 == nil { tmp28 = ifn_1226.Invoke_O_O__O(arg_1227, arg_1228) } else { tmp28 = linked_1225.(*A_arbace_main_initialize_A).Invoke_O_O_O__O(root_1224, arg_1227, arg_1228) } }
//line :546:1
		return nil }(); var root_1229 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1231 lang.IFn


	if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; if linked_1230 == nil { ifn_1231.Invoke__O() } else { linked_1230.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1229) }
//line :546:1
	if tmp29 != nil { panic(tmp29) }; return tmp28
}




func A_arbace_main_help_opt_A_New() *A_arbace_main_help_opt_A { A_arbace_main_A_Init(); t := &A_arbace_main_help_opt_A{}; t.Ctor(); return t }
//line :552:1
func (t *A_arbace_main_help_opt_A) Ctor() {}
//line :552:1
func (t *A_arbace_main_help_opt_A) Invoke_O_O_O__O(self, ___0, ___1 any) any {


	var tmp1 *lang.Keyword = A_arbace_main_A_const_218; return lang.IFn_Cast(A_arbace_main_A_const_210.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(A_arbace_main_A_const_219)))
}
func A_arbace_main_main_dispatch_A_New() *A_arbace_main_main_dispatch_A { A_arbace_main_A_Init(); t := &A_arbace_main_main_dispatch_A{}; t.Ctor(); return t }
//line :557:1
func (t *A_arbace_main_main_dispatch_A) Ctor() {}
//line :557:1
func (t *A_arbace_main_main_dispatch_A) Invoke_O_O__O(self, opt__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_56, A_arbace_main_A_const_220.GetRawRoot__O(), Lit_57, A_arbace_main_A_const_220.GetRawRoot__O(), Lit_58, A_arbace_main_A_const_221.GetRawRoot__O(), Lit_59, A_arbace_main_A_const_221.GetRawRoot__O(), nil, A_arbace_main_A_const_222.GetRawRoot__O(), Lit_60, A_arbace_main_A_const_223.GetRawRoot__O(), Lit_61, A_arbace_main_A_const_223.GetRawRoot__O(), Lit_62, A_arbace_main_A_const_223.GetRawRoot__O()))).Invoke_O__O(opt__0); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return A_arbace_main_A_const_224.GetRawRoot__O() } }










func A_arbace_main_legacy_repl_A_New() *A_arbace_main_legacy_repl_A { A_arbace_main_A_Init(); t := &A_arbace_main_legacy_repl_A{}; t.Ctor(); return t }
//line :571:1
func (t *A_arbace_main_legacy_repl_A) Ctor() {}
//line :571:1
func (t *A_arbace_main_legacy_repl_A) Invoke_O_O__O(self, args__0 any) any {



	lang.IFn_Cast(A_arbace_main_A_const_210.GetRawRoot__O()).Invoke_O__O(Lit_48)
//line :571:1
	var vec__461000176__2 any; var root_1240 any = A_arbace_main_A_const_225.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_split_with_A_fn_class); var ifn_1242 lang.IFn






	if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any; var root_1245 any = A_arbace_main_A_const_226.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_core.A_arbace_core_complement_A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = A_arbace_main_A_const_227; if linked_1246 == nil { arg_1243 = ifn_1247.Invoke_O__O(arg_1248) } else { arg_1243 = linked_1246.(*aot_arbace_core.A_arbace_core_complement_A).Invoke_O_O__O(root_1245, arg_1248) }; var arg_1244 any = args__0; if linked_1241 == nil { vec__461000176__2 = ifn_1242.Invoke_O_O__O(arg_1243, arg_1244) } else { vec__461000176__2 = linked_1241.(*aot_arbace_core.A_arbace_core_split_with_A).Invoke_O_O_O__O(root_1240, arg_1243, arg_1244) }
//line :571:1
	var inits__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000176__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__461000179__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000176__2, lang.RT_IntCast_J__I_NoInit(1), nil); var seq__461000180__5 any; var root_1249 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1251 lang.IFn






	if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any = vec__461000179__4; if linked_1250 == nil { seq__461000180__5 = ifn_1251.Invoke_O__O(arg_1252) } else { seq__461000180__5 = linked_1250.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1249, arg_1252) }
//line :571:1
	var first__461000181__6 any; var root_1253 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1255 lang.IFn






	if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = seq__461000180__5; if linked_1254 == nil { first__461000181__6 = ifn_1255.Invoke_O__O(arg_1256) } else { first__461000181__6 = linked_1254.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1253, arg_1256) }
//line :571:1
	var seq__461000180__7 any; var root_1257 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1259 lang.IFn






	if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = seq__461000180__5; if linked_1258 == nil { seq__461000180__7 = ifn_1259.Invoke_O__O(arg_1260) } else { seq__461000180__7 = linked_1258.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1257, arg_1260) }
//line :571:1
	var sep__8 any = first__461000181__6; var args__9 any = seq__461000180__7; var root_1261 any = A_arbace_main_A_const_220.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, A_arbace_main_repl_opt_A_fn_class); var ifn_1263 lang.IFn; _ = sep__8







	if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any; var root_1266 any = A_arbace_main_A_const_20.GetRawRoot__O(); var linked_1267 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1266, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1268 lang.IFn; if linked_1267 == nil { ifn_1268 = lang.IFn_Cast(root_1266) } else { ifn_1268 = nil }; var arg_1269 any = A_arbace_main_A_const_228; var arg_1270 any = args__9; if linked_1267 == nil { arg_1264 = ifn_1268.Invoke_O_O__O(arg_1269, arg_1270) } else { arg_1264 = linked_1267.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1266, arg_1269, arg_1270) }; var arg_1265 any; var root_1271 any = A_arbace_main_A_const_83.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = A_arbace_main_A_const_24.GetRawRoot__O(); var arg_1275 any; var root_1277 any = A_arbace_main_A_const_229.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = Lit_40; if linked_1278 == nil { arg_1275 = ifn_1279.Invoke_O__O(arg_1280) } else { arg_1275 = linked_1278.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O__O(root_1277, arg_1280) }; var arg_1276 any = inits__3; if linked_1272 == nil { arg_1265 = ifn_1273.Invoke_O_O_O__O(arg_1274, arg_1275, arg_1276) } else { arg_1265 = linked_1272.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1271, arg_1274, arg_1275, arg_1276) }; if linked_1262 == nil { return ifn_1263.Invoke_O_O__O(arg_1264, arg_1265) } else { return linked_1262.(*A_arbace_main_repl_opt_A).Invoke_O_O_O__O(root_1261, arg_1264, arg_1265)
	} }
func A_arbace_main_legacy_script_A_New() *A_arbace_main_legacy_script_A { A_arbace_main_A_Init(); t := &A_arbace_main_legacy_script_A{}; t.Ctor(); return t }
//line :581:1
func (t *A_arbace_main_legacy_script_A) Ctor() {}
//line :581:1
func (t *A_arbace_main_legacy_script_A) Invoke_O_O__O(self, args__0 any) any {



	lang.IFn_Cast(A_arbace_main_A_const_210.GetRawRoot__O()).Invoke_O__O(Lit_49)
//line :581:1
	var vec__461000183__2 any; var root_1285 any = A_arbace_main_A_const_225.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, aot_arbace_core.A_arbace_core_split_with_A_fn_class); var ifn_1287 lang.IFn






	if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any; var root_1290 any = A_arbace_main_A_const_226.GetRawRoot__O(); var linked_1291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1290, aot_arbace_core.A_arbace_core_complement_A_fn_class); var ifn_1292 lang.IFn; if linked_1291 == nil { ifn_1292 = lang.IFn_Cast(root_1290) } else { ifn_1292 = nil }; var arg_1293 any = A_arbace_main_A_const_230; if linked_1291 == nil { arg_1288 = ifn_1292.Invoke_O__O(arg_1293) } else { arg_1288 = linked_1291.(*aot_arbace_core.A_arbace_core_complement_A).Invoke_O_O__O(root_1290, arg_1293) }; var arg_1289 any = args__0; if linked_1286 == nil { vec__461000183__2 = ifn_1287.Invoke_O_O__O(arg_1288, arg_1289) } else { vec__461000183__2 = linked_1286.(*aot_arbace_core.A_arbace_core_split_with_A).Invoke_O_O_O__O(root_1285, arg_1288, arg_1289) }
//line :581:1
	var inits__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000183__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__461000186__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__461000183__2, lang.RT_IntCast_J__I_NoInit(1), nil); var seq__461000187__5 any; var root_1294 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1296 lang.IFn






	if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = vec__461000186__4; if linked_1295 == nil { seq__461000187__5 = ifn_1296.Invoke_O__O(arg_1297) } else { seq__461000187__5 = linked_1295.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1294, arg_1297) }
//line :581:1
	var first__461000188__6 any; var root_1298 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1300 lang.IFn






	if linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any = seq__461000187__5; if linked_1299 == nil { first__461000188__6 = ifn_1300.Invoke_O__O(arg_1301) } else { first__461000188__6 = linked_1299.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1298, arg_1301) }
//line :581:1
	var seq__461000187__7 any; var root_1302 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1304 lang.IFn






	if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any = seq__461000187__5; if linked_1303 == nil { seq__461000187__7 = ifn_1304.Invoke_O__O(arg_1305) } else { seq__461000187__7 = linked_1303.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1302, arg_1305) }
//line :581:1
	var sep__8 any = first__461000188__6; var args__9 any = seq__461000187__7; var root_1306 any = A_arbace_main_A_const_222.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, A_arbace_main_null_opt_A_fn_class); var ifn_1308 lang.IFn; _ = sep__8







	if linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any = args__9; var arg_1310 any; var root_1311 any = A_arbace_main_A_const_83.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1311, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1313 lang.IFn; if linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any = A_arbace_main_A_const_24.GetRawRoot__O(); var arg_1315 any; var root_1317 any = A_arbace_main_A_const_229.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1317, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = Lit_40; if linked_1318 == nil { arg_1315 = ifn_1319.Invoke_O__O(arg_1320) } else { arg_1315 = linked_1318.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O__O(root_1317, arg_1320) }; var arg_1316 any = inits__3; if linked_1312 == nil { arg_1310 = ifn_1313.Invoke_O_O_O__O(arg_1314, arg_1315, arg_1316) } else { arg_1310 = linked_1312.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1311, arg_1314, arg_1315, arg_1316) }; if linked_1307 == nil { return ifn_1308.Invoke_O_O__O(arg_1309, arg_1310) } else { return linked_1307.(*A_arbace_main_null_opt_A).Invoke_O_O_O__O(root_1306, arg_1309, arg_1310)
	} }
func A_arbace_main_report_error_A_New() *A_arbace_main_report_error_A { A_arbace_main_A_Init(); t := &A_arbace_main_report_error_A{}; t.Ctor(); return t }
//line :591:1
func (t *A_arbace_main_report_error_A) Ctor() {}
//line :591:1
func (t *A_arbace_main_report_error_A) DoInvoke_O_O_O__O(self, t__0, p__461000190__1 any) any { var default__461000193__3 any = Lit_55; var map__461000191__4 any = p__461000190__1; var map__461000191__5 any; if lang.ISeq_InstanceOf(map__461000191__4) { var tmp1 any; var root_1325 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any = map__461000191__4; if linked_1326 == nil { tmp1 = ifn_1327.Invoke_O__O(arg_1328) } else { tmp1 = linked_1326.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1325, arg_1328) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1329 any = A_arbace_main_A_const_68.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1329, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1331 lang.IFn; if linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; var arg_1332 any = map__461000191__4; if linked_1330 == nil { tmp2 = ifn_1331.Invoke_O__O(arg_1332) } else { tmp2 = linked_1330.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1329, arg_1332) }; map__461000191__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1333 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1333, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1335 lang.IFn; if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any = map__461000191__4; if linked_1334 == nil { tmp3 = ifn_1335.Invoke_O__O(arg_1336) } else { tmp3 = linked_1334.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1333, arg_1336) }; if jrt.J2g_Truth(tmp3) { var root_1337 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any = map__461000191__4; if linked_1338 == nil { map__461000191__5 = ifn_1339.Invoke_O__O(arg_1340) } else { map__461000191__5 = linked_1338.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1337, arg_1340) } } else { map__461000191__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000191__5 = map__461000191__4 }; var opts__6 any = map__461000191__5; var target__7 any = lang.RT_Get_O_O_O__O_NoInit(map__461000191__5, A_arbace_main_A_const_231, default__461000193__3); _ = opts__6; if








	lang.Util_Equiv_O_O__Z_NoInit(target__7, Lit_79) { return nil } else { var trace__8 any; var root_1341 any = A_arbace_main_A_const_147.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, aot_arbace_core.A_arbace_core_Throwable__GT_map_A_fn_class); var ifn_1343 lang.IFn
		if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = t__0; if linked_1342 == nil { trace__8 = ifn_1343.Invoke_O__O(arg_1344) } else { trace__8 = linked_1342.(*aot_arbace_core.A_arbace_core_Throwable__GT_map_A).Invoke_O_O__O(root_1341, arg_1344) }
//line :600:1
		var triage__9 any; var root_1345 any = A_arbace_main_A_const_146.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1345, A_arbace_main_ex_triage_A_fn_class); var ifn_1347 lang.IFn

		if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any = trace__8; if linked_1346 == nil { triage__9 = ifn_1347.Invoke_O__O(arg_1348) } else { triage__9 = linked_1346.(*A_arbace_main_ex_triage_A).Invoke_O_O__O(root_1345, arg_1348) }
//line :600:1
		var message__10 any; var root_1349 any = A_arbace_main_A_const_145.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1349, A_arbace_main_ex_str_A_fn_class); var ifn_1351 lang.IFn


		if linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any = triage__9; if linked_1350 == nil { message__10 = ifn_1351.Invoke_O__O(arg_1352) } else { message__10 = linked_1350.(*A_arbace_main_ex_str_A).Invoke_O_O__O(root_1349, arg_1352) }
//line :600:1
		var report__11 any = lang.IFn_Cast(A_arbace_main_A_const_232.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_main_A_const_233, message__10, A_arbace_main_A_const_234, triage__9, A_arbace_main_A_const_235, trace__8); var report_str__12 any; var s__1927001093__auto____12 any = jrt.StringWriter_New(); var root_1421 any = A_arbace_main_A_const_142.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1421, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1423 lang.IFn







		if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()).Invoke_O_O__O(A_arbace_main_A_const_144, s__1927001093__auto____12); if linked_1422 == nil { ifn_1423.Invoke_O__O(arg_1424) } else { linked_1422.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1421, arg_1424) }; var tmp4 any = A_arbace_main_report_error_fn__461000195_A_New_O_O(report__11, s__1927001093__auto____12); var tmp5 *jrt.Class; var fncls__1386 *jrt.Class = A_arbace_main_report_error_fn__461000195_A_fn_class; if fncls__1386 == nil { var fncls__1386d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_main_report_error_fn__461000195_A_fn_class = fncls__1386d; tmp5 = fncls__1386d } else { tmp5 = fncls__1386 }; report_str__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O()
//line :600:1
		var err_path__13 any










		if lang.Util_Equiv_O_O__Z_NoInit(target__7, Lit_55) {
			var tmp6 any = A_arbace_main_report_error_fn__461000199_A_New_O(report_str__12); var tmp7 *jrt.Class; var fncls__1409 *jrt.Class = A_arbace_main_report_error_fn__461000199_A_fn_class; if fncls__1409 == nil { var fncls__1409d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_main_report_error_fn__461000199_A_fn_class = fncls__1409d; tmp7 = fncls__1409d } else { tmp7 = fncls__1409 }; err_path__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O() } else {
//line :611:1
				err_path__13 = nil
			}





		var root_1430 any = A_arbace_main_A_const_142.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1432 lang.IFn; if linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()); var tmp9 any = A_arbace_main_A_const_144; var arg_1433 any = tmp8.Invoke_O_O__O(tmp9, A_arbace_main_A_const_149.Get__O()); if linked_1431 == nil { ifn_1432.Invoke_O__O(arg_1433) } else { linked_1431.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1430, arg_1433) }
//line :600:1
		var tmp10 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


















			if jrt.J2g_Truth(err_path__13) {
				tmp10 = lang.IFn_Cast(A_arbace_main_A_const_210.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_82, nil, nil), jrt.RefArrayOf(jrt.Object_class, message__10, jrt.System_LineSeparator__String().Ref(), nil, jrt.System_LineSeparator__String().Ref(), err_path__13)).Ref()) } else {
					tmp10 = lang.IFn_Cast(A_arbace_main_A_const_210.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil, nil), jrt.RefArrayOf(jrt.Object_class, report_str__12, jrt.System_LineSeparator__String().Ref(), message__10)).Ref()) }
//line :600:1
			return nil }(); var root_1418 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1420 lang.IFn

















		if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; if linked_1419 == nil { ifn_1420.Invoke__O() } else { linked_1419.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1418) }
//line :600:1
		if tmp11 != nil { panic(tmp11) }; return tmp10 } }







func A_arbace_main_report_error_fn__461000195_A_New_O_O(p0, p1 any) *A_arbace_main_report_error_fn__461000195_A { A_arbace_main_A_Init(); t := &A_arbace_main_report_error_fn__461000195_A{}; t.Ctor_O_O(p0, p1); return t }
//line :608:1
func (t *A_arbace_main_report_error_fn__461000195_A) Ctor_O_O(c__report, c__s__1927001093__auto__ any) { t.F_report = c__report; t.F_s__1927001093__auto__ = c__s__1927001093__auto__ }
//line :608:1
func (t *A_arbace_main_report_error_fn__461000195_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var root_1377 any = A_arbace_main_A_const_142.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()).Invoke_O_O__O(A_arbace_main_A_const_187, jrt.Boolean_FALSE.Ref()); if linked_1378 == nil { ifn_1379.Invoke_O__O(arg_1380) } else { linked_1378.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1377, arg_1380) }; var tmp2 any = A_arbace_main_report_error_fn__461000195_fn__461000196_A_New_O(t.F_report); var tmp3 *jrt.Class; var fncls__1376 *jrt.Class = A_arbace_main_report_error_fn__461000195_fn__461000196_A_fn_class; if fncls__1376 == nil { var fncls__1376d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_main_report_error_fn__461000195_fn__461000196_A_fn_class = fncls__1376d; tmp3 = fncls__1376d } else { tmp3 = fncls__1376 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :608:1
		var root_1362 any = A_arbace_main_A_const_85.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1362, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any; var t_ any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; arg_1365 = t_; if linked_1363 == nil { tmp1 = ifn_1364.Invoke_O__O(arg_1365) } else { tmp1 = linked_1363.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1362, arg_1365) } }; return nil }(); var root_1366 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1368 lang.IFn; if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; if linked_1367 == nil { ifn_1368.Invoke__O() } else { linked_1367.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1366) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
func A_arbace_main_report_error_fn__461000195_fn__461000196_A_New_O(p0 any) *A_arbace_main_report_error_fn__461000195_fn__461000196_A { A_arbace_main_A_Init(); t := &A_arbace_main_report_error_fn__461000195_fn__461000196_A{}; t.Ctor_O(p0); return t }
//line :609:1
func (t *A_arbace_main_report_error_fn__461000195_fn__461000196_A) Ctor_O(c__report any) { t.F_report = c__report }
//line :609:1
func (t *A_arbace_main_report_error_fn__461000195_fn__461000196_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_163.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_report; t.F_report = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }
//line :609:1
	return nil }(); var root_1373 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; if linked_1374 == nil { ifn_1375.Invoke__O() } else { linked_1374.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1373) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }


func A_arbace_main_report_error_fn__461000199_A_New_O(p0 any) *A_arbace_main_report_error_fn__461000199_A { A_arbace_main_A_Init(); t := &A_arbace_main_report_error_fn__461000199_A{}; t.Ctor_O(p0); return t }
//line :612:1
func (t *A_arbace_main_report_error_fn__461000199_A) Ctor_O(c__report_str any) { t.F_report_str = c__report_str }
//line :612:1
func (t *A_arbace_main_report_error_fn__461000199_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var f__3 any; var tmp2 *jrt.String = Lit_84; var tmp3 *jrt.String = Lit_85; var tmp4 any; var root_1387 any = A_arbace_main_A_const_87.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_into_array_A_fn_class); var ifn_1389 lang.IFn
										if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = A_arbace_main_A_const_236; var arg_1391 any = lang.PersistentVector_EMPTY.Ref(); if linked_1388 == nil { tmp4 = ifn_1389.Invoke_O_O__O(arg_1390, arg_1391) } else { tmp4 = linked_1388.(*aot_arbace_core.A_arbace_core_into_array_A).Invoke_O_O_O__O(root_1387, arg_1390, arg_1391) }; f__3 = jrt.Files_CreateTempFile_String_String_FileAttribute1__Path(tmp2, tmp3, jrt.J2g_CastArray[*jrt.RefArray](tmp4, jrt.FileAttribute_class.ArrayClass())).ToFile__File().Ref()
//line :612:1
	var w__4 any = jrt.BufferedWriter_New_Writer(jrt.FileWriter_New_File(jrt.File_Cast(f__3))); var tmp5 any = A_arbace_main_report_error_fn__461000199_fn__461000200_A_New_O_O(w__4, t.F_report_str); var tmp6 *jrt.Class
	var fncls__1408 /*line :612:1*/*jrt.Class = A_arbace_main_report_error_fn__461000199_fn__461000200_A_fn_class

	if fncls__1408 == nil { var fncls__1408d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_main_report_error_fn__461000199_fn__461000200_A_fn_class = fncls__1408d; tmp6 = fncls__1408d } else { tmp6 = fncls__1408 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()

	tmp1 = jrt.NN(jrt.File_Cast(f__3)).GetAbsolutePath__String().Ref() }; return nil }(); if /*line :612:1*/ tmp7 != nil { if true { var ___3 jrt.Throwable_I = tmp7; _ = ___3; tmp1 = nil } }; return tmp1 }

func A_arbace_main_report_error_fn__461000199_fn__461000200_A_New_O_O(p0, p1 any) *A_arbace_main_report_error_fn__461000199_fn__461000200_A { A_arbace_main_A_Init(); t := &A_arbace_main_report_error_fn__461000199_fn__461000200_A{}; t.Ctor_O_O(p0, p1); return t }
//line :614:1
func (t *A_arbace_main_report_error_fn__461000199_fn__461000200_A) Ctor_O_O(c__w, c__report_str any) { t.F_w = c__w; t.F_report_str = c__report_str }
//line :614:1
func (t *A_arbace_main_report_error_fn__461000199_fn__461000200_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var root_1399 any = A_arbace_main_A_const_142.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1399, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1401 lang.IFn; if linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any = lang.IFn_Cast(A_arbace_main_A_const_143.GetRawRoot__O()).Invoke_O_O__O(A_arbace_main_A_const_144, t.F_w); if linked_1400 == nil { ifn_1401.Invoke_O__O(arg_1402) } else { linked_1400.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1399, arg_1402) }; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_210.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_report_str; t.F_report_str = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); var root_1396 any = A_arbace_main_A_const_136.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; if linked_1397 == nil { ifn_1398.Invoke__O() } else { linked_1397.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1396) }
//line :614:1
		if tmp4 != nil { panic(tmp4) } }; return nil }(); var tmp6 any; var t__2 any = t.F_w; t.F_w = nil; tmp6 = t__2; jrt.BufferedWriter_Cast(tmp6).Close__V(); if tmp5 != nil { panic(tmp5) }; return tmp1 }








func A_arbace_main_main_A_New() *A_arbace_main_main_A { A_arbace_main_A_Init(); t := &A_arbace_main_main_A{}; t.Ctor(); return t }
//line :623:1
func (t *A_arbace_main_main_A) Ctor() {}
//line :623:1
func (t *A_arbace_main_main_A) DoInvoke_O_O__O(self, args__0 any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


































	if jrt.J2g_Truth(args__0) { var G__461000207__4_ any = args__0; var vec__461000208__5 any = G__461000207__4_; var seq__461000209__6 any; var root_1439 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1441 lang.IFn
		if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any = vec__461000208__5; if linked_1440 == nil { seq__461000209__6 = ifn_1441.Invoke_O__O(arg_1442) } else { seq__461000209__6 = linked_1440.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1439, arg_1442) }
//line :658:1
		var first__461000210__7 any; var root_1443 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1445 lang.IFn
		if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = seq__461000209__6; if linked_1444 == nil { first__461000210__7 = ifn_1445.Invoke_O__O(arg_1446) } else { first__461000210__7 = linked_1444.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1443, arg_1446) }
//line :658:1
		var seq__461000209__8 any; var root_1447 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1447, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1449 lang.IFn
		if linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any = seq__461000209__6; if linked_1448 == nil { seq__461000209__8 = ifn_1449.Invoke_O__O(arg_1450) } else { seq__461000209__8 = linked_1448.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1447, arg_1450) }
//line :658:1
		var opt__9 any = first__461000210__7; var first__461000210__10 any; var root_1451 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1451, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1453 lang.IFn; _ = opt__9
		if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = seq__461000209__8; if linked_1452 == nil { first__461000210__10 = ifn_1453.Invoke_O__O(arg_1454) } else { first__461000210__10 = linked_1452.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1451, arg_1454) }
//line :658:1
		var seq__461000209__11 any; var root_1455 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1457 lang.IFn
		if linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any = seq__461000209__8; if linked_1456 == nil { seq__461000209__11 = ifn_1457.Invoke_O__O(arg_1458) } else { seq__461000209__11 = linked_1456.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1455, arg_1458) }
//line :658:1
		var arg__12 any = first__461000210__10; var more__13 any = seq__461000209__11; var args__14 any = vec__461000208__5; var inits__15 any = lang.PersistentVector_EMPTY.Ref(); var flags__16 any; var G__461000207__17_ any = G__461000207__4_; var inits__18 any = inits__15; var flags__19 any = flags__16; _ = arg__12; _ = more__13; _ = args__14; L1: for { var vec__461000211__20 any = G__461000207__17_; var seq__461000212__21 any; var root_1459 any = A_arbace_main_A_const_19.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1461 lang.IFn
			if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any = vec__461000211__20; if linked_1460 == nil { seq__461000212__21 = ifn_1461.Invoke_O__O(arg_1462) } else { seq__461000212__21 = linked_1460.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1459, arg_1462) }
//line :658:1
			var first__461000213__22 any; var root_1463 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1465 lang.IFn
			if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = seq__461000212__21; if linked_1464 == nil { first__461000213__22 = ifn_1465.Invoke_O__O(arg_1466) } else { first__461000213__22 = linked_1464.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1463, arg_1466) }
//line :658:1
			var seq__461000212__23 any; var root_1467 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1469 lang.IFn
			if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = seq__461000212__21; if linked_1468 == nil { seq__461000212__23 = ifn_1469.Invoke_O__O(arg_1470) } else { seq__461000212__23 = linked_1468.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1467, arg_1470) }
//line :658:1
			var opt__24 any = first__461000213__22; var first__461000213__25 any; var root_1471 any = A_arbace_main_A_const_69.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1473 lang.IFn
			if linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any = seq__461000212__23; if linked_1472 == nil { first__461000213__25 = ifn_1473.Invoke_O__O(arg_1474) } else { first__461000213__25 = linked_1472.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1471, arg_1474) }
//line :658:1
			var seq__461000212__26 any; var root_1475 any = A_arbace_main_A_const_67.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1477 lang.IFn
			if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any = seq__461000212__23; if linked_1476 == nil { seq__461000212__26 = ifn_1477.Invoke_O__O(arg_1478) } else { seq__461000212__26 = linked_1476.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1475, arg_1478) }
//line :658:1
			var arg__27 any = first__461000213__25; var more__28 any = seq__461000212__26; var args__29 any = vec__461000211__20; var inits__30 any = inits__18; var flags__31 any = flags__19; var tmp2 any; var root_1479 any = A_arbace_main_A_const_13.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1481 lang.IFn



			if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = A_arbace_main_A_const_237; var arg_1483 any = opt__24; if linked_1480 == nil { tmp2 = ifn_1481.Invoke_O_O__O(arg_1482, arg_1483) } else { tmp2 = linked_1480.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1479, arg_1482, arg_1483) }
//line :660:1
			if jrt.J2g_Truth(tmp2) {


				var tmp3 any; var root_1500 any = A_arbace_main_A_const_126.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1500, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1502 lang.IFn; if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any = flags__31; var arg_1504 any; var tmp4 any; var root_1505 any = A_arbace_main_A_const_80.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = opt__24; var arg_1509 any = A_arbace_main_A_const_240; if linked_1506 == nil { tmp4 = ifn_1507.Invoke_O_O__O(arg_1508, arg_1509) } else { tmp4 = linked_1506.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1505, arg_1508, arg_1509) }; arg_1504 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, arg__27)); if linked_1501 == nil { tmp3 = ifn_1502.Invoke_O_O__O(arg_1503, arg_1504) } else { tmp3 = linked_1501.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1500, arg_1503, arg_1504) }; G__461000207__17_, inits__18, flags__19 = more__28, inits__30, tmp3; continue L1 } else {
//line :660:1
					var tmp5 any; var root_1484 any = A_arbace_main_A_const_204.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, A_arbace_main_init_dispatch_A_fn_class); var ifn_1486 lang.IFn





					if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = opt__24; if linked_1485 == nil { tmp5 = ifn_1486.Invoke_O__O(arg_1487) } else { tmp5 = linked_1485.(*A_arbace_main_init_dispatch_A).Invoke_O_O__O(root_1484, arg_1487) }
//line :660:1
					if jrt.J2g_Truth(tmp5) {






						var tmp6 any; var root_1510 any = A_arbace_main_A_const_9.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1510, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any = inits__30; var arg_1514 any = lang.Tuple_Create_O_O__IPersistentVector(opt__24, arg__27); if linked_1511 == nil { tmp6 = ifn_1512.Invoke_O_O__O(arg_1513, arg_1514) } else { tmp6 = linked_1511.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1510, arg_1513, arg_1514) }; G__461000207__17_, inits__18, flags__19 = more__28, tmp6, flags__31; continue L1 } else {
//line :660:1
							if A_arbace_main_A_const_238 != nil { tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)










								{ var tmp7 any; var root_1488 any = A_arbace_main_A_const_239.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, A_arbace_main_main_dispatch_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = opt__24; if linked_1489 == nil { tmp7 = ifn_1490.Invoke_O__O(arg_1491) } else { tmp7 = linked_1489.(*A_arbace_main_main_dispatch_A).Invoke_O_O__O(root_1488, arg_1491) }; tmp1 = lang.IFn_Cast(tmp7).Invoke_O_O__O(args__29, inits__30) }
//line :660:1
								return nil }(); if tmp8 != nil { if true { var t__34 jrt.Throwable_I = tmp8; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_main_A_const_241.GetRawRoot__O())
									var tmp10 any = A_arbace_main_A_const_231











									tmp9.Invoke_O_O_O__O(t__34, tmp10, lang.RT_Get_O_O_O__O_NoInit(flags__31, Lit_53, jrt.System_GetProperty_String_String__String(Lit_54, Lit_55).Ref()))
									jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(1)); tmp1 = nil } } } else {
//line :660:1
										tmp1 = nil } } }
//line :658:1
			break L1 } } else { tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

















				{ var root_1492 any = A_arbace_main_A_const_220.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, A_arbace_main_repl_opt_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any; var arg_1496 any; if linked_1493 == nil { tmp1 = ifn_1494.Invoke_O_O__O(arg_1495, arg_1496) } else { tmp1 = linked_1493.(*A_arbace_main_repl_opt_A).Invoke_O_O_O__O(root_1492, arg_1495, arg_1496) } }
//line :658:1
				return nil }(); if tmp11 != nil { if true { var t__6 jrt.Throwable_I = tmp11



















					lang.IFn_Cast(A_arbace_main_A_const_241.GetRawRoot__O()).Invoke_O_O_O__O(t__6, A_arbace_main_A_const_231, Lit_55)
					jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(1)); tmp1 = nil } } }
//line :623:1
	return nil }(); var root_1497 any = A_arbace_main_A_const_148.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_1499 lang.IFn; if

























































	linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; if linked_1498 == nil { ifn_1499.Invoke__O() } else { linked_1498.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_1497) }; if /*line :623:1*/ tmp12 != nil { panic(tmp12) }; return tmp1 }
















type A_arbace_main_A struct{ jrt.Object }

var A_arbace_main_A_const_pool *jrt.RefArray

var A_arbace_main_A_const_0 *lang.Var

var A_arbace_main_A_const_1 any

var A_arbace_main_A_const_2 *lang.Keyword

var A_arbace_main_A_const_3 any

var A_arbace_main_A_const_4 *lang.Var

var A_arbace_main_A_const_5 any

var A_arbace_main_A_const_6 *lang.Var

var A_arbace_main_A_const_7 *lang.Var

var A_arbace_main_A_const_8 *lang.Var

var A_arbace_main_A_const_9 *lang.Var

var A_arbace_main_A_const_10 any

var A_arbace_main_A_const_11 *lang.Var

var A_arbace_main_A_const_12 *lang.Var

var A_arbace_main_A_const_13 *lang.Var

var A_arbace_main_A_const_14 *lang.Var

var A_arbace_main_A_const_15 *lang.Var

var A_arbace_main_A_const_16 *lang.Var

var A_arbace_main_A_const_17 any

var A_arbace_main_A_const_18 *lang.Var

var A_arbace_main_A_const_19 *lang.Var

var A_arbace_main_A_const_20 *lang.Var

var A_arbace_main_A_const_21 *lang.Var

var A_arbace_main_A_const_22 any

var A_arbace_main_A_const_23 *lang.Var

var A_arbace_main_A_const_24 *lang.Var

var A_arbace_main_A_const_25 any

var A_arbace_main_A_const_26 any

var A_arbace_main_A_const_27 any

var A_arbace_main_A_const_28 any

var A_arbace_main_A_const_29 any

var A_arbace_main_A_const_30 any

var A_arbace_main_A_const_31 any

var A_arbace_main_A_const_32 any

var A_arbace_main_A_const_33 any

var A_arbace_main_A_const_34 any

var A_arbace_main_A_const_35 any

var A_arbace_main_A_const_36 any

var A_arbace_main_A_const_37 any

var A_arbace_main_A_const_38 any

var A_arbace_main_A_const_39 any

var A_arbace_main_A_const_40 any

var A_arbace_main_A_const_41 any

var A_arbace_main_A_const_42 any

var A_arbace_main_A_const_43 any

var A_arbace_main_A_const_44 any

var A_arbace_main_A_const_45 any

var A_arbace_main_A_const_46 any

var A_arbace_main_A_const_47 any

var A_arbace_main_A_const_48 any

var A_arbace_main_A_const_49 any

var A_arbace_main_A_const_50 any

var A_arbace_main_A_const_51 any

var A_arbace_main_A_const_52 any

var A_arbace_main_A_const_53 any

var A_arbace_main_A_const_54 any

var A_arbace_main_A_const_55 any

var A_arbace_main_A_const_56 *lang.Var

var A_arbace_main_A_const_57 *lang.Var

var A_arbace_main_A_const_58 *lang.Var

var A_arbace_main_A_const_59 any

var A_arbace_main_A_const_60 *lang.Keyword

var A_arbace_main_A_const_61 *lang.Keyword

var A_arbace_main_A_const_62 *lang.Keyword

var A_arbace_main_A_const_63 *lang.Keyword

var A_arbace_main_A_const_64 any

var A_arbace_main_A_const_65 any

var A_arbace_main_A_const_66 *lang.Var

var A_arbace_main_A_const_67 *lang.Var

var A_arbace_main_A_const_68 *lang.Var

var A_arbace_main_A_const_69 *lang.Var

var A_arbace_main_A_const_70 *lang.Keyword

var A_arbace_main_A_const_71 *lang.Keyword

var A_arbace_main_A_const_72 *lang.Var

var A_arbace_main_A_const_73 *lang.Var

var A_arbace_main_A_const_74 any

var A_arbace_main_A_const_75 *lang.Var

var A_arbace_main_A_const_76 any

var A_arbace_main_A_const_77 *lang.Var

var A_arbace_main_A_const_78 *lang.Var

var A_arbace_main_A_const_79 *lang.Var

var A_arbace_main_A_const_80 *lang.Var

var A_arbace_main_A_const_81 any

var A_arbace_main_A_const_82 *jrt.Class

var A_arbace_main_A_const_83 *lang.Var

var A_arbace_main_A_const_84 any

var A_arbace_main_A_const_85 *lang.Var

var A_arbace_main_A_const_86 *lang.Var

var A_arbace_main_A_const_87 *lang.Var

var A_arbace_main_A_const_88 *lang.Var

var A_arbace_main_A_const_89 *lang.Var

var A_arbace_main_A_const_90 *lang.Keyword

var A_arbace_main_A_const_91 *lang.Keyword

var A_arbace_main_A_const_92 *lang.Keyword

var A_arbace_main_A_const_93 *lang.Keyword

var A_arbace_main_A_const_94 *lang.Var

var A_arbace_main_A_const_95 *lang.Keyword

var A_arbace_main_A_const_96 *lang.Keyword

var A_arbace_main_A_const_97 *lang.Keyword

var A_arbace_main_A_const_98 *lang.Keyword

var A_arbace_main_A_const_99 *lang.Keyword

var A_arbace_main_A_const_100 *lang.Keyword

var A_arbace_main_A_const_101 *lang.Keyword

var A_arbace_main_A_const_102 *lang.Var

var A_arbace_main_A_const_103 *lang.Keyword

var A_arbace_main_A_const_104 *lang.Var

var A_arbace_main_A_const_105 *lang.Keyword

var A_arbace_main_A_const_106 *lang.Var

var A_arbace_main_A_const_107 any

var A_arbace_main_A_const_108 *lang.Var

var A_arbace_main_A_const_109 *lang.Keyword

var A_arbace_main_A_const_110 *lang.Keyword

var A_arbace_main_A_const_111 *lang.Keyword

var A_arbace_main_A_const_112 *lang.Keyword

var A_arbace_main_A_const_113 any

var A_arbace_main_A_const_114 *lang.Keyword

var A_arbace_main_A_const_115 any

var A_arbace_main_A_const_116 *lang.Var

var A_arbace_main_A_const_117 *lang.Var

var A_arbace_main_A_const_118 *lang.Var

var A_arbace_main_A_const_119 any

var A_arbace_main_A_const_120 *lang.Keyword

var A_arbace_main_A_const_121 *lang.Keyword

var A_arbace_main_A_const_122 *lang.Keyword

var A_arbace_main_A_const_123 *lang.Var

var A_arbace_main_A_const_124 *lang.Keyword

var A_arbace_main_A_const_125 *lang.Keyword

var A_arbace_main_A_const_126 *lang.Var

var A_arbace_main_A_const_127 any

var A_arbace_main_A_const_128 *lang.Keyword

var A_arbace_main_A_const_129 *lang.Keyword

var A_arbace_main_A_const_130 any

var A_arbace_main_A_const_131 *lang.Keyword

var A_arbace_main_A_const_132 *lang.Keyword

var A_arbace_main_A_const_133 any

var A_arbace_main_A_const_134 any

var A_arbace_main_A_const_135 *lang.Var

var A_arbace_main_A_const_136 *lang.Var

var A_arbace_main_A_const_137 *lang.Var

var A_arbace_main_A_const_138 *lang.Var

var A_arbace_main_A_const_139 *lang.Var

var A_arbace_main_A_const_140 *lang.Var

var A_arbace_main_A_const_141 *lang.Keyword

var A_arbace_main_A_const_142 *lang.Var

var A_arbace_main_A_const_143 *lang.Var

var A_arbace_main_A_const_144 *lang.Var

var A_arbace_main_A_const_145 *lang.Var

var A_arbace_main_A_const_146 *lang.Var

var A_arbace_main_A_const_147 *lang.Var

var A_arbace_main_A_const_148 *lang.Var

var A_arbace_main_A_const_149 *lang.Var

var A_arbace_main_A_const_150 *lang.Var

var A_arbace_main_A_const_151 *lang.Var

var A_arbace_main_A_const_152 any

var A_arbace_main_A_const_153 any

var A_arbace_main_A_const_154 any

var A_arbace_main_A_const_155 any

var A_arbace_main_A_const_156 *lang.Keyword

var A_arbace_main_A_const_157 any

var A_arbace_main_A_const_158 any

var A_arbace_main_A_const_159 *lang.Var

var A_arbace_main_A_const_160 *lang.Var

var A_arbace_main_A_const_161 *lang.Var

var A_arbace_main_A_const_162 *lang.Var

var A_arbace_main_A_const_163 *lang.Var

var A_arbace_main_A_const_164 *lang.Var

var A_arbace_main_A_const_165 *lang.Keyword

var A_arbace_main_A_const_166 *lang.Keyword

var A_arbace_main_A_const_167 *lang.Keyword

var A_arbace_main_A_const_168 *lang.Keyword

var A_arbace_main_A_const_169 *lang.Keyword

var A_arbace_main_A_const_170 *lang.Keyword

var A_arbace_main_A_const_171 *lang.Keyword

var A_arbace_main_A_const_172 *lang.Keyword

var A_arbace_main_A_const_173 *lang.Var

var A_arbace_main_A_const_174 *lang.Var

var A_arbace_main_A_const_175 any

var A_arbace_main_A_const_176 *lang.Var

var A_arbace_main_A_const_177 *lang.Var

var A_arbace_main_A_const_178 *lang.Var

var A_arbace_main_A_const_179 any

var A_arbace_main_A_const_180 *lang.Var

var A_arbace_main_A_const_181 *jrt.Class

var A_arbace_main_A_const_182 *lang.Var

var A_arbace_main_A_const_183 *lang.Var

var A_arbace_main_A_const_184 *lang.Var

var A_arbace_main_A_const_185 *lang.Var

var A_arbace_main_A_const_186 *lang.Var

var A_arbace_main_A_const_187 *lang.Var

var A_arbace_main_A_const_188 *lang.Var

var A_arbace_main_A_const_189 *lang.Var

var A_arbace_main_A_const_190 *lang.Var

var A_arbace_main_A_const_191 *lang.Var

var A_arbace_main_A_const_192 *lang.Var

var A_arbace_main_A_const_193 *lang.Var

var A_arbace_main_A_const_194 *lang.Var

var A_arbace_main_A_const_195 *lang.Var

var A_arbace_main_A_const_196 any

var A_arbace_main_A_const_197 *lang.Var

var A_arbace_main_A_const_198 *lang.Var

var A_arbace_main_A_const_199 *lang.Var

var A_arbace_main_A_const_200 *lang.Var

var A_arbace_main_A_const_201 *lang.Var

var A_arbace_main_A_const_202 *lang.Var

var A_arbace_main_A_const_203 any

var A_arbace_main_A_const_204 *lang.Var

var A_arbace_main_A_const_205 *lang.Var

var A_arbace_main_A_const_206 *lang.Var

var A_arbace_main_A_const_207 any

var A_arbace_main_A_const_208 *lang.Var

var A_arbace_main_A_const_209 *lang.Var

var A_arbace_main_A_const_210 *lang.Var

var A_arbace_main_A_const_211 *lang.Var

var A_arbace_main_A_const_212 *lang.Keyword

var A_arbace_main_A_const_213 *lang.Var

var A_arbace_main_A_const_214 any

var A_arbace_main_A_const_215 *lang.Var

var A_arbace_main_A_const_216 *lang.Var

var A_arbace_main_A_const_217 *lang.Var

var A_arbace_main_A_const_218 *lang.Keyword

var A_arbace_main_A_const_219 *lang.Var

var A_arbace_main_A_const_220 *lang.Var

var A_arbace_main_A_const_221 *lang.Var

var A_arbace_main_A_const_222 *lang.Var

var A_arbace_main_A_const_223 *lang.Var

var A_arbace_main_A_const_224 *lang.Var

var A_arbace_main_A_const_225 *lang.Var

var A_arbace_main_A_const_226 *lang.Var

var A_arbace_main_A_const_227 any

var A_arbace_main_A_const_228 any

var A_arbace_main_A_const_229 *lang.Var

var A_arbace_main_A_const_230 any

var A_arbace_main_A_const_231 *lang.Keyword

var A_arbace_main_A_const_232 *lang.Var

var A_arbace_main_A_const_233 *lang.Keyword

var A_arbace_main_A_const_234 *lang.Keyword

var A_arbace_main_A_const_235 *lang.Keyword

var A_arbace_main_A_const_236 *jrt.Class

var A_arbace_main_A_const_237 any

var A_arbace_main_A_const_238 *lang.Keyword

var A_arbace_main_A_const_239 *lang.Var

var A_arbace_main_A_const_240 any

var A_arbace_main_A_const_241 *lang.Var

var A_arbace_main_A_init jrt.ClassInit

func A_arbace_main_A_Init() { if !A_arbace_main_A_init.Done() { A_arbace_main_A_init.Run(A_arbace_main_A_clinit) } }

func A_arbace_main_A_clinit() { A_arbace_main_A_clinit_p0(); A_arbace_main_A_clinit_p1(); A_arbace_main_A_clinit_p2(); A_arbace_main_A_clinit_p3(); A_arbace_main_A_clinit_p4(); A_arbace_main_A_clinit_p5(); A_arbace_main_A_clinit_p6(); A_arbace_main_A_clinit_p7(); A_arbace_main_A_clinit_p8(); A_arbace_main_A_clinit_p9(); A_arbace_main_A_clinit_p10(); A_arbace_main_A_clinit_p11(); A_arbace_main_A_clinit_p12(); A_arbace_main_A_clinit_p13(); A_arbace_main_A_clinit_p14(); A_arbace_main_A_clinit_p15(); A_arbace_main_A_clinit_p16(); A_arbace_main_A_clinit_p17(); A_arbace_main_A_clinit_p18(); A_arbace_main_A_clinit_p19() }

func A_arbace_main_A_clinit_p0() { jrt.StartCheck(); A_arbace_main_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 329); A_arbace_main_A_const_0 = lang.Var_Cast(A_arbace_main_A_const_pool.A[87]); A_arbace_main_A_const_1 = A_arbace_main_A_const_pool.A[88]; A_arbace_main_A_const_2 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[89]); A_arbace_main_A_const_3 = A_arbace_main_A_const_pool.A[90]; A_arbace_main_A_const_4 = lang.Var_Cast(A_arbace_main_A_const_pool.A[91]); A_arbace_main_A_const_5 = A_arbace_main_A_const_pool.A[92]; A_arbace_main_A_const_6 = lang.Var_Cast(A_arbace_main_A_const_pool.A[93]); A_arbace_main_A_const_7 = lang.Var_Cast(A_arbace_main_A_const_pool.A[94]); A_arbace_main_A_const_8 = lang.Var_Cast(A_arbace_main_A_const_pool.A[95]); A_arbace_main_A_const_9 = lang.Var_Cast(A_arbace_main_A_const_pool.A[96]); A_arbace_main_A_const_10 = A_arbace_main_A_const_pool.A[97]; A_arbace_main_A_const_11 = lang.Var_Cast(A_arbace_main_A_const_pool.A[98]) }

func A_arbace_main_A_clinit_p1() { A_arbace_main_A_const_12 = lang.Var_Cast(A_arbace_main_A_const_pool.A[99]); A_arbace_main_A_const_13 = lang.Var_Cast(A_arbace_main_A_const_pool.A[100]); A_arbace_main_A_const_14 = lang.Var_Cast(A_arbace_main_A_const_pool.A[101]); A_arbace_main_A_const_15 = lang.Var_Cast(A_arbace_main_A_const_pool.A[102]); A_arbace_main_A_const_16 = lang.Var_Cast(A_arbace_main_A_const_pool.A[103]); A_arbace_main_A_const_17 = A_arbace_main_A_const_pool.A[104]; A_arbace_main_A_const_18 = lang.Var_Cast(A_arbace_main_A_const_pool.A[105]); A_arbace_main_A_const_19 = lang.Var_Cast(A_arbace_main_A_const_pool.A[106]); A_arbace_main_A_const_20 = lang.Var_Cast(A_arbace_main_A_const_pool.A[107]); A_arbace_main_A_const_21 = lang.Var_Cast(A_arbace_main_A_const_pool.A[108]); A_arbace_main_A_const_22 = A_arbace_main_A_const_pool.A[109]; A_arbace_main_A_const_23 = lang.Var_Cast(A_arbace_main_A_const_pool.A[110]) }

func A_arbace_main_A_clinit_p2() { A_arbace_main_A_const_24 = lang.Var_Cast(A_arbace_main_A_const_pool.A[111]); A_arbace_main_A_const_25 = A_arbace_main_A_const_pool.A[112]; A_arbace_main_A_const_26 = A_arbace_main_A_const_pool.A[113]; A_arbace_main_A_const_27 = A_arbace_main_A_const_pool.A[114]; A_arbace_main_A_const_28 = A_arbace_main_A_const_pool.A[115]; A_arbace_main_A_const_29 = A_arbace_main_A_const_pool.A[116]; A_arbace_main_A_const_30 = A_arbace_main_A_const_pool.A[117]; A_arbace_main_A_const_31 = A_arbace_main_A_const_pool.A[118]; A_arbace_main_A_const_32 = A_arbace_main_A_const_pool.A[119]; A_arbace_main_A_const_33 = A_arbace_main_A_const_pool.A[120]; A_arbace_main_A_const_34 = A_arbace_main_A_const_pool.A[121]; A_arbace_main_A_const_35 = A_arbace_main_A_const_pool.A[122]; A_arbace_main_A_const_36 = A_arbace_main_A_const_pool.A[123]; A_arbace_main_A_const_37 = A_arbace_main_A_const_pool.A[124]; A_arbace_main_A_const_38 = A_arbace_main_A_const_pool.A[125] }

func A_arbace_main_A_clinit_p3() { A_arbace_main_A_const_39 = A_arbace_main_A_const_pool.A[126]; A_arbace_main_A_const_40 = A_arbace_main_A_const_pool.A[127]; A_arbace_main_A_const_41 = A_arbace_main_A_const_pool.A[128]; A_arbace_main_A_const_42 = A_arbace_main_A_const_pool.A[129]; A_arbace_main_A_const_43 = A_arbace_main_A_const_pool.A[130]; A_arbace_main_A_const_44 = A_arbace_main_A_const_pool.A[131]; A_arbace_main_A_const_45 = A_arbace_main_A_const_pool.A[132]; A_arbace_main_A_const_46 = A_arbace_main_A_const_pool.A[133]; A_arbace_main_A_const_47 = A_arbace_main_A_const_pool.A[134]; A_arbace_main_A_const_48 = A_arbace_main_A_const_pool.A[135]; A_arbace_main_A_const_49 = A_arbace_main_A_const_pool.A[136]; A_arbace_main_A_const_50 = A_arbace_main_A_const_pool.A[137]; A_arbace_main_A_const_51 = A_arbace_main_A_const_pool.A[138]; A_arbace_main_A_const_52 = A_arbace_main_A_const_pool.A[139]; A_arbace_main_A_const_53 = A_arbace_main_A_const_pool.A[140]; A_arbace_main_A_const_54 = A_arbace_main_A_const_pool.A[141] }

func A_arbace_main_A_clinit_p4() { A_arbace_main_A_const_55 = A_arbace_main_A_const_pool.A[142]; A_arbace_main_A_const_56 = lang.Var_Cast(A_arbace_main_A_const_pool.A[143]); A_arbace_main_A_const_57 = lang.Var_Cast(A_arbace_main_A_const_pool.A[144]); A_arbace_main_A_const_58 = lang.Var_Cast(A_arbace_main_A_const_pool.A[145]); A_arbace_main_A_const_59 = A_arbace_main_A_const_pool.A[146]; A_arbace_main_A_const_60 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[147]); A_arbace_main_A_const_61 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[148]); A_arbace_main_A_const_62 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[149]); A_arbace_main_A_const_63 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[150]); A_arbace_main_A_const_64 = A_arbace_main_A_const_pool.A[151]; A_arbace_main_A_const_65 = A_arbace_main_A_const_pool.A[152]; A_arbace_main_A_const_66 = lang.Var_Cast(A_arbace_main_A_const_pool.A[153]); A_arbace_main_A_const_67 = lang.Var_Cast(A_arbace_main_A_const_pool.A[154]) }

func A_arbace_main_A_clinit_p5() { A_arbace_main_A_const_68 = lang.Var_Cast(A_arbace_main_A_const_pool.A[155]); A_arbace_main_A_const_69 = lang.Var_Cast(A_arbace_main_A_const_pool.A[156]); A_arbace_main_A_const_70 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[157]); A_arbace_main_A_const_71 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[158]); A_arbace_main_A_const_72 = lang.Var_Cast(A_arbace_main_A_const_pool.A[159]); A_arbace_main_A_const_73 = lang.Var_Cast(A_arbace_main_A_const_pool.A[160]); A_arbace_main_A_const_74 = A_arbace_main_A_const_pool.A[161]; A_arbace_main_A_const_75 = lang.Var_Cast(A_arbace_main_A_const_pool.A[162]); A_arbace_main_A_const_76 = A_arbace_main_A_const_pool.A[163]; A_arbace_main_A_const_77 = lang.Var_Cast(A_arbace_main_A_const_pool.A[164]); A_arbace_main_A_const_78 = lang.Var_Cast(A_arbace_main_A_const_pool.A[165]); A_arbace_main_A_const_79 = lang.Var_Cast(A_arbace_main_A_const_pool.A[166]) }

func A_arbace_main_A_clinit_p6() { A_arbace_main_A_const_80 = lang.Var_Cast(A_arbace_main_A_const_pool.A[167]); A_arbace_main_A_const_81 = A_arbace_main_A_const_pool.A[168]; A_arbace_main_A_const_82 = jrt.Class_Cast(A_arbace_main_A_const_pool.A[169]); A_arbace_main_A_const_83 = lang.Var_Cast(A_arbace_main_A_const_pool.A[170]); A_arbace_main_A_const_84 = A_arbace_main_A_const_pool.A[171]; A_arbace_main_A_const_85 = lang.Var_Cast(A_arbace_main_A_const_pool.A[172]); A_arbace_main_A_const_86 = lang.Var_Cast(A_arbace_main_A_const_pool.A[173]); A_arbace_main_A_const_87 = lang.Var_Cast(A_arbace_main_A_const_pool.A[174]); A_arbace_main_A_const_88 = lang.Var_Cast(A_arbace_main_A_const_pool.A[175]); A_arbace_main_A_const_89 = lang.Var_Cast(A_arbace_main_A_const_pool.A[176]); A_arbace_main_A_const_90 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[177]); A_arbace_main_A_const_91 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[178]) }

func A_arbace_main_A_clinit_p7() { A_arbace_main_A_const_92 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[179]); A_arbace_main_A_const_93 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[180]); A_arbace_main_A_const_94 = lang.Var_Cast(A_arbace_main_A_const_pool.A[181]); A_arbace_main_A_const_95 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[182]); A_arbace_main_A_const_96 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[183]); A_arbace_main_A_const_97 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[184]); A_arbace_main_A_const_98 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[185]); A_arbace_main_A_const_99 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[186]); A_arbace_main_A_const_100 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[187]); A_arbace_main_A_const_101 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[188]); A_arbace_main_A_const_102 = lang.Var_Cast(A_arbace_main_A_const_pool.A[189]); A_arbace_main_A_const_103 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[190]) }

func A_arbace_main_A_clinit_p8() { A_arbace_main_A_const_104 = lang.Var_Cast(A_arbace_main_A_const_pool.A[191]); A_arbace_main_A_const_105 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[192]); A_arbace_main_A_const_106 = lang.Var_Cast(A_arbace_main_A_const_pool.A[193]); A_arbace_main_A_const_107 = A_arbace_main_A_const_pool.A[194]; A_arbace_main_A_const_108 = lang.Var_Cast(A_arbace_main_A_const_pool.A[195]); A_arbace_main_A_const_109 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[196]); A_arbace_main_A_const_110 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[197]); A_arbace_main_A_const_111 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[198]); A_arbace_main_A_const_112 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[199]); A_arbace_main_A_const_113 = A_arbace_main_A_const_pool.A[200]; A_arbace_main_A_const_114 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[201]); A_arbace_main_A_const_115 = A_arbace_main_A_const_pool.A[202] }

func A_arbace_main_A_clinit_p9() { A_arbace_main_A_const_116 = lang.Var_Cast(A_arbace_main_A_const_pool.A[203]); A_arbace_main_A_const_117 = lang.Var_Cast(A_arbace_main_A_const_pool.A[204]); A_arbace_main_A_const_118 = lang.Var_Cast(A_arbace_main_A_const_pool.A[205]); A_arbace_main_A_const_119 = A_arbace_main_A_const_pool.A[206]; A_arbace_main_A_const_120 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[207]); A_arbace_main_A_const_121 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[208]); A_arbace_main_A_const_122 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[209]); A_arbace_main_A_const_123 = lang.Var_Cast(A_arbace_main_A_const_pool.A[210]); A_arbace_main_A_const_124 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[211]); A_arbace_main_A_const_125 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[212]); A_arbace_main_A_const_126 = lang.Var_Cast(A_arbace_main_A_const_pool.A[213]); A_arbace_main_A_const_127 = A_arbace_main_A_const_pool.A[214] }

func A_arbace_main_A_clinit_p10() { A_arbace_main_A_const_128 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[215]); A_arbace_main_A_const_129 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[216]); A_arbace_main_A_const_130 = A_arbace_main_A_const_pool.A[217]; A_arbace_main_A_const_131 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[218]); A_arbace_main_A_const_132 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[219]); A_arbace_main_A_const_133 = A_arbace_main_A_const_pool.A[220]; A_arbace_main_A_const_134 = A_arbace_main_A_const_pool.A[221]; A_arbace_main_A_const_135 = lang.Var_Cast(A_arbace_main_A_const_pool.A[222]); A_arbace_main_A_const_136 = lang.Var_Cast(A_arbace_main_A_const_pool.A[223]); A_arbace_main_A_const_137 = lang.Var_Cast(A_arbace_main_A_const_pool.A[224]); A_arbace_main_A_const_138 = lang.Var_Cast(A_arbace_main_A_const_pool.A[225]); A_arbace_main_A_const_139 = lang.Var_Cast(A_arbace_main_A_const_pool.A[226]) }

func A_arbace_main_A_clinit_p11() { A_arbace_main_A_const_140 = lang.Var_Cast(A_arbace_main_A_const_pool.A[227]); A_arbace_main_A_const_141 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[228]); A_arbace_main_A_const_142 = lang.Var_Cast(A_arbace_main_A_const_pool.A[229]); A_arbace_main_A_const_143 = lang.Var_Cast(A_arbace_main_A_const_pool.A[230]); A_arbace_main_A_const_144 = lang.Var_Cast(A_arbace_main_A_const_pool.A[231]); A_arbace_main_A_const_145 = lang.Var_Cast(A_arbace_main_A_const_pool.A[232]); A_arbace_main_A_const_146 = lang.Var_Cast(A_arbace_main_A_const_pool.A[233]); A_arbace_main_A_const_147 = lang.Var_Cast(A_arbace_main_A_const_pool.A[234]); A_arbace_main_A_const_148 = lang.Var_Cast(A_arbace_main_A_const_pool.A[235]); A_arbace_main_A_const_149 = lang.Var_Cast(A_arbace_main_A_const_pool.A[236]); A_arbace_main_A_const_150 = lang.Var_Cast(A_arbace_main_A_const_pool.A[237]); A_arbace_main_A_const_151 = lang.Var_Cast(A_arbace_main_A_const_pool.A[238]) }

func A_arbace_main_A_clinit_p12() { A_arbace_main_A_const_152 = A_arbace_main_A_const_pool.A[239]; A_arbace_main_A_const_153 = A_arbace_main_A_const_pool.A[240]; A_arbace_main_A_const_154 = A_arbace_main_A_const_pool.A[241]; A_arbace_main_A_const_155 = A_arbace_main_A_const_pool.A[242]; A_arbace_main_A_const_156 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[243]); A_arbace_main_A_const_157 = A_arbace_main_A_const_pool.A[244]; A_arbace_main_A_const_158 = A_arbace_main_A_const_pool.A[245]; A_arbace_main_A_const_159 = lang.Var_Cast(A_arbace_main_A_const_pool.A[246]); A_arbace_main_A_const_160 = lang.Var_Cast(A_arbace_main_A_const_pool.A[247]); A_arbace_main_A_const_161 = lang.Var_Cast(A_arbace_main_A_const_pool.A[248]); A_arbace_main_A_const_162 = lang.Var_Cast(A_arbace_main_A_const_pool.A[249]); A_arbace_main_A_const_163 = lang.Var_Cast(A_arbace_main_A_const_pool.A[250]); A_arbace_main_A_const_164 = lang.Var_Cast(A_arbace_main_A_const_pool.A[251]) }

func A_arbace_main_A_clinit_p13() { A_arbace_main_A_const_165 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[252]); A_arbace_main_A_const_166 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[253]); A_arbace_main_A_const_167 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[254]); A_arbace_main_A_const_168 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[255]); A_arbace_main_A_const_169 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[256]); A_arbace_main_A_const_170 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[257]); A_arbace_main_A_const_171 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[258]); A_arbace_main_A_const_172 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[259]); A_arbace_main_A_const_173 = lang.Var_Cast(A_arbace_main_A_const_pool.A[260]); A_arbace_main_A_const_174 = lang.Var_Cast(A_arbace_main_A_const_pool.A[261]); A_arbace_main_A_const_175 = A_arbace_main_A_const_pool.A[262]; A_arbace_main_A_const_176 = lang.Var_Cast(A_arbace_main_A_const_pool.A[263]) }

func A_arbace_main_A_clinit_p14() { A_arbace_main_A_const_177 = lang.Var_Cast(A_arbace_main_A_const_pool.A[264]); A_arbace_main_A_const_178 = lang.Var_Cast(A_arbace_main_A_const_pool.A[265]); A_arbace_main_A_const_179 = A_arbace_main_A_const_pool.A[266]; A_arbace_main_A_const_180 = lang.Var_Cast(A_arbace_main_A_const_pool.A[267]); A_arbace_main_A_const_181 = jrt.Class_Cast(A_arbace_main_A_const_pool.A[268]); A_arbace_main_A_const_182 = lang.Var_Cast(A_arbace_main_A_const_pool.A[269]); A_arbace_main_A_const_183 = lang.Var_Cast(A_arbace_main_A_const_pool.A[270]); A_arbace_main_A_const_184 = lang.Var_Cast(A_arbace_main_A_const_pool.A[271]); A_arbace_main_A_const_185 = lang.Var_Cast(A_arbace_main_A_const_pool.A[272]); A_arbace_main_A_const_186 = lang.Var_Cast(A_arbace_main_A_const_pool.A[273]); A_arbace_main_A_const_187 = lang.Var_Cast(A_arbace_main_A_const_pool.A[274]); A_arbace_main_A_const_188 = lang.Var_Cast(A_arbace_main_A_const_pool.A[275]) }

func A_arbace_main_A_clinit_p15() { A_arbace_main_A_const_189 = lang.Var_Cast(A_arbace_main_A_const_pool.A[276]); A_arbace_main_A_const_190 = lang.Var_Cast(A_arbace_main_A_const_pool.A[277]); A_arbace_main_A_const_191 = lang.Var_Cast(A_arbace_main_A_const_pool.A[278]); A_arbace_main_A_const_192 = lang.Var_Cast(A_arbace_main_A_const_pool.A[279]); A_arbace_main_A_const_193 = lang.Var_Cast(A_arbace_main_A_const_pool.A[280]); A_arbace_main_A_const_194 = lang.Var_Cast(A_arbace_main_A_const_pool.A[281]); A_arbace_main_A_const_195 = lang.Var_Cast(A_arbace_main_A_const_pool.A[282]); A_arbace_main_A_const_196 = A_arbace_main_A_const_pool.A[283]; A_arbace_main_A_const_197 = lang.Var_Cast(A_arbace_main_A_const_pool.A[284]); A_arbace_main_A_const_198 = lang.Var_Cast(A_arbace_main_A_const_pool.A[285]); A_arbace_main_A_const_199 = lang.Var_Cast(A_arbace_main_A_const_pool.A[286]); A_arbace_main_A_const_200 = lang.Var_Cast(A_arbace_main_A_const_pool.A[287]) }

func A_arbace_main_A_clinit_p16() { A_arbace_main_A_const_201 = lang.Var_Cast(A_arbace_main_A_const_pool.A[288]); A_arbace_main_A_const_202 = lang.Var_Cast(A_arbace_main_A_const_pool.A[289]); A_arbace_main_A_const_203 = A_arbace_main_A_const_pool.A[290]; A_arbace_main_A_const_204 = lang.Var_Cast(A_arbace_main_A_const_pool.A[291]); A_arbace_main_A_const_205 = lang.Var_Cast(A_arbace_main_A_const_pool.A[292]); A_arbace_main_A_const_206 = lang.Var_Cast(A_arbace_main_A_const_pool.A[293]); A_arbace_main_A_const_207 = A_arbace_main_A_const_pool.A[294]; A_arbace_main_A_const_208 = lang.Var_Cast(A_arbace_main_A_const_pool.A[295]); A_arbace_main_A_const_209 = lang.Var_Cast(A_arbace_main_A_const_pool.A[296]); A_arbace_main_A_const_210 = lang.Var_Cast(A_arbace_main_A_const_pool.A[297]); A_arbace_main_A_const_211 = lang.Var_Cast(A_arbace_main_A_const_pool.A[298]); A_arbace_main_A_const_212 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[299]) }

func A_arbace_main_A_clinit_p17() { A_arbace_main_A_const_213 = lang.Var_Cast(A_arbace_main_A_const_pool.A[300]); A_arbace_main_A_const_214 = A_arbace_main_A_const_pool.A[301]; A_arbace_main_A_const_215 = lang.Var_Cast(A_arbace_main_A_const_pool.A[302]); A_arbace_main_A_const_216 = lang.Var_Cast(A_arbace_main_A_const_pool.A[303]); A_arbace_main_A_const_217 = lang.Var_Cast(A_arbace_main_A_const_pool.A[304]); A_arbace_main_A_const_218 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[305]); A_arbace_main_A_const_219 = lang.Var_Cast(A_arbace_main_A_const_pool.A[306]); A_arbace_main_A_const_220 = lang.Var_Cast(A_arbace_main_A_const_pool.A[307]); A_arbace_main_A_const_221 = lang.Var_Cast(A_arbace_main_A_const_pool.A[308]); A_arbace_main_A_const_222 = lang.Var_Cast(A_arbace_main_A_const_pool.A[309]); A_arbace_main_A_const_223 = lang.Var_Cast(A_arbace_main_A_const_pool.A[310]); A_arbace_main_A_const_224 = lang.Var_Cast(A_arbace_main_A_const_pool.A[311]) }

func A_arbace_main_A_clinit_p18() { A_arbace_main_A_const_225 = lang.Var_Cast(A_arbace_main_A_const_pool.A[312]); A_arbace_main_A_const_226 = lang.Var_Cast(A_arbace_main_A_const_pool.A[313]); A_arbace_main_A_const_227 = A_arbace_main_A_const_pool.A[314]; A_arbace_main_A_const_228 = A_arbace_main_A_const_pool.A[315]; A_arbace_main_A_const_229 = lang.Var_Cast(A_arbace_main_A_const_pool.A[316]); A_arbace_main_A_const_230 = A_arbace_main_A_const_pool.A[317]; A_arbace_main_A_const_231 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[318]); A_arbace_main_A_const_232 = lang.Var_Cast(A_arbace_main_A_const_pool.A[319]); A_arbace_main_A_const_233 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[320]); A_arbace_main_A_const_234 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[321]); A_arbace_main_A_const_235 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[322]); A_arbace_main_A_const_236 = jrt.Class_Cast(A_arbace_main_A_const_pool.A[323]); A_arbace_main_A_const_237 = A_arbace_main_A_const_pool.A[324] }

func A_arbace_main_A_clinit_p19() { A_arbace_main_A_const_238 = lang.Keyword_Cast(A_arbace_main_A_const_pool.A[325]); A_arbace_main_A_const_239 = lang.Var_Cast(A_arbace_main_A_const_pool.A[326]); A_arbace_main_A_const_240 = A_arbace_main_A_const_pool.A[327]; A_arbace_main_A_const_241 = lang.Var_Cast(A_arbace_main_A_const_pool.A[328]) }

func A_arbace_main_A_New() *A_arbace_main_A { A_arbace_main_A_Init(); t := &A_arbace_main_A{}; t.Ctor(); return t }

func (t *A_arbace_main_A) Ctor() {}

func (t *A_arbace_main_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_A) GetClass__Class() *jrt.Class { return A_arbace_main_A_class }

func (t *A_arbace_main_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_main_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_A); return ok }

func A_arbace_main_A_Cast(x any) *A_arbace_main_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_A_class)) }; return v }



type A_arbace_main_core_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_main_core_class_QMARK__A_fn_class *jrt.Class



type A_arbace_main_demunge_A struct{ j2g_header uint64 }

var A_arbace_main_demunge_A_fn_class *jrt.Class



type A_arbace_main_err__GT_msg_A struct{ j2g_header uint64 }

var A_arbace_main_err__GT_msg_A_fn_class *jrt.Class



type A_arbace_main_eval461000004_A struct{ jrt.Object }

func A_arbace_main_eval461000004_A_New() *A_arbace_main_eval461000004_A { t := &A_arbace_main_eval461000004_A{}; t.Ctor(); return t }

func (t *A_arbace_main_eval461000004_A) Ctor() {}

func (t *A_arbace_main_eval461000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_eval461000004_A) GetClass__Class() *jrt.Class { return A_arbace_main_eval461000004_A_class }

func (t *A_arbace_main_eval461000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_eval461000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_main_eval461000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_eval461000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_eval461000004_A); return ok }

func A_arbace_main_eval461000004_A_Cast(x any) *A_arbace_main_eval461000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_eval461000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_eval461000004_A_class)) }; return v }



type A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A struct{ j2g_header uint64 }

var A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_fn_class *jrt.Class



type A_arbace_main_eval461000008_A struct{ jrt.Object }

func A_arbace_main_eval461000008_A_New() *A_arbace_main_eval461000008_A { t := &A_arbace_main_eval461000008_A{}; t.Ctor(); return t }

func (t *A_arbace_main_eval461000008_A) Ctor() {}

func (t *A_arbace_main_eval461000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_eval461000008_A) GetClass__Class() *jrt.Class { return A_arbace_main_eval461000008_A_class }

func (t *A_arbace_main_eval461000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_eval461000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_main_eval461000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_eval461000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_eval461000008_A); return ok }

func A_arbace_main_eval461000008_A_Cast(x any) *A_arbace_main_eval461000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_eval461000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_eval461000008_A_class)) }; return v }



type A_arbace_main_eval461000008_fn__461000009_A struct{ j2g_header uint64 }

var A_arbace_main_eval461000008_fn__461000009_A_fn_class *jrt.Class



type A_arbace_main_eval_opt_A struct{ j2g_header uint64 }

var A_arbace_main_eval_opt_A_fn_class *jrt.Class



type A_arbace_main_eval_opt_fn__461000135_A struct{ j2g_header uint64; F_reader, F_eof any }

var A_arbace_main_eval_opt_fn__461000135_A_fn_class *jrt.Class



type A_arbace_main_eval_opt_fn__461000137_A struct{ j2g_header uint64; F_reader, F_eof any }

var A_arbace_main_eval_opt_fn__461000137_A_fn_class *jrt.Class



type A_arbace_main_ex_str_A struct{ j2g_header uint64 }

var A_arbace_main_ex_str_A_fn_class *jrt.Class



type A_arbace_main_ex_str_fn__461000085_A struct{ j2g_header uint64; F_spec, F_s__1927001093__auto__ any }

var A_arbace_main_ex_str_fn__461000085_A_fn_class *jrt.Class



type A_arbace_main_ex_str_fn__461000085_fn__461000086_A struct{ j2g_header uint64 }

var A_arbace_main_ex_str_fn__461000085_fn__461000086_A_fn_class *jrt.Class



type A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A struct{ j2g_header uint64 }

var A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_fn_class *jrt.Class



type A_arbace_main_ex_str_fn__461000091_A struct{ j2g_header uint64; F_spec, F_s__1927001093__auto__ any }

var A_arbace_main_ex_str_fn__461000091_A_fn_class *jrt.Class



type A_arbace_main_ex_str_fn__461000091_fn__461000092_A struct{ j2g_header uint64 }

var A_arbace_main_ex_str_fn__461000091_fn__461000092_A_fn_class *jrt.Class



type A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A struct{ j2g_header uint64 }

var A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_fn_class *jrt.Class



type A_arbace_main_ex_triage_A struct{ j2g_header uint64 }

var A_arbace_main_ex_triage_A_fn_class *jrt.Class



type A_arbace_main_ex_triage_fn__461000061_A struct{ j2g_header uint64 }

var A_arbace_main_ex_triage_fn__461000061_A_fn_class *jrt.Class



type A_arbace_main_ex_triage_fn__461000063_A struct{ j2g_header uint64 }

var A_arbace_main_ex_triage_fn__461000063_A_fn_class *jrt.Class



type A_arbace_main_file_name_A struct{ j2g_header uint64 }

var A_arbace_main_file_name_A_fn_class *jrt.Class



type A_arbace_main_file_path_A struct{ j2g_header uint64 }

var A_arbace_main_file_path_A_fn_class *jrt.Class



type A_arbace_main_help_opt_A struct{ j2g_header uint64 }

var A_arbace_main_help_opt_A_fn_class *jrt.Class



type A_arbace_main_init_dispatch_A struct{ j2g_header uint64 }

var A_arbace_main_init_dispatch_A_fn_class *jrt.Class



type A_arbace_main_init_opt_A struct{ j2g_header uint64 }

var A_arbace_main_init_opt_A_fn_class *jrt.Class



type A_arbace_main_initialize_A struct{ j2g_header uint64 }

var A_arbace_main_initialize_A_fn_class *jrt.Class



type A_arbace_main_java_loc__GT_source_A struct{ j2g_header uint64 }

var A_arbace_main_java_loc__GT_source_A_fn_class *jrt.Class



type A_arbace_main_java_loc__GT_source_degen__461000039_A struct{ j2g_header uint64 }

var A_arbace_main_java_loc__GT_source_degen__461000039_A_fn_class *jrt.Class



type A_arbace_main_legacy_repl_A struct{ j2g_header uint64 }

var A_arbace_main_legacy_repl_A_fn_class *jrt.Class



type A_arbace_main_legacy_script_A struct{ j2g_header uint64 }

var A_arbace_main_legacy_script_A_fn_class *jrt.Class



type A_arbace_main_load_script_A struct{ j2g_header uint64 }

var A_arbace_main_load_script_A_fn_class *jrt.Class



type A_arbace_main_main_A struct{ j2g_header uint64 }

var A_arbace_main_main_A_fn_class *jrt.Class



type A_arbace_main_main_dispatch_A struct{ j2g_header uint64 }

var A_arbace_main_main_dispatch_A_fn_class *jrt.Class



type A_arbace_main_main_opt_A struct{ j2g_header uint64 }

var A_arbace_main_main_opt_A_fn_class *jrt.Class



type A_arbace_main_null_opt_A struct{ j2g_header uint64 }

var A_arbace_main_null_opt_A_fn_class *jrt.Class



type A_arbace_main_renumbering_read_A struct{ j2g_header uint64 }

var A_arbace_main_renumbering_read_A_fn_class *jrt.Class



type A_arbace_main_repl_A struct{ j2g_header uint64 }

var A_arbace_main_repl_A_fn_class *jrt.Class



type A_arbace_main_repl_default__461000107__461000116_A struct{ j2g_header uint64 }

var A_arbace_main_repl_default__461000107__461000116_A_fn_class *jrt.Class



type A_arbace_main_repl_fn__461000118_A struct{ j2g_header uint64 }

var A_arbace_main_repl_fn__461000118_A_fn_class *jrt.Class



type A_arbace_main_repl_fn__461000120_A struct{ j2g_header uint64 }

var A_arbace_main_repl_fn__461000120_A_fn_class *jrt.Class



type A_arbace_main_repl_fn__461000128_A struct{ j2g_header uint64; F_init, F_caught any }

var A_arbace_main_repl_fn__461000128_A_fn_class *jrt.Class



type A_arbace_main_repl_fn__461000130_A struct{ j2g_header uint64; F_caught, F_request_exit, F_read_eval_print any }

var A_arbace_main_repl_fn__461000130_A_fn_class *jrt.Class



type A_arbace_main_repl_read_eval_print__461000122_A struct{ j2g_header uint64; F_request_prompt, F_read, F_caught, F_eval, F_request_exit, F_print any }

var A_arbace_main_repl_read_eval_print__461000122_A_fn_class *jrt.Class



type A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A struct{ j2g_header uint64; F_request_prompt, F_read, F_request_exit any }

var A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_fn_class *jrt.Class



type A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A struct{ j2g_header uint64; F_input, F_eval any }

var A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_fn_class *jrt.Class



type A_arbace_main_repl_caught_A struct{ j2g_header uint64 }

var A_arbace_main_repl_caught_A_fn_class *jrt.Class



type A_arbace_main_repl_exception_A struct{ j2g_header uint64 }

var A_arbace_main_repl_exception_A_fn_class *jrt.Class



type A_arbace_main_repl_opt_A struct{ j2g_header uint64 }

var A_arbace_main_repl_opt_A_fn_class *jrt.Class



type A_arbace_main_repl_opt_fn__461000163_A struct{ j2g_header uint64 }

var A_arbace_main_repl_opt_fn__461000163_A_fn_class *jrt.Class



type A_arbace_main_repl_opt_fn__461000165_A struct{ j2g_header uint64; F_inits, F_args any }

var A_arbace_main_repl_opt_fn__461000165_A_fn_class *jrt.Class



type A_arbace_main_repl_prompt_A struct{ j2g_header uint64 }

var A_arbace_main_repl_prompt_A_fn_class *jrt.Class



type A_arbace_main_repl_read_A struct{ j2g_header uint64 }

var A_arbace_main_repl_read_A_fn_class *jrt.Class



type A_arbace_main_report_error_A struct{ j2g_header uint64 }

var A_arbace_main_report_error_A_fn_class *jrt.Class



type A_arbace_main_report_error_fn__461000195_A struct{ j2g_header uint64; F_report, F_s__1927001093__auto__ any }

var A_arbace_main_report_error_fn__461000195_A_fn_class *jrt.Class



type A_arbace_main_report_error_fn__461000195_fn__461000196_A struct{ j2g_header uint64; F_report any }

var A_arbace_main_report_error_fn__461000195_fn__461000196_A_fn_class *jrt.Class



type A_arbace_main_report_error_fn__461000199_A struct{ j2g_header uint64; F_report_str any }

var A_arbace_main_report_error_fn__461000199_A_fn_class *jrt.Class



type A_arbace_main_report_error_fn__461000199_fn__461000200_A struct{ j2g_header uint64; F_w, F_report_str any }

var A_arbace_main_report_error_fn__461000199_fn__461000200_A_fn_class *jrt.Class



type A_arbace_main_root_cause_A struct{ j2g_header uint64 }

var A_arbace_main_root_cause_A_fn_class *jrt.Class



type A_arbace_main_script_opt_A struct{ j2g_header uint64 }

var A_arbace_main_script_opt_A_fn_class *jrt.Class



type A_arbace_main_skip_if_eol_A struct{ j2g_header uint64 }

var A_arbace_main_skip_if_eol_A_fn_class *jrt.Class



type A_arbace_main_skip_whitespace_A struct{ j2g_header uint64 }

var A_arbace_main_skip_whitespace_A_fn_class *jrt.Class



type A_arbace_main_stack_element_str_A struct{ j2g_header uint64 }

var A_arbace_main_stack_element_str_A_fn_class *jrt.Class



type A_arbace_main_with_bindings_A struct{ j2g_header uint64 }

var A_arbace_main_with_bindings_A_fn_class *jrt.Class



type A_arbace_main_with_read_known_A struct{ j2g_header uint64 }

var A_arbace_main_with_read_known_A_fn_class *jrt.Class
