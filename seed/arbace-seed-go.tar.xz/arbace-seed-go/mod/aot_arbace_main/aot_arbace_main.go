//line aot_arbace_main.ae:1
package aot_arbace_main

import (
	"arbace/jrt"
	"arbace/lang"
)




func A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_New() *A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A { A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_Init(); t := &A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A) Ctor() {}
//line :11:1
func (t *A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp24 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_2; var tmp7 any = tmp6; var tmp8 *lang.Keyword; A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_3; var tmp9 any = tmp8.Ref(); var tmp10 any; A_arbace_main_A_Init(); tmp10 = A_arbace_main_A_const_4; tmp5.Invoke_O_O_O__O(tmp7, tmp9, tmp10); var tmp11 *lang.Var; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_1; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; A_arbace_main_A_Init(); tmp13 = A_arbace_main_A_const_5; tmp12.Invoke_O__O(tmp13); var tmp14 *lang.Var; lang.RT_Init(); tmp14 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp14).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_201)); var tmp15 *lang.Var; lang.RT_Init(); tmp15 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp15).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_202)); var tmp16 *lang.Var; lang.RT_Init(); tmp16 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp16).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_203)); var tmp17 *lang.Var; lang.RT_Init(); tmp17 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp17).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_204)); var tmp18 *lang.Var; lang.RT_Init(); tmp18 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp18).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_191)); var tmp19 *lang.Var; lang.RT_Init(); tmp19 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp19).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_205)); var tmp20 *lang.Var; lang.RT_Init(); tmp20 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp20).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_206)); var tmp21 *lang.Var; lang.RT_Init(); tmp21 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp21).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_207)); var tmp22 *lang.Var; lang.RT_Init(); tmp22 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp22).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_208)); var tmp23 *lang.Var; lang.RT_Init(); tmp23 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp23).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_209)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp24 != nil { panic(tmp24) }; return tmp3 }
//line :11:1
func A_arbace_main_eval461000008_fn__461000009_A_New() *A_arbace_main_eval461000008_fn__461000009_A { A_arbace_main_eval461000008_fn__461000009_A_Init(); t := &A_arbace_main_eval461000008_fn__461000009_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_main_eval461000008_fn__461000009_A) Ctor() {}
//line :11:1
func (t *A_arbace_main_eval461000008_fn__461000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_7; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_10; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_8; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_9; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }
















func A_arbace_main_demunge_A_New() *A_arbace_main_demunge_A { A_arbace_main_demunge_A_Init(); t := &A_arbace_main_demunge_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_main_demunge_A) Ctor() {}
//line :28:1
func (t *A_arbace_main_demunge_A) Invoke_O_O__O(self, fn_name__0 any) any {




	return lang.Compiler_Demunge_String__String(jrt.String_Cast(fn_name__0)).Ref()
}
func A_arbace_main_root_cause_A_New() *A_arbace_main_root_cause_A { A_arbace_main_root_cause_A_Init(); t := &A_arbace_main_root_cause_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_main_root_cause_A) Ctor() {}
//line :35:1
func (t *A_arbace_main_root_cause_A) Invoke_O_O__O(self, t__0 any) any { { var cause__2 any = t__0; L1: for {





	var tmp1 any; var and__1927000168__auto____3 bool = lang.Compiler_CompilerException_InstanceOf(cause__2); if and__1927000168__auto____3 {
		var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_11; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_CompilerException_Cast(cause__2).F_source.Ref(), Lit_99) } else {
//line :41:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if jrt.A2g_Truth(tmp1) { return cause__2 } else { var temp__1927000408__auto____3 any = jrt.Throwable_Cast(cause__2).GetCause__Throwable()


				if jrt.A2g_Truth(temp__1927000408__auto____3) { var cause__4 any = temp__1927000408__auto____3
					cause__2 = cause__4; continue L1 } else {
//line :44:1
						return cause__2 } } } }; /*line :35:1*/panic("a2g: unreachable") }




















func A_arbace_main_core_class_QMARK__A_New() *A_arbace_main_core_class_QMARK__A { A_arbace_main_core_class_QMARK__A_Init(); t := &A_arbace_main_core_class_QMARK__A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_main_core_class_QMARK__A) Ctor() {}
//line :56:1
func (t *A_arbace_main_core_class_QMARK__A) Invoke_O_O__O(self, class_name__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var;

	A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_12; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(class_name__0, nil)).Ref()); if jrt.A2g_Truth(and__1927000168__auto____2) { var or__1927000174__auto____3 bool = jrt.NN(jrt.String_Cast(class_name__0)).StartsWith_String__Z(Lit_197)
		if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else {
			var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_13; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_14; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 *lang.Var; A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_15; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_16; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; A_arbace_main_A_Init(); tmp10 = A_arbace_main_A_const_17; return tmp3.Invoke_O_O__O(tmp5, tmp7.Invoke_O__O(tmp9.Invoke_O_O__O(tmp10, class_name__0))) } } else {
//line :58:1
				return and__1927000168__auto____2 } }



func A_arbace_main_stack_element_str_A_New() *A_arbace_main_stack_element_str_A { A_arbace_main_stack_element_str_A_Init(); t := &A_arbace_main_stack_element_str_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_main_stack_element_str_A) Ctor() {}
//line :62:1
func (t *A_arbace_main_stack_element_str_A) Invoke_O_O__O(self, el__0 any) any { var file__2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetFileName__String().Ref(); var clojure_fn_QMARK___3 any; var and__1927000168__auto____3 any = file__2; if




	jrt.A2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_317); if or__1927000174__auto____4 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_318); if or__1927000174__auto____5 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = jrt.NN(jrt.String_Cast(file__2)).EndsWith_String__Z(Lit_319); if or__1927000174__auto____6 { clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____6).Ref() } else {


		clojure_fn_QMARK___3 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(file__2, Lit_99)).Ref() } } } } else {
//line :67:1
			clojure_fn_QMARK___3 = and__1927000168__auto____3 }; var tmp1 /*line :71:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_218, nil, Lit_215, nil, Lit_219); var tmp2 any; if jrt.A2g_Truth(clojure_fn_QMARK___3) {
				var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_18; tmp2 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetClassName__String().Ref()) } else {
					tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_320, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetClassName__String().Ref(), nil, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetMethodName__String().Ref())).Ref() }; return /*line :71:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetFileName__String().Ref(), nil, jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.As[*jrt.StackTraceElement](el__0)).GetLineNumber__I()).Ref(), nil)).Ref() }





func A_arbace_main_with_bindings_A_New() *A_arbace_main_with_bindings_A { A_arbace_main_with_bindings_A_Init(); t := &A_arbace_main_with_bindings_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_main_with_bindings_A) Ctor() {}
//line :77:1
func (t *A_arbace_main_with_bindings_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_19; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_20; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_21; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_22; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_21; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_23; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_main_A_Init(); tmp13 = A_arbace_main_A_const_24; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_main_A_Init(); tmp15 = A_arbace_main_A_const_19; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_main_A_Init(); tmp17 = A_arbace_main_A_const_20; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_main_A_Init(); tmp19 = A_arbace_main_A_const_21; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_main_A_Init(); tmp21 = A_arbace_main_A_const_25; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_main_A_Init(); tmp23 = A_arbace_main_A_const_21; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any; A_arbace_main_A_Init(); tmp25 = A_arbace_main_A_const_26; var tmp26 any = tmp24.Invoke_O__O(tmp25); var tmp27 *lang.Var; A_arbace_main_A_Init(); tmp27 = A_arbace_main_A_const_21; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_main_A_Init(); tmp29 = A_arbace_main_A_const_27; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 *lang.Var; A_arbace_main_A_Init(); tmp31 = A_arbace_main_A_const_21; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 any; A_arbace_main_A_Init(); tmp33 = A_arbace_main_A_const_28; var tmp34 any = tmp32.Invoke_O__O(tmp33); var tmp35 *lang.Var; A_arbace_main_A_Init(); tmp35 = A_arbace_main_A_const_21; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any; A_arbace_main_A_Init(); tmp37 = A_arbace_main_A_const_29; var tmp38 any = tmp36.Invoke_O__O(tmp37); var tmp39 *lang.Var; A_arbace_main_A_Init(); tmp39 = A_arbace_main_A_const_21; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 any; A_arbace_main_A_Init(); tmp41 = A_arbace_main_A_const_30; var tmp42 any = tmp40.Invoke_O__O(tmp41); var tmp43 *lang.Var; A_arbace_main_A_Init(); tmp43 = A_arbace_main_A_const_21; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 any; A_arbace_main_A_Init(); tmp45 = A_arbace_main_A_const_31; var tmp46 any = tmp44.Invoke_O__O(tmp45); var tmp47 *lang.Var; A_arbace_main_A_Init(); tmp47 = A_arbace_main_A_const_21; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 any; A_arbace_main_A_Init(); tmp49 = A_arbace_main_A_const_32; var tmp50 any = tmp48.Invoke_O__O(tmp49); var tmp51 *lang.Var; A_arbace_main_A_Init(); tmp51 = A_arbace_main_A_const_21; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 any; A_arbace_main_A_Init(); tmp53 = A_arbace_main_A_const_33; var tmp54 any = tmp52.Invoke_O__O(tmp53); var tmp55 *lang.Var; A_arbace_main_A_Init(); tmp55 = A_arbace_main_A_const_21; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 any; A_arbace_main_A_Init(); tmp57 = A_arbace_main_A_const_34; var tmp58 any = tmp56.Invoke_O__O(tmp57); var tmp59 *lang.Var; A_arbace_main_A_Init(); tmp59 = A_arbace_main_A_const_21; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 any; A_arbace_main_A_Init(); tmp61 = A_arbace_main_A_const_35; var tmp62 any = tmp60.Invoke_O__O(tmp61); var tmp63 *lang.Var; A_arbace_main_A_Init(); tmp63 = A_arbace_main_A_const_21; var tmp64 lang.IFn = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()); var tmp65 any; A_arbace_main_A_Init(); tmp65 = A_arbace_main_A_const_36; var tmp66 any = tmp64.Invoke_O__O(tmp65); var tmp67 *lang.Var; A_arbace_main_A_Init(); tmp67 = A_arbace_main_A_const_21; var tmp68 lang.IFn = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()); var tmp69 any; A_arbace_main_A_Init(); tmp69 = A_arbace_main_A_const_37; var tmp70 any = tmp68.Invoke_O__O(tmp69); var tmp71 *lang.Var; A_arbace_main_A_Init(); tmp71 = A_arbace_main_A_const_21; var tmp72 lang.IFn = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()); var tmp73 *jrt.Boolean; jrt.Boolean_Init(); tmp73 = jrt.Boolean_TRUE; var tmp74 any = tmp72.Invoke_O__O(tmp73.Ref()); var tmp75 *lang.Var; A_arbace_main_A_Init(); tmp75 = A_arbace_main_A_const_21; var tmp76 lang.IFn = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()); var tmp77 any; A_arbace_main_A_Init(); tmp77 = A_arbace_main_A_const_38; var tmp78 any = tmp76.Invoke_O__O(tmp77); var tmp79 *lang.Var; A_arbace_main_A_Init(); tmp79 = A_arbace_main_A_const_21; var tmp80 lang.IFn = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()); var tmp81 any; A_arbace_main_A_Init(); tmp81 = A_arbace_main_A_const_39; var tmp82 any = tmp80.Invoke_O__O(tmp81); var tmp83 *lang.Var; A_arbace_main_A_Init(); tmp83 = A_arbace_main_A_const_21; var tmp84 lang.IFn = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()); var tmp85 any; A_arbace_main_A_Init(); tmp85 = A_arbace_main_A_const_40; var tmp86 any = tmp84.Invoke_O__O(tmp85); var tmp87 *lang.Var; A_arbace_main_A_Init(); tmp87 = A_arbace_main_A_const_21; var tmp88 lang.IFn = lang.IFn_Cast(jrt.NN(tmp87).GetRawRoot__O()); var tmp89 any; A_arbace_main_A_Init(); tmp89 = A_arbace_main_A_const_41; var tmp90 any = tmp88.Invoke_O__O(tmp89); var tmp91 *lang.Var; A_arbace_main_A_Init(); tmp91 = A_arbace_main_A_const_21; var tmp92 lang.IFn = lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()); var tmp93 any; A_arbace_main_A_Init(); tmp93 = A_arbace_main_A_const_42; var tmp94 any = tmp92.Invoke_O__O(tmp93); var tmp95 *lang.Var; A_arbace_main_A_Init(); tmp95 = A_arbace_main_A_const_21; var tmp96 lang.IFn = lang.IFn_Cast(jrt.NN(tmp95).GetRawRoot__O()); var tmp97 *lang.Var; A_arbace_main_A_Init(); tmp97 = A_arbace_main_A_const_19; var tmp98 lang.IFn = lang.IFn_Cast(jrt.NN(tmp97).GetRawRoot__O()); var tmp99 *lang.Var; A_arbace_main_A_Init(); tmp99 = A_arbace_main_A_const_20; var tmp100 lang.IFn = lang.IFn_Cast(jrt.NN(tmp99).GetRawRoot__O()); var tmp101 *lang.Var; A_arbace_main_A_Init(); tmp101 = A_arbace_main_A_const_21; var tmp102 lang.IFn = lang.IFn_Cast(jrt.NN(tmp101).GetRawRoot__O()); var tmp103 any; A_arbace_main_A_Init(); tmp103 = A_arbace_main_A_const_43; var tmp104 any = tmp102.Invoke_O__O(tmp103); var tmp105 *lang.Var; A_arbace_main_A_Init(); tmp105 = A_arbace_main_A_const_21; var tmp106 any = lang.IFn_Cast(jrt.NN(tmp105).GetRawRoot__O()).Invoke_O__O(Lit_276); var tmp107 *lang.Var; A_arbace_main_A_Init(); tmp107 = A_arbace_main_A_const_21; var tmp108 any = tmp96.Invoke_O__O(tmp98.Invoke_O__O(tmp100.Invoke_O_O_O__O(tmp104, tmp106, lang.IFn_Cast(jrt.NN(tmp107).GetRawRoot__O()).Invoke_O__O(Lit_277)))); var tmp109 *lang.Var; A_arbace_main_A_Init(); tmp109 = A_arbace_main_A_const_21; var tmp110 lang.IFn = lang.IFn_Cast(jrt.NN(tmp109).GetRawRoot__O()); var tmp111 any; A_arbace_main_A_Init(); tmp111 = A_arbace_main_A_const_44; var tmp112 any = tmp110.Invoke_O__O(tmp111); var tmp113 *lang.Var; A_arbace_main_A_Init(); tmp113 = A_arbace_main_A_const_21; var tmp114 lang.IFn = lang.IFn_Cast(jrt.NN(tmp113).GetRawRoot__O()); var tmp115 any; A_arbace_main_A_Init(); tmp115 = A_arbace_main_A_const_45; var tmp116 any = tmp114.Invoke_O__O(tmp115); var tmp117 *lang.Var; A_arbace_main_A_Init(); tmp117 = A_arbace_main_A_const_21; var tmp118 lang.IFn = lang.IFn_Cast(jrt.NN(tmp117).GetRawRoot__O()); var tmp119 any; A_arbace_main_A_Init(); tmp119 = A_arbace_main_A_const_46; var tmp120 any = tmp118.Invoke_O__O(tmp119); var tmp121 *lang.Var; A_arbace_main_A_Init(); tmp121 = A_arbace_main_A_const_21; var tmp122 lang.IFn = lang.IFn_Cast(jrt.NN(tmp121).GetRawRoot__O()); var tmp123 any; A_arbace_main_A_Init(); tmp123 = A_arbace_main_A_const_47; var tmp124 any = tmp122.Invoke_O__O(tmp123); var tmp125 *lang.Var; A_arbace_main_A_Init(); tmp125 = A_arbace_main_A_const_21; var tmp126 lang.IFn = lang.IFn_Cast(jrt.NN(tmp125).GetRawRoot__O()); var tmp127 any; A_arbace_main_A_Init(); tmp127 = A_arbace_main_A_const_48; var tmp128 any = tmp126.Invoke_O__O(tmp127); var tmp129 *lang.Var; A_arbace_main_A_Init(); tmp129 = A_arbace_main_A_const_21; var tmp130 lang.IFn = lang.IFn_Cast(jrt.NN(tmp129).GetRawRoot__O()); var tmp131 any; A_arbace_main_A_Init(); tmp131 = A_arbace_main_A_const_49; var tmp132 any = tmp130.Invoke_O__O(tmp131); var tmp133 *lang.Var; A_arbace_main_A_Init(); tmp133 = A_arbace_main_A_const_21; var tmp134 lang.IFn = lang.IFn_Cast(jrt.NN(tmp133).GetRawRoot__O()); var tmp135 any; A_arbace_main_A_Init(); tmp135 = A_arbace_main_A_const_50; var tmp136 any = tmp134.Invoke_O__O(tmp135); var tmp137 *lang.Var; A_arbace_main_A_Init(); tmp137 = A_arbace_main_A_const_21; var tmp138 lang.IFn = lang.IFn_Cast(jrt.NN(tmp137).GetRawRoot__O()); var tmp139 any; A_arbace_main_A_Init(); tmp139 = A_arbace_main_A_const_51; var tmp140 any = tmp138.Invoke_O__O(tmp139); var tmp141 *lang.Var; A_arbace_main_A_Init(); tmp141 = A_arbace_main_A_const_21; var tmp142 lang.IFn = lang.IFn_Cast(jrt.NN(tmp141).GetRawRoot__O()); var tmp143 any; A_arbace_main_A_Init(); tmp143 = A_arbace_main_A_const_52; var tmp144 any = tmp142.Invoke_O__O(tmp143); var tmp145 *lang.Var; A_arbace_main_A_Init(); tmp145 = A_arbace_main_A_const_21; var tmp146 any = lang.IFn_Cast(jrt.NN(tmp145).GetRawRoot__O()).Invoke_O__O(nil); var tmp147 *lang.Var; A_arbace_main_A_Init(); tmp147 = A_arbace_main_A_const_21; var tmp148 lang.IFn = lang.IFn_Cast(jrt.NN(tmp147).GetRawRoot__O()); var tmp149 any; A_arbace_main_A_Init(); tmp149 = A_arbace_main_A_const_53; var tmp150 any = tmp148.Invoke_O__O(tmp149); var tmp151 *lang.Var; A_arbace_main_A_Init(); tmp151 = A_arbace_main_A_const_21; var tmp152 any = lang.IFn_Cast(jrt.NN(tmp151).GetRawRoot__O()).Invoke_O__O(nil); var tmp153 *lang.Var; A_arbace_main_A_Init(); tmp153 = A_arbace_main_A_const_21; var tmp154 lang.IFn = lang.IFn_Cast(jrt.NN(tmp153).GetRawRoot__O()); var tmp155 any; A_arbace_main_A_Init(); tmp155 = A_arbace_main_A_const_54; var tmp156 any = tmp154.Invoke_O__O(tmp155); var tmp157 *lang.Var; A_arbace_main_A_Init(); tmp157 = A_arbace_main_A_const_21; var tmp158 any = lang.IFn_Cast(jrt.NN(tmp157).GetRawRoot__O()).Invoke_O__O(nil); var tmp159 *lang.Var; A_arbace_main_A_Init(); tmp159 = A_arbace_main_A_const_21; var tmp160 lang.IFn = lang.IFn_Cast(jrt.NN(tmp159).GetRawRoot__O()); var tmp161 any; A_arbace_main_A_Init(); tmp161 = A_arbace_main_A_const_55; var tmp162 any = tmp160.Invoke_O__O(tmp161); var tmp163 *lang.Var; A_arbace_main_A_Init(); tmp163 = A_arbace_main_A_const_21; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(tmp18.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp26, tmp30, tmp34, tmp38, tmp42, tmp46, tmp50, tmp54, tmp58, tmp62, tmp66, tmp70, tmp74, tmp78, tmp82, tmp86, tmp90, tmp94, tmp108, tmp112, tmp116, tmp120, tmp124, tmp128, tmp132, tmp136, tmp140, tmp144, tmp146, tmp150, tmp152, tmp156, tmp158, tmp162, lang.IFn_Cast(jrt.NN(tmp163).GetRawRoot__O()).Invoke_O__O(nil)))))))), body__2)) }

























func A_arbace_main_repl_prompt_A_New() *A_arbace_main_repl_prompt_A { A_arbace_main_repl_prompt_A_Init(); t := &A_arbace_main_repl_prompt_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_main_repl_prompt_A) Ctor() {}
//line :103:1
func (t *A_arbace_main_repl_prompt_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_56; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_57; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_58; return tmp2.Invoke_O_O__O(Lit_298, tmp4.Invoke_O__O(jrt.NN(tmp5).Get__O()))
}
func A_arbace_main_skip_if_eol_A_New() *A_arbace_main_skip_if_eol_A { A_arbace_main_skip_if_eol_A_Init(); t := &A_arbace_main_skip_if_eol_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_main_skip_if_eol_A) Ctor() {}
//line :108:1
func (t *A_arbace_main_skip_if_eol_A) Invoke_O_O__O(self, s__0 any) any { var c__2 any = lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(s__0, Lit_63, false); var tmp1 any;








	A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_59; if lang.Util_Equiv_O_J__Z(c__2, int64(lang.RT_IntCast_O__I(tmp1))) { A_arbace_main_A_Init(); return A_arbace_main_A_const_60.Ref() } else { if lang.Util_Equiv_O_J__Z(c__2, -1) { A_arbace_main_A_Init(); return A_arbace_main_A_const_61.Ref() } else { var tmp2 *lang.Keyword; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_62; if tmp2 != nil {


		lang.Reflector_InvokeInstanceMethod_O_String_O1__O(s__0, Lit_313, jrt.RefArrayOf(jrt.Object_class, c__2))
//line :117:1
		A_arbace_main_A_Init(); return A_arbace_main_A_const_63.Ref() } else { return nil } } } }




func A_arbace_main_skip_whitespace_A_New() *A_arbace_main_skip_whitespace_A { A_arbace_main_skip_whitespace_A_Init(); t := &A_arbace_main_skip_whitespace_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_main_skip_whitespace_A) Ctor() {}
//line :122:1
func (t *A_arbace_main_skip_whitespace_A) Invoke_O_O__O(self, s__0 any) any { { var c__2 any = lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(s__0, Lit_63, false); L1: for {










	var tmp1 any; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_59; if lang.Util_Equiv_O_J__Z(c__2, int64(lang.RT_IntCast_O__I(tmp1))) { A_arbace_main_A_Init(); return A_arbace_main_A_const_60.Ref() } else { if lang.Util_Equiv_O_J__Z(c__2, -1) { A_arbace_main_A_Init(); return A_arbace_main_A_const_61.Ref() } else { var tmp2 any; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_64; if lang.Util_Equiv_O_J__Z(c__2, int64(lang.RT_IntCast_O__I(tmp2))) {


		lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(s__0, Lit_315, false)
//line :133:1
		A_arbace_main_A_Init(); return A_arbace_main_A_const_60.Ref() } else { var tmp3 bool; var or__1927000174__auto____3 bool = jrt.Character_IsWhitespace_C__Z(lang.RT_CharCast_O__C(c__2))



			if or__1927000174__auto____3 { tmp3 = or__1927000174__auto____3 } else { var tmp4 any; A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_65; tmp3 = lang.Util_Equiv_O_J__Z(c__2, int64(lang.RT_IntCast_O__I(tmp4))) }
//line :133:1
			if tmp3 {



				c__2 = lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(s__0, Lit_63, false); continue L1 } else {
//line :133:1
					var tmp5 *lang.Keyword; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_62; if tmp5 != nil {




						lang.Reflector_InvokeInstanceMethod_O_String_O1__O(s__0, Lit_313, jrt.RefArrayOf(jrt.Object_class, c__2))
//line :133:1
						A_arbace_main_A_Init(); return A_arbace_main_A_const_63.Ref() } else { return nil } } } } } } }; /*line :122:1*/panic("a2g: unreachable") }

















func A_arbace_main_renumbering_read_A_New() *A_arbace_main_renumbering_read_A { A_arbace_main_renumbering_read_A_Init(); t := &A_arbace_main_renumbering_read_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_main_renumbering_read_A) Ctor() {}
//line :140:1
func (t *A_arbace_main_renumbering_read_A) Invoke_O_O_O_O__O(self, opts__0, reader__1, line_number__2 any) any { var pre_line__4 int32 = jrt.NN(lang.LineNumberingPushbackReader_Cast(reader__1)).GetLineNumber__I(); var vec__461000024__5 any; var tmp1 *lang.Var;







	A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_66; vec__461000024__5 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(opts__0, reader__1); var pre_read__6 any = /*line :140:1*/lang.RT_Nth_O_I_O__O(vec__461000024__5, lang.RT_IntCast_J__I(0), nil); var s__7 any = lang.RT_Nth_O_I_O__O(vec__461000024__5, lang.RT_IntCast_J__I(1), nil); var map__461000027__8 any = lang.RT_Meta_O__IPersistentMap(pre_read__6); var map__461000027__9 any; if






	lang.ISeq_InstanceOf(map__461000027__8) { var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_67; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__461000027__8)) { var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_68; map__461000027__9 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__461000027__8), jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 *lang.Var; A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__461000027__8)) { var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_69; map__461000027__9 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__461000027__8) } else { lang.PersistentArrayMap_Init(); map__461000027__9 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000027__9 = map__461000027__8 }; var eval_file__10 any; var tmp6 /*line :140:1*/*lang.Keyword;






	A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_70; eval_file__10 = lang.RT_Get_O_O__O(map__461000027__9, tmp6.Ref()); var line__11 any; var tmp7 /*line :140:1*/*lang.Keyword;






	A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_71; line__11 = lang.RT_Get_O_O__O(map__461000027__9, tmp7.Ref()); var re_reader__12 any; var G__461000029__12_ any = /*line :140:1*/lang.LineNumberingPushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(s__7))); var tmp8 *lang.LineNumberingPushbackReader = lang.LineNumberingPushbackReader_Cast(G__461000029__12_); var tmp9 any; var tmp10 any; var and__1927000168__auto____13 any = line__11; if










	jrt.A2g_Truth(and__1927000168__auto____13) { var or__1927000174__auto____14 any = eval_file__10; if jrt.A2g_Truth(or__1927000174__auto____14) { tmp10 = or__1927000174__auto____14 } else { var tmp11 *lang.Var; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_11; tmp10 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(pre_line__4).Ref(), line__11) } } else { tmp10 = and__1927000168__auto____13 }; if jrt.A2g_Truth(tmp10) { tmp9 = line__11 } else { tmp9 = line_number__2 }; jrt.NN(tmp8).SetLineNumber_I__V(lang.RT_IntCast_O__I(tmp9)); re_reader__12 = G__461000029__12_; var tmp12 /*line :152:1*/*lang.Var; A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_72; return lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(opts__0, re_reader__12) }

func A_arbace_main_repl_read_A_New() *A_arbace_main_repl_read_A { A_arbace_main_repl_read_A_Init(); t := &A_arbace_main_repl_read_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_main_repl_read_A) Ctor() {}
//line :154:1
func (t *A_arbace_main_repl_read_A) Invoke_O_O_O__O(self, request_prompt__0, request_exit__1 any) any { var or__1927000174__auto____3 any; var tmp1 *lang.Keyword;











	A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_60; var tmp2 any = tmp1.Ref(); var tmp3 *lang.Keyword; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_61; var tmp4 lang.IFn = lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, request_prompt__0, tmp3.Ref(), request_exit__1))); var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_74; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_75; or__1927000174__auto____3 = tmp4.Invoke_O__O(tmp6.Invoke_O__O(jrt.NN(tmp7).Get__O())); if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var input__4 any; var tmp8 *lang.Var

		A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_73; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; A_arbace_main_A_Init(); tmp10 = A_arbace_main_A_const_76; var tmp11 any = tmp10; var tmp12 *lang.Var; A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_75; var tmp13 any = jrt.NN(tmp12).Get__O(); var tmp14 any; A_arbace_main_A_Init(); tmp14 = A_arbace_main_A_const_77; input__4 = tmp9.Invoke_O_O_O__O(tmp11, tmp13, tmp14)
		var tmp15 *lang.Var; A_arbace_main_A_Init(); tmp15 = A_arbace_main_A_const_78; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_main_A_Init(); tmp17 = A_arbace_main_A_const_75; tmp16.Invoke_O__O(jrt.NN(tmp17).Get__O())
//line :166:1
		return input__4 } }





func A_arbace_main_repl_exception_A_New() *A_arbace_main_repl_exception_A { A_arbace_main_repl_exception_A_Init(); t := &A_arbace_main_repl_exception_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_main_repl_exception_A) Ctor() {}
//line :172:1
func (t *A_arbace_main_repl_exception_A) Invoke_O_O__O(self, throwable__0 any) any {


	var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_79; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(throwable__0)
}
func A_arbace_main_file_name_A_New() *A_arbace_main_file_name_A { A_arbace_main_file_name_A_Init(); t := &A_arbace_main_file_name_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_main_file_name_A) Ctor() {}
//line :177:1
func (t *A_arbace_main_file_name_A) Invoke_O_O__O(self, full_path__0 any) any {


	if jrt.A2g_Truth(full_path__0) { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		tmp1 = jrt.File_New_String(jrt.String_Cast(full_path__0)).GetName__String().Ref()
//line :180:1
		return nil }(); if tmp2 != nil { if true { var t__4 jrt.Throwable_I = tmp2; _ = t__4; tmp1 = nil } }; return tmp1 } else { return nil
		}
}


func A_arbace_main_file_path_A_New() *A_arbace_main_file_path_A { A_arbace_main_file_path_A_Init(); t := &A_arbace_main_file_path_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_main_file_path_A) Ctor() {}
//line :185:1
func (t *A_arbace_main_file_path_A) Invoke_O_O__O(self, full_path__0 any) any {


	if jrt.A2g_Truth(full_path__0) { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var path__4 any = jrt.File_New_String(jrt.String_Cast(full_path__0)).GetPath__String().Ref(); var cd_path__5 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_243), jrt.RefArrayOf(jrt.Object_class, jrt.File_New_String(Lit_217).GetAbsolutePath__String().Ref(), nil)).Ref()



		if jrt.NN(jrt.String_Cast(path__4)).StartsWith_String__Z(jrt.String_Cast(cd_path__5)) {
			var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_80; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(path__4, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(cd_path__5)).Ref()) } else {
//line :192:1
				tmp1 = path__4 } }; return nil }()
//line :188:1
		if tmp3 != nil { if true { var t__4 jrt.Throwable_I = tmp3; _ = t__4; tmp1 = full_path__0 } }; return tmp1 } else { return nil
		}
}







func A_arbace_main_java_loc__GT_source_A_New() *A_arbace_main_java_loc__GT_source_A { A_arbace_main_java_loc__GT_source_A_Init(); t := &A_arbace_main_java_loc__GT_source_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_main_java_loc__GT_source_A) Ctor() {}
//line :198:1
func (t *A_arbace_main_java_loc__GT_source_A) Invoke_O_O_O__O(self, clazz__0, method__1 any) any {



	var tmp1 any; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_81; if jrt.A2g_Truth(lang.IFn_Cast(tmp1).Invoke_O__O(method__1)) { var degen__3 any; var tmp2 any = A_arbace_main_java_loc__GT_source_degen__461000039_A_New(); var tmp3 *jrt.Class
		A_arbace_main_java_loc__GT_source_degen__461000039_A_Init(); tmp3 = A_arbace_main_java_loc__GT_source_degen__461000039_A_fn_class; degen__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :202:1
		var vec__461000036__4 any; var tmp4 *lang.Var

		A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_83; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_83; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_18; var tmp9 any = jrt.NN(tmp8).GetRawRoot__O(); var tmp10 any; A_arbace_main_A_Init(); tmp10 = A_arbace_main_A_const_85; var tmp11 *jrt.Pattern = jrt.Pattern_Cast(tmp10); var tmp12 *lang.Var; A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_86; vec__461000036__4 = tmp5.Invoke_O_O__O(degen__3, tmp7.Invoke_O_O__O(tmp9, jrt.NN(tmp11).Split_CharSequence__String1(jrt.CharSequence_Cast(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(clazz__0))).Ref()))
//line :202:1
		var seq__461000037__5 any; var tmp13 *lang.Var
		A_arbace_main_A_Init(); tmp13 = A_arbace_main_A_const_19; seq__461000037__5 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(vec__461000036__4)
//line :202:1
		var first__461000038__6 any; var tmp14 *lang.Var
		A_arbace_main_A_Init(); tmp14 = A_arbace_main_A_const_69; first__461000038__6 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(seq__461000037__5)
//line :202:1
		var seq__461000037__7 any; var tmp15 *lang.Var
		A_arbace_main_A_Init(); tmp15 = A_arbace_main_A_const_67; seq__461000037__7 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(seq__461000037__5)
//line :202:1
		var ns_name__8 any = first__461000038__6; var first__461000038__9 any; var tmp16 *lang.Var
		A_arbace_main_A_Init(); tmp16 = A_arbace_main_A_const_69; first__461000038__9 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(seq__461000037__7)
//line :202:1
		var seq__461000037__10 any; var tmp17 *lang.Var
		A_arbace_main_A_Init(); tmp17 = A_arbace_main_A_const_67; seq__461000037__10 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(seq__461000037__7)
//line :202:1
		var fn_name__11 any = first__461000038__9; var nested__12 any = seq__461000037__10; var tmp18 *lang.Var


		A_arbace_main_A_Init(); tmp18 = A_arbace_main_A_const_84; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 jrt.CharSequence = Lit_253; var tmp21 *lang.Var; A_arbace_main_A_Init(); tmp21 = A_arbace_main_A_const_87; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *jrt.Class; A_arbace_main_A_Init(); tmp23 = A_arbace_main_A_const_82; var tmp24 any = tmp23.Ref(); var tmp25 *lang.Var; A_arbace_main_A_Init(); tmp25 = A_arbace_main_A_const_88; return tmp19.Invoke_O_O__O(ns_name__8, jrt.String_Join_CharSequence_CharSequence1__String(tmp20, jrt.A2g_CastArray[*jrt.RefArray](tmp22.Invoke_O_O__O(tmp24, lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O_O__O(fn_name__11, nested__12)), jrt.CharSequence_class.ArrayClass())).Ref()) } else {
			var tmp26 *lang.Var; A_arbace_main_A_Init(); tmp26 = A_arbace_main_A_const_84; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_main_A_Init(); tmp28 = A_arbace_main_A_const_89; var tmp29 any = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(clazz__0); var tmp30 *lang.Var; A_arbace_main_A_Init(); tmp30 = A_arbace_main_A_const_89; return tmp27.Invoke_O_O__O(tmp29, lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(method__1)) } }
//line :203:1
func A_arbace_main_java_loc__GT_source_degen__461000039_A_New() *A_arbace_main_java_loc__GT_source_degen__461000039_A { A_arbace_main_java_loc__GT_source_degen__461000039_A_Init(); t := &A_arbace_main_java_loc__GT_source_degen__461000039_A{}; t.Ctor(); return t }
//line :203:1
func (t *A_arbace_main_java_loc__GT_source_degen__461000039_A) Ctor() {}
//line :203:1
func (t *A_arbace_main_java_loc__GT_source_degen__461000039_A) Invoke_O_O__O(self, p1__461000035_SHARP___1 any) any { var tmp1 *jrt.Class; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_82; var tmp2 *jrt.Class = tmp1; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p1__461000035_SHARP___1, tmp2, Lit_255, jrt.RefArrayOf(jrt.Object_class, Lit_256, Lit_217)) }




func A_arbace_main_ex_triage_A_New() *A_arbace_main_ex_triage_A { A_arbace_main_ex_triage_A_Init(); t := &A_arbace_main_ex_triage_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_main_ex_triage_A) Ctor() {}
//line :208:1
func (t *A_arbace_main_ex_triage_A) Invoke_O_O__O(self, datafied_throwable__0 any) any { var default__461000046__2 any; A_arbace_main_A_Init(); default__461000046__2 = A_arbace_main_A_const_90.Ref(); var map__461000044__3 any = datafied_throwable__0; var map__461000044__4 any; if
















	lang.ISeq_InstanceOf(map__461000044__3) { var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_67; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__461000044__3)) { var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_68; map__461000044__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__461000044__3), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__461000044__3)) { var tmp4 *lang.Var; A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_69; map__461000044__4 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__461000044__3) } else { lang.PersistentArrayMap_Init(); map__461000044__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000044__4 = map__461000044__3 }; var via__5 any; var tmp5 /*line :208:1*/*lang.Keyword;
















	A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_91; via__5 = lang.RT_Get_O_O__O(map__461000044__4, tmp5.Ref()); var trace__6 any; var tmp6 /*line :208:1*/*lang.Keyword;
















	A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_92; trace__6 = lang.RT_Get_O_O__O(map__461000044__4, tmp6.Ref()); var phase__7 any; var tmp7 /*line :208:1*/*lang.Keyword;
















	A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_93; phase__7 = lang.RT_Get_O_O_O__O(map__461000044__4, tmp7.Ref(), default__461000046__2); var map__461000048__8 any; var tmp8 /*line :208:1*/*lang.Var;

















	A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_94; map__461000048__8 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(via__5); var map__461000048__9 any; if /*line :225:1*/ lang.ISeq_InstanceOf(map__461000048__8) { var tmp9 *lang.Var; A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_67; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(map__461000048__8)) { var tmp10 *lang.Var; A_arbace_main_A_Init(); tmp10 = A_arbace_main_A_const_68; map__461000048__9 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(map__461000048__8), jrt.Object_class.ArrayClass())).Ref() } else { var tmp11 *lang.Var; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(map__461000048__8)) { var tmp12 *lang.Var; A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_69; map__461000048__9 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(map__461000048__8) } else { lang.PersistentArrayMap_Init(); map__461000048__9 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000048__9 = map__461000048__8 }; var type__10 any; var tmp13 /*line :208:1*/*lang.Keyword;
















	A_arbace_main_A_Init(); tmp13 = A_arbace_main_A_const_95; type__10 = lang.RT_Get_O_O__O(map__461000048__9, tmp13.Ref()); var message__11 any; var tmp14 /*line :208:1*/*lang.Keyword;
















	A_arbace_main_A_Init(); tmp14 = A_arbace_main_A_const_96; message__11 = lang.RT_Get_O_O__O(map__461000048__9, tmp14.Ref()); var data__12 any; var tmp15 /*line :208:1*/*lang.Keyword;
















	A_arbace_main_A_Init(); tmp15 = A_arbace_main_A_const_97; data__12 = lang.RT_Get_O_O__O(map__461000048__9, tmp15.Ref()); var map__461000050__13 any = data__12; var map__461000050__14 any; if lang.ISeq_InstanceOf(map__461000050__13) { var tmp16 *lang.Var; A_arbace_main_A_Init(); tmp16 = A_arbace_main_A_const_67; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(map__461000050__13)) { var tmp17 *lang.Var; A_arbace_main_A_Init(); tmp17 = A_arbace_main_A_const_68; map__461000050__14 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(map__461000050__13), jrt.Object_class.ArrayClass())).Ref() } else { var tmp18 *lang.Var; A_arbace_main_A_Init(); tmp18 = A_arbace_main_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(map__461000050__13)) { var tmp19 *lang.Var; A_arbace_main_A_Init(); tmp19 = A_arbace_main_A_const_69; map__461000050__14 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(map__461000050__13) } else { lang.PersistentArrayMap_Init(); map__461000050__14 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000050__14 = map__461000050__13 }; var problems__15 any; var tmp20 /*line :208:1*/*lang.Keyword;
















	A_arbace_main_A_Init(); tmp20 = A_arbace_main_A_const_98; problems__15 = lang.RT_Get_O_O__O(map__461000050__14, tmp20.Ref()); var fn__16 any; var tmp21 /*line :208:1*/*lang.Keyword;
















	A_arbace_main_A_Init(); tmp21 = A_arbace_main_A_const_99; fn__16 = lang.RT_Get_O_O__O(map__461000050__14, tmp21.Ref()); var caller__17 any; var tmp22 /*line :208:1*/*lang.Keyword;
















	A_arbace_main_A_Init(); tmp22 = A_arbace_main_A_const_100; caller__17 = lang.RT_Get_O_O__O(map__461000050__14, tmp22.Ref()); var map__461000052__18 any; var tmp23 /*line :208:1*/*lang.Keyword;



















	A_arbace_main_A_Init(); tmp23 = A_arbace_main_A_const_97; var tmp24 *lang.Keyword = tmp23; var tmp25 *lang.Var; A_arbace_main_A_Init(); tmp25 = A_arbace_main_A_const_69; map__461000052__18 = jrt.NN(tmp24).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(via__5)); var map__461000052__19 any; if /*line :225:1*/ lang.ISeq_InstanceOf(map__461000052__18) { var tmp26 *lang.Var; A_arbace_main_A_Init(); tmp26 = A_arbace_main_A_const_67; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(map__461000052__18)) { var tmp27 *lang.Var; A_arbace_main_A_Init(); tmp27 = A_arbace_main_A_const_68; map__461000052__19 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(map__461000052__18), jrt.Object_class.ArrayClass())).Ref() } else { var tmp28 *lang.Var; A_arbace_main_A_Init(); tmp28 = A_arbace_main_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(map__461000052__18)) { var tmp29 *lang.Var; A_arbace_main_A_Init(); tmp29 = A_arbace_main_A_const_69; map__461000052__19 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(map__461000052__18) } else { lang.PersistentArrayMap_Init(); map__461000052__19 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000052__19 = map__461000052__18 }; var top_data__20 any = map__461000052__19; var source__21 any; var tmp30 /*line :208:1*/*lang.Keyword;
















	A_arbace_main_A_Init(); tmp30 = A_arbace_main_A_const_101; source__21 = lang.RT_Get_O_O__O(map__461000052__19, tmp30.Ref()); var tmp31 /*line :229:1*/*lang.Var; A_arbace_main_A_Init(); tmp31 = A_arbace_main_A_const_102; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 any; var G__461000054__22_ any = phase__7; L1:
	switch { default: switch lang.Util_Hash_O__I(G__461000054__22_) >> 3 & 15 { case 0: var tmp34 *lang.Keyword; A_arbace_main_A_Init(); tmp34 = A_arbace_main_A_const_103; if any(G__461000054__22_) == any(tmp34.Ref()) { var G__461000055__23_ any = top_data__20; var G__461000055__24_ any









		if jrt.A2g_Truth(source__21) {
			var tmp35 *lang.Var; A_arbace_main_A_Init(); tmp35 = A_arbace_main_A_const_102; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Keyword; A_arbace_main_A_Init(); tmp37 = A_arbace_main_A_const_101; var tmp38 any = tmp37.Ref(); var tmp39 *lang.Var; A_arbace_main_A_Init(); tmp39 = A_arbace_main_A_const_112; var tmp40 any = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(source__21); var tmp41 *lang.Keyword; A_arbace_main_A_Init(); tmp41 = A_arbace_main_A_const_113; var tmp42 any = tmp41.Ref(); var tmp43 *lang.Var; A_arbace_main_A_Init(); tmp43 = A_arbace_main_A_const_114; G__461000055__24_ = tmp36.Invoke_O_O_O_O_O__O(G__461000055__23_, tmp38, tmp40, tmp42, lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(source__21)) } else {
//line :240:1
				G__461000055__24_ = G__461000055__23_ }
//line :230:1
		var G__461000055__25_ any; var tmp44 any









		A_arbace_main_A_Init(); tmp44 = A_arbace_main_A_const_104; if jrt.A2g_Truth(lang.IFn_Cast(tmp44).Invoke_O__O(source__21)) {


			var tmp45 *lang.Var; A_arbace_main_A_Init(); tmp45 = A_arbace_main_A_const_105; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Keyword; A_arbace_main_A_Init(); tmp47 = A_arbace_main_A_const_101; var tmp48 any = tmp47.Ref(); var tmp49 *lang.Keyword; A_arbace_main_A_Init(); tmp49 = A_arbace_main_A_const_113; G__461000055__25_ = tmp46.Invoke_O_O_O__O(G__461000055__24_, tmp48, tmp49.Ref()) } else {
//line :240:1
				G__461000055__25_ = G__461000055__24_ }
//line :230:1
		var G__461000055__26_ any









		if jrt.A2g_Truth(type__10) {



			var tmp50 *lang.Var; A_arbace_main_A_Init(); tmp50 = A_arbace_main_A_const_102; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 *lang.Keyword; A_arbace_main_A_Init(); tmp52 = A_arbace_main_A_const_110; G__461000055__26_ = tmp51.Invoke_O_O_O__O(G__461000055__25_, tmp52.Ref(), type__10) } else {
//line :240:1
				G__461000055__26_ = G__461000055__25_ }
//line :230:1
		var G__461000055__27_ any









		if jrt.A2g_Truth(message__11) {




			var tmp53 *lang.Var; A_arbace_main_A_Init(); tmp53 = A_arbace_main_A_const_102; var tmp54 lang.IFn = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()); var tmp55 *lang.Keyword; A_arbace_main_A_Init(); tmp55 = A_arbace_main_A_const_115; G__461000055__27_ = tmp54.Invoke_O_O_O__O(G__461000055__26_, tmp55.Ref(), message__11) } else {
//line :240:1
				G__461000055__27_ = G__461000055__26_ }; if jrt.A2g_Truth(problems__15) {





					var tmp56 *lang.Var; A_arbace_main_A_Init(); tmp56 = A_arbace_main_A_const_102; var tmp57 lang.IFn = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()); var tmp58 *lang.Keyword; A_arbace_main_A_Init(); tmp58 = A_arbace_main_A_const_116; tmp33 = tmp57.Invoke_O_O_O__O(G__461000055__27_, tmp58.Ref(), data__12) } else {
//line :240:1
						tmp33 = G__461000055__27_ }
//line :230:1
		break L1 }; case 1: var tmp59 *lang.Keyword; A_arbace_main_A_Init(); tmp59 = A_arbace_main_A_const_106; if any(G__461000054__22_) == any(tmp59.Ref()) { var G__461000056__23_ any = top_data__20; var G__461000056__24_ any









			if jrt.A2g_Truth(source__21) {
				var tmp60 *lang.Var; A_arbace_main_A_Init(); tmp60 = A_arbace_main_A_const_102; var tmp61 lang.IFn = lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()); var tmp62 *lang.Keyword; A_arbace_main_A_Init(); tmp62 = A_arbace_main_A_const_101; var tmp63 any = tmp62.Ref(); var tmp64 *lang.Var; A_arbace_main_A_Init(); tmp64 = A_arbace_main_A_const_112; var tmp65 any = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()).Invoke_O__O(source__21); var tmp66 *lang.Keyword; A_arbace_main_A_Init(); tmp66 = A_arbace_main_A_const_113; var tmp67 any = tmp66.Ref(); var tmp68 *lang.Var; A_arbace_main_A_Init(); tmp68 = A_arbace_main_A_const_114; G__461000056__24_ = tmp61.Invoke_O_O_O_O_O__O(G__461000056__23_, tmp63, tmp65, tmp67, lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O__O(source__21)) } else {
//line :240:1
					G__461000056__24_ = G__461000056__23_ }
//line :230:1
			var G__461000056__25_ any; var tmp69 any









			A_arbace_main_A_Init(); tmp69 = A_arbace_main_A_const_107; if jrt.A2g_Truth(lang.IFn_Cast(tmp69).Invoke_O__O(source__21)) {


				var tmp70 *lang.Var; A_arbace_main_A_Init(); tmp70 = A_arbace_main_A_const_105; var tmp71 lang.IFn = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()); var tmp72 *lang.Keyword; A_arbace_main_A_Init(); tmp72 = A_arbace_main_A_const_101; var tmp73 any = tmp72.Ref(); var tmp74 *lang.Keyword; A_arbace_main_A_Init(); tmp74 = A_arbace_main_A_const_113; G__461000056__25_ = tmp71.Invoke_O_O_O__O(G__461000056__24_, tmp73, tmp74.Ref()) } else {
//line :240:1
					G__461000056__25_ = G__461000056__24_ }
//line :230:1
			var G__461000056__26_ any









			if jrt.A2g_Truth(type__10) {



				var tmp75 *lang.Var; A_arbace_main_A_Init(); tmp75 = A_arbace_main_A_const_102; var tmp76 lang.IFn = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()); var tmp77 *lang.Keyword; A_arbace_main_A_Init(); tmp77 = A_arbace_main_A_const_110; G__461000056__26_ = tmp76.Invoke_O_O_O__O(G__461000056__25_, tmp77.Ref(), type__10) } else {
//line :240:1
					G__461000056__26_ = G__461000056__25_ }
//line :230:1
			var G__461000056__27_ any









			if jrt.A2g_Truth(message__11) {




				var tmp78 *lang.Var; A_arbace_main_A_Init(); tmp78 = A_arbace_main_A_const_102; var tmp79 lang.IFn = lang.IFn_Cast(jrt.NN(tmp78).GetRawRoot__O()); var tmp80 *lang.Keyword; A_arbace_main_A_Init(); tmp80 = A_arbace_main_A_const_115; G__461000056__27_ = tmp79.Invoke_O_O_O__O(G__461000056__26_, tmp80.Ref(), message__11) } else {
//line :240:1
					G__461000056__27_ = G__461000056__26_ }; if jrt.A2g_Truth(problems__15) {





						var tmp81 *lang.Var; A_arbace_main_A_Init(); tmp81 = A_arbace_main_A_const_102; var tmp82 lang.IFn = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()); var tmp83 *lang.Keyword; A_arbace_main_A_Init(); tmp83 = A_arbace_main_A_const_116; tmp33 = tmp82.Invoke_O_O_O__O(G__461000056__27_, tmp83.Ref(), data__12) } else {
//line :240:1
							tmp33 = G__461000056__27_ }
//line :230:1
			break L1 }; case 3: var tmp84 *lang.Keyword; A_arbace_main_A_Init(); tmp84 = A_arbace_main_A_const_108; if any(G__461000054__22_) == any(tmp84.Ref()) { var G__461000057__23_ any = top_data__20; var G__461000057__24_ any









				if jrt.A2g_Truth(source__21) {
					var tmp85 *lang.Var; A_arbace_main_A_Init(); tmp85 = A_arbace_main_A_const_102; var tmp86 lang.IFn = lang.IFn_Cast(jrt.NN(tmp85).GetRawRoot__O()); var tmp87 *lang.Keyword; A_arbace_main_A_Init(); tmp87 = A_arbace_main_A_const_101; var tmp88 any = tmp87.Ref(); var tmp89 *lang.Var; A_arbace_main_A_Init(); tmp89 = A_arbace_main_A_const_112; var tmp90 any = lang.IFn_Cast(jrt.NN(tmp89).GetRawRoot__O()).Invoke_O__O(source__21); var tmp91 *lang.Keyword; A_arbace_main_A_Init(); tmp91 = A_arbace_main_A_const_113; var tmp92 any = tmp91.Ref(); var tmp93 *lang.Var; A_arbace_main_A_Init(); tmp93 = A_arbace_main_A_const_114; G__461000057__24_ = tmp86.Invoke_O_O_O_O_O__O(G__461000057__23_, tmp88, tmp90, tmp92, lang.IFn_Cast(jrt.NN(tmp93).GetRawRoot__O()).Invoke_O__O(source__21)) } else {
//line :240:1
						G__461000057__24_ = G__461000057__23_ }
//line :230:1
				var G__461000057__25_ any; var tmp94 any









				A_arbace_main_A_Init(); tmp94 = A_arbace_main_A_const_109; if jrt.A2g_Truth(lang.IFn_Cast(tmp94).Invoke_O__O(source__21)) {


					var tmp95 *lang.Var; A_arbace_main_A_Init(); tmp95 = A_arbace_main_A_const_105; var tmp96 lang.IFn = lang.IFn_Cast(jrt.NN(tmp95).GetRawRoot__O()); var tmp97 *lang.Keyword; A_arbace_main_A_Init(); tmp97 = A_arbace_main_A_const_101; var tmp98 any = tmp97.Ref(); var tmp99 *lang.Keyword; A_arbace_main_A_Init(); tmp99 = A_arbace_main_A_const_113; G__461000057__25_ = tmp96.Invoke_O_O_O__O(G__461000057__24_, tmp98, tmp99.Ref()) } else {
//line :240:1
						G__461000057__25_ = G__461000057__24_ }
//line :230:1
				var G__461000057__26_ any









				if jrt.A2g_Truth(type__10) {



					var tmp100 *lang.Var; A_arbace_main_A_Init(); tmp100 = A_arbace_main_A_const_102; var tmp101 lang.IFn = lang.IFn_Cast(jrt.NN(tmp100).GetRawRoot__O()); var tmp102 *lang.Keyword; A_arbace_main_A_Init(); tmp102 = A_arbace_main_A_const_110; G__461000057__26_ = tmp101.Invoke_O_O_O__O(G__461000057__25_, tmp102.Ref(), type__10) } else {
//line :240:1
						G__461000057__26_ = G__461000057__25_ }
//line :230:1
				var G__461000057__27_ any









				if jrt.A2g_Truth(message__11) {




					var tmp103 *lang.Var; A_arbace_main_A_Init(); tmp103 = A_arbace_main_A_const_102; var tmp104 lang.IFn = lang.IFn_Cast(jrt.NN(tmp103).GetRawRoot__O()); var tmp105 *lang.Keyword; A_arbace_main_A_Init(); tmp105 = A_arbace_main_A_const_115; G__461000057__27_ = tmp104.Invoke_O_O_O__O(G__461000057__26_, tmp105.Ref(), message__11) } else {
//line :240:1
						G__461000057__27_ = G__461000057__26_ }; if jrt.A2g_Truth(problems__15) {





							var tmp106 *lang.Var; A_arbace_main_A_Init(); tmp106 = A_arbace_main_A_const_102; var tmp107 lang.IFn = lang.IFn_Cast(jrt.NN(tmp106).GetRawRoot__O()); var tmp108 *lang.Keyword; A_arbace_main_A_Init(); tmp108 = A_arbace_main_A_const_116; tmp33 = tmp107.Invoke_O_O_O__O(G__461000057__27_, tmp108.Ref(), data__12) } else {
//line :240:1
								tmp33 = G__461000057__27_ }
//line :230:1
				break L1 }; case 4: var tmp109 *lang.Keyword; A_arbace_main_A_Init(); tmp109 = A_arbace_main_A_const_90; if any(G__461000054__22_) == any(tmp109.Ref()) { var vec__461000058__23 any; var tmp110 *lang.Var



























					A_arbace_main_A_Init(); tmp110 = A_arbace_main_A_const_69; var tmp111 lang.IFn = lang.IFn_Cast(jrt.NN(tmp110).GetRawRoot__O()); var tmp112 *lang.Var; A_arbace_main_A_Init(); tmp112 = A_arbace_main_A_const_122; var tmp113 lang.IFn = lang.IFn_Cast(jrt.NN(tmp112).GetRawRoot__O()); var tmp114 any = A_arbace_main_ex_triage_fn__461000061_A_New(); var tmp115 *jrt.Class; A_arbace_main_ex_triage_fn__461000061_A_Init(); tmp115 = A_arbace_main_ex_triage_fn__461000061_A_fn_class; vec__461000058__23 = tmp111.Invoke_O__O(tmp113.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp114, tmp115, nil), trace__6))
//line :230:1
					var source__24 any = lang.RT_Nth_O_I_O__O(vec__461000058__23, lang.RT_IntCast_J__I(0), nil); var method__25 any = lang.RT_Nth_O_I_O__O(vec__461000058__23, lang.RT_IntCast_J__I(1), nil); var file__26 any = lang.RT_Nth_O_I_O__O(vec__461000058__23, lang.RT_IntCast_J__I(2), nil); var line__27 any = lang.RT_Nth_O_I_O__O(vec__461000058__23, lang.RT_IntCast_J__I(3), nil); var file__28 any; var tmp116 *lang.Var




























					A_arbace_main_A_Init(); tmp116 = A_arbace_main_A_const_69; var tmp117 lang.IFn = lang.IFn_Cast(jrt.NN(tmp116).GetRawRoot__O()); var tmp118 *lang.Var; A_arbace_main_A_Init(); tmp118 = A_arbace_main_A_const_124; var tmp119 lang.IFn = lang.IFn_Cast(jrt.NN(tmp118).GetRawRoot__O()); var tmp120 any = A_arbace_main_ex_triage_fn__461000063_A_New(); var tmp121 *jrt.Class; A_arbace_main_ex_triage_fn__461000063_A_Init(); tmp121 = A_arbace_main_ex_triage_fn__461000063_A_fn_class; var tmp122 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp120, tmp121, nil); var tmp123 *lang.Keyword; A_arbace_main_A_Init(); tmp123 = A_arbace_main_A_const_126; file__28 = tmp117.Invoke_O__O(tmp119.Invoke_O_O__O(tmp122, lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(tmp123).Invoke_O__O(caller__17), file__26)))
//line :230:1
					var err_line__29 any; var or__1927000174__auto____29 any; var tmp124 *lang.Keyword





























					A_arbace_main_A_Init(); tmp124 = A_arbace_main_A_const_71; or__1927000174__auto____29 = jrt.NN(tmp124).Invoke_O__O(caller__17); if jrt.A2g_Truth(or__1927000174__auto____29) { err_line__29 = or__1927000174__auto____29 } else { err_line__29 = line__27 }
//line :230:1
					var G__461000065__30_ any; var tmp125 *lang.Keyword; A_arbace_main_A_Init(); tmp125 = A_arbace_main_A_const_110; G__461000065__30_ = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp125.Ref(), type__10)); var G__461000065__31_ any






























					if jrt.A2g_Truth(err_line__29) {
						var tmp126 *lang.Var; A_arbace_main_A_Init(); tmp126 = A_arbace_main_A_const_102; var tmp127 lang.IFn = lang.IFn_Cast(jrt.NN(tmp126).GetRawRoot__O()); var tmp128 *lang.Keyword; A_arbace_main_A_Init(); tmp128 = A_arbace_main_A_const_118; G__461000065__31_ = tmp127.Invoke_O_O_O__O(G__461000065__30_, tmp128.Ref(), err_line__29) } else {
//line :261:1
							G__461000065__31_ = G__461000065__30_ }
//line :230:1
					var G__461000065__32_ any






























					if jrt.A2g_Truth(message__11) {

						var tmp129 *lang.Var; A_arbace_main_A_Init(); tmp129 = A_arbace_main_A_const_102; var tmp130 lang.IFn = lang.IFn_Cast(jrt.NN(tmp129).GetRawRoot__O()); var tmp131 *lang.Keyword; A_arbace_main_A_Init(); tmp131 = A_arbace_main_A_const_115; G__461000065__32_ = tmp130.Invoke_O_O_O__O(G__461000065__31_, tmp131.Ref(), message__11) } else {
//line :261:1
							G__461000065__32_ = G__461000065__31_ }
//line :230:1
					var G__461000065__33_ any; var tmp132 any
					var or__1927000174__auto____33 any = fn__16
































					if jrt.A2g_Truth(or__1927000174__auto____33) { tmp132 = or__1927000174__auto____33 } else { var and__1927000168__auto____34 any = source__24; if jrt.A2g_Truth(and__1927000168__auto____34) { tmp132 = method__25 } else { tmp132 = and__1927000168__auto____34 } }
//line :261:1
					if jrt.A2g_Truth(tmp132) {


						var tmp133 *lang.Var; A_arbace_main_A_Init(); tmp133 = A_arbace_main_A_const_102; var tmp134 lang.IFn = lang.IFn_Cast(jrt.NN(tmp133).GetRawRoot__O()); var tmp135 *lang.Keyword; A_arbace_main_A_Init(); tmp135 = A_arbace_main_A_const_127; var tmp136 any = tmp135.Ref(); var tmp137 any; var or__1927000174__auto____33_2 any = fn__16; if jrt.A2g_Truth(or__1927000174__auto____33_2) { tmp137 = or__1927000174__auto____33_2 } else { var tmp138 *lang.Var; A_arbace_main_A_Init(); tmp138 = A_arbace_main_A_const_128; tmp137 = lang.IFn_Cast(jrt.NN(tmp138).GetRawRoot__O()).Invoke_O_O__O(source__24, method__25) }; G__461000065__33_ = tmp134.Invoke_O_O_O__O(G__461000065__32_, tmp136, tmp137) } else {
//line :261:1
							G__461000065__33_ = G__461000065__32_ }
//line :230:1
					var G__461000065__34_ any






























					if jrt.A2g_Truth(file__28) {



						var tmp139 *lang.Var; A_arbace_main_A_Init(); tmp139 = A_arbace_main_A_const_102; var tmp140 lang.IFn = lang.IFn_Cast(jrt.NN(tmp139).GetRawRoot__O()); var tmp141 *lang.Keyword; A_arbace_main_A_Init(); tmp141 = A_arbace_main_A_const_101; G__461000065__34_ = tmp140.Invoke_O_O_O__O(G__461000065__33_, tmp141.Ref(), file__28) } else {
//line :261:1
							G__461000065__34_ = G__461000065__33_ }; if jrt.A2g_Truth(problems__15) {




								var tmp142 *lang.Var; A_arbace_main_A_Init(); tmp142 = A_arbace_main_A_const_102; var tmp143 lang.IFn = lang.IFn_Cast(jrt.NN(tmp142).GetRawRoot__O()); var tmp144 *lang.Keyword; A_arbace_main_A_Init(); tmp144 = A_arbace_main_A_const_116; tmp33 = tmp143.Invoke_O_O_O__O(G__461000065__34_, tmp144.Ref(), data__12) } else {
//line :261:1
									tmp33 = G__461000065__34_ }
//line :230:1
					break L1 }; case 6: var tmp145 *lang.Keyword; A_arbace_main_A_Init(); tmp145 = A_arbace_main_A_const_117; if any(G__461000054__22_) == any(tmp145.Ref()) { var map__461000066__23 any = data__12; var map__461000066__24 any

						if lang.ISeq_InstanceOf(map__461000066__23) { var tmp146 *lang.Var; A_arbace_main_A_Init(); tmp146 = A_arbace_main_A_const_67; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp146).GetRawRoot__O()).Invoke_O__O(map__461000066__23)) { var tmp147 *lang.Var; A_arbace_main_A_Init(); tmp147 = A_arbace_main_A_const_68; map__461000066__24 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp147).GetRawRoot__O()).Invoke_O__O(map__461000066__23), jrt.Object_class.ArrayClass())).Ref() } else { var tmp148 *lang.Var; A_arbace_main_A_Init(); tmp148 = A_arbace_main_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp148).GetRawRoot__O()).Invoke_O__O(map__461000066__23)) { var tmp149 *lang.Var; A_arbace_main_A_Init(); tmp149 = A_arbace_main_A_const_69; map__461000066__24 = lang.IFn_Cast(jrt.NN(tmp149).GetRawRoot__O()).Invoke_O__O(map__461000066__23) } else { lang.PersistentArrayMap_Init(); map__461000066__24 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000066__24 = map__461000066__23 }
//line :230:1
						var line__25 any; var tmp150 *lang.Keyword; _ = line__25

						A_arbace_main_A_Init(); tmp150 = A_arbace_main_A_const_118; line__25 = lang.RT_Get_O_O__O(map__461000066__24, tmp150.Ref())
//line :230:1
						var column__26 any; var tmp151 *lang.Keyword; _ = column__26

						A_arbace_main_A_Init(); tmp151 = A_arbace_main_A_const_119; column__26 = lang.RT_Get_O_O__O(map__461000066__24, tmp151.Ref())
//line :230:1
						var G__461000068__27_ any; var tmp152 *lang.Var


						A_arbace_main_A_Init(); tmp152 = A_arbace_main_A_const_120; var tmp153 lang.IFn = lang.IFn_Cast(jrt.NN(tmp152).GetRawRoot__O()); var tmp154 *lang.Keyword; A_arbace_main_A_Init(); tmp154 = A_arbace_main_A_const_97; var tmp155 *lang.Keyword = tmp154; var tmp156 *lang.Var; A_arbace_main_A_Init(); tmp156 = A_arbace_main_A_const_15; G__461000068__27_ = tmp153.Invoke_O_O__O(jrt.NN(tmp155).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp156).GetRawRoot__O()).Invoke_O__O(via__5)), top_data__20)
//line :230:1
						var G__461000068__28_ any


						if jrt.A2g_Truth(source__21) {
							var tmp157 *lang.Var; A_arbace_main_A_Init(); tmp157 = A_arbace_main_A_const_102; var tmp158 lang.IFn = lang.IFn_Cast(jrt.NN(tmp157).GetRawRoot__O()); var tmp159 *lang.Keyword; A_arbace_main_A_Init(); tmp159 = A_arbace_main_A_const_101; var tmp160 any = tmp159.Ref(); var tmp161 *lang.Var; A_arbace_main_A_Init(); tmp161 = A_arbace_main_A_const_112; var tmp162 any = lang.IFn_Cast(jrt.NN(tmp161).GetRawRoot__O()).Invoke_O__O(source__21); var tmp163 *lang.Keyword; A_arbace_main_A_Init(); tmp163 = A_arbace_main_A_const_113; var tmp164 any = tmp163.Ref(); var tmp165 *lang.Var; A_arbace_main_A_Init(); tmp165 = A_arbace_main_A_const_114; G__461000068__28_ = tmp158.Invoke_O_O_O_O_O__O(G__461000068__27_, tmp160, tmp162, tmp164, lang.IFn_Cast(jrt.NN(tmp165).GetRawRoot__O()).Invoke_O__O(source__21)) } else {
//line :233:1
								G__461000068__28_ = G__461000068__27_ }
//line :230:1
						var G__461000068__29_ any; var tmp166 any


						A_arbace_main_A_Init(); tmp166 = A_arbace_main_A_const_121; if jrt.A2g_Truth(lang.IFn_Cast(tmp166).Invoke_O__O(source__21)) {


							var tmp167 *lang.Var; A_arbace_main_A_Init(); tmp167 = A_arbace_main_A_const_105; var tmp168 lang.IFn = lang.IFn_Cast(jrt.NN(tmp167).GetRawRoot__O()); var tmp169 *lang.Keyword; A_arbace_main_A_Init(); tmp169 = A_arbace_main_A_const_101; var tmp170 any = tmp169.Ref(); var tmp171 *lang.Keyword; A_arbace_main_A_Init(); tmp171 = A_arbace_main_A_const_113; G__461000068__29_ = tmp168.Invoke_O_O_O__O(G__461000068__28_, tmp170, tmp171.Ref()) } else {
//line :233:1
								G__461000068__29_ = G__461000068__28_ }; if jrt.A2g_Truth(message__11) {



									var tmp172 *lang.Var; A_arbace_main_A_Init(); tmp172 = A_arbace_main_A_const_102; var tmp173 lang.IFn = lang.IFn_Cast(jrt.NN(tmp172).GetRawRoot__O()); var tmp174 *lang.Keyword; A_arbace_main_A_Init(); tmp174 = A_arbace_main_A_const_115; tmp33 = tmp173.Invoke_O_O_O__O(G__461000068__29_, tmp174.Ref(), message__11) } else {
//line :233:1
										tmp33 = G__461000068__29_ }
//line :230:1
						break L1 }; case 9: var tmp175 *lang.Keyword; A_arbace_main_A_Init(); tmp175 = A_arbace_main_A_const_129; if any(G__461000054__22_) == any(tmp175.Ref()) { var vec__461000069__23 any; var tmp176 *lang.Var


















							A_arbace_main_A_Init(); tmp176 = A_arbace_main_A_const_69; vec__461000069__23 = lang.IFn_Cast(jrt.NN(tmp176).GetRawRoot__O()).Invoke_O__O(trace__6)
//line :230:1
							var source__24_2 any = lang.RT_Nth_O_I_O__O(vec__461000069__23, lang.RT_IntCast_J__I(0), nil); var method__25_2 any = lang.RT_Nth_O_I_O__O(vec__461000069__23, lang.RT_IntCast_J__I(1), nil); var file__26_2 any = lang.RT_Nth_O_I_O__O(vec__461000069__23, lang.RT_IntCast_J__I(2), nil); var line__27_2 any = lang.RT_Nth_O_I_O__O(vec__461000069__23, lang.RT_IntCast_J__I(3), nil); var G__461000072__28_ any = top_data__20; var G__461000072__29_ any



















							if jrt.A2g_Truth(line__27_2) {
								var tmp177 *lang.Var; A_arbace_main_A_Init(); tmp177 = A_arbace_main_A_const_102; var tmp178 lang.IFn = lang.IFn_Cast(jrt.NN(tmp177).GetRawRoot__O()); var tmp179 *lang.Keyword; A_arbace_main_A_Init(); tmp179 = A_arbace_main_A_const_118; G__461000072__29_ = tmp178.Invoke_O_O_O__O(G__461000072__28_, tmp179.Ref(), line__27_2) } else {
//line :250:1
									G__461000072__29_ = G__461000072__28_ }
//line :230:1
							var G__461000072__30_ any



















							if jrt.A2g_Truth(file__26_2) {

								var tmp180 *lang.Var; A_arbace_main_A_Init(); tmp180 = A_arbace_main_A_const_102; var tmp181 lang.IFn = lang.IFn_Cast(jrt.NN(tmp180).GetRawRoot__O()); var tmp182 *lang.Keyword; A_arbace_main_A_Init(); tmp182 = A_arbace_main_A_const_101; G__461000072__30_ = tmp181.Invoke_O_O_O__O(G__461000072__29_, tmp182.Ref(), file__26_2) } else {
//line :250:1
									G__461000072__30_ = G__461000072__29_ }
//line :230:1
							var G__461000072__31_ any; var tmp183 any
							var and__1927000168__auto____31 any = source__24_2





















							if jrt.A2g_Truth(and__1927000168__auto____31) { tmp183 = method__25_2 } else { tmp183 = and__1927000168__auto____31 }
//line :250:1
							if jrt.A2g_Truth(tmp183) {


								var tmp184 *lang.Var; A_arbace_main_A_Init(); tmp184 = A_arbace_main_A_const_102; var tmp185 lang.IFn = lang.IFn_Cast(jrt.NN(tmp184).GetRawRoot__O()); var tmp186 *lang.Keyword; A_arbace_main_A_Init(); tmp186 = A_arbace_main_A_const_127; var tmp187 any = tmp186.Ref(); var tmp188 *lang.Var; A_arbace_main_A_Init(); tmp188 = A_arbace_main_A_const_128; G__461000072__31_ = tmp185.Invoke_O_O_O__O(G__461000072__30_, tmp187, lang.IFn_Cast(jrt.NN(tmp188).GetRawRoot__O()).Invoke_O_O__O(source__24_2, method__25_2)) } else {
//line :250:1
									G__461000072__31_ = G__461000072__30_ }
//line :230:1
							var G__461000072__32_ any



















							if jrt.A2g_Truth(type__10) {



								var tmp189 *lang.Var; A_arbace_main_A_Init(); tmp189 = A_arbace_main_A_const_102; var tmp190 lang.IFn = lang.IFn_Cast(jrt.NN(tmp189).GetRawRoot__O()); var tmp191 *lang.Keyword; A_arbace_main_A_Init(); tmp191 = A_arbace_main_A_const_110; G__461000072__32_ = tmp190.Invoke_O_O_O__O(G__461000072__31_, tmp191.Ref(), type__10) } else {
//line :250:1
									G__461000072__32_ = G__461000072__31_ }; if jrt.A2g_Truth(message__11) {




										var tmp192 *lang.Var; A_arbace_main_A_Init(); tmp192 = A_arbace_main_A_const_102; var tmp193 lang.IFn = lang.IFn_Cast(jrt.NN(tmp192).GetRawRoot__O()); var tmp194 *lang.Keyword; A_arbace_main_A_Init(); tmp194 = A_arbace_main_A_const_115; tmp33 = tmp193.Invoke_O_O_O__O(G__461000072__32_, tmp194.Ref(), message__11) } else {
//line :250:1
											tmp33 = G__461000072__32_ }
//line :230:1
							break L1 }; case 12: var tmp195 *lang.Keyword; A_arbace_main_A_Init(); tmp195 = A_arbace_main_A_const_130; if any(G__461000054__22_) == any(tmp195.Ref()) { var G__461000073__23_ any = top_data__20; var G__461000073__24_ any









								if jrt.A2g_Truth(source__21) {
									var tmp196 *lang.Var; A_arbace_main_A_Init(); tmp196 = A_arbace_main_A_const_102; var tmp197 lang.IFn = lang.IFn_Cast(jrt.NN(tmp196).GetRawRoot__O()); var tmp198 *lang.Keyword; A_arbace_main_A_Init(); tmp198 = A_arbace_main_A_const_101; var tmp199 any = tmp198.Ref(); var tmp200 *lang.Var; A_arbace_main_A_Init(); tmp200 = A_arbace_main_A_const_112; var tmp201 any = lang.IFn_Cast(jrt.NN(tmp200).GetRawRoot__O()).Invoke_O__O(source__21); var tmp202 *lang.Keyword; A_arbace_main_A_Init(); tmp202 = A_arbace_main_A_const_113; var tmp203 any = tmp202.Ref(); var tmp204 *lang.Var; A_arbace_main_A_Init(); tmp204 = A_arbace_main_A_const_114; G__461000073__24_ = tmp197.Invoke_O_O_O_O_O__O(G__461000073__23_, tmp199, tmp201, tmp203, lang.IFn_Cast(jrt.NN(tmp204).GetRawRoot__O()).Invoke_O__O(source__21)) } else {
//line :240:1
										G__461000073__24_ = G__461000073__23_ }
//line :230:1
								var G__461000073__25_ any; var tmp205 any









								A_arbace_main_A_Init(); tmp205 = A_arbace_main_A_const_131; if jrt.A2g_Truth(lang.IFn_Cast(tmp205).Invoke_O__O(source__21)) {


									var tmp206 *lang.Var; A_arbace_main_A_Init(); tmp206 = A_arbace_main_A_const_105; var tmp207 lang.IFn = lang.IFn_Cast(jrt.NN(tmp206).GetRawRoot__O()); var tmp208 *lang.Keyword; A_arbace_main_A_Init(); tmp208 = A_arbace_main_A_const_101; var tmp209 any = tmp208.Ref(); var tmp210 *lang.Keyword; A_arbace_main_A_Init(); tmp210 = A_arbace_main_A_const_113; G__461000073__25_ = tmp207.Invoke_O_O_O__O(G__461000073__24_, tmp209, tmp210.Ref()) } else {
//line :240:1
										G__461000073__25_ = G__461000073__24_ }
//line :230:1
								var G__461000073__26_ any









								if jrt.A2g_Truth(type__10) {



									var tmp211 *lang.Var; A_arbace_main_A_Init(); tmp211 = A_arbace_main_A_const_102; var tmp212 lang.IFn = lang.IFn_Cast(jrt.NN(tmp211).GetRawRoot__O()); var tmp213 *lang.Keyword; A_arbace_main_A_Init(); tmp213 = A_arbace_main_A_const_110; G__461000073__26_ = tmp212.Invoke_O_O_O__O(G__461000073__25_, tmp213.Ref(), type__10) } else {
//line :240:1
										G__461000073__26_ = G__461000073__25_ }
//line :230:1
								var G__461000073__27_ any









								if jrt.A2g_Truth(message__11) {




									var tmp214 *lang.Var; A_arbace_main_A_Init(); tmp214 = A_arbace_main_A_const_102; var tmp215 lang.IFn = lang.IFn_Cast(jrt.NN(tmp214).GetRawRoot__O()); var tmp216 *lang.Keyword; A_arbace_main_A_Init(); tmp216 = A_arbace_main_A_const_115; G__461000073__27_ = tmp215.Invoke_O_O_O__O(G__461000073__26_, tmp216.Ref(), message__11) } else {
//line :240:1
										G__461000073__27_ = G__461000073__26_ }; if jrt.A2g_Truth(problems__15) {





											var tmp217 *lang.Var; A_arbace_main_A_Init(); tmp217 = A_arbace_main_A_const_102; var tmp218 lang.IFn = lang.IFn_Cast(jrt.NN(tmp217).GetRawRoot__O()); var tmp219 *lang.Keyword; A_arbace_main_A_Init(); tmp219 = A_arbace_main_A_const_116; tmp33 = tmp218.Invoke_O_O_O__O(G__461000073__27_, tmp219.Ref(), data__12) } else {
//line :240:1
												tmp33 = G__461000073__27_ }
//line :230:1
								break L1 }; case 15: var tmp220 *lang.Keyword; A_arbace_main_A_Init(); tmp220 = A_arbace_main_A_const_132; if any(G__461000054__22_) == any(tmp220.Ref()) { var vec__461000074__23 any; var tmp221 *lang.Var


















									A_arbace_main_A_Init(); tmp221 = A_arbace_main_A_const_69; vec__461000074__23 = lang.IFn_Cast(jrt.NN(tmp221).GetRawRoot__O()).Invoke_O__O(trace__6)
//line :230:1
									var source__24_3 any = lang.RT_Nth_O_I_O__O(vec__461000074__23, lang.RT_IntCast_J__I(0), nil); var method__25_3 any = lang.RT_Nth_O_I_O__O(vec__461000074__23, lang.RT_IntCast_J__I(1), nil); var file__26_3 any = lang.RT_Nth_O_I_O__O(vec__461000074__23, lang.RT_IntCast_J__I(2), nil); var line__27_3 any = lang.RT_Nth_O_I_O__O(vec__461000074__23, lang.RT_IntCast_J__I(3), nil); var G__461000077__28_ any = top_data__20; var G__461000077__29_ any



















									if jrt.A2g_Truth(line__27_3) {
										var tmp222 *lang.Var; A_arbace_main_A_Init(); tmp222 = A_arbace_main_A_const_102; var tmp223 lang.IFn = lang.IFn_Cast(jrt.NN(tmp222).GetRawRoot__O()); var tmp224 *lang.Keyword; A_arbace_main_A_Init(); tmp224 = A_arbace_main_A_const_118; G__461000077__29_ = tmp223.Invoke_O_O_O__O(G__461000077__28_, tmp224.Ref(), line__27_3) } else {
//line :250:1
											G__461000077__29_ = G__461000077__28_ }
//line :230:1
									var G__461000077__30_ any



















									if jrt.A2g_Truth(file__26_3) {

										var tmp225 *lang.Var; A_arbace_main_A_Init(); tmp225 = A_arbace_main_A_const_102; var tmp226 lang.IFn = lang.IFn_Cast(jrt.NN(tmp225).GetRawRoot__O()); var tmp227 *lang.Keyword; A_arbace_main_A_Init(); tmp227 = A_arbace_main_A_const_101; G__461000077__30_ = tmp226.Invoke_O_O_O__O(G__461000077__29_, tmp227.Ref(), file__26_3) } else {
//line :250:1
											G__461000077__30_ = G__461000077__29_ }
//line :230:1
									var G__461000077__31_ any; var tmp228 any
									var and__1927000168__auto____31_2 any = source__24_3





















									if jrt.A2g_Truth(and__1927000168__auto____31_2) { tmp228 = method__25_3 } else { tmp228 = and__1927000168__auto____31_2 }
//line :250:1
									if jrt.A2g_Truth(tmp228) {


										var tmp229 *lang.Var; A_arbace_main_A_Init(); tmp229 = A_arbace_main_A_const_102; var tmp230 lang.IFn = lang.IFn_Cast(jrt.NN(tmp229).GetRawRoot__O()); var tmp231 *lang.Keyword; A_arbace_main_A_Init(); tmp231 = A_arbace_main_A_const_127; var tmp232 any = tmp231.Ref(); var tmp233 *lang.Var; A_arbace_main_A_Init(); tmp233 = A_arbace_main_A_const_128; G__461000077__31_ = tmp230.Invoke_O_O_O__O(G__461000077__30_, tmp232, lang.IFn_Cast(jrt.NN(tmp233).GetRawRoot__O()).Invoke_O_O__O(source__24_3, method__25_3)) } else {
//line :250:1
											G__461000077__31_ = G__461000077__30_ }
//line :230:1
									var G__461000077__32_ any



















									if jrt.A2g_Truth(type__10) {



										var tmp234 *lang.Var; A_arbace_main_A_Init(); tmp234 = A_arbace_main_A_const_102; var tmp235 lang.IFn = lang.IFn_Cast(jrt.NN(tmp234).GetRawRoot__O()); var tmp236 *lang.Keyword; A_arbace_main_A_Init(); tmp236 = A_arbace_main_A_const_110; G__461000077__32_ = tmp235.Invoke_O_O_O__O(G__461000077__31_, tmp236.Ref(), type__10) } else {
//line :250:1
											G__461000077__32_ = G__461000077__31_ }; if jrt.A2g_Truth(message__11) {




												var tmp237 *lang.Var; A_arbace_main_A_Init(); tmp237 = A_arbace_main_A_const_102; var tmp238 lang.IFn = lang.IFn_Cast(jrt.NN(tmp237).GetRawRoot__O()); var tmp239 *lang.Keyword; A_arbace_main_A_Init(); tmp239 = A_arbace_main_A_const_115; tmp33 = tmp238.Invoke_O_O_O__O(G__461000077__32_, tmp239.Ref(), message__11) } else {
//line :250:1
													tmp33 = G__461000077__32_ }
//line :230:1
									break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_231, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__461000054__22_)))))}; var tmp240 any = tmp33; var tmp241 /*line :229:1*/*lang.Keyword; A_arbace_main_A_Init(); tmp241 = A_arbace_main_A_const_111; return tmp32.Invoke_O_O_O__O(tmp240, tmp241.Ref(), phase__7) }




























func A_arbace_main_ex_triage_fn__461000061_A_New() *A_arbace_main_ex_triage_fn__461000061_A { A_arbace_main_ex_triage_fn__461000061_A_Init(); t := &A_arbace_main_ex_triage_fn__461000061_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_main_ex_triage_fn__461000061_A) Ctor() {}
//line :258:1
func (t *A_arbace_main_ex_triage_fn__461000061_A) Invoke_O_O__O(self, p1__461000042_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_123; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_89; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_69; return tmp2.Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(p1__461000042_SHARP___1))) }
func A_arbace_main_ex_triage_fn__461000063_A_New() *A_arbace_main_ex_triage_fn__461000063_A { A_arbace_main_ex_triage_fn__461000063_A_Init(); t := &A_arbace_main_ex_triage_fn__461000063_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_main_ex_triage_fn__461000063_A) Ctor() {}
//line :259:1
func (t *A_arbace_main_ex_triage_fn__461000063_A) Invoke_O_O__O(self, p1__461000043_SHARP___1 any) any { var or__1927000174__auto____2 bool = lang.Util_Identical_O_O__Z(p1__461000043_SHARP___1, nil); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2).Ref() } else { var tmp1 any; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_125; return lang.IFn_Cast(tmp1).Invoke_O__O(p1__461000043_SHARP___1) } }









func A_arbace_main_ex_str_A_New() *A_arbace_main_ex_str_A { A_arbace_main_ex_str_A_Init(); t := &A_arbace_main_ex_str_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_main_ex_str_A) Ctor() {}
//line :269:1
func (t *A_arbace_main_ex_str_A) Invoke_O_O__O(self, p__461000081__0 any) any { var map__461000082__2 any = p__461000081__0; var map__461000082__3 any; if lang.ISeq_InstanceOf(map__461000082__2) { var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_67; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__461000082__2)) { var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_68; map__461000082__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__461000082__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__461000082__2)) { var tmp4 *lang.Var; A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_69; map__461000082__3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__461000082__2) } else { lang.PersistentArrayMap_Init(); map__461000082__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000082__3 = map__461000082__2 }; var triage_data__4 any = map__461000082__3; var phase__5 any; var tmp5 *lang.Keyword; _ = triage_data__4; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_111; phase__5 = lang.RT_Get_O_O__O(map__461000082__3, tmp5.Ref()); var source__6 any; var tmp6 *lang.Keyword; A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_101; source__6 = lang.RT_Get_O_O__O(map__461000082__3, tmp6.Ref()); var path__7 any; var tmp7 *lang.Keyword; A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_113; path__7 = lang.RT_Get_O_O__O(map__461000082__3, tmp7.Ref()); var line__8 any; var tmp8 *lang.Keyword; A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_118; line__8 = lang.RT_Get_O_O__O(map__461000082__3, tmp8.Ref()); var column__9 any; var tmp9 *lang.Keyword; A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_119; column__9 = lang.RT_Get_O_O__O(map__461000082__3, tmp9.Ref()); var symbol__10 any; var tmp10 *lang.Keyword; A_arbace_main_A_Init(); tmp10 = A_arbace_main_A_const_127; symbol__10 = lang.RT_Get_O_O__O(map__461000082__3, tmp10.Ref()); var class__11 any; var tmp11 *lang.Keyword; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_110; class__11 = lang.RT_Get_O_O__O(map__461000082__3, tmp11.Ref()); var cause__12 any; var tmp12 *lang.Keyword; A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_115; cause__12 = lang.RT_Get_O_O__O(map__461000082__3, tmp12.Ref()); var spec__13 any; var tmp13 *lang.Keyword; A_arbace_main_A_Init(); tmp13 = A_arbace_main_A_const_116; spec__13 = lang.RT_Get_O_O__O(map__461000082__3, tmp13.Ref()); var loc__14 any; var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_215, nil, nil); var tmp15 any; var or__1927000174__auto____18 any = path__7; if






	jrt.A2g_Truth(or__1927000174__auto____18) { tmp15 = or__1927000174__auto____18 } else { var or__1927000174__auto____19 any = source__6; if jrt.A2g_Truth(or__1927000174__auto____19) { tmp15 = or__1927000174__auto____19 } else { tmp15 = Lit_216 } }; var tmp16 any = tmp15; var tmp17 any; var or__1927000174__auto____18_2 any = line__8; if jrt.A2g_Truth(or__1927000174__auto____18_2) { tmp17 = or__1927000174__auto____18_2 } else { A_arbace_main_A_Init(); tmp17 = A_arbace_main_A_const_77 }; var tmp18 any = tmp17; var tmp19 *jrt.String; if jrt.A2g_Truth(column__9) { tmp19 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_215, nil), jrt.RefArrayOf(jrt.Object_class, nil, column__9)) } else { tmp19 = Lit_217 }; loc__14 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp14, jrt.RefArrayOf(jrt.Object_class, tmp16, nil, tmp18, tmp19.Ref())).Ref(); var class_name__15 any; var tmp20 /*line :269:1*/*lang.Var;







	A_arbace_main_A_Init(); tmp20 = A_arbace_main_A_const_89; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 any; var or__1927000174__auto____15 any = class__11; if jrt.A2g_Truth(or__1927000174__auto____15) { tmp22 = or__1927000174__auto____15 } else { tmp22 = Lit_217 }; class_name__15 = tmp21.Invoke_O__O(tmp22); var simple_class__16 any; if
	jrt.A2g_Truth(class__11) { var or__1927000174__auto____16 any; var tmp23 *lang.Var; A_arbace_main_A_Init(); tmp23 = A_arbace_main_A_const_69; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_main_A_Init(); tmp25 = A_arbace_main_A_const_16; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any; A_arbace_main_A_Init(); tmp27 = A_arbace_main_A_const_134; or__1927000174__auto____16 = tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp27, class_name__15)); if jrt.A2g_Truth(or__1927000174__auto____16) { simple_class__16 = or__1927000174__auto____16 } else { simple_class__16 = class_name__15 } } else { simple_class__16 = nil }; var cause_type__17 any; var tmp28 /*line :269:1*/*lang.Var;









	A_arbace_main_A_Init(); tmp28 = A_arbace_main_A_const_13; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any; A_arbace_main_A_Init(); tmp30 = A_arbace_main_A_const_135; if jrt.A2g_Truth(tmp29.Invoke_O_O__O(tmp30, simple_class__16)) { cause_type__17 = Lit_217 } else {

		cause_type__17 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_218, nil, Lit_219), jrt.RefArrayOf(jrt.Object_class, nil, simple_class__16, nil)).Ref() }; var G__461000084__18_ any = phase__5; switch
	lang.Util_Hash_O__I(G__461000084__18_) >> 3 & 15 { case 0: var tmp31 *lang.Keyword; A_arbace_main_A_Init(); tmp31 = A_arbace_main_A_const_103; if any(G__461000084__18_) == any(tmp31.Ref()) {




		var tmp32 *lang.Var; A_arbace_main_A_Init(); tmp32 = A_arbace_main_A_const_133; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *jrt.String
		if jrt.A2g_Truth(symbol__10) { tmp34 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_221), jrt.RefArrayOf(jrt.Object_class, symbol__10, nil)) } else { tmp34 = Lit_217 }
//line :287:1
		var tmp35 any = tmp34.Ref(); var tmp36 any


		if jrt.A2g_Truth(spec__13) { var s__1927001093__auto____19 any = jrt.StringWriter_New(); var tmp37 *lang.Var
			A_arbace_main_A_Init(); tmp37 = A_arbace_main_A_const_142; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Var; A_arbace_main_A_Init(); tmp39 = A_arbace_main_A_const_143; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 *lang.Var; A_arbace_main_A_Init(); tmp41 = A_arbace_main_A_const_144; tmp38.Invoke_O__O(tmp40.Invoke_O_O__O(tmp41.Ref(), s__1927001093__auto____19)); var tmp42 any = A_arbace_main_ex_str_fn__461000085_A_New_O_O(spec__13, s__1927001093__auto____19); var tmp43 *jrt.Class; A_arbace_main_ex_str_fn__461000085_A_Init(); tmp43 = A_arbace_main_ex_str_fn__461000085_A_fn_class; tmp36 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp42, tmp43, nil).Invoke__O() } else {





				var tmp44 *lang.Var; A_arbace_main_A_Init(); tmp44 = A_arbace_main_A_const_133; tmp36 = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O_O__O(Lit_222, cause__12) }
//line :287:1
		return tmp33.Invoke_O_O_O_O__O(Lit_220, tmp35, loc__14, tmp36) }
//line :282:1
	case 1: var tmp45 *lang.Keyword; A_arbace_main_A_Init(); tmp45 = A_arbace_main_A_const_106; if any(G__461000084__18_) == any(tmp45.Ref()) {
























		var tmp46 *lang.Var; A_arbace_main_A_Init(); tmp46 = A_arbace_main_A_const_133; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *jrt.String

		if jrt.A2g_Truth(symbol__10) { tmp48 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_221), jrt.RefArrayOf(jrt.Object_class, symbol__10, nil)) } else { tmp48 = Lit_217 }
//line :307:1
		return tmp47.Invoke_O_O_O_O_O__O(Lit_223, cause_type__17, tmp48.Ref(), loc__14, cause__12) }
//line :282:1
	case 3: var tmp49 *lang.Keyword; A_arbace_main_A_Init(); tmp49 = A_arbace_main_A_const_108; if any(G__461000084__18_) == any(tmp49.Ref()) {

















		var tmp50 *lang.Var; A_arbace_main_A_Init(); tmp50 = A_arbace_main_A_const_133; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 *jrt.String

		if jrt.A2g_Truth(symbol__10) { tmp52 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_221), jrt.RefArrayOf(jrt.Object_class, symbol__10, nil)) } else { tmp52 = Lit_217 }
//line :300:1
		return tmp51.Invoke_O_O_O_O_O__O(Lit_224, cause_type__17, tmp52.Ref(), loc__14, cause__12) }
//line :282:1
	case 4: var tmp53 *lang.Keyword; A_arbace_main_A_Init(); tmp53 = A_arbace_main_A_const_90; if any(G__461000084__18_) == any(tmp53.Ref()) {












































		if jrt.A2g_Truth(spec__13) {
			var tmp54 *lang.Var; A_arbace_main_A_Init(); tmp54 = A_arbace_main_A_const_133; var tmp55 lang.IFn = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()); var tmp56 any; var s__1927001093__auto____19_2 any = jrt.StringWriter_New(); var tmp57 *lang.Var


			A_arbace_main_A_Init(); tmp57 = A_arbace_main_A_const_142; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 *lang.Var; A_arbace_main_A_Init(); tmp59 = A_arbace_main_A_const_143; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 *lang.Var; A_arbace_main_A_Init(); tmp61 = A_arbace_main_A_const_144; tmp58.Invoke_O__O(tmp60.Invoke_O_O__O(tmp61.Ref(), s__1927001093__auto____19_2)); var tmp62 any = A_arbace_main_ex_str_fn__461000091_A_New_O_O(spec__13, s__1927001093__auto____19_2); var tmp63 *jrt.Class; A_arbace_main_ex_str_fn__461000091_A_Init(); tmp63 = A_arbace_main_ex_str_fn__461000091_A_fn_class; tmp56 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp62, tmp63, nil).Invoke__O()
//line :328:1
			return tmp55.Invoke_O_O_O_O__O(Lit_225, symbol__10, loc__14, tmp56) } else {








				var tmp64 *lang.Var; A_arbace_main_A_Init(); tmp64 = A_arbace_main_A_const_133; var tmp65 lang.IFn = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()); var tmp66 *jrt.String

				if jrt.A2g_Truth(symbol__10) { tmp66 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_221), jrt.RefArrayOf(jrt.Object_class, symbol__10, nil)) } else { tmp66 = Lit_217 }
//line :337:1
				return tmp65.Invoke_O_O_O_O_O__O(Lit_226, cause_type__17, tmp66.Ref(), loc__14, cause__12) } }
//line :282:1
	case 6: var tmp67 *lang.Keyword; A_arbace_main_A_Init(); tmp67 = A_arbace_main_A_const_117; if any(G__461000084__18_) == any(tmp67.Ref()) {

		var tmp68 *lang.Var; A_arbace_main_A_Init(); tmp68 = A_arbace_main_A_const_133; return lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O_O_O__O(Lit_227, loc__14, cause__12) }
//line :282:1
	case 9: var tmp69 *lang.Keyword; A_arbace_main_A_Init(); tmp69 = A_arbace_main_A_const_129; if any(G__461000084__18_) == any(tmp69.Ref()) {






































		var tmp70 *lang.Var; A_arbace_main_A_Init(); tmp70 = A_arbace_main_A_const_133; return lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke_O_O_O_O_O__O(Lit_228, cause_type__17, symbol__10, loc__14, cause__12) }
//line :282:1
	case 12: var tmp71 *lang.Keyword; A_arbace_main_A_Init(); tmp71 = A_arbace_main_A_const_130; if any(G__461000084__18_) == any(tmp71.Ref()) {































		var tmp72 *lang.Var; A_arbace_main_A_Init(); tmp72 = A_arbace_main_A_const_133; var tmp73 lang.IFn = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()); var tmp74 *jrt.String

		if jrt.A2g_Truth(symbol__10) { tmp74 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_221), jrt.RefArrayOf(jrt.Object_class, symbol__10, nil)) } else { tmp74 = Lit_217 }
//line :314:1
		return tmp73.Invoke_O_O_O_O_O__O(Lit_229, cause_type__17, tmp74.Ref(), loc__14, cause__12) }
//line :282:1
	case 15: var tmp75 *lang.Keyword; A_arbace_main_A_Init(); tmp75 = A_arbace_main_A_const_132; if any(G__461000084__18_) == any(tmp75.Ref()) {









































		var tmp76 *lang.Var; A_arbace_main_A_Init(); tmp76 = A_arbace_main_A_const_133; return lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()).Invoke_O_O_O_O_O__O(Lit_230, cause_type__17, symbol__10, loc__14, cause__12) }
//line :282:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_231, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__461000084__18_))))) }








func A_arbace_main_ex_str_fn__461000085_A_New_O_O(p0, p1 any) *A_arbace_main_ex_str_fn__461000085_A { A_arbace_main_ex_str_fn__461000085_A_Init(); t := &A_arbace_main_ex_str_fn__461000085_A{}; t.Ctor_O_O(p0, p1); return t }
//line :291:1
func (t *A_arbace_main_ex_str_fn__461000085_A) Ctor_O_O(c__spec, c__s__1927001093__auto__ any) { t.F_spec = c__spec; t.F_s__1927001093__auto__ = c__s__1927001093__auto__ }
//line :291:1
func (t *A_arbace_main_ex_str_fn__461000085_A) Invoke_O__O(self any) any { var tmp1 any; tmp19 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_137; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var tmp5 *lang.Var
											A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_138; var tmp6 any = jrt.NN(tmp5).Get__O(); var tmp7 *lang.Var; A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_139; if lang.Util_Equiv_O_O__Z(tmp6, jrt.NN(tmp7).GetRawRoot__O()) {
												var tmp8 *lang.Var; A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_140; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; var t_ any = t.F_spec; t.F_spec = nil; tmp10 = t_; var tmp11 any = tmp10; var tmp12 *lang.Keyword; A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_98; var tmp13 any = tmp12.Ref(); var tmp14 any = A_arbace_main_ex_str_fn__461000085_fn__461000086_A_New(); var tmp15 *jrt.Class; A_arbace_main_ex_str_fn__461000085_fn__461000086_A_Init(); tmp15 = A_arbace_main_ex_str_fn__461000085_fn__461000086_A_fn_class; tmp4 = tmp9.Invoke_O_O_O__O(tmp11, tmp13, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil)) } else {
//line :293:1
				var t__2 any = t.F_spec; t.F_spec = nil; tmp4 = t__2 }
//line :292:1
		tmp3.Invoke_O__O(tmp4)
//line :291:1
		var tmp16 *lang.Var; A_arbace_main_A_Init(); tmp16 = A_arbace_main_A_const_86; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any; var t__3 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; tmp18 = t__3; tmp1 = tmp17.Invoke_O__O(tmp18) }; return nil }(); var tmp20 *lang.Var; A_arbace_main_A_Init(); tmp20 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke__O(); if tmp19 != nil { panic(tmp19) }; return tmp1 }



func A_arbace_main_ex_str_fn__461000085_fn__461000086_A_New() *A_arbace_main_ex_str_fn__461000085_fn__461000086_A { A_arbace_main_ex_str_fn__461000085_fn__461000086_A_Init(); t := &A_arbace_main_ex_str_fn__461000085_fn__461000086_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_A) Ctor() {}
//line :295:1
func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_A) Invoke_O_O__O(self, probs__1 any) any { var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_83; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_New(); var tmp4 *jrt.Class; A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_Init(); tmp4 = A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), probs__1) }
//line :295:1
func A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_New() *A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A { A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_Init(); t := &A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A) Ctor() {}
//line :295:1
func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A) Invoke_O_O__O(self, p1__461000079_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_105; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_141; return tmp2.Invoke_O_O__O(p1__461000079_SHARP___1, tmp3.Ref()) }



































func A_arbace_main_ex_str_fn__461000091_A_New_O_O(p0, p1 any) *A_arbace_main_ex_str_fn__461000091_A { A_arbace_main_ex_str_fn__461000091_A_Init(); t := &A_arbace_main_ex_str_fn__461000091_A{}; t.Ctor_O_O(p0, p1); return t }
//line :331:1
func (t *A_arbace_main_ex_str_fn__461000091_A) Ctor_O_O(c__spec, c__s__1927001093__auto__ any) { t.F_spec = c__spec; t.F_s__1927001093__auto__ = c__s__1927001093__auto__ }
//line :331:1
func (t *A_arbace_main_ex_str_fn__461000091_A) Invoke_O__O(self any) any { var tmp1 any; tmp19 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_137; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var tmp5 *lang.Var
											A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_138; var tmp6 any = jrt.NN(tmp5).Get__O(); var tmp7 *lang.Var; A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_139; if lang.Util_Equiv_O_O__Z(tmp6, jrt.NN(tmp7).GetRawRoot__O()) {
												var tmp8 *lang.Var; A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_140; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; var t_ any = t.F_spec; t.F_spec = nil; tmp10 = t_; var tmp11 any = tmp10; var tmp12 *lang.Keyword; A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_98; var tmp13 any = tmp12.Ref(); var tmp14 any = A_arbace_main_ex_str_fn__461000091_fn__461000092_A_New(); var tmp15 *jrt.Class; A_arbace_main_ex_str_fn__461000091_fn__461000092_A_Init(); tmp15 = A_arbace_main_ex_str_fn__461000091_fn__461000092_A_fn_class; tmp4 = tmp9.Invoke_O_O_O__O(tmp11, tmp13, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil)) } else {
//line :333:1
				var t__2 any = t.F_spec; t.F_spec = nil; tmp4 = t__2 }
//line :332:1
		tmp3.Invoke_O__O(tmp4)
//line :331:1
		var tmp16 *lang.Var; A_arbace_main_A_Init(); tmp16 = A_arbace_main_A_const_86; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any; var t__3 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; tmp18 = t__3; tmp1 = tmp17.Invoke_O__O(tmp18) }; return nil }(); var tmp20 *lang.Var; A_arbace_main_A_Init(); tmp20 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke__O(); if tmp19 != nil { panic(tmp19) }; return tmp1 }



func A_arbace_main_ex_str_fn__461000091_fn__461000092_A_New() *A_arbace_main_ex_str_fn__461000091_fn__461000092_A { A_arbace_main_ex_str_fn__461000091_fn__461000092_A_Init(); t := &A_arbace_main_ex_str_fn__461000091_fn__461000092_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_A) Ctor() {}
//line :335:1
func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_A) Invoke_O_O__O(self, probs__1 any) any { var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_83; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_New(); var tmp4 *jrt.Class; A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_Init(); tmp4 = A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), probs__1) }
//line :335:1
func A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_New() *A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A { A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_Init(); t := &A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A) Ctor() {}
//line :335:1
func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A) Invoke_O_O__O(self, p1__461000080_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_105; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_141; return tmp2.Invoke_O_O__O(p1__461000080_SHARP___1, tmp3.Ref()) }







func A_arbace_main_err__GT_msg_A_New() *A_arbace_main_err__GT_msg_A { A_arbace_main_err__GT_msg_A_Init(); t := &A_arbace_main_err__GT_msg_A{}; t.Ctor(); return t }
//line :343:1
func (t *A_arbace_main_err__GT_msg_A) Ctor() {}
//line :343:1
func (t *A_arbace_main_err__GT_msg_A) Invoke_O_O__O(self, e__0 any) any {


	var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_145; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_146; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_147; return tmp2.Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(e__0)))
}
func A_arbace_main_repl_caught_A_New() *A_arbace_main_repl_caught_A { A_arbace_main_repl_caught_A_Init(); t := &A_arbace_main_repl_caught_A{}; t.Ctor(); return t }
//line :348:1
func (t *A_arbace_main_repl_caught_A) Ctor() {}
//line :348:1
func (t *A_arbace_main_repl_caught_A) Invoke_O_O__O(self, e__0 any) any {


	var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_142; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_143; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_144; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_149; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :348:1
	var tmp8 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		{ var tmp9 *lang.Var; A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_150; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_151; tmp10.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(e__0))
			var tmp12 *lang.Var; A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_148; tmp8 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke__O() }
//line :348:1
		return nil }(); var tmp14 *lang.Var


	A_arbace_main_A_Init(); tmp14 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke__O()
//line :348:1
	if tmp13 != nil { panic(tmp13) }; return tmp8
}









func A_arbace_main_with_read_known_A_New() *A_arbace_main_with_read_known_A { A_arbace_main_with_read_known_A_Init(); t := &A_arbace_main_with_read_known_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_main_with_read_known_A) Ctor() {}
//line :359:1
func (t *A_arbace_main_with_read_known_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_19; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_20; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_21; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_152; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_21; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_23; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_main_A_Init(); tmp13 = A_arbace_main_A_const_24; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_main_A_Init(); tmp15 = A_arbace_main_A_const_19; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_main_A_Init(); tmp17 = A_arbace_main_A_const_20; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_main_A_Init(); tmp19 = A_arbace_main_A_const_21; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_main_A_Init(); tmp21 = A_arbace_main_A_const_153; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_main_A_Init(); tmp23 = A_arbace_main_A_const_21; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_main_A_Init(); tmp25 = A_arbace_main_A_const_19; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_main_A_Init(); tmp27 = A_arbace_main_A_const_20; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_main_A_Init(); tmp29 = A_arbace_main_A_const_21; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 any; A_arbace_main_A_Init(); tmp31 = A_arbace_main_A_const_154; var tmp32 any = tmp30.Invoke_O__O(tmp31); var tmp33 *lang.Var; A_arbace_main_A_Init(); tmp33 = A_arbace_main_A_const_21; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_main_A_Init(); tmp35 = A_arbace_main_A_const_19; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_main_A_Init(); tmp37 = A_arbace_main_A_const_20; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Var; A_arbace_main_A_Init(); tmp39 = A_arbace_main_A_const_21; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 any; A_arbace_main_A_Init(); tmp41 = A_arbace_main_A_const_155; var tmp42 any = tmp40.Invoke_O__O(tmp41); var tmp43 *lang.Var; A_arbace_main_A_Init(); tmp43 = A_arbace_main_A_const_21; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Keyword; A_arbace_main_A_Init(); tmp45 = A_arbace_main_A_const_156; var tmp46 any = tmp44.Invoke_O__O(tmp45.Ref()); var tmp47 *lang.Var; A_arbace_main_A_Init(); tmp47 = A_arbace_main_A_const_21; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 any; A_arbace_main_A_Init(); tmp49 = A_arbace_main_A_const_157; var tmp50 any = tmp34.Invoke_O__O(tmp36.Invoke_O__O(tmp38.Invoke_O_O_O__O(tmp42, tmp46, tmp48.Invoke_O__O(tmp49)))); var tmp51 *lang.Var; A_arbace_main_A_Init(); tmp51 = A_arbace_main_A_const_21; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp52.Invoke_O__O(tmp53.Ref()); var tmp55 *lang.Var; A_arbace_main_A_Init(); tmp55 = A_arbace_main_A_const_21; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 any; A_arbace_main_A_Init(); tmp57 = A_arbace_main_A_const_158; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp22, tmp24.Invoke_O__O(tmp26.Invoke_O__O(tmp28.Invoke_O_O_O_O__O(tmp32, tmp50, tmp54, tmp56.Invoke_O__O(tmp57)))))))), body__2)) }






func A_arbace_main_repl_A_New() *A_arbace_main_repl_A { A_arbace_main_repl_A_Init(); t := &A_arbace_main_repl_A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_main_repl_A) Ctor() {}
//line :366:1
func (t *A_arbace_main_repl_A) DoInvoke_O_O__O(self, options__0 any) any { var cl__2 any; var tmp1 any = jrt.Thread_CurrentThread__Thread(); var tmp2 *jrt.Class;











































	A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_181; var tmp3 *jrt.Class = tmp2; cl__2 = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp1, tmp3, Lit_281, jrt.RefArrayOf(jrt.Object_class)); var tmp4 any =
	jrt.Thread_CurrentThread__Thread(); var tmp5 *jrt.Class; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_181; var tmp6 *jrt.Class = tmp5; lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp4, tmp6, Lit_282, jrt.RefArrayOf(jrt.Object_class, cl__2)); var default__461000107__2 any; var tmp7 any = /*line :366:1*/A_arbace_main_repl_default__461000107__461000116_A_New(); var tmp8 *jrt.Class;













































	A_arbace_main_repl_default__461000107__461000116_A_Init(); tmp8 = A_arbace_main_repl_default__461000107__461000116_A_fn_class; default__461000107__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var default__461000108__3 any; var tmp9 /*line :366:1*/*lang.Var;















































	A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_75; if lang.LineNumberingPushbackReader_InstanceOf(jrt.NN(tmp9).Get__O()) { var tmp10 any = A_arbace_main_repl_fn__461000118_A_New(); var tmp11 *jrt.Class; A_arbace_main_repl_fn__461000118_A_Init(); tmp11 = A_arbace_main_repl_fn__461000118_A_fn_class; default__461000108__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil) } else { var tmp12 any = A_arbace_main_repl_fn__461000120_A_New(); var tmp13 *jrt.Class; A_arbace_main_repl_fn__461000120_A_Init(); tmp13 = A_arbace_main_repl_fn__461000120_A_fn_class; default__461000108__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil) }; var default__461000109__4 any; var tmp14 /*line :366:1*/*lang.Var; A_arbace_main_A_Init(); tmp14 = A_arbace_main_A_const_160; default__461000109__4 = jrt.NN(tmp14).GetRawRoot__O(); var default__461000110__5 any; var tmp15 *lang.Var; A_arbace_main_A_Init(); tmp15 = A_arbace_main_A_const_148; default__461000110__5 = jrt.NN(tmp15).GetRawRoot__O(); var default__461000111__6 any; var tmp16 *lang.Var; A_arbace_main_A_Init(); tmp16 = A_arbace_main_A_const_161; default__461000111__6 = jrt.NN(tmp16).GetRawRoot__O(); var default__461000112__7 any; var tmp17 *lang.Var; A_arbace_main_A_Init(); tmp17 = A_arbace_main_A_const_162; default__461000112__7 = jrt.NN(tmp17).GetRawRoot__O(); var default__461000113__8 any; var tmp18 *lang.Var; A_arbace_main_A_Init(); tmp18 = A_arbace_main_A_const_163; default__461000113__8 = jrt.NN(tmp18).GetRawRoot__O(); var default__461000114__9 any; var tmp19 *lang.Var; A_arbace_main_A_Init(); tmp19 = A_arbace_main_A_const_164; default__461000114__9 = jrt.NN(tmp19).GetRawRoot__O(); var map__461000105__10 any; var tmp20 *lang.Var;
























































	A_arbace_main_A_Init(); tmp20 = A_arbace_main_A_const_23; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_main_A_Init(); tmp22 = A_arbace_main_A_const_143; map__461000105__10 = tmp21.Invoke_O_O__O(jrt.NN(tmp22).GetRawRoot__O(), options__0); var map__461000105__11 any; if /*line :412:1*/ lang.ISeq_InstanceOf(map__461000105__10) { var tmp23 *lang.Var; A_arbace_main_A_Init(); tmp23 = A_arbace_main_A_const_67; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(map__461000105__10)) { var tmp24 *lang.Var; A_arbace_main_A_Init(); tmp24 = A_arbace_main_A_const_68; map__461000105__11 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(map__461000105__10), jrt.Object_class.ArrayClass())).Ref() } else { var tmp25 *lang.Var; A_arbace_main_A_Init(); tmp25 = A_arbace_main_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(map__461000105__10)) { var tmp26 *lang.Var; A_arbace_main_A_Init(); tmp26 = A_arbace_main_A_const_69; map__461000105__11 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(map__461000105__10) } else { lang.PersistentArrayMap_Init(); map__461000105__11 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000105__11 = map__461000105__10 }; var init__12 any; var tmp27 /*line :366:1*/*lang.Keyword;













































	A_arbace_main_A_Init(); tmp27 = A_arbace_main_A_const_165; init__12 = lang.RT_Get_O_O_O__O(map__461000105__11, tmp27.Ref(), default__461000107__2); var need_prompt__13 any; var tmp28 /*line :366:1*/*lang.Keyword;













































	A_arbace_main_A_Init(); tmp28 = A_arbace_main_A_const_166; need_prompt__13 = lang.RT_Get_O_O_O__O(map__461000105__11, tmp28.Ref(), default__461000108__3); var prompt__14 any; var tmp29 /*line :366:1*/*lang.Keyword;













































	A_arbace_main_A_Init(); tmp29 = A_arbace_main_A_const_167; prompt__14 = lang.RT_Get_O_O_O__O(map__461000105__11, tmp29.Ref(), default__461000109__4); var flush__15 any; var tmp30 /*line :366:1*/*lang.Keyword;













































	A_arbace_main_A_Init(); tmp30 = A_arbace_main_A_const_168; flush__15 = lang.RT_Get_O_O_O__O(map__461000105__11, tmp30.Ref(), default__461000110__5); var read__16 any; var tmp31 /*line :366:1*/*lang.Keyword;













































	A_arbace_main_A_Init(); tmp31 = A_arbace_main_A_const_169; read__16 = lang.RT_Get_O_O_O__O(map__461000105__11, tmp31.Ref(), default__461000111__6); var eval__17 any; var tmp32 /*line :366:1*/*lang.Keyword;













































	A_arbace_main_A_Init(); tmp32 = A_arbace_main_A_const_170; eval__17 = lang.RT_Get_O_O_O__O(map__461000105__11, tmp32.Ref(), default__461000112__7); var print__18 any; var tmp33 /*line :366:1*/*lang.Keyword;













































	A_arbace_main_A_Init(); tmp33 = A_arbace_main_A_const_171; print__18 = lang.RT_Get_O_O_O__O(map__461000105__11, tmp33.Ref(), default__461000113__8); var caught__19 any; var tmp34 /*line :366:1*/*lang.Keyword;













































	A_arbace_main_A_Init(); tmp34 = A_arbace_main_A_const_172; caught__19 = lang.RT_Get_O_O_O__O(map__461000105__11, tmp34.Ref(), default__461000114__9); var request_prompt__20 any = /*line :366:1*/jrt.Object_New(); var request_exit__21 any = jrt.Object_New(); var read_eval_print__22 any; var tmp35 any = A_arbace_main_repl_read_eval_print__461000122_A_New_O_O_O_O_O_O(request_prompt__20, read__16, caught__19, eval__17, request_exit__21, print__18); var tmp36 *jrt.Class;




























































	A_arbace_main_repl_read_eval_print__461000122_A_Init(); tmp36 = A_arbace_main_repl_read_eval_print__461000122_A_fn_class; read_eval_print__22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil); var tmp37 /*line :446:1*/*lang.Var; A_arbace_main_A_Init(); tmp37 = A_arbace_main_A_const_142; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Var; A_arbace_main_A_Init(); tmp39 = A_arbace_main_A_const_143; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 *lang.Var; A_arbace_main_A_Init(); tmp41 = A_arbace_main_A_const_58; var tmp42 any = tmp41.Ref(); var tmp43 *lang.Var; A_arbace_main_A_Init(); tmp43 = A_arbace_main_A_const_58; var tmp44 any = jrt.NN(tmp43).Get__O(); var tmp45 *lang.Var; A_arbace_main_A_Init(); tmp45 = A_arbace_main_A_const_182; var tmp46 any = tmp45.Ref(); var tmp47 *lang.Var; A_arbace_main_A_Init(); tmp47 = A_arbace_main_A_const_182; var tmp48 any = jrt.NN(tmp47).Get__O(); var tmp49 *lang.Var; A_arbace_main_A_Init(); tmp49 = A_arbace_main_A_const_183; var tmp50 any = tmp49.Ref(); var tmp51 *lang.Var; A_arbace_main_A_Init(); tmp51 = A_arbace_main_A_const_183; var tmp52 any = jrt.NN(tmp51).Get__O(); var tmp53 *lang.Var; A_arbace_main_A_Init(); tmp53 = A_arbace_main_A_const_184; var tmp54 any = tmp53.Ref(); var tmp55 *lang.Var; A_arbace_main_A_Init(); tmp55 = A_arbace_main_A_const_184; var tmp56 any = jrt.NN(tmp55).Get__O(); var tmp57 *lang.Var; A_arbace_main_A_Init(); tmp57 = A_arbace_main_A_const_185; var tmp58 any = tmp57.Ref(); var tmp59 *lang.Var; A_arbace_main_A_Init(); tmp59 = A_arbace_main_A_const_185; var tmp60 any = jrt.NN(tmp59).Get__O(); var tmp61 *lang.Var; A_arbace_main_A_Init(); tmp61 = A_arbace_main_A_const_186; var tmp62 any = tmp61.Ref(); var tmp63 *lang.Var; A_arbace_main_A_Init(); tmp63 = A_arbace_main_A_const_186; var tmp64 any = jrt.NN(tmp63).Get__O(); var tmp65 *lang.Var; A_arbace_main_A_Init(); tmp65 = A_arbace_main_A_const_187; var tmp66 any = tmp65.Ref(); var tmp67 *jrt.Boolean; jrt.Boolean_Init(); tmp67 = jrt.Boolean_TRUE; var tmp68 any = tmp67.Ref(); var tmp69 *lang.Var; A_arbace_main_A_Init(); tmp69 = A_arbace_main_A_const_188; var tmp70 any = tmp69.Ref(); var tmp71 *lang.Var; A_arbace_main_A_Init(); tmp71 = A_arbace_main_A_const_188; var tmp72 any = jrt.NN(tmp71).Get__O(); var tmp73 *lang.Var; A_arbace_main_A_Init(); tmp73 = A_arbace_main_A_const_189; var tmp74 any = tmp73.Ref(); var tmp75 *lang.Var; A_arbace_main_A_Init(); tmp75 = A_arbace_main_A_const_189; var tmp76 any = jrt.NN(tmp75).Get__O(); var tmp77 *lang.Var; A_arbace_main_A_Init(); tmp77 = A_arbace_main_A_const_190; var tmp78 any = tmp77.Ref(); var tmp79 any = jrt.System_GetProperty_String_String__String(Lit_276, Lit_277).Ref(); var tmp80 *lang.Var; A_arbace_main_A_Init(); tmp80 = A_arbace_main_A_const_191; var tmp81 any = tmp80.Ref(); var tmp82 *lang.Var; A_arbace_main_A_Init(); tmp82 = A_arbace_main_A_const_191; var tmp83 any = jrt.NN(tmp82).Get__O(); var tmp84 *lang.Var; A_arbace_main_A_Init(); tmp84 = A_arbace_main_A_const_192; var tmp85 any = tmp84.Ref(); var tmp86 *lang.Var; A_arbace_main_A_Init(); tmp86 = A_arbace_main_A_const_192; var tmp87 any = jrt.NN(tmp86).Get__O(); var tmp88 *lang.Var; A_arbace_main_A_Init(); tmp88 = A_arbace_main_A_const_193; var tmp89 any = tmp88.Ref(); var tmp90 *lang.Var; A_arbace_main_A_Init(); tmp90 = A_arbace_main_A_const_193; var tmp91 any = jrt.NN(tmp90).Get__O(); var tmp92 *lang.Var; A_arbace_main_A_Init(); tmp92 = A_arbace_main_A_const_138; var tmp93 any = tmp92.Ref(); var tmp94 *lang.Var; A_arbace_main_A_Init(); tmp94 = A_arbace_main_A_const_138; var tmp95 any = jrt.NN(tmp94).Get__O(); var tmp96 *lang.Var; A_arbace_main_A_Init(); tmp96 = A_arbace_main_A_const_178; var tmp97 any = tmp96.Ref(); var tmp98 *lang.Var; A_arbace_main_A_Init(); tmp98 = A_arbace_main_A_const_177; var tmp99 any = tmp98.Ref(); var tmp100 *lang.Var; A_arbace_main_A_Init(); tmp100 = A_arbace_main_A_const_176; var tmp101 any = tmp100.Ref(); var tmp102 *lang.Var; A_arbace_main_A_Init(); tmp102 = A_arbace_main_A_const_180; tmp38.Invoke_O__O(tmp40.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp42, tmp44, tmp46, tmp48, tmp50, tmp52, tmp54, tmp56, tmp58, tmp60, tmp62, tmp64, tmp66, tmp68, tmp70, tmp72, tmp74, tmp76, tmp78, tmp79, tmp81, tmp83, tmp85, tmp87, tmp89, tmp91, tmp93, tmp95, tmp97, nil, tmp99, nil, tmp101, nil, tmp102.Ref(), nil))))); var tmp103 any; tmp117 := /*line :366:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
















































































		{ var tmp104 *lang.Var; A_arbace_main_A_Init(); tmp104 = A_arbace_main_A_const_142; var tmp105 lang.IFn = lang.IFn_Cast(jrt.NN(tmp104).GetRawRoot__O()); var tmp106 *lang.Var; A_arbace_main_A_Init(); tmp106 = A_arbace_main_A_const_143; var tmp107 lang.IFn = lang.IFn_Cast(jrt.NN(tmp106).GetRawRoot__O()); var tmp108 *lang.Var; A_arbace_main_A_Init(); tmp108 = A_arbace_main_A_const_194; var tmp109 any = tmp108.Ref(); var tmp110 *jrt.Boolean; jrt.Boolean_Init(); tmp110 = jrt.Boolean_TRUE; tmp105.Invoke_O__O(tmp107.Invoke_O_O__O(tmp109, tmp110.Ref())); tmp115 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
			{ var tmp111 any = A_arbace_main_repl_fn__461000128_A_New_O_O(init__12, caught__19); var tmp112 *jrt.Class; A_arbace_main_repl_fn__461000128_A_Init(); tmp112 = A_arbace_main_repl_fn__461000128_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp111, tmp112, nil).Invoke__O()




				lang.IFn_Cast(prompt__14).Invoke__O()
				lang.IFn_Cast(flush__15).Invoke__O()
//line :366:1
			L1: for {

























































































				var tmp113 any = A_arbace_main_repl_fn__461000130_A_New_O_O_O(caught__19, request_exit__21, read_eval_print__22); var tmp114 *jrt.Class; A_arbace_main_repl_fn__461000130_A_Init(); tmp114 = A_arbace_main_repl_fn__461000130_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp113, tmp114, nil).Invoke__O()) { tmp103 = nil } else {





					if jrt.A2g_Truth(lang.IFn_Cast(need_prompt__13).Invoke__O()) {
						lang.IFn_Cast(prompt__14).Invoke__O()
						lang.IFn_Cast(flush__15).Invoke__O() }
					continue L1 }
//line :366:1
				break L1
			}
			}














































































			return nil }(); var tmp116 *lang.Var; A_arbace_main_A_Init(); tmp116 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp116).GetRawRoot__O()).Invoke__O()
//line :366:1
			if tmp115 != nil { panic(tmp115) } }; return nil }(); var tmp118 *lang.Var;















































































	A_arbace_main_A_Init(); tmp118 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp118).GetRawRoot__O()).Invoke__O(); if /*line :366:1*/ tmp117 != nil { panic(tmp117) }; return tmp103 }













































func A_arbace_main_repl_default__461000107__461000116_A_New() *A_arbace_main_repl_default__461000107__461000116_A { A_arbace_main_repl_default__461000107__461000116_A_Init(); t := &A_arbace_main_repl_default__461000107__461000116_A{}; t.Ctor(); return t }
//line :412:1
func (t *A_arbace_main_repl_default__461000107__461000116_A) Ctor() {}
//line :412:1
func (t *A_arbace_main_repl_default__461000107__461000116_A) Invoke_O__O(self any) any { lang.PersistentList_Init(); return lang.PersistentList_EMPTY.Ref() }

func A_arbace_main_repl_fn__461000118_A_New() *A_arbace_main_repl_fn__461000118_A { A_arbace_main_repl_fn__461000118_A_Init(); t := &A_arbace_main_repl_fn__461000118_A{}; t.Ctor(); return t }
//line :414:1
func (t *A_arbace_main_repl_fn__461000118_A) Ctor() {}
//line :414:1
func (t *A_arbace_main_repl_fn__461000118_A) Invoke_O__O(self any) any {
	var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_75; return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(lang.LineNumberingPushbackReader_Cast(jrt.NN(tmp1).Get__O())).AtLineStart__Z()).Ref() }
//line :414:1
func A_arbace_main_repl_fn__461000120_A_New() *A_arbace_main_repl_fn__461000120_A { A_arbace_main_repl_fn__461000120_A_Init(); t := &A_arbace_main_repl_fn__461000120_A{}; t.Ctor(); return t }
//line :414:1
func (t *A_arbace_main_repl_fn__461000120_A) Ctor() {}
//line :414:1
func (t *A_arbace_main_repl_fn__461000120_A) Invoke_O__O(self any) any {

	var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_159; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_TRUE; return tmp2.Invoke_O__O(tmp3.Ref())
}









func A_arbace_main_repl_read_eval_print__461000122_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_main_repl_read_eval_print__461000122_A { A_arbace_main_repl_read_eval_print__461000122_A_Init(); t := &A_arbace_main_repl_read_eval_print__461000122_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :427:1
func (t *A_arbace_main_repl_read_eval_print__461000122_A) Ctor_O_O_O_O_O_O(c__request_prompt, c__read, c__caught, c__eval, c__request_exit, c__print any) { t.F_request_prompt = c__request_prompt; t.F_read = c__read; t.F_caught = c__caught; t.F_eval = c__eval; t.F_request_exit = c__request_exit; t.F_print = c__print }
//line :427:1
func (t *A_arbace_main_repl_read_eval_print__461000122_A) Invoke_O__O(self any) any { var tmp1 any; tmp23 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var read_eval__3 any; var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_173; read_eval__3 = jrt.NN(tmp2).Get__O(); var input__4 any; var tmp3 any = A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_New_O_O_O(t.F_request_prompt, t.F_read, t.F_request_exit); var tmp4 *jrt.Class


	A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_Init(); tmp4 = A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_fn_class; input__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
//line :427:1
	var or__1927000174__auto____5 any = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, t.F_request_exit, t.F_request_prompt))).Invoke_O__O(input__4)






	if jrt.A2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { var value__6 any; var tmp5 *lang.Var
		A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_142; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_143; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_173; tmp6.Invoke_O__O(tmp8.Invoke_O_O__O(tmp9.Ref(), read_eval__3)); var tmp10 any = A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_New_O_O(input__4, t.F_eval); var tmp11 *jrt.Class; A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_Init(); tmp11 = A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_fn_class; value__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil).Invoke__O()
//line :434:1
		var tmp12 *lang.Var; A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_176; var tmp13 *lang.Var = tmp12; var tmp14 *lang.Var; A_arbace_main_A_Init(); tmp14 = A_arbace_main_A_const_177; jrt.NN(tmp13).Set_O__O(jrt.NN(tmp14).Get__O()); var tmp15 *lang.Var; A_arbace_main_A_Init(); tmp15 = A_arbace_main_A_const_177; var tmp16 *lang.Var = tmp15; var tmp17 *lang.Var; A_arbace_main_A_Init(); tmp17 = A_arbace_main_A_const_178; jrt.NN(tmp16).Set_O__O(jrt.NN(tmp17).Get__O()); var tmp18 *lang.Var; A_arbace_main_A_Init(); tmp18 = A_arbace_main_A_const_178; jrt.NN(tmp18).Set_O__O(value__6); tmp19 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





			tmp1 = lang.IFn_Cast(t.F_print).Invoke_O__O(value__6)
//line :434:1
			return nil }(); if tmp19 != nil { if true { var e__9 jrt.Throwable_I = tmp19; var tmp20 *lang.Var; A_arbace_main_A_Init(); tmp20 = A_arbace_main_A_const_174; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 any; A_arbace_main_A_Init(); tmp22 = A_arbace_main_A_const_179; panic(jrt.Thrown(jrt.Throwable_Cast(tmp21.Invoke_O_O_O__O(nil, tmp22, e__9)))) } } } }; return nil }(); if /*line :427:1*/ tmp23 != nil { if true { var e__3 jrt.Throwable_I = tmp23
















				lang.IFn_Cast(t.F_caught).Invoke_O__O(e__3)
//line :427:1
				var tmp24 *lang.Var; A_arbace_main_A_Init(); tmp24 = A_arbace_main_A_const_180; tmp1 = jrt.NN(tmp24).Set_O__O(e__3) } }; return tmp1 }


func A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_New_O_O_O(p0, p1, p2 any) *A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A { A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_Init(); t := &A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :430:1
func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A) Ctor_O_O_O(c__request_prompt, c__read, c__request_exit any) { t.F_request_prompt = c__request_prompt; t.F_read = c__read; t.F_request_exit = c__request_exit }
//line :430:1
func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A) Invoke_O__O(self any) any { var tmp1 any; tmp20 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_142; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_143; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_173; var tmp7 any = tmp6.Ref(); var tmp8 any; var tmp9 *lang.Keyword; A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_156; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Var; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_173; if lang.Util_Equiv_O_O__Z(tmp10, jrt.NN(tmp11).Get__O()) { jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE.Ref() } else { var tmp12 *lang.Var; A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_173; tmp8 = jrt.NN(tmp12).Get__O() }; tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(tmp7, tmp8)); tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp13 any; var t_ any = t.F_read; t.F_read = nil; tmp13 = t_; var tmp14 lang.IFn = lang.IFn_Cast(tmp13); var tmp15 any; var t__2 any = t.F_request_prompt; t.F_request_prompt = nil; tmp15 = t__2; var tmp16 any = tmp15; var tmp17 any; var t__3 any = t.F_request_exit; t.F_request_exit = nil; tmp17 = t__3; tmp1 = tmp14.Invoke_O_O__O(tmp16, tmp17) }; return nil }(); var tmp19 *lang.Var; A_arbace_main_A_Init(); tmp19 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke__O()
//line :430:1
		if tmp18 != nil { panic(tmp18) } }; return nil }(); if tmp20 != nil { if lang.LispReader_ReaderException_InstanceOf(tmp20) { var e__3 *lang.LispReader_ReaderException = lang.LispReader_ReaderException_Cast(tmp20); var tmp21 *lang.Var; A_arbace_main_A_Init(); tmp21 = A_arbace_main_A_const_174; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any; A_arbace_main_A_Init(); tmp23 = A_arbace_main_A_const_175; panic(jrt.Thrown(jrt.Throwable_Cast(tmp22.Invoke_O_O_O__O(nil, tmp23, e__3.Ref())))) } else { panic(tmp20) } }; return tmp1 }




func A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_New_O_O(p0, p1 any) *A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A { A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_Init(); t := &A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A{}; t.Ctor_O_O(p0, p1); return t }
//line :435:1
func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A) Ctor_O_O(c__input, c__eval any) { t.F_input = c__input; t.F_eval = c__eval }
//line :435:1
func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_eval; t.F_eval = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_input; t.F_input = nil; tmp4 = t__2; tmp1 = tmp3.Invoke_O__O(tmp4) }; return nil }(); var tmp6 *lang.Var; A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }












func A_arbace_main_repl_fn__461000128_A_New_O_O(p0, p1 any) *A_arbace_main_repl_fn__461000128_A { A_arbace_main_repl_fn__461000128_A_Init(); t := &A_arbace_main_repl_fn__461000128_A{}; t.Ctor_O_O(p0, p1); return t }
//line :448:1
func (t *A_arbace_main_repl_fn__461000128_A) Ctor_O_O(c__init, c__caught any) { t.F_init = c__init; t.F_caught = c__caught }
//line :448:1
func (t *A_arbace_main_repl_fn__461000128_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
									{ var tmp2 any; var t_ any = t.F_init; t.F_init = nil; tmp2 = t_; tmp1 = lang.IFn_Cast(tmp2).Invoke__O() }
//line :448:1
	return nil }(); if tmp3 != nil { if true { var e__3 jrt.Throwable_I = tmp3; var tmp4 any; var t__2 any = t.F_caught


		t.F_caught = nil; tmp4 = t__2; lang.IFn_Cast(tmp4).Invoke_O__O(e__3)
//line :448:1
		var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_180; tmp1 = jrt.NN(tmp5).Set_O__O(e__3) } }; return tmp1 }








func A_arbace_main_repl_fn__461000130_A_New_O_O_O(p0, p1, p2 any) *A_arbace_main_repl_fn__461000130_A { A_arbace_main_repl_fn__461000130_A_Init(); t := &A_arbace_main_repl_fn__461000130_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :457:1
func (t *A_arbace_main_repl_fn__461000130_A) Ctor_O_O_O(c__caught, c__request_exit, c__read_eval_print any) { t.F_caught = c__caught; t.F_request_exit = c__request_exit; t.F_read_eval_print = c__read_eval_print }
//line :457:1
func (t *A_arbace_main_repl_fn__461000130_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_read_eval_print; t.F_read_eval_print = nil; tmp2 = t_; var tmp3 any = lang.IFn_Cast(tmp2).Invoke__O(); var tmp4 any; var t__2 any = t.F_request_exit; t.F_request_exit = nil; tmp4 = t__2; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(tmp3, tmp4)).Ref() }; return nil }(); if tmp5 != nil { if true { var e__3 jrt.Throwable_I = tmp5; var tmp6 any; var t__3 any = t.F_caught

	t.F_caught = nil; tmp6 = t__3; lang.IFn_Cast(tmp6).Invoke_O__O(e__3)
//line :457:1
	var tmp7 *lang.Var; A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_180; jrt.NN(tmp7).Set_O__O(e__3); tmp1 = nil } }; return tmp1 }









func A_arbace_main_load_script_A_New() *A_arbace_main_load_script_A { A_arbace_main_load_script_A_Init(); t := &A_arbace_main_load_script_A{}; t.Ctor(); return t }
//line :467:1
func (t *A_arbace_main_load_script_A) Ctor() {}
//line :467:1
func (t *A_arbace_main_load_script_A) Invoke_O_O__O(self, path__0 any) any {





	if jrt.NN(jrt.String_Cast(path__0)).StartsWith_String__Z(Lit_262) {

		var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_195; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_196; return lang.IFn_Cast(tmp2.Invoke_O__O(tmp3)).Invoke_O__O(jrt.NN(jrt.String_Cast(path__0)).Substring_I__String(lang.RT_IntCast_J__I(4)).Ref()) } else {
//line :473:1
			if jrt.NN(jrt.String_Cast(path__0)).StartsWith_String__Z(Lit_263) {



				var tmp4 *jrt.String = jrt.String_Cast(path__0); var tmp5 int64
				if jrt.NN(jrt.String_Cast(path__0)).StartsWith_String__Z(Lit_264) { tmp5 = 2 } else { tmp5 = 1 }
//line :477:1
				lang.RT_LoadResourceScript_String__V(jrt.NN(tmp4).Substring_I__String(lang.RT_IntCast_J__I(tmp5))); return nil } else {
//line :473:1
					var tmp6 *lang.Keyword; A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_62; if tmp6 != nil {






						return lang.Compiler_LoadFile_String__O(jrt.String_Cast(path__0)) } else {
//line :473:1
							return nil
						}
				}
		}
}




func A_arbace_main_init_opt_A_New() *A_arbace_main_init_opt_A { A_arbace_main_init_opt_A_Init(); t := &A_arbace_main_init_opt_A{}; t.Ctor(); return t }
//line :482:1
func (t *A_arbace_main_init_opt_A) Ctor() {}
//line :482:1
func (t *A_arbace_main_init_opt_A) Invoke_O_O__O(self, path__0 any) any {


	var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_197; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(path__0)
}
func A_arbace_main_eval_opt_A_New() *A_arbace_main_eval_opt_A { A_arbace_main_eval_opt_A_Init(); t := &A_arbace_main_eval_opt_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_main_eval_opt_A) Ctor() {}
//line :487:1
func (t *A_arbace_main_eval_opt_A) Invoke_O_O__O(self, str__0 any) any { { var eof__2 any = jrt.Object_New(); var reader__3 any = lang.LineNumberingPushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(str__0))); var input__4 any; var tmp1 *lang.Var




	A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_142; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_143; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_173; var tmp6 any = tmp5.Ref(); var tmp7 any; var tmp8 *lang.Keyword; A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_156; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Var; A_arbace_main_A_Init(); tmp10 = A_arbace_main_A_const_173; if lang.Util_Equiv_O_O__Z(tmp9, jrt.NN(tmp10).Get__O()) { jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE.Ref() } else { var tmp11 *lang.Var; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_173; tmp7 = jrt.NN(tmp11).Get__O() }; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, tmp7)); var tmp12 any = A_arbace_main_eval_opt_fn__461000135_A_New_O_O(reader__3, eof__2); var tmp13 *jrt.Class; A_arbace_main_eval_opt_fn__461000135_A_Init(); tmp13 = A_arbace_main_eval_opt_fn__461000135_A_fn_class; input__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil).Invoke__O()
//line :487:1
L1: for {





	if lang.Util_Equiv_O_O__Z(input__4, eof__2) { return nil } else { var value__5 any; var tmp14 *lang.Var
		A_arbace_main_A_Init(); tmp14 = A_arbace_main_A_const_162; value__5 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(input__4)
		if lang.Util_Identical_O_O__Z(value__5, nil) { } else {
			var tmp15 *lang.Var; A_arbace_main_A_Init(); tmp15 = A_arbace_main_A_const_163; lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(value__5) }
		var tmp16 any; var tmp17 *lang.Var; A_arbace_main_A_Init(); tmp17 = A_arbace_main_A_const_142; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_main_A_Init(); tmp19 = A_arbace_main_A_const_143; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_main_A_Init(); tmp21 = A_arbace_main_A_const_173; var tmp22 any = tmp21.Ref(); var tmp23 any; var tmp24 *lang.Keyword; A_arbace_main_A_Init(); tmp24 = A_arbace_main_A_const_156; var tmp25 any = tmp24.Ref(); var tmp26 *lang.Var; A_arbace_main_A_Init(); tmp26 = A_arbace_main_A_const_173; if lang.Util_Equiv_O_O__Z(tmp25, jrt.NN(tmp26).Get__O()) { jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE.Ref() } else { var tmp27 *lang.Var; A_arbace_main_A_Init(); tmp27 = A_arbace_main_A_const_173; tmp23 = jrt.NN(tmp27).Get__O() }; tmp18.Invoke_O__O(tmp20.Invoke_O_O__O(tmp22, tmp23)); var tmp28 any = A_arbace_main_eval_opt_fn__461000137_A_New_O_O(reader__3, eof__2); var tmp29 *jrt.Class; A_arbace_main_eval_opt_fn__461000137_A_Init(); tmp29 = A_arbace_main_eval_opt_fn__461000137_A_fn_class; tmp16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil).Invoke__O(); input__4 = tmp16; continue L1 } } }; /*line :487:1*/panic("a2g: unreachable") }




func A_arbace_main_eval_opt_fn__461000135_A_New_O_O(p0, p1 any) *A_arbace_main_eval_opt_fn__461000135_A { A_arbace_main_eval_opt_fn__461000135_A_Init(); t := &A_arbace_main_eval_opt_fn__461000135_A{}; t.Ctor_O_O(p0, p1); return t }
//line :492:1
func (t *A_arbace_main_eval_opt_fn__461000135_A) Ctor_O_O(c__reader, c__eof any) { t.F_reader = c__reader; t.F_eof = c__eof }
//line :492:1
func (t *A_arbace_main_eval_opt_fn__461000135_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_72; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_reader; t.F_reader = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_FALSE; var tmp7 any = tmp6.Ref(); var tmp8 any; var t__2 any = t.F_eof; t.F_eof = nil; tmp8 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp7, tmp8) }; return nil }(); var tmp10 *lang.Var; A_arbace_main_A_Init(); tmp10 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke__O(); if tmp9 != nil { panic(tmp9) }; return tmp1 }




func A_arbace_main_eval_opt_fn__461000137_A_New_O_O(p0, p1 any) *A_arbace_main_eval_opt_fn__461000137_A { A_arbace_main_eval_opt_fn__461000137_A_Init(); t := &A_arbace_main_eval_opt_fn__461000137_A{}; t.Ctor_O_O(p0, p1); return t }
//line :497:1
func (t *A_arbace_main_eval_opt_fn__461000137_A) Ctor_O_O(c__reader, c__eof any) { t.F_reader = c__reader; t.F_eof = c__eof }
//line :497:1
func (t *A_arbace_main_eval_opt_fn__461000137_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_72; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_reader; t.F_reader = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_FALSE; var tmp7 any = tmp6.Ref(); var tmp8 any; var t__2 any = t.F_eof; t.F_eof = nil; tmp8 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp7, tmp8) }; return nil }(); var tmp10 *lang.Var; A_arbace_main_A_Init(); tmp10 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke__O(); if tmp9 != nil { panic(tmp9) }; return tmp1 }

func A_arbace_main_init_dispatch_A_New() *A_arbace_main_init_dispatch_A { A_arbace_main_init_dispatch_A_Init(); t := &A_arbace_main_init_dispatch_A{}; t.Ctor(); return t }
//line :499:1
func (t *A_arbace_main_init_dispatch_A) Ctor() {}
//line :499:1
func (t *A_arbace_main_init_dispatch_A) Invoke_O_O__O(self, opt__0 any) any {


	var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_198; var tmp2 any = jrt.NN(tmp1).GetRawRoot__O(); var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_198; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_199; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Var; A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_199; return lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_246, tmp2, Lit_247, tmp4, Lit_248, tmp6, Lit_249, jrt.NN(tmp7).GetRawRoot__O()))).Invoke_O__O(opt__0)
}



func A_arbace_main_initialize_A_New() *A_arbace_main_initialize_A { A_arbace_main_initialize_A_Init(); t := &A_arbace_main_initialize_A{}; t.Ctor(); return t }
//line :507:1
func (t *A_arbace_main_initialize_A) Ctor() {}
//line :507:1
func (t *A_arbace_main_initialize_A) Invoke_O_O_O__O(self, args__0, inits__1 any) any {


	{ var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_202; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_203; tmp2.Invoke_O__O(tmp3)
//line :507:1
		var tmp4 *lang.Var; A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_191; jrt.NN(tmp4).Set_O__O(args__0); var seq_461000141__3 any; var tmp5 *lang.Var




		A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_19; seq_461000141__3 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(inits__1)
//line :507:1
		var chunk_461000142__4 any; var count_461000143__5 int64 = 0; var i_461000144__6 int64 = 0; L1: for {




			if lang.Numbers_Lt_J_J__Z(i_461000144__6, count_461000143__5) { var vec__461000145__7 any = lang.Indexed_Cast(chunk_461000142__4).Nth_I__O(lang.RT_IntCast_J__I(i_461000144__6)); var opt__8 any = lang.RT_Nth_O_I_O__O(vec__461000145__7, lang.RT_IntCast_J__I(0), nil); var arg__9 any = lang.RT_Nth_O_I_O__O(vec__461000145__7, lang.RT_IntCast_J__I(1), nil); var tmp6 *lang.Var
				A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_204; lang.IFn_Cast(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(opt__8)).Invoke_O__O(arg__9)
//line :512:1
				seq_461000141__3, chunk_461000142__4, count_461000143__5, i_461000144__6 = seq_461000141__3, chunk_461000142__4, count_461000143__5, lang.Numbers_Unchecked_inc_J__J(i_461000144__6); continue L1 } else { var temp__1927000414__auto____7 any; var tmp7 *lang.Var; A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_19; temp__1927000414__auto____7 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq_461000141__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_461000141__8 any = temp__1927000414__auto____7; var tmp8 *lang.Var; A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_200; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq_461000141__8)) { var c__1927000678__auto____9 any; var tmp9 *lang.Var; A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_201; c__1927000678__auto____9 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq_461000141__8); var tmp10 *lang.Var; A_arbace_main_A_Init(); tmp10 = A_arbace_main_A_const_205; seq_461000141__3, chunk_461000142__4, count_461000143__5, i_461000144__6 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq_461000141__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__461000148__9 any; var tmp11 *lang.Var; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_69; vec__461000148__9 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq_461000141__8); var opt__10 any = lang.RT_Nth_O_I_O__O(vec__461000148__9, lang.RT_IntCast_J__I(0), nil); var arg__11 any = lang.RT_Nth_O_I_O__O(vec__461000148__9, lang.RT_IntCast_J__I(1), nil); var tmp12 *lang.Var
					A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_204; lang.IFn_Cast(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(opt__10)).Invoke_O__O(arg__11)
//line :512:1
					var tmp13 *lang.Var; A_arbace_main_A_Init(); tmp13 = A_arbace_main_A_const_67; seq_461000141__3, chunk_461000142__4, count_461000143__5, i_461000144__6 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(seq_461000141__8), nil, 0, 0; continue L1 } } else { return nil } } } }
//line :507:1
	panic("a2g: unreachable")
}






func A_arbace_main_main_opt_A_New() *A_arbace_main_main_opt_A { A_arbace_main_main_opt_A_Init(); t := &A_arbace_main_main_opt_A{}; t.Ctor(); return t }
//line :515:1
func (t *A_arbace_main_main_opt_A) Ctor() {}
//line :515:1
func (t *A_arbace_main_main_opt_A) Invoke_O_O_O__O(self, p__461000152__0, inits__1 any) any { var vec__461000153__3 any = p__461000152__0; var seq__461000154__4 any; var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_19; seq__461000154__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__461000153__3); var first__461000155__5 any; var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_69; first__461000155__5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__461000154__4); var seq__461000154__6 any; var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_67; seq__461000154__6 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__461000154__4); var ___7 any = first__461000155__5; var first__461000155__8 any; var tmp4 *lang.Var; _ = ___7; A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_69; first__461000155__8 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__461000154__6); var seq__461000154__9 any; var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_67; seq__461000154__9 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__461000154__6); var main_ns__10 any = first__461000155__8; var args__11 any = seq__461000154__9; var tmp6 *lang.Var;



	A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_142; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_143; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_main_A_Init(); tmp10 = A_arbace_main_A_const_58; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Var; A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_58; var tmp13 any = jrt.NN(tmp12).Get__O(); var tmp14 *lang.Var; A_arbace_main_A_Init(); tmp14 = A_arbace_main_A_const_182; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Var; A_arbace_main_A_Init(); tmp16 = A_arbace_main_A_const_182; var tmp17 any = jrt.NN(tmp16).Get__O(); var tmp18 *lang.Var; A_arbace_main_A_Init(); tmp18 = A_arbace_main_A_const_183; var tmp19 any = tmp18.Ref(); var tmp20 *lang.Var; A_arbace_main_A_Init(); tmp20 = A_arbace_main_A_const_183; var tmp21 any = jrt.NN(tmp20).Get__O(); var tmp22 *lang.Var; A_arbace_main_A_Init(); tmp22 = A_arbace_main_A_const_184; var tmp23 any = tmp22.Ref(); var tmp24 *lang.Var; A_arbace_main_A_Init(); tmp24 = A_arbace_main_A_const_184; var tmp25 any = jrt.NN(tmp24).Get__O(); var tmp26 *lang.Var; A_arbace_main_A_Init(); tmp26 = A_arbace_main_A_const_185; var tmp27 any = tmp26.Ref(); var tmp28 *lang.Var; A_arbace_main_A_Init(); tmp28 = A_arbace_main_A_const_185; var tmp29 any = jrt.NN(tmp28).Get__O(); var tmp30 *lang.Var; A_arbace_main_A_Init(); tmp30 = A_arbace_main_A_const_186; var tmp31 any = tmp30.Ref(); var tmp32 *lang.Var; A_arbace_main_A_Init(); tmp32 = A_arbace_main_A_const_186; var tmp33 any = jrt.NN(tmp32).Get__O(); var tmp34 *lang.Var; A_arbace_main_A_Init(); tmp34 = A_arbace_main_A_const_187; var tmp35 any = tmp34.Ref(); var tmp36 *jrt.Boolean; jrt.Boolean_Init(); tmp36 = jrt.Boolean_TRUE; var tmp37 any = tmp36.Ref(); var tmp38 *lang.Var; A_arbace_main_A_Init(); tmp38 = A_arbace_main_A_const_188; var tmp39 any = tmp38.Ref(); var tmp40 *lang.Var; A_arbace_main_A_Init(); tmp40 = A_arbace_main_A_const_188; var tmp41 any = jrt.NN(tmp40).Get__O(); var tmp42 *lang.Var; A_arbace_main_A_Init(); tmp42 = A_arbace_main_A_const_189; var tmp43 any = tmp42.Ref(); var tmp44 *lang.Var; A_arbace_main_A_Init(); tmp44 = A_arbace_main_A_const_189; var tmp45 any = jrt.NN(tmp44).Get__O(); var tmp46 *lang.Var; A_arbace_main_A_Init(); tmp46 = A_arbace_main_A_const_190; var tmp47 any = tmp46.Ref(); var tmp48 any = jrt.System_GetProperty_String_String__String(Lit_276, Lit_277).Ref(); var tmp49 *lang.Var; A_arbace_main_A_Init(); tmp49 = A_arbace_main_A_const_191; var tmp50 any = tmp49.Ref(); var tmp51 *lang.Var; A_arbace_main_A_Init(); tmp51 = A_arbace_main_A_const_191; var tmp52 any = jrt.NN(tmp51).Get__O(); var tmp53 *lang.Var; A_arbace_main_A_Init(); tmp53 = A_arbace_main_A_const_192; var tmp54 any = tmp53.Ref(); var tmp55 *lang.Var; A_arbace_main_A_Init(); tmp55 = A_arbace_main_A_const_192; var tmp56 any = jrt.NN(tmp55).Get__O(); var tmp57 *lang.Var; A_arbace_main_A_Init(); tmp57 = A_arbace_main_A_const_193; var tmp58 any = tmp57.Ref(); var tmp59 *lang.Var; A_arbace_main_A_Init(); tmp59 = A_arbace_main_A_const_193; var tmp60 any = jrt.NN(tmp59).Get__O(); var tmp61 *lang.Var; A_arbace_main_A_Init(); tmp61 = A_arbace_main_A_const_138; var tmp62 any = tmp61.Ref(); var tmp63 *lang.Var; A_arbace_main_A_Init(); tmp63 = A_arbace_main_A_const_138; var tmp64 any = jrt.NN(tmp63).Get__O(); var tmp65 *lang.Var; A_arbace_main_A_Init(); tmp65 = A_arbace_main_A_const_178; var tmp66 any = tmp65.Ref(); var tmp67 *lang.Var; A_arbace_main_A_Init(); tmp67 = A_arbace_main_A_const_177; var tmp68 any = tmp67.Ref(); var tmp69 *lang.Var; A_arbace_main_A_Init(); tmp69 = A_arbace_main_A_const_176; var tmp70 any = tmp69.Ref(); var tmp71 *lang.Var; A_arbace_main_A_Init(); tmp71 = A_arbace_main_A_const_180; tmp7.Invoke_O__O(tmp9.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp13, tmp15, tmp17, tmp19, tmp21, tmp23, tmp25, tmp27, tmp29, tmp31, tmp33, tmp35, tmp37, tmp39, tmp41, tmp43, tmp45, tmp47, tmp48, tmp50, tmp52, tmp54, tmp56, tmp58, tmp60, tmp62, tmp64, tmp66, nil, tmp68, nil, tmp70, nil, tmp71.Ref(), nil))))); var tmp72 any; tmp83 := /*line :515:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




		{ var tmp73 *lang.Var; A_arbace_main_A_Init(); tmp73 = A_arbace_main_A_const_206; lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()).Invoke_O_O__O(args__11, inits__1)
			var tmp74 *lang.Var; A_arbace_main_A_Init(); tmp74 = A_arbace_main_A_const_23; var tmp75 lang.IFn = lang.IFn_Cast(jrt.NN(tmp74).GetRawRoot__O()); var tmp76 *lang.Var; A_arbace_main_A_Init(); tmp76 = A_arbace_main_A_const_207; var tmp77 lang.IFn = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()); var tmp78 any; var G__461000156__14_ any; var tmp79 *lang.Var; A_arbace_main_A_Init(); tmp79 = A_arbace_main_A_const_84; G__461000156__14_ = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()).Invoke_O__O(main_ns__10); var tmp80 *lang.Var; A_arbace_main_A_Init(); tmp80 = A_arbace_main_A_const_1; lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke_O__O(G__461000156__14_); tmp78 = G__461000156__14_; var tmp81 any = tmp78; var tmp82 any; A_arbace_main_A_Init(); tmp82 = A_arbace_main_A_const_208; tmp72 = tmp75.Invoke_O_O__O(tmp77.Invoke_O_O__O(tmp81, tmp82), args__11) }
//line :515:1
		return nil }(); var tmp84 *lang.Var;



	A_arbace_main_A_Init(); tmp84 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp84).GetRawRoot__O()).Invoke__O(); if /*line :515:1*/ tmp83 != nil { panic(tmp83) }; return tmp72 }







func A_arbace_main_repl_opt_A_New() *A_arbace_main_repl_opt_A { A_arbace_main_repl_opt_A_Init(); t := &A_arbace_main_repl_opt_A{}; t.Ctor(); return t }
//line :523:1
func (t *A_arbace_main_repl_opt_A) Ctor() {}
//line :523:1
func (t *A_arbace_main_repl_opt_A) Invoke_O_O_O__O(self, p__461000159__0, inits__1 any) any { var vec__461000160__3 any = p__461000159__0; var seq__461000161__4 any; var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_19; seq__461000161__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__461000160__3); var first__461000162__5 any; var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_69; first__461000162__5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__461000161__4); var seq__461000161__6 any; var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_67; seq__461000161__6 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__461000161__4); var ___7 any = first__461000162__5; var args__8 any = seq__461000161__6; var tmp4 *lang.Var; _ = ___7;



	A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_209; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = A_arbace_main_repl_opt_fn__461000163_A_New(); var tmp7 *jrt.Class; A_arbace_main_repl_opt_fn__461000163_A_Init(); tmp7 = A_arbace_main_repl_opt_fn__461000163_A_fn_class; if jrt.A2g_Truth(tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), inits__1)) { } else {
		var tmp8 *lang.Var; A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_210; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_294, nil, nil); var tmp11 *lang.Var; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_212; var tmp12 any = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke__O(); var tmp13 *jrt.String; var temp__1927000414__auto____12 any; var tmp14 *lang.Keyword
		A_arbace_main_A_Init(); tmp14 = A_arbace_main_A_const_213; var tmp15 *lang.Keyword = tmp14; var tmp16 *lang.Var; A_arbace_main_A_Init(); tmp16 = A_arbace_main_A_const_214; temp__1927000414__auto____12 = jrt.NN(tmp15).Invoke_O__O(jrt.NN(tmp16).Get__O()); if jrt.A2g_Truth(temp__1927000414__auto____12) { var c__13 any = temp__1927000414__auto____12; var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_218, nil, Lit_219); var tmp18 *lang.Var
			A_arbace_main_A_Init(); tmp18 = A_arbace_main_A_const_80; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any; A_arbace_main_A_Init(); tmp20 = A_arbace_main_A_const_215; var tmp21 any = tmp20; tmp13 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp19.Invoke_O_O_O__O(c__13, tmp21, jrt.Long_ValueOf_J__Long(lang.Numbers_Min_J_J__J(7, int64(lang.RT_Count_O__I(c__13)))).Ref()), nil)) } else {
//line :529:1
				tmp13 = nil }
//line :528:1
		tmp9.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, tmp13.Ref())).Ref()) }; var tmp22 /*line :531:1*/*lang.Var; A_arbace_main_A_Init(); tmp22 = A_arbace_main_A_const_211; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Keyword; A_arbace_main_A_Init(); tmp24 = A_arbace_main_A_const_165; var tmp25 any = tmp24.Ref(); var tmp26 any = A_arbace_main_repl_opt_fn__461000165_A_New_O_O(inits__1, args__8); var tmp27 *jrt.Class; A_arbace_main_repl_opt_fn__461000165_A_Init(); tmp27 = A_arbace_main_repl_opt_fn__461000165_A_fn_class; tmp23.Invoke_O_O__O(tmp25, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil)); var tmp28 /*line :534:1*/*lang.Var; A_arbace_main_A_Init(); tmp28 = A_arbace_main_A_const_163; lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke__O();
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I(0)); return nil }
//line :527:1
func A_arbace_main_repl_opt_fn__461000163_A_New() *A_arbace_main_repl_opt_fn__461000163_A { A_arbace_main_repl_opt_fn__461000163_A_Init(); t := &A_arbace_main_repl_opt_fn__461000163_A{}; t.Ctor(); return t }
//line :527:1
func (t *A_arbace_main_repl_opt_fn__461000163_A) Ctor() {}
//line :527:1
func (t *A_arbace_main_repl_opt_fn__461000163_A) Invoke_O_O__O(self, p1__461000158_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_199; var tmp2 any = jrt.NN(tmp1).GetRawRoot__O(); var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_204; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_69; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp2, tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(p1__461000158_SHARP___1)))).Ref() }



func A_arbace_main_repl_opt_fn__461000165_A_New_O_O(p0, p1 any) *A_arbace_main_repl_opt_fn__461000165_A { A_arbace_main_repl_opt_fn__461000165_A_Init(); t := &A_arbace_main_repl_opt_fn__461000165_A{}; t.Ctor_O_O(p0, p1); return t }
//line :531:1
func (t *A_arbace_main_repl_opt_fn__461000165_A) Ctor_O_O(c__inits, c__args any) { t.F_inits = c__inits; t.F_args = c__args }
//line :531:1
func (t *A_arbace_main_repl_opt_fn__461000165_A) Invoke_O__O(self any) any {
	var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_206; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_args, t.F_inits)
	var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_23; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_1; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 *lang.Var; A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_216; return tmp3.Invoke_O_O__O(tmp5, jrt.NN(tmp6).GetRawRoot__O())
}


func A_arbace_main_script_opt_A_New() *A_arbace_main_script_opt_A { A_arbace_main_script_opt_A_Init(); t := &A_arbace_main_script_opt_A{}; t.Ctor(); return t }
//line :537:1
func (t *A_arbace_main_script_opt_A) Ctor() {}
//line :537:1
func (t *A_arbace_main_script_opt_A) Invoke_O_O_O__O(self, p__461000168__0, inits__1 any) any { var vec__461000169__3 any = p__461000168__0; var seq__461000170__4 any; var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_19; seq__461000170__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__461000169__3); var first__461000171__5 any; var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_69; first__461000171__5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__461000170__4); var seq__461000170__6 any; var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_67; seq__461000170__6 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__461000170__4); var path__7 any = first__461000171__5; var args__8 any = seq__461000170__6; var tmp4 *lang.Var;


	A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_142; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_143; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_58; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Var; A_arbace_main_A_Init(); tmp10 = A_arbace_main_A_const_58; var tmp11 any = jrt.NN(tmp10).Get__O(); var tmp12 *lang.Var; A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_182; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Var; A_arbace_main_A_Init(); tmp14 = A_arbace_main_A_const_182; var tmp15 any = jrt.NN(tmp14).Get__O(); var tmp16 *lang.Var; A_arbace_main_A_Init(); tmp16 = A_arbace_main_A_const_183; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Var; A_arbace_main_A_Init(); tmp18 = A_arbace_main_A_const_183; var tmp19 any = jrt.NN(tmp18).Get__O(); var tmp20 *lang.Var; A_arbace_main_A_Init(); tmp20 = A_arbace_main_A_const_184; var tmp21 any = tmp20.Ref(); var tmp22 *lang.Var; A_arbace_main_A_Init(); tmp22 = A_arbace_main_A_const_184; var tmp23 any = jrt.NN(tmp22).Get__O(); var tmp24 *lang.Var; A_arbace_main_A_Init(); tmp24 = A_arbace_main_A_const_185; var tmp25 any = tmp24.Ref(); var tmp26 *lang.Var; A_arbace_main_A_Init(); tmp26 = A_arbace_main_A_const_185; var tmp27 any = jrt.NN(tmp26).Get__O(); var tmp28 *lang.Var; A_arbace_main_A_Init(); tmp28 = A_arbace_main_A_const_186; var tmp29 any = tmp28.Ref(); var tmp30 *lang.Var; A_arbace_main_A_Init(); tmp30 = A_arbace_main_A_const_186; var tmp31 any = jrt.NN(tmp30).Get__O(); var tmp32 *lang.Var; A_arbace_main_A_Init(); tmp32 = A_arbace_main_A_const_187; var tmp33 any = tmp32.Ref(); var tmp34 *jrt.Boolean; jrt.Boolean_Init(); tmp34 = jrt.Boolean_TRUE; var tmp35 any = tmp34.Ref(); var tmp36 *lang.Var; A_arbace_main_A_Init(); tmp36 = A_arbace_main_A_const_188; var tmp37 any = tmp36.Ref(); var tmp38 *lang.Var; A_arbace_main_A_Init(); tmp38 = A_arbace_main_A_const_188; var tmp39 any = jrt.NN(tmp38).Get__O(); var tmp40 *lang.Var; A_arbace_main_A_Init(); tmp40 = A_arbace_main_A_const_189; var tmp41 any = tmp40.Ref(); var tmp42 *lang.Var; A_arbace_main_A_Init(); tmp42 = A_arbace_main_A_const_189; var tmp43 any = jrt.NN(tmp42).Get__O(); var tmp44 *lang.Var; A_arbace_main_A_Init(); tmp44 = A_arbace_main_A_const_190; var tmp45 any = tmp44.Ref(); var tmp46 any = jrt.System_GetProperty_String_String__String(Lit_276, Lit_277).Ref(); var tmp47 *lang.Var; A_arbace_main_A_Init(); tmp47 = A_arbace_main_A_const_191; var tmp48 any = tmp47.Ref(); var tmp49 *lang.Var; A_arbace_main_A_Init(); tmp49 = A_arbace_main_A_const_191; var tmp50 any = jrt.NN(tmp49).Get__O(); var tmp51 *lang.Var; A_arbace_main_A_Init(); tmp51 = A_arbace_main_A_const_192; var tmp52 any = tmp51.Ref(); var tmp53 *lang.Var; A_arbace_main_A_Init(); tmp53 = A_arbace_main_A_const_192; var tmp54 any = jrt.NN(tmp53).Get__O(); var tmp55 *lang.Var; A_arbace_main_A_Init(); tmp55 = A_arbace_main_A_const_193; var tmp56 any = tmp55.Ref(); var tmp57 *lang.Var; A_arbace_main_A_Init(); tmp57 = A_arbace_main_A_const_193; var tmp58 any = jrt.NN(tmp57).Get__O(); var tmp59 *lang.Var; A_arbace_main_A_Init(); tmp59 = A_arbace_main_A_const_138; var tmp60 any = tmp59.Ref(); var tmp61 *lang.Var; A_arbace_main_A_Init(); tmp61 = A_arbace_main_A_const_138; var tmp62 any = jrt.NN(tmp61).Get__O(); var tmp63 *lang.Var; A_arbace_main_A_Init(); tmp63 = A_arbace_main_A_const_178; var tmp64 any = tmp63.Ref(); var tmp65 *lang.Var; A_arbace_main_A_Init(); tmp65 = A_arbace_main_A_const_177; var tmp66 any = tmp65.Ref(); var tmp67 *lang.Var; A_arbace_main_A_Init(); tmp67 = A_arbace_main_A_const_176; var tmp68 any = tmp67.Ref(); var tmp69 *lang.Var; A_arbace_main_A_Init(); tmp69 = A_arbace_main_A_const_180; tmp5.Invoke_O__O(tmp7.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp11, tmp13, tmp15, tmp17, tmp19, tmp21, tmp23, tmp25, tmp27, tmp29, tmp31, tmp33, tmp35, tmp37, tmp39, tmp41, tmp43, tmp45, tmp46, tmp48, tmp50, tmp52, tmp54, tmp56, tmp58, tmp60, tmp62, tmp64, nil, tmp66, nil, tmp68, nil, tmp69.Ref(), nil))))); var tmp70 any; tmp76 := /*line :537:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		{ var tmp71 *lang.Var; A_arbace_main_A_Init(); tmp71 = A_arbace_main_A_const_206; lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()).Invoke_O_O__O(args__8, inits__1)
			if lang.Util_Equiv_O_O__Z(path__7, Lit_311) {
				var tmp72 *lang.Var; A_arbace_main_A_Init(); tmp72 = A_arbace_main_A_const_217; var tmp73 lang.IFn = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()); var tmp74 *lang.Var; A_arbace_main_A_Init(); tmp74 = A_arbace_main_A_const_75; tmp70 = tmp73.Invoke_O__O(jrt.NN(tmp74).Get__O()) } else {
					var tmp75 *lang.Var; A_arbace_main_A_Init(); tmp75 = A_arbace_main_A_const_197; tmp70 = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()).Invoke_O__O(path__7) } }
//line :537:1
		return nil }(); var tmp77 *lang.Var;


	A_arbace_main_A_Init(); tmp77 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()).Invoke__O(); if /*line :537:1*/ tmp76 != nil { panic(tmp76) }; return tmp70 }








func A_arbace_main_null_opt_A_New() *A_arbace_main_null_opt_A { A_arbace_main_null_opt_A_Init(); t := &A_arbace_main_null_opt_A{}; t.Ctor(); return t }
//line :546:1
func (t *A_arbace_main_null_opt_A) Ctor() {}
//line :546:1
func (t *A_arbace_main_null_opt_A) Invoke_O_O_O__O(self, args__0, inits__1 any) any {


	var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_142; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_143; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_58; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_58; var tmp8 any = jrt.NN(tmp7).Get__O(); var tmp9 *lang.Var; A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_182; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Var; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_182; var tmp12 any = jrt.NN(tmp11).Get__O(); var tmp13 *lang.Var; A_arbace_main_A_Init(); tmp13 = A_arbace_main_A_const_183; var tmp14 any = tmp13.Ref(); var tmp15 *lang.Var; A_arbace_main_A_Init(); tmp15 = A_arbace_main_A_const_183; var tmp16 any = jrt.NN(tmp15).Get__O(); var tmp17 *lang.Var; A_arbace_main_A_Init(); tmp17 = A_arbace_main_A_const_184; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Var; A_arbace_main_A_Init(); tmp19 = A_arbace_main_A_const_184; var tmp20 any = jrt.NN(tmp19).Get__O(); var tmp21 *lang.Var; A_arbace_main_A_Init(); tmp21 = A_arbace_main_A_const_185; var tmp22 any = tmp21.Ref(); var tmp23 *lang.Var; A_arbace_main_A_Init(); tmp23 = A_arbace_main_A_const_185; var tmp24 any = jrt.NN(tmp23).Get__O(); var tmp25 *lang.Var; A_arbace_main_A_Init(); tmp25 = A_arbace_main_A_const_186; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Var; A_arbace_main_A_Init(); tmp27 = A_arbace_main_A_const_186; var tmp28 any = jrt.NN(tmp27).Get__O(); var tmp29 *lang.Var; A_arbace_main_A_Init(); tmp29 = A_arbace_main_A_const_187; var tmp30 any = tmp29.Ref(); var tmp31 *jrt.Boolean; jrt.Boolean_Init(); tmp31 = jrt.Boolean_TRUE; var tmp32 any = tmp31.Ref(); var tmp33 *lang.Var; A_arbace_main_A_Init(); tmp33 = A_arbace_main_A_const_188; var tmp34 any = tmp33.Ref(); var tmp35 *lang.Var; A_arbace_main_A_Init(); tmp35 = A_arbace_main_A_const_188; var tmp36 any = jrt.NN(tmp35).Get__O(); var tmp37 *lang.Var; A_arbace_main_A_Init(); tmp37 = A_arbace_main_A_const_189; var tmp38 any = tmp37.Ref(); var tmp39 *lang.Var; A_arbace_main_A_Init(); tmp39 = A_arbace_main_A_const_189; var tmp40 any = jrt.NN(tmp39).Get__O(); var tmp41 *lang.Var; A_arbace_main_A_Init(); tmp41 = A_arbace_main_A_const_190; var tmp42 any = tmp41.Ref(); var tmp43 any = jrt.System_GetProperty_String_String__String(Lit_276, Lit_277).Ref(); var tmp44 *lang.Var; A_arbace_main_A_Init(); tmp44 = A_arbace_main_A_const_191; var tmp45 any = tmp44.Ref(); var tmp46 *lang.Var; A_arbace_main_A_Init(); tmp46 = A_arbace_main_A_const_191; var tmp47 any = jrt.NN(tmp46).Get__O(); var tmp48 *lang.Var; A_arbace_main_A_Init(); tmp48 = A_arbace_main_A_const_192; var tmp49 any = tmp48.Ref(); var tmp50 *lang.Var; A_arbace_main_A_Init(); tmp50 = A_arbace_main_A_const_192; var tmp51 any = jrt.NN(tmp50).Get__O(); var tmp52 *lang.Var; A_arbace_main_A_Init(); tmp52 = A_arbace_main_A_const_193; var tmp53 any = tmp52.Ref(); var tmp54 *lang.Var; A_arbace_main_A_Init(); tmp54 = A_arbace_main_A_const_193; var tmp55 any = jrt.NN(tmp54).Get__O(); var tmp56 *lang.Var; A_arbace_main_A_Init(); tmp56 = A_arbace_main_A_const_138; var tmp57 any = tmp56.Ref(); var tmp58 *lang.Var; A_arbace_main_A_Init(); tmp58 = A_arbace_main_A_const_138; var tmp59 any = jrt.NN(tmp58).Get__O(); var tmp60 *lang.Var; A_arbace_main_A_Init(); tmp60 = A_arbace_main_A_const_178; var tmp61 any = tmp60.Ref(); var tmp62 *lang.Var; A_arbace_main_A_Init(); tmp62 = A_arbace_main_A_const_177; var tmp63 any = tmp62.Ref(); var tmp64 *lang.Var; A_arbace_main_A_Init(); tmp64 = A_arbace_main_A_const_176; var tmp65 any = tmp64.Ref(); var tmp66 *lang.Var; A_arbace_main_A_Init(); tmp66 = A_arbace_main_A_const_180; tmp2.Invoke_O__O(tmp4.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp10, tmp12, tmp14, tmp16, tmp18, tmp20, tmp22, tmp24, tmp26, tmp28, tmp30, tmp32, tmp34, tmp36, tmp38, tmp40, tmp42, tmp43, tmp45, tmp47, tmp49, tmp51, tmp53, tmp55, tmp57, tmp59, tmp61, nil, tmp63, nil, tmp65, nil, tmp66.Ref(), nil)))))
//line :546:1
	var tmp67 any; tmp69 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		{ var tmp68 *lang.Var; A_arbace_main_A_Init(); tmp68 = A_arbace_main_A_const_206; tmp67 = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O_O__O(args__0, inits__1) }
//line :546:1
		return nil }(); var tmp70 *lang.Var


	A_arbace_main_A_Init(); tmp70 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke__O()
//line :546:1
	if tmp69 != nil { panic(tmp69) }; return tmp67
}




func A_arbace_main_help_opt_A_New() *A_arbace_main_help_opt_A { A_arbace_main_help_opt_A_Init(); t := &A_arbace_main_help_opt_A{}; t.Ctor(); return t }
//line :552:1
func (t *A_arbace_main_help_opt_A) Ctor() {}
//line :552:1
func (t *A_arbace_main_help_opt_A) Invoke_O_O_O__O(self, ___0, ___1 any) any {


	var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_210; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_218; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_219; return tmp2.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(tmp5.Ref())))
}
func A_arbace_main_main_dispatch_A_New() *A_arbace_main_main_dispatch_A { A_arbace_main_main_dispatch_A_Init(); t := &A_arbace_main_main_dispatch_A{}; t.Ctor(); return t }
//line :557:1
func (t *A_arbace_main_main_dispatch_A) Ctor() {}
//line :557:1
func (t *A_arbace_main_main_dispatch_A) Invoke_O_O__O(self, opt__0 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Var;



	A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_220; var tmp2 any = jrt.NN(tmp1).GetRawRoot__O(); var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_220; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_221; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Var; A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_221; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 *lang.Var; A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_222; var tmp10 any = jrt.NN(tmp9).GetRawRoot__O(); var tmp11 *lang.Var; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_223; var tmp12 any = jrt.NN(tmp11).GetRawRoot__O(); var tmp13 *lang.Var; A_arbace_main_A_Init(); tmp13 = A_arbace_main_A_const_223; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_main_A_Init(); tmp15 = A_arbace_main_A_const_223; or__1927000174__auto____2 = lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_187, tmp2, Lit_269, tmp4, Lit_270, tmp6, Lit_271, tmp8, nil, tmp10, Lit_272, tmp12, Lit_273, tmp14, Lit_274, jrt.NN(tmp15).GetRawRoot__O()))).Invoke_O__O(opt__0); if /*line :560:1*/ jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp16 *lang.Var; A_arbace_main_A_Init(); tmp16 = A_arbace_main_A_const_224; return jrt.NN(tmp16).GetRawRoot__O() } }










func A_arbace_main_legacy_repl_A_New() *A_arbace_main_legacy_repl_A { A_arbace_main_legacy_repl_A_Init(); t := &A_arbace_main_legacy_repl_A{}; t.Ctor(); return t }
//line :571:1
func (t *A_arbace_main_legacy_repl_A) Ctor() {}
//line :571:1
func (t *A_arbace_main_legacy_repl_A) Invoke_O_O__O(self, args__0 any) any {



	var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_210; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(Lit_258)
//line :571:1
	var vec__461000176__2 any; var tmp2 *lang.Var






	A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_225; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_226; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_227; vec__461000176__2 = tmp3.Invoke_O_O__O(tmp5.Invoke_O__O(tmp6), args__0)
//line :571:1
	var inits__3 any = lang.RT_Nth_O_I_O__O(vec__461000176__2, lang.RT_IntCast_J__I(0), nil); var vec__461000179__4 any = lang.RT_Nth_O_I_O__O(vec__461000176__2, lang.RT_IntCast_J__I(1), nil); var seq__461000180__5 any; var tmp7 *lang.Var






	A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_19; seq__461000180__5 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(vec__461000179__4)
//line :571:1
	var first__461000181__6 any; var tmp8 *lang.Var






	A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_69; first__461000181__6 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq__461000180__5)
//line :571:1
	var seq__461000180__7 any; var tmp9 *lang.Var






	A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_67; seq__461000180__7 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq__461000180__5)
//line :571:1
	var sep__8 any = first__461000181__6; var args__9 any = seq__461000180__7; var tmp10 *lang.Var; _ = sep__8







	A_arbace_main_A_Init(); tmp10 = A_arbace_main_A_const_220; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_20; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any; A_arbace_main_A_Init(); tmp14 = A_arbace_main_A_const_228; var tmp15 any = tmp13.Invoke_O_O__O(tmp14, args__9); var tmp16 *lang.Var; A_arbace_main_A_Init(); tmp16 = A_arbace_main_A_const_83; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_main_A_Init(); tmp18 = A_arbace_main_A_const_24; var tmp19 any = jrt.NN(tmp18).GetRawRoot__O(); var tmp20 *lang.Var; A_arbace_main_A_Init(); tmp20 = A_arbace_main_A_const_229; return tmp11.Invoke_O_O__O(tmp15, tmp17.Invoke_O_O_O__O(tmp19, lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(Lit_246), inits__3))
}
func A_arbace_main_legacy_script_A_New() *A_arbace_main_legacy_script_A { A_arbace_main_legacy_script_A_Init(); t := &A_arbace_main_legacy_script_A{}; t.Ctor(); return t }
//line :581:1
func (t *A_arbace_main_legacy_script_A) Ctor() {}
//line :581:1
func (t *A_arbace_main_legacy_script_A) Invoke_O_O__O(self, args__0 any) any {



	var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_210; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(Lit_260)
//line :581:1
	var vec__461000183__2 any; var tmp2 *lang.Var






	A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_225; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_226; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_230; vec__461000183__2 = tmp3.Invoke_O_O__O(tmp5.Invoke_O__O(tmp6), args__0)
//line :581:1
	var inits__3 any = lang.RT_Nth_O_I_O__O(vec__461000183__2, lang.RT_IntCast_J__I(0), nil); var vec__461000186__4 any = lang.RT_Nth_O_I_O__O(vec__461000183__2, lang.RT_IntCast_J__I(1), nil); var seq__461000187__5 any; var tmp7 *lang.Var






	A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_19; seq__461000187__5 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(vec__461000186__4)
//line :581:1
	var first__461000188__6 any; var tmp8 *lang.Var






	A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_69; first__461000188__6 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq__461000187__5)
//line :581:1
	var seq__461000187__7 any; var tmp9 *lang.Var






	A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_67; seq__461000187__7 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq__461000187__5)
//line :581:1
	var sep__8 any = first__461000188__6; var args__9 any = seq__461000187__7; var tmp10 *lang.Var; _ = sep__8







	A_arbace_main_A_Init(); tmp10 = A_arbace_main_A_const_222; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_83; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_main_A_Init(); tmp14 = A_arbace_main_A_const_24; var tmp15 any = jrt.NN(tmp14).GetRawRoot__O(); var tmp16 *lang.Var; A_arbace_main_A_Init(); tmp16 = A_arbace_main_A_const_229; return tmp11.Invoke_O_O__O(args__9, tmp13.Invoke_O_O_O__O(tmp15, lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(Lit_246), inits__3))
}
func A_arbace_main_report_error_A_New() *A_arbace_main_report_error_A { A_arbace_main_report_error_A_Init(); t := &A_arbace_main_report_error_A{}; t.Ctor(); return t }
//line :591:1
func (t *A_arbace_main_report_error_A) Ctor() {}
//line :591:1
func (t *A_arbace_main_report_error_A) DoInvoke_O_O_O__O(self, t__0, p__461000190__1 any) any { var default__461000193__3 any = Lit_114; var map__461000191__4 any = p__461000190__1; var map__461000191__5 any; if lang.ISeq_InstanceOf(map__461000191__4) { var tmp1 *lang.Var; A_arbace_main_A_Init(); tmp1 = A_arbace_main_A_const_67; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__461000191__4)) { var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_68; map__461000191__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__461000191__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__461000191__4)) { var tmp4 *lang.Var; A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_69; map__461000191__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__461000191__4) } else { lang.PersistentArrayMap_Init(); map__461000191__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__461000191__5 = map__461000191__4 }; var opts__6 any = map__461000191__5; var target__7 any; var tmp5 *lang.Keyword; _ = opts__6; A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_231; target__7 = lang.RT_Get_O_O_O__O(map__461000191__5, tmp5.Ref(), default__461000193__3); if








	lang.Util_Equiv_O_O__Z(target__7, Lit_301) { return nil } else { var trace__8 any; var tmp6 *lang.Var
		A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_147; trace__8 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(t__0)
//line :600:1
		var triage__9 any; var tmp7 *lang.Var

		A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_146; triage__9 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(trace__8)
//line :600:1
		var message__10 any; var tmp8 *lang.Var


		A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_145; message__10 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(triage__9)
//line :600:1
		var report__11 any; var tmp9 *lang.Var



		A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_232; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_234; var tmp12 any = tmp11.Ref(); var tmp13 *lang.Keyword; A_arbace_main_A_Init(); tmp13 = A_arbace_main_A_const_235; var tmp14 any = tmp13.Ref(); var tmp15 *lang.Keyword; A_arbace_main_A_Init(); tmp15 = A_arbace_main_A_const_236; report__11 = tmp10.Invoke_O_O_O_O_O_O__O(tmp12, message__10, tmp14, triage__9, tmp15.Ref(), trace__8)
//line :600:1
		var report_str__12 any; var s__1927001093__auto____12 any = jrt.StringWriter_New(); var tmp16 *lang.Var







		A_arbace_main_A_Init(); tmp16 = A_arbace_main_A_const_142; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_main_A_Init(); tmp18 = A_arbace_main_A_const_143; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_main_A_Init(); tmp20 = A_arbace_main_A_const_144; tmp17.Invoke_O__O(tmp19.Invoke_O_O__O(tmp20.Ref(), s__1927001093__auto____12)); var tmp21 any = A_arbace_main_report_error_fn__461000195_A_New_O_O(report__11, s__1927001093__auto____12); var tmp22 *jrt.Class; A_arbace_main_report_error_fn__461000195_A_Init(); tmp22 = A_arbace_main_report_error_fn__461000195_A_fn_class; report_str__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil).Invoke__O()
//line :600:1
		var err_path__13 any










		if lang.Util_Equiv_O_O__Z(target__7, Lit_114) {
			var tmp23 any = A_arbace_main_report_error_fn__461000199_A_New_O(report_str__12); var tmp24 *jrt.Class; A_arbace_main_report_error_fn__461000199_A_Init(); tmp24 = A_arbace_main_report_error_fn__461000199_A_fn_class; err_path__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil).Invoke__O() } else {
//line :611:1
				err_path__13 = nil
			}





		var tmp25 *lang.Var; A_arbace_main_A_Init(); tmp25 = A_arbace_main_A_const_142; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_main_A_Init(); tmp27 = A_arbace_main_A_const_143; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_main_A_Init(); tmp29 = A_arbace_main_A_const_144; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Var; A_arbace_main_A_Init(); tmp31 = A_arbace_main_A_const_149; tmp26.Invoke_O__O(tmp28.Invoke_O_O__O(tmp30, jrt.NN(tmp31).Get__O()))
//line :600:1
		var tmp32 any; tmp35 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


















			if jrt.A2g_Truth(err_path__13) {
				var tmp33 *lang.Var; A_arbace_main_A_Init(); tmp33 = A_arbace_main_A_const_210; tmp32 = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_302, nil, nil), jrt.RefArrayOf(jrt.Object_class, message__10, jrt.System_LineSeparator__String().Ref(), nil, jrt.System_LineSeparator__String().Ref(), err_path__13)).Ref()) } else {
					var tmp34 *lang.Var; A_arbace_main_A_Init(); tmp34 = A_arbace_main_A_const_210; tmp32 = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil, nil), jrt.RefArrayOf(jrt.Object_class, report_str__12, jrt.System_LineSeparator__String().Ref(), message__10)).Ref()) }
//line :600:1
			return nil }(); var tmp36 *lang.Var

















		A_arbace_main_A_Init(); tmp36 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke__O()
//line :600:1
		if tmp35 != nil { panic(tmp35) }; return tmp32 } }







func A_arbace_main_report_error_fn__461000195_A_New_O_O(p0, p1 any) *A_arbace_main_report_error_fn__461000195_A { A_arbace_main_report_error_fn__461000195_A_Init(); t := &A_arbace_main_report_error_fn__461000195_A{}; t.Ctor_O_O(p0, p1); return t }
//line :608:1
func (t *A_arbace_main_report_error_fn__461000195_A) Ctor_O_O(c__report, c__s__1927001093__auto__ any) { t.F_report = c__report; t.F_s__1927001093__auto__ = c__s__1927001093__auto__ }
//line :608:1
func (t *A_arbace_main_report_error_fn__461000195_A) Invoke_O__O(self any) any { var tmp1 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_142; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_143; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_187; var tmp7 any = tmp6.Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_FALSE; tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(tmp7, tmp8.Ref())); var tmp9 any = A_arbace_main_report_error_fn__461000195_fn__461000196_A_New_O(t.F_report); var tmp10 *jrt.Class; A_arbace_main_report_error_fn__461000195_fn__461000196_A_Init(); tmp10 = A_arbace_main_report_error_fn__461000195_fn__461000196_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()
//line :608:1
		var tmp11 *lang.Var; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_86; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; var t_ any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; tmp13 = t_; tmp1 = tmp12.Invoke_O__O(tmp13) }; return nil }(); var tmp15 *lang.Var; A_arbace_main_A_Init(); tmp15 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke__O(); if tmp14 != nil { panic(tmp14) }; return tmp1 }
func A_arbace_main_report_error_fn__461000195_fn__461000196_A_New_O(p0 any) *A_arbace_main_report_error_fn__461000195_fn__461000196_A { A_arbace_main_report_error_fn__461000195_fn__461000196_A_Init(); t := &A_arbace_main_report_error_fn__461000195_fn__461000196_A{}; t.Ctor_O(p0); return t }
//line :609:1
func (t *A_arbace_main_report_error_fn__461000195_fn__461000196_A) Ctor_O(c__report any) { t.F_report = c__report }
//line :609:1
func (t *A_arbace_main_report_error_fn__461000195_fn__461000196_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_163; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_report; t.F_report = nil; tmp4 = t_; tmp1 = tmp3.Invoke_O__O(tmp4) }
//line :609:1
	return nil }(); var tmp6 *lang.Var; A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }


func A_arbace_main_report_error_fn__461000199_A_New_O(p0 any) *A_arbace_main_report_error_fn__461000199_A { A_arbace_main_report_error_fn__461000199_A_Init(); t := &A_arbace_main_report_error_fn__461000199_A{}; t.Ctor_O(p0); return t }
//line :612:1
func (t *A_arbace_main_report_error_fn__461000199_A) Ctor_O(c__report_str any) { t.F_report_str = c__report_str }
//line :612:1
func (t *A_arbace_main_report_error_fn__461000199_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var f__3 any; var tmp2 *jrt.String = Lit_306; var tmp3 *jrt.String = Lit_307; var tmp4 *lang.Var
										A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_87; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *jrt.Class; A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_233; var tmp7 any = tmp6.Ref(); var tmp8 *lang.PersistentVector; lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY; f__3 = jrt.Files_CreateTempFile_String_String_FileAttribute1__Path(tmp2, tmp3, jrt.A2g_CastArray[*jrt.RefArray](tmp5.Invoke_O_O__O(tmp7, tmp8.Ref()), jrt.FileAttribute_class.ArrayClass())).ToFile__File().Ref()
//line :612:1
	var w__4 any = jrt.BufferedWriter_New_Writer(jrt.FileWriter_New_File(jrt.File_Cast(f__3))); var tmp9 any = A_arbace_main_report_error_fn__461000199_fn__461000200_A_New_O_O(w__4, t.F_report_str); var tmp10 *jrt.Class

	A_arbace_main_report_error_fn__461000199_fn__461000200_A_Init(); tmp10 = A_arbace_main_report_error_fn__461000199_fn__461000200_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()

	tmp1 = jrt.NN(jrt.File_Cast(f__3)).GetAbsolutePath__String().Ref() }; return nil }(); if /*line :612:1*/ tmp11 != nil { if true { var ___3 jrt.Throwable_I = tmp11; _ = ___3; tmp1 = nil } }; return tmp1 }

func A_arbace_main_report_error_fn__461000199_fn__461000200_A_New_O_O(p0, p1 any) *A_arbace_main_report_error_fn__461000199_fn__461000200_A { A_arbace_main_report_error_fn__461000199_fn__461000200_A_Init(); t := &A_arbace_main_report_error_fn__461000199_fn__461000200_A{}; t.Ctor_O_O(p0, p1); return t }
//line :614:1
func (t *A_arbace_main_report_error_fn__461000199_fn__461000200_A) Ctor_O_O(c__w, c__report_str any) { t.F_w = c__w; t.F_report_str = c__report_str }
//line :614:1
func (t *A_arbace_main_report_error_fn__461000199_fn__461000200_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 *lang.Var; A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_142; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_143; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_144; tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6.Ref(), t.F_w)); tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp7 *lang.Var; A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_210; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; var t_ any = t.F_report_str; t.F_report_str = nil; tmp9 = t_; tmp1 = tmp8.Invoke_O__O(tmp9) }; return nil }(); var tmp11 *lang.Var; A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_136; lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke__O()
//line :614:1
		if tmp10 != nil { panic(tmp10) } }; return nil }(); var tmp13 any; var t__2 any = t.F_w; t.F_w = nil; tmp13 = t__2; jrt.BufferedWriter_Cast(tmp13).Close__V(); if tmp12 != nil { panic(tmp12) }; return tmp1 }








func A_arbace_main_main_A_New() *A_arbace_main_main_A { A_arbace_main_main_A_Init(); t := &A_arbace_main_main_A{}; t.Ctor(); return t }
//line :623:1
func (t *A_arbace_main_main_A) Ctor() {}
//line :623:1
func (t *A_arbace_main_main_A) DoInvoke_O_O__O(self, args__0 any) any { var tmp1 any; tmp34 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


































	if jrt.A2g_Truth(args__0) { var G__461000207__4_ any = args__0; var vec__461000208__5 any = G__461000207__4_; var seq__461000209__6 any; var tmp2 *lang.Var
		A_arbace_main_A_Init(); tmp2 = A_arbace_main_A_const_19; seq__461000209__6 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(vec__461000208__5)
//line :658:1
		var first__461000210__7 any; var tmp3 *lang.Var
		A_arbace_main_A_Init(); tmp3 = A_arbace_main_A_const_69; first__461000210__7 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__461000209__6)
//line :658:1
		var seq__461000209__8 any; var tmp4 *lang.Var
		A_arbace_main_A_Init(); tmp4 = A_arbace_main_A_const_67; seq__461000209__8 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__461000209__6)
//line :658:1
		var opt__9 any = first__461000210__7; var first__461000210__10 any; var tmp5 *lang.Var; _ = opt__9
		A_arbace_main_A_Init(); tmp5 = A_arbace_main_A_const_69; first__461000210__10 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__461000209__8)
//line :658:1
		var seq__461000209__11 any; var tmp6 *lang.Var
		A_arbace_main_A_Init(); tmp6 = A_arbace_main_A_const_67; seq__461000209__11 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq__461000209__8)
//line :658:1
		var arg__12 any = first__461000210__10; var more__13 any = seq__461000209__11; var args__14 any = vec__461000208__5; var inits__15 any; _ = arg__12; _ = more__13; _ = args__14; lang.PersistentVector_Init(); inits__15 = lang.PersistentVector_EMPTY.Ref(); var flags__16 any; var G__461000207__17_ any = G__461000207__4_; var inits__18 any = inits__15; var flags__19 any = flags__16; L1: for { var vec__461000211__20 any = G__461000207__17_; var seq__461000212__21 any; var tmp7 *lang.Var
			A_arbace_main_A_Init(); tmp7 = A_arbace_main_A_const_19; seq__461000212__21 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(vec__461000211__20)
//line :658:1
			var first__461000213__22 any; var tmp8 *lang.Var
			A_arbace_main_A_Init(); tmp8 = A_arbace_main_A_const_69; first__461000213__22 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq__461000212__21)
//line :658:1
			var seq__461000212__23 any; var tmp9 *lang.Var
			A_arbace_main_A_Init(); tmp9 = A_arbace_main_A_const_67; seq__461000212__23 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq__461000212__21)
//line :658:1
			var opt__24 any = first__461000213__22; var first__461000213__25 any; var tmp10 *lang.Var
			A_arbace_main_A_Init(); tmp10 = A_arbace_main_A_const_69; first__461000213__25 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq__461000212__23)
//line :658:1
			var seq__461000212__26 any; var tmp11 *lang.Var
			A_arbace_main_A_Init(); tmp11 = A_arbace_main_A_const_67; seq__461000212__26 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq__461000212__23)
//line :658:1
			var arg__27 any = first__461000213__25; var more__28 any = seq__461000212__26; var args__29 any = vec__461000211__20; var inits__30 any = inits__18; var flags__31 any = flags__19; var tmp12 *lang.Var

			A_arbace_main_A_Init(); tmp12 = A_arbace_main_A_const_13; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any; A_arbace_main_A_Init(); tmp14 = A_arbace_main_A_const_239; if jrt.A2g_Truth(tmp13.Invoke_O_O__O(tmp14, opt__24)) {


				var tmp15 *lang.Var; A_arbace_main_A_Init(); tmp15 = A_arbace_main_A_const_120; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_main_A_Init(); tmp17 = A_arbace_main_A_const_80; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any; A_arbace_main_A_Init(); tmp19 = A_arbace_main_A_const_240; G__461000207__17_, inits__18, flags__19 = more__28, inits__30, tmp16.Invoke_O_O__O(flags__31, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp18.Invoke_O_O__O(opt__24, tmp19), arg__27))); continue L1 } else {
//line :660:1
					var tmp20 *lang.Var; A_arbace_main_A_Init(); tmp20 = A_arbace_main_A_const_204; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(opt__24)) {






						var tmp21 *lang.Var; A_arbace_main_A_Init(); tmp21 = A_arbace_main_A_const_8; G__461000207__17_, inits__18, flags__19 = more__28, lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O_O__O(inits__30, lang.Tuple_Create_O_O__IPersistentVector(opt__24, arg__27)), flags__31; continue L1 } else {
//line :660:1
							var tmp22 *lang.Keyword; A_arbace_main_A_Init(); tmp22 = A_arbace_main_A_const_237; if tmp22 != nil { tmp24 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)










								{ var tmp23 *lang.Var; A_arbace_main_A_Init(); tmp23 = A_arbace_main_A_const_238; tmp1 = lang.IFn_Cast(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(opt__24)).Invoke_O_O__O(args__29, inits__30) }
//line :660:1
								return nil }(); if tmp24 != nil { if true { var t__34 jrt.Throwable_I = tmp24; var tmp25 *lang.Var












									A_arbace_main_A_Init(); tmp25 = A_arbace_main_A_const_241; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_main_A_Init(); tmp27 = A_arbace_main_A_const_231; var tmp28 any = tmp27.Ref(); tmp26.Invoke_O_O_O__O(t__34, tmp28, lang.RT_Get_O_O_O__O(flags__31, Lit_266, jrt.System_GetProperty_String_String__String(Lit_267, Lit_114).Ref()))
									jrt.System_Exit_I__V(lang.RT_IntCast_J__I(1)); tmp1 = nil } } } else {
//line :660:1
										tmp1 = nil } } }
//line :658:1
			break L1 } } else { tmp30 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

















				{ var tmp29 *lang.Var; A_arbace_main_A_Init(); tmp29 = A_arbace_main_A_const_220; tmp1 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O_O__O(nil, nil) }
//line :658:1
				return nil }(); if tmp30 != nil { if true { var t__6 jrt.Throwable_I = tmp30; var tmp31 *lang.Var



















					A_arbace_main_A_Init(); tmp31 = A_arbace_main_A_const_241; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Keyword; A_arbace_main_A_Init(); tmp33 = A_arbace_main_A_const_231; tmp32.Invoke_O_O_O__O(t__6, tmp33.Ref(), Lit_114)
					jrt.System_Exit_I__V(lang.RT_IntCast_J__I(1)); tmp1 = nil } } }
//line :623:1
	return nil }(); var tmp35 *lang.Var;

























































	A_arbace_main_A_Init(); tmp35 = A_arbace_main_A_const_148; lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke__O(); if /*line :623:1*/ tmp34 != nil { panic(tmp34) }; return tmp1 }
















type A_arbace_main_A struct{ jrt.Object }

var A_arbace_main_A_const_0 *lang.Var

var A_arbace_main_A_const_1 *lang.Var

var A_arbace_main_A_const_2 any

var A_arbace_main_A_const_3 *lang.Keyword

var A_arbace_main_A_const_4 any

var A_arbace_main_A_const_5 any

var A_arbace_main_A_const_6 *lang.Var

var A_arbace_main_A_const_7 *lang.Var

var A_arbace_main_A_const_8 *lang.Var

var A_arbace_main_A_const_9 any

var A_arbace_main_A_const_10 *lang.Var

var A_arbace_main_A_const_11 *lang.Var

var A_arbace_main_A_const_12 *lang.Var

var A_arbace_main_A_const_13 *lang.Var

var A_arbace_main_A_const_14 *lang.Var

var A_arbace_main_A_const_15 *lang.Var

var A_arbace_main_A_const_16 *lang.Var

var A_arbace_main_A_const_17 any

var A_arbace_main_A_const_18 *lang.Var

var A_arbace_main_A_const_19 *lang.Var

var A_arbace_main_A_const_20 *lang.Var

var A_arbace_main_A_const_21 *lang.Var

var A_arbace_main_A_const_22 any

var A_arbace_main_A_const_23 *lang.Var

var A_arbace_main_A_const_24 *lang.Var

var A_arbace_main_A_const_25 any

var A_arbace_main_A_const_26 any

var A_arbace_main_A_const_27 any

var A_arbace_main_A_const_28 any

var A_arbace_main_A_const_29 any

var A_arbace_main_A_const_30 any

var A_arbace_main_A_const_31 any

var A_arbace_main_A_const_32 any

var A_arbace_main_A_const_33 any

var A_arbace_main_A_const_34 any

var A_arbace_main_A_const_35 any

var A_arbace_main_A_const_36 any

var A_arbace_main_A_const_37 any

var A_arbace_main_A_const_38 any

var A_arbace_main_A_const_39 any

var A_arbace_main_A_const_40 any

var A_arbace_main_A_const_41 any

var A_arbace_main_A_const_42 any

var A_arbace_main_A_const_43 any

var A_arbace_main_A_const_44 any

var A_arbace_main_A_const_45 any

var A_arbace_main_A_const_46 any

var A_arbace_main_A_const_47 any

var A_arbace_main_A_const_48 any

var A_arbace_main_A_const_49 any

var A_arbace_main_A_const_50 any

var A_arbace_main_A_const_51 any

var A_arbace_main_A_const_52 any

var A_arbace_main_A_const_53 any

var A_arbace_main_A_const_54 any

var A_arbace_main_A_const_55 any

var A_arbace_main_A_const_56 *lang.Var

var A_arbace_main_A_const_57 *lang.Var

var A_arbace_main_A_const_58 *lang.Var

var A_arbace_main_A_const_59 any

var A_arbace_main_A_const_60 *lang.Keyword

var A_arbace_main_A_const_61 *lang.Keyword

var A_arbace_main_A_const_62 *lang.Keyword

var A_arbace_main_A_const_63 *lang.Keyword

var A_arbace_main_A_const_64 any

var A_arbace_main_A_const_65 any

var A_arbace_main_A_const_66 *lang.Var

var A_arbace_main_A_const_67 *lang.Var

var A_arbace_main_A_const_68 *lang.Var

var A_arbace_main_A_const_69 *lang.Var

var A_arbace_main_A_const_70 *lang.Keyword

var A_arbace_main_A_const_71 *lang.Keyword

var A_arbace_main_A_const_72 *lang.Var

var A_arbace_main_A_const_73 *lang.Var

var A_arbace_main_A_const_74 *lang.Var

var A_arbace_main_A_const_75 *lang.Var

var A_arbace_main_A_const_76 any

var A_arbace_main_A_const_77 any

var A_arbace_main_A_const_78 *lang.Var

var A_arbace_main_A_const_79 *lang.Var

var A_arbace_main_A_const_80 *lang.Var

var A_arbace_main_A_const_81 any

var A_arbace_main_A_const_82 *jrt.Class

var A_arbace_main_A_const_83 *lang.Var

var A_arbace_main_A_const_84 *lang.Var

var A_arbace_main_A_const_85 any

var A_arbace_main_A_const_86 *lang.Var

var A_arbace_main_A_const_87 *lang.Var

var A_arbace_main_A_const_88 *lang.Var

var A_arbace_main_A_const_89 *lang.Var

var A_arbace_main_A_const_90 *lang.Keyword

var A_arbace_main_A_const_91 *lang.Keyword

var A_arbace_main_A_const_92 *lang.Keyword

var A_arbace_main_A_const_93 *lang.Keyword

var A_arbace_main_A_const_94 *lang.Var

var A_arbace_main_A_const_95 *lang.Keyword

var A_arbace_main_A_const_96 *lang.Keyword

var A_arbace_main_A_const_97 *lang.Keyword

var A_arbace_main_A_const_98 *lang.Keyword

var A_arbace_main_A_const_99 *lang.Keyword

var A_arbace_main_A_const_100 *lang.Keyword

var A_arbace_main_A_const_101 *lang.Keyword

var A_arbace_main_A_const_102 *lang.Var

var A_arbace_main_A_const_103 *lang.Keyword

var A_arbace_main_A_const_104 any

var A_arbace_main_A_const_105 *lang.Var

var A_arbace_main_A_const_106 *lang.Keyword

var A_arbace_main_A_const_107 any

var A_arbace_main_A_const_108 *lang.Keyword

var A_arbace_main_A_const_109 any

var A_arbace_main_A_const_110 *lang.Keyword

var A_arbace_main_A_const_111 *lang.Keyword

var A_arbace_main_A_const_112 *lang.Var

var A_arbace_main_A_const_113 *lang.Keyword

var A_arbace_main_A_const_114 *lang.Var

var A_arbace_main_A_const_115 *lang.Keyword

var A_arbace_main_A_const_116 *lang.Keyword

var A_arbace_main_A_const_117 *lang.Keyword

var A_arbace_main_A_const_118 *lang.Keyword

var A_arbace_main_A_const_119 *lang.Keyword

var A_arbace_main_A_const_120 *lang.Var

var A_arbace_main_A_const_121 any

var A_arbace_main_A_const_122 *lang.Var

var A_arbace_main_A_const_123 *lang.Var

var A_arbace_main_A_const_124 *lang.Var

var A_arbace_main_A_const_125 any

var A_arbace_main_A_const_126 *lang.Keyword

var A_arbace_main_A_const_127 *lang.Keyword

var A_arbace_main_A_const_128 *lang.Var

var A_arbace_main_A_const_129 *lang.Keyword

var A_arbace_main_A_const_130 *lang.Keyword

var A_arbace_main_A_const_131 any

var A_arbace_main_A_const_132 *lang.Keyword

var A_arbace_main_A_const_133 *lang.Var

var A_arbace_main_A_const_134 any

var A_arbace_main_A_const_135 any

var A_arbace_main_A_const_136 *lang.Var

var A_arbace_main_A_const_137 *lang.Var

var A_arbace_main_A_const_138 *lang.Var

var A_arbace_main_A_const_139 *lang.Var

var A_arbace_main_A_const_140 *lang.Var

var A_arbace_main_A_const_141 *lang.Keyword

var A_arbace_main_A_const_142 *lang.Var

var A_arbace_main_A_const_143 *lang.Var

var A_arbace_main_A_const_144 *lang.Var

var A_arbace_main_A_const_145 *lang.Var

var A_arbace_main_A_const_146 *lang.Var

var A_arbace_main_A_const_147 *lang.Var

var A_arbace_main_A_const_148 *lang.Var

var A_arbace_main_A_const_149 *lang.Var

var A_arbace_main_A_const_150 *lang.Var

var A_arbace_main_A_const_151 *lang.Var

var A_arbace_main_A_const_152 any

var A_arbace_main_A_const_153 any

var A_arbace_main_A_const_154 any

var A_arbace_main_A_const_155 any

var A_arbace_main_A_const_156 *lang.Keyword

var A_arbace_main_A_const_157 any

var A_arbace_main_A_const_158 any

var A_arbace_main_A_const_159 *lang.Var

var A_arbace_main_A_const_160 *lang.Var

var A_arbace_main_A_const_161 *lang.Var

var A_arbace_main_A_const_162 *lang.Var

var A_arbace_main_A_const_163 *lang.Var

var A_arbace_main_A_const_164 *lang.Var

var A_arbace_main_A_const_165 *lang.Keyword

var A_arbace_main_A_const_166 *lang.Keyword

var A_arbace_main_A_const_167 *lang.Keyword

var A_arbace_main_A_const_168 *lang.Keyword

var A_arbace_main_A_const_169 *lang.Keyword

var A_arbace_main_A_const_170 *lang.Keyword

var A_arbace_main_A_const_171 *lang.Keyword

var A_arbace_main_A_const_172 *lang.Keyword

var A_arbace_main_A_const_173 *lang.Var

var A_arbace_main_A_const_174 *lang.Var

var A_arbace_main_A_const_175 any

var A_arbace_main_A_const_176 *lang.Var

var A_arbace_main_A_const_177 *lang.Var

var A_arbace_main_A_const_178 *lang.Var

var A_arbace_main_A_const_179 any

var A_arbace_main_A_const_180 *lang.Var

var A_arbace_main_A_const_181 *jrt.Class

var A_arbace_main_A_const_182 *lang.Var

var A_arbace_main_A_const_183 *lang.Var

var A_arbace_main_A_const_184 *lang.Var

var A_arbace_main_A_const_185 *lang.Var

var A_arbace_main_A_const_186 *lang.Var

var A_arbace_main_A_const_187 *lang.Var

var A_arbace_main_A_const_188 *lang.Var

var A_arbace_main_A_const_189 *lang.Var

var A_arbace_main_A_const_190 *lang.Var

var A_arbace_main_A_const_191 *lang.Var

var A_arbace_main_A_const_192 *lang.Var

var A_arbace_main_A_const_193 *lang.Var

var A_arbace_main_A_const_194 *lang.Var

var A_arbace_main_A_const_195 *lang.Var

var A_arbace_main_A_const_196 any

var A_arbace_main_A_const_197 *lang.Var

var A_arbace_main_A_const_198 *lang.Var

var A_arbace_main_A_const_199 *lang.Var

var A_arbace_main_A_const_200 *lang.Var

var A_arbace_main_A_const_201 *lang.Var

var A_arbace_main_A_const_202 *lang.Var

var A_arbace_main_A_const_203 any

var A_arbace_main_A_const_204 *lang.Var

var A_arbace_main_A_const_205 *lang.Var

var A_arbace_main_A_const_206 *lang.Var

var A_arbace_main_A_const_207 *lang.Var

var A_arbace_main_A_const_208 any

var A_arbace_main_A_const_209 *lang.Var

var A_arbace_main_A_const_210 *lang.Var

var A_arbace_main_A_const_211 *lang.Var

var A_arbace_main_A_const_212 *lang.Var

var A_arbace_main_A_const_213 *lang.Keyword

var A_arbace_main_A_const_214 *lang.Var

var A_arbace_main_A_const_215 any

var A_arbace_main_A_const_216 *lang.Var

var A_arbace_main_A_const_217 *lang.Var

var A_arbace_main_A_const_218 *lang.Keyword

var A_arbace_main_A_const_219 *lang.Var

var A_arbace_main_A_const_220 *lang.Var

var A_arbace_main_A_const_221 *lang.Var

var A_arbace_main_A_const_222 *lang.Var

var A_arbace_main_A_const_223 *lang.Var

var A_arbace_main_A_const_224 *lang.Var

var A_arbace_main_A_const_225 *lang.Var

var A_arbace_main_A_const_226 *lang.Var

var A_arbace_main_A_const_227 any

var A_arbace_main_A_const_228 any

var A_arbace_main_A_const_229 *lang.Var

var A_arbace_main_A_const_230 any

var A_arbace_main_A_const_231 *lang.Keyword

var A_arbace_main_A_const_232 *lang.Var

var A_arbace_main_A_const_233 *jrt.Class

var A_arbace_main_A_const_234 *lang.Keyword

var A_arbace_main_A_const_235 *lang.Keyword

var A_arbace_main_A_const_236 *lang.Keyword

var A_arbace_main_A_const_237 *lang.Keyword

var A_arbace_main_A_const_238 *lang.Var

var A_arbace_main_A_const_239 any

var A_arbace_main_A_const_240 any

var A_arbace_main_A_const_241 *lang.Var

var A_arbace_main_A_init jrt.ClassInit

func A_arbace_main_A_Init() { if !A_arbace_main_A_init.Done() { A_arbace_main_A_init.Run(A_arbace_main_A_clinit) } }

func A_arbace_main_A_clinit() { A_arbace_main_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_main_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_main_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_main_A_const_3 = lang.RT_Keyword_String_String__Keyword(nil, Lit_3); A_arbace_main_A_const_4 = lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref()); A_arbace_main_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_main_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_main_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_main_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_main_A_const_9 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_main_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_main_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_main_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_main_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_main_A_const_14 = lang.RT_Var_String_String__Var(Lit_11, Lit_20); A_arbace_main_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_main_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_main_A_const_17 = jrt.Pattern_Compile_String__Pattern(Lit_23).Ref(); A_arbace_main_A_const_18 = lang.RT_Var_String_String__Var(Lit_11, Lit_24); A_arbace_main_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_main_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_main_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_main_A_const_22 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_28).Ref(); A_arbace_main_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_main_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_main_A_const_25 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_31).Ref(); A_arbace_main_A_const_26 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_31).Ref(); A_arbace_main_A_const_27 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_32).Ref(); A_arbace_main_A_const_28 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_32).Ref(); A_arbace_main_A_const_29 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_33).Ref(); A_arbace_main_A_const_30 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_33).Ref(); A_arbace_main_A_const_31 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_34).Ref(); A_arbace_main_A_const_32 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_34).Ref(); A_arbace_main_A_const_33 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_35).Ref(); A_arbace_main_A_const_34 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_35).Ref(); A_arbace_main_A_const_35 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_36).Ref(); A_arbace_main_A_const_36 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_36).Ref(); A_arbace_main_A_const_37 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_37).Ref(); A_arbace_main_A_const_38 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_main_A_const_39 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_main_A_const_40 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_39).Ref(); A_arbace_main_A_const_41 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_39).Ref(); A_arbace_main_A_const_42 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_40).Ref(); A_arbace_main_A_const_43 = lang.Symbol_Intern_String_String__Symbol(Lit_41, Lit_42).Ref(); A_arbace_main_A_const_44 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_43).Ref(); A_arbace_main_A_const_45 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_43).Ref(); A_arbace_main_A_const_46 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_44).Ref(); A_arbace_main_A_const_47 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_44).Ref(); A_arbace_main_A_const_48 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_45).Ref(); A_arbace_main_A_const_49 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_45).Ref(); A_arbace_main_A_const_50 = lang.Symbol_Intern_String_String__Symbol(Lit_5, Lit_46).Ref(); A_arbace_main_A_const_51 = lang.Symbol_Intern_String_String__Symbol(Lit_5, Lit_46).Ref(); A_arbace_main_A_const_52 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_47).Ref(); A_arbace_main_A_const_53 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_48).Ref(); A_arbace_main_A_const_54 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_49).Ref(); A_arbace_main_A_const_55 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_50).Ref(); A_arbace_main_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_main_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_main_A_const_58 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_main_A_const_59 = jrt.Character_ValueOf_C__Character(10).Ref(); A_arbace_main_A_const_60 = lang.RT_Keyword_String_String__Keyword(nil, Lit_53); A_arbace_main_A_const_61 = lang.RT_Keyword_String_String__Keyword(nil, Lit_54); A_arbace_main_A_const_62 = lang.RT_Keyword_String_String__Keyword(nil, Lit_55); A_arbace_main_A_const_63 = lang.RT_Keyword_String_String__Keyword(nil, Lit_56); A_arbace_main_A_const_64 = jrt.Character_ValueOf_C__Character(59).Ref(); A_arbace_main_A_const_65 = jrt.Character_ValueOf_C__Character(44).Ref(); A_arbace_main_A_const_66 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_main_A_const_67 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_main_A_const_68 = lang.RT_Var_String_String__Var(Lit_0, Lit_59); A_arbace_main_A_const_69 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_main_A_const_70 = lang.RT_Keyword_String_String__Keyword(Lit_0, Lit_61); A_arbace_main_A_const_71 = lang.RT_Keyword_String_String__Keyword(nil, Lit_62); A_arbace_main_A_const_72 = lang.RT_Var_String_String__Var(Lit_0, Lit_63); A_arbace_main_A_const_73 = lang.RT_Var_String_String__Var(Lit_11, Lit_64); A_arbace_main_A_const_74 = lang.RT_Var_String_String__Var(Lit_11, Lit_65); A_arbace_main_A_const_75 = lang.RT_Var_String_String__Var(Lit_0, Lit_66); A_arbace_main_A_const_76 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_67).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_68).Ref())); A_arbace_main_A_const_77 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_main_A_const_78 = lang.RT_Var_String_String__Var(Lit_11, Lit_69); A_arbace_main_A_const_79 = lang.RT_Var_String_String__Var(Lit_11, Lit_70); A_arbace_main_A_const_80 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); A_arbace_main_A_const_81 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref())).Ref(); A_arbace_main_A_const_82 = lang.RT_ClassForNameNonLoading_String__Class(Lit_74); A_arbace_main_A_const_83 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); A_arbace_main_A_const_84 = lang.RT_Var_String_String__Var(Lit_0, Lit_76); A_arbace_main_A_const_85 = jrt.Pattern_Compile_String__Pattern(Lit_77).Ref(); A_arbace_main_A_const_86 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_main_A_const_87 = lang.RT_Var_String_String__Var(Lit_0, Lit_79); A_arbace_main_A_const_88 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_main_A_const_89 = lang.RT_Var_String_String__Var(Lit_0, Lit_81); A_arbace_main_A_const_90 = lang.RT_Keyword_String_String__Keyword(nil, Lit_82); A_arbace_main_A_const_91 = lang.RT_Keyword_String_String__Keyword(nil, Lit_83); A_arbace_main_A_const_92 = lang.RT_Keyword_String_String__Keyword(nil, Lit_84); A_arbace_main_A_const_93 = lang.RT_Keyword_String_String__Keyword(nil, Lit_85); A_arbace_main_A_const_94 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_main_A_const_95 = lang.RT_Keyword_String_String__Keyword(nil, Lit_87); A_arbace_main_A_const_96 = lang.RT_Keyword_String_String__Keyword(nil, Lit_88); A_arbace_main_A_const_97 = lang.RT_Keyword_String_String__Keyword(nil, Lit_89); A_arbace_main_A_const_98 = lang.RT_Keyword_String_String__Keyword(Lit_5, Lit_90); A_arbace_main_A_const_99 = lang.RT_Keyword_String_String__Keyword(Lit_5, Lit_91); A_arbace_main_A_const_100 = lang.RT_Keyword_String_String__Keyword(Lit_92, Lit_93); A_arbace_main_A_const_101 = lang.RT_Keyword_String_String__Keyword(Lit_94, Lit_95); A_arbace_main_A_const_102 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_main_A_const_103 = lang.RT_Keyword_String_String__Keyword(nil, Lit_97); A_arbace_main_A_const_104 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_98, Lit_99)).Ref(); A_arbace_main_A_const_105 = lang.RT_Var_String_String__Var(Lit_0, Lit_100); A_arbace_main_A_const_106 = lang.RT_Keyword_String_String__Keyword(nil, Lit_101); A_arbace_main_A_const_107 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_98, Lit_99)).Ref(); A_arbace_main_A_const_108 = lang.RT_Keyword_String_String__Keyword(nil, Lit_102); A_arbace_main_A_const_109 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_98, Lit_99)).Ref(); A_arbace_main_A_const_110 = lang.RT_Keyword_String_String__Keyword(Lit_94, Lit_103); A_arbace_main_A_const_111 = lang.RT_Keyword_String_String__Keyword(Lit_94, Lit_85); A_arbace_main_A_const_112 = lang.RT_Var_String_String__Var(Lit_11, Lit_104); A_arbace_main_A_const_113 = lang.RT_Keyword_String_String__Keyword(Lit_94, Lit_105); A_arbace_main_A_const_114 = lang.RT_Var_String_String__Var(Lit_11, Lit_106); A_arbace_main_A_const_115 = lang.RT_Keyword_String_String__Keyword(Lit_94, Lit_107); A_arbace_main_A_const_116 = lang.RT_Keyword_String_String__Keyword(Lit_94, Lit_7); A_arbace_main_A_const_117 = lang.RT_Keyword_String_String__Keyword(nil, Lit_108); A_arbace_main_A_const_118 = lang.RT_Keyword_String_String__Keyword(Lit_94, Lit_62); A_arbace_main_A_const_119 = lang.RT_Keyword_String_String__Keyword(Lit_94, Lit_109); A_arbace_main_A_const_120 = lang.RT_Var_String_String__Var(Lit_0, Lit_110); A_arbace_main_A_const_121 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_98, Lit_99)).Ref(); A_arbace_main_A_const_122 = lang.RT_Var_String_String__Var(Lit_0, Lit_111); A_arbace_main_A_const_123 = lang.RT_Var_String_String__Var(Lit_11, Lit_112); A_arbace_main_A_const_124 = lang.RT_Var_String_String__Var(Lit_0, Lit_113); A_arbace_main_A_const_125 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_98, Lit_99)).Ref(); A_arbace_main_A_const_126 = lang.RT_Keyword_String_String__Keyword(nil, Lit_114); A_arbace_main_A_const_127 = lang.RT_Keyword_String_String__Keyword(Lit_94, Lit_76); A_arbace_main_A_const_128 = lang.RT_Var_String_String__Var(Lit_11, Lit_115); A_arbace_main_A_const_129 = lang.RT_Keyword_String_String__Keyword(nil, Lit_116); A_arbace_main_A_const_130 = lang.RT_Keyword_String_String__Keyword(nil, Lit_117); A_arbace_main_A_const_131 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_98, Lit_99)).Ref(); A_arbace_main_A_const_132 = lang.RT_Keyword_String_String__Keyword(nil, Lit_118); A_arbace_main_A_const_133 = lang.RT_Var_String_String__Var(Lit_0, Lit_119); A_arbace_main_A_const_134 = jrt.Pattern_Compile_String__Pattern(Lit_120).Ref(); A_arbace_main_A_const_135 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_121, Lit_122)).Ref(); A_arbace_main_A_const_136 = lang.RT_Var_String_String__Var(Lit_0, Lit_123); A_arbace_main_A_const_137 = lang.RT_Var_String_String__Var(Lit_5, Lit_124); A_arbace_main_A_const_138 = lang.RT_Var_String_String__Var(Lit_5, Lit_46); A_arbace_main_A_const_139 = lang.RT_Var_String_String__Var(Lit_5, Lit_125); A_arbace_main_A_const_140 = lang.RT_Var_String_String__Var(Lit_0, Lit_126); A_arbace_main_A_const_141 = lang.RT_Keyword_String_String__Keyword(nil, Lit_127); A_arbace_main_A_const_142 = lang.RT_Var_String_String__Var(Lit_0, Lit_128); A_arbace_main_A_const_143 = lang.RT_Var_String_String__Var(Lit_0, Lit_129); A_arbace_main_A_const_144 = lang.RT_Var_String_String__Var(Lit_0, Lit_130); A_arbace_main_A_const_145 = lang.RT_Var_String_String__Var(Lit_11, Lit_131); A_arbace_main_A_const_146 = lang.RT_Var_String_String__Var(Lit_11, Lit_132); A_arbace_main_A_const_147 = lang.RT_Var_String_String__Var(Lit_0, Lit_133); A_arbace_main_A_const_148 = lang.RT_Var_String_String__Var(Lit_0, Lit_134); A_arbace_main_A_const_149 = lang.RT_Var_String_String__Var(Lit_0, Lit_135); A_arbace_main_A_const_150 = lang.RT_Var_String_String__Var(Lit_0, Lit_136); A_arbace_main_A_const_151 = lang.RT_Var_String_String__Var(Lit_11, Lit_137); A_arbace_main_A_const_152 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_28).Ref(); A_arbace_main_A_const_153 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_138).Ref(); A_arbace_main_A_const_154 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_139).Ref(); A_arbace_main_A_const_155 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_140).Ref(); A_arbace_main_A_const_156 = lang.RT_Keyword_String_String__Keyword(nil, Lit_141); A_arbace_main_A_const_157 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_138).Ref(); A_arbace_main_A_const_158 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_138).Ref(); A_arbace_main_A_const_159 = lang.RT_Var_String_String__Var(Lit_0, Lit_142); A_arbace_main_A_const_160 = lang.RT_Var_String_String__Var(Lit_11, Lit_143); A_arbace_main_A_const_161 = lang.RT_Var_String_String__Var(Lit_11, Lit_144); A_arbace_main_A_const_162 = lang.RT_Var_String_String__Var(Lit_0, Lit_145); A_arbace_main_A_const_163 = lang.RT_Var_String_String__Var(Lit_0, Lit_146); A_arbace_main_A_const_164 = lang.RT_Var_String_String__Var(Lit_11, Lit_147); A_arbace_main_A_const_165 = lang.RT_Keyword_String_String__Keyword(nil, Lit_148); A_arbace_main_A_const_166 = lang.RT_Keyword_String_String__Keyword(nil, Lit_149); A_arbace_main_A_const_167 = lang.RT_Keyword_String_String__Keyword(nil, Lit_150); A_arbace_main_A_const_168 = lang.RT_Keyword_String_String__Keyword(nil, Lit_134); A_arbace_main_A_const_169 = lang.RT_Keyword_String_String__Keyword(nil, Lit_63); A_arbace_main_A_const_170 = lang.RT_Keyword_String_String__Keyword(nil, Lit_145); A_arbace_main_A_const_171 = lang.RT_Keyword_String_String__Keyword(nil, Lit_136); A_arbace_main_A_const_172 = lang.RT_Keyword_String_String__Keyword(nil, Lit_151); A_arbace_main_A_const_173 = lang.RT_Var_String_String__Var(Lit_0, Lit_138); A_arbace_main_A_const_174 = lang.RT_Var_String_String__Var(Lit_0, Lit_152); A_arbace_main_A_const_175 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(Lit_94, Lit_85).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref())); A_arbace_main_A_const_176 = lang.RT_Var_String_String__Var(Lit_0, Lit_49); A_arbace_main_A_const_177 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_main_A_const_178 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_main_A_const_179 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(Lit_94, Lit_85).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref())); A_arbace_main_A_const_180 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_main_A_const_181 = lang.RT_ClassForNameNonLoading_String__Class(Lit_153); A_arbace_main_A_const_182 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_main_A_const_183 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_main_A_const_184 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_main_A_const_185 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_main_A_const_186 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_main_A_const_187 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_main_A_const_188 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_main_A_const_189 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_main_A_const_190 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_main_A_const_191 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_main_A_const_192 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_main_A_const_193 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_main_A_const_194 = lang.RT_Var_String_String__Var(Lit_0, Lit_154); A_arbace_main_A_const_195 = lang.RT_Var_String_String__Var(Lit_0, Lit_155); A_arbace_main_A_const_196 = lang.Symbol_Intern_String_String__Symbol(Lit_156, Lit_157).Ref(); A_arbace_main_A_const_197 = lang.RT_Var_String_String__Var(Lit_11, Lit_158); A_arbace_main_A_const_198 = lang.RT_Var_String_String__Var(Lit_11, Lit_159); A_arbace_main_A_const_199 = lang.RT_Var_String_String__Var(Lit_11, Lit_160); A_arbace_main_A_const_200 = lang.RT_Var_String_String__Var(Lit_0, Lit_161); A_arbace_main_A_const_201 = lang.RT_Var_String_String__Var(Lit_0, Lit_162); A_arbace_main_A_const_202 = lang.RT_Var_String_String__Var(Lit_0, Lit_163); A_arbace_main_A_const_203 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_164).Ref(); A_arbace_main_A_const_204 = lang.RT_Var_String_String__Var(Lit_11, Lit_165); A_arbace_main_A_const_205 = lang.RT_Var_String_String__Var(Lit_0, Lit_166); A_arbace_main_A_const_206 = lang.RT_Var_String_String__Var(Lit_11, Lit_167); A_arbace_main_A_const_207 = lang.RT_Var_String_String__Var(Lit_0, Lit_168); A_arbace_main_A_const_208 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_169).Ref(); A_arbace_main_A_const_209 = lang.RT_Var_String_String__Var(Lit_0, Lit_170); A_arbace_main_A_const_210 = lang.RT_Var_String_String__Var(Lit_0, Lit_171); A_arbace_main_A_const_211 = lang.RT_Var_String_String__Var(Lit_11, Lit_172); A_arbace_main_A_const_212 = lang.RT_Var_String_String__Var(Lit_0, Lit_173); A_arbace_main_A_const_213 = lang.RT_Keyword_String_String__Keyword(nil, Lit_174); A_arbace_main_A_const_214 = lang.RT_Var_String_String__Var(Lit_0, Lit_175); A_arbace_main_A_const_215 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_main_A_const_216 = lang.RT_Var_String_String__Var(Lit_11, Lit_176); A_arbace_main_A_const_217 = lang.RT_Var_String_String__Var(Lit_0, Lit_177); A_arbace_main_A_const_218 = lang.RT_Keyword_String_String__Keyword(nil, Lit_12); A_arbace_main_A_const_219 = lang.RT_Var_String_String__Var(Lit_11, Lit_178); A_arbace_main_A_const_220 = lang.RT_Var_String_String__Var(Lit_11, Lit_179); A_arbace_main_A_const_221 = lang.RT_Var_String_String__Var(Lit_11, Lit_180); A_arbace_main_A_const_222 = lang.RT_Var_String_String__Var(Lit_11, Lit_181); A_arbace_main_A_const_223 = lang.RT_Var_String_String__Var(Lit_11, Lit_182); A_arbace_main_A_const_224 = lang.RT_Var_String_String__Var(Lit_11, Lit_183); A_arbace_main_A_const_225 = lang.RT_Var_String_String__Var(Lit_0, Lit_184); A_arbace_main_A_const_226 = lang.RT_Var_String_String__Var(Lit_0, Lit_185); A_arbace_main_A_const_227 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_186)).Ref(); A_arbace_main_A_const_228 = lang.Tuple_Create_O__IPersistentVector(Lit_187); A_arbace_main_A_const_229 = lang.RT_Var_String_String__Var(Lit_0, Lit_188); A_arbace_main_A_const_230 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_186)).Ref(); A_arbace_main_A_const_231 = lang.RT_Keyword_String_String__Keyword(nil, Lit_189); A_arbace_main_A_const_232 = lang.RT_Var_String_String__Var(Lit_0, Lit_190); A_arbace_main_A_const_233 = lang.RT_ClassForNameNonLoading_String__Class(Lit_191); A_arbace_main_A_const_234 = lang.RT_Keyword_String_String__Keyword(Lit_11, Lit_88); A_arbace_main_A_const_235 = lang.RT_Keyword_String_String__Keyword(Lit_11, Lit_192); A_arbace_main_A_const_236 = lang.RT_Keyword_String_String__Keyword(Lit_11, Lit_84); A_arbace_main_A_const_237 = lang.RT_Keyword_String_String__Keyword(nil, Lit_180); A_arbace_main_A_const_238 = lang.RT_Var_String_String__Var(Lit_11, Lit_193); A_arbace_main_A_const_239 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_194)).Ref(); A_arbace_main_A_const_240 = jrt.Long_ValueOf_J__Long(2).Ref(); A_arbace_main_A_const_241 = lang.RT_Var_String_String__Var(Lit_11, Lit_195) }

func A_arbace_main_A_New() *A_arbace_main_A { A_arbace_main_A_Init(); t := &A_arbace_main_A{}; t.Ctor(); return t }

func (t *A_arbace_main_A) Ctor() {}

func (t *A_arbace_main_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_A) GetClass__Class() *jrt.Class { return A_arbace_main_A_class }

func (t *A_arbace_main_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_A); return ok }

func A_arbace_main_A_Cast(x any) *A_arbace_main_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_A_class)) }; return v }



type A_arbace_main_core_class_QMARK__A struct{ jrt.Object }

func (t *A_arbace_main_core_class_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_main_core_class_QMARK__A_fn_class *jrt.Class

var A_arbace_main_core_class_QMARK__A_init jrt.ClassInit

func A_arbace_main_core_class_QMARK__A_Init() { if !A_arbace_main_core_class_QMARK__A_init.Done() { A_arbace_main_core_class_QMARK__A_init.Run(A_arbace_main_core_class_QMARK__A_clinit) } }

func A_arbace_main_core_class_QMARK__A_clinit() { A_arbace_main_core_class_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_196, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_core_class_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_core_class_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_main_core_class_QMARK__A_class }

func (t *A_arbace_main_core_class_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_core_class_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_core_class_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_core_class_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_core_class_QMARK__A); return ok }

func A_arbace_main_core_class_QMARK__A_Cast(x any) *A_arbace_main_core_class_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_core_class_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_core_class_QMARK__A_class)) }; return v }



type A_arbace_main_demunge_A struct{ jrt.Object }

func (t *A_arbace_main_demunge_A) Is_Compiler_AOTF1() {}

var A_arbace_main_demunge_A_fn_class *jrt.Class

var A_arbace_main_demunge_A_init jrt.ClassInit

func A_arbace_main_demunge_A_Init() { if !A_arbace_main_demunge_A_init.Done() { A_arbace_main_demunge_A_init.Run(A_arbace_main_demunge_A_clinit) } }

func A_arbace_main_demunge_A_clinit() { A_arbace_main_demunge_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_198, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_demunge_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_demunge_A) GetClass__Class() *jrt.Class { return A_arbace_main_demunge_A_class }

func (t *A_arbace_main_demunge_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_demunge_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_demunge_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_demunge_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_demunge_A); return ok }

func A_arbace_main_demunge_A_Cast(x any) *A_arbace_main_demunge_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_demunge_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_demunge_A_class)) }; return v }



type A_arbace_main_err__GT_msg_A struct{ jrt.Object }

func (t *A_arbace_main_err__GT_msg_A) Is_Compiler_AOTF1() {}

var A_arbace_main_err__GT_msg_A_fn_class *jrt.Class

var A_arbace_main_err__GT_msg_A_init jrt.ClassInit

func A_arbace_main_err__GT_msg_A_Init() { if !A_arbace_main_err__GT_msg_A_init.Done() { A_arbace_main_err__GT_msg_A_init.Run(A_arbace_main_err__GT_msg_A_clinit) } }

func A_arbace_main_err__GT_msg_A_clinit() { A_arbace_main_err__GT_msg_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_199, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_err__GT_msg_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_err__GT_msg_A) GetClass__Class() *jrt.Class { return A_arbace_main_err__GT_msg_A_class }

func (t *A_arbace_main_err__GT_msg_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_err__GT_msg_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_err__GT_msg_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_err__GT_msg_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_err__GT_msg_A); return ok }

func A_arbace_main_err__GT_msg_A_Cast(x any) *A_arbace_main_err__GT_msg_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_err__GT_msg_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_err__GT_msg_A_class)) }; return v }



type A_arbace_main_eval461000004_A struct{ jrt.Object }

func A_arbace_main_eval461000004_A_New() *A_arbace_main_eval461000004_A { t := &A_arbace_main_eval461000004_A{}; t.Ctor(); return t }

func (t *A_arbace_main_eval461000004_A) Ctor() {}

func (t *A_arbace_main_eval461000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_eval461000004_A) GetClass__Class() *jrt.Class { return A_arbace_main_eval461000004_A_class }

func (t *A_arbace_main_eval461000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_eval461000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_eval461000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_eval461000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_eval461000004_A); return ok }

func A_arbace_main_eval461000004_A_Cast(x any) *A_arbace_main_eval461000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_eval461000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_eval461000004_A_class)) }; return v }



type A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A struct{ jrt.Object }

func (t *A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A) Is_Compiler_AOTF0() {}

var A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_fn_class *jrt.Class

var A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_init jrt.ClassInit

func A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_Init() { if !A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_init.Done() { A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_init.Run(A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_clinit) } }

func A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_clinit() { A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_200, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A) GetClass__Class() *jrt.Class { return A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_class }

func (t *A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A); return ok }

func A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_Cast(x any) *A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_eval461000004_loading__1927001464__auto____461000005_A_class)) }; return v }



type A_arbace_main_eval461000008_A struct{ jrt.Object }

func A_arbace_main_eval461000008_A_New() *A_arbace_main_eval461000008_A { t := &A_arbace_main_eval461000008_A{}; t.Ctor(); return t }

func (t *A_arbace_main_eval461000008_A) Ctor() {}

func (t *A_arbace_main_eval461000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_eval461000008_A) GetClass__Class() *jrt.Class { return A_arbace_main_eval461000008_A_class }

func (t *A_arbace_main_eval461000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_eval461000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_eval461000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_eval461000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_eval461000008_A); return ok }

func A_arbace_main_eval461000008_A_Cast(x any) *A_arbace_main_eval461000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_eval461000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_eval461000008_A_class)) }; return v }



type A_arbace_main_eval461000008_fn__461000009_A struct{ jrt.Object }

func (t *A_arbace_main_eval461000008_fn__461000009_A) Is_Compiler_AOTF0() {}

var A_arbace_main_eval461000008_fn__461000009_A_fn_class *jrt.Class

var A_arbace_main_eval461000008_fn__461000009_A_init jrt.ClassInit

func A_arbace_main_eval461000008_fn__461000009_A_Init() { if !A_arbace_main_eval461000008_fn__461000009_A_init.Done() { A_arbace_main_eval461000008_fn__461000009_A_init.Run(A_arbace_main_eval461000008_fn__461000009_A_clinit) } }

func A_arbace_main_eval461000008_fn__461000009_A_clinit() { A_arbace_main_eval461000008_fn__461000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_210, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_eval461000008_fn__461000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_eval461000008_fn__461000009_A) GetClass__Class() *jrt.Class { return A_arbace_main_eval461000008_fn__461000009_A_class }

func (t *A_arbace_main_eval461000008_fn__461000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_eval461000008_fn__461000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_eval461000008_fn__461000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_eval461000008_fn__461000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_eval461000008_fn__461000009_A); return ok }

func A_arbace_main_eval461000008_fn__461000009_A_Cast(x any) *A_arbace_main_eval461000008_fn__461000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_eval461000008_fn__461000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_eval461000008_fn__461000009_A_class)) }; return v }



type A_arbace_main_eval_opt_A struct{ jrt.Object }

func (t *A_arbace_main_eval_opt_A) Is_Compiler_AOTF1() {}

var A_arbace_main_eval_opt_A_fn_class *jrt.Class

var A_arbace_main_eval_opt_A_init jrt.ClassInit

func A_arbace_main_eval_opt_A_Init() { if !A_arbace_main_eval_opt_A_init.Done() { A_arbace_main_eval_opt_A_init.Run(A_arbace_main_eval_opt_A_clinit) } }

func A_arbace_main_eval_opt_A_clinit() { A_arbace_main_eval_opt_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_211, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_eval_opt_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_eval_opt_A) GetClass__Class() *jrt.Class { return A_arbace_main_eval_opt_A_class }

func (t *A_arbace_main_eval_opt_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_eval_opt_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_eval_opt_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_eval_opt_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_eval_opt_A); return ok }

func A_arbace_main_eval_opt_A_Cast(x any) *A_arbace_main_eval_opt_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_eval_opt_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_eval_opt_A_class)) }; return v }



type A_arbace_main_eval_opt_fn__461000135_A struct{ jrt.Object; F_reader, F_eof any }

func (t *A_arbace_main_eval_opt_fn__461000135_A) Is_Compiler_AOTF0() {}

var A_arbace_main_eval_opt_fn__461000135_A_fn_class *jrt.Class

var A_arbace_main_eval_opt_fn__461000135_A_init jrt.ClassInit

func A_arbace_main_eval_opt_fn__461000135_A_Init() { if !A_arbace_main_eval_opt_fn__461000135_A_init.Done() { A_arbace_main_eval_opt_fn__461000135_A_init.Run(A_arbace_main_eval_opt_fn__461000135_A_clinit) } }

func A_arbace_main_eval_opt_fn__461000135_A_clinit() { A_arbace_main_eval_opt_fn__461000135_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_212, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_eval_opt_fn__461000135_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_eval_opt_fn__461000135_A) GetClass__Class() *jrt.Class { return A_arbace_main_eval_opt_fn__461000135_A_class }

func (t *A_arbace_main_eval_opt_fn__461000135_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_eval_opt_fn__461000135_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_eval_opt_fn__461000135_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_eval_opt_fn__461000135_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_eval_opt_fn__461000135_A); return ok }

func A_arbace_main_eval_opt_fn__461000135_A_Cast(x any) *A_arbace_main_eval_opt_fn__461000135_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_eval_opt_fn__461000135_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_eval_opt_fn__461000135_A_class)) }; return v }



type A_arbace_main_eval_opt_fn__461000137_A struct{ jrt.Object; F_reader, F_eof any }

func (t *A_arbace_main_eval_opt_fn__461000137_A) Is_Compiler_AOTF0() {}

var A_arbace_main_eval_opt_fn__461000137_A_fn_class *jrt.Class

var A_arbace_main_eval_opt_fn__461000137_A_init jrt.ClassInit

func A_arbace_main_eval_opt_fn__461000137_A_Init() { if !A_arbace_main_eval_opt_fn__461000137_A_init.Done() { A_arbace_main_eval_opt_fn__461000137_A_init.Run(A_arbace_main_eval_opt_fn__461000137_A_clinit) } }

func A_arbace_main_eval_opt_fn__461000137_A_clinit() { A_arbace_main_eval_opt_fn__461000137_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_213, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_eval_opt_fn__461000137_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_eval_opt_fn__461000137_A) GetClass__Class() *jrt.Class { return A_arbace_main_eval_opt_fn__461000137_A_class }

func (t *A_arbace_main_eval_opt_fn__461000137_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_eval_opt_fn__461000137_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_eval_opt_fn__461000137_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_eval_opt_fn__461000137_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_eval_opt_fn__461000137_A); return ok }

func A_arbace_main_eval_opt_fn__461000137_A_Cast(x any) *A_arbace_main_eval_opt_fn__461000137_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_eval_opt_fn__461000137_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_eval_opt_fn__461000137_A_class)) }; return v }



type A_arbace_main_ex_str_A struct{ jrt.Object }

func (t *A_arbace_main_ex_str_A) Is_Compiler_AOTF1() {}

var A_arbace_main_ex_str_A_fn_class *jrt.Class

var A_arbace_main_ex_str_A_init jrt.ClassInit

func A_arbace_main_ex_str_A_Init() { if !A_arbace_main_ex_str_A_init.Done() { A_arbace_main_ex_str_A_init.Run(A_arbace_main_ex_str_A_clinit) } }

func A_arbace_main_ex_str_A_clinit() { A_arbace_main_ex_str_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_214, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_ex_str_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_ex_str_A) GetClass__Class() *jrt.Class { return A_arbace_main_ex_str_A_class }

func (t *A_arbace_main_ex_str_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_ex_str_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_ex_str_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_ex_str_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_ex_str_A); return ok }

func A_arbace_main_ex_str_A_Cast(x any) *A_arbace_main_ex_str_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_ex_str_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_ex_str_A_class)) }; return v }



type A_arbace_main_ex_str_fn__461000085_A struct{ jrt.Object; F_spec, F_s__1927001093__auto__ any }

func (t *A_arbace_main_ex_str_fn__461000085_A) Is_Compiler_AOTF0() {}

var A_arbace_main_ex_str_fn__461000085_A_fn_class *jrt.Class

var A_arbace_main_ex_str_fn__461000085_A_init jrt.ClassInit

func A_arbace_main_ex_str_fn__461000085_A_Init() { if !A_arbace_main_ex_str_fn__461000085_A_init.Done() { A_arbace_main_ex_str_fn__461000085_A_init.Run(A_arbace_main_ex_str_fn__461000085_A_clinit) } }

func A_arbace_main_ex_str_fn__461000085_A_clinit() { A_arbace_main_ex_str_fn__461000085_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_232, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_ex_str_fn__461000085_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_ex_str_fn__461000085_A) GetClass__Class() *jrt.Class { return A_arbace_main_ex_str_fn__461000085_A_class }

func (t *A_arbace_main_ex_str_fn__461000085_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_ex_str_fn__461000085_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_ex_str_fn__461000085_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_ex_str_fn__461000085_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_ex_str_fn__461000085_A); return ok }

func A_arbace_main_ex_str_fn__461000085_A_Cast(x any) *A_arbace_main_ex_str_fn__461000085_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_ex_str_fn__461000085_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_ex_str_fn__461000085_A_class)) }; return v }



type A_arbace_main_ex_str_fn__461000085_fn__461000086_A struct{ jrt.Object }

func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_A) Is_Compiler_AOTF1() {}

var A_arbace_main_ex_str_fn__461000085_fn__461000086_A_fn_class *jrt.Class

var A_arbace_main_ex_str_fn__461000085_fn__461000086_A_init jrt.ClassInit

func A_arbace_main_ex_str_fn__461000085_fn__461000086_A_Init() { if !A_arbace_main_ex_str_fn__461000085_fn__461000086_A_init.Done() { A_arbace_main_ex_str_fn__461000085_fn__461000086_A_init.Run(A_arbace_main_ex_str_fn__461000085_fn__461000086_A_clinit) } }

func A_arbace_main_ex_str_fn__461000085_fn__461000086_A_clinit() { A_arbace_main_ex_str_fn__461000085_fn__461000086_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_233, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_A) GetClass__Class() *jrt.Class { return A_arbace_main_ex_str_fn__461000085_fn__461000086_A_class }

func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_ex_str_fn__461000085_fn__461000086_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_ex_str_fn__461000085_fn__461000086_A); return ok }

func A_arbace_main_ex_str_fn__461000085_fn__461000086_A_Cast(x any) *A_arbace_main_ex_str_fn__461000085_fn__461000086_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_ex_str_fn__461000085_fn__461000086_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_ex_str_fn__461000085_fn__461000086_A_class)) }; return v }



type A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A struct{ jrt.Object }

func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A) Is_Compiler_AOTF1() {}

var A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_fn_class *jrt.Class

var A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_init jrt.ClassInit

func A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_Init() { if !A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_init.Done() { A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_init.Run(A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_clinit) } }

func A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_clinit() { A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_234, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A) GetClass__Class() *jrt.Class { return A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_class }

func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A); return ok }

func A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_Cast(x any) *A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_ex_str_fn__461000085_fn__461000086_fn__461000087_A_class)) }; return v }



type A_arbace_main_ex_str_fn__461000091_A struct{ jrt.Object; F_spec, F_s__1927001093__auto__ any }

func (t *A_arbace_main_ex_str_fn__461000091_A) Is_Compiler_AOTF0() {}

var A_arbace_main_ex_str_fn__461000091_A_fn_class *jrt.Class

var A_arbace_main_ex_str_fn__461000091_A_init jrt.ClassInit

func A_arbace_main_ex_str_fn__461000091_A_Init() { if !A_arbace_main_ex_str_fn__461000091_A_init.Done() { A_arbace_main_ex_str_fn__461000091_A_init.Run(A_arbace_main_ex_str_fn__461000091_A_clinit) } }

func A_arbace_main_ex_str_fn__461000091_A_clinit() { A_arbace_main_ex_str_fn__461000091_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_235, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_ex_str_fn__461000091_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_ex_str_fn__461000091_A) GetClass__Class() *jrt.Class { return A_arbace_main_ex_str_fn__461000091_A_class }

func (t *A_arbace_main_ex_str_fn__461000091_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_ex_str_fn__461000091_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_ex_str_fn__461000091_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_ex_str_fn__461000091_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_ex_str_fn__461000091_A); return ok }

func A_arbace_main_ex_str_fn__461000091_A_Cast(x any) *A_arbace_main_ex_str_fn__461000091_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_ex_str_fn__461000091_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_ex_str_fn__461000091_A_class)) }; return v }



type A_arbace_main_ex_str_fn__461000091_fn__461000092_A struct{ jrt.Object }

func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_A) Is_Compiler_AOTF1() {}

var A_arbace_main_ex_str_fn__461000091_fn__461000092_A_fn_class *jrt.Class

var A_arbace_main_ex_str_fn__461000091_fn__461000092_A_init jrt.ClassInit

func A_arbace_main_ex_str_fn__461000091_fn__461000092_A_Init() { if !A_arbace_main_ex_str_fn__461000091_fn__461000092_A_init.Done() { A_arbace_main_ex_str_fn__461000091_fn__461000092_A_init.Run(A_arbace_main_ex_str_fn__461000091_fn__461000092_A_clinit) } }

func A_arbace_main_ex_str_fn__461000091_fn__461000092_A_clinit() { A_arbace_main_ex_str_fn__461000091_fn__461000092_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_236, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_A) GetClass__Class() *jrt.Class { return A_arbace_main_ex_str_fn__461000091_fn__461000092_A_class }

func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_ex_str_fn__461000091_fn__461000092_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_ex_str_fn__461000091_fn__461000092_A); return ok }

func A_arbace_main_ex_str_fn__461000091_fn__461000092_A_Cast(x any) *A_arbace_main_ex_str_fn__461000091_fn__461000092_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_ex_str_fn__461000091_fn__461000092_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_ex_str_fn__461000091_fn__461000092_A_class)) }; return v }



type A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A struct{ jrt.Object }

func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A) Is_Compiler_AOTF1() {}

var A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_fn_class *jrt.Class

var A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_init jrt.ClassInit

func A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_Init() { if !A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_init.Done() { A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_init.Run(A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_clinit) } }

func A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_clinit() { A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_237, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A) GetClass__Class() *jrt.Class { return A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_class }

func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A); return ok }

func A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_Cast(x any) *A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_ex_str_fn__461000091_fn__461000092_fn__461000093_A_class)) }; return v }



type A_arbace_main_ex_triage_A struct{ jrt.Object }

func (t *A_arbace_main_ex_triage_A) Is_Compiler_AOTF1() {}

var A_arbace_main_ex_triage_A_fn_class *jrt.Class

var A_arbace_main_ex_triage_A_init jrt.ClassInit

func A_arbace_main_ex_triage_A_Init() { if !A_arbace_main_ex_triage_A_init.Done() { A_arbace_main_ex_triage_A_init.Run(A_arbace_main_ex_triage_A_clinit) } }

func A_arbace_main_ex_triage_A_clinit() { A_arbace_main_ex_triage_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_238, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_ex_triage_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_ex_triage_A) GetClass__Class() *jrt.Class { return A_arbace_main_ex_triage_A_class }

func (t *A_arbace_main_ex_triage_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_ex_triage_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_ex_triage_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_ex_triage_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_ex_triage_A); return ok }

func A_arbace_main_ex_triage_A_Cast(x any) *A_arbace_main_ex_triage_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_ex_triage_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_ex_triage_A_class)) }; return v }



type A_arbace_main_ex_triage_fn__461000061_A struct{ jrt.Object }

func (t *A_arbace_main_ex_triage_fn__461000061_A) Is_Compiler_AOTF1() {}

var A_arbace_main_ex_triage_fn__461000061_A_fn_class *jrt.Class

var A_arbace_main_ex_triage_fn__461000061_A_init jrt.ClassInit

func A_arbace_main_ex_triage_fn__461000061_A_Init() { if !A_arbace_main_ex_triage_fn__461000061_A_init.Done() { A_arbace_main_ex_triage_fn__461000061_A_init.Run(A_arbace_main_ex_triage_fn__461000061_A_clinit) } }

func A_arbace_main_ex_triage_fn__461000061_A_clinit() { A_arbace_main_ex_triage_fn__461000061_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_239, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_ex_triage_fn__461000061_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_ex_triage_fn__461000061_A) GetClass__Class() *jrt.Class { return A_arbace_main_ex_triage_fn__461000061_A_class }

func (t *A_arbace_main_ex_triage_fn__461000061_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_ex_triage_fn__461000061_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_ex_triage_fn__461000061_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_ex_triage_fn__461000061_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_ex_triage_fn__461000061_A); return ok }

func A_arbace_main_ex_triage_fn__461000061_A_Cast(x any) *A_arbace_main_ex_triage_fn__461000061_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_ex_triage_fn__461000061_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_ex_triage_fn__461000061_A_class)) }; return v }



type A_arbace_main_ex_triage_fn__461000063_A struct{ jrt.Object }

func (t *A_arbace_main_ex_triage_fn__461000063_A) Is_Compiler_AOTF1() {}

var A_arbace_main_ex_triage_fn__461000063_A_fn_class *jrt.Class

var A_arbace_main_ex_triage_fn__461000063_A_init jrt.ClassInit

func A_arbace_main_ex_triage_fn__461000063_A_Init() { if !A_arbace_main_ex_triage_fn__461000063_A_init.Done() { A_arbace_main_ex_triage_fn__461000063_A_init.Run(A_arbace_main_ex_triage_fn__461000063_A_clinit) } }

func A_arbace_main_ex_triage_fn__461000063_A_clinit() { A_arbace_main_ex_triage_fn__461000063_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_240, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_ex_triage_fn__461000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_ex_triage_fn__461000063_A) GetClass__Class() *jrt.Class { return A_arbace_main_ex_triage_fn__461000063_A_class }

func (t *A_arbace_main_ex_triage_fn__461000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_ex_triage_fn__461000063_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_ex_triage_fn__461000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_ex_triage_fn__461000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_ex_triage_fn__461000063_A); return ok }

func A_arbace_main_ex_triage_fn__461000063_A_Cast(x any) *A_arbace_main_ex_triage_fn__461000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_ex_triage_fn__461000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_ex_triage_fn__461000063_A_class)) }; return v }



type A_arbace_main_file_name_A struct{ jrt.Object }

func (t *A_arbace_main_file_name_A) Is_Compiler_AOTF1() {}

var A_arbace_main_file_name_A_fn_class *jrt.Class

var A_arbace_main_file_name_A_init jrt.ClassInit

func A_arbace_main_file_name_A_Init() { if !A_arbace_main_file_name_A_init.Done() { A_arbace_main_file_name_A_init.Run(A_arbace_main_file_name_A_clinit) } }

func A_arbace_main_file_name_A_clinit() { A_arbace_main_file_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_241, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_file_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_file_name_A) GetClass__Class() *jrt.Class { return A_arbace_main_file_name_A_class }

func (t *A_arbace_main_file_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_file_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_file_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_file_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_file_name_A); return ok }

func A_arbace_main_file_name_A_Cast(x any) *A_arbace_main_file_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_file_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_file_name_A_class)) }; return v }



type A_arbace_main_file_path_A struct{ jrt.Object }

func (t *A_arbace_main_file_path_A) Is_Compiler_AOTF1() {}

var A_arbace_main_file_path_A_fn_class *jrt.Class

var A_arbace_main_file_path_A_init jrt.ClassInit

func A_arbace_main_file_path_A_Init() { if !A_arbace_main_file_path_A_init.Done() { A_arbace_main_file_path_A_init.Run(A_arbace_main_file_path_A_clinit) } }

func A_arbace_main_file_path_A_clinit() { A_arbace_main_file_path_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_242, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_file_path_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_file_path_A) GetClass__Class() *jrt.Class { return A_arbace_main_file_path_A_class }

func (t *A_arbace_main_file_path_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_file_path_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_file_path_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_file_path_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_file_path_A); return ok }

func A_arbace_main_file_path_A_Cast(x any) *A_arbace_main_file_path_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_file_path_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_file_path_A_class)) }; return v }



type A_arbace_main_help_opt_A struct{ jrt.Object }

func (t *A_arbace_main_help_opt_A) Is_Compiler_AOTF2() {}

var A_arbace_main_help_opt_A_fn_class *jrt.Class

var A_arbace_main_help_opt_A_init jrt.ClassInit

func A_arbace_main_help_opt_A_Init() { if !A_arbace_main_help_opt_A_init.Done() { A_arbace_main_help_opt_A_init.Run(A_arbace_main_help_opt_A_clinit) } }

func A_arbace_main_help_opt_A_clinit() { A_arbace_main_help_opt_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_244, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_help_opt_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_help_opt_A) GetClass__Class() *jrt.Class { return A_arbace_main_help_opt_A_class }

func (t *A_arbace_main_help_opt_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_help_opt_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_help_opt_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_help_opt_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_help_opt_A); return ok }

func A_arbace_main_help_opt_A_Cast(x any) *A_arbace_main_help_opt_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_help_opt_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_help_opt_A_class)) }; return v }



type A_arbace_main_init_dispatch_A struct{ jrt.Object }

func (t *A_arbace_main_init_dispatch_A) Is_Compiler_AOTF1() {}

var A_arbace_main_init_dispatch_A_fn_class *jrt.Class

var A_arbace_main_init_dispatch_A_init jrt.ClassInit

func A_arbace_main_init_dispatch_A_Init() { if !A_arbace_main_init_dispatch_A_init.Done() { A_arbace_main_init_dispatch_A_init.Run(A_arbace_main_init_dispatch_A_clinit) } }

func A_arbace_main_init_dispatch_A_clinit() { A_arbace_main_init_dispatch_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_245, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_init_dispatch_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_init_dispatch_A) GetClass__Class() *jrt.Class { return A_arbace_main_init_dispatch_A_class }

func (t *A_arbace_main_init_dispatch_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_init_dispatch_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_init_dispatch_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_init_dispatch_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_init_dispatch_A); return ok }

func A_arbace_main_init_dispatch_A_Cast(x any) *A_arbace_main_init_dispatch_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_init_dispatch_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_init_dispatch_A_class)) }; return v }



type A_arbace_main_init_opt_A struct{ jrt.Object }

func (t *A_arbace_main_init_opt_A) Is_Compiler_AOTF1() {}

var A_arbace_main_init_opt_A_fn_class *jrt.Class

var A_arbace_main_init_opt_A_init jrt.ClassInit

func A_arbace_main_init_opt_A_Init() { if !A_arbace_main_init_opt_A_init.Done() { A_arbace_main_init_opt_A_init.Run(A_arbace_main_init_opt_A_clinit) } }

func A_arbace_main_init_opt_A_clinit() { A_arbace_main_init_opt_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_250, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_init_opt_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_init_opt_A) GetClass__Class() *jrt.Class { return A_arbace_main_init_opt_A_class }

func (t *A_arbace_main_init_opt_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_init_opt_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_init_opt_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_init_opt_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_init_opt_A); return ok }

func A_arbace_main_init_opt_A_Cast(x any) *A_arbace_main_init_opt_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_init_opt_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_init_opt_A_class)) }; return v }



type A_arbace_main_initialize_A struct{ jrt.Object }

func (t *A_arbace_main_initialize_A) Is_Compiler_AOTF2() {}

var A_arbace_main_initialize_A_fn_class *jrt.Class

var A_arbace_main_initialize_A_init jrt.ClassInit

func A_arbace_main_initialize_A_Init() { if !A_arbace_main_initialize_A_init.Done() { A_arbace_main_initialize_A_init.Run(A_arbace_main_initialize_A_clinit) } }

func A_arbace_main_initialize_A_clinit() { A_arbace_main_initialize_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_251, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_initialize_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_initialize_A) GetClass__Class() *jrt.Class { return A_arbace_main_initialize_A_class }

func (t *A_arbace_main_initialize_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_initialize_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_initialize_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_initialize_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_initialize_A); return ok }

func A_arbace_main_initialize_A_Cast(x any) *A_arbace_main_initialize_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_initialize_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_initialize_A_class)) }; return v }



type A_arbace_main_java_loc__GT_source_A struct{ jrt.Object }

func (t *A_arbace_main_java_loc__GT_source_A) Is_Compiler_AOTF2() {}

var A_arbace_main_java_loc__GT_source_A_fn_class *jrt.Class

var A_arbace_main_java_loc__GT_source_A_init jrt.ClassInit

func A_arbace_main_java_loc__GT_source_A_Init() { if !A_arbace_main_java_loc__GT_source_A_init.Done() { A_arbace_main_java_loc__GT_source_A_init.Run(A_arbace_main_java_loc__GT_source_A_clinit) } }

func A_arbace_main_java_loc__GT_source_A_clinit() { A_arbace_main_java_loc__GT_source_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_252, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_java_loc__GT_source_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_java_loc__GT_source_A) GetClass__Class() *jrt.Class { return A_arbace_main_java_loc__GT_source_A_class }

func (t *A_arbace_main_java_loc__GT_source_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_java_loc__GT_source_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_java_loc__GT_source_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_java_loc__GT_source_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_java_loc__GT_source_A); return ok }

func A_arbace_main_java_loc__GT_source_A_Cast(x any) *A_arbace_main_java_loc__GT_source_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_java_loc__GT_source_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_java_loc__GT_source_A_class)) }; return v }



type A_arbace_main_java_loc__GT_source_degen__461000039_A struct{ jrt.Object }

func (t *A_arbace_main_java_loc__GT_source_degen__461000039_A) Is_Compiler_AOTF1() {}

var A_arbace_main_java_loc__GT_source_degen__461000039_A_fn_class *jrt.Class

var A_arbace_main_java_loc__GT_source_degen__461000039_A_init jrt.ClassInit

func A_arbace_main_java_loc__GT_source_degen__461000039_A_Init() { if !A_arbace_main_java_loc__GT_source_degen__461000039_A_init.Done() { A_arbace_main_java_loc__GT_source_degen__461000039_A_init.Run(A_arbace_main_java_loc__GT_source_degen__461000039_A_clinit) } }

func A_arbace_main_java_loc__GT_source_degen__461000039_A_clinit() { A_arbace_main_java_loc__GT_source_degen__461000039_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_254, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_java_loc__GT_source_degen__461000039_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_java_loc__GT_source_degen__461000039_A) GetClass__Class() *jrt.Class { return A_arbace_main_java_loc__GT_source_degen__461000039_A_class }

func (t *A_arbace_main_java_loc__GT_source_degen__461000039_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_java_loc__GT_source_degen__461000039_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_java_loc__GT_source_degen__461000039_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_java_loc__GT_source_degen__461000039_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_java_loc__GT_source_degen__461000039_A); return ok }

func A_arbace_main_java_loc__GT_source_degen__461000039_A_Cast(x any) *A_arbace_main_java_loc__GT_source_degen__461000039_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_java_loc__GT_source_degen__461000039_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_java_loc__GT_source_degen__461000039_A_class)) }; return v }



type A_arbace_main_legacy_repl_A struct{ jrt.Object }

func (t *A_arbace_main_legacy_repl_A) Is_Compiler_AOTF1() {}

var A_arbace_main_legacy_repl_A_fn_class *jrt.Class

var A_arbace_main_legacy_repl_A_init jrt.ClassInit

func A_arbace_main_legacy_repl_A_Init() { if !A_arbace_main_legacy_repl_A_init.Done() { A_arbace_main_legacy_repl_A_init.Run(A_arbace_main_legacy_repl_A_clinit) } }

func A_arbace_main_legacy_repl_A_clinit() { A_arbace_main_legacy_repl_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_257, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_legacy_repl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_legacy_repl_A) GetClass__Class() *jrt.Class { return A_arbace_main_legacy_repl_A_class }

func (t *A_arbace_main_legacy_repl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_legacy_repl_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_legacy_repl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_legacy_repl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_legacy_repl_A); return ok }

func A_arbace_main_legacy_repl_A_Cast(x any) *A_arbace_main_legacy_repl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_legacy_repl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_legacy_repl_A_class)) }; return v }



type A_arbace_main_legacy_script_A struct{ jrt.Object }

func (t *A_arbace_main_legacy_script_A) Is_Compiler_AOTF1() {}

var A_arbace_main_legacy_script_A_fn_class *jrt.Class

var A_arbace_main_legacy_script_A_init jrt.ClassInit

func A_arbace_main_legacy_script_A_Init() { if !A_arbace_main_legacy_script_A_init.Done() { A_arbace_main_legacy_script_A_init.Run(A_arbace_main_legacy_script_A_clinit) } }

func A_arbace_main_legacy_script_A_clinit() { A_arbace_main_legacy_script_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_259, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_legacy_script_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_legacy_script_A) GetClass__Class() *jrt.Class { return A_arbace_main_legacy_script_A_class }

func (t *A_arbace_main_legacy_script_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_legacy_script_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_legacy_script_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_legacy_script_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_legacy_script_A); return ok }

func A_arbace_main_legacy_script_A_Cast(x any) *A_arbace_main_legacy_script_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_legacy_script_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_legacy_script_A_class)) }; return v }



type A_arbace_main_load_script_A struct{ jrt.Object }

func (t *A_arbace_main_load_script_A) Is_Compiler_AOTF1() {}

var A_arbace_main_load_script_A_fn_class *jrt.Class

var A_arbace_main_load_script_A_init jrt.ClassInit

func A_arbace_main_load_script_A_Init() { if !A_arbace_main_load_script_A_init.Done() { A_arbace_main_load_script_A_init.Run(A_arbace_main_load_script_A_clinit) } }

func A_arbace_main_load_script_A_clinit() { A_arbace_main_load_script_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_261, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_load_script_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_load_script_A) GetClass__Class() *jrt.Class { return A_arbace_main_load_script_A_class }

func (t *A_arbace_main_load_script_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_load_script_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_load_script_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_load_script_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_load_script_A); return ok }

func A_arbace_main_load_script_A_Cast(x any) *A_arbace_main_load_script_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_load_script_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_load_script_A_class)) }; return v }



type A_arbace_main_main_A struct{ jrt.Object }

func (t *A_arbace_main_main_A) Is_Compiler_AOTR0() {}

var A_arbace_main_main_A_fn_class *jrt.Class

var A_arbace_main_main_A_init jrt.ClassInit

func A_arbace_main_main_A_Init() { if !A_arbace_main_main_A_init.Done() { A_arbace_main_main_A_init.Run(A_arbace_main_main_A_clinit) } }

func A_arbace_main_main_A_clinit() { A_arbace_main_main_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_265, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_main_main_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_main_A) GetClass__Class() *jrt.Class { return A_arbace_main_main_A_class }

func (t *A_arbace_main_main_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_main_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_main_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_main_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_main_A); return ok }

func A_arbace_main_main_A_Cast(x any) *A_arbace_main_main_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_main_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_main_A_class)) }; return v }



type A_arbace_main_main_dispatch_A struct{ jrt.Object }

func (t *A_arbace_main_main_dispatch_A) Is_Compiler_AOTF1() {}

var A_arbace_main_main_dispatch_A_fn_class *jrt.Class

var A_arbace_main_main_dispatch_A_init jrt.ClassInit

func A_arbace_main_main_dispatch_A_Init() { if !A_arbace_main_main_dispatch_A_init.Done() { A_arbace_main_main_dispatch_A_init.Run(A_arbace_main_main_dispatch_A_clinit) } }

func A_arbace_main_main_dispatch_A_clinit() { A_arbace_main_main_dispatch_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_268, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_main_dispatch_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_main_dispatch_A) GetClass__Class() *jrt.Class { return A_arbace_main_main_dispatch_A_class }

func (t *A_arbace_main_main_dispatch_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_main_dispatch_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_main_dispatch_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_main_dispatch_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_main_dispatch_A); return ok }

func A_arbace_main_main_dispatch_A_Cast(x any) *A_arbace_main_main_dispatch_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_main_dispatch_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_main_dispatch_A_class)) }; return v }



type A_arbace_main_main_opt_A struct{ jrt.Object }

func (t *A_arbace_main_main_opt_A) Is_Compiler_AOTF2() {}

var A_arbace_main_main_opt_A_fn_class *jrt.Class

var A_arbace_main_main_opt_A_init jrt.ClassInit

func A_arbace_main_main_opt_A_Init() { if !A_arbace_main_main_opt_A_init.Done() { A_arbace_main_main_opt_A_init.Run(A_arbace_main_main_opt_A_clinit) } }

func A_arbace_main_main_opt_A_clinit() { A_arbace_main_main_opt_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_275, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_main_opt_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_main_opt_A) GetClass__Class() *jrt.Class { return A_arbace_main_main_opt_A_class }

func (t *A_arbace_main_main_opt_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_main_opt_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_main_opt_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_main_opt_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_main_opt_A); return ok }

func A_arbace_main_main_opt_A_Cast(x any) *A_arbace_main_main_opt_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_main_opt_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_main_opt_A_class)) }; return v }



type A_arbace_main_null_opt_A struct{ jrt.Object }

func (t *A_arbace_main_null_opt_A) Is_Compiler_AOTF2() {}

var A_arbace_main_null_opt_A_fn_class *jrt.Class

var A_arbace_main_null_opt_A_init jrt.ClassInit

func A_arbace_main_null_opt_A_Init() { if !A_arbace_main_null_opt_A_init.Done() { A_arbace_main_null_opt_A_init.Run(A_arbace_main_null_opt_A_clinit) } }

func A_arbace_main_null_opt_A_clinit() { A_arbace_main_null_opt_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_278, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_null_opt_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_null_opt_A) GetClass__Class() *jrt.Class { return A_arbace_main_null_opt_A_class }

func (t *A_arbace_main_null_opt_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_null_opt_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_null_opt_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_null_opt_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_null_opt_A); return ok }

func A_arbace_main_null_opt_A_Cast(x any) *A_arbace_main_null_opt_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_null_opt_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_null_opt_A_class)) }; return v }



type A_arbace_main_renumbering_read_A struct{ jrt.Object }

func (t *A_arbace_main_renumbering_read_A) Is_Compiler_AOTF3() {}

var A_arbace_main_renumbering_read_A_fn_class *jrt.Class

var A_arbace_main_renumbering_read_A_init jrt.ClassInit

func A_arbace_main_renumbering_read_A_Init() { if !A_arbace_main_renumbering_read_A_init.Done() { A_arbace_main_renumbering_read_A_init.Run(A_arbace_main_renumbering_read_A_clinit) } }

func A_arbace_main_renumbering_read_A_clinit() { A_arbace_main_renumbering_read_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_279, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_renumbering_read_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_renumbering_read_A) GetClass__Class() *jrt.Class { return A_arbace_main_renumbering_read_A_class }

func (t *A_arbace_main_renumbering_read_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_renumbering_read_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_renumbering_read_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_renumbering_read_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_renumbering_read_A); return ok }

func A_arbace_main_renumbering_read_A_Cast(x any) *A_arbace_main_renumbering_read_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_renumbering_read_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_renumbering_read_A_class)) }; return v }



type A_arbace_main_repl_A struct{ jrt.Object }

func (t *A_arbace_main_repl_A) Is_Compiler_AOTR0() {}

var A_arbace_main_repl_A_fn_class *jrt.Class

var A_arbace_main_repl_A_init jrt.ClassInit

func A_arbace_main_repl_A_Init() { if !A_arbace_main_repl_A_init.Done() { A_arbace_main_repl_A_init.Run(A_arbace_main_repl_A_clinit) } }

func A_arbace_main_repl_A_clinit() { A_arbace_main_repl_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_280, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_main_repl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_A_class }

func (t *A_arbace_main_repl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_A); return ok }

func A_arbace_main_repl_A_Cast(x any) *A_arbace_main_repl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_A_class)) }; return v }



type A_arbace_main_repl_default__461000107__461000116_A struct{ jrt.Object }

func (t *A_arbace_main_repl_default__461000107__461000116_A) Is_Compiler_AOTF0() {}

var A_arbace_main_repl_default__461000107__461000116_A_fn_class *jrt.Class

var A_arbace_main_repl_default__461000107__461000116_A_init jrt.ClassInit

func A_arbace_main_repl_default__461000107__461000116_A_Init() { if !A_arbace_main_repl_default__461000107__461000116_A_init.Done() { A_arbace_main_repl_default__461000107__461000116_A_init.Run(A_arbace_main_repl_default__461000107__461000116_A_clinit) } }

func A_arbace_main_repl_default__461000107__461000116_A_clinit() { A_arbace_main_repl_default__461000107__461000116_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_283, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_repl_default__461000107__461000116_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_default__461000107__461000116_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_default__461000107__461000116_A_class }

func (t *A_arbace_main_repl_default__461000107__461000116_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_default__461000107__461000116_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_default__461000107__461000116_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_default__461000107__461000116_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_default__461000107__461000116_A); return ok }

func A_arbace_main_repl_default__461000107__461000116_A_Cast(x any) *A_arbace_main_repl_default__461000107__461000116_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_default__461000107__461000116_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_default__461000107__461000116_A_class)) }; return v }



type A_arbace_main_repl_fn__461000118_A struct{ jrt.Object }

func (t *A_arbace_main_repl_fn__461000118_A) Is_Compiler_AOTF0() {}

var A_arbace_main_repl_fn__461000118_A_fn_class *jrt.Class

var A_arbace_main_repl_fn__461000118_A_init jrt.ClassInit

func A_arbace_main_repl_fn__461000118_A_Init() { if !A_arbace_main_repl_fn__461000118_A_init.Done() { A_arbace_main_repl_fn__461000118_A_init.Run(A_arbace_main_repl_fn__461000118_A_clinit) } }

func A_arbace_main_repl_fn__461000118_A_clinit() { A_arbace_main_repl_fn__461000118_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_284, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_repl_fn__461000118_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_fn__461000118_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_fn__461000118_A_class }

func (t *A_arbace_main_repl_fn__461000118_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_fn__461000118_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_fn__461000118_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_fn__461000118_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_fn__461000118_A); return ok }

func A_arbace_main_repl_fn__461000118_A_Cast(x any) *A_arbace_main_repl_fn__461000118_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_fn__461000118_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_fn__461000118_A_class)) }; return v }



type A_arbace_main_repl_fn__461000120_A struct{ jrt.Object }

func (t *A_arbace_main_repl_fn__461000120_A) Is_Compiler_AOTF0() {}

var A_arbace_main_repl_fn__461000120_A_fn_class *jrt.Class

var A_arbace_main_repl_fn__461000120_A_init jrt.ClassInit

func A_arbace_main_repl_fn__461000120_A_Init() { if !A_arbace_main_repl_fn__461000120_A_init.Done() { A_arbace_main_repl_fn__461000120_A_init.Run(A_arbace_main_repl_fn__461000120_A_clinit) } }

func A_arbace_main_repl_fn__461000120_A_clinit() { A_arbace_main_repl_fn__461000120_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_285, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_repl_fn__461000120_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_fn__461000120_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_fn__461000120_A_class }

func (t *A_arbace_main_repl_fn__461000120_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_fn__461000120_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_fn__461000120_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_fn__461000120_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_fn__461000120_A); return ok }

func A_arbace_main_repl_fn__461000120_A_Cast(x any) *A_arbace_main_repl_fn__461000120_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_fn__461000120_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_fn__461000120_A_class)) }; return v }



type A_arbace_main_repl_fn__461000128_A struct{ jrt.Object; F_init, F_caught any }

func (t *A_arbace_main_repl_fn__461000128_A) Is_Compiler_AOTF0() {}

var A_arbace_main_repl_fn__461000128_A_fn_class *jrt.Class

var A_arbace_main_repl_fn__461000128_A_init jrt.ClassInit

func A_arbace_main_repl_fn__461000128_A_Init() { if !A_arbace_main_repl_fn__461000128_A_init.Done() { A_arbace_main_repl_fn__461000128_A_init.Run(A_arbace_main_repl_fn__461000128_A_clinit) } }

func A_arbace_main_repl_fn__461000128_A_clinit() { A_arbace_main_repl_fn__461000128_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_286, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_repl_fn__461000128_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_fn__461000128_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_fn__461000128_A_class }

func (t *A_arbace_main_repl_fn__461000128_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_fn__461000128_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_fn__461000128_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_fn__461000128_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_fn__461000128_A); return ok }

func A_arbace_main_repl_fn__461000128_A_Cast(x any) *A_arbace_main_repl_fn__461000128_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_fn__461000128_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_fn__461000128_A_class)) }; return v }



type A_arbace_main_repl_fn__461000130_A struct{ jrt.Object; F_caught, F_request_exit, F_read_eval_print any }

func (t *A_arbace_main_repl_fn__461000130_A) Is_Compiler_AOTF0() {}

var A_arbace_main_repl_fn__461000130_A_fn_class *jrt.Class

var A_arbace_main_repl_fn__461000130_A_init jrt.ClassInit

func A_arbace_main_repl_fn__461000130_A_Init() { if !A_arbace_main_repl_fn__461000130_A_init.Done() { A_arbace_main_repl_fn__461000130_A_init.Run(A_arbace_main_repl_fn__461000130_A_clinit) } }

func A_arbace_main_repl_fn__461000130_A_clinit() { A_arbace_main_repl_fn__461000130_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_287, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_repl_fn__461000130_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_fn__461000130_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_fn__461000130_A_class }

func (t *A_arbace_main_repl_fn__461000130_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_fn__461000130_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_fn__461000130_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_fn__461000130_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_fn__461000130_A); return ok }

func A_arbace_main_repl_fn__461000130_A_Cast(x any) *A_arbace_main_repl_fn__461000130_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_fn__461000130_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_fn__461000130_A_class)) }; return v }



type A_arbace_main_repl_read_eval_print__461000122_A struct{ jrt.Object; F_request_prompt, F_read, F_caught, F_eval, F_request_exit, F_print any }

func (t *A_arbace_main_repl_read_eval_print__461000122_A) Is_Compiler_AOTF0() {}

var A_arbace_main_repl_read_eval_print__461000122_A_fn_class *jrt.Class

var A_arbace_main_repl_read_eval_print__461000122_A_init jrt.ClassInit

func A_arbace_main_repl_read_eval_print__461000122_A_Init() { if !A_arbace_main_repl_read_eval_print__461000122_A_init.Done() { A_arbace_main_repl_read_eval_print__461000122_A_init.Run(A_arbace_main_repl_read_eval_print__461000122_A_clinit) } }

func A_arbace_main_repl_read_eval_print__461000122_A_clinit() { A_arbace_main_repl_read_eval_print__461000122_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_288, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_repl_read_eval_print__461000122_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_read_eval_print__461000122_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_read_eval_print__461000122_A_class }

func (t *A_arbace_main_repl_read_eval_print__461000122_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_read_eval_print__461000122_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_read_eval_print__461000122_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_read_eval_print__461000122_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_read_eval_print__461000122_A); return ok }

func A_arbace_main_repl_read_eval_print__461000122_A_Cast(x any) *A_arbace_main_repl_read_eval_print__461000122_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_read_eval_print__461000122_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_read_eval_print__461000122_A_class)) }; return v }



type A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A struct{ jrt.Object; F_request_prompt, F_read, F_request_exit any }

func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A) Is_Compiler_AOTF0() {}

var A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_fn_class *jrt.Class

var A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_init jrt.ClassInit

func A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_Init() { if !A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_init.Done() { A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_init.Run(A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_clinit) } }

func A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_clinit() { A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_289, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_class }

func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A); return ok }

func A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_Cast(x any) *A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_read_eval_print__461000122_fn__461000123_A_class)) }; return v }



type A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A struct{ jrt.Object; F_input, F_eval any }

func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A) Is_Compiler_AOTF0() {}

var A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_fn_class *jrt.Class

var A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_init jrt.ClassInit

func A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_Init() { if !A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_init.Done() { A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_init.Run(A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_clinit) } }

func A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_clinit() { A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_290, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_class }

func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A); return ok }

func A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_Cast(x any) *A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_read_eval_print__461000122_fn__461000125_A_class)) }; return v }



type A_arbace_main_repl_caught_A struct{ jrt.Object }

func (t *A_arbace_main_repl_caught_A) Is_Compiler_AOTF1() {}

var A_arbace_main_repl_caught_A_fn_class *jrt.Class

var A_arbace_main_repl_caught_A_init jrt.ClassInit

func A_arbace_main_repl_caught_A_Init() { if !A_arbace_main_repl_caught_A_init.Done() { A_arbace_main_repl_caught_A_init.Run(A_arbace_main_repl_caught_A_clinit) } }

func A_arbace_main_repl_caught_A_clinit() { A_arbace_main_repl_caught_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_291, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_repl_caught_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_caught_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_caught_A_class }

func (t *A_arbace_main_repl_caught_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_caught_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_caught_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_caught_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_caught_A); return ok }

func A_arbace_main_repl_caught_A_Cast(x any) *A_arbace_main_repl_caught_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_caught_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_caught_A_class)) }; return v }



type A_arbace_main_repl_exception_A struct{ jrt.Object }

func (t *A_arbace_main_repl_exception_A) Is_Compiler_AOTF1() {}

var A_arbace_main_repl_exception_A_fn_class *jrt.Class

var A_arbace_main_repl_exception_A_init jrt.ClassInit

func A_arbace_main_repl_exception_A_Init() { if !A_arbace_main_repl_exception_A_init.Done() { A_arbace_main_repl_exception_A_init.Run(A_arbace_main_repl_exception_A_clinit) } }

func A_arbace_main_repl_exception_A_clinit() { A_arbace_main_repl_exception_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_292, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_repl_exception_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_exception_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_exception_A_class }

func (t *A_arbace_main_repl_exception_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_exception_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_exception_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_exception_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_exception_A); return ok }

func A_arbace_main_repl_exception_A_Cast(x any) *A_arbace_main_repl_exception_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_exception_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_exception_A_class)) }; return v }



type A_arbace_main_repl_opt_A struct{ jrt.Object }

func (t *A_arbace_main_repl_opt_A) Is_Compiler_AOTF2() {}

var A_arbace_main_repl_opt_A_fn_class *jrt.Class

var A_arbace_main_repl_opt_A_init jrt.ClassInit

func A_arbace_main_repl_opt_A_Init() { if !A_arbace_main_repl_opt_A_init.Done() { A_arbace_main_repl_opt_A_init.Run(A_arbace_main_repl_opt_A_clinit) } }

func A_arbace_main_repl_opt_A_clinit() { A_arbace_main_repl_opt_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_293, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_repl_opt_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_opt_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_opt_A_class }

func (t *A_arbace_main_repl_opt_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_opt_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_opt_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_opt_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_opt_A); return ok }

func A_arbace_main_repl_opt_A_Cast(x any) *A_arbace_main_repl_opt_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_opt_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_opt_A_class)) }; return v }



type A_arbace_main_repl_opt_fn__461000163_A struct{ jrt.Object }

func (t *A_arbace_main_repl_opt_fn__461000163_A) Is_Compiler_AOTF1() {}

var A_arbace_main_repl_opt_fn__461000163_A_fn_class *jrt.Class

var A_arbace_main_repl_opt_fn__461000163_A_init jrt.ClassInit

func A_arbace_main_repl_opt_fn__461000163_A_Init() { if !A_arbace_main_repl_opt_fn__461000163_A_init.Done() { A_arbace_main_repl_opt_fn__461000163_A_init.Run(A_arbace_main_repl_opt_fn__461000163_A_clinit) } }

func A_arbace_main_repl_opt_fn__461000163_A_clinit() { A_arbace_main_repl_opt_fn__461000163_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_295, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_repl_opt_fn__461000163_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_opt_fn__461000163_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_opt_fn__461000163_A_class }

func (t *A_arbace_main_repl_opt_fn__461000163_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_opt_fn__461000163_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_opt_fn__461000163_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_opt_fn__461000163_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_opt_fn__461000163_A); return ok }

func A_arbace_main_repl_opt_fn__461000163_A_Cast(x any) *A_arbace_main_repl_opt_fn__461000163_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_opt_fn__461000163_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_opt_fn__461000163_A_class)) }; return v }



type A_arbace_main_repl_opt_fn__461000165_A struct{ jrt.Object; F_inits, F_args any }

func (t *A_arbace_main_repl_opt_fn__461000165_A) Is_Compiler_AOTF0() {}

var A_arbace_main_repl_opt_fn__461000165_A_fn_class *jrt.Class

var A_arbace_main_repl_opt_fn__461000165_A_init jrt.ClassInit

func A_arbace_main_repl_opt_fn__461000165_A_Init() { if !A_arbace_main_repl_opt_fn__461000165_A_init.Done() { A_arbace_main_repl_opt_fn__461000165_A_init.Run(A_arbace_main_repl_opt_fn__461000165_A_clinit) } }

func A_arbace_main_repl_opt_fn__461000165_A_clinit() { A_arbace_main_repl_opt_fn__461000165_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_296, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_repl_opt_fn__461000165_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_opt_fn__461000165_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_opt_fn__461000165_A_class }

func (t *A_arbace_main_repl_opt_fn__461000165_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_opt_fn__461000165_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_opt_fn__461000165_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_opt_fn__461000165_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_opt_fn__461000165_A); return ok }

func A_arbace_main_repl_opt_fn__461000165_A_Cast(x any) *A_arbace_main_repl_opt_fn__461000165_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_opt_fn__461000165_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_opt_fn__461000165_A_class)) }; return v }



type A_arbace_main_repl_prompt_A struct{ jrt.Object }

func (t *A_arbace_main_repl_prompt_A) Is_Compiler_AOTF0() {}

var A_arbace_main_repl_prompt_A_fn_class *jrt.Class

var A_arbace_main_repl_prompt_A_init jrt.ClassInit

func A_arbace_main_repl_prompt_A_Init() { if !A_arbace_main_repl_prompt_A_init.Done() { A_arbace_main_repl_prompt_A_init.Run(A_arbace_main_repl_prompt_A_clinit) } }

func A_arbace_main_repl_prompt_A_clinit() { A_arbace_main_repl_prompt_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_297, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_repl_prompt_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_prompt_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_prompt_A_class }

func (t *A_arbace_main_repl_prompt_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_prompt_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_prompt_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_prompt_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_prompt_A); return ok }

func A_arbace_main_repl_prompt_A_Cast(x any) *A_arbace_main_repl_prompt_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_prompt_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_prompt_A_class)) }; return v }



type A_arbace_main_repl_read_A struct{ jrt.Object }

func (t *A_arbace_main_repl_read_A) Is_Compiler_AOTF2() {}

var A_arbace_main_repl_read_A_fn_class *jrt.Class

var A_arbace_main_repl_read_A_init jrt.ClassInit

func A_arbace_main_repl_read_A_Init() { if !A_arbace_main_repl_read_A_init.Done() { A_arbace_main_repl_read_A_init.Run(A_arbace_main_repl_read_A_clinit) } }

func A_arbace_main_repl_read_A_clinit() { A_arbace_main_repl_read_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_299, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_repl_read_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_repl_read_A) GetClass__Class() *jrt.Class { return A_arbace_main_repl_read_A_class }

func (t *A_arbace_main_repl_read_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_repl_read_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_repl_read_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_repl_read_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_repl_read_A); return ok }

func A_arbace_main_repl_read_A_Cast(x any) *A_arbace_main_repl_read_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_repl_read_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_repl_read_A_class)) }; return v }



type A_arbace_main_report_error_A struct{ jrt.Object }

func (t *A_arbace_main_report_error_A) Is_Compiler_AOTR1() {}

var A_arbace_main_report_error_A_fn_class *jrt.Class

var A_arbace_main_report_error_A_init jrt.ClassInit

func A_arbace_main_report_error_A_Init() { if !A_arbace_main_report_error_A_init.Done() { A_arbace_main_report_error_A_init.Run(A_arbace_main_report_error_A_clinit) } }

func A_arbace_main_report_error_A_clinit() { A_arbace_main_report_error_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_300, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_main_report_error_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_report_error_A) GetClass__Class() *jrt.Class { return A_arbace_main_report_error_A_class }

func (t *A_arbace_main_report_error_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_report_error_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_report_error_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_report_error_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_report_error_A); return ok }

func A_arbace_main_report_error_A_Cast(x any) *A_arbace_main_report_error_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_report_error_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_report_error_A_class)) }; return v }



type A_arbace_main_report_error_fn__461000195_A struct{ jrt.Object; F_report, F_s__1927001093__auto__ any }

func (t *A_arbace_main_report_error_fn__461000195_A) Is_Compiler_AOTF0() {}

var A_arbace_main_report_error_fn__461000195_A_fn_class *jrt.Class

var A_arbace_main_report_error_fn__461000195_A_init jrt.ClassInit

func A_arbace_main_report_error_fn__461000195_A_Init() { if !A_arbace_main_report_error_fn__461000195_A_init.Done() { A_arbace_main_report_error_fn__461000195_A_init.Run(A_arbace_main_report_error_fn__461000195_A_clinit) } }

func A_arbace_main_report_error_fn__461000195_A_clinit() { A_arbace_main_report_error_fn__461000195_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_303, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_report_error_fn__461000195_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_report_error_fn__461000195_A) GetClass__Class() *jrt.Class { return A_arbace_main_report_error_fn__461000195_A_class }

func (t *A_arbace_main_report_error_fn__461000195_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_report_error_fn__461000195_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_report_error_fn__461000195_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_report_error_fn__461000195_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_report_error_fn__461000195_A); return ok }

func A_arbace_main_report_error_fn__461000195_A_Cast(x any) *A_arbace_main_report_error_fn__461000195_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_report_error_fn__461000195_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_report_error_fn__461000195_A_class)) }; return v }



type A_arbace_main_report_error_fn__461000195_fn__461000196_A struct{ jrt.Object; F_report any }

func (t *A_arbace_main_report_error_fn__461000195_fn__461000196_A) Is_Compiler_AOTF0() {}

var A_arbace_main_report_error_fn__461000195_fn__461000196_A_fn_class *jrt.Class

var A_arbace_main_report_error_fn__461000195_fn__461000196_A_init jrt.ClassInit

func A_arbace_main_report_error_fn__461000195_fn__461000196_A_Init() { if !A_arbace_main_report_error_fn__461000195_fn__461000196_A_init.Done() { A_arbace_main_report_error_fn__461000195_fn__461000196_A_init.Run(A_arbace_main_report_error_fn__461000195_fn__461000196_A_clinit) } }

func A_arbace_main_report_error_fn__461000195_fn__461000196_A_clinit() { A_arbace_main_report_error_fn__461000195_fn__461000196_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_304, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_report_error_fn__461000195_fn__461000196_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_report_error_fn__461000195_fn__461000196_A) GetClass__Class() *jrt.Class { return A_arbace_main_report_error_fn__461000195_fn__461000196_A_class }

func (t *A_arbace_main_report_error_fn__461000195_fn__461000196_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_report_error_fn__461000195_fn__461000196_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_report_error_fn__461000195_fn__461000196_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_report_error_fn__461000195_fn__461000196_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_report_error_fn__461000195_fn__461000196_A); return ok }

func A_arbace_main_report_error_fn__461000195_fn__461000196_A_Cast(x any) *A_arbace_main_report_error_fn__461000195_fn__461000196_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_report_error_fn__461000195_fn__461000196_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_report_error_fn__461000195_fn__461000196_A_class)) }; return v }



type A_arbace_main_report_error_fn__461000199_A struct{ jrt.Object; F_report_str any }

func (t *A_arbace_main_report_error_fn__461000199_A) Is_Compiler_AOTF0() {}

var A_arbace_main_report_error_fn__461000199_A_fn_class *jrt.Class

var A_arbace_main_report_error_fn__461000199_A_init jrt.ClassInit

func A_arbace_main_report_error_fn__461000199_A_Init() { if !A_arbace_main_report_error_fn__461000199_A_init.Done() { A_arbace_main_report_error_fn__461000199_A_init.Run(A_arbace_main_report_error_fn__461000199_A_clinit) } }

func A_arbace_main_report_error_fn__461000199_A_clinit() { A_arbace_main_report_error_fn__461000199_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_305, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_report_error_fn__461000199_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_report_error_fn__461000199_A) GetClass__Class() *jrt.Class { return A_arbace_main_report_error_fn__461000199_A_class }

func (t *A_arbace_main_report_error_fn__461000199_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_report_error_fn__461000199_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_report_error_fn__461000199_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_report_error_fn__461000199_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_report_error_fn__461000199_A); return ok }

func A_arbace_main_report_error_fn__461000199_A_Cast(x any) *A_arbace_main_report_error_fn__461000199_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_report_error_fn__461000199_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_report_error_fn__461000199_A_class)) }; return v }



type A_arbace_main_report_error_fn__461000199_fn__461000200_A struct{ jrt.Object; F_w, F_report_str any }

func (t *A_arbace_main_report_error_fn__461000199_fn__461000200_A) Is_Compiler_AOTF0() {}

var A_arbace_main_report_error_fn__461000199_fn__461000200_A_fn_class *jrt.Class

var A_arbace_main_report_error_fn__461000199_fn__461000200_A_init jrt.ClassInit

func A_arbace_main_report_error_fn__461000199_fn__461000200_A_Init() { if !A_arbace_main_report_error_fn__461000199_fn__461000200_A_init.Done() { A_arbace_main_report_error_fn__461000199_fn__461000200_A_init.Run(A_arbace_main_report_error_fn__461000199_fn__461000200_A_clinit) } }

func A_arbace_main_report_error_fn__461000199_fn__461000200_A_clinit() { A_arbace_main_report_error_fn__461000199_fn__461000200_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_308, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_report_error_fn__461000199_fn__461000200_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_report_error_fn__461000199_fn__461000200_A) GetClass__Class() *jrt.Class { return A_arbace_main_report_error_fn__461000199_fn__461000200_A_class }

func (t *A_arbace_main_report_error_fn__461000199_fn__461000200_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_report_error_fn__461000199_fn__461000200_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_report_error_fn__461000199_fn__461000200_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_report_error_fn__461000199_fn__461000200_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_report_error_fn__461000199_fn__461000200_A); return ok }

func A_arbace_main_report_error_fn__461000199_fn__461000200_A_Cast(x any) *A_arbace_main_report_error_fn__461000199_fn__461000200_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_report_error_fn__461000199_fn__461000200_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_report_error_fn__461000199_fn__461000200_A_class)) }; return v }



type A_arbace_main_root_cause_A struct{ jrt.Object }

func (t *A_arbace_main_root_cause_A) Is_Compiler_AOTF1() {}

var A_arbace_main_root_cause_A_fn_class *jrt.Class

var A_arbace_main_root_cause_A_init jrt.ClassInit

func A_arbace_main_root_cause_A_Init() { if !A_arbace_main_root_cause_A_init.Done() { A_arbace_main_root_cause_A_init.Run(A_arbace_main_root_cause_A_clinit) } }

func A_arbace_main_root_cause_A_clinit() { A_arbace_main_root_cause_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_309, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_root_cause_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_root_cause_A) GetClass__Class() *jrt.Class { return A_arbace_main_root_cause_A_class }

func (t *A_arbace_main_root_cause_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_root_cause_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_root_cause_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_root_cause_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_root_cause_A); return ok }

func A_arbace_main_root_cause_A_Cast(x any) *A_arbace_main_root_cause_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_root_cause_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_root_cause_A_class)) }; return v }



type A_arbace_main_script_opt_A struct{ jrt.Object }

func (t *A_arbace_main_script_opt_A) Is_Compiler_AOTF2() {}

var A_arbace_main_script_opt_A_fn_class *jrt.Class

var A_arbace_main_script_opt_A_init jrt.ClassInit

func A_arbace_main_script_opt_A_Init() { if !A_arbace_main_script_opt_A_init.Done() { A_arbace_main_script_opt_A_init.Run(A_arbace_main_script_opt_A_clinit) } }

func A_arbace_main_script_opt_A_clinit() { A_arbace_main_script_opt_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_310, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_script_opt_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_script_opt_A) GetClass__Class() *jrt.Class { return A_arbace_main_script_opt_A_class }

func (t *A_arbace_main_script_opt_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_script_opt_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_script_opt_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_script_opt_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_script_opt_A); return ok }

func A_arbace_main_script_opt_A_Cast(x any) *A_arbace_main_script_opt_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_script_opt_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_script_opt_A_class)) }; return v }



type A_arbace_main_skip_if_eol_A struct{ jrt.Object }

func (t *A_arbace_main_skip_if_eol_A) Is_Compiler_AOTF1() {}

var A_arbace_main_skip_if_eol_A_fn_class *jrt.Class

var A_arbace_main_skip_if_eol_A_init jrt.ClassInit

func A_arbace_main_skip_if_eol_A_Init() { if !A_arbace_main_skip_if_eol_A_init.Done() { A_arbace_main_skip_if_eol_A_init.Run(A_arbace_main_skip_if_eol_A_clinit) } }

func A_arbace_main_skip_if_eol_A_clinit() { A_arbace_main_skip_if_eol_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_312, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_skip_if_eol_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_skip_if_eol_A) GetClass__Class() *jrt.Class { return A_arbace_main_skip_if_eol_A_class }

func (t *A_arbace_main_skip_if_eol_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_skip_if_eol_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_skip_if_eol_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_skip_if_eol_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_skip_if_eol_A); return ok }

func A_arbace_main_skip_if_eol_A_Cast(x any) *A_arbace_main_skip_if_eol_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_skip_if_eol_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_skip_if_eol_A_class)) }; return v }



type A_arbace_main_skip_whitespace_A struct{ jrt.Object }

func (t *A_arbace_main_skip_whitespace_A) Is_Compiler_AOTF1() {}

var A_arbace_main_skip_whitespace_A_fn_class *jrt.Class

var A_arbace_main_skip_whitespace_A_init jrt.ClassInit

func A_arbace_main_skip_whitespace_A_Init() { if !A_arbace_main_skip_whitespace_A_init.Done() { A_arbace_main_skip_whitespace_A_init.Run(A_arbace_main_skip_whitespace_A_clinit) } }

func A_arbace_main_skip_whitespace_A_clinit() { A_arbace_main_skip_whitespace_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_314, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_skip_whitespace_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_skip_whitespace_A) GetClass__Class() *jrt.Class { return A_arbace_main_skip_whitespace_A_class }

func (t *A_arbace_main_skip_whitespace_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_skip_whitespace_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_skip_whitespace_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_skip_whitespace_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_skip_whitespace_A); return ok }

func A_arbace_main_skip_whitespace_A_Cast(x any) *A_arbace_main_skip_whitespace_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_skip_whitespace_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_skip_whitespace_A_class)) }; return v }



type A_arbace_main_stack_element_str_A struct{ jrt.Object }

func (t *A_arbace_main_stack_element_str_A) Is_Compiler_AOTF1() {}

var A_arbace_main_stack_element_str_A_fn_class *jrt.Class

var A_arbace_main_stack_element_str_A_init jrt.ClassInit

func A_arbace_main_stack_element_str_A_Init() { if !A_arbace_main_stack_element_str_A_init.Done() { A_arbace_main_stack_element_str_A_init.Run(A_arbace_main_stack_element_str_A_clinit) } }

func A_arbace_main_stack_element_str_A_clinit() { A_arbace_main_stack_element_str_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_316, lang.Compiler_AOTFn_class) }

func (t *A_arbace_main_stack_element_str_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_stack_element_str_A) GetClass__Class() *jrt.Class { return A_arbace_main_stack_element_str_A_class }

func (t *A_arbace_main_stack_element_str_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_stack_element_str_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_stack_element_str_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_stack_element_str_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_stack_element_str_A); return ok }

func A_arbace_main_stack_element_str_A_Cast(x any) *A_arbace_main_stack_element_str_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_stack_element_str_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_stack_element_str_A_class)) }; return v }



type A_arbace_main_with_bindings_A struct{ jrt.Object }

func (t *A_arbace_main_with_bindings_A) Is_Compiler_AOTR2() {}

var A_arbace_main_with_bindings_A_fn_class *jrt.Class

var A_arbace_main_with_bindings_A_init jrt.ClassInit

func A_arbace_main_with_bindings_A_Init() { if !A_arbace_main_with_bindings_A_init.Done() { A_arbace_main_with_bindings_A_init.Run(A_arbace_main_with_bindings_A_clinit) } }

func A_arbace_main_with_bindings_A_clinit() { A_arbace_main_with_bindings_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_321, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_main_with_bindings_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_with_bindings_A) GetClass__Class() *jrt.Class { return A_arbace_main_with_bindings_A_class }

func (t *A_arbace_main_with_bindings_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_with_bindings_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_with_bindings_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_with_bindings_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_with_bindings_A); return ok }

func A_arbace_main_with_bindings_A_Cast(x any) *A_arbace_main_with_bindings_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_with_bindings_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_with_bindings_A_class)) }; return v }



type A_arbace_main_with_read_known_A struct{ jrt.Object }

func (t *A_arbace_main_with_read_known_A) Is_Compiler_AOTR2() {}

var A_arbace_main_with_read_known_A_fn_class *jrt.Class

var A_arbace_main_with_read_known_A_init jrt.ClassInit

func A_arbace_main_with_read_known_A_Init() { if !A_arbace_main_with_read_known_A_init.Done() { A_arbace_main_with_read_known_A_init.Run(A_arbace_main_with_read_known_A_clinit) } }

func A_arbace_main_with_read_known_A_clinit() { A_arbace_main_with_read_known_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_322, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_main_with_read_known_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_main_with_read_known_A) GetClass__Class() *jrt.Class { return A_arbace_main_with_read_known_A_class }

func (t *A_arbace_main_with_read_known_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_main_with_read_known_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_main_with_read_known_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_main_with_read_known_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_main_with_read_known_A); return ok }

func A_arbace_main_with_read_known_A_Cast(x any) *A_arbace_main_with_read_known_A { if x == nil { return nil }; v, ok := x.(*A_arbace_main_with_read_known_A); if !ok { panic(jrt.ClassCast(x, A_arbace_main_with_read_known_A_class)) }; return v }
