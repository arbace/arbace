//line aot_arbace_test__init.ae:1
package aot_arbace_test

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_test__init_A_Load__O() any { A_arbace_test__init_A_Init(); jrt.StartCheck(); A_arbace_test__init_A_Unit0__O(); A_arbace_test__init_A_Unit1__O(); A_arbace_test__init_A_Unit2__O(); A_arbace_test__init_A_Unit3__O(); A_arbace_test__init_A_Unit4__O(); A_arbace_test__init_A_Unit5__O(); A_arbace_test__init_A_Unit6__O(); A_arbace_test__init_A_Unit7__O(); A_arbace_test__init_A_Unit8__O(); A_arbace_test__init_A_Unit9__O(); A_arbace_test__init_A_Unit10__O(); A_arbace_test__init_A_Unit11__O(); A_arbace_test__init_A_Unit12__O(); A_arbace_test__init_A_Unit13__O(); A_arbace_test__init_A_Unit14__O(); A_arbace_test__init_A_Unit15__O(); A_arbace_test__init_A_Unit16__O(); A_arbace_test__init_A_Unit17__O(); A_arbace_test__init_A_Unit18__O(); A_arbace_test__init_A_Unit19__O(); A_arbace_test__init_A_Unit20__O(); A_arbace_test__init_A_Unit21__O(); A_arbace_test__init_A_Unit22__O(); A_arbace_test__init_A_Unit23__O(); A_arbace_test__init_A_Unit24__O(); A_arbace_test__init_A_Unit25__O(); A_arbace_test__init_A_Unit26__O(); A_arbace_test__init_A_Unit27__O(); A_arbace_test__init_A_Unit28__O(); A_arbace_test__init_A_Unit29__O(); A_arbace_test__init_A_Unit30__O(); A_arbace_test__init_A_Unit31__O(); A_arbace_test__init_A_Unit32__O(); A_arbace_test__init_A_Unit33__O(); A_arbace_test__init_A_Unit34__O(); A_arbace_test__init_A_Unit35__O(); A_arbace_test__init_A_Unit36__O(); A_arbace_test__init_A_Unit37__O(); A_arbace_test__init_A_Unit38__O(); A_arbace_test__init_A_Unit39__O(); A_arbace_test__init_A_Unit40__O(); A_arbace_test__init_A_Unit41__O(); A_arbace_test__init_A_Unit42__O(); A_arbace_test__init_A_Unit43__O(); A_arbace_test__init_A_Unit44__O(); A_arbace_test__init_A_Unit45__O(); A_arbace_test__init_A_Unit46__O(); A_arbace_test__init_A_Unit47__O(); A_arbace_test__init_A_Unit48__O(); A_arbace_test__init_A_Unit49__O(); A_arbace_test__init_A_Unit50__O(); A_arbace_test__init_A_Unit51__O(); A_arbace_test__init_A_Unit52__O(); A_arbace_test__init_A_Unit53__O(); A_arbace_test__init_A_Unit54__O(); A_arbace_test__init_A_Unit55__O(); A_arbace_test__init_A_Unit56__O(); A_arbace_test__init_A_Unit57__O(); A_arbace_test__init_A_Unit58__O(); A_arbace_test__init_A_Unit59__O(); A_arbace_test__init_A_Unit60__O(); A_arbace_test__init_A_Unit61__O(); A_arbace_test__init_A_Unit62__O(); A_arbace_test__init_A_Unit63__O(); A_arbace_test__init_A_Unit64__O(); A_arbace_test__init_A_Unit65__O(); A_arbace_test__init_A_Unit66__O(); A_arbace_test__init_A_Unit67__O(); A_arbace_test__init_A_Unit68__O(); A_arbace_test__init_A_Unit69__O(); A_arbace_test__init_A_Unit70__O(); A_arbace_test__init_A_Unit71__O(); A_arbace_test__init_A_Unit72__O(); A_arbace_test__init_A_Unit73__O(); A_arbace_test__init_A_Unit74__O(); A_arbace_test__init_A_Unit75__O(); A_arbace_test__init_A_Unit76__O(); A_arbace_test__init_A_Unit77__O(); A_arbace_test__init_A_Unit78__O(); A_arbace_test__init_A_Unit79__O(); A_arbace_test__init_A_Unit80__O(); A_arbace_test__init_A_Unit81__O(); A_arbace_test__init_A_Unit82__O(); return nil }











func A_arbace_test__init_A_Unit0__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); return lang.IFn_Cast(A_arbace_test__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_test__init_A_const_1) }
//line :17:1
func A_arbace_test__init_A_Unit1__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_test__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_2)) }
//line :17:1
func A_arbace_test__init_A_Unit2__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 any = A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :17:1
func A_arbace_test__init_A_Unit3__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_test__init_A_const_1)).Equals_O__Z(A_arbace_test__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_test_eval196000008_fn__196000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_test_eval196000008_fn__196000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_test_eval196000008_fn__196000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }






























































































































































































































func A_arbace_test__init_A_Unit4__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(240, 1); var v__1927001498__auto____1 any; A_arbace_test__init_A_const_4.SetDynamic_Z__Var(true); var tmp1 *lang.Var = A_arbace_test__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_5)); v__1927001498__auto____1 = A_arbace_test__init_A_const_4; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { A_arbace_test__init_A_const_4.SetDynamic_Z__Var(true); var tmp2 *lang.Var = A_arbace_test__init_A_const_4; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_6)); A_arbace_test__init_A_const_4.BindRoot_O__V(jrt.Boolean_TRUE.Ref()); return A_arbace_test__init_A_const_4 } }






func A_arbace_test__init_A_Unit5__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(247, 1); A_arbace_test__init_A_const_7.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_test__init_A_const_7; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_8)); return A_arbace_test__init_A_const_7.SetDynamic_Z__Var(true).Ref() }








func A_arbace_test__init_A_Unit6__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); A_arbace_test__init_A_const_9.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_test__init_A_const_9; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_10)); return A_arbace_test__init_A_const_9.SetDynamic_Z__Var(true).Ref() }

func A_arbace_test__init_A_Unit7__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(258, 1); A_arbace_test__init_A_const_11.BindRoot_O__V(A_arbace_test__init_A_const_12); var tmp1 *lang.Var = A_arbace_test__init_A_const_11; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_13)); return A_arbace_test__init_A_const_11.SetDynamic_Z__Var(true).Ref() }


func A_arbace_test__init_A_Unit8__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(261, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_14; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_test__init_A_const_15.GetRawRoot__O()).Invoke__O()); var tmp2 *lang.Var = A_arbace_test__init_A_const_14; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_16)); return A_arbace_test__init_A_const_14.SetDynamic_Z__Var(true).Ref() }

func A_arbace_test__init_A_Unit9__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(263, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_17; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_test__init_A_const_15.GetRawRoot__O()).Invoke__O()); var tmp2 *lang.Var = A_arbace_test__init_A_const_17; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_18)); return A_arbace_test__init_A_const_17.SetDynamic_Z__Var(true).Ref() }

func A_arbace_test__init_A_Unit10__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(265, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_19; tmp1.BindRoot_O__V(A_arbace_test__init_A_const_20.Get__O()); var tmp2 *lang.Var = A_arbace_test__init_A_const_19; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_21)); return A_arbace_test__init_A_const_19.SetDynamic_Z__Var(true).Ref() }

func A_arbace_test__init_A_Unit11__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(267, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_22; var tmp2 any = A_arbace_test_with_test_out_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_test_with_test_out_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, true); A_arbace_test_with_test_out_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_test__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_23)); return A_arbace_test__init_A_const_22 }
//line :267:1
func A_arbace_test__init_A_Unit12__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(267, 1); A_arbace_test__init_A_const_22.SetMacro__V(); return nil }
//line :267:1
func A_arbace_test__init_A_Unit13__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(267, 1); return A_arbace_test__init_A_const_22 }








func A_arbace_test__init_A_Unit14__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(276, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_24; var tmp2 any = A_arbace_test_file_position_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_test_file_position_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_test_file_position_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_25)); return A_arbace_test__init_A_const_24 }











func A_arbace_test__init_A_Unit15__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_26; var tmp2 any = A_arbace_test_testing_vars_str_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_test_testing_vars_str_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_test_testing_vars_str_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_27)); return A_arbace_test__init_A_const_26 }












func A_arbace_test__init_A_Unit16__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(301, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_28; var tmp2 any = A_arbace_test_testing_contexts_str_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_test_testing_contexts_str_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_test_testing_contexts_str_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_29)); return A_arbace_test__init_A_const_28 }






func A_arbace_test__init_A_Unit17__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(308, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_30; var tmp2 any = A_arbace_test_inc_report_counter_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_test_inc_report_counter_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_test_inc_report_counter_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_31)); return A_arbace_test__init_A_const_30 }









func A_arbace_test__init_A_Unit18__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(318, 1); var v__1927000386__auto____1 any; A_arbace_test__init_A_const_32.SetDynamic_Z__Var(true); var tmp1 *lang.Var = A_arbace_test__init_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_33)); v__1927000386__auto____1 = A_arbace_test__init_A_const_32; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(A_arbace_test__init_A_const_34.GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { A_arbace_test__init_A_const_32.SetDynamic_Z__Var(true); var tmp3 *lang.Var = A_arbace_test__init_A_const_32; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_38)); var tmp4 *lang.Var = A_arbace_test__init_A_const_32; var tmp5 *jrt.String = Lit_46; var tmp6 lang.IFn = A_arbace_test__init_A_const_35; var tmp7 any = A_arbace_test__init_A_const_36; tmp4.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp6, tmp7, A_arbace_test__init_A_const_37)); return A_arbace_test__init_A_const_32 } }










func A_arbace_test__init_A_Unit19__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(329, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_39; var tmp2 any = A_arbace_test_file_and_line_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_test_file_and_line_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_test_file_and_line_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_40)); return A_arbace_test__init_A_const_39 }








func A_arbace_test__init_A_Unit20__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(338, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_41; var tmp2 any = A_arbace_test_stacktrace_file_and_line_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_test_stacktrace_file_and_line_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_test_stacktrace_file_and_line_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_42)); return A_arbace_test__init_A_const_41 }






func A_arbace_test__init_A_Unit21__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(345, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_43; var tmp2 any = A_arbace_test_do_report_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_test_do_report_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_test_do_report_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_44)); return A_arbace_test__init_A_const_43 }

















func A_arbace_test__init_A_Unit22__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(363, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_32.Get__O()); var tmp2 any = A_arbace_test__init_A_const_36; var tmp3 any = A_arbace_test_eval196000039_fn__196000040_A_New(); var tmp4 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_test_eval196000039_fn__196000040_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_test_eval196000039_fn__196000040_A_fn_class = fncls__11d; tmp4 = fncls__11d } else { tmp4 = fncls__11 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_test__init_A_Unit23__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(366, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_32.Get__O()); var tmp2 any = A_arbace_test__init_A_const_45; var tmp3 any = A_arbace_test_eval196000043_fn__196000044_A_New(); var tmp4 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_test_eval196000043_fn__196000044_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_test_eval196000043_fn__196000044_A_fn_class = fncls__12d; tmp4 = fncls__12d } else { tmp4 = fncls__12 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_test__init_A_Unit24__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(369, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_32.Get__O()); var tmp2 any = A_arbace_test__init_A_const_46; var tmp3 any = A_arbace_test_eval196000047_fn__196000048_A_New(); var tmp4 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_test_eval196000047_fn__196000048_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_test_eval196000047_fn__196000048_A_fn_class = fncls__13d; tmp4 = fncls__13d } else { tmp4 = fncls__13 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }








func A_arbace_test__init_A_Unit25__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(378, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_32.Get__O()); var tmp2 any = A_arbace_test__init_A_const_47; var tmp3 any = A_arbace_test_eval196000051_fn__196000052_A_New(); var tmp4 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_test_eval196000051_fn__196000052_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_test_eval196000051_fn__196000052_A_fn_class = fncls__14d; tmp4 = fncls__14d } else { tmp4 = fncls__14 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }












func A_arbace_test__init_A_Unit26__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(391, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_32.Get__O()); var tmp2 any = A_arbace_test__init_A_const_48; var tmp3 any = A_arbace_test_eval196000055_fn__196000056_A_New(); var tmp4 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_test_eval196000055_fn__196000056_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_test_eval196000055_fn__196000056_A_fn_class = fncls__15d; tmp4 = fncls__15d } else { tmp4 = fncls__15 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_test__init_A_Unit27__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(397, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_32.Get__O()); var tmp2 any = A_arbace_test__init_A_const_49; var tmp3 any = A_arbace_test_eval196000059_fn__196000060_A_New(); var tmp4 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_test_eval196000059_fn__196000060_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_test_eval196000059_fn__196000060_A_fn_class = fncls__16d; tmp4 = fncls__16d } else { tmp4 = fncls__16 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_test__init_A_Unit28__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(402, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_32.Get__O()); var tmp2 any = A_arbace_test__init_A_const_50; var tmp3 any = A_arbace_test_eval196000063_fn__196000064_A_New(); var tmp4 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_test_eval196000063_fn__196000064_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_test_eval196000063_fn__196000064_A_fn_class = fncls__17d; tmp4 = fncls__17d } else { tmp4 = fncls__17 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_test__init_A_Unit29__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(403, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_32.Get__O()); var tmp2 any = A_arbace_test__init_A_const_51; var tmp3 any = A_arbace_test_eval196000067_fn__196000068_A_New(); var tmp4 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_test_eval196000067_fn__196000068_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_test_eval196000067_fn__196000068_A_fn_class = fncls__18d; tmp4 = fncls__18d } else { tmp4 = fncls__18 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_test__init_A_Unit30__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(404, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_32.Get__O()); var tmp2 any = A_arbace_test__init_A_const_52; var tmp3 any = A_arbace_test_eval196000071_fn__196000072_A_New(); var tmp4 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_test_eval196000071_fn__196000072_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_test_eval196000071_fn__196000072_A_fn_class = fncls__19d; tmp4 = fncls__19d } else { tmp4 = fncls__19 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test__init_A_Unit31__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(408, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_53; var tmp2 any = A_arbace_test_get_possibly_unbound_var_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_test_get_possibly_unbound_var_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_test_get_possibly_unbound_var_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_54)); return A_arbace_test__init_A_const_53 }







func A_arbace_test__init_A_Unit32__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(416, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_55; var tmp2 any = A_arbace_test_function_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_test_function_QMARK__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_test_function_QMARK__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_56)); return A_arbace_test__init_A_const_55 }











func A_arbace_test__init_A_Unit33__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(428, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_57; var tmp2 any = A_arbace_test_assert_predicate_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_test_assert_predicate_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_test_assert_predicate_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_58)); return A_arbace_test__init_A_const_57 }


















func A_arbace_test__init_A_Unit34__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(447, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_59; var tmp2 any = A_arbace_test_assert_any_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_test_assert_any_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_test_assert_any_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_60)); return A_arbace_test__init_A_const_59 }


















func A_arbace_test__init_A_Unit35__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(466, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_test__init_A_const_61; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_62)); v__1927000386__auto____1 = A_arbace_test__init_A_const_61; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(A_arbace_test__init_A_const_34.GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_test__init_A_const_61; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_63)); var tmp4 *lang.Var = A_arbace_test__init_A_const_61; var tmp5 *jrt.String = Lit_63; var tmp6 any = A_arbace_test_eval196000082_fn__196000083_A_New(); var tmp7 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_test_eval196000082_fn__196000083_A_fn_class
						if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_test_eval196000082_fn__196000083_A_fn_class = fncls__24d; tmp7 = fncls__24d } else { tmp7 = fncls__24 }
//line :466:1
	var tmp8 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_test__init_A_const_36; tmp4.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp8, tmp9, A_arbace_test__init_A_const_37)); return A_arbace_test__init_A_const_61 } }






func A_arbace_test__init_A_Unit36__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(473, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_61.GetRawRoot__O()); var tmp2 any = A_arbace_test__init_A_const_64; var tmp3 any = A_arbace_test_eval196000086_fn__196000087_A_New(); var tmp4 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_test_eval196000086_fn__196000087_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_test_eval196000086_fn__196000087_A_fn_class = fncls__25d; tmp4 = fncls__25d } else { tmp4 = fncls__25 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test__init_A_Unit37__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(477, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_61.GetRawRoot__O()); var tmp2 any = A_arbace_test__init_A_const_36; var tmp3 any = A_arbace_test_eval196000090_fn__196000091_A_New(); var tmp4 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_test_eval196000090_fn__196000091_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_test_eval196000090_fn__196000091_A_fn_class = fncls__26d; tmp4 = fncls__26d } else { tmp4 = fncls__26 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_test__init_A_Unit38__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(482, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_61.GetRawRoot__O()); var tmp2 any = A_arbace_test__init_A_const_65; var tmp3 any = A_arbace_test_eval196000097_fn__196000098_A_New(); var tmp4 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_test_eval196000097_fn__196000098_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_test_eval196000097_fn__196000098_A_fn_class = fncls__27d; tmp4 = fncls__27d } else { tmp4 = fncls__27 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }











func A_arbace_test__init_A_Unit39__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(494, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_61.GetRawRoot__O()); var tmp2 any = A_arbace_test__init_A_const_66; var tmp3 any = A_arbace_test_eval196000102_fn__196000103_A_New(); var tmp4 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_test_eval196000102_fn__196000103_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_test_eval196000102_fn__196000103_A_fn_class = fncls__28d; tmp4 = fncls__28d } else { tmp4 = fncls__28 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }













func A_arbace_test__init_A_Unit40__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(508, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_61.GetRawRoot__O()); var tmp2 any = A_arbace_test__init_A_const_67; var tmp3 any = A_arbace_test_eval196000108_fn__196000109_A_New(); var tmp4 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_test_eval196000108_fn__196000109_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_test_eval196000108_fn__196000109_A_fn_class = fncls__29d; tmp4 = fncls__29d } else { tmp4 = fncls__29 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


















func A_arbace_test__init_A_Unit41__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(527, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_68; var tmp2 any = A_arbace_test_try_expr_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_test_try_expr_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_test_try_expr_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_69)); return A_arbace_test__init_A_const_68 }
//line :527:1
func A_arbace_test__init_A_Unit42__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(527, 1); A_arbace_test__init_A_const_68.SetMacro__V(); return nil }
//line :527:1
func A_arbace_test__init_A_Unit43__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(527, 1); return A_arbace_test__init_A_const_68 }













func A_arbace_test__init_A_Unit44__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(541, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_70; var tmp2 any = A_arbace_test_is_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_test_is_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_test_is_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_71)); return A_arbace_test__init_A_const_70 }
//line :541:1
func A_arbace_test__init_A_Unit45__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(541, 1); A_arbace_test__init_A_const_70.SetMacro__V(); return nil }
//line :541:1
func A_arbace_test__init_A_Unit46__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(541, 1); return A_arbace_test__init_A_const_70 }

















func A_arbace_test__init_A_Unit47__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(559, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_72; var tmp2 any = A_arbace_test_are_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_test_are_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, true); A_arbace_test_are_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_test__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_73)); return A_arbace_test__init_A_const_72 }
//line :559:1
func A_arbace_test__init_A_Unit48__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(559, 1); A_arbace_test__init_A_const_72.SetMacro__V(); return nil }
//line :559:1
func A_arbace_test__init_A_Unit49__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(559, 1); return A_arbace_test__init_A_const_72 }
























func A_arbace_test__init_A_Unit50__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(584, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_74; var tmp2 any = A_arbace_test_testing_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_test_testing_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, true); A_arbace_test_testing_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_test__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_75)); return A_arbace_test__init_A_const_74 }
//line :584:1
func A_arbace_test__init_A_Unit51__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(584, 1); A_arbace_test__init_A_const_74.SetMacro__V(); return nil }
//line :584:1
func A_arbace_test__init_A_Unit52__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(584, 1); return A_arbace_test__init_A_const_74 }









func A_arbace_test__init_A_Unit53__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(594, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_76; var tmp2 any = A_arbace_test_with_test_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_test_with_test_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, true); A_arbace_test_with_test_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_test__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_77)); return A_arbace_test__init_A_const_76 }
//line :594:1
func A_arbace_test__init_A_Unit54__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(594, 1); A_arbace_test__init_A_const_76.SetMacro__V(); return nil }
//line :594:1
func A_arbace_test__init_A_Unit55__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(594, 1); return A_arbace_test__init_A_const_76 }











func A_arbace_test__init_A_Unit56__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(606, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_78; var tmp2 any = A_arbace_test_deftest_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_test_deftest_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, true); A_arbace_test_deftest_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_test__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_79)); return A_arbace_test__init_A_const_78 }
//line :606:1
func A_arbace_test__init_A_Unit57__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(606, 1); A_arbace_test__init_A_const_78.SetMacro__V(); return nil }
//line :606:1
func A_arbace_test__init_A_Unit58__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(606, 1); return A_arbace_test__init_A_const_78 }
















func A_arbace_test__init_A_Unit59__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(623, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_80; var tmp2 any = A_arbace_test_deftest__A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_test_deftest__A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, true); A_arbace_test_deftest__A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_test__init_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_81)); return A_arbace_test__init_A_const_80 }
//line :623:1
func A_arbace_test__init_A_Unit60__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(623, 1); A_arbace_test__init_A_const_80.SetMacro__V(); return nil }
//line :623:1
func A_arbace_test__init_A_Unit61__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(623, 1); return A_arbace_test__init_A_const_80 }







func A_arbace_test__init_A_Unit62__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(631, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_82; var tmp2 any = A_arbace_test_set_test_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_test_set_test_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, true); A_arbace_test_set_test_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_test__init_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_83)); return A_arbace_test__init_A_const_82 }
//line :631:1
func A_arbace_test__init_A_Unit63__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(631, 1); A_arbace_test__init_A_const_82.SetMacro__V(); return nil }
//line :631:1
func A_arbace_test__init_A_Unit64__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(631, 1); return A_arbace_test__init_A_const_82 }












func A_arbace_test__init_A_Unit65__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(644, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_84; var tmp2 any = A_arbace_test_add_ns_meta_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_test_add_ns_meta_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_test_add_ns_meta_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_85)); return A_arbace_test__init_A_const_84 }






func A_arbace_test__init_A_Unit66__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(651, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_test__init_A_const_86; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_87)); v__1927000386__auto____1 = A_arbace_test__init_A_const_86; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(A_arbace_test__init_A_const_34.GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_test__init_A_const_86; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_88)); var tmp4 *lang.Var = A_arbace_test__init_A_const_86; var tmp5 *jrt.String = Lit_79; var tmp6 any = A_arbace_test_eval196000154_fn__196000155_A_New(); var tmp7 *jrt.Class
						var fncls__39 /*line :651:1*/*jrt.Class = A_arbace_test_eval196000154_fn__196000155_A_fn_class




	if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, true); A_arbace_test_eval196000154_fn__196000155_A_fn_class = fncls__39d; tmp7 = fncls__39d } else { tmp7 = fncls__39 }
//line :651:1
	var tmp8 lang.IFn = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp6, tmp7, nil, 1); var tmp9 any = A_arbace_test__init_A_const_36; tmp4.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp8, tmp9, A_arbace_test__init_A_const_37)); return A_arbace_test__init_A_const_86 } }






func A_arbace_test__init_A_Unit67__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(658, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_86.GetRawRoot__O()); var tmp2 any = A_arbace_test__init_A_const_89; var tmp3 any = A_arbace_test_eval196000158_fn__196000159_A_New(); var tmp4 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_test_eval196000158_fn__196000159_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, true); A_arbace_test_eval196000158_fn__196000159_A_fn_class = fncls__40d; tmp4 = fncls__40d } else { tmp4 = fncls__40 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp3, tmp4, nil, 1)).Ref() }


func A_arbace_test__init_A_Unit68__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(661, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test__init_A_const_86.GetRawRoot__O()); var tmp2 any = A_arbace_test__init_A_const_90; var tmp3 any = A_arbace_test_eval196000162_fn__196000163_A_New(); var tmp4 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_test_eval196000162_fn__196000163_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, true); A_arbace_test_eval196000162_fn__196000163_A_fn_class = fncls__41d; tmp4 = fncls__41d } else { tmp4 = fncls__41 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp3, tmp4, nil, 1)).Ref() }


func A_arbace_test__init_A_Unit69__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(664, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_91; var tmp2 any = A_arbace_test_default_fixture_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_test_default_fixture_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_test_default_fixture_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_92)); return A_arbace_test__init_A_const_91 }





func A_arbace_test__init_A_Unit70__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(670, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_93; var tmp2 any = A_arbace_test_compose_fixtures_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_test_compose_fixtures_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_test_compose_fixtures_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_94)); return A_arbace_test__init_A_const_93 }






func A_arbace_test__init_A_Unit71__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(677, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_95; var tmp2 any = A_arbace_test_join_fixtures_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_test_join_fixtures_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_test_join_fixtures_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_96)); return A_arbace_test__init_A_const_95 }








func A_arbace_test__init_A_Unit72__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(686, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_97; var tmp2 any = A_arbace_test_test_var_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_test_test_var_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_test_test_var_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_98)); return A_arbace_test__init_A_const_97.SetDynamic_Z__Var(true).Ref() }














func A_arbace_test__init_A_Unit73__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(701, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_99; var tmp2 any = A_arbace_test_test_vars_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_test_test_vars_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_test_test_vars_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_100)); return A_arbace_test__init_A_const_99 }













func A_arbace_test__init_A_Unit74__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(715, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_101; var tmp2 any = A_arbace_test_test_all_vars_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_test_test_all_vars_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_test_test_all_vars_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_102)); return A_arbace_test__init_A_const_101 }





func A_arbace_test__init_A_Unit75__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(721, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_103; var tmp2 any = A_arbace_test_test_ns_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_test_test_ns_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_test_test_ns_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_104)); return A_arbace_test__init_A_const_103 }






















func A_arbace_test__init_A_Unit76__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(744, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_105; var tmp2 any = A_arbace_test_run_tests_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_test_run_tests_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, true); A_arbace_test_run_tests_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_test__init_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_106)); return A_arbace_test__init_A_const_105 }











func A_arbace_test__init_A_Unit77__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(756, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_107; var tmp2 any = A_arbace_test_run_all_tests_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_test_run_all_tests_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_test_run_all_tests_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_108)); return A_arbace_test__init_A_const_107 }








func A_arbace_test__init_A_Unit78__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(765, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_109; var tmp2 any = A_arbace_test_successful_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_test_successful_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_test_successful_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_110)); return A_arbace_test__init_A_const_109 }







func A_arbace_test__init_A_Unit79__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(773, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_111; var tmp2 any = A_arbace_test_run_test_var_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_test_run_test_var_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_test_run_test_var_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_112)); return A_arbace_test__init_A_const_111 }















func A_arbace_test__init_A_Unit80__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(789, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_113; var tmp2 any = A_arbace_test_run_test_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_test_run_test_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_test_run_test_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_114)); return A_arbace_test__init_A_const_113 }
//line :789:1
func A_arbace_test__init_A_Unit81__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(789, 1); A_arbace_test__init_A_const_113.SetMacro__V(); return nil }
//line :789:1
func A_arbace_test__init_A_Unit82__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(789, 1); return A_arbace_test__init_A_const_113 }







type A_arbace_test__init_A struct{ jrt.Object }

var A_arbace_test__init_A_const_pool *jrt.RefArray

var A_arbace_test__init_A_const_0 *lang.Var

var A_arbace_test__init_A_const_1 any

var A_arbace_test__init_A_const_2 any

var A_arbace_test__init_A_const_3 any

var A_arbace_test__init_A_const_4 *lang.Var

var A_arbace_test__init_A_const_5 any

var A_arbace_test__init_A_const_6 any

var A_arbace_test__init_A_const_7 *lang.Var

var A_arbace_test__init_A_const_8 any

var A_arbace_test__init_A_const_9 *lang.Var

var A_arbace_test__init_A_const_10 any

var A_arbace_test__init_A_const_11 *lang.Var

var A_arbace_test__init_A_const_12 any

var A_arbace_test__init_A_const_13 any

var A_arbace_test__init_A_const_14 *lang.Var

var A_arbace_test__init_A_const_15 *lang.Var

var A_arbace_test__init_A_const_16 any

var A_arbace_test__init_A_const_17 *lang.Var

var A_arbace_test__init_A_const_18 any

var A_arbace_test__init_A_const_19 *lang.Var

var A_arbace_test__init_A_const_20 *lang.Var

var A_arbace_test__init_A_const_21 any

var A_arbace_test__init_A_const_22 *lang.Var

var A_arbace_test__init_A_const_23 any

var A_arbace_test__init_A_const_24 *lang.Var

var A_arbace_test__init_A_const_25 any

var A_arbace_test__init_A_const_26 *lang.Var

var A_arbace_test__init_A_const_27 any

var A_arbace_test__init_A_const_28 *lang.Var

var A_arbace_test__init_A_const_29 any

var A_arbace_test__init_A_const_30 *lang.Var

var A_arbace_test__init_A_const_31 any

var A_arbace_test__init_A_const_32 *lang.Var

var A_arbace_test__init_A_const_33 any

var A_arbace_test__init_A_const_34 *lang.Var

var A_arbace_test__init_A_const_35 *lang.Keyword

var A_arbace_test__init_A_const_36 *lang.Keyword

var A_arbace_test__init_A_const_37 *lang.Var

var A_arbace_test__init_A_const_38 any

var A_arbace_test__init_A_const_39 *lang.Var

var A_arbace_test__init_A_const_40 any

var A_arbace_test__init_A_const_41 *lang.Var

var A_arbace_test__init_A_const_42 any

var A_arbace_test__init_A_const_43 *lang.Var

var A_arbace_test__init_A_const_44 any

var A_arbace_test__init_A_const_45 *lang.Keyword

var A_arbace_test__init_A_const_46 *lang.Keyword

var A_arbace_test__init_A_const_47 *lang.Keyword

var A_arbace_test__init_A_const_48 *lang.Keyword

var A_arbace_test__init_A_const_49 *lang.Keyword

var A_arbace_test__init_A_const_50 *lang.Keyword

var A_arbace_test__init_A_const_51 *lang.Keyword

var A_arbace_test__init_A_const_52 *lang.Keyword

var A_arbace_test__init_A_const_53 *lang.Var

var A_arbace_test__init_A_const_54 any

var A_arbace_test__init_A_const_55 *lang.Var

var A_arbace_test__init_A_const_56 any

var A_arbace_test__init_A_const_57 *lang.Var

var A_arbace_test__init_A_const_58 any

var A_arbace_test__init_A_const_59 *lang.Var

var A_arbace_test__init_A_const_60 any

var A_arbace_test__init_A_const_61 *lang.Var

var A_arbace_test__init_A_const_62 any

var A_arbace_test__init_A_const_63 any

var A_arbace_test__init_A_const_64 *lang.Keyword

var A_arbace_test__init_A_const_65 any

var A_arbace_test__init_A_const_66 any

var A_arbace_test__init_A_const_67 any

var A_arbace_test__init_A_const_68 *lang.Var

var A_arbace_test__init_A_const_69 any

var A_arbace_test__init_A_const_70 *lang.Var

var A_arbace_test__init_A_const_71 any

var A_arbace_test__init_A_const_72 *lang.Var

var A_arbace_test__init_A_const_73 any

var A_arbace_test__init_A_const_74 *lang.Var

var A_arbace_test__init_A_const_75 any

var A_arbace_test__init_A_const_76 *lang.Var

var A_arbace_test__init_A_const_77 any

var A_arbace_test__init_A_const_78 *lang.Var

var A_arbace_test__init_A_const_79 any

var A_arbace_test__init_A_const_80 *lang.Var

var A_arbace_test__init_A_const_81 any

var A_arbace_test__init_A_const_82 *lang.Var

var A_arbace_test__init_A_const_83 any

var A_arbace_test__init_A_const_84 *lang.Var

var A_arbace_test__init_A_const_85 any

var A_arbace_test__init_A_const_86 *lang.Var

var A_arbace_test__init_A_const_87 any

var A_arbace_test__init_A_const_88 any

var A_arbace_test__init_A_const_89 *lang.Keyword

var A_arbace_test__init_A_const_90 *lang.Keyword

var A_arbace_test__init_A_const_91 *lang.Var

var A_arbace_test__init_A_const_92 any

var A_arbace_test__init_A_const_93 *lang.Var

var A_arbace_test__init_A_const_94 any

var A_arbace_test__init_A_const_95 *lang.Var

var A_arbace_test__init_A_const_96 any

var A_arbace_test__init_A_const_97 *lang.Var

var A_arbace_test__init_A_const_98 any

var A_arbace_test__init_A_const_99 *lang.Var

var A_arbace_test__init_A_const_100 any

var A_arbace_test__init_A_const_101 *lang.Var

var A_arbace_test__init_A_const_102 any

var A_arbace_test__init_A_const_103 *lang.Var

var A_arbace_test__init_A_const_104 any

var A_arbace_test__init_A_const_105 *lang.Var

var A_arbace_test__init_A_const_106 any

var A_arbace_test__init_A_const_107 *lang.Var

var A_arbace_test__init_A_const_108 any

var A_arbace_test__init_A_const_109 *lang.Var

var A_arbace_test__init_A_const_110 any

var A_arbace_test__init_A_const_111 *lang.Var

var A_arbace_test__init_A_const_112 any

var A_arbace_test__init_A_const_113 *lang.Var

var A_arbace_test__init_A_const_114 any

var A_arbace_test__init_A_init jrt.ClassInit

func A_arbace_test__init_A_Init() { if !A_arbace_test__init_A_init.Done() { A_arbace_test__init_A_init.Run(A_arbace_test__init_A_clinit) } }

func A_arbace_test__init_A_clinit() { A_arbace_test__init_A_clinit_p0(); A_arbace_test__init_A_clinit_p1(); A_arbace_test__init_A_clinit_p2(); A_arbace_test__init_A_clinit_p3(); A_arbace_test__init_A_clinit_p4(); A_arbace_test__init_A_clinit_p5(); A_arbace_test__init_A_clinit_p6(); A_arbace_test__init_A_clinit_p7(); A_arbace_test__init_A_clinit_p8() }

func A_arbace_test__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_test__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_38, 173); A_arbace_test__init_A_const_0 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[58]); A_arbace_test__init_A_const_1 = A_arbace_test__init_A_const_pool.A[59]; A_arbace_test__init_A_const_2 = A_arbace_test__init_A_const_pool.A[60]; A_arbace_test__init_A_const_3 = A_arbace_test__init_A_const_pool.A[61]; A_arbace_test__init_A_const_4 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[62]); A_arbace_test__init_A_const_5 = A_arbace_test__init_A_const_pool.A[63]; A_arbace_test__init_A_const_6 = A_arbace_test__init_A_const_pool.A[64]; A_arbace_test__init_A_const_7 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[65]); A_arbace_test__init_A_const_8 = A_arbace_test__init_A_const_pool.A[66]; A_arbace_test__init_A_const_9 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[67]); A_arbace_test__init_A_const_10 = A_arbace_test__init_A_const_pool.A[68]; A_arbace_test__init_A_const_11 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[69]); A_arbace_test__init_A_const_12 = A_arbace_test__init_A_const_pool.A[70] }

func A_arbace_test__init_A_clinit_p1() { A_arbace_test__init_A_const_13 = A_arbace_test__init_A_const_pool.A[71]; A_arbace_test__init_A_const_14 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[72]); A_arbace_test__init_A_const_15 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[73]); A_arbace_test__init_A_const_16 = A_arbace_test__init_A_const_pool.A[74]; A_arbace_test__init_A_const_17 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[75]); A_arbace_test__init_A_const_18 = A_arbace_test__init_A_const_pool.A[76]; A_arbace_test__init_A_const_19 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[77]); A_arbace_test__init_A_const_20 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[78]); A_arbace_test__init_A_const_21 = A_arbace_test__init_A_const_pool.A[79]; A_arbace_test__init_A_const_22 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[80]); A_arbace_test__init_A_const_23 = A_arbace_test__init_A_const_pool.A[81]; A_arbace_test__init_A_const_24 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[82]); A_arbace_test__init_A_const_25 = A_arbace_test__init_A_const_pool.A[83] }

func A_arbace_test__init_A_clinit_p2() { A_arbace_test__init_A_const_26 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[84]); A_arbace_test__init_A_const_27 = A_arbace_test__init_A_const_pool.A[85]; A_arbace_test__init_A_const_28 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[86]); A_arbace_test__init_A_const_29 = A_arbace_test__init_A_const_pool.A[87]; A_arbace_test__init_A_const_30 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[88]); A_arbace_test__init_A_const_31 = A_arbace_test__init_A_const_pool.A[89]; A_arbace_test__init_A_const_32 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[90]); A_arbace_test__init_A_const_33 = A_arbace_test__init_A_const_pool.A[91]; A_arbace_test__init_A_const_34 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[92]); A_arbace_test__init_A_const_35 = lang.Keyword_Cast(A_arbace_test__init_A_const_pool.A[93]); A_arbace_test__init_A_const_36 = lang.Keyword_Cast(A_arbace_test__init_A_const_pool.A[94]); A_arbace_test__init_A_const_37 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[95]); A_arbace_test__init_A_const_38 = A_arbace_test__init_A_const_pool.A[96] }

func A_arbace_test__init_A_clinit_p3() { A_arbace_test__init_A_const_39 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[97]); A_arbace_test__init_A_const_40 = A_arbace_test__init_A_const_pool.A[98]; A_arbace_test__init_A_const_41 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[99]); A_arbace_test__init_A_const_42 = A_arbace_test__init_A_const_pool.A[100]; A_arbace_test__init_A_const_43 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[101]); A_arbace_test__init_A_const_44 = A_arbace_test__init_A_const_pool.A[102]; A_arbace_test__init_A_const_45 = lang.Keyword_Cast(A_arbace_test__init_A_const_pool.A[103]); A_arbace_test__init_A_const_46 = lang.Keyword_Cast(A_arbace_test__init_A_const_pool.A[104]); A_arbace_test__init_A_const_47 = lang.Keyword_Cast(A_arbace_test__init_A_const_pool.A[105]); A_arbace_test__init_A_const_48 = lang.Keyword_Cast(A_arbace_test__init_A_const_pool.A[106]); A_arbace_test__init_A_const_49 = lang.Keyword_Cast(A_arbace_test__init_A_const_pool.A[107]); A_arbace_test__init_A_const_50 = lang.Keyword_Cast(A_arbace_test__init_A_const_pool.A[108]) }

func A_arbace_test__init_A_clinit_p4() { A_arbace_test__init_A_const_51 = lang.Keyword_Cast(A_arbace_test__init_A_const_pool.A[109]); A_arbace_test__init_A_const_52 = lang.Keyword_Cast(A_arbace_test__init_A_const_pool.A[110]); A_arbace_test__init_A_const_53 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[111]); A_arbace_test__init_A_const_54 = A_arbace_test__init_A_const_pool.A[112]; A_arbace_test__init_A_const_55 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[113]); A_arbace_test__init_A_const_56 = A_arbace_test__init_A_const_pool.A[114]; A_arbace_test__init_A_const_57 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[115]); A_arbace_test__init_A_const_58 = A_arbace_test__init_A_const_pool.A[116]; A_arbace_test__init_A_const_59 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[117]); A_arbace_test__init_A_const_60 = A_arbace_test__init_A_const_pool.A[118]; A_arbace_test__init_A_const_61 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[119]); A_arbace_test__init_A_const_62 = A_arbace_test__init_A_const_pool.A[120]; A_arbace_test__init_A_const_63 = A_arbace_test__init_A_const_pool.A[121] }

func A_arbace_test__init_A_clinit_p5() { A_arbace_test__init_A_const_64 = lang.Keyword_Cast(A_arbace_test__init_A_const_pool.A[122]); A_arbace_test__init_A_const_65 = A_arbace_test__init_A_const_pool.A[123]; A_arbace_test__init_A_const_66 = A_arbace_test__init_A_const_pool.A[124]; A_arbace_test__init_A_const_67 = A_arbace_test__init_A_const_pool.A[125]; A_arbace_test__init_A_const_68 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[126]); A_arbace_test__init_A_const_69 = A_arbace_test__init_A_const_pool.A[127]; A_arbace_test__init_A_const_70 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[128]); A_arbace_test__init_A_const_71 = A_arbace_test__init_A_const_pool.A[129]; A_arbace_test__init_A_const_72 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[130]); A_arbace_test__init_A_const_73 = A_arbace_test__init_A_const_pool.A[131]; A_arbace_test__init_A_const_74 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[132]); A_arbace_test__init_A_const_75 = A_arbace_test__init_A_const_pool.A[133]; A_arbace_test__init_A_const_76 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[134]); A_arbace_test__init_A_const_77 = A_arbace_test__init_A_const_pool.A[135] }

func A_arbace_test__init_A_clinit_p6() { A_arbace_test__init_A_const_78 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[136]); A_arbace_test__init_A_const_79 = A_arbace_test__init_A_const_pool.A[137]; A_arbace_test__init_A_const_80 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[138]); A_arbace_test__init_A_const_81 = A_arbace_test__init_A_const_pool.A[139]; A_arbace_test__init_A_const_82 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[140]); A_arbace_test__init_A_const_83 = A_arbace_test__init_A_const_pool.A[141]; A_arbace_test__init_A_const_84 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[142]); A_arbace_test__init_A_const_85 = A_arbace_test__init_A_const_pool.A[143]; A_arbace_test__init_A_const_86 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[144]); A_arbace_test__init_A_const_87 = A_arbace_test__init_A_const_pool.A[145]; A_arbace_test__init_A_const_88 = A_arbace_test__init_A_const_pool.A[146]; A_arbace_test__init_A_const_89 = lang.Keyword_Cast(A_arbace_test__init_A_const_pool.A[147]); A_arbace_test__init_A_const_90 = lang.Keyword_Cast(A_arbace_test__init_A_const_pool.A[148]) }

func A_arbace_test__init_A_clinit_p7() { A_arbace_test__init_A_const_91 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[149]); A_arbace_test__init_A_const_92 = A_arbace_test__init_A_const_pool.A[150]; A_arbace_test__init_A_const_93 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[151]); A_arbace_test__init_A_const_94 = A_arbace_test__init_A_const_pool.A[152]; A_arbace_test__init_A_const_95 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[153]); A_arbace_test__init_A_const_96 = A_arbace_test__init_A_const_pool.A[154]; A_arbace_test__init_A_const_97 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[155]); A_arbace_test__init_A_const_98 = A_arbace_test__init_A_const_pool.A[156]; A_arbace_test__init_A_const_99 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[157]); A_arbace_test__init_A_const_100 = A_arbace_test__init_A_const_pool.A[158]; A_arbace_test__init_A_const_101 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[159]); A_arbace_test__init_A_const_102 = A_arbace_test__init_A_const_pool.A[160]; A_arbace_test__init_A_const_103 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[161]) }

func A_arbace_test__init_A_clinit_p8() { A_arbace_test__init_A_const_104 = A_arbace_test__init_A_const_pool.A[162]; A_arbace_test__init_A_const_105 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[163]); A_arbace_test__init_A_const_106 = A_arbace_test__init_A_const_pool.A[164]; A_arbace_test__init_A_const_107 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[165]); A_arbace_test__init_A_const_108 = A_arbace_test__init_A_const_pool.A[166]; A_arbace_test__init_A_const_109 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[167]); A_arbace_test__init_A_const_110 = A_arbace_test__init_A_const_pool.A[168]; A_arbace_test__init_A_const_111 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[169]); A_arbace_test__init_A_const_112 = A_arbace_test__init_A_const_pool.A[170]; A_arbace_test__init_A_const_113 = lang.Var_Cast(A_arbace_test__init_A_const_pool.A[171]); A_arbace_test__init_A_const_114 = A_arbace_test__init_A_const_pool.A[172] }

func A_arbace_test__init_A_New() *A_arbace_test__init_A { A_arbace_test__init_A_Init(); t := &A_arbace_test__init_A{}; t.Ctor(); return t }

func (t *A_arbace_test__init_A) Ctor() {}

func (t *A_arbace_test__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test__init_A) GetClass__Class() *jrt.Class { return A_arbace_test__init_A_class }

func (t *A_arbace_test__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test__init_A); return ok }

func A_arbace_test__init_A_Cast(x any) *A_arbace_test__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test__init_A_class)) }; return v }
