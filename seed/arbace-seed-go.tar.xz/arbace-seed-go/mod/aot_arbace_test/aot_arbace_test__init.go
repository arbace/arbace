//line aot_arbace_test__init.ae:1
package aot_arbace_test

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_test__init_A_Load__O() any { A_arbace_test__init_A_Init(); A_arbace_test__init_A_Unit0__O(); A_arbace_test__init_A_Unit1__O(); A_arbace_test__init_A_Unit2__O(); A_arbace_test__init_A_Unit3__O(); A_arbace_test__init_A_Unit4__O(); A_arbace_test__init_A_Unit5__O(); A_arbace_test__init_A_Unit6__O(); A_arbace_test__init_A_Unit7__O(); A_arbace_test__init_A_Unit8__O(); A_arbace_test__init_A_Unit9__O(); A_arbace_test__init_A_Unit10__O(); A_arbace_test__init_A_Unit11__O(); A_arbace_test__init_A_Unit12__O(); A_arbace_test__init_A_Unit13__O(); A_arbace_test__init_A_Unit14__O(); A_arbace_test__init_A_Unit15__O(); A_arbace_test__init_A_Unit16__O(); A_arbace_test__init_A_Unit17__O(); A_arbace_test__init_A_Unit18__O(); A_arbace_test__init_A_Unit19__O(); A_arbace_test__init_A_Unit20__O(); A_arbace_test__init_A_Unit21__O(); A_arbace_test__init_A_Unit22__O(); A_arbace_test__init_A_Unit23__O(); A_arbace_test__init_A_Unit24__O(); A_arbace_test__init_A_Unit25__O(); A_arbace_test__init_A_Unit26__O(); A_arbace_test__init_A_Unit27__O(); A_arbace_test__init_A_Unit28__O(); A_arbace_test__init_A_Unit29__O(); A_arbace_test__init_A_Unit30__O(); A_arbace_test__init_A_Unit31__O(); A_arbace_test__init_A_Unit32__O(); A_arbace_test__init_A_Unit33__O(); A_arbace_test__init_A_Unit34__O(); A_arbace_test__init_A_Unit35__O(); A_arbace_test__init_A_Unit36__O(); A_arbace_test__init_A_Unit37__O(); A_arbace_test__init_A_Unit38__O(); A_arbace_test__init_A_Unit39__O(); A_arbace_test__init_A_Unit40__O(); A_arbace_test__init_A_Unit41__O(); A_arbace_test__init_A_Unit42__O(); A_arbace_test__init_A_Unit43__O(); A_arbace_test__init_A_Unit44__O(); A_arbace_test__init_A_Unit45__O(); A_arbace_test__init_A_Unit46__O(); A_arbace_test__init_A_Unit47__O(); A_arbace_test__init_A_Unit48__O(); A_arbace_test__init_A_Unit49__O(); A_arbace_test__init_A_Unit50__O(); A_arbace_test__init_A_Unit51__O(); A_arbace_test__init_A_Unit52__O(); A_arbace_test__init_A_Unit53__O(); A_arbace_test__init_A_Unit54__O(); A_arbace_test__init_A_Unit55__O(); A_arbace_test__init_A_Unit56__O(); A_arbace_test__init_A_Unit57__O(); A_arbace_test__init_A_Unit58__O(); A_arbace_test__init_A_Unit59__O(); A_arbace_test__init_A_Unit60__O(); A_arbace_test__init_A_Unit61__O(); A_arbace_test__init_A_Unit62__O(); A_arbace_test__init_A_Unit63__O(); A_arbace_test__init_A_Unit64__O(); A_arbace_test__init_A_Unit65__O(); A_arbace_test__init_A_Unit66__O(); A_arbace_test__init_A_Unit67__O(); A_arbace_test__init_A_Unit68__O(); A_arbace_test__init_A_Unit69__O(); A_arbace_test__init_A_Unit70__O(); A_arbace_test__init_A_Unit71__O(); A_arbace_test__init_A_Unit72__O(); A_arbace_test__init_A_Unit73__O(); A_arbace_test__init_A_Unit74__O(); A_arbace_test__init_A_Unit75__O(); A_arbace_test__init_A_Unit76__O(); A_arbace_test__init_A_Unit77__O(); A_arbace_test__init_A_Unit78__O(); A_arbace_test__init_A_Unit79__O(); A_arbace_test__init_A_Unit80__O(); A_arbace_test__init_A_Unit81__O(); A_arbace_test__init_A_Unit82__O(); return nil }











func A_arbace_test__init_A_Unit0__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); return lang.IFn_Cast(jrt.NN(A_arbace_test__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_test__init_A_const_1) }
//line :17:1
func A_arbace_test__init_A_Unit1__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_test__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_2)) }
//line :17:1
func A_arbace_test__init_A_Unit2__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); var tmp1 any = A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_New(); var tmp2 *jrt.Class; A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_Init(); tmp2 = A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :17:1
func A_arbace_test__init_A_Unit3__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_test__init_A_const_1)).Equals_O__Z(A_arbace_test__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_test_eval196000008_fn__196000009_A_New(); var tmp2 *jrt.Class; A_arbace_test_eval196000008_fn__196000009_A_Init(); tmp2 = A_arbace_test_eval196000008_fn__196000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }






























































































































































































































func A_arbace_test__init_A_Unit4__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(240, 1); var v__1927001498__auto____1 any; jrt.NN(A_arbace_test__init_A_const_4).SetDynamic_Z__Var(true); var tmp1 *lang.Var = A_arbace_test__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_5)); v__1927001498__auto____1 = A_arbace_test__init_A_const_4.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { jrt.NN(A_arbace_test__init_A_const_4).SetDynamic_Z__Var(true); var tmp2 *lang.Var = A_arbace_test__init_A_const_4; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_6)); var tmp3 *lang.Var = A_arbace_test__init_A_const_4; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; jrt.NN(tmp3).BindRoot_O__V(tmp4.Ref()); return A_arbace_test__init_A_const_4.Ref() } }






func A_arbace_test__init_A_Unit5__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(247, 1); jrt.NN(A_arbace_test__init_A_const_7).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_test__init_A_const_7; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_8)); return jrt.NN(A_arbace_test__init_A_const_7).SetDynamic_Z__Var(true).Ref() }








func A_arbace_test__init_A_Unit6__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(256, 1); jrt.NN(A_arbace_test__init_A_const_9).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_test__init_A_const_9; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_10)); return jrt.NN(A_arbace_test__init_A_const_9).SetDynamic_Z__Var(true).Ref() }

func A_arbace_test__init_A_Unit7__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(258, 1); jrt.NN(A_arbace_test__init_A_const_11).BindRoot_O__V(A_arbace_test__init_A_const_12); var tmp1 *lang.Var = A_arbace_test__init_A_const_11; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_13)); return jrt.NN(A_arbace_test__init_A_const_11).SetDynamic_Z__Var(true).Ref() }


func A_arbace_test__init_A_Unit8__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(261, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_14; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_test__init_A_const_15).GetRawRoot__O()).Invoke__O()); var tmp2 *lang.Var = A_arbace_test__init_A_const_14; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_16)); return jrt.NN(A_arbace_test__init_A_const_14).SetDynamic_Z__Var(true).Ref() }

func A_arbace_test__init_A_Unit9__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(263, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_17; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_test__init_A_const_15).GetRawRoot__O()).Invoke__O()); var tmp2 *lang.Var = A_arbace_test__init_A_const_17; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_18)); return jrt.NN(A_arbace_test__init_A_const_17).SetDynamic_Z__Var(true).Ref() }

func A_arbace_test__init_A_Unit10__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(265, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_19; jrt.NN(tmp1).BindRoot_O__V(jrt.NN(A_arbace_test__init_A_const_20).Get__O()); var tmp2 *lang.Var = A_arbace_test__init_A_const_19; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_21)); return jrt.NN(A_arbace_test__init_A_const_19).SetDynamic_Z__Var(true).Ref() }

func A_arbace_test__init_A_Unit11__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(267, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_22; var tmp2 any = A_arbace_test_with_test_out_A_New(); var tmp3 *jrt.Class; A_arbace_test_with_test_out_A_Init(); tmp3 = A_arbace_test_with_test_out_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_test__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_23)); return A_arbace_test__init_A_const_22.Ref() }
//line :267:1
func A_arbace_test__init_A_Unit12__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(267, 1); jrt.NN(A_arbace_test__init_A_const_22).SetMacro__V(); return nil }
//line :267:1
func A_arbace_test__init_A_Unit13__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(267, 1); return A_arbace_test__init_A_const_22.Ref() }








func A_arbace_test__init_A_Unit14__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(276, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_24; var tmp2 any = A_arbace_test_file_position_A_New(); var tmp3 *jrt.Class; A_arbace_test_file_position_A_Init(); tmp3 = A_arbace_test_file_position_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_25)); return A_arbace_test__init_A_const_24.Ref() }











func A_arbace_test__init_A_Unit15__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(288, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_26; var tmp2 any = A_arbace_test_testing_vars_str_A_New(); var tmp3 *jrt.Class; A_arbace_test_testing_vars_str_A_Init(); tmp3 = A_arbace_test_testing_vars_str_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_27)); return A_arbace_test__init_A_const_26.Ref() }












func A_arbace_test__init_A_Unit16__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(301, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_28; var tmp2 any = A_arbace_test_testing_contexts_str_A_New(); var tmp3 *jrt.Class; A_arbace_test_testing_contexts_str_A_Init(); tmp3 = A_arbace_test_testing_contexts_str_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_29)); return A_arbace_test__init_A_const_28.Ref() }






func A_arbace_test__init_A_Unit17__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(308, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_30; var tmp2 any = A_arbace_test_inc_report_counter_A_New(); var tmp3 *jrt.Class; A_arbace_test_inc_report_counter_A_Init(); tmp3 = A_arbace_test_inc_report_counter_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_31)); return A_arbace_test__init_A_const_30.Ref() }









func A_arbace_test__init_A_Unit18__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(318, 1); var v__1927000386__auto____1 any; jrt.NN(A_arbace_test__init_A_const_32).SetDynamic_Z__Var(true); var tmp1 *lang.Var = A_arbace_test__init_A_const_32; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_33)); v__1927000386__auto____1 = A_arbace_test__init_A_const_32.Ref(); var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(jrt.NN(A_arbace_test__init_A_const_34).GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { jrt.NN(A_arbace_test__init_A_const_32).SetDynamic_Z__Var(true); var tmp3 *lang.Var = A_arbace_test__init_A_const_32; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_38)); var tmp4 *lang.Var = A_arbace_test__init_A_const_32; var tmp5 *jrt.String = Lit_42; var tmp6 lang.IFn = Up_Keyword_IFn(A_arbace_test__init_A_const_35); var tmp7 any = A_arbace_test__init_A_const_36.Ref(); jrt.NN(tmp4).BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp6, tmp7, Up_Var_IRef(A_arbace_test__init_A_const_37))); return A_arbace_test__init_A_const_32.Ref() } }










func A_arbace_test__init_A_Unit19__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(329, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_39; var tmp2 any = A_arbace_test_file_and_line_A_New(); var tmp3 *jrt.Class; A_arbace_test_file_and_line_A_Init(); tmp3 = A_arbace_test_file_and_line_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_39; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_40)); return A_arbace_test__init_A_const_39.Ref() }








func A_arbace_test__init_A_Unit20__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(338, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_41; var tmp2 any = A_arbace_test_stacktrace_file_and_line_A_New(); var tmp3 *jrt.Class; A_arbace_test_stacktrace_file_and_line_A_Init(); tmp3 = A_arbace_test_stacktrace_file_and_line_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_41; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_42)); return A_arbace_test__init_A_const_41.Ref() }






func A_arbace_test__init_A_Unit21__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(345, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_43; var tmp2 any = A_arbace_test_do_report_A_New(); var tmp3 *jrt.Class; A_arbace_test_do_report_A_Init(); tmp3 = A_arbace_test_do_report_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_44)); return A_arbace_test__init_A_const_43.Ref() }

















func A_arbace_test__init_A_Unit22__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(363, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_32).Get__O()); var tmp2 any = A_arbace_test__init_A_const_36.Ref(); var tmp3 any = A_arbace_test_eval196000039_fn__196000040_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000039_fn__196000040_A_Init(); tmp4 = A_arbace_test_eval196000039_fn__196000040_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_test__init_A_Unit23__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(366, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_32).Get__O()); var tmp2 any = A_arbace_test__init_A_const_45.Ref(); var tmp3 any = A_arbace_test_eval196000043_fn__196000044_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000043_fn__196000044_A_Init(); tmp4 = A_arbace_test_eval196000043_fn__196000044_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_test__init_A_Unit24__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(369, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_32).Get__O()); var tmp2 any = A_arbace_test__init_A_const_46.Ref(); var tmp3 any = A_arbace_test_eval196000047_fn__196000048_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000047_fn__196000048_A_Init(); tmp4 = A_arbace_test_eval196000047_fn__196000048_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }








func A_arbace_test__init_A_Unit25__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(378, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_32).Get__O()); var tmp2 any = A_arbace_test__init_A_const_47.Ref(); var tmp3 any = A_arbace_test_eval196000051_fn__196000052_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000051_fn__196000052_A_Init(); tmp4 = A_arbace_test_eval196000051_fn__196000052_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }












func A_arbace_test__init_A_Unit26__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(391, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_32).Get__O()); var tmp2 any = A_arbace_test__init_A_const_48.Ref(); var tmp3 any = A_arbace_test_eval196000055_fn__196000056_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000055_fn__196000056_A_Init(); tmp4 = A_arbace_test_eval196000055_fn__196000056_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_test__init_A_Unit27__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(397, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_32).Get__O()); var tmp2 any = A_arbace_test__init_A_const_49.Ref(); var tmp3 any = A_arbace_test_eval196000059_fn__196000060_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000059_fn__196000060_A_Init(); tmp4 = A_arbace_test_eval196000059_fn__196000060_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_test__init_A_Unit28__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(402, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_32).Get__O()); var tmp2 any = A_arbace_test__init_A_const_50.Ref(); var tmp3 any = A_arbace_test_eval196000063_fn__196000064_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000063_fn__196000064_A_Init(); tmp4 = A_arbace_test_eval196000063_fn__196000064_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_test__init_A_Unit29__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(403, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_32).Get__O()); var tmp2 any = A_arbace_test__init_A_const_51.Ref(); var tmp3 any = A_arbace_test_eval196000067_fn__196000068_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000067_fn__196000068_A_Init(); tmp4 = A_arbace_test_eval196000067_fn__196000068_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_test__init_A_Unit30__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(404, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_32).Get__O()); var tmp2 any = A_arbace_test__init_A_const_52.Ref(); var tmp3 any = A_arbace_test_eval196000071_fn__196000072_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000071_fn__196000072_A_Init(); tmp4 = A_arbace_test_eval196000071_fn__196000072_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test__init_A_Unit31__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(408, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_53; var tmp2 any = A_arbace_test_get_possibly_unbound_var_A_New(); var tmp3 *jrt.Class; A_arbace_test_get_possibly_unbound_var_A_Init(); tmp3 = A_arbace_test_get_possibly_unbound_var_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_53; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_54)); return A_arbace_test__init_A_const_53.Ref() }







func A_arbace_test__init_A_Unit32__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(416, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_55; var tmp2 any = A_arbace_test_function_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_test_function_QMARK__A_Init(); tmp3 = A_arbace_test_function_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_55; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_56)); return A_arbace_test__init_A_const_55.Ref() }











func A_arbace_test__init_A_Unit33__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(428, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_57; var tmp2 any = A_arbace_test_assert_predicate_A_New(); var tmp3 *jrt.Class; A_arbace_test_assert_predicate_A_Init(); tmp3 = A_arbace_test_assert_predicate_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_57; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_58)); return A_arbace_test__init_A_const_57.Ref() }


















func A_arbace_test__init_A_Unit34__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(447, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_59; var tmp2 any = A_arbace_test_assert_any_A_New(); var tmp3 *jrt.Class; A_arbace_test_assert_any_A_Init(); tmp3 = A_arbace_test_assert_any_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_59; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_60)); return A_arbace_test__init_A_const_59.Ref() }


















func A_arbace_test__init_A_Unit35__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(466, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_test__init_A_const_61; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_62)); v__1927000386__auto____1 = A_arbace_test__init_A_const_61.Ref(); var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(jrt.NN(A_arbace_test__init_A_const_34).GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_test__init_A_const_61; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_63)); var tmp4 *lang.Var = A_arbace_test__init_A_const_61; var tmp5 *jrt.String = Lit_107; var tmp6 any = A_arbace_test_eval196000082_fn__196000083_A_New(); var tmp7 *jrt.Class; A_arbace_test_eval196000082_fn__196000083_A_Init(); tmp7 = A_arbace_test_eval196000082_fn__196000083_A_fn_class; var tmp8 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_test__init_A_const_36.Ref(); jrt.NN(tmp4).BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp8, tmp9, Up_Var_IRef(A_arbace_test__init_A_const_37))); return A_arbace_test__init_A_const_61.Ref() } }






func A_arbace_test__init_A_Unit36__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(473, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_61).GetRawRoot__O()); var tmp2 any = A_arbace_test__init_A_const_64.Ref(); var tmp3 any = A_arbace_test_eval196000086_fn__196000087_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000086_fn__196000087_A_Init(); tmp4 = A_arbace_test_eval196000086_fn__196000087_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test__init_A_Unit37__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(477, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_61).GetRawRoot__O()); var tmp2 any = A_arbace_test__init_A_const_36.Ref(); var tmp3 any = A_arbace_test_eval196000090_fn__196000091_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000090_fn__196000091_A_Init(); tmp4 = A_arbace_test_eval196000090_fn__196000091_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_test__init_A_Unit38__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(482, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_61).GetRawRoot__O()); var tmp2 any = A_arbace_test__init_A_const_65; var tmp3 any = A_arbace_test_eval196000097_fn__196000098_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000097_fn__196000098_A_Init(); tmp4 = A_arbace_test_eval196000097_fn__196000098_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }











func A_arbace_test__init_A_Unit39__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(494, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_61).GetRawRoot__O()); var tmp2 any = A_arbace_test__init_A_const_66; var tmp3 any = A_arbace_test_eval196000102_fn__196000103_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000102_fn__196000103_A_Init(); tmp4 = A_arbace_test_eval196000102_fn__196000103_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }













func A_arbace_test__init_A_Unit40__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(508, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_61).GetRawRoot__O()); var tmp2 any = A_arbace_test__init_A_const_67; var tmp3 any = A_arbace_test_eval196000108_fn__196000109_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000108_fn__196000109_A_Init(); tmp4 = A_arbace_test_eval196000108_fn__196000109_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


















func A_arbace_test__init_A_Unit41__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(527, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_68; var tmp2 any = A_arbace_test_try_expr_A_New(); var tmp3 *jrt.Class; A_arbace_test_try_expr_A_Init(); tmp3 = A_arbace_test_try_expr_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_68; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_69)); return A_arbace_test__init_A_const_68.Ref() }
//line :527:1
func A_arbace_test__init_A_Unit42__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(527, 1); jrt.NN(A_arbace_test__init_A_const_68).SetMacro__V(); return nil }
//line :527:1
func A_arbace_test__init_A_Unit43__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(527, 1); return A_arbace_test__init_A_const_68.Ref() }













func A_arbace_test__init_A_Unit44__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(541, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_70; var tmp2 any = A_arbace_test_is_A_New(); var tmp3 *jrt.Class; A_arbace_test_is_A_Init(); tmp3 = A_arbace_test_is_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_70; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_71)); return A_arbace_test__init_A_const_70.Ref() }
//line :541:1
func A_arbace_test__init_A_Unit45__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(541, 1); jrt.NN(A_arbace_test__init_A_const_70).SetMacro__V(); return nil }
//line :541:1
func A_arbace_test__init_A_Unit46__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(541, 1); return A_arbace_test__init_A_const_70.Ref() }

















func A_arbace_test__init_A_Unit47__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(559, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_72; var tmp2 any = A_arbace_test_are_A_New(); var tmp3 *jrt.Class; A_arbace_test_are_A_Init(); tmp3 = A_arbace_test_are_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_test__init_A_const_72; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_73)); return A_arbace_test__init_A_const_72.Ref() }
//line :559:1
func A_arbace_test__init_A_Unit48__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(559, 1); jrt.NN(A_arbace_test__init_A_const_72).SetMacro__V(); return nil }
//line :559:1
func A_arbace_test__init_A_Unit49__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(559, 1); return A_arbace_test__init_A_const_72.Ref() }
























func A_arbace_test__init_A_Unit50__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(584, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_74; var tmp2 any = A_arbace_test_testing_A_New(); var tmp3 *jrt.Class; A_arbace_test_testing_A_Init(); tmp3 = A_arbace_test_testing_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_test__init_A_const_74; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_75)); return A_arbace_test__init_A_const_74.Ref() }
//line :584:1
func A_arbace_test__init_A_Unit51__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(584, 1); jrt.NN(A_arbace_test__init_A_const_74).SetMacro__V(); return nil }
//line :584:1
func A_arbace_test__init_A_Unit52__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(584, 1); return A_arbace_test__init_A_const_74.Ref() }









func A_arbace_test__init_A_Unit53__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(594, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_76; var tmp2 any = A_arbace_test_with_test_A_New(); var tmp3 *jrt.Class; A_arbace_test_with_test_A_Init(); tmp3 = A_arbace_test_with_test_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_test__init_A_const_76; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_77)); return A_arbace_test__init_A_const_76.Ref() }
//line :594:1
func A_arbace_test__init_A_Unit54__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(594, 1); jrt.NN(A_arbace_test__init_A_const_76).SetMacro__V(); return nil }
//line :594:1
func A_arbace_test__init_A_Unit55__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(594, 1); return A_arbace_test__init_A_const_76.Ref() }











func A_arbace_test__init_A_Unit56__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(606, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_78; var tmp2 any = A_arbace_test_deftest_A_New(); var tmp3 *jrt.Class; A_arbace_test_deftest_A_Init(); tmp3 = A_arbace_test_deftest_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_test__init_A_const_78; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_79)); return A_arbace_test__init_A_const_78.Ref() }
//line :606:1
func A_arbace_test__init_A_Unit57__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(606, 1); jrt.NN(A_arbace_test__init_A_const_78).SetMacro__V(); return nil }
//line :606:1
func A_arbace_test__init_A_Unit58__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(606, 1); return A_arbace_test__init_A_const_78.Ref() }
















func A_arbace_test__init_A_Unit59__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(623, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_80; var tmp2 any = A_arbace_test_deftest__A_New(); var tmp3 *jrt.Class; A_arbace_test_deftest__A_Init(); tmp3 = A_arbace_test_deftest__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_test__init_A_const_80; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_81)); return A_arbace_test__init_A_const_80.Ref() }
//line :623:1
func A_arbace_test__init_A_Unit60__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(623, 1); jrt.NN(A_arbace_test__init_A_const_80).SetMacro__V(); return nil }
//line :623:1
func A_arbace_test__init_A_Unit61__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(623, 1); return A_arbace_test__init_A_const_80.Ref() }







func A_arbace_test__init_A_Unit62__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(631, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_82; var tmp2 any = A_arbace_test_set_test_A_New(); var tmp3 *jrt.Class; A_arbace_test_set_test_A_Init(); tmp3 = A_arbace_test_set_test_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_test__init_A_const_82; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_83)); return A_arbace_test__init_A_const_82.Ref() }
//line :631:1
func A_arbace_test__init_A_Unit63__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(631, 1); jrt.NN(A_arbace_test__init_A_const_82).SetMacro__V(); return nil }
//line :631:1
func A_arbace_test__init_A_Unit64__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(631, 1); return A_arbace_test__init_A_const_82.Ref() }












func A_arbace_test__init_A_Unit65__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(644, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_84; var tmp2 any = A_arbace_test_add_ns_meta_A_New(); var tmp3 *jrt.Class; A_arbace_test_add_ns_meta_A_Init(); tmp3 = A_arbace_test_add_ns_meta_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_84; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_85)); return A_arbace_test__init_A_const_84.Ref() }






func A_arbace_test__init_A_Unit66__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(651, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_test__init_A_const_86; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_87)); v__1927000386__auto____1 = A_arbace_test__init_A_const_86.Ref(); var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(jrt.NN(A_arbace_test__init_A_const_34).GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_test__init_A_const_86; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_88)); var tmp4 *lang.Var = A_arbace_test__init_A_const_86; var tmp5 *jrt.String = Lit_316; var tmp6 any = A_arbace_test_eval196000154_fn__196000155_A_New(); var tmp7 *jrt.Class; A_arbace_test_eval196000154_fn__196000155_A_Init(); tmp7 = A_arbace_test_eval196000154_fn__196000155_A_fn_class; var tmp8 lang.IFn = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp6, tmp7, nil, 1); var tmp9 any = A_arbace_test__init_A_const_36.Ref(); jrt.NN(tmp4).BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp8, tmp9, Up_Var_IRef(A_arbace_test__init_A_const_37))); return A_arbace_test__init_A_const_86.Ref() } }






func A_arbace_test__init_A_Unit67__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(658, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_86).GetRawRoot__O()); var tmp2 any = A_arbace_test__init_A_const_89.Ref(); var tmp3 any = A_arbace_test_eval196000158_fn__196000159_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000158_fn__196000159_A_Init(); tmp4 = A_arbace_test_eval196000158_fn__196000159_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp3, tmp4, nil, 1)).Ref() }


func A_arbace_test__init_A_Unit68__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(661, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test__init_A_const_86).GetRawRoot__O()); var tmp2 any = A_arbace_test__init_A_const_90.Ref(); var tmp3 any = A_arbace_test_eval196000162_fn__196000163_A_New(); var tmp4 *jrt.Class; A_arbace_test_eval196000162_fn__196000163_A_Init(); tmp4 = A_arbace_test_eval196000162_fn__196000163_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp3, tmp4, nil, 1)).Ref() }


func A_arbace_test__init_A_Unit69__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(664, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_91; var tmp2 any = A_arbace_test_default_fixture_A_New(); var tmp3 *jrt.Class; A_arbace_test_default_fixture_A_Init(); tmp3 = A_arbace_test_default_fixture_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_91; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_92)); return A_arbace_test__init_A_const_91.Ref() }





func A_arbace_test__init_A_Unit70__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(670, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_93; var tmp2 any = A_arbace_test_compose_fixtures_A_New(); var tmp3 *jrt.Class; A_arbace_test_compose_fixtures_A_Init(); tmp3 = A_arbace_test_compose_fixtures_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_93; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_94)); return A_arbace_test__init_A_const_93.Ref() }






func A_arbace_test__init_A_Unit71__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(677, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_95; var tmp2 any = A_arbace_test_join_fixtures_A_New(); var tmp3 *jrt.Class; A_arbace_test_join_fixtures_A_Init(); tmp3 = A_arbace_test_join_fixtures_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_95; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_96)); return A_arbace_test__init_A_const_95.Ref() }








func A_arbace_test__init_A_Unit72__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(686, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_97; var tmp2 any = A_arbace_test_test_var_A_New(); var tmp3 *jrt.Class; A_arbace_test_test_var_A_Init(); tmp3 = A_arbace_test_test_var_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_97; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_98)); return jrt.NN(A_arbace_test__init_A_const_97).SetDynamic_Z__Var(true).Ref() }














func A_arbace_test__init_A_Unit73__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(701, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_99; var tmp2 any = A_arbace_test_test_vars_A_New(); var tmp3 *jrt.Class; A_arbace_test_test_vars_A_Init(); tmp3 = A_arbace_test_test_vars_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_99; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_100)); return A_arbace_test__init_A_const_99.Ref() }













func A_arbace_test__init_A_Unit74__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(715, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_101; var tmp2 any = A_arbace_test_test_all_vars_A_New(); var tmp3 *jrt.Class; A_arbace_test_test_all_vars_A_Init(); tmp3 = A_arbace_test_test_all_vars_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_101; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_102)); return A_arbace_test__init_A_const_101.Ref() }





func A_arbace_test__init_A_Unit75__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(721, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_103; var tmp2 any = A_arbace_test_test_ns_A_New(); var tmp3 *jrt.Class; A_arbace_test_test_ns_A_Init(); tmp3 = A_arbace_test_test_ns_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_103; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_104)); return A_arbace_test__init_A_const_103.Ref() }






















func A_arbace_test__init_A_Unit76__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(744, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_105; var tmp2 any = A_arbace_test_run_tests_A_New(); var tmp3 *jrt.Class; A_arbace_test_run_tests_A_Init(); tmp3 = A_arbace_test_run_tests_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_test__init_A_const_105; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_106)); return A_arbace_test__init_A_const_105.Ref() }











func A_arbace_test__init_A_Unit77__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(756, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_107; var tmp2 any = A_arbace_test_run_all_tests_A_New(); var tmp3 *jrt.Class; A_arbace_test_run_all_tests_A_Init(); tmp3 = A_arbace_test_run_all_tests_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_107; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_108)); return A_arbace_test__init_A_const_107.Ref() }








func A_arbace_test__init_A_Unit78__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(765, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_109; var tmp2 any = A_arbace_test_successful_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_test_successful_QMARK__A_Init(); tmp3 = A_arbace_test_successful_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_109; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_110)); return A_arbace_test__init_A_const_109.Ref() }







func A_arbace_test__init_A_Unit79__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(773, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_111; var tmp2 any = A_arbace_test_run_test_var_A_New(); var tmp3 *jrt.Class; A_arbace_test_run_test_var_A_Init(); tmp3 = A_arbace_test_run_test_var_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_111; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_112)); return A_arbace_test__init_A_const_111.Ref() }















func A_arbace_test__init_A_Unit80__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(789, 1); var tmp1 *lang.Var = A_arbace_test__init_A_const_113; var tmp2 any = A_arbace_test_run_test_A_New(); var tmp3 *jrt.Class; A_arbace_test_run_test_A_Init(); tmp3 = A_arbace_test_run_test_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test__init_A_const_113; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test__init_A_const_114)); return A_arbace_test__init_A_const_113.Ref() }
//line :789:1
func A_arbace_test__init_A_Unit81__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(789, 1); jrt.NN(A_arbace_test__init_A_const_113).SetMacro__V(); return nil }
//line :789:1
func A_arbace_test__init_A_Unit82__O() any { A_arbace_test__init_A_Init(); lang.Compiler_AOT_At_I_I__V(789, 1); return A_arbace_test__init_A_const_113.Ref() }







type A_arbace_test__init_A struct{ jrt.Object }

var A_arbace_test__init_A_const_0 *lang.Var

var A_arbace_test__init_A_const_1 any

var A_arbace_test__init_A_const_2 any

var A_arbace_test__init_A_const_3 any

var A_arbace_test__init_A_const_4 *lang.Var

var A_arbace_test__init_A_const_5 any

var A_arbace_test__init_A_const_6 any

var A_arbace_test__init_A_const_7 *lang.Var

var A_arbace_test__init_A_const_8 any

var A_arbace_test__init_A_const_9 *lang.Var

var A_arbace_test__init_A_const_10 any

var A_arbace_test__init_A_const_11 *lang.Var

var A_arbace_test__init_A_const_12 any

var A_arbace_test__init_A_const_13 any

var A_arbace_test__init_A_const_14 *lang.Var

var A_arbace_test__init_A_const_15 *lang.Var

var A_arbace_test__init_A_const_16 any

var A_arbace_test__init_A_const_17 *lang.Var

var A_arbace_test__init_A_const_18 any

var A_arbace_test__init_A_const_19 *lang.Var

var A_arbace_test__init_A_const_20 *lang.Var

var A_arbace_test__init_A_const_21 any

var A_arbace_test__init_A_const_22 *lang.Var

var A_arbace_test__init_A_const_23 any

var A_arbace_test__init_A_const_24 *lang.Var

var A_arbace_test__init_A_const_25 any

var A_arbace_test__init_A_const_26 *lang.Var

var A_arbace_test__init_A_const_27 any

var A_arbace_test__init_A_const_28 *lang.Var

var A_arbace_test__init_A_const_29 any

var A_arbace_test__init_A_const_30 *lang.Var

var A_arbace_test__init_A_const_31 any

var A_arbace_test__init_A_const_32 *lang.Var

var A_arbace_test__init_A_const_33 any

var A_arbace_test__init_A_const_34 *lang.Var

var A_arbace_test__init_A_const_35 *lang.Keyword

var A_arbace_test__init_A_const_36 *lang.Keyword

var A_arbace_test__init_A_const_37 *lang.Var

var A_arbace_test__init_A_const_38 any

var A_arbace_test__init_A_const_39 *lang.Var

var A_arbace_test__init_A_const_40 any

var A_arbace_test__init_A_const_41 *lang.Var

var A_arbace_test__init_A_const_42 any

var A_arbace_test__init_A_const_43 *lang.Var

var A_arbace_test__init_A_const_44 any

var A_arbace_test__init_A_const_45 *lang.Keyword

var A_arbace_test__init_A_const_46 *lang.Keyword

var A_arbace_test__init_A_const_47 *lang.Keyword

var A_arbace_test__init_A_const_48 *lang.Keyword

var A_arbace_test__init_A_const_49 *lang.Keyword

var A_arbace_test__init_A_const_50 *lang.Keyword

var A_arbace_test__init_A_const_51 *lang.Keyword

var A_arbace_test__init_A_const_52 *lang.Keyword

var A_arbace_test__init_A_const_53 *lang.Var

var A_arbace_test__init_A_const_54 any

var A_arbace_test__init_A_const_55 *lang.Var

var A_arbace_test__init_A_const_56 any

var A_arbace_test__init_A_const_57 *lang.Var

var A_arbace_test__init_A_const_58 any

var A_arbace_test__init_A_const_59 *lang.Var

var A_arbace_test__init_A_const_60 any

var A_arbace_test__init_A_const_61 *lang.Var

var A_arbace_test__init_A_const_62 any

var A_arbace_test__init_A_const_63 any

var A_arbace_test__init_A_const_64 *lang.Keyword

var A_arbace_test__init_A_const_65 any

var A_arbace_test__init_A_const_66 any

var A_arbace_test__init_A_const_67 any

var A_arbace_test__init_A_const_68 *lang.Var

var A_arbace_test__init_A_const_69 any

var A_arbace_test__init_A_const_70 *lang.Var

var A_arbace_test__init_A_const_71 any

var A_arbace_test__init_A_const_72 *lang.Var

var A_arbace_test__init_A_const_73 any

var A_arbace_test__init_A_const_74 *lang.Var

var A_arbace_test__init_A_const_75 any

var A_arbace_test__init_A_const_76 *lang.Var

var A_arbace_test__init_A_const_77 any

var A_arbace_test__init_A_const_78 *lang.Var

var A_arbace_test__init_A_const_79 any

var A_arbace_test__init_A_const_80 *lang.Var

var A_arbace_test__init_A_const_81 any

var A_arbace_test__init_A_const_82 *lang.Var

var A_arbace_test__init_A_const_83 any

var A_arbace_test__init_A_const_84 *lang.Var

var A_arbace_test__init_A_const_85 any

var A_arbace_test__init_A_const_86 *lang.Var

var A_arbace_test__init_A_const_87 any

var A_arbace_test__init_A_const_88 any

var A_arbace_test__init_A_const_89 *lang.Keyword

var A_arbace_test__init_A_const_90 *lang.Keyword

var A_arbace_test__init_A_const_91 *lang.Var

var A_arbace_test__init_A_const_92 any

var A_arbace_test__init_A_const_93 *lang.Var

var A_arbace_test__init_A_const_94 any

var A_arbace_test__init_A_const_95 *lang.Var

var A_arbace_test__init_A_const_96 any

var A_arbace_test__init_A_const_97 *lang.Var

var A_arbace_test__init_A_const_98 any

var A_arbace_test__init_A_const_99 *lang.Var

var A_arbace_test__init_A_const_100 any

var A_arbace_test__init_A_const_101 *lang.Var

var A_arbace_test__init_A_const_102 any

var A_arbace_test__init_A_const_103 *lang.Var

var A_arbace_test__init_A_const_104 any

var A_arbace_test__init_A_const_105 *lang.Var

var A_arbace_test__init_A_const_106 any

var A_arbace_test__init_A_const_107 *lang.Var

var A_arbace_test__init_A_const_108 any

var A_arbace_test__init_A_const_109 *lang.Var

var A_arbace_test__init_A_const_110 any

var A_arbace_test__init_A_const_111 *lang.Var

var A_arbace_test__init_A_const_112 any

var A_arbace_test__init_A_const_113 *lang.Var

var A_arbace_test__init_A_const_114 any

var A_arbace_test__init_A_init jrt.ClassInit

func A_arbace_test__init_A_Init() { if !A_arbace_test__init_A_init.Done() { A_arbace_test__init_A_init.Run(A_arbace_test__init_A_clinit) } }

func A_arbace_test__init_A_clinit() { A_arbace_test__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_252); A_arbace_test__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17))); A_arbace_test__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_test__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_test__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_13, Lit_115); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(); var tmp2 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(); var tmp3 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_256).Ref(); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; var tmp5 any = tmp4.Ref(); A_arbace_test__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, Lit_253, tmp2, Lit_255, tmp3, tmp5, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(240).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); var tmp6 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(); var tmp8 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_256).Ref(); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_TRUE; var tmp10 any = tmp9.Ref(); A_arbace_test__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, Lit_253, tmp7, Lit_255, tmp8, tmp10, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(240).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_13, Lit_65); var tmp11 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(); var tmp12 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_256).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_test__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp11, Lit_259, tmp12, Lit_255, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(247).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_13, Lit_38); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_256).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_test__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(256).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_13, Lit_145); A_arbace_test__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_66).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_56).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_46).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_44).Ref(), jrt.Long_ValueOf_J__Long(0).Ref())); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_256).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_test__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(258).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_13, Lit_35); A_arbace_test__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_256).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_test__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(261).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_13, Lit_37); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_256).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_test__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(263).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_13, Lit_26); A_arbace_test__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_256).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_test__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(265).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_13, Lit_260); A_arbace_test__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_262).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_263).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_264, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(267).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_13, Lit_265); A_arbace_test__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_266).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_267, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), Lit_269, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(276).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_13, Lit_59); A_arbace_test__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_270).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_271, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(288).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_13, Lit_60); A_arbace_test__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_272, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(301).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_13, Lit_55); A_arbace_test__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_273, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(308).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_13, Lit_42); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(); var tmp32 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_256).Ref(); var tmp33 *jrt.Boolean; jrt.Boolean_Init(); tmp33 = jrt.Boolean_TRUE; var tmp34 any = tmp33.Ref(); A_arbace_test__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, Lit_274, tmp32, tmp34, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(318).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_test__init_A_const_35 = lang.RT_Keyword_String_String__Keyword(nil, Lit_43); A_arbace_test__init_A_const_36 = lang.RT_Keyword_String_String__Keyword(nil, Lit_88); A_arbace_test__init_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_275); var tmp35 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(); var tmp36 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_256).Ref(); var tmp37 *jrt.Boolean; jrt.Boolean_Init(); tmp37 = jrt.Boolean_TRUE; var tmp38 any = tmp37.Ref(); A_arbace_test__init_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp35, Lit_274, tmp36, tmp38, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(318).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_39 = lang.RT_Var_String_String__Var(Lit_13, Lit_276); var tmp39 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(); var tmp40 *jrt.Boolean; jrt.Boolean_Init(); tmp40 = jrt.Boolean_TRUE; var tmp41 any = tmp40.Ref(); A_arbace_test__init_A_const_40 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp39, tmp41, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_277)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_278).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_279).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_280).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), Lit_281, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(329).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_13, Lit_47); var tmp42 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(); var tmp43 *jrt.Boolean; jrt.Boolean_Init(); tmp43 = jrt.Boolean_TRUE; var tmp44 any = tmp43.Ref(); A_arbace_test__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp42, tmp44, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_282).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(338).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_13, Lit_81); A_arbace_test__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_270).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_283, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_269, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(345).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_45 = lang.RT_Keyword_String_String__Keyword(nil, Lit_56); A_arbace_test__init_A_const_46 = lang.RT_Keyword_String_String__Keyword(nil, Lit_46); A_arbace_test__init_A_const_47 = lang.RT_Keyword_String_String__Keyword(nil, Lit_44); A_arbace_test__init_A_const_48 = lang.RT_Keyword_String_String__Keyword(nil, Lit_152); A_arbace_test__init_A_const_49 = lang.RT_Keyword_String_String__Keyword(nil, Lit_149); A_arbace_test__init_A_const_50 = lang.RT_Keyword_String_String__Keyword(nil, Lit_151); A_arbace_test__init_A_const_51 = lang.RT_Keyword_String_String__Keyword(nil, Lit_132); A_arbace_test__init_A_const_52 = lang.RT_Keyword_String_String__Keyword(nil, Lit_133); A_arbace_test__init_A_const_53 = lang.RT_Var_String_String__Var(Lit_13, Lit_72); A_arbace_test__init_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_284).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_285, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(408).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_55 = lang.RT_Var_String_String__Var(Lit_13, Lit_90); A_arbace_test__init_A_const_56 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_286).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_287, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(416).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_57 = lang.RT_Var_String_String__Var(Lit_13, Lit_91); A_arbace_test__init_A_const_58 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_288).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_290, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(428).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_59 = lang.RT_Var_String_String__Var(Lit_13, Lit_92); A_arbace_test__init_A_const_60 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_288).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_291, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(447).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_61 = lang.RT_Var_String_String__Var(Lit_13, Lit_107); A_arbace_test__init_A_const_62 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(466).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_63 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(466).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_64 = lang.RT_Keyword_String_String__Keyword(nil, Lit_85); A_arbace_test__init_A_const_65 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_96).Ref(); A_arbace_test__init_A_const_66 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_292).Ref(); A_arbace_test__init_A_const_67 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_293).Ref(); A_arbace_test__init_A_const_68 = lang.RT_Var_String_String__Var(Lit_13, Lit_110); A_arbace_test__init_A_const_69 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_288).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_294, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(527).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_70 = lang.RT_Var_String_String__Var(Lit_13, Lit_111); A_arbace_test__init_A_const_71 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_288).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_295, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(541).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_72 = lang.RT_Var_String_String__Var(Lit_13, Lit_296); A_arbace_test__init_A_const_73 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_297).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_298).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_262).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_299).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_300, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(559).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_74 = lang.RT_Var_String_String__Var(Lit_13, Lit_301); A_arbace_test__init_A_const_75 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_302).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_262).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_263).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_303, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(584).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_76 = lang.RT_Var_String_String__Var(Lit_13, Lit_304); A_arbace_test__init_A_const_77 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_305).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_262).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_263).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_306, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(594).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_78 = lang.RT_Var_String_String__Var(Lit_13, Lit_307); A_arbace_test__init_A_const_79 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_262).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_263).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_308, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(606).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_80 = lang.RT_Var_String_String__Var(Lit_13, Lit_309); A_arbace_test__init_A_const_81 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_262).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_263).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_310, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(623).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_82 = lang.RT_Var_String_String__Var(Lit_13, Lit_311); A_arbace_test__init_A_const_83 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_262).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_263).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_312, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(631).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_84 = lang.RT_Var_String_String__Var(Lit_13, Lit_126); var tmp45 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(); var tmp46 *jrt.Boolean; jrt.Boolean_Init(); tmp46 = jrt.Boolean_TRUE; var tmp47 any = tmp46.Ref(); A_arbace_test__init_A_const_85 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp45, tmp47, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_313).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_314).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_315, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(644).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_86 = lang.RT_Var_String_String__Var(Lit_13, Lit_316); A_arbace_test__init_A_const_87 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_317, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(651).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_88 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_317, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(651).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_89 = lang.RT_Keyword_String_String__Keyword(nil, Lit_318); A_arbace_test__init_A_const_90 = lang.RT_Keyword_String_String__Keyword(nil, Lit_319); A_arbace_test__init_A_const_91 = lang.RT_Var_String_String__Var(Lit_13, Lit_131); var tmp48 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(); var tmp49 *jrt.Boolean; jrt.Boolean_Init(); tmp49 = jrt.Boolean_TRUE; var tmp50 any = tmp49.Ref(); A_arbace_test__init_A_const_92 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp48, tmp50, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_320).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_321, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(664).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_93 = lang.RT_Var_String_String__Var(Lit_13, Lit_130); A_arbace_test__init_A_const_94 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_322).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_323).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_324, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(670).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_95 = lang.RT_Var_String_String__Var(Lit_13, Lit_139); A_arbace_test__init_A_const_96 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_325).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_326, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(677).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_97 = lang.RT_Var_String_String__Var(Lit_13, Lit_122); var tmp51 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(); var tmp52 any = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_284).Ref())))); var tmp53 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(); var tmp54 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_256).Ref(); var tmp55 *jrt.Boolean; jrt.Boolean_Init(); tmp55 = jrt.Boolean_TRUE; var tmp56 any = tmp55.Ref(); A_arbace_test__init_A_const_98 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp51, tmp52, tmp53, Lit_327, tmp54, tmp56, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(686).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_99 = lang.RT_Var_String_String__Var(Lit_13, Lit_141); A_arbace_test__init_A_const_100 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_328).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_329, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_330, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(701).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_101 = lang.RT_Var_String_String__Var(Lit_13, Lit_148); A_arbace_test__init_A_const_102 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_331, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(715).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_103 = lang.RT_Var_String_String__Var(Lit_13, Lit_155); A_arbace_test__init_A_const_104 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_332, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(721).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_105 = lang.RT_Var_String_String__Var(Lit_13, Lit_156); A_arbace_test__init_A_const_106 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector(), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_262).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_333).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_334, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(744).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_107 = lang.RT_Var_String_String__Var(Lit_13, Lit_335); A_arbace_test__init_A_const_108 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_336).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_337, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(756).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_109 = lang.RT_Var_String_String__Var(Lit_13, Lit_338); A_arbace_test__init_A_const_110 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_152).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_339, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(765).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_111 = lang.RT_Var_String_String__Var(Lit_13, Lit_161); A_arbace_test__init_A_const_112 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_284).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_340, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_341, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(773).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)); A_arbace_test__init_A_const_113 = lang.RT_Var_String_String__Var(Lit_13, Lit_342); A_arbace_test__init_A_const_114 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_261).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_343).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_344, lang.RT_Keyword_String_String__Keyword(nil, Lit_254).Ref(), Lit_341, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), jrt.Integer_ValueOf_I__Integer(789).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_257).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), Lit_258)) }

func A_arbace_test__init_A_New() *A_arbace_test__init_A { A_arbace_test__init_A_Init(); t := &A_arbace_test__init_A{}; t.Ctor(); return t }

func (t *A_arbace_test__init_A) Ctor() {}

func (t *A_arbace_test__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test__init_A) GetClass__Class() *jrt.Class { return A_arbace_test__init_A_class }

func (t *A_arbace_test__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test__init_A); return ok }

func A_arbace_test__init_A_Cast(x any) *A_arbace_test__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test__init_A_class)) }; return v }
