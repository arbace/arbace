//line a2g_strings.ae:1
package aot_arbace_test

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.template")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("temp")

var Lit_6 *jrt.String = jrt.Intern("arbace.stacktrace")

var Lit_7 *jrt.String = jrt.Intern("stack")

var Lit_8 *jrt.String = jrt.Intern("arbace.string")

var Lit_9 *jrt.String = jrt.Intern("str")

var Lit_10 *jrt.String = jrt.Intern("commute")

var Lit_11 *jrt.String = jrt.Intern("deref")

var Lit_12 *jrt.String = jrt.Intern("conj")

var Lit_13 *jrt.String = jrt.Intern("arbace.test")

var Lit_14 *jrt.String = jrt.Intern("author")

var Lit_15 *jrt.String = jrt.Intern("Stuart Sierra, with contributions and suggestions by\n  Chas Emerick, Allen Rohner, and Stuart Halloway")

var Lit_16 *jrt.String = jrt.Intern("doc")

var Lit_17 *jrt.String = jrt.Intern("A unit testing framework.\n\n   ASSERTIONS\n\n   The core of the library is the \"is\" macro, which lets you make\n   assertions of any arbitrary expression:\n\n   (is (= 4 (+ 2 2)))\n   (is (instance? Integer 256))\n   (is (.startsWith \"abcde\" \"ab\"))\n\n   You can type an \"is\" expression directly at the REPL, which will\n   print a message if it fails.\n\n       user> (is (= 5 (+ 2 2)))\n\n       FAIL in  (:1)\n       expected: (= 5 (+ 2 2))\n         actual: (not (= 5 4))\n       false\n\n   The \"expected:\" line shows you the original expression, and the\n   \"actual:\" shows you what actually happened.  In this case, it\n   shows that (+ 2 2) returned 4, which is not = to 5.  Finally, the\n   \"false\" on the last line is the value returned from the\n   expression.  The \"is\" macro always returns the result of the\n   inner expression.\n\n   There are two special assertions for testing exceptions.  The\n   \"(is (thrown? c ...))\" form tests if an exception of class c is\n   thrown:\n\n   (is (thrown? ArithmeticException (/ 1 0)))\n\n   \"(is (thrown-with-msg? c re ...))\" does the same thing and also\n   tests that the message on the exception matches the regular\n   expression re:\n\n   (is (thrown-with-msg? ArithmeticException #\"Divide by zero\"\n                         (/ 1 0)))\n\n   DOCUMENTING TESTS\n\n   \"is\" takes an optional second argument, a string describing the\n   assertion.  This message will be included in the error report.\n\n   (is (= 5 (+ 2 2)) \"Crazy arithmetic\")\n\n   In addition, you can document groups of assertions with the\n   \"testing\" macro, which takes a string followed by any number of\n   assertions.  The string will be included in failure reports.\n   Calls to \"testing\" may be nested, and all of the strings will be\n   joined together with spaces in the final report, in a style\n   similar to RSpec <http://rspec.info/>\n\n   (testing \"Arithmetic\"\n     (testing \"with positive integers\"\n       (is (= 4 (+ 2 2)))\n       (is (= 7 (+ 3 4))))\n     (testing \"with negative integers\"\n       (is (= -4 (+ -2 -2)))\n       (is (= -1 (+ 3 -4)))))\n\n   Note that, unlike RSpec, the \"testing\" macro may only be used\n   INSIDE a \"deftest\" or \"with-test\" form (see below).\n\n   DEFINING TESTS\n\n   There are two ways to define tests.  The \"with-test\" macro takes\n   a defn or def form as its first argument, followed by any number\n   of assertions.  The tests will be stored as metadata on the\n   definition.\n\n   (with-test\n       (defn my-function [x y]\n         (+ x y))\n     (is (= 4 (my-function 2 2)))\n     (is (= 7 (my-function 3 4))))\n\n   As of Clojure SVN rev. 1221, this does not work with defmacro.\n   See http://code.google.com/p/clojure/issues/detail?id=51\n\n   The other way lets you define tests separately from the rest of\n   your code, even in a different namespace:\n\n   (deftest addition\n     (is (= 4 (+ 2 2)))\n     (is (= 7 (+ 3 4))))\n\n   (deftest subtraction\n     (is (= 1 (- 4 3)))\n     (is (= 3 (- 7 4))))\n\n   This creates functions named \"addition\" and \"subtraction\", which\n   can be called like any other function.  Therefore, tests can be\n   grouped and composed, in a style similar to the test framework in\n   Peter Seibel's \"Practical Common Lisp\"\n   <http://www.gigamonkeys.com/book/practical-building-a-unit-test-framework.html>\n\n   (deftest arithmetic\n     (addition)\n     (subtraction))\n\n   The names of the nested tests will be joined in a list, like\n   \"(arithmetic addition)\", in failure reports.  You can use nested\n   tests to set up a context shared by several tests.\n\n   RUNNING TESTS\n\n   Run tests with the function \"(run-tests namespaces...)\":\n\n   (run-tests 'your.namespace 'some.other.namespace)\n\n   If you don't specify any namespaces, the current namespace is\n   used.  To run all tests in all namespaces, use \"(run-all-tests)\".\n\n   By default, these functions will search for all tests defined in\n   a namespace and run them in an undefined order.  However, if you\n   are composing tests, as in the \"arithmetic\" example above, you\n   probably do not want the \"addition\" and \"subtraction\" tests run\n   separately.  In that case, you must define a special function\n   named \"test-ns-hook\" that runs your tests in the correct order:\n\n   (defn test-ns-hook []\n     (arithmetic))\n\n   Note: test-ns-hook prevents execution of fixtures (see below).\n\n   OMITTING TESTS FROM PRODUCTION CODE\n\n   You can bind the variable \"*load-tests*\" to false when loading or\n   compiling code in production.  This will prevent any tests from\n   being created by \"with-test\" or \"deftest\".\n\n   FIXTURES\n\n   Fixtures allow you to run code before and after tests, to set up\n   the context in which tests should be run.\n\n   A fixture is just a function that calls another function passed as\n   an argument.  It looks like this:\n\n   (defn my-fixture [f]\n      Perform setup, establish bindings, whatever.\n     (f)  Then call the function we were passed.\n      Tear-down / clean-up code here.\n    )\n\n   Fixtures are attached to namespaces in one of two ways.  \"each\"\n   fixtures are run repeatedly, once for each test function created\n   with \"deftest\" or \"with-test\".  \"each\" fixtures are useful for\n   establishing a consistent before/after state for each test, like\n   clearing out database tables.\n\n   \"each\" fixtures can be attached to the current namespace like this:\n   (use-fixtures :each fixture1 fixture2 ...)\n   The fixture1, fixture2 are just functions like the example above.\n   They can also be anonymous functions, like this:\n   (use-fixtures :each (fn [f] setup... (f) cleanup...))\n\n   The other kind of fixture, a \"once\" fixture, is only run once,\n   around ALL the tests in the namespace.  \"once\" fixtures are useful\n   for tasks that only need to be performed once, like establishing\n   database connections, or for time-consuming tasks.\n\n   Attach \"once\" fixtures to the current namespace like this:\n   (use-fixtures :once fixture1 fixture2 ...)\n\n   Note: Fixtures and test-ns-hook are mutually incompatible.  If you\n   are using test-ns-hook, fixture functions will *never* be run.\n\n   SAVING TEST OUTPUT TO A FILE\n\n   All the test reporting functions write to the var *test-out*.  By\n   default, this is the same as *out*, but you can rebind it to any\n   PrintWriter.  For example, it could be a file opened with\n   arbace.java.io/writer.\n\n   EXTENDING TEST-IS (ADVANCED)\n\n   You can extend the behavior of the \"is\" macro by defining new\n   methods for the \"assert-expr\" multimethod.  These methods are\n   called during expansion of the \"is\" macro, so they should return\n   quoted forms to be evaluated.\n\n   You can plug in your own test-reporting framework by rebinding\n   the \"report\" function: (report event)\n\n   The 'event' argument is a map.  It will always have a :type key,\n   whose value will be a keyword signaling the type of event being\n   reported.  Standard events with :type value of :pass, :fail, and\n   :error are called when an assertion passes, fails, and throws an\n   exception, respectively.  In that case, the event will also have\n   the following keys:\n\n     :expected   The form that was expected to be true\n     :actual     A form representing what actually occurred\n     :message    The string message given as an argument to 'is'\n\n   The \"testing\" strings will be a list in \"*testing-contexts*\", and\n   the vars being tested will be a list in \"*testing-vars*\".\n\n   Your \"report\" function should wrap any printing calls in the\n   \"with-test-out\" macro, which rebinds *out* to the current value\n   of *test-out*.\n\n   The event types are:\n   :default :pass :fail :error :summary :begin-test-ns :end-test-ns\n   :begin-test-var :end-test-var\n")

var Lit_18 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_19 *jrt.String = jrt.Intern("seq")

var Lit_20 *jrt.String = jrt.Intern("concat")

var Lit_21 *jrt.String = jrt.Intern("list")

var Lit_22 *jrt.String = jrt.Intern("binding")

var Lit_23 *jrt.String = jrt.Intern("apply")

var Lit_24 *jrt.String = jrt.Intern("vector")

var Lit_25 *jrt.String = jrt.Intern("*out*")

var Lit_26 *jrt.String = jrt.Intern("*test-out*")

var Lit_27 *jrt.String = jrt.Intern("next")

var Lit_28 *jrt.String = jrt.Intern("to-array")

var Lit_29 *jrt.String = jrt.Intern("first")

var Lit_30 *jrt.String = jrt.Intern("file")

var Lit_31 *jrt.String = jrt.Intern("line")

var Lit_32 *jrt.String = jrt.Intern("reverse")

var Lit_33 *jrt.String = jrt.Intern("map")

var Lit_34 *jrt.String = jrt.Intern("name")

var Lit_35 *jrt.String = jrt.Intern("*testing-vars*")

var Lit_36 *jrt.String = jrt.Intern("interpose")

var Lit_37 *jrt.String = jrt.Intern("*testing-contexts*")

var Lit_38 *jrt.String = jrt.Intern("*report-counters*")

var Lit_39 *jrt.String = jrt.Intern("update-in")

var Lit_40 *jrt.String = jrt.Intern("fnil")

var Lit_41 *jrt.String = jrt.Intern("inc")

var Lit_42 *jrt.String = jrt.Intern("report")

var Lit_43 *jrt.String = jrt.Intern("type")

var Lit_44 *jrt.String = jrt.Intern("error")

var Lit_45 *jrt.String = jrt.Intern("merge")

var Lit_46 *jrt.String = jrt.Intern("fail")

var Lit_47 *jrt.String = jrt.Intern("stacktrace-file-and-line")

var Lit_48 *jrt.String = jrt.Intern("actual")

var Lit_49 *jrt.String = jrt.Intern("drop-while")

var Lit_50 *jrt.String = jrt.Intern("starts-with?")

var Lit_51 *jrt.String = jrt.Intern("prn")

var Lit_52 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_53 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_54 *jrt.String = jrt.Intern("hash-map")

var Lit_55 *jrt.String = jrt.Intern("inc-report-counter")

var Lit_56 *jrt.String = jrt.Intern("pass")

var Lit_57 *jrt.String = jrt.Intern("println")

var Lit_58 *jrt.String = jrt.Intern("message")

var Lit_59 *jrt.String = jrt.Intern("testing-vars-str")

var Lit_60 *jrt.String = jrt.Intern("testing-contexts-str")

var Lit_61 *jrt.String = jrt.Intern("pr-str")

var Lit_62 *jrt.String = jrt.Intern("expected")

var Lit_63 *jrt.String = jrt.Intern("print-cause-trace")

var Lit_64 *jrt.String = jrt.Intern("print")

var Lit_65 *jrt.String = jrt.Intern("*stack-trace-depth*")

var Lit_66 *jrt.String = jrt.Intern("test")

var Lit_67 *jrt.String = jrt.Intern("ns-name")

var Lit_68 *jrt.String = jrt.Intern("ns")

var Lit_69 *jrt.String = jrt.Intern("var-get")

var Lit_70 *jrt.String = jrt.Intern("symbol?")

var Lit_71 *jrt.String = jrt.Intern("resolve")

var Lit_72 *jrt.String = jrt.Intern("get-possibly-unbound-var")

var Lit_73 *jrt.String = jrt.Intern("fn?")

var Lit_74 *jrt.String = jrt.Intern("not")

var Lit_75 *jrt.String = jrt.Intern("macro")

var Lit_76 *jrt.String = jrt.Intern("rest")

var Lit_77 *jrt.String = jrt.Intern("let")

var Lit_78 *jrt.String = jrt.Intern("values__196000077__auto__")

var Lit_79 *jrt.String = jrt.Intern("result__196000078__auto__")

var Lit_80 *jrt.String = jrt.Intern("if")

var Lit_81 *jrt.String = jrt.Intern("do-report")

var Lit_82 *jrt.String = jrt.Intern("quote")

var Lit_83 *jrt.String = jrt.Intern("cons")

var Lit_84 *jrt.String = jrt.Intern("value__196000080__auto__")

var Lit_85 *jrt.String = jrt.Intern("always-fail")

var Lit_86 *jrt.String = jrt.Intern("seq?")

var Lit_87 *jrt.String = jrt.Intern("else")

var Lit_88 *jrt.String = jrt.Intern("default")

var Lit_89 *jrt.String = jrt.Intern("sequential?")

var Lit_90 *jrt.String = jrt.Intern("function?")

var Lit_91 *jrt.String = jrt.Intern("assert-predicate")

var Lit_92 *jrt.String = jrt.Intern("assert-any")

var Lit_93 *jrt.String = jrt.Intern("klass__196000094__auto__")

var Lit_94 *jrt.String = jrt.Intern("object__196000095__auto__")

var Lit_95 *jrt.String = jrt.Intern("result__196000096__auto__")

var Lit_96 *jrt.String = jrt.Intern("instance?")

var Lit_97 *jrt.String = jrt.Intern("class")

var Lit_98 *jrt.String = jrt.Intern("second")

var Lit_99 *jrt.String = jrt.Intern("nthnext")

var Lit_100 *jrt.String = jrt.Intern("try")

var Lit_101 *jrt.String = jrt.Intern("catch")

var Lit_102 *jrt.String = jrt.Intern("e__196000101__auto__")

var Lit_103 *jrt.String = jrt.Intern("e__196000106__auto__")

var Lit_104 *jrt.String = jrt.Intern("m__196000107__auto__")

var Lit_105 *jrt.String = jrt.Intern(".getMessage")

var Lit_106 *jrt.String = jrt.Intern("re-find")

var Lit_107 *jrt.String = jrt.Intern("assert-expr")

var Lit_108 *jrt.String = jrt.Intern("java.lang.Throwable")

var Lit_109 *jrt.String = jrt.Intern("t__196000112__auto__")

var Lit_110 *jrt.String = jrt.Intern("try-expr")

var Lit_111 *jrt.String = jrt.Intern("is")

var Lit_112 *jrt.String = jrt.Intern("empty?")

var Lit_113 *jrt.String = jrt.Intern("mod")

var Lit_114 *jrt.String = jrt.Intern("do-template")

var Lit_115 *jrt.String = jrt.Intern("*load-tests*")

var Lit_116 *jrt.String = jrt.Intern("doto")

var Lit_117 *jrt.String = jrt.Intern("alter-meta!")

var Lit_118 *jrt.String = jrt.Intern("assoc")

var Lit_119 *jrt.String = jrt.Intern("fn")

var Lit_120 *jrt.String = jrt.Intern("def")

var Lit_121 *jrt.String = jrt.Intern("vary-meta")

var Lit_122 *jrt.String = jrt.Intern("test-var")

var Lit_123 *jrt.String = jrt.Intern("var")

var Lit_124 *jrt.String = jrt.Intern("private")

var Lit_125 *jrt.String = jrt.Intern("*ns*")

var Lit_126 *jrt.String = jrt.Intern("add-ns-meta")

var Lit_127 *jrt.String = jrt.Intern("each-fixtures")

var Lit_128 *jrt.String = jrt.Intern("once-fixtures")

var Lit_129 *jrt.String = jrt.Intern("reduce")

var Lit_130 *jrt.String = jrt.Intern("compose-fixtures")

var Lit_131 *jrt.String = jrt.Intern("default-fixture")

var Lit_132 *jrt.String = jrt.Intern("begin-test-var")

var Lit_133 *jrt.String = jrt.Intern("end-test-var")

var Lit_134 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_135 *jrt.String = jrt.Intern("chunk-first")

var Lit_136 *jrt.String = jrt.Intern("group-by")

var Lit_137 *jrt.String = jrt.Intern("comp")

var Lit_138 *jrt.String = jrt.Intern("meta")

var Lit_139 *jrt.String = jrt.Intern("join-fixtures")

var Lit_140 *jrt.String = jrt.Intern("chunk-rest")

var Lit_141 *jrt.String = jrt.Intern("test-vars")

var Lit_142 *jrt.String = jrt.Intern("vals")

var Lit_143 *jrt.String = jrt.Intern("ns-interns")

var Lit_144 *jrt.String = jrt.Intern("ref")

var Lit_145 *jrt.String = jrt.Intern("*initial-report-counters*")

var Lit_146 *jrt.String = jrt.Intern("the-ns")

var Lit_147 *jrt.String = jrt.Intern("find-var")

var Lit_148 *jrt.String = jrt.Intern("test-all-vars")

var Lit_149 *jrt.String = jrt.Intern("begin-test-ns")

var Lit_150 *jrt.String = jrt.Intern("symbol")

var Lit_151 *jrt.String = jrt.Intern("end-test-ns")

var Lit_152 *jrt.String = jrt.Intern("summary")

var Lit_153 *jrt.String = jrt.Intern("merge-with")

var Lit_154 *jrt.String = jrt.Intern("+")

var Lit_155 *jrt.String = jrt.Intern("test-ns")

var Lit_156 *jrt.String = jrt.Intern("run-tests")

var Lit_157 *jrt.String = jrt.Intern("filter")

var Lit_158 *jrt.String = jrt.Intern("re-matches")

var Lit_159 *jrt.String = jrt.Intern("all-ns")

var Lit_160 *jrt.String = jrt.Intern("*err*")

var Lit_161 *jrt.String = jrt.Intern("run-test-var")

var Lit_162 *jrt.String = jrt.Intern("arbace.test$add_ns_meta")

var Lit_163 *jrt.String = jrt.Intern("arbace.test$are")

var Lit_164 *jrt.String = jrt.Intern("The number of args doesn't match are's argv.")

var Lit_165 *jrt.String = jrt.Intern("arbace.test$assert_any")

var Lit_166 *jrt.String = jrt.Intern("arbace.test$assert_predicate")

var Lit_167 *jrt.String = jrt.Intern("arbace.test$compose_fixtures")

var Lit_168 *jrt.String = jrt.Intern("arbace.test$compose_fixtures$fn__196000167")

var Lit_169 *jrt.String = jrt.Intern("arbace.test$compose_fixtures$fn__196000167$fn__196000168")

var Lit_170 *jrt.String = jrt.Intern("arbace.test$default_fixture")

var Lit_171 *jrt.String = jrt.Intern("arbace.test$deftest")

var Lit_172 *jrt.String = jrt.Intern("arbace.test$deftest_")

var Lit_173 *jrt.String = jrt.Intern("arbace.test$do_report")

var Lit_174 *jrt.String = jrt.Intern("arbace.test$do_report$fn__196000036")

var Lit_175 *jrt.String = jrt.Intern("java.lang.")

var Lit_176 *jrt.String = jrt.Intern("arbace.test$")

var Lit_177 *jrt.String = jrt.Intern("arbace.core$ex_info")

var Lit_178 *jrt.String = jrt.Intern("arbace.test$eval196000004$loading__1927001464__auto____196000005")

var Lit_179 *jrt.String = jrt.Intern("arbace.test$eval196000008$fn__196000009")

var Lit_180 *jrt.String = jrt.Intern("arbace.test$eval196000039$fn__196000040")

var Lit_181 *jrt.String = jrt.Intern("arbace.test$eval196000043$fn__196000044")

var Lit_182 *jrt.String = jrt.Intern("arbace.test$eval196000047$fn__196000048")

var Lit_183 *jrt.String = jrt.Intern("\nFAIL in")

var Lit_184 *jrt.String = jrt.Intern("expected:")

var Lit_185 *jrt.String = jrt.Intern("  actual:")

var Lit_186 *jrt.String = jrt.Intern("arbace.test$eval196000051$fn__196000052")

var Lit_187 *jrt.String = jrt.Intern("\nERROR in")

var Lit_188 *jrt.String = jrt.Intern("  actual: ")

var Lit_189 *jrt.String = jrt.Intern("arbace.test$eval196000055$fn__196000056")

var Lit_190 *jrt.String = jrt.Intern("\nRan")

var Lit_191 *jrt.String = jrt.Intern("tests containing")

var Lit_192 *jrt.String = jrt.Intern("assertions.")

var Lit_193 *jrt.String = jrt.Intern("failures,")

var Lit_194 *jrt.String = jrt.Intern("errors.")

var Lit_195 *jrt.String = jrt.Intern("arbace.test$eval196000059$fn__196000060")

var Lit_196 *jrt.String = jrt.Intern("\nTesting")

var Lit_197 *jrt.String = jrt.Intern("arbace.test$eval196000063$fn__196000064")

var Lit_198 *jrt.String = jrt.Intern("arbace.test$eval196000067$fn__196000068")

var Lit_199 *jrt.String = jrt.Intern("arbace.test$eval196000071$fn__196000072")

var Lit_200 *jrt.String = jrt.Intern("arbace.test$eval196000082$fn__196000083")

var Lit_201 *jrt.String = jrt.Intern("arbace.test$eval196000086$fn__196000087")

var Lit_202 *jrt.String = jrt.Intern("arbace.test$eval196000090$fn__196000091")

var Lit_203 *jrt.String = jrt.Intern("arbace.test$eval196000097$fn__196000098")

var Lit_204 *jrt.String = jrt.Intern("arbace.test$eval196000102$fn__196000103")

var Lit_205 *jrt.String = jrt.Intern("arbace.test$eval196000108$fn__196000109")

var Lit_206 *jrt.String = jrt.Intern("arbace.test$eval196000154$fn__196000155")

var Lit_207 *jrt.String = jrt.Intern("arbace.test$eval196000158$fn__196000159")

var Lit_208 *jrt.String = jrt.Intern("arbace.test$eval196000162$fn__196000163")

var Lit_209 *jrt.String = jrt.Intern("arbace.test$file_and_line")

var Lit_210 *jrt.String = jrt.Intern("arbace.test$file_position")

var Lit_211 *jrt.String = jrt.Intern("arbace.test$function_QMARK_")

var Lit_212 *jrt.String = jrt.Intern("arbace.test$get_possibly_unbound_var")

var Lit_213 *jrt.String = jrt.Intern("arbace.test$inc_report_counter")

var Lit_214 *jrt.String = jrt.Intern("arbace.test$inc_report_counter$fn__196000027")

var Lit_215 *jrt.String = jrt.Intern("arbace.test$is")

var Lit_216 *jrt.String = jrt.Intern("arbace.test$join_fixtures")

var Lit_217 *jrt.String = jrt.Intern("arbace.test$run_all_tests")

var Lit_218 *jrt.String = jrt.Intern("arbace.test$run_all_tests$fn__196000211")

var Lit_219 *jrt.String = jrt.Intern("arbace.test$run_test")

var Lit_220 *jrt.String = jrt.Intern("Unable to resolve")

var Lit_221 *jrt.String = jrt.Intern("to a test function.")

var Lit_222 *jrt.String = jrt.Intern("is not a test.")

var Lit_223 *jrt.String = jrt.Intern("arbace.test$run_test_var")

var Lit_224 *jrt.String = jrt.Intern("arbace.test$run_tests")

var Lit_225 *jrt.String = jrt.Intern("arbace.test$set_test")

var Lit_226 *jrt.String = jrt.Intern("arbace.test$stacktrace_file_and_line")

var Lit_227 *jrt.String = jrt.Intern("arbace.test$successful_QMARK_")

var Lit_228 *jrt.String = jrt.Intern("arbace.test$test_all_vars")

var Lit_229 *jrt.String = jrt.Intern("arbace.test$test_ns")

var Lit_230 *jrt.String = jrt.Intern("test-ns-hook")

var Lit_231 *jrt.String = jrt.Intern("arbace.test$test_var")

var Lit_232 *jrt.String = jrt.Intern("arbace.test$test_var$fn__196000173")

var Lit_233 *jrt.String = jrt.Intern("Uncaught exception, not in assertion.")

var Lit_234 *jrt.String = jrt.Intern("arbace.test$test_vars")

var Lit_235 *jrt.String = jrt.Intern("arbace.test$test_vars$fn__196000183")

var Lit_236 *jrt.String = jrt.Intern("arbace.test$test_vars$fn__196000183$fn__196000188")

var Lit_237 *jrt.String = jrt.Intern("arbace.test$test_vars$fn__196000183$fn__196000190")

var Lit_238 *jrt.String = jrt.Intern("arbace.test$test_vars$fn__196000196")

var Lit_239 *jrt.String = jrt.Intern("arbace.test$test_vars$fn__196000196$fn__196000201")

var Lit_240 *jrt.String = jrt.Intern("arbace.test$test_vars$fn__196000196$fn__196000203")

var Lit_241 *jrt.String = jrt.Intern("arbace.test$testing")

var Lit_242 *jrt.String = jrt.Intern("arbace.test$testing_contexts_str")

var Lit_243 *jrt.String = jrt.Intern(" ")

var Lit_244 *jrt.String = jrt.Intern("arbace.test$testing_vars_str")

var Lit_245 *jrt.String = jrt.Intern(" (")

var Lit_246 *jrt.String = jrt.Intern(":")

var Lit_247 *jrt.String = jrt.Intern(")")

var Lit_248 *jrt.String = jrt.Intern("arbace.test$testing_vars_str$fn__196000023")

var Lit_249 *jrt.String = jrt.Intern("arbace.test$try_expr")

var Lit_250 *jrt.String = jrt.Intern("arbace.test$with_test")

var Lit_251 *jrt.String = jrt.Intern("arbace.test$with_test_out")

var Lit_252 *jrt.String = jrt.Intern("in-ns")

var Lit_253 *jrt.String = jrt.Intern("True by default.  If set to false, no test functions will\n   be created by deftest, set-test, or with-test.  Use this to omit\n   tests when compiling or loading production code.")

var Lit_254 *jrt.String = jrt.Intern("added")

var Lit_255 *jrt.String = jrt.Intern("1.1")

var Lit_256 *jrt.String = jrt.Intern("dynamic")

var Lit_257 *jrt.String = jrt.Intern("column")

var Lit_258 *jrt.String = jrt.Intern("arbace/test.ae")

var Lit_259 *jrt.String = jrt.Intern("The maximum depth of stack traces to print when an Exception\n  is thrown during a test.  Defaults to nil, which means print the\n  complete stack trace.")

var Lit_260 *jrt.String = jrt.Intern("with-test-out")

var Lit_261 *jrt.String = jrt.Intern("arglists")

var Lit_262 *jrt.String = jrt.Intern("&")

var Lit_263 *jrt.String = jrt.Intern("body")

var Lit_264 *jrt.String = jrt.Intern("Runs body with *out* bound to the value of *test-out*.")

var Lit_265 *jrt.String = jrt.Intern("file-position")

var Lit_266 *jrt.String = jrt.Intern("n")

var Lit_267 *jrt.String = jrt.Intern("Returns a vector [filename line-number] for the nth call up the\n  stack.\n\n  Deprecated in 1.2: The information needed for test reporting is\n  now on :file and :line keys in the result map.")

var Lit_268 *jrt.String = jrt.Intern("deprecated")

var Lit_269 *jrt.String = jrt.Intern("1.2")

var Lit_270 *jrt.String = jrt.Intern("m")

var Lit_271 *jrt.String = jrt.Intern("Returns a string representation of the current test.  Renders names\n  in *testing-vars* as a list, then the source file and line of\n  current assertion.")

var Lit_272 *jrt.String = jrt.Intern("Returns a string representation of the current test context. Joins\n  strings in *testing-contexts* with spaces.")

var Lit_273 *jrt.String = jrt.Intern("Increments the named counter in *report-counters*, a ref to a map.\n  Does nothing if *report-counters* is nil.")

var Lit_274 *jrt.String = jrt.Intern("Generic reporting function, may be overridden to plug in\n   different report formats (e.g., TAP, JUnit).  Assertions such as\n   'is' call 'report' to indicate results. The argument given to\n   'report' will be a map with a :type key. See (doc arbace.test)\n   docs under 'EXTENDING TEST-IS' for types of arguments for\n   'report'.")

var Lit_275 *jrt.String = jrt.Intern("global-hierarchy")

var Lit_276 *jrt.String = jrt.Intern("file-and-line")

var Lit_277 *jrt.String = jrt.Intern("exception")

var Lit_278 *jrt.String = jrt.Intern("tag")

var Lit_279 *jrt.String = jrt.Intern("Throwable")

var Lit_280 *jrt.String = jrt.Intern("depth")

var Lit_281 *jrt.String = jrt.Intern("1.8")

var Lit_282 *jrt.String = jrt.Intern("stacktrace")

var Lit_283 *jrt.String = jrt.Intern("Add file and line information to a test result and call report.\n   If you are writing a custom assert-expr method, call this function\n   to pass test results to report.")

var Lit_284 *jrt.String = jrt.Intern("v")

var Lit_285 *jrt.String = jrt.Intern("Like var-get but returns nil if the var is unbound.")

var Lit_286 *jrt.String = jrt.Intern("x")

var Lit_287 *jrt.String = jrt.Intern("Returns true if argument is a function or a symbol that resolves to\n  a function (not a macro).")

var Lit_288 *jrt.String = jrt.Intern("msg")

var Lit_289 *jrt.String = jrt.Intern("form")

var Lit_290 *jrt.String = jrt.Intern("Returns generic assertion code for any functional predicate.  The\n  'expected' argument to 'report' will contains the original form, the\n  'actual' argument will contain the form with all its sub-forms\n  evaluated.  If the predicate returns false, the 'actual' form will\n  be wrapped in (not...).")

var Lit_291 *jrt.String = jrt.Intern("Returns generic assertion code for any test, including macros, Java\n  method calls, or isolated symbols.")

var Lit_292 *jrt.String = jrt.Intern("thrown?")

var Lit_293 *jrt.String = jrt.Intern("thrown-with-msg?")

var Lit_294 *jrt.String = jrt.Intern("Used by the 'is' macro to catch unexpected exceptions.\n  You don't call this.")

var Lit_295 *jrt.String = jrt.Intern("Generic assertion macro.  'form' is any predicate test.\n  'msg' is an optional message to attach to the assertion.\n\n  Example: (is (= 4 (+ 2 2)) \"Two plus two should be 4\")\n\n  Special forms:\n\n  (is (thrown? c body)) checks that an instance of c is thrown from\n  body, fails if not; then returns the thing thrown.\n\n  (is (thrown-with-msg? c re body)) checks that an instance of c is\n  thrown AND that the message on the exception matches (with\n  re-find) the regular expression re.")

var Lit_296 *jrt.String = jrt.Intern("are")

var Lit_297 *jrt.String = jrt.Intern("argv")

var Lit_298 *jrt.String = jrt.Intern("expr")

var Lit_299 *jrt.String = jrt.Intern("args")

var Lit_300 *jrt.String = jrt.Intern("Checks multiple assertions with a template expression.\n  See arbace.template/do-template for an explanation of\n  templates.\n\n  Example: (are [x y] (= x y)\n                2 (+ 1 1)\n                4 (* 2 2))\n  Expands to:\n           (do (is (= 2 (+ 1 1)))\n               (is (= 4 (* 2 2))))\n\n  Note: This breaks some reporting features, such as line numbers.")

var Lit_301 *jrt.String = jrt.Intern("testing")

var Lit_302 *jrt.String = jrt.Intern("string")

var Lit_303 *jrt.String = jrt.Intern("Adds a new string to the list of testing contexts.  May be nested,\n  but must occur inside a test function (deftest).")

var Lit_304 *jrt.String = jrt.Intern("with-test")

var Lit_305 *jrt.String = jrt.Intern("definition")

var Lit_306 *jrt.String = jrt.Intern("Takes any definition form (that returns a Var) as the first argument.\n  Remaining body goes in the :test metadata function for that Var.\n\n  When *load-tests* is false, only evaluates the definition, ignoring\n  the tests.")

var Lit_307 *jrt.String = jrt.Intern("deftest")

var Lit_308 *jrt.String = jrt.Intern("Defines a test function with no arguments.  Test functions may call\n  other tests, so tests may be composed.  If you compose tests, you\n  should also define a function named test-ns-hook; run-tests will\n  call test-ns-hook instead of testing all vars.\n\n  Note: Actually, the test body goes in the :test metadata on the var,\n  and the real function (the value of the var) calls test-var on\n  itself.\n\n  When *load-tests* is false, deftest is ignored.")

var Lit_309 *jrt.String = jrt.Intern("deftest-")

var Lit_310 *jrt.String = jrt.Intern("Like deftest but creates a private var.")

var Lit_311 *jrt.String = jrt.Intern("set-test")

var Lit_312 *jrt.String = jrt.Intern("Experimental.\n  Sets :test metadata of the named var to a fn with the given body.\n  The var must already exist.  Does not modify the value of the var.\n\n  When *load-tests* is false, set-test is ignored.")

var Lit_313 *jrt.String = jrt.Intern("key")

var Lit_314 *jrt.String = jrt.Intern("coll")

var Lit_315 *jrt.String = jrt.Intern("Adds elements in coll to the current namespace metadata as the\n  value of key.")

var Lit_316 *jrt.String = jrt.Intern("use-fixtures")

var Lit_317 *jrt.String = jrt.Intern("Wrap test runs in a fixture function to perform setup and\n  teardown. Using a fixture-type of :each wraps every test\n  individually, while :once wraps the whole run in a single function.")

var Lit_318 *jrt.String = jrt.Intern("each")

var Lit_319 *jrt.String = jrt.Intern("once")

var Lit_320 *jrt.String = jrt.Intern("f")

var Lit_321 *jrt.String = jrt.Intern("The default, empty, fixture function.  Just calls its argument.")

var Lit_322 *jrt.String = jrt.Intern("f1")

var Lit_323 *jrt.String = jrt.Intern("f2")

var Lit_324 *jrt.String = jrt.Intern("Composes two fixture functions, creating a new fixture function\n  that combines their behavior.")

var Lit_325 *jrt.String = jrt.Intern("fixtures")

var Lit_326 *jrt.String = jrt.Intern("Composes a collection of fixtures, in order.  Always returns a valid\n  fixture function, even if the collection is empty.")

var Lit_327 *jrt.String = jrt.Intern("If v has a function in its :test metadata, calls that function,\n  with *testing-vars* bound to (conj *testing-vars* v).")

var Lit_328 *jrt.String = jrt.Intern("vars")

var Lit_329 *jrt.String = jrt.Intern("Groups vars by their namespace and runs test-var on them with\n  appropriate fixtures applied.")

var Lit_330 *jrt.String = jrt.Intern("1.6")

var Lit_331 *jrt.String = jrt.Intern("Calls test-vars on every var interned in the namespace, with fixtures.")

var Lit_332 *jrt.String = jrt.Intern("If the namespace defines a function named test-ns-hook, calls that.\n  Otherwise, calls test-all-vars on the namespace.  'ns' is a\n  namespace object or a symbol.\n\n  Internally binds *report-counters* to a ref initialized to\n  *initial-report-counters*.  Returns the final, dereferenced state of\n  *report-counters*.")

var Lit_333 *jrt.String = jrt.Intern("namespaces")

var Lit_334 *jrt.String = jrt.Intern("Runs all tests in the given namespaces; prints results.\n  Defaults to current namespace if none given.  Returns a map\n  summarizing test results.")

var Lit_335 *jrt.String = jrt.Intern("run-all-tests")

var Lit_336 *jrt.String = jrt.Intern("re")

var Lit_337 *jrt.String = jrt.Intern("Runs all tests in all namespaces; prints results.\n  Optional argument is a regular expression; only namespaces with\n  names matching the regular expression (with re-matches) will be\n  tested.")

var Lit_338 *jrt.String = jrt.Intern("successful?")

var Lit_339 *jrt.String = jrt.Intern("Returns true if the given test summary indicates all tests\n  were successful, false otherwise.")

var Lit_340 *jrt.String = jrt.Intern("Runs the tests for a single Var, with fixtures executed around the test, and summary output after.")

var Lit_341 *jrt.String = jrt.Intern("1.11")

var Lit_342 *jrt.String = jrt.Intern("run-test")

var Lit_343 *jrt.String = jrt.Intern("test-symbol")

var Lit_344 *jrt.String = jrt.Intern("Runs a single test.\n\n  Because the intent is to run a single test, there is no check for the namespace test-ns-hook.")
