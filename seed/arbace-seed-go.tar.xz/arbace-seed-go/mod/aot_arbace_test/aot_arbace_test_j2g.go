//line aot_arbace_test_j2g.ae:1
package aot_arbace_test

import (
	"arbace/jrt"
	"arbace/lang"
)










func A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_New() *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A) Ctor() {}
//line :17:1
func (t *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_test_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_test_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_test_A_const_3, A_arbace_test_A_const_4, A_arbace_test_A_const_5); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :17:1
func A_arbace_test_eval196000008_fn__196000009_A_New() *A_arbace_test_eval196000008_fn__196000009_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000008_fn__196000009_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_test_eval196000008_fn__196000009_A) Ctor() {}
//line :17:1
func (t *A_arbace_test_eval196000008_fn__196000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_test_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_10), A_arbace_test_A_const_8.GetRawRoot__O(), A_arbace_test_A_const_9) }

























































































































































































































































func A_arbace_test_with_test_out_A_New() *A_arbace_test_with_test_out_A { A_arbace_test_A_Init(); t := &A_arbace_test_with_test_out_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_test_with_test_out_A) Ctor() {}
//line :267:1
func (t *A_arbace_test_with_test_out_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { return lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_14), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_16.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_17), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_18))))), body__2)) }








func A_arbace_test_file_position_A_New() *A_arbace_test_file_position_A { A_arbace_test_A_Init(); t := &A_arbace_test_file_position_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_test_file_position_A) Ctor() {}
//line :276:1
func (t *A_arbace_test_file_position_A) Invoke_O_O__O(self, n__0 any) any { var s__2 any = lang.RT_Nth_O_I__O_NoInit(jrt.Throwable_New().GetStackTrace__StackTraceElement1().Ref(), lang.RT_IntCast_O__I_NoInit(n__0)); return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.As[*jrt.StackTraceElement](s__2)).GetFileName__String().Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.As[*jrt.StackTraceElement](s__2)).GetLineNumber__I()).Ref()) }











func A_arbace_test_testing_vars_str_A_New() *A_arbace_test_testing_vars_str_A { A_arbace_test_A_Init(); t := &A_arbace_test_testing_vars_str_A{}; t.Ctor(); return t }
//line :288:1
func (t *A_arbace_test_testing_vars_str_A) Ctor() {}
//line :288:1
func (t *A_arbace_test_testing_vars_str_A) Invoke_O_O__O(self, m__0 any) any { var map__196000021__2 any = m__0; var map__196000021__3 any; if





	lang.ISeq_InstanceOf(map__196000021__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_test_A_const_19.GetRawRoot__O()).Invoke_O__O(map__196000021__2)) { map__196000021__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_test_A_const_20.GetRawRoot__O()).Invoke_O__O(map__196000021__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(map__196000021__2)) { map__196000021__3 = lang.IFn_Cast(A_arbace_test_A_const_21.GetRawRoot__O()).Invoke_O__O(map__196000021__2) } else { map__196000021__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__196000021__3 = map__196000021__2 }; var file__4 any = /*line :288:1*/lang.RT_Get_O_O__O_NoInit(map__196000021__3, A_arbace_test_A_const_22); var line__5 any = lang.RT_Get_O_O__O_NoInit(map__196000021__3, A_arbace_test_A_const_23); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_34, nil, Lit_35, nil, Lit_36); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_24.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_25.GetRawRoot__O()); var tmp4 any = A_arbace_test_testing_vars_str_fn__196000023_A_New(); var tmp5 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_test_testing_vars_str_fn__196000023_A_fn_class; if









	fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_test_testing_vars_str_fn__196000023_A_fn_class = fncls__1d; tmp5 = fncls__1d } else { tmp5 = fncls__1 }; return /*line :295:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), A_arbace_test_A_const_27.Get__O())), nil, file__4, nil, line__5, nil)).Ref() }


func A_arbace_test_testing_vars_str_fn__196000023_A_New() *A_arbace_test_testing_vars_str_fn__196000023_A { A_arbace_test_A_Init(); t := &A_arbace_test_testing_vars_str_fn__196000023_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_test_testing_vars_str_fn__196000023_A) Ctor() {}
//line :298:1
func (t *A_arbace_test_testing_vars_str_fn__196000023_A) Invoke_O_O__O(self, p1__196000020_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_test_A_const_26; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__196000020_SHARP___1)) }


func A_arbace_test_testing_contexts_str_A_New() *A_arbace_test_testing_contexts_str_A { A_arbace_test_A_Init(); t := &A_arbace_test_testing_contexts_str_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_test_testing_contexts_str_A) Ctor() {}
//line :301:1
func (t *A_arbace_test_testing_contexts_str_A) Invoke_O__O(self any) any {




	return lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_28.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_29.GetRawRoot__O()).Invoke_O_O__O(Lit_33, lang.IFn_Cast(A_arbace_test_A_const_24.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_30.Get__O())))
}
func A_arbace_test_inc_report_counter_A_New() *A_arbace_test_inc_report_counter_A { A_arbace_test_A_Init(); t := &A_arbace_test_inc_report_counter_A{}; t.Ctor(); return t }
//line :308:1
func (t *A_arbace_test_inc_report_counter_A) Ctor() {}
//line :308:1
func (t *A_arbace_test_inc_report_counter_A) Invoke_O_O__O(self, name__0 any) any {




	if jrt.J2g_Truth(A_arbace_test_A_const_31.Get__O()) {
		var tmp1 any = A_arbace_test_inc_report_counter_fn__196000027_A_New_O(name__0); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_test_inc_report_counter_fn__196000027_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_test_inc_report_counter_fn__196000027_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; return lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) } else {
//line :313:1
			return nil } }
func A_arbace_test_inc_report_counter_fn__196000027_A_New_O(p0 any) *A_arbace_test_inc_report_counter_fn__196000027_A { A_arbace_test_A_Init(); t := &A_arbace_test_inc_report_counter_fn__196000027_A{}; t.Ctor_O(p0); return t }
//line :314:1
func (t *A_arbace_test_inc_report_counter_fn__196000027_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :314:1
func (t *A_arbace_test_inc_report_counter_fn__196000027_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_test_A_const_6.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_test_A_const_31.Get__O(), A_arbace_test_A_const_32.GetRawRoot__O(), lang.Tuple_Create_O__IPersistentVector(t.F_name), lang.IFn_Cast(A_arbace_test_A_const_33.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_34.GetRawRoot__O(), A_arbace_test_A_const_35)) }














func A_arbace_test_file_and_line_A_New() *A_arbace_test_file_and_line_A { A_arbace_test_A_Init(); t := &A_arbace_test_file_and_line_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_test_file_and_line_A) Ctor() {}
//line :329:1
func (t *A_arbace_test_file_and_line_A) Invoke_O_O_O__O(self, exception__0, depth__1 any) any { var stacktrace__3 any = jrt.Throwable_Cast(exception__0).GetStackTrace__StackTraceElement1().Ref(); var tmp1 bool; var na_3 any = depth__1; var na_4 int64 = int64(lang.RT_Count_O__I_NoInit(stacktrace__3)); if



	jrt.Long_InstanceOf(na_3) { var n0_5 int64 = jrt.NN(jrt.Long_Cast(na_3)).LongValue__J(); var n1_6 int64 = na_4; tmp1 = n0_5 < n1_6 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_3, na_4) }; if tmp1 { var s__4 any = lang.RT_Nth_O_I__O_NoInit(stacktrace__3, lang.RT_IntCast_O__I_NoInit(depth__1)); var tmp2 any = A_arbace_test_A_const_22; var tmp3 any = jrt.NN(jrt.As[*jrt.StackTraceElement](s__4)).GetFileName__String().Ref(); var tmp4 any = A_arbace_test_A_const_23; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.As[*jrt.StackTraceElement](s__4)).GetLineNumber__I()).Ref())) } else { return A_arbace_test_A_const_36 } }




func A_arbace_test_stacktrace_file_and_line_A_New() *A_arbace_test_stacktrace_file_and_line_A { A_arbace_test_A_Init(); t := &A_arbace_test_stacktrace_file_and_line_A{}; t.Ctor(); return t }
//line :338:1
func (t *A_arbace_test_stacktrace_file_and_line_A) Ctor() {}
//line :338:1
func (t *A_arbace_test_stacktrace_file_and_line_A) Invoke_O_O__O(self, stacktrace__0 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(stacktrace__0)) { var s__2 any = lang.IFn_Cast(A_arbace_test_A_const_21.GetRawRoot__O()).Invoke_O__O(stacktrace__0); var tmp1 any = A_arbace_test_A_const_22; var tmp2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](s__2)).GetFileName__String().Ref(); var tmp3 any = A_arbace_test_A_const_23; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.As[*jrt.StackTraceElement](s__2)).GetLineNumber__I()).Ref())) } else { return A_arbace_test_A_const_37
	}
}


func A_arbace_test_do_report_A_New() *A_arbace_test_do_report_A { A_arbace_test_A_Init(); t := &A_arbace_test_do_report_A{}; t.Ctor(); return t }
//line :345:1
func (t *A_arbace_test_do_report_A) Ctor() {}
//line :345:1
func (t *A_arbace_test_do_report_A) Invoke_O_O__O(self, m__0 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_38.Get__O()); var tmp2 any; var G__196000035__2_ any = A_arbace_test_A_const_39.Invoke_O__O(m__0)
L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__196000035__2_) >> 0 & 1 { case 0: if any(G__196000035__2_) == any(A_arbace_test_A_const_40) {







	tmp2 = lang.IFn_Cast(A_arbace_test_A_const_41.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_43.GetRawRoot__O()).Invoke_O__O(jrt.Throwable_Cast(A_arbace_test_A_const_44.Invoke_O__O(m__0)).GetStackTrace__StackTraceElement1().Ref()), m__0)
//line :352:1
	break L1 }; case 1: if any(G__196000035__2_) == any(A_arbace_test_A_const_42) {

		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_41.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_43.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_45.GetRawRoot__O()); var tmp6 any = A_arbace_test_do_report_fn__196000036_A_New(); var tmp7 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_test_do_report_fn__196000036_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_test_do_report_fn__196000036_A_fn_class = fncls__9d; tmp7 = fncls__9d } else { tmp7 = fncls__9 }; tmp2 = tmp3.Invoke_O_O__O(tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), jrt.Thread_CurrentThread__Thread().GetStackTrace__StackTraceElement1().Ref())), m__0)
//line :352:1
		break L1 }; default:}; tmp2 = m__0}
//line :351:1
	return tmp1.Invoke_O__O(tmp2)
}

func A_arbace_test_do_report_fn__196000036_A_New() *A_arbace_test_do_report_fn__196000036_A { A_arbace_test_A_Init(); t := &A_arbace_test_do_report_fn__196000036_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_test_do_report_fn__196000036_A) Ctor() {}
//line :354:1
func (t *A_arbace_test_do_report_fn__196000036_A) Invoke_O_O__O(self, p1__196000034_SHARP___1 any) any { var cl_name__2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](p1__196000034_SHARP___1)).GetClassName__String().Ref(); var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_test_A_const_46.GetRawRoot__O()).Invoke_O_O__O(cl_name__2, Lit_5); if

	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_test_A_const_46.GetRawRoot__O()).Invoke_O_O__O(cl_name__2, Lit_6); if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {

		return lang.IFn_Cast(A_arbace_test_A_const_46.GetRawRoot__O()).Invoke_O_O__O(cl_name__2, Lit_7) } } }




func A_arbace_test_eval196000039_fn__196000040_A_New() *A_arbace_test_eval196000039_fn__196000040_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000039_fn__196000040_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_test_eval196000039_fn__196000040_A) Ctor() {}
//line :363:1
func (t *A_arbace_test_eval196000039_fn__196000040_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_51; lang.IFn_Cast(A_arbace_test_A_const_49.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_A_const_52.Get__O()))
//line :363:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		tmp3 = lang.IFn_Cast(A_arbace_test_A_const_47.GetRawRoot__O()).Invoke_O__O(m__1)
//line :363:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_A_const_48.GetRawRoot__O()).Invoke__O()
//line :363:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}

func A_arbace_test_eval196000043_fn__196000044_A_New() *A_arbace_test_eval196000043_fn__196000044_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000043_fn__196000044_A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_test_eval196000043_fn__196000044_A) Ctor() {}
//line :366:1
func (t *A_arbace_test_eval196000043_fn__196000044_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_51; lang.IFn_Cast(A_arbace_test_A_const_49.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_A_const_52.Get__O()))
//line :366:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		tmp3 = lang.IFn_Cast(A_arbace_test_A_const_53.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_54)
//line :366:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_A_const_48.GetRawRoot__O()).Invoke__O()
//line :366:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}

func A_arbace_test_eval196000047_fn__196000048_A_New() *A_arbace_test_eval196000047_fn__196000048_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000047_fn__196000048_A{}; t.Ctor(); return t }
//line :369:1
func (t *A_arbace_test_eval196000047_fn__196000048_A) Ctor() {}
//line :369:1
func (t *A_arbace_test_eval196000047_fn__196000048_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_51; lang.IFn_Cast(A_arbace_test_A_const_49.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_A_const_52.Get__O()))
//line :369:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		lang.IFn_Cast(A_arbace_test_A_const_53.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_42)
		lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O_O__O(Lit_8, lang.IFn_Cast(A_arbace_test_A_const_57.GetRawRoot__O()).Invoke_O__O(m__1))
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_30.Get__O())) { lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_58.GetRawRoot__O()).Invoke__O()) }
//line :369:1
		{ var temp__1927000414__auto____4 any = A_arbace_test_A_const_56.Invoke_O__O(m__1)




			if jrt.J2g_Truth(temp__1927000414__auto____4) { var message__5 any = temp__1927000414__auto____4; lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O__O(message__5) }
			lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O_O__O(Lit_9, lang.IFn_Cast(A_arbace_test_A_const_59.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60.Invoke_O__O(m__1)))
			tmp3 = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O_O__O(Lit_10, lang.IFn_Cast(A_arbace_test_A_const_59.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44.Invoke_O__O(m__1))) }
//line :369:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_A_const_48.GetRawRoot__O()).Invoke__O()
//line :369:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}







func A_arbace_test_eval196000051_fn__196000052_A_New() *A_arbace_test_eval196000051_fn__196000052_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000051_fn__196000052_A{}; t.Ctor(); return t }
//line :378:1
func (t *A_arbace_test_eval196000051_fn__196000052_A) Ctor() {}
//line :378:1
func (t *A_arbace_test_eval196000051_fn__196000052_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_51; lang.IFn_Cast(A_arbace_test_A_const_49.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_A_const_52.Get__O()))
//line :378:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		lang.IFn_Cast(A_arbace_test_A_const_53.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_40)
		lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O_O__O(Lit_11, lang.IFn_Cast(A_arbace_test_A_const_57.GetRawRoot__O()).Invoke_O__O(m__1))
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_30.Get__O())) { lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_58.GetRawRoot__O()).Invoke__O()) }
//line :378:1
		{ var temp__1927000414__auto____4 any = A_arbace_test_A_const_56.Invoke_O__O(m__1)




			if jrt.J2g_Truth(temp__1927000414__auto____4) { var message__5 any = temp__1927000414__auto____4; lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O__O(message__5) }
			lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O_O__O(Lit_9, lang.IFn_Cast(A_arbace_test_A_const_59.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60.Invoke_O__O(m__1)))
			lang.IFn_Cast(A_arbace_test_A_const_62.GetRawRoot__O()).Invoke_O__O(Lit_12)
//line :378:1
			var actual__4 any = A_arbace_test_A_const_44.Invoke_O__O(m__1)








			if jrt.Throwable_InstanceOf(actual__4) {
				tmp3 = lang.IFn_Cast(A_arbace_test_A_const_61.GetRawRoot__O()).Invoke_O_O__O(actual__4, A_arbace_test_A_const_63.Get__O()) } else {
					tmp3 = lang.IFn_Cast(A_arbace_test_A_const_47.GetRawRoot__O()).Invoke_O__O(actual__4) } }
//line :378:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_A_const_48.GetRawRoot__O()).Invoke__O()
//line :378:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}











func A_arbace_test_eval196000055_fn__196000056_A_New() *A_arbace_test_eval196000055_fn__196000056_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000055_fn__196000056_A{}; t.Ctor(); return t }
//line :391:1
func (t *A_arbace_test_eval196000055_fn__196000056_A) Ctor() {}
//line :391:1
func (t *A_arbace_test_eval196000055_fn__196000056_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_51; lang.IFn_Cast(A_arbace_test_A_const_49.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_A_const_52.Get__O()))
//line :391:1
	var tmp3 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()); var tmp5 any = A_arbace_test_A_const_64.Invoke_O__O(m__1); var tmp6 jrt.Number_I; var na_10 any; var na_12 any = A_arbace_test_A_const_54.Invoke_O__O(m__1); var na_13 any = A_arbace_test_A_const_42.Invoke_O__O(m__1); var tmp7 bool; var tmp8 bool
			tmp8 = jrt.Long_InstanceOf(na_12); if tmp8 { tmp8 = jrt.Long_InstanceOf(na_13) }; tmp7 = tmp8; if tmp7 { var n0_14 int64 = jrt.NN(jrt.Long_Cast(na_12)).LongValue__J(); var n1_15 int64 = jrt.NN(jrt.Long_Cast(na_13)).LongValue__J(); var nr_16 int64 = n0_14 + n1_15; if (n0_14^nr_16)&(n1_15^nr_16) >= 0 { na_10 = jrt.Long_ValueOf_J__Long_NoInit(nr_16).Ref() } else { na_10 = lang.Numbers_Add_O_O__Number_NoInit(na_12, na_13) } } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_12); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_13) }; tmp9 = tmp10; if tmp9 { var n0_14_2 float64 = jrt.NN(jrt.Double_Cast(na_12)).DoubleValue__D(); var n1_15_2 float64 = jrt.NN(jrt.Double_Cast(na_13)).DoubleValue__D(); na_10 = jrt.Double_ValueOf_D__Double_NoInit(n0_14_2 + n1_15_2).Ref() } else { na_10 = lang.Numbers_Add_O_O__Number_NoInit(na_12, na_13) } }; var na_11 any = A_arbace_test_A_const_40.Invoke_O__O(m__1); var tmp11 bool; var tmp12 bool; tmp12 = jrt.Long_InstanceOf(na_10); if tmp12 { tmp12 = jrt.Long_InstanceOf(na_11) }; tmp11 = tmp12; if tmp11 { var n0_17 int64 = jrt.NN(jrt.Long_Cast(na_10)).LongValue__J(); var n1_18 int64 = jrt.NN(jrt.Long_Cast(na_11)).LongValue__J(); var nr_19 int64 = n0_17 + n1_18; if (n0_17^nr_19)&(n1_18^nr_19) >= 0 { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_19)) } else { tmp6 = lang.Numbers_Add_O_O__Number_NoInit(na_10, na_11) } } else { var tmp13 bool; var tmp14 bool; tmp14 = jrt.Double_InstanceOf(na_10); if tmp14 { tmp14 = jrt.Double_InstanceOf(na_11) }; tmp13 = tmp14; if tmp13 { var n0_17_2 float64 = jrt.NN(jrt.Double_Cast(na_10)).DoubleValue__D(); var n1_18_2 float64 = jrt.NN(jrt.Double_Cast(na_11)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_17_2 + n1_18_2)) } else { tmp6 = lang.Numbers_Add_O_O__Number_NoInit(na_10, na_11) } }
//line :393:1
			tmp4.Invoke_O_O_O_O_O__O(Lit_13, tmp5, Lit_14, tmp6, Lit_15)

			tmp3 = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_test_A_const_42.Invoke_O__O(m__1), Lit_16, A_arbace_test_A_const_40.Invoke_O__O(m__1), Lit_17) }
//line :391:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_A_const_48.GetRawRoot__O()).Invoke__O()
//line :391:1
	if tmp15 != nil { panic(tmp15) }; return tmp3
}




func A_arbace_test_eval196000059_fn__196000060_A_New() *A_arbace_test_eval196000059_fn__196000060_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000059_fn__196000060_A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_test_eval196000059_fn__196000060_A) Ctor() {}
//line :397:1
func (t *A_arbace_test_eval196000059_fn__196000060_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_51; lang.IFn_Cast(A_arbace_test_A_const_49.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_A_const_52.Get__O()))
//line :397:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		tmp3 = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O_O__O(Lit_18, lang.IFn_Cast(A_arbace_test_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_66.Invoke_O__O(m__1)))
//line :397:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_A_const_48.GetRawRoot__O()).Invoke__O()
//line :397:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}



func A_arbace_test_eval196000063_fn__196000064_A_New() *A_arbace_test_eval196000063_fn__196000064_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000063_fn__196000064_A{}; t.Ctor(); return t }
//line :402:1
func (t *A_arbace_test_eval196000063_fn__196000064_A) Ctor() {}
//line :402:1
func (t *A_arbace_test_eval196000063_fn__196000064_A) Invoke_O_O__O(self, m__1 any) any { return nil }
func A_arbace_test_eval196000067_fn__196000068_A_New() *A_arbace_test_eval196000067_fn__196000068_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000067_fn__196000068_A{}; t.Ctor(); return t }
//line :403:1
func (t *A_arbace_test_eval196000067_fn__196000068_A) Ctor() {}
//line :403:1
func (t *A_arbace_test_eval196000067_fn__196000068_A) Invoke_O_O__O(self, m__1 any) any { return nil }
func A_arbace_test_eval196000071_fn__196000072_A_New() *A_arbace_test_eval196000071_fn__196000072_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000071_fn__196000072_A{}; t.Ctor(); return t }
//line :404:1
func (t *A_arbace_test_eval196000071_fn__196000072_A) Ctor() {}
//line :404:1
func (t *A_arbace_test_eval196000071_fn__196000072_A) Invoke_O_O__O(self, m__1 any) any { return nil }



func A_arbace_test_get_possibly_unbound_var_A_New() *A_arbace_test_get_possibly_unbound_var_A { A_arbace_test_A_Init(); t := &A_arbace_test_get_possibly_unbound_var_A{}; t.Ctor(); return t }
//line :408:1
func (t *A_arbace_test_get_possibly_unbound_var_A) Ctor() {}
//line :408:1
func (t *A_arbace_test_get_possibly_unbound_var_A) Invoke_O_O__O(self, v__0 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



	tmp1 = lang.IFn_Cast(A_arbace_test_A_const_67.GetRawRoot__O()).Invoke_O__O(v__0)
//line :408:1
	return nil }(); if tmp2 != nil { if jrt.IllegalStateException_InstanceOf(tmp2) { var e__4 jrt.IllegalStateException_I = jrt.IllegalStateException_Cast(tmp2); _ = e__4; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }







func A_arbace_test_function_QMARK__A_New() *A_arbace_test_function_QMARK__A { A_arbace_test_A_Init(); t := &A_arbace_test_function_QMARK__A{}; t.Ctor(); return t }
//line :416:1
func (t *A_arbace_test_function_QMARK__A) Ctor() {}
//line :416:1
func (t *A_arbace_test_function_QMARK__A) Invoke_O_O__O(self, x__0 any) any {




	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_test_A_const_68.GetRawRoot__O()).Invoke_O__O(x__0)) { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_test_A_const_69.GetRawRoot__O()).Invoke_O__O(x__0)
		if jrt.J2g_Truth(temp__1927000414__auto____2) { var v__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any = lang.IFn_Cast(A_arbace_test_A_const_70.GetRawRoot__O()).Invoke_O__O(v__3)
			if jrt.J2g_Truth(temp__1927000414__auto____4) { var value__5 any = temp__1927000414__auto____4; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_test_A_const_71.GetRawRoot__O()).Invoke_O__O(value__5)
				if jrt.J2g_Truth(and__1927000168__auto____6) {
					var tmp1 *lang.Keyword = A_arbace_test_A_const_73; return lang.IFn_Cast(A_arbace_test_A_const_72.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__3))) } else {
//line :424:1
						return and__1927000168__auto____6 } } else {
//line :423:1
							return nil } } else {
//line :422:1
								return nil } } else {



									return lang.IFn_Cast(A_arbace_test_A_const_71.GetRawRoot__O()).Invoke_O__O(x__0)
								} }
func A_arbace_test_assert_predicate_A_New() *A_arbace_test_assert_predicate_A { A_arbace_test_A_Init(); t := &A_arbace_test_assert_predicate_A{}; t.Ctor(); return t }
//line :428:1
func (t *A_arbace_test_assert_predicate_A) Ctor() {}
//line :428:1
func (t *A_arbace_test_assert_predicate_A) Invoke_O_O_O__O(self, msg__0, form__1 any) any { var args__3 any = lang.IFn_Cast(A_arbace_test_A_const_74.GetRawRoot__O()).Invoke_O__O(form__1); var pred__4 any = lang.IFn_Cast(A_arbace_test_A_const_21.GetRawRoot__O()).Invoke_O__O(form__1); return /*line :436:1*/ lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_75), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_16.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_76), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_77), args__3))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_78), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_79), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(pred__4), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_76)))))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_80), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_78), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_81), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_50.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_54), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_56), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__0), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__1)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_83), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(pred__4)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_76))))))))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_84), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_50.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_42), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_56), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__0), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__1)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_85), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_86)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_87), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(pred__4)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_76))))))))))))))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_78))) }










func A_arbace_test_assert_any_A_New() *A_arbace_test_assert_any_A { A_arbace_test_A_Init(); t := &A_arbace_test_assert_any_A{}; t.Ctor(); return t }
//line :447:1
func (t *A_arbace_test_assert_any_A) Ctor() {}
//line :447:1
func (t *A_arbace_test_assert_any_A) Invoke_O_O_O__O(self, msg__0, form__1 any) any { return lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_88), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_16.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_89), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__1))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_90), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_89), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_91), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_50.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_54), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_56), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__0), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__1)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_89)))))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_92), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_50.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_42), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_56), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__0), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__1)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_89))))))))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_89))) }



















func A_arbace_test_eval196000082_fn__196000083_A_New() *A_arbace_test_eval196000082_fn__196000083_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000082_fn__196000083_A{}; t.Ctor(); return t }
//line :467:1
func (t *A_arbace_test_eval196000082_fn__196000083_A) Ctor() {}
//line :467:1
func (t *A_arbace_test_eval196000082_fn__196000083_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any {
	if lang.Util_Identical_O_O__Z_NoInit(form__2, nil) { return A_arbace_test_A_const_93 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_test_A_const_94.GetRawRoot__O()).Invoke_O__O(form__2)) {

		return lang.IFn_Cast(A_arbace_test_A_const_21.GetRawRoot__O()).Invoke_O__O(form__2) } else {
//line :468:1
			if A_arbace_test_A_const_95 != nil { return A_arbace_test_A_const_96 } else { return nil
			}
		}
	}
}
func A_arbace_test_eval196000086_fn__196000087_A_New() *A_arbace_test_eval196000086_fn__196000087_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000086_fn__196000087_A{}; t.Ctor(); return t }
//line :473:1
func (t *A_arbace_test_eval196000086_fn__196000087_A) Ctor() {}
//line :473:1
func (t *A_arbace_test_eval196000086_fn__196000087_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any { return lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_97), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_50.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_42), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_56), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1))))))) }



func A_arbace_test_eval196000090_fn__196000091_A_New() *A_arbace_test_eval196000090_fn__196000091_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000090_fn__196000091_A{}; t.Ctor(); return t }
//line :477:1
func (t *A_arbace_test_eval196000090_fn__196000091_A) Ctor() {}
//line :477:1
func (t *A_arbace_test_eval196000090_fn__196000091_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_test_A_const_98.GetRawRoot__O()).Invoke_O__O(form__2); if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_test_A_const_99.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_21.GetRawRoot__O()).Invoke_O__O(form__2)) } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_test_A_const_100.GetRawRoot__O()).Invoke_O_O__O(msg__1, form__2) } else {
			return lang.IFn_Cast(A_arbace_test_A_const_101.GetRawRoot__O()).Invoke_O_O__O(msg__1, form__2)
		} }
func A_arbace_test_eval196000097_fn__196000098_A_New() *A_arbace_test_eval196000097_fn__196000098_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000097_fn__196000098_A{}; t.Ctor(); return t }
//line :482:1
func (t *A_arbace_test_eval196000097_fn__196000098_A) Ctor() {}
//line :482:1
func (t *A_arbace_test_eval196000097_fn__196000098_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any { return lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_102), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_16.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_103), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(form__2, lang.RT_IntCast_J__I_NoInit(1))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_104), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(form__2, lang.RT_IntCast_J__I_NoInit(2))))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_105), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_16.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_106), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_107), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_103), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_104)))))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_108), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_106), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_109), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_50.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_54), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_56), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_110), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_104))))))))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_111), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_50.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_42), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_56), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_112), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_104)))))))))))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_106)))))) }











func A_arbace_test_eval196000102_fn__196000103_A_New() *A_arbace_test_eval196000102_fn__196000103_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000102_fn__196000103_A{}; t.Ctor(); return t }
//line :494:1
func (t *A_arbace_test_eval196000102_fn__196000103_A) Ctor() {}
//line :494:1
func (t *A_arbace_test_eval196000102_fn__196000103_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any { var klass__3 any = lang.IFn_Cast(A_arbace_test_A_const_113.GetRawRoot__O()).Invoke_O__O(form__2); var body__4 any = lang.IFn_Cast(A_arbace_test_A_const_114.GetRawRoot__O()).Invoke_O_O__O(form__2, A_arbace_test_A_const_115); return /*line :498:1*/ lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_116), body__4, lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_117), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_50.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_42), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_56), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(nil)))))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_118), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(klass__3), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_119), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_120), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_50.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_54), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_56), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_119)))))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_119)))))) }









func A_arbace_test_eval196000108_fn__196000109_A_New() *A_arbace_test_eval196000108_fn__196000109_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000108_fn__196000109_A{}; t.Ctor(); return t }
//line :508:1
func (t *A_arbace_test_eval196000108_fn__196000109_A) Ctor() {}
//line :508:1
func (t *A_arbace_test_eval196000108_fn__196000109_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any { var klass__3 any = lang.RT_Nth_O_I__O_NoInit(form__2, lang.RT_IntCast_J__I_NoInit(1)); var re__4 any = lang.RT_Nth_O_I__O_NoInit(form__2, lang.RT_IntCast_J__I_NoInit(2)); var body__5 any = lang.IFn_Cast(A_arbace_test_A_const_114.GetRawRoot__O()).Invoke_O_O__O(form__2, A_arbace_test_A_const_121); return /*line :513:1*/ lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_122), body__5, lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_123), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_50.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_42), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_56), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(nil)))))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_124), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(klass__3), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_125), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_126), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_16.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_127), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_128), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_125)))))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_129), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_130), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(re__4), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_127)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_131), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_50.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_54), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_56), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_125)))))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_132), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_50.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_42), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_56), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_125)))))))))))))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_125)))))) }













func A_arbace_test_try_expr_A_New() *A_arbace_test_try_expr_A { A_arbace_test_A_Init(); t := &A_arbace_test_try_expr_A{}; t.Ctor(); return t }
//line :527:1
func (t *A_arbace_test_try_expr_A) Ctor() {}
//line :527:1
func (t *A_arbace_test_try_expr_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, msg__2, form__3 any) any { return lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_133), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_134.GetRawRoot__O()).Invoke_O_O__O(msg__2, form__3)), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_135), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_136), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_137), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_138), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_50.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_40), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_56), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__2), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__3)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_137))))))))))))) }













func A_arbace_test_is_A_New() *A_arbace_test_is_A { A_arbace_test_A_Init(); t := &A_arbace_test_is_A{}; t.Ctor(); return t }
//line :541:1
func (t *A_arbace_test_is_A) Ctor() {}
//line :541:1
func (t *A_arbace_test_is_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, form__2, msg__3 any) any { return lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_139), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__3), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2))) }
//line :541:1
func (t *A_arbace_test_is_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, form__2 any) any { return lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_140), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(nil))) }

















func A_arbace_test_are_A_New() *A_arbace_test_are_A { A_arbace_test_A_Init(); t := &A_arbace_test_are_A{}; t.Ctor(); return t }
//line :559:1
func (t *A_arbace_test_are_A) Ctor() {}
//line :559:1
func (t *A_arbace_test_are_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, argv__2, expr__3, args__4 any) any {














	var tmp1 any; var or__1927000174__auto____6 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_test_A_const_141.GetRawRoot__O()).Invoke_O__O(argv__2)

	if jrt.J2g_Truth(and__1927000168__auto____6) { or__1927000174__auto____6 = lang.IFn_Cast(A_arbace_test_A_const_141.GetRawRoot__O()).Invoke_O__O(args__4) } else { or__1927000174__auto____6 = and__1927000168__auto____6 }
//line :574:1
	if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { var and__1927000168__auto____7 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(argv__2)))



		if and__1927000168__auto____7 { var and__1927000168__auto____8 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(args__4))); if and__1927000168__auto____8 {

			var tmp2 bool; var na_20 any = lang.IFn_Cast(A_arbace_test_A_const_142.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(args__4)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(argv__2)).Ref()); if jrt.Long_InstanceOf(na_20) { var n0_21 int64 = jrt.NN(jrt.Long_Cast(na_20)).LongValue__J(); tmp2 = n0_21 == 0 } else { if jrt.Double_InstanceOf(na_20) { var n0_21_2 float64 = jrt.NN(jrt.Double_Cast(na_20)).DoubleValue__D(); tmp2 = n0_21_2 == 0.0 } else { tmp2 = lang.Numbers_IsZero_O__Z_NoInit(na_20) } }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref() } else {
//line :578:1
				tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } }
//line :574:1
	if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_143), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(argv__2), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_144), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(expr__3)))), args__4)) } else { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(Lit_1)))
	}
}







func A_arbace_test_testing_A_New() *A_arbace_test_testing_A { A_arbace_test_A_Init(); t := &A_arbace_test_testing_A{}; t.Ctor(); return t }
//line :584:1
func (t *A_arbace_test_testing_A) Ctor() {}
//line :584:1
func (t *A_arbace_test_testing_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, string__2, body__3 any) any { return lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_145), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_16.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_146), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_147), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_148), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(string__2)))))))), body__3)) }









func A_arbace_test_with_test_A_New() *A_arbace_test_with_test_A { A_arbace_test_A_Init(); t := &A_arbace_test_with_test_A{}; t.Ctor(); return t }
//line :594:1
func (t *A_arbace_test_with_test_A) Ctor() {}
//line :594:1
func (t *A_arbace_test_with_test_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, definition__2, body__3 any) any {







	if jrt.J2g_Truth(A_arbace_test_A_const_149.Get__O()) { return lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_150), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(definition__2), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_151), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_152), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_64), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_153), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_16.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke__O()))), body__3)))))))) } else { return definition__2
	}
}

func A_arbace_test_deftest_A_New() *A_arbace_test_deftest_A { A_arbace_test_A_Init(); t := &A_arbace_test_deftest_A{}; t.Ctor(); return t }
//line :606:1
func (t *A_arbace_test_deftest_A) Ctor() {}
//line :606:1
func (t *A_arbace_test_deftest_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, body__3 any) any {












	if jrt.J2g_Truth(A_arbace_test_A_const_149.Get__O()) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_155.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_156.GetRawRoot__O(); var tmp3 any = A_arbace_test_A_const_64; return lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_154), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O_O_O__O(name__2, tmp2, tmp3, lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_157), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_16.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke__O()))), body__3)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_158), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_16.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke__O()))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_159), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_160), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(name__2)))))))))))) } else { return nil
	}
}

func A_arbace_test_deftest__A_New() *A_arbace_test_deftest__A { A_arbace_test_A_Init(); t := &A_arbace_test_deftest__A{}; t.Ctor(); return t }
//line :623:1
func (t *A_arbace_test_deftest__A) Ctor() {}
//line :623:1
func (t *A_arbace_test_deftest__A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, body__3 any) any {



	if jrt.J2g_Truth(A_arbace_test_A_const_149.Get__O()) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_155.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_156.GetRawRoot__O(); var tmp3 any = A_arbace_test_A_const_64; return lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_161), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O_O_O_O_O__O(name__2, tmp2, tmp3, lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_163), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_16.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke__O()))), body__3)), A_arbace_test_A_const_162, jrt.Boolean_TRUE.Ref())), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_164), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_16.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke__O()))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_165), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_166), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(name__2)))))))))))) } else { return nil
	}
}

func A_arbace_test_set_test_A_New() *A_arbace_test_set_test_A { A_arbace_test_A_Init(); t := &A_arbace_test_set_test_A{}; t.Ctor(); return t }
//line :631:1
func (t *A_arbace_test_set_test_A) Ctor() {}
//line :631:1
func (t *A_arbace_test_set_test_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, body__3 any) any {







	if jrt.J2g_Truth(A_arbace_test_A_const_149.Get__O()) { return lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_167), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_168), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(name__2)))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_169), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_64), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_170), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_16.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke__O()))), body__3))))) } else { return nil
	}
}


func A_arbace_test_add_ns_meta_A_New() *A_arbace_test_add_ns_meta_A { A_arbace_test_A_Init(); t := &A_arbace_test_add_ns_meta_A{}; t.Ctor(); return t }
//line :644:1
func (t *A_arbace_test_add_ns_meta_A) Ctor() {}
//line :644:1
func (t *A_arbace_test_add_ns_meta_A) Invoke_O_O_O__O(self, key__0, coll__1 any) any {




	return lang.IFn_Cast(A_arbace_test_A_const_171.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_test_A_const_172.Get__O(), A_arbace_test_A_const_156.GetRawRoot__O(), key__0, coll__1)
}





func A_arbace_test_eval196000154_fn__196000155_A_New() *A_arbace_test_eval196000154_fn__196000155_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000154_fn__196000155_A{}; t.Ctor(); return t }
//line :656:1
func (t *A_arbace_test_eval196000154_fn__196000155_A) Ctor() {}
//line :656:1
func (t *A_arbace_test_eval196000154_fn__196000155_A) DoInvoke_O_O_O__O(self, fixture_type__1, args__2 any) any { return fixture_type__1 }

func A_arbace_test_eval196000158_fn__196000159_A_New() *A_arbace_test_eval196000158_fn__196000159_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000158_fn__196000159_A{}; t.Ctor(); return t }
//line :658:1
func (t *A_arbace_test_eval196000158_fn__196000159_A) Ctor() {}
//line :658:1
func (t *A_arbace_test_eval196000158_fn__196000159_A) DoInvoke_O_O_O__O(self, fixture_type__1, args__2 any) any {
	return lang.IFn_Cast(A_arbace_test_A_const_173.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_174, args__2)
}
func A_arbace_test_eval196000162_fn__196000163_A_New() *A_arbace_test_eval196000162_fn__196000163_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000162_fn__196000163_A{}; t.Ctor(); return t }
//line :661:1
func (t *A_arbace_test_eval196000162_fn__196000163_A) Ctor() {}
//line :661:1
func (t *A_arbace_test_eval196000162_fn__196000163_A) DoInvoke_O_O_O__O(self, fixture_type__1, args__2 any) any {
	return lang.IFn_Cast(A_arbace_test_A_const_173.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_175, args__2)
}
func A_arbace_test_default_fixture_A_New() *A_arbace_test_default_fixture_A { A_arbace_test_A_Init(); t := &A_arbace_test_default_fixture_A{}; t.Ctor(); return t }
//line :664:1
func (t *A_arbace_test_default_fixture_A) Ctor() {}
//line :664:1
func (t *A_arbace_test_default_fixture_A) Invoke_O_O__O(self, f__0 any) any {



	return lang.IFn_Cast(f__0).Invoke__O()
}
func A_arbace_test_compose_fixtures_A_New() *A_arbace_test_compose_fixtures_A { A_arbace_test_A_Init(); t := &A_arbace_test_compose_fixtures_A{}; t.Ctor(); return t }
//line :670:1
func (t *A_arbace_test_compose_fixtures_A) Ctor() {}
//line :670:1
func (t *A_arbace_test_compose_fixtures_A) Invoke_O_O_O__O(self, f1__0, f2__1 any) any {




	var tmp1 any = A_arbace_test_compose_fixtures_fn__196000167_A_New_O_O(f1__0, f2__1); var tmp2 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_test_compose_fixtures_fn__196000167_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_test_compose_fixtures_fn__196000167_A_fn_class = fncls__23d; tmp2 = fncls__23d } else { tmp2 = fncls__23 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :675:1
func A_arbace_test_compose_fixtures_fn__196000167_A_New_O_O(p0, p1 any) *A_arbace_test_compose_fixtures_fn__196000167_A { A_arbace_test_A_Init(); t := &A_arbace_test_compose_fixtures_fn__196000167_A{}; t.Ctor_O_O(p0, p1); return t }
//line :675:1
func (t *A_arbace_test_compose_fixtures_fn__196000167_A) Ctor_O_O(c__f1, c__f2 any) { t.F_f1 = c__f1; t.F_f2 = c__f2 }
//line :675:1
func (t *A_arbace_test_compose_fixtures_fn__196000167_A) Invoke_O_O__O(self, g__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_f1); var tmp2 any = A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_New_O_O(g__1, t.F_f2); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; return tmp1.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) }
//line :675:1
func A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_New_O_O(p0, p1 any) *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A { A_arbace_test_A_Init(); t := &A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A{}; t.Ctor_O_O(p0, p1); return t }
//line :675:1
func (t *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A) Ctor_O_O(c__g, c__f2 any) { t.F_g = c__g; t.F_f2 = c__f2 }
//line :675:1
func (t *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f2).Invoke_O__O(t.F_g) }

func A_arbace_test_join_fixtures_A_New() *A_arbace_test_join_fixtures_A { A_arbace_test_A_Init(); t := &A_arbace_test_join_fixtures_A{}; t.Ctor(); return t }
//line :677:1
func (t *A_arbace_test_join_fixtures_A) Ctor() {}
//line :677:1
func (t *A_arbace_test_join_fixtures_A) Invoke_O_O__O(self, fixtures__0 any) any {




	return lang.IFn_Cast(A_arbace_test_A_const_176.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_test_A_const_177.GetRawRoot__O(), A_arbace_test_A_const_178.GetRawRoot__O(), fixtures__0)
}


func A_arbace_test_test_var_A_New() *A_arbace_test_test_var_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_var_A{}; t.Ctor(); return t }
//line :686:1
func (t *A_arbace_test_test_var_A) Ctor() {}
//line :686:1
func (t *A_arbace_test_test_var_A) Invoke_O_O__O(self, v__0 any) any { var tmp1 *lang.Keyword = A_arbace_test_A_const_64; var temp__1927000414__auto____2 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__0)); if




	jrt.J2g_Truth(temp__1927000414__auto____2) { var t__3 any = temp__1927000414__auto____2; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp3 any = A_arbace_test_A_const_27
		lang.IFn_Cast(A_arbace_test_A_const_49.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_test_A_const_8.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_27.Get__O(), v__0)))
//line :691:1
		var tmp4 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

			lang.IFn_Cast(A_arbace_test_A_const_179.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_A_const_39, A_arbace_test_A_const_180, A_arbace_test_A_const_181, v__0)))
			lang.IFn_Cast(A_arbace_test_A_const_53.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_64)
			{ var tmp5 any = A_arbace_test_test_var_fn__196000173_A_New_O(t__3); var tmp6 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_test_test_var_fn__196000173_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_test_test_var_fn__196000173_A_fn_class = fncls__24d; tmp6 = fncls__24d } else { tmp6 = fncls__24 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()



				tmp4 = lang.IFn_Cast(A_arbace_test_A_const_179.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_A_const_39, A_arbace_test_A_const_182, A_arbace_test_A_const_181, v__0))) }
//line :691:1
			return nil }()
		lang.IFn_Cast(A_arbace_test_A_const_48.GetRawRoot__O()).Invoke__O()
//line :691:1
		if tmp7 != nil { panic(tmp7) }; return tmp4 } else { return nil } }



func A_arbace_test_test_var_fn__196000173_A_New_O(p0 any) *A_arbace_test_test_var_fn__196000173_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_var_fn__196000173_A{}; t.Ctor_O(p0); return t }
//line :695:1
func (t *A_arbace_test_test_var_fn__196000173_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :695:1
func (t *A_arbace_test_test_var_fn__196000173_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_t; t.F_t = nil; tmp2 = t_; tmp1 = lang.IFn_Cast(tmp2).Invoke__O() }; return nil }(); if tmp3 != nil { if true { var e__3 jrt.Throwable_I = tmp3

	tmp1 = lang.IFn_Cast(A_arbace_test_A_const_179.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_A_const_39, A_arbace_test_A_const_40, A_arbace_test_A_const_56, Lit_26, A_arbace_test_A_const_60, nil, A_arbace_test_A_const_44, e__3))) } }; return tmp1 }



func A_arbace_test_test_vars_A_New() *A_arbace_test_test_vars_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_vars_A{}; t.Ctor(); return t }
//line :701:1
func (t *A_arbace_test_test_vars_A) Ctor() {}
//line :701:1
func (t *A_arbace_test_test_vars_A) Invoke_O_O__O(self, vars__0 any) any { { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_186.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_66; var seq_196000176__2 any = lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_185.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_A_const_187.GetRawRoot__O()), vars__0)); var chunk_196000177__3 any; var count_196000178__4 int64 = 0; var i_196000179__5 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i_196000179__5, count_196000178__4) { var vec__196000180__6 any = lang.Indexed_Cast(chunk_196000177__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_196000179__5)); var ns__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__196000180__6, lang.RT_IntCast_J__I_NoInit(0), nil); var vars__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__196000180__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp3 *lang.Keyword = A_arbace_test_A_const_175; var once_fixture_fn__9 any = lang.IFn_Cast(A_arbace_test_A_const_188.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(ns__7))); var tmp4 *lang.Keyword = A_arbace_test_A_const_174; var each_fixture_fn__10 any = lang.IFn_Cast(A_arbace_test_A_const_188.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(ns__7))); var tmp5 lang.IFn = lang.IFn_Cast(once_fixture_fn__9); var tmp6 any = A_arbace_test_test_vars_fn__196000183_A_New_O_O(vars__8, each_fixture_fn__10); var tmp7 *jrt.Class
		var fncls__27 /*line :706:1*/*jrt.Class = A_arbace_test_test_vars_fn__196000183_A_fn_class



		if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_test_test_vars_fn__196000183_A_fn_class = fncls__27d; tmp7 = fncls__27d } else { tmp7 = fncls__27 }
//line :709:1
		tmp5.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil))
//line :706:1
		seq_196000176__2, chunk_196000177__3, count_196000178__4, i_196000179__5 = seq_196000176__2, chunk_196000177__3, count_196000178__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_196000179__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(seq_196000176__2); if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_196000176__7 any = temp__1927000414__auto____6; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_test_A_const_183.GetRawRoot__O()).Invoke_O__O(seq_196000176__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_test_A_const_184.GetRawRoot__O()).Invoke_O__O(seq_196000176__7); seq_196000176__2, chunk_196000177__3, count_196000178__4, i_196000179__5 = lang.IFn_Cast(A_arbace_test_A_const_190.GetRawRoot__O()).Invoke_O__O(seq_196000176__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__196000193__8 any = lang.IFn_Cast(A_arbace_test_A_const_21.GetRawRoot__O()).Invoke_O__O(seq_196000176__7); var ns__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__196000193__8, lang.RT_IntCast_J__I_NoInit(0), nil); var vars__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__196000193__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp8 *lang.Keyword = A_arbace_test_A_const_175; var once_fixture_fn__11 any = lang.IFn_Cast(A_arbace_test_A_const_188.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(ns__9))); var tmp9 *lang.Keyword = A_arbace_test_A_const_174; var each_fixture_fn__12 any = lang.IFn_Cast(A_arbace_test_A_const_188.GetRawRoot__O()).Invoke_O__O(tmp9.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(ns__9))); var tmp10 lang.IFn = lang.IFn_Cast(once_fixture_fn__11); var tmp11 any = A_arbace_test_test_vars_fn__196000196_A_New_O_O(vars__10, each_fixture_fn__12); var tmp12 *jrt.Class
			var fncls__30 /*line :706:1*/*jrt.Class = A_arbace_test_test_vars_fn__196000196_A_fn_class



			if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_test_test_vars_fn__196000196_A_fn_class = fncls__30d; tmp12 = fncls__30d } else { tmp12 = fncls__30 }
//line :709:1
			tmp10.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))
//line :706:1
			seq_196000176__2, chunk_196000177__3, count_196000178__4, i_196000179__5 = lang.IFn_Cast(A_arbace_test_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_196000176__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :701:1*/panic("j2g: unreachable") }








func A_arbace_test_test_vars_fn__196000183_A_New_O_O(p0, p1 any) *A_arbace_test_test_vars_fn__196000183_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_vars_fn__196000183_A{}; t.Ctor_O_O(p0, p1); return t }
//line :710:1
func (t *A_arbace_test_test_vars_fn__196000183_A) Ctor_O_O(c__vars, c__each_fixture_fn any) { t.F_vars = c__vars; t.F_each_fixture_fn = c__each_fixture_fn }
//line :710:1
func (t *A_arbace_test_test_vars_fn__196000183_A) Invoke_O__O(self any) any { { var seq_196000184__1 any = lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(t.F_vars); var chunk_196000185__2 any; var count_196000186__3 int64 = 0; var i_196000187__4 int64 = 0; L1: for {
										if lang.Numbers_Lt_J_J__Z_NoInit(i_196000187__4, count_196000186__3) { var v__5 any = lang.Indexed_Cast(chunk_196000185__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_196000187__4)); var tmp1 *lang.Keyword = A_arbace_test_A_const_64
											if jrt.J2g_Truth(tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__5))) {
												var tmp2 lang.IFn = lang.IFn_Cast(t.F_each_fixture_fn); var tmp3 any = A_arbace_test_test_vars_fn__196000183_fn__196000188_A_New_O(v__5); var tmp4 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_test_test_vars_fn__196000183_fn__196000188_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_test_test_vars_fn__196000183_fn__196000188_A_fn_class = fncls__25d; tmp4 = fncls__25d } else { tmp4 = fncls__25 }; tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :711:1
		seq_196000184__1, chunk_196000185__2, count_196000186__3, i_196000187__4 = seq_196000184__1, chunk_196000185__2, count_196000186__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_196000187__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(seq_196000184__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_196000184__6 any = temp__1927000414__auto____5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_test_A_const_183.GetRawRoot__O()).Invoke_O__O(seq_196000184__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_test_A_const_184.GetRawRoot__O()).Invoke_O__O(seq_196000184__6); seq_196000184__1, chunk_196000185__2, count_196000186__3, i_196000187__4 = lang.IFn_Cast(A_arbace_test_A_const_190.GetRawRoot__O()).Invoke_O__O(seq_196000184__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var v__7 any = lang.IFn_Cast(A_arbace_test_A_const_21.GetRawRoot__O()).Invoke_O__O(seq_196000184__6); var tmp5 *lang.Keyword = A_arbace_test_A_const_64
			if jrt.J2g_Truth(tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__7))) {
				var tmp6 lang.IFn = lang.IFn_Cast(t.F_each_fixture_fn); var tmp7 any = A_arbace_test_test_vars_fn__196000183_fn__196000190_A_New_O(v__7); var tmp8 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_test_test_vars_fn__196000183_fn__196000190_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_test_test_vars_fn__196000183_fn__196000190_A_fn_class = fncls__26d; tmp8 = fncls__26d } else { tmp8 = fncls__26 }; tmp6.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)) }
//line :711:1
			seq_196000184__1, chunk_196000185__2, count_196000186__3, i_196000187__4 = lang.IFn_Cast(A_arbace_test_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_196000184__6), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :710:1*/panic("j2g: unreachable") }
//line :710:1
func A_arbace_test_test_vars_fn__196000196_A_New_O_O(p0, p1 any) *A_arbace_test_test_vars_fn__196000196_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_vars_fn__196000196_A{}; t.Ctor_O_O(p0, p1); return t }
//line :710:1
func (t *A_arbace_test_test_vars_fn__196000196_A) Ctor_O_O(c__vars, c__each_fixture_fn any) { t.F_vars = c__vars; t.F_each_fixture_fn = c__each_fixture_fn }
//line :710:1
func (t *A_arbace_test_test_vars_fn__196000196_A) Invoke_O__O(self any) any { { var seq_196000197__1 any = lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(t.F_vars); var chunk_196000198__2 any; var count_196000199__3 int64 = 0; var i_196000200__4 int64 = 0; L1: for {
										if lang.Numbers_Lt_J_J__Z_NoInit(i_196000200__4, count_196000199__3) { var v__5 any = lang.Indexed_Cast(chunk_196000198__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_196000200__4)); var tmp1 *lang.Keyword = A_arbace_test_A_const_64
											if jrt.J2g_Truth(tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__5))) {
												var tmp2 lang.IFn = lang.IFn_Cast(t.F_each_fixture_fn); var tmp3 any = A_arbace_test_test_vars_fn__196000196_fn__196000201_A_New_O(v__5); var tmp4 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_test_test_vars_fn__196000196_fn__196000201_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_test_test_vars_fn__196000196_fn__196000201_A_fn_class = fncls__28d; tmp4 = fncls__28d } else { tmp4 = fncls__28 }; tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :711:1
		seq_196000197__1, chunk_196000198__2, count_196000199__3, i_196000200__4 = seq_196000197__1, chunk_196000198__2, count_196000199__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_196000200__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(seq_196000197__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_196000197__6 any = temp__1927000414__auto____5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_test_A_const_183.GetRawRoot__O()).Invoke_O__O(seq_196000197__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_test_A_const_184.GetRawRoot__O()).Invoke_O__O(seq_196000197__6); seq_196000197__1, chunk_196000198__2, count_196000199__3, i_196000200__4 = lang.IFn_Cast(A_arbace_test_A_const_190.GetRawRoot__O()).Invoke_O__O(seq_196000197__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var v__7 any = lang.IFn_Cast(A_arbace_test_A_const_21.GetRawRoot__O()).Invoke_O__O(seq_196000197__6); var tmp5 *lang.Keyword = A_arbace_test_A_const_64
			if jrt.J2g_Truth(tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__7))) {
				var tmp6 lang.IFn = lang.IFn_Cast(t.F_each_fixture_fn); var tmp7 any = A_arbace_test_test_vars_fn__196000196_fn__196000203_A_New_O(v__7); var tmp8 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_test_test_vars_fn__196000196_fn__196000203_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_test_test_vars_fn__196000196_fn__196000203_A_fn_class = fncls__29d; tmp8 = fncls__29d } else { tmp8 = fncls__29 }; tmp6.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)) }
//line :711:1
			seq_196000197__1, chunk_196000198__2, count_196000199__3, i_196000200__4 = lang.IFn_Cast(A_arbace_test_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_196000197__6), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :710:1*/panic("j2g: unreachable") }


func A_arbace_test_test_vars_fn__196000183_fn__196000188_A_New_O(p0 any) *A_arbace_test_test_vars_fn__196000183_fn__196000188_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_vars_fn__196000183_fn__196000188_A{}; t.Ctor_O(p0); return t }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000183_fn__196000188_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000183_fn__196000188_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_test_A_const_189.Get__O()).Invoke_O__O(t.F_v) }
//line :713:1
func A_arbace_test_test_vars_fn__196000183_fn__196000190_A_New_O(p0 any) *A_arbace_test_test_vars_fn__196000183_fn__196000190_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_vars_fn__196000183_fn__196000190_A{}; t.Ctor_O(p0); return t }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000183_fn__196000190_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000183_fn__196000190_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_test_A_const_189.Get__O()).Invoke_O__O(t.F_v) }
//line :713:1
func A_arbace_test_test_vars_fn__196000196_fn__196000201_A_New_O(p0 any) *A_arbace_test_test_vars_fn__196000196_fn__196000201_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_vars_fn__196000196_fn__196000201_A{}; t.Ctor_O(p0); return t }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000196_fn__196000201_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000196_fn__196000201_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_test_A_const_189.Get__O()).Invoke_O__O(t.F_v) }
//line :713:1
func A_arbace_test_test_vars_fn__196000196_fn__196000203_A_New_O(p0 any) *A_arbace_test_test_vars_fn__196000196_fn__196000203_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_vars_fn__196000196_fn__196000203_A{}; t.Ctor_O(p0); return t }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000196_fn__196000203_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000196_fn__196000203_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_test_A_const_189.Get__O()).Invoke_O__O(t.F_v) }

func A_arbace_test_test_all_vars_A_New() *A_arbace_test_test_all_vars_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_all_vars_A{}; t.Ctor(); return t }
//line :715:1
func (t *A_arbace_test_test_all_vars_A) Ctor() {}
//line :715:1
func (t *A_arbace_test_test_all_vars_A) Invoke_O_O__O(self, ns__0 any) any {



	return lang.IFn_Cast(A_arbace_test_A_const_191.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_192.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_193.GetRawRoot__O()).Invoke_O__O(ns__0)))
}
func A_arbace_test_test_ns_A_New() *A_arbace_test_test_ns_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_ns_A{}; t.Ctor(); return t }
//line :721:1
func (t *A_arbace_test_test_ns_A) Ctor() {}
//line :721:1
func (t *A_arbace_test_test_ns_A) Invoke_O_O__O(self, ns__0 any) any {









	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_31; lang.IFn_Cast(A_arbace_test_A_const_49.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_test_A_const_194.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_195.Get__O())))
//line :721:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var ns_obj__4 any = lang.IFn_Cast(A_arbace_test_A_const_196.GetRawRoot__O()).Invoke_O__O(ns__0)











		lang.IFn_Cast(A_arbace_test_A_const_179.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_A_const_39, A_arbace_test_A_const_199, A_arbace_test_A_const_66, ns_obj__4)))
//line :721:1
		var temp__1927000408__auto____5 any = lang.IFn_Cast(A_arbace_test_A_const_197.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_200.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_65.GetRawRoot__O()).Invoke_O__O(ns_obj__4)), Lit_24))













		if jrt.J2g_Truth(temp__1927000408__auto____5) { var v__6 any = temp__1927000408__auto____5
			lang.IFn_Cast(lang.IFn_Cast(A_arbace_test_A_const_67.GetRawRoot__O()).Invoke_O__O(v__6)).Invoke__O() } else {

				lang.IFn_Cast(A_arbace_test_A_const_198.GetRawRoot__O()).Invoke_O__O(ns_obj__4) }
		lang.IFn_Cast(A_arbace_test_A_const_179.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_A_const_39, A_arbace_test_A_const_201, A_arbace_test_A_const_66, ns_obj__4)))
//line :731:1
		tmp3 = lang.IFn_Cast(A_arbace_test_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_31.Get__O()) }; return nil }(); lang.IFn_Cast(A_arbace_test_A_const_48.GetRawRoot__O()).Invoke__O()
//line :721:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}





















func A_arbace_test_run_tests_A_New() *A_arbace_test_run_tests_A { A_arbace_test_A_Init(); t := &A_arbace_test_run_tests_A{}; t.Ctor(); return t }
//line :744:1
func (t *A_arbace_test_run_tests_A) Ctor() {}
//line :744:1
func (t *A_arbace_test_run_tests_A) DoInvoke_O_O__O(self, namespaces__0 any) any { var summary__2 any = lang.IFn_Cast(A_arbace_test_A_const_156.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_test_A_const_203.GetRawRoot__O(), A_arbace_test_A_const_204.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_25.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_205.GetRawRoot__O(), namespaces__0)), A_arbace_test_A_const_39, A_arbace_test_A_const_202);








	lang.IFn_Cast(A_arbace_test_A_const_179.GetRawRoot__O()).Invoke_O__O(summary__2); return summary__2 }
//line :744:1
func (t *A_arbace_test_run_tests_A) Invoke_O__O(self any) any {




	return lang.IFn_Cast(A_arbace_test_A_const_206.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_172.Get__O())
}





func A_arbace_test_run_all_tests_A_New() *A_arbace_test_run_all_tests_A { A_arbace_test_A_Init(); t := &A_arbace_test_run_all_tests_A{}; t.Ctor(); return t }
//line :756:1
func (t *A_arbace_test_run_all_tests_A) Ctor() {}
//line :756:1
func (t *A_arbace_test_run_all_tests_A) Invoke_O_O__O(self, re__0 any) any {






	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_206.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_207.GetRawRoot__O()); var tmp4 any = A_arbace_test_run_all_tests_fn__196000211_A_New_O(re__0); var tmp5 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_test_run_all_tests_fn__196000211_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_test_run_all_tests_fn__196000211_A_fn_class = fncls__31d; tmp5 = fncls__31d } else { tmp5 = fncls__31 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_test_A_const_210.GetRawRoot__O()).Invoke__O())) }
//line :756:1
func (t *A_arbace_test_run_all_tests_A) Invoke_O__O(self any) any {





	return lang.IFn_Cast(A_arbace_test_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_A_const_206.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_A_const_210.GetRawRoot__O()).Invoke__O()) }
func A_arbace_test_run_all_tests_fn__196000211_A_New_O(p0 any) *A_arbace_test_run_all_tests_fn__196000211_A { A_arbace_test_A_Init(); t := &A_arbace_test_run_all_tests_fn__196000211_A{}; t.Ctor_O(p0); return t }
//line :763:1
func (t *A_arbace_test_run_all_tests_fn__196000211_A) Ctor_O(c__re any) { t.F_re = c__re }
//line :763:1
func (t *A_arbace_test_run_all_tests_fn__196000211_A) Invoke_O_O__O(self, p1__196000210_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_208.GetRawRoot__O()); var tmp2 any = t.F_re; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_test_A_const_209.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_65.GetRawRoot__O()).Invoke_O__O(p1__196000210_SHARP___1))) }

func A_arbace_test_successful_QMARK__A_New() *A_arbace_test_successful_QMARK__A { A_arbace_test_A_Init(); t := &A_arbace_test_successful_QMARK__A{}; t.Ctor(); return t }
//line :765:1
func (t *A_arbace_test_successful_QMARK__A) Ctor() {}
//line :765:1
func (t *A_arbace_test_successful_QMARK__A) Invoke_O_O__O(self, summary__0 any) any { var and__1927000168__auto____2 bool; var na_32 any = A_arbace_test_A_const_42.Invoke_O_O__O(summary__0, A_arbace_test_A_const_35); if




	jrt.Long_InstanceOf(na_32) { var n0_33 int64 = jrt.NN(jrt.Long_Cast(na_32)).LongValue__J(); and__1927000168__auto____2 = n0_33 == 0 } else { if jrt.Double_InstanceOf(na_32) { var n0_33_2 float64 = jrt.NN(jrt.Double_Cast(na_32)).DoubleValue__D(); and__1927000168__auto____2 = n0_33_2 == 0.0 } else { and__1927000168__auto____2 = lang.Numbers_IsZero_O__Z_NoInit(na_32) } }; if and__1927000168__auto____2 {
		var tmp1 bool; var na_34 any = A_arbace_test_A_const_40.Invoke_O_O__O(summary__0, A_arbace_test_A_const_35); if jrt.Long_InstanceOf(na_34) { var n0_35 int64 = jrt.NN(jrt.Long_Cast(na_34)).LongValue__J(); tmp1 = n0_35 == 0 } else { if jrt.Double_InstanceOf(na_34) { var n0_35_2 float64 = jrt.NN(jrt.Double_Cast(na_34)).DoubleValue__D(); tmp1 = n0_35_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_34) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() } else {
//line :770:1
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }


func A_arbace_test_run_test_var_A_New() *A_arbace_test_run_test_var_A { A_arbace_test_A_Init(); t := &A_arbace_test_run_test_var_A{}; t.Ctor(); return t }
//line :773:1
func (t *A_arbace_test_run_test_var_A) Ctor() {}
//line :773:1
func (t *A_arbace_test_run_test_var_A) Invoke_O_O__O(self, v__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_31; lang.IFn_Cast(A_arbace_test_A_const_49.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_test_A_const_194.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_195.Get__O())))
//line :773:1
	var tmp3 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Keyword = A_arbace_test_A_const_66; var ns_obj__4 any = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__0)); var summary__5 any






		lang.IFn_Cast(A_arbace_test_A_const_179.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_A_const_39, A_arbace_test_A_const_199, A_arbace_test_A_const_66, ns_obj__4)))

		lang.IFn_Cast(A_arbace_test_A_const_191.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O__IPersistentVector(v__0))
		lang.IFn_Cast(A_arbace_test_A_const_179.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_A_const_39, A_arbace_test_A_const_201, A_arbace_test_A_const_66, ns_obj__4)))

		summary__5 = lang.IFn_Cast(A_arbace_test_A_const_156.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_31.Get__O()), A_arbace_test_A_const_39, A_arbace_test_A_const_202)
		lang.IFn_Cast(A_arbace_test_A_const_179.GetRawRoot__O()).Invoke_O__O(summary__5)
//line :773:1
		tmp3 = summary__5 }; return nil }()



	lang.IFn_Cast(A_arbace_test_A_const_48.GetRawRoot__O()).Invoke__O()
//line :773:1
	if tmp5 != nil { panic(tmp5) }; return tmp3
}














func A_arbace_test_run_test_A_New() *A_arbace_test_run_test_A { A_arbace_test_A_Init(); t := &A_arbace_test_run_test_A{}; t.Ctor(); return t }
//line :789:1
func (t *A_arbace_test_run_test_A) Ctor() {}
//line :789:1
func (t *A_arbace_test_run_test_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, test_symbol__2 any) any { var test_var__4 any = lang.IFn_Cast(A_arbace_test_A_const_69.GetRawRoot__O()).Invoke_O__O(test_symbol__2); if






	lang.Util_Identical_O_O__Z_NoInit(test_var__4, nil) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_51; lang.IFn_Cast(A_arbace_test_A_const_49.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_A_const_211.Get__O()))
//line :796:1
		var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


			tmp3 = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O_O_O__O(Lit_21, test_symbol__2, Lit_22)
//line :796:1
			return nil
		}()
		lang.IFn_Cast(A_arbace_test_A_const_48.GetRawRoot__O()).Invoke__O()
//line :796:1
		if tmp4 != nil { panic(tmp4) }; return tmp3 } else { var tmp5 *lang.Keyword = A_arbace_test_A_const_64; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_test_A_const_72.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(test_var__4)))) {





			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp7 any = A_arbace_test_A_const_51; lang.IFn_Cast(A_arbace_test_A_const_49.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O_O__O(tmp7, A_arbace_test_A_const_211.Get__O()))
//line :796:1
			var tmp8 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






				tmp8 = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O_O__O(test_symbol__2, Lit_23)
//line :796:1
				return nil
			}()




			lang.IFn_Cast(A_arbace_test_A_const_48.GetRawRoot__O()).Invoke__O()
//line :796:1
			if tmp9 != nil { panic(tmp9) }; return tmp8 } else { if A_arbace_test_A_const_95 != nil { return lang.IFn_Cast(A_arbace_test_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_212), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(test_var__4))) } else { return nil } } } }















type A_arbace_test_A struct{ jrt.Object }

var A_arbace_test_A_const_pool *jrt.RefArray

var A_arbace_test_A_const_0 *lang.Var

var A_arbace_test_A_const_1 *lang.Var

var A_arbace_test_A_const_2 any

var A_arbace_test_A_const_3 any

var A_arbace_test_A_const_4 any

var A_arbace_test_A_const_5 any

var A_arbace_test_A_const_6 *lang.Var

var A_arbace_test_A_const_7 *lang.Var

var A_arbace_test_A_const_8 *lang.Var

var A_arbace_test_A_const_9 any

var A_arbace_test_A_const_10 *lang.Var

var A_arbace_test_A_const_11 *lang.Var

var A_arbace_test_A_const_12 *lang.Var

var A_arbace_test_A_const_13 *lang.Var

var A_arbace_test_A_const_14 any

var A_arbace_test_A_const_15 *lang.Var

var A_arbace_test_A_const_16 *lang.Var

var A_arbace_test_A_const_17 any

var A_arbace_test_A_const_18 any

var A_arbace_test_A_const_19 *lang.Var

var A_arbace_test_A_const_20 *lang.Var

var A_arbace_test_A_const_21 *lang.Var

var A_arbace_test_A_const_22 *lang.Keyword

var A_arbace_test_A_const_23 *lang.Keyword

var A_arbace_test_A_const_24 *lang.Var

var A_arbace_test_A_const_25 *lang.Var

var A_arbace_test_A_const_26 *lang.Keyword

var A_arbace_test_A_const_27 *lang.Var

var A_arbace_test_A_const_28 *lang.Var

var A_arbace_test_A_const_29 *lang.Var

var A_arbace_test_A_const_30 *lang.Var

var A_arbace_test_A_const_31 *lang.Var

var A_arbace_test_A_const_32 *lang.Var

var A_arbace_test_A_const_33 *lang.Var

var A_arbace_test_A_const_34 *lang.Var

var A_arbace_test_A_const_35 any

var A_arbace_test_A_const_36 any

var A_arbace_test_A_const_37 any

var A_arbace_test_A_const_38 *lang.Var

var A_arbace_test_A_const_39 *lang.Keyword

var A_arbace_test_A_const_40 *lang.Keyword

var A_arbace_test_A_const_41 *lang.Var

var A_arbace_test_A_const_42 *lang.Keyword

var A_arbace_test_A_const_43 *lang.Var

var A_arbace_test_A_const_44 *lang.Keyword

var A_arbace_test_A_const_45 *lang.Var

var A_arbace_test_A_const_46 *lang.Var

var A_arbace_test_A_const_47 *lang.Var

var A_arbace_test_A_const_48 *lang.Var

var A_arbace_test_A_const_49 *lang.Var

var A_arbace_test_A_const_50 *lang.Var

var A_arbace_test_A_const_51 *lang.Var

var A_arbace_test_A_const_52 *lang.Var

var A_arbace_test_A_const_53 *lang.Var

var A_arbace_test_A_const_54 *lang.Keyword

var A_arbace_test_A_const_55 *lang.Var

var A_arbace_test_A_const_56 *lang.Keyword

var A_arbace_test_A_const_57 *lang.Var

var A_arbace_test_A_const_58 *lang.Var

var A_arbace_test_A_const_59 *lang.Var

var A_arbace_test_A_const_60 *lang.Keyword

var A_arbace_test_A_const_61 *lang.Var

var A_arbace_test_A_const_62 *lang.Var

var A_arbace_test_A_const_63 *lang.Var

var A_arbace_test_A_const_64 *lang.Keyword

var A_arbace_test_A_const_65 *lang.Var

var A_arbace_test_A_const_66 *lang.Keyword

var A_arbace_test_A_const_67 *lang.Var

var A_arbace_test_A_const_68 *lang.Var

var A_arbace_test_A_const_69 *lang.Var

var A_arbace_test_A_const_70 *lang.Var

var A_arbace_test_A_const_71 *lang.Var

var A_arbace_test_A_const_72 *lang.Var

var A_arbace_test_A_const_73 *lang.Keyword

var A_arbace_test_A_const_74 *lang.Var

var A_arbace_test_A_const_75 any

var A_arbace_test_A_const_76 any

var A_arbace_test_A_const_77 any

var A_arbace_test_A_const_78 any

var A_arbace_test_A_const_79 any

var A_arbace_test_A_const_80 any

var A_arbace_test_A_const_81 any

var A_arbace_test_A_const_82 any

var A_arbace_test_A_const_83 any

var A_arbace_test_A_const_84 any

var A_arbace_test_A_const_85 any

var A_arbace_test_A_const_86 any

var A_arbace_test_A_const_87 any

var A_arbace_test_A_const_88 any

var A_arbace_test_A_const_89 any

var A_arbace_test_A_const_90 any

var A_arbace_test_A_const_91 any

var A_arbace_test_A_const_92 any

var A_arbace_test_A_const_93 *lang.Keyword

var A_arbace_test_A_const_94 *lang.Var

var A_arbace_test_A_const_95 *lang.Keyword

var A_arbace_test_A_const_96 *lang.Keyword

var A_arbace_test_A_const_97 any

var A_arbace_test_A_const_98 *lang.Var

var A_arbace_test_A_const_99 *lang.Var

var A_arbace_test_A_const_100 *lang.Var

var A_arbace_test_A_const_101 *lang.Var

var A_arbace_test_A_const_102 any

var A_arbace_test_A_const_103 any

var A_arbace_test_A_const_104 any

var A_arbace_test_A_const_105 any

var A_arbace_test_A_const_106 any

var A_arbace_test_A_const_107 any

var A_arbace_test_A_const_108 any

var A_arbace_test_A_const_109 any

var A_arbace_test_A_const_110 any

var A_arbace_test_A_const_111 any

var A_arbace_test_A_const_112 any

var A_arbace_test_A_const_113 *lang.Var

var A_arbace_test_A_const_114 *lang.Var

var A_arbace_test_A_const_115 any

var A_arbace_test_A_const_116 any

var A_arbace_test_A_const_117 any

var A_arbace_test_A_const_118 any

var A_arbace_test_A_const_119 any

var A_arbace_test_A_const_120 any

var A_arbace_test_A_const_121 any

var A_arbace_test_A_const_122 any

var A_arbace_test_A_const_123 any

var A_arbace_test_A_const_124 any

var A_arbace_test_A_const_125 any

var A_arbace_test_A_const_126 any

var A_arbace_test_A_const_127 any

var A_arbace_test_A_const_128 any

var A_arbace_test_A_const_129 any

var A_arbace_test_A_const_130 any

var A_arbace_test_A_const_131 any

var A_arbace_test_A_const_132 any

var A_arbace_test_A_const_133 any

var A_arbace_test_A_const_134 *lang.Var

var A_arbace_test_A_const_135 any

var A_arbace_test_A_const_136 any

var A_arbace_test_A_const_137 any

var A_arbace_test_A_const_138 any

var A_arbace_test_A_const_139 any

var A_arbace_test_A_const_140 any

var A_arbace_test_A_const_141 *lang.Var

var A_arbace_test_A_const_142 *lang.Var

var A_arbace_test_A_const_143 any

var A_arbace_test_A_const_144 any

var A_arbace_test_A_const_145 any

var A_arbace_test_A_const_146 any

var A_arbace_test_A_const_147 any

var A_arbace_test_A_const_148 any

var A_arbace_test_A_const_149 *lang.Var

var A_arbace_test_A_const_150 any

var A_arbace_test_A_const_151 any

var A_arbace_test_A_const_152 any

var A_arbace_test_A_const_153 any

var A_arbace_test_A_const_154 any

var A_arbace_test_A_const_155 *lang.Var

var A_arbace_test_A_const_156 *lang.Var

var A_arbace_test_A_const_157 any

var A_arbace_test_A_const_158 any

var A_arbace_test_A_const_159 any

var A_arbace_test_A_const_160 any

var A_arbace_test_A_const_161 any

var A_arbace_test_A_const_162 *lang.Keyword

var A_arbace_test_A_const_163 any

var A_arbace_test_A_const_164 any

var A_arbace_test_A_const_165 any

var A_arbace_test_A_const_166 any

var A_arbace_test_A_const_167 any

var A_arbace_test_A_const_168 any

var A_arbace_test_A_const_169 any

var A_arbace_test_A_const_170 any

var A_arbace_test_A_const_171 *lang.Var

var A_arbace_test_A_const_172 *lang.Var

var A_arbace_test_A_const_173 *lang.Var

var A_arbace_test_A_const_174 *lang.Keyword

var A_arbace_test_A_const_175 *lang.Keyword

var A_arbace_test_A_const_176 *lang.Var

var A_arbace_test_A_const_177 *lang.Var

var A_arbace_test_A_const_178 *lang.Var

var A_arbace_test_A_const_179 *lang.Var

var A_arbace_test_A_const_180 *lang.Keyword

var A_arbace_test_A_const_181 *lang.Keyword

var A_arbace_test_A_const_182 *lang.Keyword

var A_arbace_test_A_const_183 *lang.Var

var A_arbace_test_A_const_184 *lang.Var

var A_arbace_test_A_const_185 *lang.Var

var A_arbace_test_A_const_186 *lang.Var

var A_arbace_test_A_const_187 *lang.Var

var A_arbace_test_A_const_188 *lang.Var

var A_arbace_test_A_const_189 *lang.Var

var A_arbace_test_A_const_190 *lang.Var

var A_arbace_test_A_const_191 *lang.Var

var A_arbace_test_A_const_192 *lang.Var

var A_arbace_test_A_const_193 *lang.Var

var A_arbace_test_A_const_194 *lang.Var

var A_arbace_test_A_const_195 *lang.Var

var A_arbace_test_A_const_196 *lang.Var

var A_arbace_test_A_const_197 *lang.Var

var A_arbace_test_A_const_198 *lang.Var

var A_arbace_test_A_const_199 *lang.Keyword

var A_arbace_test_A_const_200 *lang.Var

var A_arbace_test_A_const_201 *lang.Keyword

var A_arbace_test_A_const_202 *lang.Keyword

var A_arbace_test_A_const_203 *lang.Var

var A_arbace_test_A_const_204 *lang.Var

var A_arbace_test_A_const_205 *lang.Var

var A_arbace_test_A_const_206 *lang.Var

var A_arbace_test_A_const_207 *lang.Var

var A_arbace_test_A_const_208 *lang.Var

var A_arbace_test_A_const_209 *lang.Var

var A_arbace_test_A_const_210 *lang.Var

var A_arbace_test_A_const_211 *lang.Var

var A_arbace_test_A_const_212 any

var A_arbace_test_A_init jrt.ClassInit

func A_arbace_test_A_Init() { if !A_arbace_test_A_init.Done() { A_arbace_test_A_init.Run(A_arbace_test_A_clinit) } }

func A_arbace_test_A_clinit() { A_arbace_test_A_clinit_p0(); A_arbace_test_A_clinit_p1(); A_arbace_test_A_clinit_p2(); A_arbace_test_A_clinit_p3(); A_arbace_test_A_clinit_p4(); A_arbace_test_A_clinit_p5(); A_arbace_test_A_clinit_p6(); A_arbace_test_A_clinit_p7(); A_arbace_test_A_clinit_p8(); A_arbace_test_A_clinit_p9(); A_arbace_test_A_clinit_p10(); A_arbace_test_A_clinit_p11(); A_arbace_test_A_clinit_p12(); A_arbace_test_A_clinit_p13(); A_arbace_test_A_clinit_p14(); A_arbace_test_A_clinit_p15(); A_arbace_test_A_clinit_p16() }

func A_arbace_test_A_clinit_p0() { jrt.StartCheck(); A_arbace_test_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 289); A_arbace_test_A_const_0 = lang.Var_Cast(A_arbace_test_A_const_pool.A[76]); A_arbace_test_A_const_1 = lang.Var_Cast(A_arbace_test_A_const_pool.A[77]); A_arbace_test_A_const_2 = A_arbace_test_A_const_pool.A[78]; A_arbace_test_A_const_3 = A_arbace_test_A_const_pool.A[79]; A_arbace_test_A_const_4 = A_arbace_test_A_const_pool.A[80]; A_arbace_test_A_const_5 = A_arbace_test_A_const_pool.A[81]; A_arbace_test_A_const_6 = lang.Var_Cast(A_arbace_test_A_const_pool.A[82]); A_arbace_test_A_const_7 = lang.Var_Cast(A_arbace_test_A_const_pool.A[83]); A_arbace_test_A_const_8 = lang.Var_Cast(A_arbace_test_A_const_pool.A[84]); A_arbace_test_A_const_9 = A_arbace_test_A_const_pool.A[85]; A_arbace_test_A_const_10 = lang.Var_Cast(A_arbace_test_A_const_pool.A[86]); A_arbace_test_A_const_11 = lang.Var_Cast(A_arbace_test_A_const_pool.A[87]) }

func A_arbace_test_A_clinit_p1() { A_arbace_test_A_const_12 = lang.Var_Cast(A_arbace_test_A_const_pool.A[88]); A_arbace_test_A_const_13 = lang.Var_Cast(A_arbace_test_A_const_pool.A[89]); A_arbace_test_A_const_14 = A_arbace_test_A_const_pool.A[90]; A_arbace_test_A_const_15 = lang.Var_Cast(A_arbace_test_A_const_pool.A[91]); A_arbace_test_A_const_16 = lang.Var_Cast(A_arbace_test_A_const_pool.A[92]); A_arbace_test_A_const_17 = A_arbace_test_A_const_pool.A[93]; A_arbace_test_A_const_18 = A_arbace_test_A_const_pool.A[94]; A_arbace_test_A_const_19 = lang.Var_Cast(A_arbace_test_A_const_pool.A[95]); A_arbace_test_A_const_20 = lang.Var_Cast(A_arbace_test_A_const_pool.A[96]); A_arbace_test_A_const_21 = lang.Var_Cast(A_arbace_test_A_const_pool.A[97]); A_arbace_test_A_const_22 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[98]); A_arbace_test_A_const_23 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[99]) }

func A_arbace_test_A_clinit_p2() { A_arbace_test_A_const_24 = lang.Var_Cast(A_arbace_test_A_const_pool.A[100]); A_arbace_test_A_const_25 = lang.Var_Cast(A_arbace_test_A_const_pool.A[101]); A_arbace_test_A_const_26 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[102]); A_arbace_test_A_const_27 = lang.Var_Cast(A_arbace_test_A_const_pool.A[103]); A_arbace_test_A_const_28 = lang.Var_Cast(A_arbace_test_A_const_pool.A[104]); A_arbace_test_A_const_29 = lang.Var_Cast(A_arbace_test_A_const_pool.A[105]); A_arbace_test_A_const_30 = lang.Var_Cast(A_arbace_test_A_const_pool.A[106]); A_arbace_test_A_const_31 = lang.Var_Cast(A_arbace_test_A_const_pool.A[107]); A_arbace_test_A_const_32 = lang.Var_Cast(A_arbace_test_A_const_pool.A[108]); A_arbace_test_A_const_33 = lang.Var_Cast(A_arbace_test_A_const_pool.A[109]); A_arbace_test_A_const_34 = lang.Var_Cast(A_arbace_test_A_const_pool.A[110]); A_arbace_test_A_const_35 = A_arbace_test_A_const_pool.A[111] }

func A_arbace_test_A_clinit_p3() { A_arbace_test_A_const_36 = A_arbace_test_A_const_pool.A[112]; A_arbace_test_A_const_37 = A_arbace_test_A_const_pool.A[113]; A_arbace_test_A_const_38 = lang.Var_Cast(A_arbace_test_A_const_pool.A[114]); A_arbace_test_A_const_39 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[115]); A_arbace_test_A_const_40 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[116]); A_arbace_test_A_const_41 = lang.Var_Cast(A_arbace_test_A_const_pool.A[117]); A_arbace_test_A_const_42 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[118]); A_arbace_test_A_const_43 = lang.Var_Cast(A_arbace_test_A_const_pool.A[119]); A_arbace_test_A_const_44 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[120]); A_arbace_test_A_const_45 = lang.Var_Cast(A_arbace_test_A_const_pool.A[121]); A_arbace_test_A_const_46 = lang.Var_Cast(A_arbace_test_A_const_pool.A[122]); A_arbace_test_A_const_47 = lang.Var_Cast(A_arbace_test_A_const_pool.A[123]) }

func A_arbace_test_A_clinit_p4() { A_arbace_test_A_const_48 = lang.Var_Cast(A_arbace_test_A_const_pool.A[124]); A_arbace_test_A_const_49 = lang.Var_Cast(A_arbace_test_A_const_pool.A[125]); A_arbace_test_A_const_50 = lang.Var_Cast(A_arbace_test_A_const_pool.A[126]); A_arbace_test_A_const_51 = lang.Var_Cast(A_arbace_test_A_const_pool.A[127]); A_arbace_test_A_const_52 = lang.Var_Cast(A_arbace_test_A_const_pool.A[128]); A_arbace_test_A_const_53 = lang.Var_Cast(A_arbace_test_A_const_pool.A[129]); A_arbace_test_A_const_54 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[130]); A_arbace_test_A_const_55 = lang.Var_Cast(A_arbace_test_A_const_pool.A[131]); A_arbace_test_A_const_56 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[132]); A_arbace_test_A_const_57 = lang.Var_Cast(A_arbace_test_A_const_pool.A[133]); A_arbace_test_A_const_58 = lang.Var_Cast(A_arbace_test_A_const_pool.A[134]); A_arbace_test_A_const_59 = lang.Var_Cast(A_arbace_test_A_const_pool.A[135]) }

func A_arbace_test_A_clinit_p5() { A_arbace_test_A_const_60 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[136]); A_arbace_test_A_const_61 = lang.Var_Cast(A_arbace_test_A_const_pool.A[137]); A_arbace_test_A_const_62 = lang.Var_Cast(A_arbace_test_A_const_pool.A[138]); A_arbace_test_A_const_63 = lang.Var_Cast(A_arbace_test_A_const_pool.A[139]); A_arbace_test_A_const_64 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[140]); A_arbace_test_A_const_65 = lang.Var_Cast(A_arbace_test_A_const_pool.A[141]); A_arbace_test_A_const_66 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[142]); A_arbace_test_A_const_67 = lang.Var_Cast(A_arbace_test_A_const_pool.A[143]); A_arbace_test_A_const_68 = lang.Var_Cast(A_arbace_test_A_const_pool.A[144]); A_arbace_test_A_const_69 = lang.Var_Cast(A_arbace_test_A_const_pool.A[145]); A_arbace_test_A_const_70 = lang.Var_Cast(A_arbace_test_A_const_pool.A[146]); A_arbace_test_A_const_71 = lang.Var_Cast(A_arbace_test_A_const_pool.A[147]) }

func A_arbace_test_A_clinit_p6() { A_arbace_test_A_const_72 = lang.Var_Cast(A_arbace_test_A_const_pool.A[148]); A_arbace_test_A_const_73 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[149]); A_arbace_test_A_const_74 = lang.Var_Cast(A_arbace_test_A_const_pool.A[150]); A_arbace_test_A_const_75 = A_arbace_test_A_const_pool.A[151]; A_arbace_test_A_const_76 = A_arbace_test_A_const_pool.A[152]; A_arbace_test_A_const_77 = A_arbace_test_A_const_pool.A[153]; A_arbace_test_A_const_78 = A_arbace_test_A_const_pool.A[154]; A_arbace_test_A_const_79 = A_arbace_test_A_const_pool.A[155]; A_arbace_test_A_const_80 = A_arbace_test_A_const_pool.A[156]; A_arbace_test_A_const_81 = A_arbace_test_A_const_pool.A[157]; A_arbace_test_A_const_82 = A_arbace_test_A_const_pool.A[158]; A_arbace_test_A_const_83 = A_arbace_test_A_const_pool.A[159]; A_arbace_test_A_const_84 = A_arbace_test_A_const_pool.A[160]; A_arbace_test_A_const_85 = A_arbace_test_A_const_pool.A[161]; A_arbace_test_A_const_86 = A_arbace_test_A_const_pool.A[162] }

func A_arbace_test_A_clinit_p7() { A_arbace_test_A_const_87 = A_arbace_test_A_const_pool.A[163]; A_arbace_test_A_const_88 = A_arbace_test_A_const_pool.A[164]; A_arbace_test_A_const_89 = A_arbace_test_A_const_pool.A[165]; A_arbace_test_A_const_90 = A_arbace_test_A_const_pool.A[166]; A_arbace_test_A_const_91 = A_arbace_test_A_const_pool.A[167]; A_arbace_test_A_const_92 = A_arbace_test_A_const_pool.A[168]; A_arbace_test_A_const_93 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[169]); A_arbace_test_A_const_94 = lang.Var_Cast(A_arbace_test_A_const_pool.A[170]); A_arbace_test_A_const_95 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[171]); A_arbace_test_A_const_96 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[172]); A_arbace_test_A_const_97 = A_arbace_test_A_const_pool.A[173]; A_arbace_test_A_const_98 = lang.Var_Cast(A_arbace_test_A_const_pool.A[174]); A_arbace_test_A_const_99 = lang.Var_Cast(A_arbace_test_A_const_pool.A[175]) }

func A_arbace_test_A_clinit_p8() { A_arbace_test_A_const_100 = lang.Var_Cast(A_arbace_test_A_const_pool.A[176]); A_arbace_test_A_const_101 = lang.Var_Cast(A_arbace_test_A_const_pool.A[177]); A_arbace_test_A_const_102 = A_arbace_test_A_const_pool.A[178]; A_arbace_test_A_const_103 = A_arbace_test_A_const_pool.A[179]; A_arbace_test_A_const_104 = A_arbace_test_A_const_pool.A[180]; A_arbace_test_A_const_105 = A_arbace_test_A_const_pool.A[181]; A_arbace_test_A_const_106 = A_arbace_test_A_const_pool.A[182]; A_arbace_test_A_const_107 = A_arbace_test_A_const_pool.A[183]; A_arbace_test_A_const_108 = A_arbace_test_A_const_pool.A[184]; A_arbace_test_A_const_109 = A_arbace_test_A_const_pool.A[185]; A_arbace_test_A_const_110 = A_arbace_test_A_const_pool.A[186]; A_arbace_test_A_const_111 = A_arbace_test_A_const_pool.A[187]; A_arbace_test_A_const_112 = A_arbace_test_A_const_pool.A[188]; A_arbace_test_A_const_113 = lang.Var_Cast(A_arbace_test_A_const_pool.A[189]) }

func A_arbace_test_A_clinit_p9() { A_arbace_test_A_const_114 = lang.Var_Cast(A_arbace_test_A_const_pool.A[190]); A_arbace_test_A_const_115 = A_arbace_test_A_const_pool.A[191]; A_arbace_test_A_const_116 = A_arbace_test_A_const_pool.A[192]; A_arbace_test_A_const_117 = A_arbace_test_A_const_pool.A[193]; A_arbace_test_A_const_118 = A_arbace_test_A_const_pool.A[194]; A_arbace_test_A_const_119 = A_arbace_test_A_const_pool.A[195]; A_arbace_test_A_const_120 = A_arbace_test_A_const_pool.A[196]; A_arbace_test_A_const_121 = A_arbace_test_A_const_pool.A[197]; A_arbace_test_A_const_122 = A_arbace_test_A_const_pool.A[198]; A_arbace_test_A_const_123 = A_arbace_test_A_const_pool.A[199]; A_arbace_test_A_const_124 = A_arbace_test_A_const_pool.A[200]; A_arbace_test_A_const_125 = A_arbace_test_A_const_pool.A[201]; A_arbace_test_A_const_126 = A_arbace_test_A_const_pool.A[202]; A_arbace_test_A_const_127 = A_arbace_test_A_const_pool.A[203]; A_arbace_test_A_const_128 = A_arbace_test_A_const_pool.A[204] }

func A_arbace_test_A_clinit_p10() { A_arbace_test_A_const_129 = A_arbace_test_A_const_pool.A[205]; A_arbace_test_A_const_130 = A_arbace_test_A_const_pool.A[206]; A_arbace_test_A_const_131 = A_arbace_test_A_const_pool.A[207]; A_arbace_test_A_const_132 = A_arbace_test_A_const_pool.A[208]; A_arbace_test_A_const_133 = A_arbace_test_A_const_pool.A[209]; A_arbace_test_A_const_134 = lang.Var_Cast(A_arbace_test_A_const_pool.A[210]); A_arbace_test_A_const_135 = A_arbace_test_A_const_pool.A[211]; A_arbace_test_A_const_136 = A_arbace_test_A_const_pool.A[212]; A_arbace_test_A_const_137 = A_arbace_test_A_const_pool.A[213]; A_arbace_test_A_const_138 = A_arbace_test_A_const_pool.A[214]; A_arbace_test_A_const_139 = A_arbace_test_A_const_pool.A[215]; A_arbace_test_A_const_140 = A_arbace_test_A_const_pool.A[216]; A_arbace_test_A_const_141 = lang.Var_Cast(A_arbace_test_A_const_pool.A[217]); A_arbace_test_A_const_142 = lang.Var_Cast(A_arbace_test_A_const_pool.A[218]); A_arbace_test_A_const_143 = A_arbace_test_A_const_pool.A[219] }

func A_arbace_test_A_clinit_p11() { A_arbace_test_A_const_144 = A_arbace_test_A_const_pool.A[220]; A_arbace_test_A_const_145 = A_arbace_test_A_const_pool.A[221]; A_arbace_test_A_const_146 = A_arbace_test_A_const_pool.A[222]; A_arbace_test_A_const_147 = A_arbace_test_A_const_pool.A[223]; A_arbace_test_A_const_148 = A_arbace_test_A_const_pool.A[224]; A_arbace_test_A_const_149 = lang.Var_Cast(A_arbace_test_A_const_pool.A[225]); A_arbace_test_A_const_150 = A_arbace_test_A_const_pool.A[226]; A_arbace_test_A_const_151 = A_arbace_test_A_const_pool.A[227]; A_arbace_test_A_const_152 = A_arbace_test_A_const_pool.A[228]; A_arbace_test_A_const_153 = A_arbace_test_A_const_pool.A[229]; A_arbace_test_A_const_154 = A_arbace_test_A_const_pool.A[230]; A_arbace_test_A_const_155 = lang.Var_Cast(A_arbace_test_A_const_pool.A[231]); A_arbace_test_A_const_156 = lang.Var_Cast(A_arbace_test_A_const_pool.A[232]); A_arbace_test_A_const_157 = A_arbace_test_A_const_pool.A[233]; A_arbace_test_A_const_158 = A_arbace_test_A_const_pool.A[234] }

func A_arbace_test_A_clinit_p12() { A_arbace_test_A_const_159 = A_arbace_test_A_const_pool.A[235]; A_arbace_test_A_const_160 = A_arbace_test_A_const_pool.A[236]; A_arbace_test_A_const_161 = A_arbace_test_A_const_pool.A[237]; A_arbace_test_A_const_162 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[238]); A_arbace_test_A_const_163 = A_arbace_test_A_const_pool.A[239]; A_arbace_test_A_const_164 = A_arbace_test_A_const_pool.A[240]; A_arbace_test_A_const_165 = A_arbace_test_A_const_pool.A[241]; A_arbace_test_A_const_166 = A_arbace_test_A_const_pool.A[242]; A_arbace_test_A_const_167 = A_arbace_test_A_const_pool.A[243]; A_arbace_test_A_const_168 = A_arbace_test_A_const_pool.A[244]; A_arbace_test_A_const_169 = A_arbace_test_A_const_pool.A[245]; A_arbace_test_A_const_170 = A_arbace_test_A_const_pool.A[246]; A_arbace_test_A_const_171 = lang.Var_Cast(A_arbace_test_A_const_pool.A[247]); A_arbace_test_A_const_172 = lang.Var_Cast(A_arbace_test_A_const_pool.A[248]) }

func A_arbace_test_A_clinit_p13() { A_arbace_test_A_const_173 = lang.Var_Cast(A_arbace_test_A_const_pool.A[249]); A_arbace_test_A_const_174 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[250]); A_arbace_test_A_const_175 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[251]); A_arbace_test_A_const_176 = lang.Var_Cast(A_arbace_test_A_const_pool.A[252]); A_arbace_test_A_const_177 = lang.Var_Cast(A_arbace_test_A_const_pool.A[253]); A_arbace_test_A_const_178 = lang.Var_Cast(A_arbace_test_A_const_pool.A[254]); A_arbace_test_A_const_179 = lang.Var_Cast(A_arbace_test_A_const_pool.A[255]); A_arbace_test_A_const_180 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[256]); A_arbace_test_A_const_181 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[257]); A_arbace_test_A_const_182 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[258]); A_arbace_test_A_const_183 = lang.Var_Cast(A_arbace_test_A_const_pool.A[259]); A_arbace_test_A_const_184 = lang.Var_Cast(A_arbace_test_A_const_pool.A[260]) }

func A_arbace_test_A_clinit_p14() { A_arbace_test_A_const_185 = lang.Var_Cast(A_arbace_test_A_const_pool.A[261]); A_arbace_test_A_const_186 = lang.Var_Cast(A_arbace_test_A_const_pool.A[262]); A_arbace_test_A_const_187 = lang.Var_Cast(A_arbace_test_A_const_pool.A[263]); A_arbace_test_A_const_188 = lang.Var_Cast(A_arbace_test_A_const_pool.A[264]); A_arbace_test_A_const_189 = lang.Var_Cast(A_arbace_test_A_const_pool.A[265]); A_arbace_test_A_const_190 = lang.Var_Cast(A_arbace_test_A_const_pool.A[266]); A_arbace_test_A_const_191 = lang.Var_Cast(A_arbace_test_A_const_pool.A[267]); A_arbace_test_A_const_192 = lang.Var_Cast(A_arbace_test_A_const_pool.A[268]); A_arbace_test_A_const_193 = lang.Var_Cast(A_arbace_test_A_const_pool.A[269]); A_arbace_test_A_const_194 = lang.Var_Cast(A_arbace_test_A_const_pool.A[270]); A_arbace_test_A_const_195 = lang.Var_Cast(A_arbace_test_A_const_pool.A[271]); A_arbace_test_A_const_196 = lang.Var_Cast(A_arbace_test_A_const_pool.A[272]) }

func A_arbace_test_A_clinit_p15() { A_arbace_test_A_const_197 = lang.Var_Cast(A_arbace_test_A_const_pool.A[273]); A_arbace_test_A_const_198 = lang.Var_Cast(A_arbace_test_A_const_pool.A[274]); A_arbace_test_A_const_199 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[275]); A_arbace_test_A_const_200 = lang.Var_Cast(A_arbace_test_A_const_pool.A[276]); A_arbace_test_A_const_201 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[277]); A_arbace_test_A_const_202 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[278]); A_arbace_test_A_const_203 = lang.Var_Cast(A_arbace_test_A_const_pool.A[279]); A_arbace_test_A_const_204 = lang.Var_Cast(A_arbace_test_A_const_pool.A[280]); A_arbace_test_A_const_205 = lang.Var_Cast(A_arbace_test_A_const_pool.A[281]); A_arbace_test_A_const_206 = lang.Var_Cast(A_arbace_test_A_const_pool.A[282]); A_arbace_test_A_const_207 = lang.Var_Cast(A_arbace_test_A_const_pool.A[283]); A_arbace_test_A_const_208 = lang.Var_Cast(A_arbace_test_A_const_pool.A[284]) }

func A_arbace_test_A_clinit_p16() { A_arbace_test_A_const_209 = lang.Var_Cast(A_arbace_test_A_const_pool.A[285]); A_arbace_test_A_const_210 = lang.Var_Cast(A_arbace_test_A_const_pool.A[286]); A_arbace_test_A_const_211 = lang.Var_Cast(A_arbace_test_A_const_pool.A[287]); A_arbace_test_A_const_212 = A_arbace_test_A_const_pool.A[288] }

func A_arbace_test_A_New() *A_arbace_test_A { A_arbace_test_A_Init(); t := &A_arbace_test_A{}; t.Ctor(); return t }

func (t *A_arbace_test_A) Ctor() {}

func (t *A_arbace_test_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_A) GetClass__Class() *jrt.Class { return A_arbace_test_A_class }

func (t *A_arbace_test_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_A); return ok }

func A_arbace_test_A_Cast(x any) *A_arbace_test_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_A_class)) }; return v }



type A_arbace_test_add_ns_meta_A struct{ j2g_header uint64 }

var A_arbace_test_add_ns_meta_A_fn_class *jrt.Class



type A_arbace_test_are_A struct{ j2g_header uint64 }

var A_arbace_test_are_A_fn_class *jrt.Class



type A_arbace_test_assert_any_A struct{ j2g_header uint64 }

var A_arbace_test_assert_any_A_fn_class *jrt.Class



type A_arbace_test_assert_predicate_A struct{ j2g_header uint64 }

var A_arbace_test_assert_predicate_A_fn_class *jrt.Class



type A_arbace_test_compose_fixtures_A struct{ j2g_header uint64 }

var A_arbace_test_compose_fixtures_A_fn_class *jrt.Class



type A_arbace_test_compose_fixtures_fn__196000167_A struct{ j2g_header uint64; F_f1, F_f2 any }

var A_arbace_test_compose_fixtures_fn__196000167_A_fn_class *jrt.Class



type A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A struct{ j2g_header uint64; F_g, F_f2 any }

var A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_fn_class *jrt.Class



type A_arbace_test_default_fixture_A struct{ j2g_header uint64 }

var A_arbace_test_default_fixture_A_fn_class *jrt.Class



type A_arbace_test_deftest_A struct{ j2g_header uint64 }

var A_arbace_test_deftest_A_fn_class *jrt.Class



type A_arbace_test_deftest__A struct{ j2g_header uint64 }

var A_arbace_test_deftest__A_fn_class *jrt.Class



type A_arbace_test_do_report_A struct{ j2g_header uint64 }

var A_arbace_test_do_report_A_fn_class *jrt.Class



type A_arbace_test_do_report_fn__196000036_A struct{ j2g_header uint64 }

var A_arbace_test_do_report_fn__196000036_A_fn_class *jrt.Class



type A_arbace_test_eval196000004_A struct{ jrt.Object }

func A_arbace_test_eval196000004_A_New() *A_arbace_test_eval196000004_A { t := &A_arbace_test_eval196000004_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000004_A) Ctor() {}

func (t *A_arbace_test_eval196000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000004_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000004_A_class }

func (t *A_arbace_test_eval196000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000004_A); return ok }

func A_arbace_test_eval196000004_A_Cast(x any) *A_arbace_test_eval196000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000004_A_class)) }; return v }



type A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_fn_class *jrt.Class



type A_arbace_test_eval196000008_A struct{ jrt.Object }

func A_arbace_test_eval196000008_A_New() *A_arbace_test_eval196000008_A { t := &A_arbace_test_eval196000008_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000008_A) Ctor() {}

func (t *A_arbace_test_eval196000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000008_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000008_A_class }

func (t *A_arbace_test_eval196000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000008_A); return ok }

func A_arbace_test_eval196000008_A_Cast(x any) *A_arbace_test_eval196000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000008_A_class)) }; return v }



type A_arbace_test_eval196000008_fn__196000009_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000008_fn__196000009_A_fn_class *jrt.Class



type A_arbace_test_eval196000039_A struct{ jrt.Object }

func A_arbace_test_eval196000039_A_New() *A_arbace_test_eval196000039_A { t := &A_arbace_test_eval196000039_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000039_A) Ctor() {}

func (t *A_arbace_test_eval196000039_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000039_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000039_A_class }

func (t *A_arbace_test_eval196000039_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000039_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000039_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000039_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000039_A); return ok }

func A_arbace_test_eval196000039_A_Cast(x any) *A_arbace_test_eval196000039_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000039_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000039_A_class)) }; return v }



type A_arbace_test_eval196000039_fn__196000040_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000039_fn__196000040_A_fn_class *jrt.Class



type A_arbace_test_eval196000043_A struct{ jrt.Object }

func A_arbace_test_eval196000043_A_New() *A_arbace_test_eval196000043_A { t := &A_arbace_test_eval196000043_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000043_A) Ctor() {}

func (t *A_arbace_test_eval196000043_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000043_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000043_A_class }

func (t *A_arbace_test_eval196000043_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000043_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000043_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000043_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000043_A); return ok }

func A_arbace_test_eval196000043_A_Cast(x any) *A_arbace_test_eval196000043_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000043_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000043_A_class)) }; return v }



type A_arbace_test_eval196000043_fn__196000044_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000043_fn__196000044_A_fn_class *jrt.Class



type A_arbace_test_eval196000047_A struct{ jrt.Object }

func A_arbace_test_eval196000047_A_New() *A_arbace_test_eval196000047_A { t := &A_arbace_test_eval196000047_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000047_A) Ctor() {}

func (t *A_arbace_test_eval196000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000047_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000047_A_class }

func (t *A_arbace_test_eval196000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000047_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000047_A); return ok }

func A_arbace_test_eval196000047_A_Cast(x any) *A_arbace_test_eval196000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000047_A_class)) }; return v }



type A_arbace_test_eval196000047_fn__196000048_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000047_fn__196000048_A_fn_class *jrt.Class



type A_arbace_test_eval196000051_A struct{ jrt.Object }

func A_arbace_test_eval196000051_A_New() *A_arbace_test_eval196000051_A { t := &A_arbace_test_eval196000051_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000051_A) Ctor() {}

func (t *A_arbace_test_eval196000051_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000051_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000051_A_class }

func (t *A_arbace_test_eval196000051_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000051_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000051_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000051_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000051_A); return ok }

func A_arbace_test_eval196000051_A_Cast(x any) *A_arbace_test_eval196000051_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000051_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000051_A_class)) }; return v }



type A_arbace_test_eval196000051_fn__196000052_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000051_fn__196000052_A_fn_class *jrt.Class



type A_arbace_test_eval196000055_A struct{ jrt.Object }

func A_arbace_test_eval196000055_A_New() *A_arbace_test_eval196000055_A { t := &A_arbace_test_eval196000055_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000055_A) Ctor() {}

func (t *A_arbace_test_eval196000055_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000055_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000055_A_class }

func (t *A_arbace_test_eval196000055_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000055_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000055_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000055_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000055_A); return ok }

func A_arbace_test_eval196000055_A_Cast(x any) *A_arbace_test_eval196000055_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000055_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000055_A_class)) }; return v }



type A_arbace_test_eval196000055_fn__196000056_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000055_fn__196000056_A_fn_class *jrt.Class



type A_arbace_test_eval196000059_A struct{ jrt.Object }

func A_arbace_test_eval196000059_A_New() *A_arbace_test_eval196000059_A { t := &A_arbace_test_eval196000059_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000059_A) Ctor() {}

func (t *A_arbace_test_eval196000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000059_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000059_A_class }

func (t *A_arbace_test_eval196000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000059_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000059_A); return ok }

func A_arbace_test_eval196000059_A_Cast(x any) *A_arbace_test_eval196000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000059_A_class)) }; return v }



type A_arbace_test_eval196000059_fn__196000060_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000059_fn__196000060_A_fn_class *jrt.Class



type A_arbace_test_eval196000063_A struct{ jrt.Object }

func A_arbace_test_eval196000063_A_New() *A_arbace_test_eval196000063_A { t := &A_arbace_test_eval196000063_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000063_A) Ctor() {}

func (t *A_arbace_test_eval196000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000063_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000063_A_class }

func (t *A_arbace_test_eval196000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000063_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000063_A); return ok }

func A_arbace_test_eval196000063_A_Cast(x any) *A_arbace_test_eval196000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000063_A_class)) }; return v }



type A_arbace_test_eval196000063_fn__196000064_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000063_fn__196000064_A_fn_class *jrt.Class



type A_arbace_test_eval196000067_A struct{ jrt.Object }

func A_arbace_test_eval196000067_A_New() *A_arbace_test_eval196000067_A { t := &A_arbace_test_eval196000067_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000067_A) Ctor() {}

func (t *A_arbace_test_eval196000067_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000067_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000067_A_class }

func (t *A_arbace_test_eval196000067_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000067_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000067_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000067_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000067_A); return ok }

func A_arbace_test_eval196000067_A_Cast(x any) *A_arbace_test_eval196000067_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000067_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000067_A_class)) }; return v }



type A_arbace_test_eval196000067_fn__196000068_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000067_fn__196000068_A_fn_class *jrt.Class



type A_arbace_test_eval196000071_A struct{ jrt.Object }

func A_arbace_test_eval196000071_A_New() *A_arbace_test_eval196000071_A { t := &A_arbace_test_eval196000071_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000071_A) Ctor() {}

func (t *A_arbace_test_eval196000071_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000071_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000071_A_class }

func (t *A_arbace_test_eval196000071_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000071_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000071_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000071_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000071_A); return ok }

func A_arbace_test_eval196000071_A_Cast(x any) *A_arbace_test_eval196000071_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000071_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000071_A_class)) }; return v }



type A_arbace_test_eval196000071_fn__196000072_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000071_fn__196000072_A_fn_class *jrt.Class



type A_arbace_test_eval196000082_A struct{ jrt.Object }

func A_arbace_test_eval196000082_A_New() *A_arbace_test_eval196000082_A { t := &A_arbace_test_eval196000082_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000082_A) Ctor() {}

func (t *A_arbace_test_eval196000082_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000082_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000082_A_class }

func (t *A_arbace_test_eval196000082_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000082_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000082_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000082_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000082_A); return ok }

func A_arbace_test_eval196000082_A_Cast(x any) *A_arbace_test_eval196000082_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000082_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000082_A_class)) }; return v }



type A_arbace_test_eval196000082_fn__196000083_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000082_fn__196000083_A_fn_class *jrt.Class



type A_arbace_test_eval196000086_A struct{ jrt.Object }

func A_arbace_test_eval196000086_A_New() *A_arbace_test_eval196000086_A { t := &A_arbace_test_eval196000086_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000086_A) Ctor() {}

func (t *A_arbace_test_eval196000086_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000086_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000086_A_class }

func (t *A_arbace_test_eval196000086_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000086_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000086_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000086_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000086_A); return ok }

func A_arbace_test_eval196000086_A_Cast(x any) *A_arbace_test_eval196000086_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000086_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000086_A_class)) }; return v }



type A_arbace_test_eval196000086_fn__196000087_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000086_fn__196000087_A_fn_class *jrt.Class



type A_arbace_test_eval196000090_A struct{ jrt.Object }

func A_arbace_test_eval196000090_A_New() *A_arbace_test_eval196000090_A { t := &A_arbace_test_eval196000090_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000090_A) Ctor() {}

func (t *A_arbace_test_eval196000090_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000090_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000090_A_class }

func (t *A_arbace_test_eval196000090_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000090_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000090_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000090_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000090_A); return ok }

func A_arbace_test_eval196000090_A_Cast(x any) *A_arbace_test_eval196000090_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000090_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000090_A_class)) }; return v }



type A_arbace_test_eval196000090_fn__196000091_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000090_fn__196000091_A_fn_class *jrt.Class



type A_arbace_test_eval196000097_A struct{ jrt.Object }

func A_arbace_test_eval196000097_A_New() *A_arbace_test_eval196000097_A { t := &A_arbace_test_eval196000097_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000097_A) Ctor() {}

func (t *A_arbace_test_eval196000097_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000097_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000097_A_class }

func (t *A_arbace_test_eval196000097_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000097_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000097_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000097_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000097_A); return ok }

func A_arbace_test_eval196000097_A_Cast(x any) *A_arbace_test_eval196000097_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000097_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000097_A_class)) }; return v }



type A_arbace_test_eval196000097_fn__196000098_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000097_fn__196000098_A_fn_class *jrt.Class



type A_arbace_test_eval196000102_A struct{ jrt.Object }

func A_arbace_test_eval196000102_A_New() *A_arbace_test_eval196000102_A { t := &A_arbace_test_eval196000102_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000102_A) Ctor() {}

func (t *A_arbace_test_eval196000102_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000102_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000102_A_class }

func (t *A_arbace_test_eval196000102_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000102_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000102_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000102_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000102_A); return ok }

func A_arbace_test_eval196000102_A_Cast(x any) *A_arbace_test_eval196000102_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000102_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000102_A_class)) }; return v }



type A_arbace_test_eval196000102_fn__196000103_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000102_fn__196000103_A_fn_class *jrt.Class



type A_arbace_test_eval196000108_A struct{ jrt.Object }

func A_arbace_test_eval196000108_A_New() *A_arbace_test_eval196000108_A { t := &A_arbace_test_eval196000108_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000108_A) Ctor() {}

func (t *A_arbace_test_eval196000108_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000108_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000108_A_class }

func (t *A_arbace_test_eval196000108_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000108_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000108_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000108_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000108_A); return ok }

func A_arbace_test_eval196000108_A_Cast(x any) *A_arbace_test_eval196000108_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000108_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000108_A_class)) }; return v }



type A_arbace_test_eval196000108_fn__196000109_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000108_fn__196000109_A_fn_class *jrt.Class



type A_arbace_test_eval196000154_A struct{ jrt.Object }

func A_arbace_test_eval196000154_A_New() *A_arbace_test_eval196000154_A { t := &A_arbace_test_eval196000154_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000154_A) Ctor() {}

func (t *A_arbace_test_eval196000154_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000154_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000154_A_class }

func (t *A_arbace_test_eval196000154_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000154_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000154_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000154_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000154_A); return ok }

func A_arbace_test_eval196000154_A_Cast(x any) *A_arbace_test_eval196000154_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000154_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000154_A_class)) }; return v }



type A_arbace_test_eval196000154_fn__196000155_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000154_fn__196000155_A_fn_class *jrt.Class



type A_arbace_test_eval196000158_A struct{ jrt.Object }

func A_arbace_test_eval196000158_A_New() *A_arbace_test_eval196000158_A { t := &A_arbace_test_eval196000158_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000158_A) Ctor() {}

func (t *A_arbace_test_eval196000158_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000158_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000158_A_class }

func (t *A_arbace_test_eval196000158_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000158_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000158_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000158_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000158_A); return ok }

func A_arbace_test_eval196000158_A_Cast(x any) *A_arbace_test_eval196000158_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000158_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000158_A_class)) }; return v }



type A_arbace_test_eval196000158_fn__196000159_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000158_fn__196000159_A_fn_class *jrt.Class



type A_arbace_test_eval196000162_A struct{ jrt.Object }

func A_arbace_test_eval196000162_A_New() *A_arbace_test_eval196000162_A { t := &A_arbace_test_eval196000162_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000162_A) Ctor() {}

func (t *A_arbace_test_eval196000162_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000162_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000162_A_class }

func (t *A_arbace_test_eval196000162_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000162_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000162_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000162_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000162_A); return ok }

func A_arbace_test_eval196000162_A_Cast(x any) *A_arbace_test_eval196000162_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000162_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000162_A_class)) }; return v }



type A_arbace_test_eval196000162_fn__196000163_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000162_fn__196000163_A_fn_class *jrt.Class



type A_arbace_test_file_and_line_A struct{ j2g_header uint64 }

var A_arbace_test_file_and_line_A_fn_class *jrt.Class



type A_arbace_test_file_position_A struct{ j2g_header uint64 }

var A_arbace_test_file_position_A_fn_class *jrt.Class



type A_arbace_test_function_QMARK__A struct{ j2g_header uint64 }

var A_arbace_test_function_QMARK__A_fn_class *jrt.Class



type A_arbace_test_get_possibly_unbound_var_A struct{ j2g_header uint64 }

var A_arbace_test_get_possibly_unbound_var_A_fn_class *jrt.Class



type A_arbace_test_inc_report_counter_A struct{ j2g_header uint64 }

var A_arbace_test_inc_report_counter_A_fn_class *jrt.Class



type A_arbace_test_inc_report_counter_fn__196000027_A struct{ j2g_header uint64; F_name any }

var A_arbace_test_inc_report_counter_fn__196000027_A_fn_class *jrt.Class



type A_arbace_test_is_A struct{ j2g_header uint64 }

var A_arbace_test_is_A_fn_class *jrt.Class



type A_arbace_test_join_fixtures_A struct{ j2g_header uint64 }

var A_arbace_test_join_fixtures_A_fn_class *jrt.Class



type A_arbace_test_run_all_tests_A struct{ j2g_header uint64 }

var A_arbace_test_run_all_tests_A_fn_class *jrt.Class



type A_arbace_test_run_all_tests_fn__196000211_A struct{ j2g_header uint64; F_re any }

var A_arbace_test_run_all_tests_fn__196000211_A_fn_class *jrt.Class



type A_arbace_test_run_test_A struct{ j2g_header uint64 }

var A_arbace_test_run_test_A_fn_class *jrt.Class



type A_arbace_test_run_test_var_A struct{ j2g_header uint64 }

var A_arbace_test_run_test_var_A_fn_class *jrt.Class



type A_arbace_test_run_tests_A struct{ j2g_header uint64 }

var A_arbace_test_run_tests_A_fn_class *jrt.Class



type A_arbace_test_set_test_A struct{ j2g_header uint64 }

var A_arbace_test_set_test_A_fn_class *jrt.Class



type A_arbace_test_stacktrace_file_and_line_A struct{ j2g_header uint64 }

var A_arbace_test_stacktrace_file_and_line_A_fn_class *jrt.Class



type A_arbace_test_successful_QMARK__A struct{ j2g_header uint64 }

var A_arbace_test_successful_QMARK__A_fn_class *jrt.Class



type A_arbace_test_test_all_vars_A struct{ j2g_header uint64 }

var A_arbace_test_test_all_vars_A_fn_class *jrt.Class



type A_arbace_test_test_ns_A struct{ j2g_header uint64 }

var A_arbace_test_test_ns_A_fn_class *jrt.Class



type A_arbace_test_test_var_A struct{ j2g_header uint64 }

var A_arbace_test_test_var_A_fn_class *jrt.Class



type A_arbace_test_test_var_fn__196000173_A struct{ j2g_header uint64; F_t any }

var A_arbace_test_test_var_fn__196000173_A_fn_class *jrt.Class



type A_arbace_test_test_vars_A struct{ j2g_header uint64 }

var A_arbace_test_test_vars_A_fn_class *jrt.Class



type A_arbace_test_test_vars_fn__196000183_A struct{ j2g_header uint64; F_vars, F_each_fixture_fn any }

var A_arbace_test_test_vars_fn__196000183_A_fn_class *jrt.Class



type A_arbace_test_test_vars_fn__196000183_fn__196000188_A struct{ j2g_header uint64; F_v any }

var A_arbace_test_test_vars_fn__196000183_fn__196000188_A_fn_class *jrt.Class



type A_arbace_test_test_vars_fn__196000183_fn__196000190_A struct{ j2g_header uint64; F_v any }

var A_arbace_test_test_vars_fn__196000183_fn__196000190_A_fn_class *jrt.Class



type A_arbace_test_test_vars_fn__196000196_A struct{ j2g_header uint64; F_vars, F_each_fixture_fn any }

var A_arbace_test_test_vars_fn__196000196_A_fn_class *jrt.Class



type A_arbace_test_test_vars_fn__196000196_fn__196000201_A struct{ j2g_header uint64; F_v any }

var A_arbace_test_test_vars_fn__196000196_fn__196000201_A_fn_class *jrt.Class



type A_arbace_test_test_vars_fn__196000196_fn__196000203_A struct{ j2g_header uint64; F_v any }

var A_arbace_test_test_vars_fn__196000196_fn__196000203_A_fn_class *jrt.Class



type A_arbace_test_testing_A struct{ j2g_header uint64 }

var A_arbace_test_testing_A_fn_class *jrt.Class



type A_arbace_test_testing_contexts_str_A struct{ j2g_header uint64 }

var A_arbace_test_testing_contexts_str_A_fn_class *jrt.Class



type A_arbace_test_testing_vars_str_A struct{ j2g_header uint64 }

var A_arbace_test_testing_vars_str_A_fn_class *jrt.Class



type A_arbace_test_testing_vars_str_fn__196000023_A struct{ j2g_header uint64 }

var A_arbace_test_testing_vars_str_fn__196000023_A_fn_class *jrt.Class



type A_arbace_test_try_expr_A struct{ j2g_header uint64 }

var A_arbace_test_try_expr_A_fn_class *jrt.Class



type A_arbace_test_with_test_A struct{ j2g_header uint64 }

var A_arbace_test_with_test_A_fn_class *jrt.Class



type A_arbace_test_with_test_out_A struct{ j2g_header uint64 }

var A_arbace_test_with_test_out_A_fn_class *jrt.Class
