//line aot_arbace_test_j2g.ae:1
package aot_arbace_test

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_stacktrace"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)







func A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_New() *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A) Ctor() {}
//line :17:1
func (t *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_test_A_const_4.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_5); tmp2 = lang.IFn_Cast(A_arbace_test_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_test_A_const_1, A_arbace_test_A_const_2, A_arbace_test_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :17:1
func A_arbace_test_eval196000008_fn__196000009_A_New() *A_arbace_test_eval196000008_fn__196000009_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000008_fn__196000009_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_test_eval196000008_fn__196000009_A) Ctor() {}
//line :17:1
func (t *A_arbace_test_eval196000008_fn__196000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_6.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_test_A_const_7.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_test_A_const_8; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_test_A_const_9.GetRawRoot__O(), A_arbace_test_A_const_10) }

























































































































































































































































func A_arbace_test_with_test_out_A_New() *A_arbace_test_with_test_out_A { A_arbace_test_A_Init(); t := &A_arbace_test_with_test_out_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_test_with_test_out_A) Ctor() {}
//line :267:1
func (t *A_arbace_test_with_test_out_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { var root_41 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_14); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp4 any; var root_30 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = A_arbace_test_A_const_16.GetRawRoot__O(); var arg_34 any; var root_26 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any; var root_21 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_17); var arg_25 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_18); if linked_22 == nil { arg_29 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { arg_29 = linked_22.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; if linked_27 == nil { arg_34 = ifn_28.Invoke_O__O(arg_29) } else { arg_34 = linked_27.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_26, arg_29) }; if linked_31 == nil { tmp4 = ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { tmp4 = linked_31.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_30, arg_33, arg_34) }; arg_44 = tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4), body__2); if linked_42 == nil { return ifn_43.Invoke_O__O(arg_44) } else { return linked_42.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_41, arg_44) } }








func A_arbace_test_file_position_A_New() *A_arbace_test_file_position_A { A_arbace_test_A_Init(); t := &A_arbace_test_file_position_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_test_file_position_A) Ctor() {}
//line :276:1
func (t *A_arbace_test_file_position_A) Invoke_O_O__O(self, n__0 any) any { var s__2 any = lang.RT_Nth_O_I__O_NoInit(jrt.Throwable_New().GetStackTrace__StackTraceElement1().Ref(), lang.RT_IntCast_O__I_NoInit(n__0)); return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.As[*jrt.StackTraceElement](s__2)).GetFileName__String().Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.As[*jrt.StackTraceElement](s__2)).GetLineNumber__I()).Ref()) }











func A_arbace_test_testing_vars_str_A_New() *A_arbace_test_testing_vars_str_A { A_arbace_test_A_Init(); t := &A_arbace_test_testing_vars_str_A{}; t.Ctor(); return t }
//line :288:1
func (t *A_arbace_test_testing_vars_str_A) Ctor() {}
//line :288:1
func (t *A_arbace_test_testing_vars_str_A) Invoke_O_O__O(self, m__0 any) any { var map__196000021__2 any = m__0; var map__196000021__3 any; if





	lang.ISeq_InstanceOf(map__196000021__2) { var tmp1 any; var root_45 any = A_arbace_test_A_const_19.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = map__196000021__2; if linked_46 == nil { tmp1 = ifn_47.Invoke_O__O(arg_48) } else { tmp1 = linked_46.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_45, arg_48) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_49 any = A_arbace_test_A_const_20.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = map__196000021__2; if linked_50 == nil { tmp2 = ifn_51.Invoke_O__O(arg_52) } else { tmp2 = linked_50.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_49, arg_52) }; map__196000021__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_53 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = map__196000021__2; if linked_54 == nil { tmp3 = ifn_55.Invoke_O__O(arg_56) } else { tmp3 = linked_54.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_53, arg_56) }; if jrt.J2g_Truth(tmp3) { var root_57 any = A_arbace_test_A_const_21.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = map__196000021__2; if linked_58 == nil { map__196000021__3 = ifn_59.Invoke_O__O(arg_60) } else { map__196000021__3 = linked_58.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_57, arg_60) } } else { map__196000021__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__196000021__3 = map__196000021__2 }; var file__4 any = /*line :288:1*/lang.RT_Get_O_O__O_NoInit(map__196000021__3, A_arbace_test_A_const_22); var line__5 any = lang.RT_Get_O_O__O_NoInit(map__196000021__3, A_arbace_test_A_const_23); var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_34, nil, Lit_35, nil, Lit_36); var tmp5 any; var root_67 any = A_arbace_test_A_const_24.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_69 lang.IFn; if









	linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any; var root_62 any = A_arbace_test_A_const_25.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any; var tmp6 any = A_arbace_test_testing_vars_str_fn__196000023_A_New(); var tmp7 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_test_testing_vars_str_fn__196000023_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_test_testing_vars_str_fn__196000023_A_fn_class = fncls__61d; tmp7 = fncls__61d } else { tmp7 = fncls__61 }; arg_65 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_66 any = A_arbace_test_A_const_27.Get__O(); if linked_63 == nil { arg_70 = ifn_64.Invoke_O_O__O(arg_65, arg_66) } else { arg_70 = linked_63.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_62, arg_65, arg_66) }; if linked_68 == nil { tmp5 = ifn_69.Invoke_O__O(arg_70) } else { tmp5 = linked_68.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_67, arg_70) }; return /*line :295:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5, nil, file__4, nil, line__5, nil)).Ref() }


func A_arbace_test_testing_vars_str_fn__196000023_A_New() *A_arbace_test_testing_vars_str_fn__196000023_A { A_arbace_test_A_Init(); t := &A_arbace_test_testing_vars_str_fn__196000023_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_test_testing_vars_str_fn__196000023_A) Ctor() {}
//line :298:1
func (t *A_arbace_test_testing_vars_str_fn__196000023_A) Invoke_O_O__O(self, p1__196000020_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_test_A_const_26; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__196000020_SHARP___1)) }


func A_arbace_test_testing_contexts_str_A_New() *A_arbace_test_testing_contexts_str_A { A_arbace_test_A_Init(); t := &A_arbace_test_testing_contexts_str_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_test_testing_contexts_str_A) Ctor() {}
//line :301:1
func (t *A_arbace_test_testing_contexts_str_A) Invoke_O__O(self any) any {




	var root_80 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = A_arbace_test_A_const_28.GetRawRoot__O(); var arg_84 any; var root_75 any = A_arbace_test_A_const_29.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = Lit_33; var arg_79 any; var root_71 any = A_arbace_test_A_const_24.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = A_arbace_test_A_const_30.Get__O(); if linked_72 == nil { arg_79 = ifn_73.Invoke_O__O(arg_74) } else { arg_79 = linked_72.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_71, arg_74) }; if linked_76 == nil { arg_84 = ifn_77.Invoke_O_O__O(arg_78, arg_79) } else { arg_84 = linked_76.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_75, arg_78, arg_79) }; if linked_81 == nil { return ifn_82.Invoke_O_O__O(arg_83, arg_84) } else { return linked_81.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_80, arg_83, arg_84)
	} }
func A_arbace_test_inc_report_counter_A_New() *A_arbace_test_inc_report_counter_A { A_arbace_test_A_Init(); t := &A_arbace_test_inc_report_counter_A{}; t.Ctor(); return t }
//line :308:1
func (t *A_arbace_test_inc_report_counter_A) Ctor() {}
//line :308:1
func (t *A_arbace_test_inc_report_counter_A) Invoke_O_O__O(self, name__0 any) any {




	if jrt.J2g_Truth(A_arbace_test_A_const_31.Get__O()) {
		var tmp1 any = A_arbace_test_inc_report_counter_fn__196000027_A_New_O(name__0); var tmp2 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_test_inc_report_counter_fn__196000027_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_test_inc_report_counter_fn__196000027_A_fn_class = fncls__97d; tmp2 = fncls__97d } else { tmp2 = fncls__97 }; return lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) } else {
//line :313:1
			return nil } }
func A_arbace_test_inc_report_counter_fn__196000027_A_New_O(p0 any) *A_arbace_test_inc_report_counter_fn__196000027_A { A_arbace_test_A_Init(); t := &A_arbace_test_inc_report_counter_fn__196000027_A{}; t.Ctor_O(p0); return t }
//line :314:1
func (t *A_arbace_test_inc_report_counter_fn__196000027_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :314:1
func (t *A_arbace_test_inc_report_counter_fn__196000027_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_6.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_31.Get__O(); var tmp3 any = A_arbace_test_A_const_32.GetRawRoot__O(); var tmp4 any = lang.Tuple_Create_O__IPersistentVector(t.F_name); var tmp5 any; var root_85 any = A_arbace_test_A_const_33.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = A_arbace_test_A_const_34.GetRawRoot__O(); var arg_89 any = A_arbace_test_A_const_35; if linked_86 == nil { tmp5 = ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { tmp5 = linked_86.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_85, arg_88, arg_89) }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5) }














func A_arbace_test_file_and_line_A_New() *A_arbace_test_file_and_line_A { A_arbace_test_A_Init(); t := &A_arbace_test_file_and_line_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_test_file_and_line_A) Ctor() {}
//line :329:1
func (t *A_arbace_test_file_and_line_A) Invoke_O_O_O__O(self, exception__0, depth__1 any) any { var stacktrace__3 any = jrt.Throwable_Cast(exception__0).GetStackTrace__StackTraceElement1().Ref(); var tmp1 bool; var na_98 any = depth__1; var na_99 int64 = int64(lang.RT_Count_O__I_NoInit(stacktrace__3)); if



	jrt.Long_InstanceOf(na_98) { var n0_100 int64 = jrt.NN(jrt.Long_Cast(na_98)).LongValue__J(); var n1_101 int64 = na_99; tmp1 = n0_100 < n1_101 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_98, na_99) }; if tmp1 { var s__4 any = lang.RT_Nth_O_I__O_NoInit(stacktrace__3, lang.RT_IntCast_O__I_NoInit(depth__1)); var tmp2 any = A_arbace_test_A_const_22; var tmp3 any = jrt.NN(jrt.As[*jrt.StackTraceElement](s__4)).GetFileName__String().Ref(); var tmp4 any = A_arbace_test_A_const_23; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.As[*jrt.StackTraceElement](s__4)).GetLineNumber__I()).Ref())) } else { return A_arbace_test_A_const_36 } }




func A_arbace_test_stacktrace_file_and_line_A_New() *A_arbace_test_stacktrace_file_and_line_A { A_arbace_test_A_Init(); t := &A_arbace_test_stacktrace_file_and_line_A{}; t.Ctor(); return t }
//line :338:1
func (t *A_arbace_test_stacktrace_file_and_line_A) Ctor() {}
//line :338:1
func (t *A_arbace_test_stacktrace_file_and_line_A) Invoke_O_O__O(self, stacktrace__0 any) any {

	var tmp1 any; var root_103 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = stacktrace__0; if linked_104 == nil { tmp1 = ifn_105.Invoke_O__O(arg_106) } else { tmp1 = linked_104.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_103, arg_106) }; if jrt.J2g_Truth(tmp1) { var s__2 any; var root_107 any = A_arbace_test_A_const_21.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_109 lang.IFn
		if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = stacktrace__0; if linked_108 == nil { s__2 = ifn_109.Invoke_O__O(arg_110) } else { s__2 = linked_108.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_107, arg_110) }
//line :340:1
		var tmp2 any = A_arbace_test_A_const_22; var tmp3 any = jrt.NN(jrt.As[*jrt.StackTraceElement](s__2)).GetFileName__String().Ref(); var tmp4 any = A_arbace_test_A_const_23; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.As[*jrt.StackTraceElement](s__2)).GetLineNumber__I()).Ref())) } else { return A_arbace_test_A_const_37
		}
}


func A_arbace_test_do_report_A_New() *A_arbace_test_do_report_A { A_arbace_test_A_Init(); t := &A_arbace_test_do_report_A{}; t.Ctor(); return t }
//line :345:1
func (t *A_arbace_test_do_report_A) Ctor() {}
//line :345:1
func (t *A_arbace_test_do_report_A) Invoke_O_O__O(self, m__0 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_38.Get__O()); var tmp2 any; var G__196000035__2_ any = A_arbace_test_A_const_39.Invoke_O__O(m__0)
L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__196000035__2_) >> 0 & 1 { case 0: if any(G__196000035__2_) == any(A_arbace_test_A_const_40) {







	var root_116 any = A_arbace_test_A_const_41.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any; var root_112 any = A_arbace_test_A_const_42.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, A_arbace_test_stacktrace_file_and_line_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = jrt.Throwable_Cast(A_arbace_test_A_const_43.Invoke_O__O(m__0)).GetStackTrace__StackTraceElement1().Ref(); if linked_113 == nil { arg_119 = ifn_114.Invoke_O__O(arg_115) } else { arg_119 = linked_113.(*A_arbace_test_stacktrace_file_and_line_A).Invoke_O_O__O(root_112, arg_115) }; var arg_120 any = m__0; if linked_117 == nil { tmp2 = ifn_118.Invoke_O_O__O(arg_119, arg_120) } else { tmp2 = linked_117.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_116, arg_119, arg_120) }
//line :352:1
	break L1 }; case 1: if any(G__196000035__2_) == any(A_arbace_test_A_const_44) {

		var root_146 any = A_arbace_test_A_const_41.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any; var root_142 any = A_arbace_test_A_const_42.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, A_arbace_test_stacktrace_file_and_line_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any; var root_137 any = A_arbace_test_A_const_45.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_drop_while_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any; var tmp3 any = A_arbace_test_do_report_fn__196000036_A_New(); var tmp4 *jrt.Class; var fncls__136 *jrt.Class = A_arbace_test_do_report_fn__196000036_A_fn_class; if fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_test_do_report_fn__196000036_A_fn_class = fncls__136d; tmp4 = fncls__136d } else { tmp4 = fncls__136 }; arg_140 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_141 any = jrt.Thread_CurrentThread__Thread().GetStackTrace__StackTraceElement1().Ref(); if linked_138 == nil { arg_145 = ifn_139.Invoke_O_O__O(arg_140, arg_141) } else { arg_145 = linked_138.(*aot_arbace_core.A_arbace_core_drop_while_A).Invoke_O_O_O__O(root_137, arg_140, arg_141) }; if linked_143 == nil { arg_149 = ifn_144.Invoke_O__O(arg_145) } else { arg_149 = linked_143.(*A_arbace_test_stacktrace_file_and_line_A).Invoke_O_O__O(root_142, arg_145) }; var arg_150 any = m__0; if linked_147 == nil { tmp2 = ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { tmp2 = linked_147.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) }
//line :352:1
		break L1 }; default:}; tmp2 = m__0}
//line :351:1
	return tmp1.Invoke_O__O(tmp2)
}

func A_arbace_test_do_report_fn__196000036_A_New() *A_arbace_test_do_report_fn__196000036_A { A_arbace_test_A_Init(); t := &A_arbace_test_do_report_fn__196000036_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_test_do_report_fn__196000036_A) Ctor() {}
//line :354:1
func (t *A_arbace_test_do_report_fn__196000036_A) Invoke_O_O__O(self, p1__196000034_SHARP___1 any) any { var cl_name__2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](p1__196000034_SHARP___1)).GetClassName__String().Ref(); var or__1927000174__auto____3 any; var root_121 any = A_arbace_test_A_const_46.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_123 lang.IFn; if

	linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = cl_name__2; var arg_125 any = Lit_5; if linked_122 == nil { or__1927000174__auto____3 = ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { or__1927000174__auto____3 = linked_122.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_121, arg_124, arg_125) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_126 any = A_arbace_test_A_const_46.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_128 lang.IFn
		if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = cl_name__2; var arg_130 any = Lit_6; if linked_127 == nil { or__1927000174__auto____4 = ifn_128.Invoke_O_O__O(arg_129, arg_130) } else { or__1927000174__auto____4 = linked_127.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_126, arg_129, arg_130) }
//line :356:1
		if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {

			var root_131 any = A_arbace_test_A_const_46.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = cl_name__2; var arg_135 any = Lit_7; if linked_132 == nil { return ifn_133.Invoke_O_O__O(arg_134, arg_135) } else { return linked_132.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_131, arg_134, arg_135) } } } }




func A_arbace_test_eval196000039_fn__196000040_A_New() *A_arbace_test_eval196000039_fn__196000040_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000039_fn__196000040_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_test_eval196000039_fn__196000040_A) Ctor() {}
//line :363:1
func (t *A_arbace_test_eval196000039_fn__196000040_A) Invoke_O_O__O(self, m__1 any) any {
	var root_163 any = A_arbace_test_A_const_49.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_51; var arg_166 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_A_const_52.Get__O()); if linked_164 == nil { ifn_165.Invoke_O__O(arg_166) } else { linked_164.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_163, arg_166) }
//line :363:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		tmp3 = lang.IFn_Cast(A_arbace_test_A_const_47.GetRawRoot__O()).Invoke_O__O(m__1)
//line :363:1
		return nil }(); var root_155 any = A_arbace_test_A_const_48.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_157 lang.IFn
	if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; if linked_156 == nil { ifn_157.Invoke__O() } else { linked_156.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_155) }
//line :363:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}

func A_arbace_test_eval196000043_fn__196000044_A_New() *A_arbace_test_eval196000043_fn__196000044_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000043_fn__196000044_A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_test_eval196000043_fn__196000044_A) Ctor() {}
//line :366:1
func (t *A_arbace_test_eval196000043_fn__196000044_A) Invoke_O_O__O(self, m__1 any) any {
	var root_179 any = A_arbace_test_A_const_49.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_51; var arg_182 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_A_const_52.Get__O()); if linked_180 == nil { ifn_181.Invoke_O__O(arg_182) } else { linked_180.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_179, arg_182) }
//line :366:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var root_167 any = A_arbace_test_A_const_53.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, A_arbace_test_inc_report_counter_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = A_arbace_test_A_const_54; if linked_168 == nil { tmp3 = ifn_169.Invoke_O__O(arg_170) } else { tmp3 = linked_168.(*A_arbace_test_inc_report_counter_A).Invoke_O_O__O(root_167, arg_170) } }
//line :366:1
		return nil }(); var root_171 any = A_arbace_test_A_const_48.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_173 lang.IFn
	if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; if linked_172 == nil { ifn_173.Invoke__O() } else { linked_172.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_171) }
//line :366:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}

func A_arbace_test_eval196000047_fn__196000048_A_New() *A_arbace_test_eval196000047_fn__196000048_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000047_fn__196000048_A{}; t.Ctor(); return t }
//line :369:1
func (t *A_arbace_test_eval196000047_fn__196000048_A) Ctor() {}
//line :369:1
func (t *A_arbace_test_eval196000047_fn__196000048_A) Invoke_O_O__O(self, m__1 any) any {
	var root_200 any = A_arbace_test_A_const_49.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_51; var arg_203 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_A_const_52.Get__O()); if linked_201 == nil { ifn_202.Invoke_O__O(arg_203) } else { linked_201.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_200, arg_203) }
//line :369:1
	var tmp3 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_204 any = A_arbace_test_A_const_53.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, A_arbace_test_inc_report_counter_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = A_arbace_test_A_const_44; if linked_205 == nil { ifn_206.Invoke_O__O(arg_207) } else { linked_205.(*A_arbace_test_inc_report_counter_A).Invoke_O_O__O(root_204, arg_207) }
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()); var tmp5 any; var root_208 any = A_arbace_test_A_const_57.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, A_arbace_test_testing_vars_str_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = m__1; if linked_209 == nil { tmp5 = ifn_210.Invoke_O__O(arg_211) } else { tmp5 = linked_209.(*A_arbace_test_testing_vars_str_A).Invoke_O_O__O(root_208, arg_211) }; tmp4.Invoke_O_O__O(Lit_8, tmp5)
			var tmp6 any; var root_217 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = A_arbace_test_A_const_30.Get__O(); if linked_218 == nil { tmp6 = ifn_219.Invoke_O__O(arg_220) } else { tmp6 = linked_218.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_217, arg_220) }; if jrt.J2g_Truth(tmp6) { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()); var tmp8 any; var root_221 any = A_arbace_test_A_const_58.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, A_arbace_test_testing_contexts_str_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; if linked_222 == nil { tmp8 = ifn_223.Invoke__O() } else { tmp8 = linked_222.(*A_arbace_test_testing_contexts_str_A).Invoke_O__O(root_221) }; tmp7.Invoke_O__O(tmp8) }
//line :369:1
			var temp__1927000414__auto____4 any = A_arbace_test_A_const_59.Invoke_O__O(m__1)




			if jrt.J2g_Truth(temp__1927000414__auto____4) { var message__5 any = temp__1927000414__auto____4; lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O__O(message__5) }
			lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O_O__O(Lit_9, lang.IFn_Cast(A_arbace_test_A_const_56.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60.Invoke_O__O(m__1)))
			tmp3 = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O_O__O(Lit_10, lang.IFn_Cast(A_arbace_test_A_const_56.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_43.Invoke_O__O(m__1))) }
//line :369:1
		return nil }(); var root_192 any = A_arbace_test_A_const_48.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_194 lang.IFn
	if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; if linked_193 == nil { ifn_194.Invoke__O() } else { linked_193.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_192) }
//line :369:1
	if tmp9 != nil { panic(tmp9) }; return tmp3
}







func A_arbace_test_eval196000051_fn__196000052_A_New() *A_arbace_test_eval196000051_fn__196000052_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000051_fn__196000052_A{}; t.Ctor(); return t }
//line :378:1
func (t *A_arbace_test_eval196000051_fn__196000052_A) Ctor() {}
//line :378:1
func (t *A_arbace_test_eval196000051_fn__196000052_A) Invoke_O_O__O(self, m__1 any) any {
	var root_258 any = A_arbace_test_A_const_49.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_51; var arg_261 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_A_const_52.Get__O()); if linked_259 == nil { ifn_260.Invoke_O__O(arg_261) } else { linked_259.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_258, arg_261) }
//line :378:1
	var tmp3 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_262 any = A_arbace_test_A_const_53.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, A_arbace_test_inc_report_counter_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = A_arbace_test_A_const_40; if linked_263 == nil { ifn_264.Invoke_O__O(arg_265) } else { linked_263.(*A_arbace_test_inc_report_counter_A).Invoke_O_O__O(root_262, arg_265) }
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()); var tmp5 any; var root_266 any = A_arbace_test_A_const_57.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, A_arbace_test_testing_vars_str_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = m__1; if linked_267 == nil { tmp5 = ifn_268.Invoke_O__O(arg_269) } else { tmp5 = linked_267.(*A_arbace_test_testing_vars_str_A).Invoke_O_O__O(root_266, arg_269) }; tmp4.Invoke_O_O__O(Lit_11, tmp5)
			var tmp6 any; var root_275 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = A_arbace_test_A_const_30.Get__O(); if linked_276 == nil { tmp6 = ifn_277.Invoke_O__O(arg_278) } else { tmp6 = linked_276.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_275, arg_278) }; if jrt.J2g_Truth(tmp6) { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()); var tmp8 any; var root_279 any = A_arbace_test_A_const_58.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, A_arbace_test_testing_contexts_str_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; if linked_280 == nil { tmp8 = ifn_281.Invoke__O() } else { tmp8 = linked_280.(*A_arbace_test_testing_contexts_str_A).Invoke_O__O(root_279) }; tmp7.Invoke_O__O(tmp8) }
//line :378:1
			var temp__1927000414__auto____4 any = A_arbace_test_A_const_59.Invoke_O__O(m__1)




			if jrt.J2g_Truth(temp__1927000414__auto____4) { var message__5 any = temp__1927000414__auto____4; lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O__O(message__5) }
			lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O_O__O(Lit_9, lang.IFn_Cast(A_arbace_test_A_const_56.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60.Invoke_O__O(m__1)))
			lang.IFn_Cast(A_arbace_test_A_const_63.GetRawRoot__O()).Invoke_O__O(Lit_12)
//line :378:1
			var actual__4 any = A_arbace_test_A_const_43.Invoke_O__O(m__1)








			if jrt.Throwable_InstanceOf(actual__4) {
				var root_241 any = A_arbace_test_A_const_61.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_stacktrace.A_arbace_stacktrace_print_cause_trace_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = actual__4; var arg_245 any = A_arbace_test_A_const_62.Get__O(); if linked_242 == nil { tmp3 = ifn_243.Invoke_O_O__O(arg_244, arg_245) } else { tmp3 = linked_242.(*aot_arbace_stacktrace.A_arbace_stacktrace_print_cause_trace_A).Invoke_O_O_O__O(root_241, arg_244, arg_245) } } else {
					tmp3 = lang.IFn_Cast(A_arbace_test_A_const_47.GetRawRoot__O()).Invoke_O__O(actual__4) } }
//line :378:1
		return nil }(); var root_250 any = A_arbace_test_A_const_48.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_252 lang.IFn
	if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; if linked_251 == nil { ifn_252.Invoke__O() } else { linked_251.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_250) }
//line :378:1
	if tmp9 != nil { panic(tmp9) }; return tmp3
}











func A_arbace_test_eval196000055_fn__196000056_A_New() *A_arbace_test_eval196000055_fn__196000056_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000055_fn__196000056_A{}; t.Ctor(); return t }
//line :391:1
func (t *A_arbace_test_eval196000055_fn__196000056_A) Ctor() {}
//line :391:1
func (t *A_arbace_test_eval196000055_fn__196000056_A) Invoke_O_O__O(self, m__1 any) any {
	var root_318 any = A_arbace_test_A_const_49.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_51; var arg_321 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_A_const_52.Get__O()); if linked_319 == nil { ifn_320.Invoke_O__O(arg_321) } else { linked_319.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_318, arg_321) }
//line :391:1
	var tmp3 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()); var tmp5 any = A_arbace_test_A_const_64.Invoke_O__O(m__1); var tmp6 jrt.Number_I; var na_322 any; var na_324 any = A_arbace_test_A_const_54.Invoke_O__O(m__1); var na_325 any = A_arbace_test_A_const_44.Invoke_O__O(m__1); var tmp7 bool; var tmp8 bool
			tmp8 = jrt.Long_InstanceOf(na_324); if tmp8 { tmp8 = jrt.Long_InstanceOf(na_325) }; tmp7 = tmp8; if tmp7 { var n0_326 int64 = jrt.NN(jrt.Long_Cast(na_324)).LongValue__J(); var n1_327 int64 = jrt.NN(jrt.Long_Cast(na_325)).LongValue__J(); var nr_328 int64 = n0_326 + n1_327; if (n0_326^nr_328)&(n1_327^nr_328) >= 0 { na_322 = jrt.Long_ValueOf_J__Long_NoInit(nr_328).Ref() } else { na_322 = lang.Numbers_Add_O_O__Number_NoInit(na_324, na_325) } } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_324); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_325) }; tmp9 = tmp10; if tmp9 { var n0_326_2 float64 = jrt.NN(jrt.Double_Cast(na_324)).DoubleValue__D(); var n1_327_2 float64 = jrt.NN(jrt.Double_Cast(na_325)).DoubleValue__D(); na_322 = jrt.Double_ValueOf_D__Double_NoInit(n0_326_2 + n1_327_2).Ref() } else { na_322 = lang.Numbers_Add_O_O__Number_NoInit(na_324, na_325) } }; var na_323 any = A_arbace_test_A_const_40.Invoke_O__O(m__1); var tmp11 bool; var tmp12 bool; tmp12 = jrt.Long_InstanceOf(na_322); if tmp12 { tmp12 = jrt.Long_InstanceOf(na_323) }; tmp11 = tmp12; if tmp11 { var n0_329 int64 = jrt.NN(jrt.Long_Cast(na_322)).LongValue__J(); var n1_330 int64 = jrt.NN(jrt.Long_Cast(na_323)).LongValue__J(); var nr_331 int64 = n0_329 + n1_330; if (n0_329^nr_331)&(n1_330^nr_331) >= 0 { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_331)) } else { tmp6 = lang.Numbers_Add_O_O__Number_NoInit(na_322, na_323) } } else { var tmp13 bool; var tmp14 bool; tmp14 = jrt.Double_InstanceOf(na_322); if tmp14 { tmp14 = jrt.Double_InstanceOf(na_323) }; tmp13 = tmp14; if tmp13 { var n0_329_2 float64 = jrt.NN(jrt.Double_Cast(na_322)).DoubleValue__D(); var n1_330_2 float64 = jrt.NN(jrt.Double_Cast(na_323)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_329_2 + n1_330_2)) } else { tmp6 = lang.Numbers_Add_O_O__Number_NoInit(na_322, na_323) } }
//line :393:1
			tmp4.Invoke_O_O_O_O_O__O(Lit_13, tmp5, Lit_14, tmp6, Lit_15)

			tmp3 = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_test_A_const_44.Invoke_O__O(m__1), Lit_16, A_arbace_test_A_const_40.Invoke_O__O(m__1), Lit_17) }
//line :391:1
		return nil }(); var root_310 any = A_arbace_test_A_const_48.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_312 lang.IFn
	if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; if linked_311 == nil { ifn_312.Invoke__O() } else { linked_311.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_310) }
//line :391:1
	if tmp15 != nil { panic(tmp15) }; return tmp3
}




func A_arbace_test_eval196000059_fn__196000060_A_New() *A_arbace_test_eval196000059_fn__196000060_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000059_fn__196000060_A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_test_eval196000059_fn__196000060_A) Ctor() {}
//line :397:1
func (t *A_arbace_test_eval196000059_fn__196000060_A) Invoke_O_O__O(self, m__1 any) any {
	var root_357 any = A_arbace_test_A_const_49.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_51; var arg_360 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_A_const_52.Get__O()); if linked_358 == nil { ifn_359.Invoke_O__O(arg_360) } else { linked_358.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_357, arg_360) }
//line :397:1
	var tmp3 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()); var tmp5 any; var root_340 any = A_arbace_test_A_const_65.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = A_arbace_test_A_const_66.Invoke_O__O(m__1); if linked_341 == nil { tmp5 = ifn_342.Invoke_O__O(arg_343) } else { tmp5 = linked_341.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_340, arg_343) }; tmp3 = tmp4.Invoke_O_O__O(Lit_18, tmp5) }
//line :397:1
		return nil }(); var root_349 any = A_arbace_test_A_const_48.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_351 lang.IFn
	if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; if linked_350 == nil { ifn_351.Invoke__O() } else { linked_350.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_349) }
//line :397:1
	if tmp6 != nil { panic(tmp6) }; return tmp3
}



func A_arbace_test_eval196000063_fn__196000064_A_New() *A_arbace_test_eval196000063_fn__196000064_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000063_fn__196000064_A{}; t.Ctor(); return t }
//line :402:1
func (t *A_arbace_test_eval196000063_fn__196000064_A) Ctor() {}
//line :402:1
func (t *A_arbace_test_eval196000063_fn__196000064_A) Invoke_O_O__O(self, m__1 any) any { return nil }
func A_arbace_test_eval196000067_fn__196000068_A_New() *A_arbace_test_eval196000067_fn__196000068_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000067_fn__196000068_A{}; t.Ctor(); return t }
//line :403:1
func (t *A_arbace_test_eval196000067_fn__196000068_A) Ctor() {}
//line :403:1
func (t *A_arbace_test_eval196000067_fn__196000068_A) Invoke_O_O__O(self, m__1 any) any { return nil }
func A_arbace_test_eval196000071_fn__196000072_A_New() *A_arbace_test_eval196000071_fn__196000072_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000071_fn__196000072_A{}; t.Ctor(); return t }
//line :404:1
func (t *A_arbace_test_eval196000071_fn__196000072_A) Ctor() {}
//line :404:1
func (t *A_arbace_test_eval196000071_fn__196000072_A) Invoke_O_O__O(self, m__1 any) any { return nil }



func A_arbace_test_get_possibly_unbound_var_A_New() *A_arbace_test_get_possibly_unbound_var_A { A_arbace_test_A_Init(); t := &A_arbace_test_get_possibly_unbound_var_A{}; t.Ctor(); return t }
//line :408:1
func (t *A_arbace_test_get_possibly_unbound_var_A) Ctor() {}
//line :408:1
func (t *A_arbace_test_get_possibly_unbound_var_A) Invoke_O_O__O(self, v__0 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



	{ var root_361 any = A_arbace_test_A_const_67.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_core.A_arbace_core_var_get_A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = v__0; if linked_362 == nil { tmp1 = ifn_363.Invoke_O__O(arg_364) } else { tmp1 = linked_362.(*aot_arbace_core.A_arbace_core_var_get_A).Invoke_O_O__O(root_361, arg_364) } }
//line :408:1
	return nil }(); if tmp2 != nil { if jrt.IllegalStateException_InstanceOf(tmp2) { var e__4 jrt.IllegalStateException_I = jrt.IllegalStateException_Cast(tmp2); _ = e__4; tmp1 = nil } else { panic(tmp2) } }; return tmp1 }







func A_arbace_test_function_QMARK__A_New() *A_arbace_test_function_QMARK__A { A_arbace_test_A_Init(); t := &A_arbace_test_function_QMARK__A{}; t.Ctor(); return t }
//line :416:1
func (t *A_arbace_test_function_QMARK__A) Ctor() {}
//line :416:1
func (t *A_arbace_test_function_QMARK__A) Invoke_O_O__O(self, x__0 any) any {




	var tmp1 any; var root_365 any = A_arbace_test_A_const_68.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = x__0; if linked_366 == nil { tmp1 = ifn_367.Invoke_O__O(arg_368) } else { tmp1 = linked_366.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_365, arg_368) }; if jrt.J2g_Truth(tmp1) { var temp__1927000414__auto____2 any; var root_369 any = A_arbace_test_A_const_69.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_371 lang.IFn
		if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = x__0; if linked_370 == nil { temp__1927000414__auto____2 = ifn_371.Invoke_O__O(arg_372) } else { temp__1927000414__auto____2 = linked_370.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_369, arg_372) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var v__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any; var root_373 any = A_arbace_test_A_const_70.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_373, A_arbace_test_get_possibly_unbound_var_A_fn_class); var ifn_375 lang.IFn
			if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any = v__3; if linked_374 == nil { temp__1927000414__auto____4 = ifn_375.Invoke_O__O(arg_376) } else { temp__1927000414__auto____4 = linked_374.(*A_arbace_test_get_possibly_unbound_var_A).Invoke_O_O__O(root_373, arg_376) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var value__5 any = temp__1927000414__auto____4; var and__1927000168__auto____6 any; var root_377 any = A_arbace_test_A_const_71.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_377, aot_arbace_core.A_arbace_core_fn_QMARK__A_fn_class); var ifn_379 lang.IFn
				if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = value__5; if linked_378 == nil { and__1927000168__auto____6 = ifn_379.Invoke_O__O(arg_380) } else { and__1927000168__auto____6 = linked_378.(*aot_arbace_core.A_arbace_core_fn_QMARK__A).Invoke_O_O__O(root_377, arg_380) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
					var root_381 any = A_arbace_test_A_const_72.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var tmp2 *lang.Keyword = A_arbace_test_A_const_73; var arg_384 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__3)); if linked_382 == nil { return ifn_383.Invoke_O__O(arg_384) } else { return linked_382.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_381, arg_384) } } else {
//line :424:1
						return and__1927000168__auto____6 } } else {
//line :423:1
							return nil } } else {
//line :422:1
								return nil } } else {



									var root_385 any = A_arbace_test_A_const_71.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_fn_QMARK__A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = x__0; if linked_386 == nil { return ifn_387.Invoke_O__O(arg_388) } else { return linked_386.(*aot_arbace_core.A_arbace_core_fn_QMARK__A).Invoke_O_O__O(root_385, arg_388)
									} } }
func A_arbace_test_assert_predicate_A_New() *A_arbace_test_assert_predicate_A { A_arbace_test_A_Init(); t := &A_arbace_test_assert_predicate_A{}; t.Ctor(); return t }
//line :428:1
func (t *A_arbace_test_assert_predicate_A) Ctor() {}
//line :428:1
func (t *A_arbace_test_assert_predicate_A) Invoke_O_O_O__O(self, msg__0, form__1 any) any { var args__3 any; var root_389 any = A_arbace_test_A_const_74.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_391 lang.IFn; if







	linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = form__1; if linked_390 == nil { args__3 = ifn_391.Invoke_O__O(arg_392) } else { args__3 = linked_390.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_389, arg_392) }; var pred__4 any; var root_393 any = /*line :428:1*/A_arbace_test_A_const_21.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_395 lang.IFn; if








	linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = form__1; if linked_394 == nil { pred__4 = ifn_395.Invoke_O__O(arg_396) } else { pred__4 = linked_394.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_393, arg_396) }; var root_583 any = /*line :436:1*/A_arbace_test_A_const_11.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_75); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp4 any; var root_427 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = A_arbace_test_A_const_16.GetRawRoot__O(); var arg_431 any; var root_423 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_76); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp8 any; var root_402 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; var root_397 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_77); var arg_401 any = args__3; if linked_398 == nil { arg_405 = ifn_399.Invoke_O_O__O(arg_400, arg_401) } else { arg_405 = linked_398.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_397, arg_400, arg_401) }; if linked_403 == nil { tmp8 = ifn_404.Invoke_O__O(arg_405) } else { tmp8 = linked_403.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_402, arg_405) }; var tmp9 any = tmp7.Invoke_O__O(tmp8); var tmp10 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_78); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp12 any; var root_412 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_79), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(pred__4), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_76)); if linked_413 == nil { tmp12 = ifn_414.Invoke_O__O(arg_415) } else { tmp12 = linked_413.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_412, arg_415) }; arg_426 = tmp5.Invoke_O_O_O_O__O(tmp6, tmp9, tmp10, tmp11.Invoke_O__O(tmp12)); if linked_424 == nil { arg_431 = ifn_425.Invoke_O__O(arg_426) } else { arg_431 = linked_424.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_423, arg_426) }; if linked_428 == nil { tmp4 = ifn_429.Invoke_O_O__O(arg_430, arg_431) } else { tmp4 = linked_428.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_427, arg_430, arg_431) }; var tmp13 any = tmp3.Invoke_O__O(tmp4); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp15 any; var root_572 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp17 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_80); var tmp18 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_78); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp20 any; var root_485 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any; var root_480 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_81); var arg_484 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp22 any; var root_475 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = A_arbace_test_A_const_50.GetRawRoot__O(); var arg_479 any; var root_471 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp24 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39); var tmp25 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_54); var tmp26 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_59); var tmp27 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__0); var tmp28 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp30 any; var root_437 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any; var root_432 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82); var arg_436 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__1); if linked_433 == nil { arg_440 = ifn_434.Invoke_O_O__O(arg_435, arg_436) } else { arg_440 = linked_433.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_432, arg_435, arg_436) }; if linked_438 == nil { tmp30 = ifn_439.Invoke_O__O(arg_440) } else { tmp30 = linked_438.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_437, arg_440) }; var tmp31 any = tmp29.Invoke_O__O(tmp30); var tmp32 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_43); var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp34 any; var root_456 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp36 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_83); var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp38 any; var root_446 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any; var root_441 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82); var arg_445 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(pred__4); if linked_442 == nil { arg_449 = ifn_443.Invoke_O_O__O(arg_444, arg_445) } else { arg_449 = linked_442.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_441, arg_444, arg_445) }; if linked_447 == nil { tmp38 = ifn_448.Invoke_O__O(arg_449) } else { tmp38 = linked_447.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_446, arg_449) }; arg_459 = tmp35.Invoke_O_O_O__O(tmp36, tmp37.Invoke_O__O(tmp38), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_76)); if linked_457 == nil { tmp34 = ifn_458.Invoke_O__O(arg_459) } else { tmp34 = linked_457.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_456, arg_459) }; arg_474 = tmp23.Invoke_O_O_O_O_O_O_O_O__O(tmp24, tmp25, tmp26, tmp27, tmp28, tmp31, tmp32, tmp33.Invoke_O__O(tmp34)); if linked_472 == nil { arg_479 = ifn_473.Invoke_O__O(arg_474) } else { arg_479 = linked_472.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_471, arg_474) }; if linked_476 == nil { tmp22 = ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { tmp22 = linked_476.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) }; arg_484 = tmp21.Invoke_O__O(tmp22); if linked_481 == nil { arg_488 = ifn_482.Invoke_O_O__O(arg_483, arg_484) } else { arg_488 = linked_481.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_480, arg_483, arg_484) }; if linked_486 == nil { tmp20 = ifn_487.Invoke_O__O(arg_488) } else { tmp20 = linked_486.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_485, arg_488) }; var tmp39 any = tmp19.Invoke_O__O(tmp20); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp41 any; var root_561 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any; var root_556 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_84); var arg_560 any; var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp43 any; var root_551 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = A_arbace_test_A_const_50.GetRawRoot__O(); var arg_555 any; var root_547 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any; var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp45 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39); var tmp46 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44); var tmp47 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_59); var tmp48 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__0); var tmp49 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60); var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp51 any; var root_494 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any; var root_489 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82); var arg_493 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__1); if linked_490 == nil { arg_497 = ifn_491.Invoke_O_O__O(arg_492, arg_493) } else { arg_497 = linked_490.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_489, arg_492, arg_493) }; if linked_495 == nil { tmp51 = ifn_496.Invoke_O__O(arg_497) } else { tmp51 = linked_495.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_494, arg_497) }; var tmp52 any = tmp50.Invoke_O__O(tmp51); var tmp53 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_43); var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp55 any; var root_532 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any; var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp57 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_85); var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp59 any; var root_503 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any; var root_498 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82); var arg_502 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_86); if linked_499 == nil { arg_506 = ifn_500.Invoke_O_O__O(arg_501, arg_502) } else { arg_506 = linked_499.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_498, arg_501, arg_502) }; if linked_504 == nil { tmp59 = ifn_505.Invoke_O__O(arg_506) } else { tmp59 = linked_504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_503, arg_506) }; var tmp60 any = tmp58.Invoke_O__O(tmp59); var tmp61 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp62 any; var root_522 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any; var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp64 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_87); var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp66 any; var root_512 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any; var root_507 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82); var arg_511 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(pred__4); if linked_508 == nil { arg_515 = ifn_509.Invoke_O_O__O(arg_510, arg_511) } else { arg_515 = linked_508.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_507, arg_510, arg_511) }; if linked_513 == nil { tmp66 = ifn_514.Invoke_O__O(arg_515) } else { tmp66 = linked_513.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_512, arg_515) }; arg_525 = tmp63.Invoke_O_O_O__O(tmp64, tmp65.Invoke_O__O(tmp66), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_76)); if linked_523 == nil { tmp62 = ifn_524.Invoke_O__O(arg_525) } else { tmp62 = linked_523.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_522, arg_525) }; arg_535 = tmp56.Invoke_O_O_O__O(tmp57, tmp60, tmp61.Invoke_O__O(tmp62)); if linked_533 == nil { tmp55 = ifn_534.Invoke_O__O(arg_535) } else { tmp55 = linked_533.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_532, arg_535) }; arg_550 = tmp44.Invoke_O_O_O_O_O_O_O_O__O(tmp45, tmp46, tmp47, tmp48, tmp49, tmp52, tmp53, tmp54.Invoke_O__O(tmp55)); if linked_548 == nil { arg_555 = ifn_549.Invoke_O__O(arg_550) } else { arg_555 = linked_548.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_547, arg_550) }; if linked_552 == nil { tmp43 = ifn_553.Invoke_O_O__O(arg_554, arg_555) } else { tmp43 = linked_552.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_551, arg_554, arg_555) }; arg_560 = tmp42.Invoke_O__O(tmp43); if linked_557 == nil { arg_564 = ifn_558.Invoke_O_O__O(arg_559, arg_560) } else { arg_564 = linked_557.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_556, arg_559, arg_560) }; if linked_562 == nil { tmp41 = ifn_563.Invoke_O__O(arg_564) } else { tmp41 = linked_562.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_561, arg_564) }; arg_575 = tmp16.Invoke_O_O_O_O__O(tmp17, tmp18, tmp39, tmp40.Invoke_O__O(tmp41)); if linked_573 == nil { tmp15 = ifn_574.Invoke_O__O(arg_575) } else { tmp15 = linked_573.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_572, arg_575) }; arg_586 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp13, tmp14.Invoke_O__O(tmp15), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_78)); if linked_584 == nil { return ifn_585.Invoke_O__O(arg_586) } else { return linked_584.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_583, arg_586) } }










func A_arbace_test_assert_any_A_New() *A_arbace_test_assert_any_A { A_arbace_test_A_Init(); t := &A_arbace_test_assert_any_A{}; t.Ctor(); return t }
//line :447:1
func (t *A_arbace_test_assert_any_A) Ctor() {}
//line :447:1
func (t *A_arbace_test_assert_any_A) Invoke_O_O_O__O(self, msg__0, form__1 any) any { var root_695 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_88); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp4 any; var root_596 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = A_arbace_test_A_const_16.GetRawRoot__O(); var arg_600 any; var root_592 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any; var root_587 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_89); var arg_591 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__1); if linked_588 == nil { arg_595 = ifn_589.Invoke_O_O__O(arg_590, arg_591) } else { arg_595 = linked_588.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_587, arg_590, arg_591) }; if linked_593 == nil { arg_600 = ifn_594.Invoke_O__O(arg_595) } else { arg_600 = linked_593.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_592, arg_595) }; if linked_597 == nil { tmp4 = ifn_598.Invoke_O_O__O(arg_599, arg_600) } else { tmp4 = linked_597.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_596, arg_599, arg_600) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp7 any; var root_684 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_90); var tmp10 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_89); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp12 any; var root_635 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any; var root_630 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_91); var arg_634 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp14 any; var root_625 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = A_arbace_test_A_const_50.GetRawRoot__O(); var arg_629 any; var root_621 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp16 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39); var tmp17 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_54); var tmp18 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_59); var tmp19 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__0); var tmp20 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp22 any; var root_606 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any; var root_601 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_603 lang.IFn; if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82); var arg_605 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__1); if linked_602 == nil { arg_609 = ifn_603.Invoke_O_O__O(arg_604, arg_605) } else { arg_609 = linked_602.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_601, arg_604, arg_605) }; if linked_607 == nil { tmp22 = ifn_608.Invoke_O__O(arg_609) } else { tmp22 = linked_607.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_606, arg_609) }; arg_624 = tmp15.Invoke_O_O_O_O_O_O_O_O__O(tmp16, tmp17, tmp18, tmp19, tmp20, tmp21.Invoke_O__O(tmp22), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_43), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_89)); if linked_622 == nil { arg_629 = ifn_623.Invoke_O__O(arg_624) } else { arg_629 = linked_622.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_621, arg_624) }; if linked_626 == nil { tmp14 = ifn_627.Invoke_O_O__O(arg_628, arg_629) } else { tmp14 = linked_626.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_625, arg_628, arg_629) }; arg_634 = tmp13.Invoke_O__O(tmp14); if linked_631 == nil { arg_638 = ifn_632.Invoke_O_O__O(arg_633, arg_634) } else { arg_638 = linked_631.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_630, arg_633, arg_634) }; if linked_636 == nil { tmp12 = ifn_637.Invoke_O__O(arg_638) } else { tmp12 = linked_636.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_635, arg_638) }; var tmp23 any = tmp11.Invoke_O__O(tmp12); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp25 any; var root_673 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any; var root_668 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_92); var arg_672 any; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp27 any; var root_663 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = A_arbace_test_A_const_50.GetRawRoot__O(); var arg_667 any; var root_659 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp29 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39); var tmp30 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44); var tmp31 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_59); var tmp32 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__0); var tmp33 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp35 any; var root_644 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any; var root_639 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82); var arg_643 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__1); if linked_640 == nil { arg_647 = ifn_641.Invoke_O_O__O(arg_642, arg_643) } else { arg_647 = linked_640.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_639, arg_642, arg_643) }; if linked_645 == nil { tmp35 = ifn_646.Invoke_O__O(arg_647) } else { tmp35 = linked_645.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_644, arg_647) }; arg_662 = tmp28.Invoke_O_O_O_O_O_O_O_O__O(tmp29, tmp30, tmp31, tmp32, tmp33, tmp34.Invoke_O__O(tmp35), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_43), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_89)); if linked_660 == nil { arg_667 = ifn_661.Invoke_O__O(arg_662) } else { arg_667 = linked_660.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_659, arg_662) }; if linked_664 == nil { tmp27 = ifn_665.Invoke_O_O__O(arg_666, arg_667) } else { tmp27 = linked_664.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_663, arg_666, arg_667) }; arg_672 = tmp26.Invoke_O__O(tmp27); if linked_669 == nil { arg_676 = ifn_670.Invoke_O_O__O(arg_671, arg_672) } else { arg_676 = linked_669.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_668, arg_671, arg_672) }; if linked_674 == nil { tmp25 = ifn_675.Invoke_O__O(arg_676) } else { tmp25 = linked_674.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_673, arg_676) }; arg_687 = tmp8.Invoke_O_O_O_O__O(tmp9, tmp10, tmp23, tmp24.Invoke_O__O(tmp25)); if linked_685 == nil { tmp7 = ifn_686.Invoke_O__O(arg_687) } else { tmp7 = linked_685.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_684, arg_687) }; arg_698 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_89)); if linked_696 == nil { return ifn_697.Invoke_O__O(arg_698) } else { return linked_696.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_695, arg_698) } }



















func A_arbace_test_eval196000082_fn__196000083_A_New() *A_arbace_test_eval196000082_fn__196000083_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000082_fn__196000083_A{}; t.Ctor(); return t }
//line :467:1
func (t *A_arbace_test_eval196000082_fn__196000083_A) Ctor() {}
//line :467:1
func (t *A_arbace_test_eval196000082_fn__196000083_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any {
	if lang.Util_Identical_O_O__Z_NoInit(form__2, nil) { return A_arbace_test_A_const_93 } else { var tmp1 any; var root_699 any = A_arbace_test_A_const_94.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_701 lang.IFn

		if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any = form__2; if linked_700 == nil { tmp1 = ifn_701.Invoke_O__O(arg_702) } else { tmp1 = linked_700.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_699, arg_702) }
//line :468:1
		if jrt.J2g_Truth(tmp1) {

			var root_703 any = A_arbace_test_A_const_21.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = form__2; if linked_704 == nil { return ifn_705.Invoke_O__O(arg_706) } else { return linked_704.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_703, arg_706) } } else {
//line :468:1
				if A_arbace_test_A_const_95 != nil { return A_arbace_test_A_const_96 } else { return nil
				}
			}
	}
}
func A_arbace_test_eval196000086_fn__196000087_A_New() *A_arbace_test_eval196000086_fn__196000087_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000086_fn__196000087_A{}; t.Ctor(); return t }
//line :473:1
func (t *A_arbace_test_eval196000086_fn__196000087_A) Ctor() {}
//line :473:1
func (t *A_arbace_test_eval196000086_fn__196000087_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any { var root_728 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any; var root_723 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_97); var arg_727 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp2 any; var root_718 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_718, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_720 lang.IFn; if linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any = A_arbace_test_A_const_50.GetRawRoot__O(); var arg_722 any; var root_714 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_59), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1)); if linked_715 == nil { arg_722 = ifn_716.Invoke_O__O(arg_717) } else { arg_722 = linked_715.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_714, arg_717) }; if linked_719 == nil { tmp2 = ifn_720.Invoke_O_O__O(arg_721, arg_722) } else { tmp2 = linked_719.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_718, arg_721, arg_722) }; arg_727 = tmp1.Invoke_O__O(tmp2); if linked_724 == nil { arg_731 = ifn_725.Invoke_O_O__O(arg_726, arg_727) } else { arg_731 = linked_724.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_723, arg_726, arg_727) }; if linked_729 == nil { return ifn_730.Invoke_O__O(arg_731) } else { return linked_729.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_728, arg_731) } }



func A_arbace_test_eval196000090_fn__196000091_A_New() *A_arbace_test_eval196000090_fn__196000091_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000090_fn__196000091_A{}; t.Ctor(); return t }
//line :477:1
func (t *A_arbace_test_eval196000090_fn__196000091_A) Ctor() {}
//line :477:1
func (t *A_arbace_test_eval196000090_fn__196000091_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any; var root_732 any = A_arbace_test_A_const_98.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_sequential_QMARK__A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = form__2; if linked_733 == nil { and__1927000168__auto____3 = ifn_734.Invoke_O__O(arg_735) } else { and__1927000168__auto____3 = linked_733.(*aot_arbace_core.A_arbace_core_sequential_QMARK__A).Invoke_O_O__O(root_732, arg_735) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_740 any = A_arbace_test_A_const_99.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, A_arbace_test_function_QMARK__A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any; var root_736 any = A_arbace_test_A_const_21.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_738 lang.IFn; if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = form__2; if linked_737 == nil { arg_743 = ifn_738.Invoke_O__O(arg_739) } else { arg_743 = linked_737.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_736, arg_739) }; if linked_741 == nil { tmp1 = ifn_742.Invoke_O__O(arg_743) } else { tmp1 = linked_741.(*A_arbace_test_function_QMARK__A).Invoke_O_O__O(root_740, arg_743) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var root_744 any = A_arbace_test_A_const_100.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, A_arbace_test_assert_predicate_A_fn_class); var ifn_746 lang.IFn; if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any = msg__1; var arg_748 any = form__2; if linked_745 == nil { return ifn_746.Invoke_O_O__O(arg_747, arg_748) } else { return linked_745.(*A_arbace_test_assert_predicate_A).Invoke_O_O_O__O(root_744, arg_747, arg_748) } } else {
			var root_749 any = A_arbace_test_A_const_101.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, A_arbace_test_assert_any_A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = msg__1; var arg_753 any = form__2; if linked_750 == nil { return ifn_751.Invoke_O_O__O(arg_752, arg_753) } else { return linked_750.(*A_arbace_test_assert_any_A).Invoke_O_O_O__O(root_749, arg_752, arg_753)
			} } }
func A_arbace_test_eval196000097_fn__196000098_A_New() *A_arbace_test_eval196000097_fn__196000098_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000097_fn__196000098_A{}; t.Ctor(); return t }
//line :482:1
func (t *A_arbace_test_eval196000097_fn__196000098_A) Ctor() {}
//line :482:1
func (t *A_arbace_test_eval196000097_fn__196000098_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any { var root_916 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_102); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp4 any; var root_765 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = A_arbace_test_A_const_16.GetRawRoot__O(); var arg_769 any; var root_761 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_103), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(form__2, lang.RT_IntCast_J__I_NoInit(1))), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_104), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(form__2, lang.RT_IntCast_J__I_NoInit(2)))); if linked_762 == nil { arg_769 = ifn_763.Invoke_O__O(arg_764) } else { arg_769 = linked_762.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_761, arg_764) }; if linked_766 == nil { tmp4 = ifn_767.Invoke_O_O__O(arg_768, arg_769) } else { tmp4 = linked_766.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_765, arg_768, arg_769) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp7 any; var root_906 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_105); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp11 any; var root_789 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = A_arbace_test_A_const_16.GetRawRoot__O(); var arg_793 any; var root_785 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any; var root_780 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_106); var arg_784 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp13 any; var root_776 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_107), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_103), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_104)); if linked_777 == nil { tmp13 = ifn_778.Invoke_O__O(arg_779) } else { tmp13 = linked_777.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_776, arg_779) }; arg_784 = tmp12.Invoke_O__O(tmp13); if linked_781 == nil { arg_788 = ifn_782.Invoke_O_O__O(arg_783, arg_784) } else { arg_788 = linked_781.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_780, arg_783, arg_784) }; if linked_786 == nil { arg_793 = ifn_787.Invoke_O__O(arg_788) } else { arg_793 = linked_786.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_785, arg_788) }; if linked_790 == nil { tmp11 = ifn_791.Invoke_O_O__O(arg_792, arg_793) } else { tmp11 = linked_790.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_789, arg_792, arg_793) }; var tmp14 any = tmp10.Invoke_O__O(tmp11); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp16 any; var root_895 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp18 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_108); var tmp19 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_106); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp21 any; var root_837 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any; var root_832 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_109); var arg_836 any; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp23 any; var root_827 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = A_arbace_test_A_const_50.GetRawRoot__O(); var arg_831 any; var root_823 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_825 lang.IFn; if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp25 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39); var tmp26 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_54); var tmp27 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_59); var tmp28 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1); var tmp29 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp31 any; var root_799 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any; var root_794 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_796 lang.IFn; if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82); var arg_798 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2); if linked_795 == nil { arg_802 = ifn_796.Invoke_O_O__O(arg_797, arg_798) } else { arg_802 = linked_795.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_794, arg_797, arg_798) }; if linked_800 == nil { tmp31 = ifn_801.Invoke_O__O(arg_802) } else { tmp31 = linked_800.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_799, arg_802) }; var tmp32 any = tmp30.Invoke_O__O(tmp31); var tmp33 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_43); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp35 any; var root_808 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any; var root_803 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_110); var arg_807 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_104); if linked_804 == nil { arg_811 = ifn_805.Invoke_O_O__O(arg_806, arg_807) } else { arg_811 = linked_804.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_803, arg_806, arg_807) }; if linked_809 == nil { tmp35 = ifn_810.Invoke_O__O(arg_811) } else { tmp35 = linked_809.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_808, arg_811) }; arg_826 = tmp24.Invoke_O_O_O_O_O_O_O_O__O(tmp25, tmp26, tmp27, tmp28, tmp29, tmp32, tmp33, tmp34.Invoke_O__O(tmp35)); if linked_824 == nil { arg_831 = ifn_825.Invoke_O__O(arg_826) } else { arg_831 = linked_824.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_823, arg_826) }; if linked_828 == nil { tmp23 = ifn_829.Invoke_O_O__O(arg_830, arg_831) } else { tmp23 = linked_828.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_827, arg_830, arg_831) }; arg_836 = tmp22.Invoke_O__O(tmp23); if linked_833 == nil { arg_840 = ifn_834.Invoke_O_O__O(arg_835, arg_836) } else { arg_840 = linked_833.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_832, arg_835, arg_836) }; if linked_838 == nil { tmp21 = ifn_839.Invoke_O__O(arg_840) } else { tmp21 = linked_838.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_837, arg_840) }; var tmp36 any = tmp20.Invoke_O__O(tmp21); var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp38 any; var root_884 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any; var root_879 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_879, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_881 lang.IFn; if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_111); var arg_883 any; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp40 any; var root_874 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_874, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any = A_arbace_test_A_const_50.GetRawRoot__O(); var arg_878 any; var root_870 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any; var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp42 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39); var tmp43 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44); var tmp44 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_59); var tmp45 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1); var tmp46 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60); var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp48 any; var root_846 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any; var root_841 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82); var arg_845 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2); if linked_842 == nil { arg_849 = ifn_843.Invoke_O_O__O(arg_844, arg_845) } else { arg_849 = linked_842.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_841, arg_844, arg_845) }; if linked_847 == nil { tmp48 = ifn_848.Invoke_O__O(arg_849) } else { tmp48 = linked_847.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_846, arg_849) }; var tmp49 any = tmp47.Invoke_O__O(tmp48); var tmp50 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_43); var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp52 any; var root_855 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any; var root_850 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_112); var arg_854 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_104); if linked_851 == nil { arg_858 = ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { arg_858 = linked_851.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_850, arg_853, arg_854) }; if linked_856 == nil { tmp52 = ifn_857.Invoke_O__O(arg_858) } else { tmp52 = linked_856.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_855, arg_858) }; arg_873 = tmp41.Invoke_O_O_O_O_O_O_O_O__O(tmp42, tmp43, tmp44, tmp45, tmp46, tmp49, tmp50, tmp51.Invoke_O__O(tmp52)); if linked_871 == nil { arg_878 = ifn_872.Invoke_O__O(arg_873) } else { arg_878 = linked_871.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_870, arg_873) }; if linked_875 == nil { tmp40 = ifn_876.Invoke_O_O__O(arg_877, arg_878) } else { tmp40 = linked_875.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_874, arg_877, arg_878) }; arg_883 = tmp39.Invoke_O__O(tmp40); if linked_880 == nil { arg_887 = ifn_881.Invoke_O_O__O(arg_882, arg_883) } else { arg_887 = linked_880.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_879, arg_882, arg_883) }; if linked_885 == nil { tmp38 = ifn_886.Invoke_O__O(arg_887) } else { tmp38 = linked_885.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_884, arg_887) }; arg_898 = tmp17.Invoke_O_O_O_O__O(tmp18, tmp19, tmp36, tmp37.Invoke_O__O(tmp38)); if linked_896 == nil { tmp16 = ifn_897.Invoke_O__O(arg_898) } else { tmp16 = linked_896.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_895, arg_898) }; arg_909 = tmp8.Invoke_O_O_O_O__O(tmp9, tmp14, tmp15.Invoke_O__O(tmp16), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_106)); if linked_907 == nil { tmp7 = ifn_908.Invoke_O__O(arg_909) } else { tmp7 = linked_907.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_906, arg_909) }; arg_919 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_917 == nil { return ifn_918.Invoke_O__O(arg_919) } else { return linked_917.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_916, arg_919) } }











func A_arbace_test_eval196000102_fn__196000103_A_New() *A_arbace_test_eval196000102_fn__196000103_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000102_fn__196000103_A{}; t.Ctor(); return t }
//line :494:1
func (t *A_arbace_test_eval196000102_fn__196000103_A) Ctor() {}
//line :494:1
func (t *A_arbace_test_eval196000102_fn__196000103_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any { var klass__3 any; var root_920 any = A_arbace_test_A_const_113.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_922 lang.IFn; if



	linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = form__2; if linked_921 == nil { klass__3 = ifn_922.Invoke_O__O(arg_923) } else { klass__3 = linked_921.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_920, arg_923) }; var body__4 any; var root_924 any = /*line :494:1*/A_arbace_test_A_const_114.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_nthnext_A_fn_class); var ifn_926 lang.IFn; if




	linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = form__2; var arg_928 any = A_arbace_test_A_const_115; if linked_925 == nil { body__4 = ifn_926.Invoke_O_O__O(arg_927, arg_928) } else { body__4 = linked_925.(*aot_arbace_core.A_arbace_core_nthnext_A).Invoke_O_O_O__O(root_924, arg_927, arg_928) }; var root_1024 any = /*line :498:1*/A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_116); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp4 any; var root_963 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any; var root_958 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_117); var arg_962 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp6 any; var root_953 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_954 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_953, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_955 lang.IFn; if linked_954 == nil { ifn_955 = lang.IFn_Cast(root_953) } else { ifn_955 = nil }; var arg_956 any = A_arbace_test_A_const_50.GetRawRoot__O(); var arg_957 any; var root_949 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_949, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_951 lang.IFn; if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp8 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39); var tmp9 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44); var tmp10 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_59); var tmp11 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1); var tmp12 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp14 any; var root_934 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any; var root_929 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82); var arg_933 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2); if linked_930 == nil { arg_937 = ifn_931.Invoke_O_O__O(arg_932, arg_933) } else { arg_937 = linked_930.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_929, arg_932, arg_933) }; if linked_935 == nil { tmp14 = ifn_936.Invoke_O__O(arg_937) } else { tmp14 = linked_935.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_934, arg_937) }; arg_952 = tmp7.Invoke_O_O_O_O_O_O_O_O__O(tmp8, tmp9, tmp10, tmp11, tmp12, tmp13.Invoke_O__O(tmp14), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_43), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(nil)); if linked_950 == nil { arg_957 = ifn_951.Invoke_O__O(arg_952) } else { arg_957 = linked_950.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_949, arg_952) }; if linked_954 == nil { tmp6 = ifn_955.Invoke_O_O__O(arg_956, arg_957) } else { tmp6 = linked_954.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_953, arg_956, arg_957) }; arg_962 = tmp5.Invoke_O__O(tmp6); if linked_959 == nil { arg_966 = ifn_960.Invoke_O_O__O(arg_961, arg_962) } else { arg_966 = linked_959.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_958, arg_961, arg_962) }; if linked_964 == nil { tmp4 = ifn_965.Invoke_O__O(arg_966) } else { tmp4 = linked_964.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_963, arg_966) }; var tmp15 any = tmp3.Invoke_O__O(tmp4); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp17 any; var root_1013 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp19 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_118); var tmp20 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(klass__3); var tmp21 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_119); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp23 any; var root_1001 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1001, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1003 lang.IFn; if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any; var root_996 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_120); var arg_1000 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp25 any; var root_991 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_991, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_993 lang.IFn; if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any = A_arbace_test_A_const_50.GetRawRoot__O(); var arg_995 any; var root_987 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_987, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_989 lang.IFn; if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp27 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39); var tmp28 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_54); var tmp29 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_59); var tmp30 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1); var tmp31 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp33 any; var root_972 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_974 lang.IFn; if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any; var root_967 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82); var arg_971 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2); if linked_968 == nil { arg_975 = ifn_969.Invoke_O_O__O(arg_970, arg_971) } else { arg_975 = linked_968.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_967, arg_970, arg_971) }; if linked_973 == nil { tmp33 = ifn_974.Invoke_O__O(arg_975) } else { tmp33 = linked_973.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_972, arg_975) }; arg_990 = tmp26.Invoke_O_O_O_O_O_O_O_O__O(tmp27, tmp28, tmp29, tmp30, tmp31, tmp32.Invoke_O__O(tmp33), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_43), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_119)); if linked_988 == nil { arg_995 = ifn_989.Invoke_O__O(arg_990) } else { arg_995 = linked_988.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_987, arg_990) }; if linked_992 == nil { tmp25 = ifn_993.Invoke_O_O__O(arg_994, arg_995) } else { tmp25 = linked_992.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_991, arg_994, arg_995) }; arg_1000 = tmp24.Invoke_O__O(tmp25); if linked_997 == nil { arg_1004 = ifn_998.Invoke_O_O__O(arg_999, arg_1000) } else { arg_1004 = linked_997.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_996, arg_999, arg_1000) }; if linked_1002 == nil { tmp23 = ifn_1003.Invoke_O__O(arg_1004) } else { tmp23 = linked_1002.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1001, arg_1004) }; arg_1016 = tmp18.Invoke_O_O_O_O_O__O(tmp19, tmp20, tmp21, tmp22.Invoke_O__O(tmp23), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_119)); if linked_1014 == nil { tmp17 = ifn_1015.Invoke_O__O(arg_1016) } else { tmp17 = linked_1014.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1013, arg_1016) }; arg_1027 = tmp1.Invoke_O_O_O_O__O(tmp2, body__4, tmp15, tmp16.Invoke_O__O(tmp17)); if linked_1025 == nil { return ifn_1026.Invoke_O__O(arg_1027) } else { return linked_1025.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1024, arg_1027) } }









func A_arbace_test_eval196000108_fn__196000109_A_New() *A_arbace_test_eval196000108_fn__196000109_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000108_fn__196000109_A{}; t.Ctor(); return t }
//line :508:1
func (t *A_arbace_test_eval196000108_fn__196000109_A) Ctor() {}
//line :508:1
func (t *A_arbace_test_eval196000108_fn__196000109_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any { var klass__3 any = lang.RT_Nth_O_I__O_NoInit(form__2, lang.RT_IntCast_J__I_NoInit(1)); var re__4 any = lang.RT_Nth_O_I__O_NoInit(form__2, lang.RT_IntCast_J__I_NoInit(2)); var body__5 any; var root_1028 any = A_arbace_test_A_const_114.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_nthnext_A_fn_class); var ifn_1030 lang.IFn; if






	linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = form__2; var arg_1032 any = A_arbace_test_A_const_121; if linked_1029 == nil { body__5 = ifn_1030.Invoke_O_O__O(arg_1031, arg_1032) } else { body__5 = linked_1029.(*aot_arbace_core.A_arbace_core_nthnext_A).Invoke_O_O_O__O(root_1028, arg_1031, arg_1032) }; var root_1220 any = /*line :513:1*/A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_122); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp4 any; var root_1067 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1069 lang.IFn; if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any; var root_1062 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1062, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1064 lang.IFn; if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_123); var arg_1066 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp6 any; var root_1057 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = A_arbace_test_A_const_50.GetRawRoot__O(); var arg_1061 any; var root_1053 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp8 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39); var tmp9 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44); var tmp10 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_59); var tmp11 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1); var tmp12 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp14 any; var root_1038 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1040 lang.IFn; if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any; var root_1033 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82); var arg_1037 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2); if linked_1034 == nil { arg_1041 = ifn_1035.Invoke_O_O__O(arg_1036, arg_1037) } else { arg_1041 = linked_1034.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1033, arg_1036, arg_1037) }; if linked_1039 == nil { tmp14 = ifn_1040.Invoke_O__O(arg_1041) } else { tmp14 = linked_1039.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1038, arg_1041) }; arg_1056 = tmp7.Invoke_O_O_O_O_O_O_O_O__O(tmp8, tmp9, tmp10, tmp11, tmp12, tmp13.Invoke_O__O(tmp14), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_43), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(nil)); if linked_1054 == nil { arg_1061 = ifn_1055.Invoke_O__O(arg_1056) } else { arg_1061 = linked_1054.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1053, arg_1056) }; if linked_1058 == nil { tmp6 = ifn_1059.Invoke_O_O__O(arg_1060, arg_1061) } else { tmp6 = linked_1058.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1057, arg_1060, arg_1061) }; arg_1066 = tmp5.Invoke_O__O(tmp6); if linked_1063 == nil { arg_1070 = ifn_1064.Invoke_O_O__O(arg_1065, arg_1066) } else { arg_1070 = linked_1063.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1062, arg_1065, arg_1066) }; if linked_1068 == nil { tmp4 = ifn_1069.Invoke_O__O(arg_1070) } else { tmp4 = linked_1068.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1067, arg_1070) }; var tmp15 any = tmp3.Invoke_O__O(tmp4); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp17 any; var root_1209 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp19 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_124); var tmp20 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(klass__3); var tmp21 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_125); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp23 any; var root_1197 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1199 lang.IFn; if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp25 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_126); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp27 any; var root_1089 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1089, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1091 lang.IFn; if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = A_arbace_test_A_const_16.GetRawRoot__O(); var arg_1093 any; var root_1085 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any; var root_1080 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1080, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1082 lang.IFn; if linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_127); var arg_1084 any; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp29 any; var root_1076 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1076, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1078 lang.IFn; if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any; var root_1071 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_128); var arg_1075 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_125); if linked_1072 == nil { arg_1079 = ifn_1073.Invoke_O_O__O(arg_1074, arg_1075) } else { arg_1079 = linked_1072.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1071, arg_1074, arg_1075) }; if linked_1077 == nil { tmp29 = ifn_1078.Invoke_O__O(arg_1079) } else { tmp29 = linked_1077.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1076, arg_1079) }; arg_1084 = tmp28.Invoke_O__O(tmp29); if linked_1081 == nil { arg_1088 = ifn_1082.Invoke_O_O__O(arg_1083, arg_1084) } else { arg_1088 = linked_1081.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1080, arg_1083, arg_1084) }; if linked_1086 == nil { arg_1093 = ifn_1087.Invoke_O__O(arg_1088) } else { arg_1093 = linked_1086.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1085, arg_1088) }; if linked_1090 == nil { tmp27 = ifn_1091.Invoke_O_O__O(arg_1092, arg_1093) } else { tmp27 = linked_1090.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1089, arg_1092, arg_1093) }; var tmp30 any = tmp26.Invoke_O__O(tmp27); var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp32 any; var root_1187 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1189 lang.IFn; if linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp34 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_129); var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp36 any; var root_1100 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1102 lang.IFn; if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_130), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(re__4), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_127)); if linked_1101 == nil { tmp36 = ifn_1102.Invoke_O__O(arg_1103) } else { tmp36 = linked_1101.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1100, arg_1103) }; var tmp37 any = tmp35.Invoke_O__O(tmp36); var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp39 any; var root_1138 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any; var root_1133 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_131); var arg_1137 any; var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp41 any; var root_1128 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1128, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1130 lang.IFn; if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = A_arbace_test_A_const_50.GetRawRoot__O(); var arg_1132 any; var root_1124 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1126 lang.IFn; if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any; var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp43 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39); var tmp44 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_54); var tmp45 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_59); var tmp46 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1); var tmp47 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60); var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp49 any; var root_1109 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any; var root_1104 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1104, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82); var arg_1108 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2); if linked_1105 == nil { arg_1112 = ifn_1106.Invoke_O_O__O(arg_1107, arg_1108) } else { arg_1112 = linked_1105.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1104, arg_1107, arg_1108) }; if linked_1110 == nil { tmp49 = ifn_1111.Invoke_O__O(arg_1112) } else { tmp49 = linked_1110.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1109, arg_1112) }; arg_1127 = tmp42.Invoke_O_O_O_O_O_O_O_O__O(tmp43, tmp44, tmp45, tmp46, tmp47, tmp48.Invoke_O__O(tmp49), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_43), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_125)); if linked_1125 == nil { arg_1132 = ifn_1126.Invoke_O__O(arg_1127) } else { arg_1132 = linked_1125.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1124, arg_1127) }; if linked_1129 == nil { tmp41 = ifn_1130.Invoke_O_O__O(arg_1131, arg_1132) } else { tmp41 = linked_1129.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1128, arg_1131, arg_1132) }; arg_1137 = tmp40.Invoke_O__O(tmp41); if linked_1134 == nil { arg_1141 = ifn_1135.Invoke_O_O__O(arg_1136, arg_1137) } else { arg_1141 = linked_1134.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1133, arg_1136, arg_1137) }; if linked_1139 == nil { tmp39 = ifn_1140.Invoke_O__O(arg_1141) } else { tmp39 = linked_1139.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1138, arg_1141) }; var tmp50 any = tmp38.Invoke_O__O(tmp39); var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp52 any; var root_1176 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1178 lang.IFn; if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any; var root_1171 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_132); var arg_1175 any; var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp54 any; var root_1166 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1166, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = A_arbace_test_A_const_50.GetRawRoot__O(); var arg_1170 any; var root_1162 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1162, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1164 lang.IFn; if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any; var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp56 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39); var tmp57 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_44); var tmp58 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_59); var tmp59 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__1); var tmp60 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60); var tmp61 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp62 any; var root_1147 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any; var root_1142 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1142, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1144 lang.IFn; if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82); var arg_1146 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2); if linked_1143 == nil { arg_1150 = ifn_1144.Invoke_O_O__O(arg_1145, arg_1146) } else { arg_1150 = linked_1143.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1142, arg_1145, arg_1146) }; if linked_1148 == nil { tmp62 = ifn_1149.Invoke_O__O(arg_1150) } else { tmp62 = linked_1148.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1147, arg_1150) }; arg_1165 = tmp55.Invoke_O_O_O_O_O_O_O_O__O(tmp56, tmp57, tmp58, tmp59, tmp60, tmp61.Invoke_O__O(tmp62), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_43), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_125)); if linked_1163 == nil { arg_1170 = ifn_1164.Invoke_O__O(arg_1165) } else { arg_1170 = linked_1163.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1162, arg_1165) }; if linked_1167 == nil { tmp54 = ifn_1168.Invoke_O_O__O(arg_1169, arg_1170) } else { tmp54 = linked_1167.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1166, arg_1169, arg_1170) }; arg_1175 = tmp53.Invoke_O__O(tmp54); if linked_1172 == nil { arg_1179 = ifn_1173.Invoke_O_O__O(arg_1174, arg_1175) } else { arg_1179 = linked_1172.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1171, arg_1174, arg_1175) }; if linked_1177 == nil { tmp52 = ifn_1178.Invoke_O__O(arg_1179) } else { tmp52 = linked_1177.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1176, arg_1179) }; arg_1190 = tmp33.Invoke_O_O_O_O__O(tmp34, tmp37, tmp50, tmp51.Invoke_O__O(tmp52)); if linked_1188 == nil { tmp32 = ifn_1189.Invoke_O__O(arg_1190) } else { tmp32 = linked_1188.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1187, arg_1190) }; arg_1200 = tmp24.Invoke_O_O_O__O(tmp25, tmp30, tmp31.Invoke_O__O(tmp32)); if linked_1198 == nil { tmp23 = ifn_1199.Invoke_O__O(arg_1200) } else { tmp23 = linked_1198.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1197, arg_1200) }; arg_1212 = tmp18.Invoke_O_O_O_O_O__O(tmp19, tmp20, tmp21, tmp22.Invoke_O__O(tmp23), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_125)); if linked_1210 == nil { tmp17 = ifn_1211.Invoke_O__O(arg_1212) } else { tmp17 = linked_1210.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1209, arg_1212) }; arg_1223 = tmp1.Invoke_O_O_O_O__O(tmp2, body__5, tmp15, tmp16.Invoke_O__O(tmp17)); if linked_1221 == nil { return ifn_1222.Invoke_O__O(arg_1223) } else { return linked_1221.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1220, arg_1223) } }













func A_arbace_test_try_expr_A_New() *A_arbace_test_try_expr_A { A_arbace_test_A_Init(); t := &A_arbace_test_try_expr_A{}; t.Ctor(); return t }
//line :527:1
func (t *A_arbace_test_try_expr_A) Ctor() {}
//line :527:1
func (t *A_arbace_test_try_expr_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, msg__2, form__3 any) any { var root_1279 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1281 lang.IFn; if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_133); var tmp3 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_A_const_134.GetRawRoot__O()).Invoke_O_O__O(msg__2, form__3)); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp5 any; var root_1269 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp7 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_135); var tmp8 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_136); var tmp9 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_137); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp11 any; var root_1258 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1258, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any; var root_1253 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1253, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1255 lang.IFn; if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_138); var arg_1257 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp13 any; var root_1248 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any = A_arbace_test_A_const_50.GetRawRoot__O(); var arg_1252 any; var root_1244 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1246 lang.IFn; if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp15 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_39); var tmp16 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_40); var tmp17 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_59); var tmp18 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__2); var tmp19 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_60); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp21 any; var root_1229 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1231 lang.IFn; if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any; var root_1224 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_82); var arg_1228 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__3); if linked_1225 == nil { arg_1232 = ifn_1226.Invoke_O_O__O(arg_1227, arg_1228) } else { arg_1232 = linked_1225.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1224, arg_1227, arg_1228) }; if linked_1230 == nil { tmp21 = ifn_1231.Invoke_O__O(arg_1232) } else { tmp21 = linked_1230.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1229, arg_1232) }; arg_1247 = tmp14.Invoke_O_O_O_O_O_O_O_O__O(tmp15, tmp16, tmp17, tmp18, tmp19, tmp20.Invoke_O__O(tmp21), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_43), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_137)); if linked_1245 == nil { arg_1252 = ifn_1246.Invoke_O__O(arg_1247) } else { arg_1252 = linked_1245.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1244, arg_1247) }; if linked_1249 == nil { tmp13 = ifn_1250.Invoke_O_O__O(arg_1251, arg_1252) } else { tmp13 = linked_1249.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1248, arg_1251, arg_1252) }; arg_1257 = tmp12.Invoke_O__O(tmp13); if linked_1254 == nil { arg_1261 = ifn_1255.Invoke_O_O__O(arg_1256, arg_1257) } else { arg_1261 = linked_1254.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1253, arg_1256, arg_1257) }; if linked_1259 == nil { tmp11 = ifn_1260.Invoke_O__O(arg_1261) } else { tmp11 = linked_1259.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1258, arg_1261) }; arg_1272 = tmp6.Invoke_O_O_O_O__O(tmp7, tmp8, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_1270 == nil { tmp5 = ifn_1271.Invoke_O__O(arg_1272) } else { tmp5 = linked_1270.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1269, arg_1272) }; arg_1282 = tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O__O(tmp5)); if linked_1280 == nil { return ifn_1281.Invoke_O__O(arg_1282) } else { return linked_1280.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1279, arg_1282) } }













func A_arbace_test_is_A_New() *A_arbace_test_is_A { A_arbace_test_A_Init(); t := &A_arbace_test_is_A{}; t.Ctor(); return t }
//line :541:1
func (t *A_arbace_test_is_A) Ctor() {}
//line :541:1
func (t *A_arbace_test_is_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, form__2, msg__3 any) any { var root_1289 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_139), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(msg__3), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2)); if linked_1290 == nil { return ifn_1291.Invoke_O__O(arg_1292) } else { return linked_1290.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1289, arg_1292) } }
//line :541:1
func (t *A_arbace_test_is_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, form__2 any) any { var root_1299 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_140), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(form__2), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(nil)); if linked_1300 == nil { return ifn_1301.Invoke_O__O(arg_1302) } else { return linked_1300.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1299, arg_1302) } }

















func A_arbace_test_are_A_New() *A_arbace_test_are_A { A_arbace_test_A_Init(); t := &A_arbace_test_are_A{}; t.Ctor(); return t }
//line :559:1
func (t *A_arbace_test_are_A) Ctor() {}
//line :559:1
func (t *A_arbace_test_are_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, argv__2, expr__3, args__4 any) any {














	var tmp1 any; var or__1927000174__auto____6 any; var and__1927000168__auto____6 any; var root_1303 any = A_arbace_test_A_const_141.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1305 lang.IFn

	if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = argv__2; if linked_1304 == nil { and__1927000168__auto____6 = ifn_1305.Invoke_O__O(arg_1306) } else { and__1927000168__auto____6 = linked_1304.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1303, arg_1306) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1307 any = A_arbace_test_A_const_141.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = args__4; if linked_1308 == nil { or__1927000174__auto____6 = ifn_1309.Invoke_O__O(arg_1310) } else { or__1927000174__auto____6 = linked_1308.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1307, arg_1310) } } else { or__1927000174__auto____6 = and__1927000168__auto____6 }
//line :574:1
	if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { var and__1927000168__auto____7 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(argv__2)))



		if and__1927000168__auto____7 { var and__1927000168__auto____8 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(args__4))); if and__1927000168__auto____8 {

			var tmp2 bool; var na_1311 any; var root_1312 any = A_arbace_test_A_const_142.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_mod_A_fn_class); var ifn_1314 lang.IFn; if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(args__4)).Ref(); var arg_1316 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(argv__2)).Ref(); if linked_1313 == nil { na_1311 = ifn_1314.Invoke_O_O__O(arg_1315, arg_1316) } else { na_1311 = linked_1313.(*aot_arbace_core.A_arbace_core_mod_A).Invoke_O_O_O__O(root_1312, arg_1315, arg_1316) }; if jrt.Long_InstanceOf(na_1311) { var n0_1317 int64 = jrt.NN(jrt.Long_Cast(na_1311)).LongValue__J(); tmp2 = n0_1317 == 0 } else { if jrt.Double_InstanceOf(na_1311) { var n0_1317_2 float64 = jrt.NN(jrt.Double_Cast(na_1311)).DoubleValue__D(); tmp2 = n0_1317_2 == 0.0 } else { tmp2 = lang.Numbers_IsZero_O__Z_NoInit(na_1311) } }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref() } else {
//line :578:1
				tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } }
//line :574:1
	if jrt.J2g_Truth(tmp1) { var root_1334 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp4 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_143); var tmp5 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(argv__2); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp7 any; var root_1323 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any; var root_1318 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1320 lang.IFn; if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_144); var arg_1322 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(expr__3); if linked_1319 == nil { arg_1326 = ifn_1320.Invoke_O_O__O(arg_1321, arg_1322) } else { arg_1326 = linked_1319.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1318, arg_1321, arg_1322) }; if linked_1324 == nil { tmp7 = ifn_1325.Invoke_O__O(arg_1326) } else { tmp7 = linked_1324.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1323, arg_1326) }; arg_1337 = tmp3.Invoke_O_O_O_O__O(tmp4, tmp5, tmp6.Invoke_O__O(tmp7), args__4); if linked_1335 == nil { return ifn_1336.Invoke_O__O(arg_1337) } else { return linked_1335.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1334, arg_1337) } } else { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(Lit_1)))
	}
}







func A_arbace_test_testing_A_New() *A_arbace_test_testing_A { A_arbace_test_A_Init(); t := &A_arbace_test_testing_A{}; t.Ctor(); return t }
//line :584:1
func (t *A_arbace_test_testing_A) Ctor() {}
//line :584:1
func (t *A_arbace_test_testing_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, string__2, body__3 any) any { var root_1368 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1370 lang.IFn; if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_145); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp4 any; var root_1357 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1357, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1359 lang.IFn; if linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = A_arbace_test_A_const_16.GetRawRoot__O(); var arg_1361 any; var root_1353 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any; var root_1348 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_146); var arg_1352 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp6 any; var root_1344 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1344, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1346 lang.IFn; if linked_1345 == nil { ifn_1346 = lang.IFn_Cast(root_1344) } else { ifn_1346 = nil }; var arg_1347 any = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_147), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_148), lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(string__2)); if linked_1345 == nil { tmp6 = ifn_1346.Invoke_O__O(arg_1347) } else { tmp6 = linked_1345.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1344, arg_1347) }; arg_1352 = tmp5.Invoke_O__O(tmp6); if linked_1349 == nil { arg_1356 = ifn_1350.Invoke_O_O__O(arg_1351, arg_1352) } else { arg_1356 = linked_1349.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1348, arg_1351, arg_1352) }; if linked_1354 == nil { arg_1361 = ifn_1355.Invoke_O__O(arg_1356) } else { arg_1361 = linked_1354.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1353, arg_1356) }; if linked_1358 == nil { tmp4 = ifn_1359.Invoke_O_O__O(arg_1360, arg_1361) } else { tmp4 = linked_1358.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1357, arg_1360, arg_1361) }; arg_1371 = tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4), body__3); if linked_1369 == nil { return ifn_1370.Invoke_O__O(arg_1371) } else { return linked_1369.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1368, arg_1371) } }









func A_arbace_test_with_test_A_New() *A_arbace_test_with_test_A { A_arbace_test_A_Init(); t := &A_arbace_test_with_test_A{}; t.Ctor(); return t }
//line :594:1
func (t *A_arbace_test_with_test_A) Ctor() {}
//line :594:1
func (t *A_arbace_test_with_test_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, definition__2, body__3 any) any {







	if jrt.J2g_Truth(A_arbace_test_A_const_149.Get__O()) { var root_1411 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1413 lang.IFn; if linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_150); var tmp3 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(definition__2); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp5 any; var root_1401 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1401, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1403 lang.IFn; if linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp7 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_151); var tmp8 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_152); var tmp9 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_64); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp11 any; var root_1390 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1390, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1392 lang.IFn; if linked_1391 == nil { ifn_1392 = lang.IFn_Cast(root_1390) } else { ifn_1392 = nil }; var arg_1393 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp13 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_153); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp15 any; var root_1379 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1381 lang.IFn; if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any = A_arbace_test_A_const_16.GetRawRoot__O(); var arg_1383 any; var root_1375 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1375, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1377 lang.IFn; if linked_1376 == nil { ifn_1377 = lang.IFn_Cast(root_1375) } else { ifn_1377 = nil }; var arg_1378 any; var root_1372 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1373 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1372, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1374 lang.IFn; if linked_1373 == nil { ifn_1374 = lang.IFn_Cast(root_1372) } else { ifn_1374 = nil }; if linked_1373 == nil { arg_1378 = ifn_1374.Invoke__O() } else { arg_1378 = linked_1373.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O__O(root_1372) }; if linked_1376 == nil { arg_1383 = ifn_1377.Invoke_O__O(arg_1378) } else { arg_1383 = linked_1376.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1375, arg_1378) }; if linked_1380 == nil { tmp15 = ifn_1381.Invoke_O_O__O(arg_1382, arg_1383) } else { tmp15 = linked_1380.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1379, arg_1382, arg_1383) }; arg_1393 = tmp12.Invoke_O_O_O__O(tmp13, tmp14.Invoke_O__O(tmp15), body__3); if linked_1391 == nil { tmp11 = ifn_1392.Invoke_O__O(arg_1393) } else { tmp11 = linked_1391.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1390, arg_1393) }; arg_1404 = tmp6.Invoke_O_O_O_O__O(tmp7, tmp8, tmp9, tmp10.Invoke_O__O(tmp11)); if linked_1402 == nil { tmp5 = ifn_1403.Invoke_O__O(arg_1404) } else { tmp5 = linked_1402.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1401, arg_1404) }; arg_1414 = tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O__O(tmp5)); if linked_1412 == nil { return ifn_1413.Invoke_O__O(arg_1414) } else { return linked_1412.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1411, arg_1414) } } else { return definition__2
	}
}

func A_arbace_test_deftest_A_New() *A_arbace_test_deftest_A { A_arbace_test_A_Init(); t := &A_arbace_test_deftest_A{}; t.Ctor(); return t }
//line :606:1
func (t *A_arbace_test_deftest_A) Ctor() {}
//line :606:1
func (t *A_arbace_test_deftest_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, body__3 any) any {












	if jrt.J2g_Truth(A_arbace_test_A_const_149.Get__O()) { var root_1490 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1492 lang.IFn; if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_154); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_155.GetRawRoot__O()); var tmp5 any = A_arbace_test_A_const_156.GetRawRoot__O(); var tmp6 any = A_arbace_test_A_const_64; var tmp7 any; var root_1433 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1435 lang.IFn
		if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_157); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp11 any; var root_1422 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1424 lang.IFn; if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = A_arbace_test_A_const_16.GetRawRoot__O(); var arg_1426 any; var root_1418 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1420 lang.IFn; if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any; var root_1415 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1416 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1415, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1417 lang.IFn; if linked_1416 == nil { ifn_1417 = lang.IFn_Cast(root_1415) } else { ifn_1417 = nil }; if linked_1416 == nil { arg_1421 = ifn_1417.Invoke__O() } else { arg_1421 = linked_1416.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O__O(root_1415) }; if linked_1419 == nil { arg_1426 = ifn_1420.Invoke_O__O(arg_1421) } else { arg_1426 = linked_1419.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1418, arg_1421) }; if linked_1423 == nil { tmp11 = ifn_1424.Invoke_O_O__O(arg_1425, arg_1426) } else { tmp11 = linked_1423.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1422, arg_1425, arg_1426) }; arg_1436 = tmp8.Invoke_O_O_O__O(tmp9, tmp10.Invoke_O__O(tmp11), body__3); if linked_1434 == nil { tmp7 = ifn_1435.Invoke_O__O(arg_1436) } else { tmp7 = linked_1434.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1433, arg_1436) }
//line :619:1
		var tmp12 any = tmp3.Invoke_O__O(tmp4.Invoke_O_O_O_O__O(name__2, tmp5, tmp6, tmp7)); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp14 any; var root_1480 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp16 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_158); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp18 any; var root_1451 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1451, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = A_arbace_test_A_const_16.GetRawRoot__O(); var arg_1455 any; var root_1447 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1447, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1449 lang.IFn; if linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any; var root_1444 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; if linked_1445 == nil { arg_1450 = ifn_1446.Invoke__O() } else { arg_1450 = linked_1445.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O__O(root_1444) }; if linked_1448 == nil { arg_1455 = ifn_1449.Invoke_O__O(arg_1450) } else { arg_1455 = linked_1448.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1447, arg_1450) }; if linked_1452 == nil { tmp18 = ifn_1453.Invoke_O_O__O(arg_1454, arg_1455) } else { tmp18 = linked_1452.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1451, arg_1454, arg_1455) }; var tmp19 any = tmp17.Invoke_O__O(tmp18); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp21 any; var root_1470 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any; var root_1465 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_159); var arg_1469 any; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp23 any; var root_1461 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1461, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1463 lang.IFn; if linked_1462 == nil { ifn_1463 = lang.IFn_Cast(root_1461) } else { ifn_1463 = nil }; var arg_1464 any; var root_1456 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1456, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1458 lang.IFn; if linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_160); var arg_1460 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(name__2); if linked_1457 == nil { arg_1464 = ifn_1458.Invoke_O_O__O(arg_1459, arg_1460) } else { arg_1464 = linked_1457.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1456, arg_1459, arg_1460) }; if linked_1462 == nil { tmp23 = ifn_1463.Invoke_O__O(arg_1464) } else { tmp23 = linked_1462.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1461, arg_1464) }; arg_1469 = tmp22.Invoke_O__O(tmp23); if linked_1466 == nil { arg_1473 = ifn_1467.Invoke_O_O__O(arg_1468, arg_1469) } else { arg_1473 = linked_1466.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1465, arg_1468, arg_1469) }; if linked_1471 == nil { tmp21 = ifn_1472.Invoke_O__O(arg_1473) } else { tmp21 = linked_1471.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1470, arg_1473) }; arg_1483 = tmp15.Invoke_O_O_O__O(tmp16, tmp19, tmp20.Invoke_O__O(tmp21)); if linked_1481 == nil { tmp14 = ifn_1482.Invoke_O__O(arg_1483) } else { tmp14 = linked_1481.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1480, arg_1483) }; arg_1493 = tmp1.Invoke_O_O_O__O(tmp2, tmp12, tmp13.Invoke_O__O(tmp14)); if linked_1491 == nil { return ifn_1492.Invoke_O__O(arg_1493) } else { return linked_1491.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1490, arg_1493) } } else { return nil
		}
}

func A_arbace_test_deftest__A_New() *A_arbace_test_deftest__A { A_arbace_test_A_Init(); t := &A_arbace_test_deftest__A{}; t.Ctor(); return t }
//line :623:1
func (t *A_arbace_test_deftest__A) Ctor() {}
//line :623:1
func (t *A_arbace_test_deftest__A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, body__3 any) any {



	if jrt.J2g_Truth(A_arbace_test_A_const_149.Get__O()) { var root_1571 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1571, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1573 lang.IFn; if linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_161); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_155.GetRawRoot__O()); var tmp5 any = A_arbace_test_A_const_156.GetRawRoot__O(); var tmp6 any = A_arbace_test_A_const_64; var tmp7 any; var root_1512 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1514 lang.IFn
		if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_162); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp11 any; var root_1501 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1503 lang.IFn; if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = A_arbace_test_A_const_16.GetRawRoot__O(); var arg_1505 any; var root_1497 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1499 lang.IFn; if linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any; var root_1494 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1495 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1494, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1496 lang.IFn; if linked_1495 == nil { ifn_1496 = lang.IFn_Cast(root_1494) } else { ifn_1496 = nil }; if linked_1495 == nil { arg_1500 = ifn_1496.Invoke__O() } else { arg_1500 = linked_1495.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O__O(root_1494) }; if linked_1498 == nil { arg_1505 = ifn_1499.Invoke_O__O(arg_1500) } else { arg_1505 = linked_1498.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1497, arg_1500) }; if linked_1502 == nil { tmp11 = ifn_1503.Invoke_O_O__O(arg_1504, arg_1505) } else { tmp11 = linked_1502.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1501, arg_1504, arg_1505) }; arg_1515 = tmp8.Invoke_O_O_O__O(tmp9, tmp10.Invoke_O__O(tmp11), body__3); if linked_1513 == nil { tmp7 = ifn_1514.Invoke_O__O(arg_1515) } else { tmp7 = linked_1513.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1512, arg_1515) }
//line :627:1
		var tmp12 any = tmp3.Invoke_O__O(tmp4.Invoke_O_O_O_O_O_O__O(name__2, tmp5, tmp6, tmp7, A_arbace_test_A_const_163, jrt.Boolean_TRUE.Ref())); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp14 any; var root_1561 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp16 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_164); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp18 any; var root_1532 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any = A_arbace_test_A_const_16.GetRawRoot__O(); var arg_1536 any; var root_1528 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1528, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1530 lang.IFn; if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any; var root_1525 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1525, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1527 lang.IFn; if linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; if linked_1526 == nil { arg_1531 = ifn_1527.Invoke__O() } else { arg_1531 = linked_1526.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O__O(root_1525) }; if linked_1529 == nil { arg_1536 = ifn_1530.Invoke_O__O(arg_1531) } else { arg_1536 = linked_1529.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1528, arg_1531) }; if linked_1533 == nil { tmp18 = ifn_1534.Invoke_O_O__O(arg_1535, arg_1536) } else { tmp18 = linked_1533.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1532, arg_1535, arg_1536) }; var tmp19 any = tmp17.Invoke_O__O(tmp18); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp21 any; var root_1551 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1551, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1553 lang.IFn; if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any; var root_1546 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_165); var arg_1550 any; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp23 any; var root_1542 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any; var root_1537 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_166); var arg_1541 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(name__2); if linked_1538 == nil { arg_1545 = ifn_1539.Invoke_O_O__O(arg_1540, arg_1541) } else { arg_1545 = linked_1538.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1537, arg_1540, arg_1541) }; if linked_1543 == nil { tmp23 = ifn_1544.Invoke_O__O(arg_1545) } else { tmp23 = linked_1543.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1542, arg_1545) }; arg_1550 = tmp22.Invoke_O__O(tmp23); if linked_1547 == nil { arg_1554 = ifn_1548.Invoke_O_O__O(arg_1549, arg_1550) } else { arg_1554 = linked_1547.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1546, arg_1549, arg_1550) }; if linked_1552 == nil { tmp21 = ifn_1553.Invoke_O__O(arg_1554) } else { tmp21 = linked_1552.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1551, arg_1554) }; arg_1564 = tmp15.Invoke_O_O_O__O(tmp16, tmp19, tmp20.Invoke_O__O(tmp21)); if linked_1562 == nil { tmp14 = ifn_1563.Invoke_O__O(arg_1564) } else { tmp14 = linked_1562.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1561, arg_1564) }; arg_1574 = tmp1.Invoke_O_O_O__O(tmp2, tmp12, tmp13.Invoke_O__O(tmp14)); if linked_1572 == nil { return ifn_1573.Invoke_O__O(arg_1574) } else { return linked_1572.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1571, arg_1574) } } else { return nil
		}
}

func A_arbace_test_set_test_A_New() *A_arbace_test_set_test_A { A_arbace_test_A_Init(); t := &A_arbace_test_set_test_A{}; t.Ctor(); return t }
//line :631:1
func (t *A_arbace_test_set_test_A) Ctor() {}
//line :631:1
func (t *A_arbace_test_set_test_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, body__3 any) any {







	if jrt.J2g_Truth(A_arbace_test_A_const_149.Get__O()) { var root_1614 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1614, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1616 lang.IFn; if linked_1615 == nil { ifn_1616 = lang.IFn_Cast(root_1614) } else { ifn_1616 = nil }; var arg_1617 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_167); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp4 any; var root_1580 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1580, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1582 lang.IFn; if linked_1581 == nil { ifn_1582 = lang.IFn_Cast(root_1580) } else { ifn_1582 = nil }; var arg_1583 any; var root_1575 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1576 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1575, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1577 lang.IFn; if linked_1576 == nil { ifn_1577 = lang.IFn_Cast(root_1575) } else { ifn_1577 = nil }; var arg_1578 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_168); var arg_1579 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(name__2); if linked_1576 == nil { arg_1583 = ifn_1577.Invoke_O_O__O(arg_1578, arg_1579) } else { arg_1583 = linked_1576.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1575, arg_1578, arg_1579) }; if linked_1581 == nil { tmp4 = ifn_1582.Invoke_O__O(arg_1583) } else { tmp4 = linked_1581.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1580, arg_1583) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_169); var tmp7 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_64); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp9 any; var root_1602 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1604 lang.IFn; if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_12.GetRawRoot__O()); var tmp11 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_170); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()); var tmp13 any; var root_1591 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = A_arbace_test_A_const_16.GetRawRoot__O(); var arg_1595 any; var root_1587 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1589 lang.IFn; if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any; var root_1584 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1585 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1584, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1586 lang.IFn; if linked_1585 == nil { ifn_1586 = lang.IFn_Cast(root_1584) } else { ifn_1586 = nil }; if linked_1585 == nil { arg_1590 = ifn_1586.Invoke__O() } else { arg_1590 = linked_1585.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O__O(root_1584) }; if linked_1588 == nil { arg_1595 = ifn_1589.Invoke_O__O(arg_1590) } else { arg_1595 = linked_1588.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1587, arg_1590) }; if linked_1592 == nil { tmp13 = ifn_1593.Invoke_O_O__O(arg_1594, arg_1595) } else { tmp13 = linked_1592.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1591, arg_1594, arg_1595) }; arg_1605 = tmp10.Invoke_O_O_O__O(tmp11, tmp12.Invoke_O__O(tmp13), body__3); if linked_1603 == nil { tmp9 = ifn_1604.Invoke_O__O(arg_1605) } else { tmp9 = linked_1603.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1602, arg_1605) }; arg_1617 = tmp1.Invoke_O_O_O_O_O__O(tmp2, tmp5, tmp6, tmp7, tmp8.Invoke_O__O(tmp9)); if linked_1615 == nil { return ifn_1616.Invoke_O__O(arg_1617) } else { return linked_1615.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1614, arg_1617) } } else { return nil
	}
}


func A_arbace_test_add_ns_meta_A_New() *A_arbace_test_add_ns_meta_A { A_arbace_test_A_Init(); t := &A_arbace_test_add_ns_meta_A{}; t.Ctor(); return t }
//line :644:1
func (t *A_arbace_test_add_ns_meta_A) Ctor() {}
//line :644:1
func (t *A_arbace_test_add_ns_meta_A) Invoke_O_O_O__O(self, key__0, coll__1 any) any {




	return lang.IFn_Cast(A_arbace_test_A_const_171.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_test_A_const_172.Get__O(), A_arbace_test_A_const_156.GetRawRoot__O(), key__0, coll__1)
}





func A_arbace_test_eval196000154_fn__196000155_A_New() *A_arbace_test_eval196000154_fn__196000155_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000154_fn__196000155_A{}; t.Ctor(); return t }
//line :656:1
func (t *A_arbace_test_eval196000154_fn__196000155_A) Ctor() {}
//line :656:1
func (t *A_arbace_test_eval196000154_fn__196000155_A) DoInvoke_O_O_O__O(self, fixture_type__1, args__2 any) any { return fixture_type__1 }

func A_arbace_test_eval196000158_fn__196000159_A_New() *A_arbace_test_eval196000158_fn__196000159_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000158_fn__196000159_A{}; t.Ctor(); return t }
//line :658:1
func (t *A_arbace_test_eval196000158_fn__196000159_A) Ctor() {}
//line :658:1
func (t *A_arbace_test_eval196000158_fn__196000159_A) DoInvoke_O_O_O__O(self, fixture_type__1, args__2 any) any {
	var root_1625 any = A_arbace_test_A_const_173.GetRawRoot__O(); var linked_1626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1625, A_arbace_test_add_ns_meta_A_fn_class); var ifn_1627 lang.IFn; if linked_1626 == nil { ifn_1627 = lang.IFn_Cast(root_1625) } else { ifn_1627 = nil }; var arg_1628 any = A_arbace_test_A_const_174; var arg_1629 any = args__2; if linked_1626 == nil { return ifn_1627.Invoke_O_O__O(arg_1628, arg_1629) } else { return linked_1626.(*A_arbace_test_add_ns_meta_A).Invoke_O_O_O__O(root_1625, arg_1628, arg_1629)
	} }
func A_arbace_test_eval196000162_fn__196000163_A_New() *A_arbace_test_eval196000162_fn__196000163_A { A_arbace_test_A_Init(); t := &A_arbace_test_eval196000162_fn__196000163_A{}; t.Ctor(); return t }
//line :661:1
func (t *A_arbace_test_eval196000162_fn__196000163_A) Ctor() {}
//line :661:1
func (t *A_arbace_test_eval196000162_fn__196000163_A) DoInvoke_O_O_O__O(self, fixture_type__1, args__2 any) any {
	var root_1630 any = A_arbace_test_A_const_173.GetRawRoot__O(); var linked_1631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1630, A_arbace_test_add_ns_meta_A_fn_class); var ifn_1632 lang.IFn; if linked_1631 == nil { ifn_1632 = lang.IFn_Cast(root_1630) } else { ifn_1632 = nil }; var arg_1633 any = A_arbace_test_A_const_175; var arg_1634 any = args__2; if linked_1631 == nil { return ifn_1632.Invoke_O_O__O(arg_1633, arg_1634) } else { return linked_1631.(*A_arbace_test_add_ns_meta_A).Invoke_O_O_O__O(root_1630, arg_1633, arg_1634)
	} }
func A_arbace_test_default_fixture_A_New() *A_arbace_test_default_fixture_A { A_arbace_test_A_Init(); t := &A_arbace_test_default_fixture_A{}; t.Ctor(); return t }
//line :664:1
func (t *A_arbace_test_default_fixture_A) Ctor() {}
//line :664:1
func (t *A_arbace_test_default_fixture_A) Invoke_O_O__O(self, f__0 any) any {



	return lang.IFn_Cast(f__0).Invoke__O()
}
func A_arbace_test_compose_fixtures_A_New() *A_arbace_test_compose_fixtures_A { A_arbace_test_A_Init(); t := &A_arbace_test_compose_fixtures_A{}; t.Ctor(); return t }
//line :670:1
func (t *A_arbace_test_compose_fixtures_A) Ctor() {}
//line :670:1
func (t *A_arbace_test_compose_fixtures_A) Invoke_O_O_O__O(self, f1__0, f2__1 any) any {




	var tmp1 any = A_arbace_test_compose_fixtures_fn__196000167_A_New_O_O(f1__0, f2__1); var tmp2 *jrt.Class; var fncls__1636 *jrt.Class = A_arbace_test_compose_fixtures_fn__196000167_A_fn_class; if fncls__1636 == nil { var fncls__1636d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_test_compose_fixtures_fn__196000167_A_fn_class = fncls__1636d; tmp2 = fncls__1636d } else { tmp2 = fncls__1636 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :675:1
func A_arbace_test_compose_fixtures_fn__196000167_A_New_O_O(p0, p1 any) *A_arbace_test_compose_fixtures_fn__196000167_A { A_arbace_test_A_Init(); t := &A_arbace_test_compose_fixtures_fn__196000167_A{}; t.Ctor_O_O(p0, p1); return t }
//line :675:1
func (t *A_arbace_test_compose_fixtures_fn__196000167_A) Ctor_O_O(c__f1, c__f2 any) { t.F_f1 = c__f1; t.F_f2 = c__f2 }
//line :675:1
func (t *A_arbace_test_compose_fixtures_fn__196000167_A) Invoke_O_O__O(self, g__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_f1); var tmp2 any = A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_New_O_O(g__1, t.F_f2); var tmp3 *jrt.Class; var fncls__1635 *jrt.Class = A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_fn_class; if fncls__1635 == nil { var fncls__1635d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_fn_class = fncls__1635d; tmp3 = fncls__1635d } else { tmp3 = fncls__1635 }; return tmp1.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) }
//line :675:1
func A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_New_O_O(p0, p1 any) *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A { A_arbace_test_A_Init(); t := &A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A{}; t.Ctor_O_O(p0, p1); return t }
//line :675:1
func (t *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A) Ctor_O_O(c__g, c__f2 any) { t.F_g = c__g; t.F_f2 = c__f2 }
//line :675:1
func (t *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f2).Invoke_O__O(t.F_g) }

func A_arbace_test_join_fixtures_A_New() *A_arbace_test_join_fixtures_A { A_arbace_test_A_Init(); t := &A_arbace_test_join_fixtures_A{}; t.Ctor(); return t }
//line :677:1
func (t *A_arbace_test_join_fixtures_A) Ctor() {}
//line :677:1
func (t *A_arbace_test_join_fixtures_A) Invoke_O_O__O(self, fixtures__0 any) any {




	var root_1637 any = A_arbace_test_A_const_176.GetRawRoot__O(); var linked_1638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1637, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1639 lang.IFn; if linked_1638 == nil { ifn_1639 = lang.IFn_Cast(root_1637) } else { ifn_1639 = nil }; var arg_1640 any = A_arbace_test_A_const_177.GetRawRoot__O(); var arg_1641 any = A_arbace_test_A_const_178.GetRawRoot__O(); var arg_1642 any = fixtures__0; if linked_1638 == nil { return ifn_1639.Invoke_O_O_O__O(arg_1640, arg_1641, arg_1642) } else { return linked_1638.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1637, arg_1640, arg_1641, arg_1642)
	}
}

func A_arbace_test_test_var_A_New() *A_arbace_test_test_var_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_var_A{}; t.Ctor(); return t }
//line :686:1
func (t *A_arbace_test_test_var_A) Ctor() {}
//line :686:1
func (t *A_arbace_test_test_var_A) Invoke_O_O__O(self, v__0 any) any { var tmp1 *lang.Keyword = A_arbace_test_A_const_64; var temp__1927000414__auto____2 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__0)); if




	jrt.J2g_Truth(temp__1927000414__auto____2) { var t__3 any = temp__1927000414__auto____2; var root_1660 any = A_arbace_test_A_const_49.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1662 lang.IFn
		if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp3 any = A_arbace_test_A_const_27; var tmp4 any; var root_1650 any = A_arbace_test_A_const_9.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1650, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1652 lang.IFn; if linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = A_arbace_test_A_const_27.Get__O(); var arg_1654 any = v__0; if linked_1651 == nil { tmp4 = ifn_1652.Invoke_O_O__O(arg_1653, arg_1654) } else { tmp4 = linked_1651.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1650, arg_1653, arg_1654) }; arg_1663 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_1661 == nil { ifn_1662.Invoke_O__O(arg_1663) } else { linked_1661.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1660, arg_1663) }
//line :691:1
		var tmp5 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

			{ var root_1664 any = A_arbace_test_A_const_179.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, A_arbace_test_do_report_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_A_const_39, A_arbace_test_A_const_182, A_arbace_test_A_const_181, v__0)); if linked_1665 == nil { ifn_1666.Invoke_O__O(arg_1667) } else { linked_1665.(*A_arbace_test_do_report_A).Invoke_O_O__O(root_1664, arg_1667) }
				var root_1668 any = A_arbace_test_A_const_53.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, A_arbace_test_inc_report_counter_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = A_arbace_test_A_const_64; if linked_1669 == nil { ifn_1670.Invoke_O__O(arg_1671) } else { linked_1669.(*A_arbace_test_inc_report_counter_A).Invoke_O_O__O(root_1668, arg_1671) }
				var tmp6 any = A_arbace_test_test_var_fn__196000173_A_New_O(t__3); var tmp7 *jrt.Class; var fncls__1676 *jrt.Class = A_arbace_test_test_var_fn__196000173_A_fn_class; if fncls__1676 == nil { var fncls__1676d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_test_test_var_fn__196000173_A_fn_class = fncls__1676d; tmp7 = fncls__1676d } else { tmp7 = fncls__1676 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()



				var root_1643 any = A_arbace_test_A_const_179.GetRawRoot__O(); var linked_1644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1643, A_arbace_test_do_report_A_fn_class); var ifn_1645 lang.IFn; if linked_1644 == nil { ifn_1645 = lang.IFn_Cast(root_1643) } else { ifn_1645 = nil }; var arg_1646 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_A_const_39, A_arbace_test_A_const_180, A_arbace_test_A_const_181, v__0)); if linked_1644 == nil { tmp5 = ifn_1645.Invoke_O__O(arg_1646) } else { tmp5 = linked_1644.(*A_arbace_test_do_report_A).Invoke_O_O__O(root_1643, arg_1646) } }
//line :691:1
			return nil }(); var root_1647 any = A_arbace_test_A_const_48.GetRawRoot__O(); var linked_1648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1647, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1649 lang.IFn
		if linked_1648 == nil { ifn_1649 = lang.IFn_Cast(root_1647) } else { ifn_1649 = nil }; if linked_1648 == nil { ifn_1649.Invoke__O() } else { linked_1648.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1647) }
//line :691:1
		if tmp8 != nil { panic(tmp8) }; return tmp5 } else { return nil } }



func A_arbace_test_test_var_fn__196000173_A_New_O(p0 any) *A_arbace_test_test_var_fn__196000173_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_var_fn__196000173_A{}; t.Ctor_O(p0); return t }
//line :695:1
func (t *A_arbace_test_test_var_fn__196000173_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :695:1
func (t *A_arbace_test_test_var_fn__196000173_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_t; t.F_t = nil; tmp2 = t_; tmp1 = lang.IFn_Cast(tmp2).Invoke__O() }; return nil }(); if tmp3 != nil { if true { var e__3 jrt.Throwable_I = tmp3; var root_1672 any = A_arbace_test_A_const_179.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, A_arbace_test_do_report_A_fn_class); var ifn_1674 lang.IFn

	if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; var arg_1675 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_A_const_39, A_arbace_test_A_const_40, A_arbace_test_A_const_59, Lit_26, A_arbace_test_A_const_60, nil, A_arbace_test_A_const_43, e__3)); if linked_1673 == nil { tmp1 = ifn_1674.Invoke_O__O(arg_1675) } else { tmp1 = linked_1673.(*A_arbace_test_do_report_A).Invoke_O_O__O(root_1672, arg_1675) } } }; return tmp1 }



func A_arbace_test_test_vars_A_New() *A_arbace_test_test_vars_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_vars_A{}; t.Ctor(); return t }
//line :701:1
func (t *A_arbace_test_test_vars_A) Ctor() {}
//line :701:1
func (t *A_arbace_test_test_vars_A) Invoke_O_O__O(self, vars__0 any) any { { var seq_196000176__2 any; var root_1687 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1687, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1689 lang.IFn




	if linked_1688 == nil { ifn_1689 = lang.IFn_Cast(root_1687) } else { ifn_1689 = nil }; var arg_1690 any; var root_1682 any = A_arbace_test_A_const_183.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1682, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_1684 lang.IFn; if linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var arg_1685 any; var root_1677 any = A_arbace_test_A_const_184.GetRawRoot__O(); var linked_1678 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1677, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1679 lang.IFn; if linked_1678 == nil { ifn_1679 = lang.IFn_Cast(root_1677) } else { ifn_1679 = nil }; var arg_1680 any = A_arbace_test_A_const_66; var arg_1681 any = A_arbace_test_A_const_185.GetRawRoot__O(); if linked_1678 == nil { arg_1685 = ifn_1679.Invoke_O_O__O(arg_1680, arg_1681) } else { arg_1685 = linked_1678.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1677, arg_1680, arg_1681) }; var arg_1686 any = vars__0; if linked_1683 == nil { arg_1690 = ifn_1684.Invoke_O_O__O(arg_1685, arg_1686) } else { arg_1690 = linked_1683.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_1682, arg_1685, arg_1686) }; if linked_1688 == nil { seq_196000176__2 = ifn_1689.Invoke_O__O(arg_1690) } else { seq_196000176__2 = linked_1688.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1687, arg_1690) }
//line :701:1
	var chunk_196000177__3 any; var count_196000178__4 int64 = 0; var i_196000179__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_196000179__5, count_196000178__4) { var vec__196000180__6 any = lang.Indexed_Cast(chunk_196000177__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_196000179__5)); var ns__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__196000180__6, lang.RT_IntCast_J__I_NoInit(0), nil); var vars__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__196000180__6, lang.RT_IntCast_J__I_NoInit(1), nil); var once_fixture_fn__9 any; var root_1707 any = A_arbace_test_A_const_188.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1707, A_arbace_test_join_fixtures_A_fn_class); var ifn_1709 lang.IFn
			if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var tmp1 *lang.Keyword = A_arbace_test_A_const_175; var arg_1710 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(ns__7)); if linked_1708 == nil { once_fixture_fn__9 = ifn_1709.Invoke_O__O(arg_1710) } else { once_fixture_fn__9 = linked_1708.(*A_arbace_test_join_fixtures_A).Invoke_O_O__O(root_1707, arg_1710) }
//line :706:1
			var each_fixture_fn__10 any; var root_1711 any = A_arbace_test_A_const_188.GetRawRoot__O(); var linked_1712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1711, A_arbace_test_join_fixtures_A_fn_class); var ifn_1713 lang.IFn

			if linked_1712 == nil { ifn_1713 = lang.IFn_Cast(root_1711) } else { ifn_1713 = nil }; var tmp2 *lang.Keyword = A_arbace_test_A_const_174; var arg_1714 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(ns__7)); if linked_1712 == nil { each_fixture_fn__10 = ifn_1713.Invoke_O__O(arg_1714) } else { each_fixture_fn__10 = linked_1712.(*A_arbace_test_join_fixtures_A).Invoke_O_O__O(root_1711, arg_1714) }
			var tmp3 lang.IFn = lang.IFn_Cast(once_fixture_fn__9); var tmp4 any = A_arbace_test_test_vars_fn__196000183_A_New_O_O(vars__8, each_fixture_fn__10); var tmp5 *jrt.Class; var fncls__1745 *jrt.Class = A_arbace_test_test_vars_fn__196000183_A_fn_class
			if fncls__1745 == nil { var fncls__1745d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_test_test_vars_fn__196000183_A_fn_class = fncls__1745d; tmp5 = fncls__1745d } else { tmp5 = fncls__1745 }
//line :709:1
			tmp3.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil))
//line :706:1
			seq_196000176__2, chunk_196000177__3, count_196000178__4, i_196000179__5 = seq_196000176__2, chunk_196000177__3, count_196000178__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_196000179__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_1691 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1693 lang.IFn; if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any = seq_196000176__2; if linked_1692 == nil { temp__1927000414__auto____6 = ifn_1693.Invoke_O__O(arg_1694) } else { temp__1927000414__auto____6 = linked_1692.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1691, arg_1694) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_196000176__7 any = temp__1927000414__auto____6; var tmp6 any; var root_1695 any = A_arbace_test_A_const_186.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1695, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1697 lang.IFn; if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any = seq_196000176__7; if linked_1696 == nil { tmp6 = ifn_1697.Invoke_O__O(arg_1698) } else { tmp6 = linked_1696.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1695, arg_1698) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____8 any; var root_1699 any = A_arbace_test_A_const_187.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1701 lang.IFn; if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any = seq_196000176__7; if linked_1700 == nil { c__1927000678__auto____8 = ifn_1701.Invoke_O__O(arg_1702) } else { c__1927000678__auto____8 = linked_1700.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1699, arg_1702) }; var tmp7 any; var root_1746 any = A_arbace_test_A_const_190.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1748 lang.IFn; if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any = seq_196000176__7; if linked_1747 == nil { tmp7 = ifn_1748.Invoke_O__O(arg_1749) } else { tmp7 = linked_1747.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1746, arg_1749) }; seq_196000176__2, chunk_196000177__3, count_196000178__4, i_196000179__5 = tmp7, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__196000193__8 any; var root_1703 any = A_arbace_test_A_const_21.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any = seq_196000176__7; if linked_1704 == nil { vec__196000193__8 = ifn_1705.Invoke_O__O(arg_1706) } else { vec__196000193__8 = linked_1704.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1703, arg_1706) }; var ns__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__196000193__8, lang.RT_IntCast_J__I_NoInit(0), nil); var vars__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__196000193__8, lang.RT_IntCast_J__I_NoInit(1), nil); var once_fixture_fn__11 any; var root_1750 any = A_arbace_test_A_const_188.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, A_arbace_test_join_fixtures_A_fn_class); var ifn_1752 lang.IFn
				if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var tmp8 *lang.Keyword = A_arbace_test_A_const_175; var arg_1753 any = tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(ns__9)); if linked_1751 == nil { once_fixture_fn__11 = ifn_1752.Invoke_O__O(arg_1753) } else { once_fixture_fn__11 = linked_1751.(*A_arbace_test_join_fixtures_A).Invoke_O_O__O(root_1750, arg_1753) }
//line :706:1
				var each_fixture_fn__12 any; var root_1754 any = A_arbace_test_A_const_188.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, A_arbace_test_join_fixtures_A_fn_class); var ifn_1756 lang.IFn

				if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var tmp9 *lang.Keyword = A_arbace_test_A_const_174; var arg_1757 any = tmp9.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(ns__9)); if linked_1755 == nil { each_fixture_fn__12 = ifn_1756.Invoke_O__O(arg_1757) } else { each_fixture_fn__12 = linked_1755.(*A_arbace_test_join_fixtures_A).Invoke_O_O__O(root_1754, arg_1757) }
				var tmp10 lang.IFn = lang.IFn_Cast(once_fixture_fn__11); var tmp11 any = A_arbace_test_test_vars_fn__196000196_A_New_O_O(vars__10, each_fixture_fn__12); var tmp12 *jrt.Class; var fncls__1788 *jrt.Class = A_arbace_test_test_vars_fn__196000196_A_fn_class
				if fncls__1788 == nil { var fncls__1788d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_test_test_vars_fn__196000196_A_fn_class = fncls__1788d; tmp12 = fncls__1788d } else { tmp12 = fncls__1788 }
//line :709:1
				tmp10.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))
//line :706:1
				var tmp13 any; var root_1789 any = A_arbace_test_A_const_19.GetRawRoot__O(); var linked_1790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1789, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1791 lang.IFn; if linked_1790 == nil { ifn_1791 = lang.IFn_Cast(root_1789) } else { ifn_1791 = nil }; var arg_1792 any = seq_196000176__7; if linked_1790 == nil { tmp13 = ifn_1791.Invoke_O__O(arg_1792) } else { tmp13 = linked_1790.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1789, arg_1792) }; seq_196000176__2, chunk_196000177__3, count_196000178__4, i_196000179__5 = tmp13, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :701:1*/panic("j2g: unreachable") }








func A_arbace_test_test_vars_fn__196000183_A_New_O_O(p0, p1 any) *A_arbace_test_test_vars_fn__196000183_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_vars_fn__196000183_A{}; t.Ctor_O_O(p0, p1); return t }
//line :710:1
func (t *A_arbace_test_test_vars_fn__196000183_A) Ctor_O_O(c__vars, c__each_fixture_fn any) { t.F_vars = c__vars; t.F_each_fixture_fn = c__each_fixture_fn }
//line :710:1
func (t *A_arbace_test_test_vars_fn__196000183_A) Invoke_O__O(self any) any { { var seq_196000184__1 any; var root_1715 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1717 lang.IFn
										if linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any = t.F_vars; if linked_1716 == nil { seq_196000184__1 = ifn_1717.Invoke_O__O(arg_1718) } else { seq_196000184__1 = linked_1716.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1715, arg_1718) }
//line :710:1
	var chunk_196000185__2 any; var count_196000186__3 int64 = 0; var i_196000187__4 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_196000187__4, count_196000186__3) { var v__5 any = lang.Indexed_Cast(chunk_196000185__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_196000187__4)); var tmp1 *lang.Keyword = A_arbace_test_A_const_64
			if jrt.J2g_Truth(tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__5))) {
				var tmp2 lang.IFn = lang.IFn_Cast(t.F_each_fixture_fn); var tmp3 any = A_arbace_test_test_vars_fn__196000183_fn__196000188_A_New_O(v__5); var tmp4 *jrt.Class; var fncls__1735 *jrt.Class = A_arbace_test_test_vars_fn__196000183_fn__196000188_A_fn_class; if fncls__1735 == nil { var fncls__1735d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_test_test_vars_fn__196000183_fn__196000188_A_fn_class = fncls__1735d; tmp4 = fncls__1735d } else { tmp4 = fncls__1735 }; tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :711:1
			seq_196000184__1, chunk_196000185__2, count_196000186__3, i_196000187__4 = seq_196000184__1, chunk_196000185__2, count_196000186__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_196000187__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_1719 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1719, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1721 lang.IFn; if linked_1720 == nil { ifn_1721 = lang.IFn_Cast(root_1719) } else { ifn_1721 = nil }; var arg_1722 any = seq_196000184__1; if linked_1720 == nil { temp__1927000414__auto____5 = ifn_1721.Invoke_O__O(arg_1722) } else { temp__1927000414__auto____5 = linked_1720.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1719, arg_1722) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_196000184__6 any = temp__1927000414__auto____5; var tmp5 any; var root_1723 any = A_arbace_test_A_const_186.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1723, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1725 lang.IFn; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any = seq_196000184__6; if linked_1724 == nil { tmp5 = ifn_1725.Invoke_O__O(arg_1726) } else { tmp5 = linked_1724.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1723, arg_1726) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____7 any; var root_1727 any = A_arbace_test_A_const_187.GetRawRoot__O(); var linked_1728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1727, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1729 lang.IFn; if linked_1728 == nil { ifn_1729 = lang.IFn_Cast(root_1727) } else { ifn_1729 = nil }; var arg_1730 any = seq_196000184__6; if linked_1728 == nil { c__1927000678__auto____7 = ifn_1729.Invoke_O__O(arg_1730) } else { c__1927000678__auto____7 = linked_1728.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1727, arg_1730) }; var tmp6 any; var root_1736 any = A_arbace_test_A_const_190.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1738 lang.IFn; if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any = seq_196000184__6; if linked_1737 == nil { tmp6 = ifn_1738.Invoke_O__O(arg_1739) } else { tmp6 = linked_1737.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1736, arg_1739) }; seq_196000184__1, chunk_196000185__2, count_196000186__3, i_196000187__4 = tmp6, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var v__7 any; var root_1731 any = A_arbace_test_A_const_21.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1731, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1733 lang.IFn; if linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any = seq_196000184__6; if linked_1732 == nil { v__7 = ifn_1733.Invoke_O__O(arg_1734) } else { v__7 = linked_1732.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1731, arg_1734) }
				var tmp7 *lang.Keyword = A_arbace_test_A_const_64; if jrt.J2g_Truth(tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__7))) {
					var tmp8 lang.IFn = lang.IFn_Cast(t.F_each_fixture_fn); var tmp9 any = A_arbace_test_test_vars_fn__196000183_fn__196000190_A_New_O(v__7); var tmp10 *jrt.Class; var fncls__1740 *jrt.Class = A_arbace_test_test_vars_fn__196000183_fn__196000190_A_fn_class; if fncls__1740 == nil { var fncls__1740d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_test_test_vars_fn__196000183_fn__196000190_A_fn_class = fncls__1740d; tmp10 = fncls__1740d } else { tmp10 = fncls__1740 }; tmp8.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)) }
//line :711:1
				var tmp11 any; var root_1741 any = A_arbace_test_A_const_19.GetRawRoot__O(); var linked_1742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1741, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1743 lang.IFn; if linked_1742 == nil { ifn_1743 = lang.IFn_Cast(root_1741) } else { ifn_1743 = nil }; var arg_1744 any = seq_196000184__6; if linked_1742 == nil { tmp11 = ifn_1743.Invoke_O__O(arg_1744) } else { tmp11 = linked_1742.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1741, arg_1744) }; seq_196000184__1, chunk_196000185__2, count_196000186__3, i_196000187__4 = tmp11, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :710:1*/panic("j2g: unreachable") }
//line :710:1
func A_arbace_test_test_vars_fn__196000196_A_New_O_O(p0, p1 any) *A_arbace_test_test_vars_fn__196000196_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_vars_fn__196000196_A{}; t.Ctor_O_O(p0, p1); return t }
//line :710:1
func (t *A_arbace_test_test_vars_fn__196000196_A) Ctor_O_O(c__vars, c__each_fixture_fn any) { t.F_vars = c__vars; t.F_each_fixture_fn = c__each_fixture_fn }
//line :710:1
func (t *A_arbace_test_test_vars_fn__196000196_A) Invoke_O__O(self any) any { { var seq_196000197__1 any; var root_1758 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1760 lang.IFn
										if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = t.F_vars; if linked_1759 == nil { seq_196000197__1 = ifn_1760.Invoke_O__O(arg_1761) } else { seq_196000197__1 = linked_1759.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1758, arg_1761) }
//line :710:1
	var chunk_196000198__2 any; var count_196000199__3 int64 = 0; var i_196000200__4 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_196000200__4, count_196000199__3) { var v__5 any = lang.Indexed_Cast(chunk_196000198__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_196000200__4)); var tmp1 *lang.Keyword = A_arbace_test_A_const_64
			if jrt.J2g_Truth(tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__5))) {
				var tmp2 lang.IFn = lang.IFn_Cast(t.F_each_fixture_fn); var tmp3 any = A_arbace_test_test_vars_fn__196000196_fn__196000201_A_New_O(v__5); var tmp4 *jrt.Class; var fncls__1778 *jrt.Class = A_arbace_test_test_vars_fn__196000196_fn__196000201_A_fn_class; if fncls__1778 == nil { var fncls__1778d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_test_test_vars_fn__196000196_fn__196000201_A_fn_class = fncls__1778d; tmp4 = fncls__1778d } else { tmp4 = fncls__1778 }; tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :711:1
			seq_196000197__1, chunk_196000198__2, count_196000199__3, i_196000200__4 = seq_196000197__1, chunk_196000198__2, count_196000199__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_196000200__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_1762 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1764 lang.IFn; if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any = seq_196000197__1; if linked_1763 == nil { temp__1927000414__auto____5 = ifn_1764.Invoke_O__O(arg_1765) } else { temp__1927000414__auto____5 = linked_1763.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1762, arg_1765) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_196000197__6 any = temp__1927000414__auto____5; var tmp5 any; var root_1766 any = A_arbace_test_A_const_186.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1768 lang.IFn; if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = seq_196000197__6; if linked_1767 == nil { tmp5 = ifn_1768.Invoke_O__O(arg_1769) } else { tmp5 = linked_1767.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1766, arg_1769) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____7 any; var root_1770 any = A_arbace_test_A_const_187.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1770, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1772 lang.IFn; if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var arg_1773 any = seq_196000197__6; if linked_1771 == nil { c__1927000678__auto____7 = ifn_1772.Invoke_O__O(arg_1773) } else { c__1927000678__auto____7 = linked_1771.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1770, arg_1773) }; var tmp6 any; var root_1779 any = A_arbace_test_A_const_190.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1781 lang.IFn; if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = seq_196000197__6; if linked_1780 == nil { tmp6 = ifn_1781.Invoke_O__O(arg_1782) } else { tmp6 = linked_1780.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1779, arg_1782) }; seq_196000197__1, chunk_196000198__2, count_196000199__3, i_196000200__4 = tmp6, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var v__7 any; var root_1774 any = A_arbace_test_A_const_21.GetRawRoot__O(); var linked_1775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1774, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1776 lang.IFn; if linked_1775 == nil { ifn_1776 = lang.IFn_Cast(root_1774) } else { ifn_1776 = nil }; var arg_1777 any = seq_196000197__6; if linked_1775 == nil { v__7 = ifn_1776.Invoke_O__O(arg_1777) } else { v__7 = linked_1775.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1774, arg_1777) }
				var tmp7 *lang.Keyword = A_arbace_test_A_const_64; if jrt.J2g_Truth(tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__7))) {
					var tmp8 lang.IFn = lang.IFn_Cast(t.F_each_fixture_fn); var tmp9 any = A_arbace_test_test_vars_fn__196000196_fn__196000203_A_New_O(v__7); var tmp10 *jrt.Class; var fncls__1783 *jrt.Class = A_arbace_test_test_vars_fn__196000196_fn__196000203_A_fn_class; if fncls__1783 == nil { var fncls__1783d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_test_test_vars_fn__196000196_fn__196000203_A_fn_class = fncls__1783d; tmp10 = fncls__1783d } else { tmp10 = fncls__1783 }; tmp8.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)) }
//line :711:1
				var tmp11 any; var root_1784 any = A_arbace_test_A_const_19.GetRawRoot__O(); var linked_1785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1784, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1786 lang.IFn; if linked_1785 == nil { ifn_1786 = lang.IFn_Cast(root_1784) } else { ifn_1786 = nil }; var arg_1787 any = seq_196000197__6; if linked_1785 == nil { tmp11 = ifn_1786.Invoke_O__O(arg_1787) } else { tmp11 = linked_1785.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1784, arg_1787) }; seq_196000197__1, chunk_196000198__2, count_196000199__3, i_196000200__4 = tmp11, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :710:1*/panic("j2g: unreachable") }


func A_arbace_test_test_vars_fn__196000183_fn__196000188_A_New_O(p0 any) *A_arbace_test_test_vars_fn__196000183_fn__196000188_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_vars_fn__196000183_fn__196000188_A{}; t.Ctor_O(p0); return t }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000183_fn__196000188_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000183_fn__196000188_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_test_A_const_189.Get__O()).Invoke_O__O(t.F_v) }
//line :713:1
func A_arbace_test_test_vars_fn__196000183_fn__196000190_A_New_O(p0 any) *A_arbace_test_test_vars_fn__196000183_fn__196000190_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_vars_fn__196000183_fn__196000190_A{}; t.Ctor_O(p0); return t }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000183_fn__196000190_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000183_fn__196000190_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_test_A_const_189.Get__O()).Invoke_O__O(t.F_v) }
//line :713:1
func A_arbace_test_test_vars_fn__196000196_fn__196000201_A_New_O(p0 any) *A_arbace_test_test_vars_fn__196000196_fn__196000201_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_vars_fn__196000196_fn__196000201_A{}; t.Ctor_O(p0); return t }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000196_fn__196000201_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000196_fn__196000201_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_test_A_const_189.Get__O()).Invoke_O__O(t.F_v) }
//line :713:1
func A_arbace_test_test_vars_fn__196000196_fn__196000203_A_New_O(p0 any) *A_arbace_test_test_vars_fn__196000196_fn__196000203_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_vars_fn__196000196_fn__196000203_A{}; t.Ctor_O(p0); return t }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000196_fn__196000203_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000196_fn__196000203_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_test_A_const_189.Get__O()).Invoke_O__O(t.F_v) }

func A_arbace_test_test_all_vars_A_New() *A_arbace_test_test_all_vars_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_all_vars_A{}; t.Ctor(); return t }
//line :715:1
func (t *A_arbace_test_test_all_vars_A) Ctor() {}
//line :715:1
func (t *A_arbace_test_test_all_vars_A) Invoke_O_O__O(self, ns__0 any) any {



	var root_1801 any = A_arbace_test_A_const_191.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, A_arbace_test_test_vars_A_fn_class); var ifn_1803 lang.IFn; if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any; var root_1797 any = A_arbace_test_A_const_192.GetRawRoot__O(); var linked_1798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1797, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1799 lang.IFn; if linked_1798 == nil { ifn_1799 = lang.IFn_Cast(root_1797) } else { ifn_1799 = nil }; var arg_1800 any; var root_1793 any = A_arbace_test_A_const_193.GetRawRoot__O(); var linked_1794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1793, aot_arbace_core.A_arbace_core_ns_interns_A_fn_class); var ifn_1795 lang.IFn; if linked_1794 == nil { ifn_1795 = lang.IFn_Cast(root_1793) } else { ifn_1795 = nil }; var arg_1796 any = ns__0; if linked_1794 == nil { arg_1800 = ifn_1795.Invoke_O__O(arg_1796) } else { arg_1800 = linked_1794.(*aot_arbace_core.A_arbace_core_ns_interns_A).Invoke_O_O__O(root_1793, arg_1796) }; if linked_1798 == nil { arg_1804 = ifn_1799.Invoke_O__O(arg_1800) } else { arg_1804 = linked_1798.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1797, arg_1800) }; if linked_1802 == nil { return ifn_1803.Invoke_O__O(arg_1804) } else { return linked_1802.(*A_arbace_test_test_vars_A).Invoke_O_O__O(root_1801, arg_1804)
	} }
func A_arbace_test_test_ns_A_New() *A_arbace_test_test_ns_A { A_arbace_test_A_Init(); t := &A_arbace_test_test_ns_A{}; t.Ctor(); return t }
//line :721:1
func (t *A_arbace_test_test_ns_A) Ctor() {}
//line :721:1
func (t *A_arbace_test_test_ns_A) Invoke_O_O__O(self, ns__0 any) any {









	var root_1821 any = A_arbace_test_A_const_49.GetRawRoot__O(); var linked_1822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1821, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1823 lang.IFn; if linked_1822 == nil { ifn_1823 = lang.IFn_Cast(root_1821) } else { ifn_1823 = nil }; var arg_1824 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_31; var tmp3 any; var root_1812 any = A_arbace_test_A_const_194.GetRawRoot__O(); var linked_1813 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1812, aot_arbace_core.A_arbace_core_ref_A_fn_class); var ifn_1814 lang.IFn; if linked_1813 == nil { ifn_1814 = lang.IFn_Cast(root_1812) } else { ifn_1814 = nil }; var arg_1815 any = A_arbace_test_A_const_195.Get__O(); if linked_1813 == nil { tmp3 = ifn_1814.Invoke_O__O(arg_1815) } else { tmp3 = linked_1813.(*aot_arbace_core.A_arbace_core_ref_A).Invoke_O_O__O(root_1812, arg_1815) }; arg_1824 = tmp1.Invoke_O_O__O(tmp2, tmp3); if linked_1822 == nil { ifn_1823.Invoke_O__O(arg_1824) } else { linked_1822.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1821, arg_1824) }
//line :721:1
	var tmp4 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var ns_obj__4 any; var root_1825 any = A_arbace_test_A_const_196.GetRawRoot__O(); var linked_1826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1825, aot_arbace_core.A_arbace_core_the_ns_A_fn_class); var ifn_1827 lang.IFn










		if linked_1826 == nil { ifn_1827 = lang.IFn_Cast(root_1825) } else { ifn_1827 = nil }; var arg_1828 any = ns__0; if linked_1826 == nil { ns_obj__4 = ifn_1827.Invoke_O__O(arg_1828) } else { ns_obj__4 = linked_1826.(*aot_arbace_core.A_arbace_core_the_ns_A).Invoke_O_O__O(root_1825, arg_1828) }
		var root_1833 any = A_arbace_test_A_const_179.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, A_arbace_test_do_report_A_fn_class); var ifn_1835 lang.IFn; if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_A_const_39, A_arbace_test_A_const_198, A_arbace_test_A_const_66, ns_obj__4)); if linked_1834 == nil { ifn_1835.Invoke_O__O(arg_1836) } else { linked_1834.(*A_arbace_test_do_report_A).Invoke_O_O__O(root_1833, arg_1836) }
//line :721:1
		var temp__1927000408__auto____5 any; var root_1850 any = A_arbace_test_A_const_199.GetRawRoot__O(); var linked_1851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1850, aot_arbace_core.A_arbace_core_find_var_A_fn_class); var ifn_1852 lang.IFn













		if linked_1851 == nil { ifn_1852 = lang.IFn_Cast(root_1850) } else { ifn_1852 = nil }; var arg_1853 any; var root_1845 any = A_arbace_test_A_const_200.GetRawRoot__O(); var linked_1846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1845, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1847 lang.IFn; if linked_1846 == nil { ifn_1847 = lang.IFn_Cast(root_1845) } else { ifn_1847 = nil }; var arg_1848 any; var root_1841 any = A_arbace_test_A_const_28.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any; var root_1837 any = A_arbace_test_A_const_65.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1839 lang.IFn; if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = ns_obj__4; if linked_1838 == nil { arg_1844 = ifn_1839.Invoke_O__O(arg_1840) } else { arg_1844 = linked_1838.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1837, arg_1840) }; if linked_1842 == nil { arg_1848 = ifn_1843.Invoke_O__O(arg_1844) } else { arg_1848 = linked_1842.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1841, arg_1844) }; var arg_1849 any = Lit_24; if linked_1846 == nil { arg_1853 = ifn_1847.Invoke_O_O__O(arg_1848, arg_1849) } else { arg_1853 = linked_1846.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_1845, arg_1848, arg_1849) }; if linked_1851 == nil { temp__1927000408__auto____5 = ifn_1852.Invoke_O__O(arg_1853) } else { temp__1927000408__auto____5 = linked_1851.(*aot_arbace_core.A_arbace_core_find_var_A).Invoke_O_O__O(root_1850, arg_1853) }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var v__6 any = temp__1927000408__auto____5; var tmp5 any; var root_1854 any = A_arbace_test_A_const_67.GetRawRoot__O(); var linked_1855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1854, aot_arbace_core.A_arbace_core_var_get_A_fn_class); var ifn_1856 lang.IFn
			if linked_1855 == nil { ifn_1856 = lang.IFn_Cast(root_1854) } else { ifn_1856 = nil }; var arg_1857 any = v__6; if linked_1855 == nil { tmp5 = ifn_1856.Invoke_O__O(arg_1857) } else { tmp5 = linked_1855.(*aot_arbace_core.A_arbace_core_var_get_A).Invoke_O_O__O(root_1854, arg_1857) }; lang.IFn_Cast(tmp5).Invoke__O() } else {

				var root_1858 any = A_arbace_test_A_const_201.GetRawRoot__O(); var linked_1859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1858, A_arbace_test_test_all_vars_A_fn_class); var ifn_1860 lang.IFn; if linked_1859 == nil { ifn_1860 = lang.IFn_Cast(root_1858) } else { ifn_1860 = nil }; var arg_1861 any = ns_obj__4; if linked_1859 == nil { ifn_1860.Invoke_O__O(arg_1861) } else { linked_1859.(*A_arbace_test_test_all_vars_A).Invoke_O_O__O(root_1858, arg_1861) } }
		var root_1829 any = A_arbace_test_A_const_179.GetRawRoot__O(); var linked_1830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1829, A_arbace_test_do_report_A_fn_class); var ifn_1831 lang.IFn; if linked_1830 == nil { ifn_1831 = lang.IFn_Cast(root_1829) } else { ifn_1831 = nil }; var arg_1832 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_A_const_39, A_arbace_test_A_const_197, A_arbace_test_A_const_66, ns_obj__4)); if linked_1830 == nil { ifn_1831.Invoke_O__O(arg_1832) } else { linked_1830.(*A_arbace_test_do_report_A).Invoke_O_O__O(root_1829, arg_1832) }
//line :731:1
		var root_1805 any = A_arbace_test_A_const_7.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any = A_arbace_test_A_const_31.Get__O(); if linked_1806 == nil { tmp4 = ifn_1807.Invoke_O__O(arg_1808) } else { tmp4 = linked_1806.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1805, arg_1808) } }; return nil }()
//line :721:1
	var root_1809 any = A_arbace_test_A_const_48.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1811 lang.IFn









	if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; if linked_1810 == nil { ifn_1811.Invoke__O() } else { linked_1810.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1809) }
//line :721:1
	if tmp6 != nil { panic(tmp6) }; return tmp4
}





















func A_arbace_test_run_tests_A_New() *A_arbace_test_run_tests_A { A_arbace_test_A_Init(); t := &A_arbace_test_run_tests_A{}; t.Ctor(); return t }
//line :744:1
func (t *A_arbace_test_run_tests_A) Ctor() {}
//line :744:1
func (t *A_arbace_test_run_tests_A) DoInvoke_O_O__O(self, namespaces__0 any) any { var summary__2 any; var root_1873 any = A_arbace_test_A_const_156.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1873, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1875 lang.IFn; if






	linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any; var root_1867 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1867, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1869 lang.IFn; if linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; var arg_1870 any = A_arbace_test_A_const_202.GetRawRoot__O(); var arg_1871 any = A_arbace_test_A_const_203.GetRawRoot__O(); var arg_1872 any; var root_1862 any = A_arbace_test_A_const_25.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1862, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1864 lang.IFn; if linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; var arg_1865 any = A_arbace_test_A_const_204.GetRawRoot__O(); var arg_1866 any = namespaces__0; if linked_1863 == nil { arg_1872 = ifn_1864.Invoke_O_O__O(arg_1865, arg_1866) } else { arg_1872 = linked_1863.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1862, arg_1865, arg_1866) }; if linked_1868 == nil { arg_1876 = ifn_1869.Invoke_O_O_O__O(arg_1870, arg_1871, arg_1872) } else { arg_1876 = linked_1868.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1867, arg_1870, arg_1871, arg_1872) }; var arg_1877 any = A_arbace_test_A_const_39; var arg_1878 any = A_arbace_test_A_const_205; if linked_1874 == nil { summary__2 = ifn_1875.Invoke_O_O_O__O(arg_1876, arg_1877, arg_1878) } else { summary__2 = linked_1874.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1873, arg_1876, arg_1877, arg_1878) }; var root_1879 any =

	A_arbace_test_A_const_179.GetRawRoot__O(); var linked_1880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1879, A_arbace_test_do_report_A_fn_class); var ifn_1881 lang.IFn; if linked_1880 == nil { ifn_1881 = lang.IFn_Cast(root_1879) } else { ifn_1881 = nil }; var arg_1882 any = summary__2; if linked_1880 == nil { ifn_1881.Invoke_O__O(arg_1882) } else { linked_1880.(*A_arbace_test_do_report_A).Invoke_O_O__O(root_1879, arg_1882) }; return summary__2 }
//line :744:1
func (t *A_arbace_test_run_tests_A) Invoke_O__O(self any) any {




	return lang.IFn_Cast(A_arbace_test_A_const_206.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_172.Get__O())
}





func A_arbace_test_run_all_tests_A_New() *A_arbace_test_run_all_tests_A { A_arbace_test_A_Init(); t := &A_arbace_test_run_all_tests_A{}; t.Ctor(); return t }
//line :756:1
func (t *A_arbace_test_run_all_tests_A) Ctor() {}
//line :756:1
func (t *A_arbace_test_run_all_tests_A) Invoke_O_O__O(self, re__0 any) any {






	var root_1909 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_1910 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1909, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1911 lang.IFn; if linked_1910 == nil { ifn_1911 = lang.IFn_Cast(root_1909) } else { ifn_1911 = nil }; var arg_1912 any = A_arbace_test_A_const_206.GetRawRoot__O(); var arg_1913 any; var root_1904 any = A_arbace_test_A_const_207.GetRawRoot__O(); var linked_1905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1904, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1906 lang.IFn; if linked_1905 == nil { ifn_1906 = lang.IFn_Cast(root_1904) } else { ifn_1906 = nil }; var arg_1907 any; var tmp1 any = A_arbace_test_run_all_tests_fn__196000211_A_New_O(re__0); var tmp2 *jrt.Class; var fncls__1900 *jrt.Class = A_arbace_test_run_all_tests_fn__196000211_A_fn_class; if fncls__1900 == nil { var fncls__1900d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_test_run_all_tests_fn__196000211_A_fn_class = fncls__1900d; tmp2 = fncls__1900d } else { tmp2 = fncls__1900 }; arg_1907 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1908 any; var root_1901 any = A_arbace_test_A_const_210.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, aot_arbace_core.A_arbace_core_all_ns_A_fn_class); var ifn_1903 lang.IFn; if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; if linked_1902 == nil { arg_1908 = ifn_1903.Invoke__O() } else { arg_1908 = linked_1902.(*aot_arbace_core.A_arbace_core_all_ns_A).Invoke_O__O(root_1901) }; if linked_1905 == nil { arg_1913 = ifn_1906.Invoke_O_O__O(arg_1907, arg_1908) } else { arg_1913 = linked_1905.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1904, arg_1907, arg_1908) }; if linked_1910 == nil { return ifn_1911.Invoke_O_O__O(arg_1912, arg_1913) } else { return linked_1910.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1909, arg_1912, arg_1913) } }
//line :756:1
func (t *A_arbace_test_run_all_tests_A) Invoke_O__O(self any) any {





	var root_1917 any = A_arbace_test_A_const_15.GetRawRoot__O(); var linked_1918 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1917, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1919 lang.IFn; if linked_1918 == nil { ifn_1919 = lang.IFn_Cast(root_1917) } else { ifn_1919 = nil }; var arg_1920 any = A_arbace_test_A_const_206.GetRawRoot__O(); var arg_1921 any; var root_1914 any = A_arbace_test_A_const_210.GetRawRoot__O(); var linked_1915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1914, aot_arbace_core.A_arbace_core_all_ns_A_fn_class); var ifn_1916 lang.IFn; if linked_1915 == nil { ifn_1916 = lang.IFn_Cast(root_1914) } else { ifn_1916 = nil }; if linked_1915 == nil { arg_1921 = ifn_1916.Invoke__O() } else { arg_1921 = linked_1915.(*aot_arbace_core.A_arbace_core_all_ns_A).Invoke_O__O(root_1914) }; if linked_1918 == nil { return ifn_1919.Invoke_O_O__O(arg_1920, arg_1921) } else { return linked_1918.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1917, arg_1920, arg_1921) } }
func A_arbace_test_run_all_tests_fn__196000211_A_New_O(p0 any) *A_arbace_test_run_all_tests_fn__196000211_A { A_arbace_test_A_Init(); t := &A_arbace_test_run_all_tests_fn__196000211_A{}; t.Ctor_O(p0); return t }
//line :763:1
func (t *A_arbace_test_run_all_tests_fn__196000211_A) Ctor_O(c__re any) { t.F_re = c__re }
//line :763:1
func (t *A_arbace_test_run_all_tests_fn__196000211_A) Invoke_O_O__O(self, p1__196000210_SHARP___1 any) any { var root_1895 any = A_arbace_test_A_const_208.GetRawRoot__O(); var linked_1896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1895, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_1897 lang.IFn; if linked_1896 == nil { ifn_1897 = lang.IFn_Cast(root_1895) } else { ifn_1897 = nil }; var arg_1898 any = t.F_re; var arg_1899 any; var root_1891 any = A_arbace_test_A_const_209.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1893 lang.IFn; if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any; var root_1887 any = A_arbace_test_A_const_65.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_1889 lang.IFn; if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any = p1__196000210_SHARP___1; if linked_1888 == nil { arg_1894 = ifn_1889.Invoke_O__O(arg_1890) } else { arg_1894 = linked_1888.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_1887, arg_1890) }; if linked_1892 == nil { arg_1899 = ifn_1893.Invoke_O__O(arg_1894) } else { arg_1899 = linked_1892.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1891, arg_1894) }; if linked_1896 == nil { return ifn_1897.Invoke_O_O__O(arg_1898, arg_1899) } else { return linked_1896.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_1895, arg_1898, arg_1899) } }

func A_arbace_test_successful_QMARK__A_New() *A_arbace_test_successful_QMARK__A { A_arbace_test_A_Init(); t := &A_arbace_test_successful_QMARK__A{}; t.Ctor(); return t }
//line :765:1
func (t *A_arbace_test_successful_QMARK__A) Ctor() {}
//line :765:1
func (t *A_arbace_test_successful_QMARK__A) Invoke_O_O__O(self, summary__0 any) any { var and__1927000168__auto____2 bool; var na_1922 any = A_arbace_test_A_const_44.Invoke_O_O__O(summary__0, A_arbace_test_A_const_35); if




	jrt.Long_InstanceOf(na_1922) { var n0_1923 int64 = jrt.NN(jrt.Long_Cast(na_1922)).LongValue__J(); and__1927000168__auto____2 = n0_1923 == 0 } else { if jrt.Double_InstanceOf(na_1922) { var n0_1923_2 float64 = jrt.NN(jrt.Double_Cast(na_1922)).DoubleValue__D(); and__1927000168__auto____2 = n0_1923_2 == 0.0 } else { and__1927000168__auto____2 = lang.Numbers_IsZero_O__Z_NoInit(na_1922) } }; if and__1927000168__auto____2 {
		var tmp1 bool; var na_1924 any = A_arbace_test_A_const_40.Invoke_O_O__O(summary__0, A_arbace_test_A_const_35); if jrt.Long_InstanceOf(na_1924) { var n0_1925 int64 = jrt.NN(jrt.Long_Cast(na_1924)).LongValue__J(); tmp1 = n0_1925 == 0 } else { if jrt.Double_InstanceOf(na_1924) { var n0_1925_2 float64 = jrt.NN(jrt.Double_Cast(na_1924)).DoubleValue__D(); tmp1 = n0_1925_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_1924) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() } else {
//line :770:1
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }


func A_arbace_test_run_test_var_A_New() *A_arbace_test_run_test_var_A { A_arbace_test_A_Init(); t := &A_arbace_test_run_test_var_A{}; t.Ctor(); return t }
//line :773:1
func (t *A_arbace_test_run_test_var_A) Ctor() {}
//line :773:1
func (t *A_arbace_test_run_test_var_A) Invoke_O_O__O(self, v__0 any) any {



	var root_1948 any = A_arbace_test_A_const_49.GetRawRoot__O(); var linked_1949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1948, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1950 lang.IFn; if linked_1949 == nil { ifn_1950 = lang.IFn_Cast(root_1948) } else { ifn_1950 = nil }; var arg_1951 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_31; var tmp3 any; var root_1939 any = A_arbace_test_A_const_194.GetRawRoot__O(); var linked_1940 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1939, aot_arbace_core.A_arbace_core_ref_A_fn_class); var ifn_1941 lang.IFn; if linked_1940 == nil { ifn_1941 = lang.IFn_Cast(root_1939) } else { ifn_1941 = nil }; var arg_1942 any = A_arbace_test_A_const_195.Get__O(); if linked_1940 == nil { tmp3 = ifn_1941.Invoke_O__O(arg_1942) } else { tmp3 = linked_1940.(*aot_arbace_core.A_arbace_core_ref_A).Invoke_O_O__O(root_1939, arg_1942) }; arg_1951 = tmp1.Invoke_O_O__O(tmp2, tmp3); if linked_1949 == nil { ifn_1950.Invoke_O__O(arg_1951) } else { linked_1949.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1948, arg_1951) }
//line :773:1
	var tmp4 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp5 *lang.Keyword = A_arbace_test_A_const_66; var ns_obj__4 any = tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__0)); var summary__5 any; var root_1952 any = A_arbace_test_A_const_179.GetRawRoot__O(); var linked_1953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1952, A_arbace_test_do_report_A_fn_class); var ifn_1954 lang.IFn






		if linked_1953 == nil { ifn_1954 = lang.IFn_Cast(root_1952) } else { ifn_1954 = nil }; var arg_1955 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_A_const_39, A_arbace_test_A_const_198, A_arbace_test_A_const_66, ns_obj__4)); if linked_1953 == nil { ifn_1954.Invoke_O__O(arg_1955) } else { linked_1953.(*A_arbace_test_do_report_A).Invoke_O_O__O(root_1952, arg_1955)
		}
		var root_1956 any = A_arbace_test_A_const_191.GetRawRoot__O(); var linked_1957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1956, A_arbace_test_test_vars_A_fn_class); var ifn_1958 lang.IFn; if linked_1957 == nil { ifn_1958 = lang.IFn_Cast(root_1956) } else { ifn_1958 = nil }; var arg_1959 any = lang.Tuple_Create_O__IPersistentVector(v__0); if linked_1957 == nil { ifn_1958.Invoke_O__O(arg_1959) } else { linked_1957.(*A_arbace_test_test_vars_A).Invoke_O_O__O(root_1956, arg_1959) }
		var root_1960 any = A_arbace_test_A_const_179.GetRawRoot__O(); var linked_1961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1960, A_arbace_test_do_report_A_fn_class); var ifn_1962 lang.IFn; if linked_1961 == nil { ifn_1962 = lang.IFn_Cast(root_1960) } else { ifn_1962 = nil }; var arg_1963 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_A_const_39, A_arbace_test_A_const_197, A_arbace_test_A_const_66, ns_obj__4)); if linked_1961 == nil { ifn_1962.Invoke_O__O(arg_1963) } else { linked_1961.(*A_arbace_test_do_report_A).Invoke_O_O__O(root_1960, arg_1963)
		}
		var root_1930 any = A_arbace_test_A_const_156.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1930, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1932 lang.IFn; if linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any; var root_1926 any = A_arbace_test_A_const_7.GetRawRoot__O(); var linked_1927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1926, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1928 lang.IFn; if linked_1927 == nil { ifn_1928 = lang.IFn_Cast(root_1926) } else { ifn_1928 = nil }; var arg_1929 any = A_arbace_test_A_const_31.Get__O(); if linked_1927 == nil { arg_1933 = ifn_1928.Invoke_O__O(arg_1929) } else { arg_1933 = linked_1927.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1926, arg_1929) }; var arg_1934 any = A_arbace_test_A_const_39; var arg_1935 any = A_arbace_test_A_const_205; if linked_1931 == nil { summary__5 = ifn_1932.Invoke_O_O_O__O(arg_1933, arg_1934, arg_1935) } else { summary__5 = linked_1931.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1930, arg_1933, arg_1934, arg_1935) }
		var root_1964 any = A_arbace_test_A_const_179.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1964, A_arbace_test_do_report_A_fn_class); var ifn_1966 lang.IFn; if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any = summary__5; if linked_1965 == nil { ifn_1966.Invoke_O__O(arg_1967) } else { linked_1965.(*A_arbace_test_do_report_A).Invoke_O_O__O(root_1964, arg_1967) }
//line :773:1
		tmp4 = summary__5 }; return nil }(); var root_1936 any = A_arbace_test_A_const_48.GetRawRoot__O(); var linked_1937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1936, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1938 lang.IFn



	if linked_1937 == nil { ifn_1938 = lang.IFn_Cast(root_1936) } else { ifn_1938 = nil }; if linked_1937 == nil { ifn_1938.Invoke__O() } else { linked_1937.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1936) }
//line :773:1
	if tmp6 != nil { panic(tmp6) }; return tmp4
}














func A_arbace_test_run_test_A_New() *A_arbace_test_run_test_A { A_arbace_test_A_Init(); t := &A_arbace_test_run_test_A{}; t.Ctor(); return t }
//line :789:1
func (t *A_arbace_test_run_test_A) Ctor() {}
//line :789:1
func (t *A_arbace_test_run_test_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, test_symbol__2 any) any { var test_var__4 any; var root_1968 any = A_arbace_test_A_const_69.GetRawRoot__O(); var linked_1969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1968, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_1970 lang.IFn; if





	linked_1969 == nil { ifn_1970 = lang.IFn_Cast(root_1968) } else { ifn_1970 = nil }; var arg_1971 any = test_symbol__2; if linked_1969 == nil { test_var__4 = ifn_1970.Invoke_O__O(arg_1971) } else { test_var__4 = linked_1969.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_1968, arg_1971) }; if
	lang.Util_Identical_O_O__Z_NoInit(test_var__4, nil) {

		var root_2007 any = A_arbace_test_A_const_49.GetRawRoot__O(); var linked_2008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2007, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2009 lang.IFn; if linked_2008 == nil { ifn_2009 = lang.IFn_Cast(root_2007) } else { ifn_2009 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp2 any = A_arbace_test_A_const_51; var arg_2010 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_A_const_212.Get__O()); if linked_2008 == nil { ifn_2009.Invoke_O__O(arg_2010) } else { linked_2008.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2007, arg_2010) }
//line :796:1
		var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


			tmp3 = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O_O_O__O(Lit_21, test_symbol__2, Lit_22)
//line :796:1
			return nil }(); var root_1978 any = A_arbace_test_A_const_48.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1980 lang.IFn

		if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; if linked_1979 == nil { ifn_1980.Invoke__O() } else { linked_1979.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1978) }
//line :796:1
		if tmp4 != nil { panic(tmp4) }; return tmp3 } else { var tmp5 any; var root_1981 any = A_arbace_test_A_const_72.GetRawRoot__O(); var linked_1982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1981, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1983 lang.IFn




			if linked_1982 == nil { ifn_1983 = lang.IFn_Cast(root_1981) } else { ifn_1983 = nil }; var tmp6 *lang.Keyword = A_arbace_test_A_const_64; var arg_1984 any = tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(test_var__4)); if linked_1982 == nil { tmp5 = ifn_1983.Invoke_O__O(arg_1984) } else { tmp5 = linked_1982.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1981, arg_1984) }
//line :796:1
			if jrt.J2g_Truth(tmp5) {





				var root_2016 any = A_arbace_test_A_const_49.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2016, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2018 lang.IFn; if linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_test_A_const_50.GetRawRoot__O()); var tmp8 any = A_arbace_test_A_const_51; var arg_2019 any = tmp7.Invoke_O_O__O(tmp8, A_arbace_test_A_const_212.Get__O()); if linked_2017 == nil { ifn_2018.Invoke_O__O(arg_2019) } else { linked_2017.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2016, arg_2019) }
//line :796:1
				var tmp9 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






					tmp9 = lang.IFn_Cast(A_arbace_test_A_const_55.GetRawRoot__O()).Invoke_O_O__O(test_symbol__2, Lit_23)
//line :796:1
					return nil }(); var root_1990 any = A_arbace_test_A_const_48.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1992 lang.IFn





				if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; if linked_1991 == nil { ifn_1992.Invoke__O() } else { linked_1991.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1990) }
//line :796:1
				if tmp10 != nil { panic(tmp10) }; return tmp9 } else { if A_arbace_test_A_const_95 != nil { var root_1998 any = A_arbace_test_A_const_11.GetRawRoot__O(); var linked_1999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1998, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2000 lang.IFn; if linked_1999 == nil { ifn_2000 = lang.IFn_Cast(root_1998) } else { ifn_2000 = nil }; var arg_2001 any; var root_1993 any = A_arbace_test_A_const_12.GetRawRoot__O(); var linked_1994 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1993, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1995 lang.IFn; if linked_1994 == nil { ifn_1995 = lang.IFn_Cast(root_1993) } else { ifn_1995 = nil }; var arg_1996 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_test_A_const_211); var arg_1997 any = lang.IFn_Cast(A_arbace_test_A_const_13.GetRawRoot__O()).Invoke_O__O(test_var__4); if linked_1994 == nil { arg_2001 = ifn_1995.Invoke_O_O__O(arg_1996, arg_1997) } else { arg_2001 = linked_1994.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1993, arg_1996, arg_1997) }; if linked_1999 == nil { return ifn_2000.Invoke_O__O(arg_2001) } else { return linked_1999.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1998, arg_2001) } } else { return nil } } } }















type A_arbace_test_A struct{ jrt.Object }

var A_arbace_test_A_const_pool *jrt.RefArray

var A_arbace_test_A_const_0 *lang.Var

var A_arbace_test_A_const_1 any

var A_arbace_test_A_const_2 any

var A_arbace_test_A_const_3 any

var A_arbace_test_A_const_4 *lang.Var

var A_arbace_test_A_const_5 any

var A_arbace_test_A_const_6 *lang.Var

var A_arbace_test_A_const_7 *lang.Var

var A_arbace_test_A_const_8 *lang.Var

var A_arbace_test_A_const_9 *lang.Var

var A_arbace_test_A_const_10 any

var A_arbace_test_A_const_11 *lang.Var

var A_arbace_test_A_const_12 *lang.Var

var A_arbace_test_A_const_13 *lang.Var

var A_arbace_test_A_const_14 any

var A_arbace_test_A_const_15 *lang.Var

var A_arbace_test_A_const_16 *lang.Var

var A_arbace_test_A_const_17 any

var A_arbace_test_A_const_18 any

var A_arbace_test_A_const_19 *lang.Var

var A_arbace_test_A_const_20 *lang.Var

var A_arbace_test_A_const_21 *lang.Var

var A_arbace_test_A_const_22 *lang.Keyword

var A_arbace_test_A_const_23 *lang.Keyword

var A_arbace_test_A_const_24 *lang.Var

var A_arbace_test_A_const_25 *lang.Var

var A_arbace_test_A_const_26 *lang.Keyword

var A_arbace_test_A_const_27 *lang.Var

var A_arbace_test_A_const_28 *lang.Var

var A_arbace_test_A_const_29 *lang.Var

var A_arbace_test_A_const_30 *lang.Var

var A_arbace_test_A_const_31 *lang.Var

var A_arbace_test_A_const_32 *lang.Var

var A_arbace_test_A_const_33 *lang.Var

var A_arbace_test_A_const_34 *lang.Var

var A_arbace_test_A_const_35 any

var A_arbace_test_A_const_36 any

var A_arbace_test_A_const_37 any

var A_arbace_test_A_const_38 *lang.Var

var A_arbace_test_A_const_39 *lang.Keyword

var A_arbace_test_A_const_40 *lang.Keyword

var A_arbace_test_A_const_41 *lang.Var

var A_arbace_test_A_const_42 *lang.Var

var A_arbace_test_A_const_43 *lang.Keyword

var A_arbace_test_A_const_44 *lang.Keyword

var A_arbace_test_A_const_45 *lang.Var

var A_arbace_test_A_const_46 *lang.Var

var A_arbace_test_A_const_47 *lang.Var

var A_arbace_test_A_const_48 *lang.Var

var A_arbace_test_A_const_49 *lang.Var

var A_arbace_test_A_const_50 *lang.Var

var A_arbace_test_A_const_51 *lang.Var

var A_arbace_test_A_const_52 *lang.Var

var A_arbace_test_A_const_53 *lang.Var

var A_arbace_test_A_const_54 *lang.Keyword

var A_arbace_test_A_const_55 *lang.Var

var A_arbace_test_A_const_56 *lang.Var

var A_arbace_test_A_const_57 *lang.Var

var A_arbace_test_A_const_58 *lang.Var

var A_arbace_test_A_const_59 *lang.Keyword

var A_arbace_test_A_const_60 *lang.Keyword

var A_arbace_test_A_const_61 *lang.Var

var A_arbace_test_A_const_62 *lang.Var

var A_arbace_test_A_const_63 *lang.Var

var A_arbace_test_A_const_64 *lang.Keyword

var A_arbace_test_A_const_65 *lang.Var

var A_arbace_test_A_const_66 *lang.Keyword

var A_arbace_test_A_const_67 *lang.Var

var A_arbace_test_A_const_68 *lang.Var

var A_arbace_test_A_const_69 *lang.Var

var A_arbace_test_A_const_70 *lang.Var

var A_arbace_test_A_const_71 *lang.Var

var A_arbace_test_A_const_72 *lang.Var

var A_arbace_test_A_const_73 *lang.Keyword

var A_arbace_test_A_const_74 *lang.Var

var A_arbace_test_A_const_75 any

var A_arbace_test_A_const_76 any

var A_arbace_test_A_const_77 any

var A_arbace_test_A_const_78 any

var A_arbace_test_A_const_79 any

var A_arbace_test_A_const_80 any

var A_arbace_test_A_const_81 any

var A_arbace_test_A_const_82 any

var A_arbace_test_A_const_83 any

var A_arbace_test_A_const_84 any

var A_arbace_test_A_const_85 any

var A_arbace_test_A_const_86 any

var A_arbace_test_A_const_87 any

var A_arbace_test_A_const_88 any

var A_arbace_test_A_const_89 any

var A_arbace_test_A_const_90 any

var A_arbace_test_A_const_91 any

var A_arbace_test_A_const_92 any

var A_arbace_test_A_const_93 *lang.Keyword

var A_arbace_test_A_const_94 *lang.Var

var A_arbace_test_A_const_95 *lang.Keyword

var A_arbace_test_A_const_96 *lang.Keyword

var A_arbace_test_A_const_97 any

var A_arbace_test_A_const_98 *lang.Var

var A_arbace_test_A_const_99 *lang.Var

var A_arbace_test_A_const_100 *lang.Var

var A_arbace_test_A_const_101 *lang.Var

var A_arbace_test_A_const_102 any

var A_arbace_test_A_const_103 any

var A_arbace_test_A_const_104 any

var A_arbace_test_A_const_105 any

var A_arbace_test_A_const_106 any

var A_arbace_test_A_const_107 any

var A_arbace_test_A_const_108 any

var A_arbace_test_A_const_109 any

var A_arbace_test_A_const_110 any

var A_arbace_test_A_const_111 any

var A_arbace_test_A_const_112 any

var A_arbace_test_A_const_113 *lang.Var

var A_arbace_test_A_const_114 *lang.Var

var A_arbace_test_A_const_115 any

var A_arbace_test_A_const_116 any

var A_arbace_test_A_const_117 any

var A_arbace_test_A_const_118 any

var A_arbace_test_A_const_119 any

var A_arbace_test_A_const_120 any

var A_arbace_test_A_const_121 any

var A_arbace_test_A_const_122 any

var A_arbace_test_A_const_123 any

var A_arbace_test_A_const_124 any

var A_arbace_test_A_const_125 any

var A_arbace_test_A_const_126 any

var A_arbace_test_A_const_127 any

var A_arbace_test_A_const_128 any

var A_arbace_test_A_const_129 any

var A_arbace_test_A_const_130 any

var A_arbace_test_A_const_131 any

var A_arbace_test_A_const_132 any

var A_arbace_test_A_const_133 any

var A_arbace_test_A_const_134 *lang.Var

var A_arbace_test_A_const_135 any

var A_arbace_test_A_const_136 any

var A_arbace_test_A_const_137 any

var A_arbace_test_A_const_138 any

var A_arbace_test_A_const_139 any

var A_arbace_test_A_const_140 any

var A_arbace_test_A_const_141 *lang.Var

var A_arbace_test_A_const_142 *lang.Var

var A_arbace_test_A_const_143 any

var A_arbace_test_A_const_144 any

var A_arbace_test_A_const_145 any

var A_arbace_test_A_const_146 any

var A_arbace_test_A_const_147 any

var A_arbace_test_A_const_148 any

var A_arbace_test_A_const_149 *lang.Var

var A_arbace_test_A_const_150 any

var A_arbace_test_A_const_151 any

var A_arbace_test_A_const_152 any

var A_arbace_test_A_const_153 any

var A_arbace_test_A_const_154 any

var A_arbace_test_A_const_155 *lang.Var

var A_arbace_test_A_const_156 *lang.Var

var A_arbace_test_A_const_157 any

var A_arbace_test_A_const_158 any

var A_arbace_test_A_const_159 any

var A_arbace_test_A_const_160 any

var A_arbace_test_A_const_161 any

var A_arbace_test_A_const_162 any

var A_arbace_test_A_const_163 *lang.Keyword

var A_arbace_test_A_const_164 any

var A_arbace_test_A_const_165 any

var A_arbace_test_A_const_166 any

var A_arbace_test_A_const_167 any

var A_arbace_test_A_const_168 any

var A_arbace_test_A_const_169 any

var A_arbace_test_A_const_170 any

var A_arbace_test_A_const_171 *lang.Var

var A_arbace_test_A_const_172 *lang.Var

var A_arbace_test_A_const_173 *lang.Var

var A_arbace_test_A_const_174 *lang.Keyword

var A_arbace_test_A_const_175 *lang.Keyword

var A_arbace_test_A_const_176 *lang.Var

var A_arbace_test_A_const_177 *lang.Var

var A_arbace_test_A_const_178 *lang.Var

var A_arbace_test_A_const_179 *lang.Var

var A_arbace_test_A_const_180 *lang.Keyword

var A_arbace_test_A_const_181 *lang.Keyword

var A_arbace_test_A_const_182 *lang.Keyword

var A_arbace_test_A_const_183 *lang.Var

var A_arbace_test_A_const_184 *lang.Var

var A_arbace_test_A_const_185 *lang.Var

var A_arbace_test_A_const_186 *lang.Var

var A_arbace_test_A_const_187 *lang.Var

var A_arbace_test_A_const_188 *lang.Var

var A_arbace_test_A_const_189 *lang.Var

var A_arbace_test_A_const_190 *lang.Var

var A_arbace_test_A_const_191 *lang.Var

var A_arbace_test_A_const_192 *lang.Var

var A_arbace_test_A_const_193 *lang.Var

var A_arbace_test_A_const_194 *lang.Var

var A_arbace_test_A_const_195 *lang.Var

var A_arbace_test_A_const_196 *lang.Var

var A_arbace_test_A_const_197 *lang.Keyword

var A_arbace_test_A_const_198 *lang.Keyword

var A_arbace_test_A_const_199 *lang.Var

var A_arbace_test_A_const_200 *lang.Var

var A_arbace_test_A_const_201 *lang.Var

var A_arbace_test_A_const_202 *lang.Var

var A_arbace_test_A_const_203 *lang.Var

var A_arbace_test_A_const_204 *lang.Var

var A_arbace_test_A_const_205 *lang.Keyword

var A_arbace_test_A_const_206 *lang.Var

var A_arbace_test_A_const_207 *lang.Var

var A_arbace_test_A_const_208 *lang.Var

var A_arbace_test_A_const_209 *lang.Var

var A_arbace_test_A_const_210 *lang.Var

var A_arbace_test_A_const_211 any

var A_arbace_test_A_const_212 *lang.Var

var A_arbace_test_A_init jrt.ClassInit

func A_arbace_test_A_Init() { if !A_arbace_test_A_init.Done() { A_arbace_test_A_init.Run(A_arbace_test_A_clinit) } }

func A_arbace_test_A_clinit() { A_arbace_test_A_clinit_p0(); A_arbace_test_A_clinit_p1(); A_arbace_test_A_clinit_p2(); A_arbace_test_A_clinit_p3(); A_arbace_test_A_clinit_p4(); A_arbace_test_A_clinit_p5(); A_arbace_test_A_clinit_p6(); A_arbace_test_A_clinit_p7(); A_arbace_test_A_clinit_p8(); A_arbace_test_A_clinit_p9(); A_arbace_test_A_clinit_p10(); A_arbace_test_A_clinit_p11(); A_arbace_test_A_clinit_p12(); A_arbace_test_A_clinit_p13(); A_arbace_test_A_clinit_p14(); A_arbace_test_A_clinit_p15(); A_arbace_test_A_clinit_p16() }

func A_arbace_test_A_clinit_p0() { jrt.StartCheck(); A_arbace_test_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 289); A_arbace_test_A_const_0 = lang.Var_Cast(A_arbace_test_A_const_pool.A[76]); A_arbace_test_A_const_1 = A_arbace_test_A_const_pool.A[77]; A_arbace_test_A_const_2 = A_arbace_test_A_const_pool.A[78]; A_arbace_test_A_const_3 = A_arbace_test_A_const_pool.A[79]; A_arbace_test_A_const_4 = lang.Var_Cast(A_arbace_test_A_const_pool.A[80]); A_arbace_test_A_const_5 = A_arbace_test_A_const_pool.A[81]; A_arbace_test_A_const_6 = lang.Var_Cast(A_arbace_test_A_const_pool.A[82]); A_arbace_test_A_const_7 = lang.Var_Cast(A_arbace_test_A_const_pool.A[83]); A_arbace_test_A_const_8 = lang.Var_Cast(A_arbace_test_A_const_pool.A[84]); A_arbace_test_A_const_9 = lang.Var_Cast(A_arbace_test_A_const_pool.A[85]); A_arbace_test_A_const_10 = A_arbace_test_A_const_pool.A[86]; A_arbace_test_A_const_11 = lang.Var_Cast(A_arbace_test_A_const_pool.A[87]) }

func A_arbace_test_A_clinit_p1() { A_arbace_test_A_const_12 = lang.Var_Cast(A_arbace_test_A_const_pool.A[88]); A_arbace_test_A_const_13 = lang.Var_Cast(A_arbace_test_A_const_pool.A[89]); A_arbace_test_A_const_14 = A_arbace_test_A_const_pool.A[90]; A_arbace_test_A_const_15 = lang.Var_Cast(A_arbace_test_A_const_pool.A[91]); A_arbace_test_A_const_16 = lang.Var_Cast(A_arbace_test_A_const_pool.A[92]); A_arbace_test_A_const_17 = A_arbace_test_A_const_pool.A[93]; A_arbace_test_A_const_18 = A_arbace_test_A_const_pool.A[94]; A_arbace_test_A_const_19 = lang.Var_Cast(A_arbace_test_A_const_pool.A[95]); A_arbace_test_A_const_20 = lang.Var_Cast(A_arbace_test_A_const_pool.A[96]); A_arbace_test_A_const_21 = lang.Var_Cast(A_arbace_test_A_const_pool.A[97]); A_arbace_test_A_const_22 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[98]); A_arbace_test_A_const_23 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[99]) }

func A_arbace_test_A_clinit_p2() { A_arbace_test_A_const_24 = lang.Var_Cast(A_arbace_test_A_const_pool.A[100]); A_arbace_test_A_const_25 = lang.Var_Cast(A_arbace_test_A_const_pool.A[101]); A_arbace_test_A_const_26 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[102]); A_arbace_test_A_const_27 = lang.Var_Cast(A_arbace_test_A_const_pool.A[103]); A_arbace_test_A_const_28 = lang.Var_Cast(A_arbace_test_A_const_pool.A[104]); A_arbace_test_A_const_29 = lang.Var_Cast(A_arbace_test_A_const_pool.A[105]); A_arbace_test_A_const_30 = lang.Var_Cast(A_arbace_test_A_const_pool.A[106]); A_arbace_test_A_const_31 = lang.Var_Cast(A_arbace_test_A_const_pool.A[107]); A_arbace_test_A_const_32 = lang.Var_Cast(A_arbace_test_A_const_pool.A[108]); A_arbace_test_A_const_33 = lang.Var_Cast(A_arbace_test_A_const_pool.A[109]); A_arbace_test_A_const_34 = lang.Var_Cast(A_arbace_test_A_const_pool.A[110]); A_arbace_test_A_const_35 = A_arbace_test_A_const_pool.A[111] }

func A_arbace_test_A_clinit_p3() { A_arbace_test_A_const_36 = A_arbace_test_A_const_pool.A[112]; A_arbace_test_A_const_37 = A_arbace_test_A_const_pool.A[113]; A_arbace_test_A_const_38 = lang.Var_Cast(A_arbace_test_A_const_pool.A[114]); A_arbace_test_A_const_39 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[115]); A_arbace_test_A_const_40 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[116]); A_arbace_test_A_const_41 = lang.Var_Cast(A_arbace_test_A_const_pool.A[117]); A_arbace_test_A_const_42 = lang.Var_Cast(A_arbace_test_A_const_pool.A[118]); A_arbace_test_A_const_43 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[119]); A_arbace_test_A_const_44 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[120]); A_arbace_test_A_const_45 = lang.Var_Cast(A_arbace_test_A_const_pool.A[121]); A_arbace_test_A_const_46 = lang.Var_Cast(A_arbace_test_A_const_pool.A[122]); A_arbace_test_A_const_47 = lang.Var_Cast(A_arbace_test_A_const_pool.A[123]) }

func A_arbace_test_A_clinit_p4() { A_arbace_test_A_const_48 = lang.Var_Cast(A_arbace_test_A_const_pool.A[124]); A_arbace_test_A_const_49 = lang.Var_Cast(A_arbace_test_A_const_pool.A[125]); A_arbace_test_A_const_50 = lang.Var_Cast(A_arbace_test_A_const_pool.A[126]); A_arbace_test_A_const_51 = lang.Var_Cast(A_arbace_test_A_const_pool.A[127]); A_arbace_test_A_const_52 = lang.Var_Cast(A_arbace_test_A_const_pool.A[128]); A_arbace_test_A_const_53 = lang.Var_Cast(A_arbace_test_A_const_pool.A[129]); A_arbace_test_A_const_54 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[130]); A_arbace_test_A_const_55 = lang.Var_Cast(A_arbace_test_A_const_pool.A[131]); A_arbace_test_A_const_56 = lang.Var_Cast(A_arbace_test_A_const_pool.A[132]); A_arbace_test_A_const_57 = lang.Var_Cast(A_arbace_test_A_const_pool.A[133]); A_arbace_test_A_const_58 = lang.Var_Cast(A_arbace_test_A_const_pool.A[134]); A_arbace_test_A_const_59 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[135]) }

func A_arbace_test_A_clinit_p5() { A_arbace_test_A_const_60 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[136]); A_arbace_test_A_const_61 = lang.Var_Cast(A_arbace_test_A_const_pool.A[137]); A_arbace_test_A_const_62 = lang.Var_Cast(A_arbace_test_A_const_pool.A[138]); A_arbace_test_A_const_63 = lang.Var_Cast(A_arbace_test_A_const_pool.A[139]); A_arbace_test_A_const_64 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[140]); A_arbace_test_A_const_65 = lang.Var_Cast(A_arbace_test_A_const_pool.A[141]); A_arbace_test_A_const_66 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[142]); A_arbace_test_A_const_67 = lang.Var_Cast(A_arbace_test_A_const_pool.A[143]); A_arbace_test_A_const_68 = lang.Var_Cast(A_arbace_test_A_const_pool.A[144]); A_arbace_test_A_const_69 = lang.Var_Cast(A_arbace_test_A_const_pool.A[145]); A_arbace_test_A_const_70 = lang.Var_Cast(A_arbace_test_A_const_pool.A[146]); A_arbace_test_A_const_71 = lang.Var_Cast(A_arbace_test_A_const_pool.A[147]) }

func A_arbace_test_A_clinit_p6() { A_arbace_test_A_const_72 = lang.Var_Cast(A_arbace_test_A_const_pool.A[148]); A_arbace_test_A_const_73 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[149]); A_arbace_test_A_const_74 = lang.Var_Cast(A_arbace_test_A_const_pool.A[150]); A_arbace_test_A_const_75 = A_arbace_test_A_const_pool.A[151]; A_arbace_test_A_const_76 = A_arbace_test_A_const_pool.A[152]; A_arbace_test_A_const_77 = A_arbace_test_A_const_pool.A[153]; A_arbace_test_A_const_78 = A_arbace_test_A_const_pool.A[154]; A_arbace_test_A_const_79 = A_arbace_test_A_const_pool.A[155]; A_arbace_test_A_const_80 = A_arbace_test_A_const_pool.A[156]; A_arbace_test_A_const_81 = A_arbace_test_A_const_pool.A[157]; A_arbace_test_A_const_82 = A_arbace_test_A_const_pool.A[158]; A_arbace_test_A_const_83 = A_arbace_test_A_const_pool.A[159]; A_arbace_test_A_const_84 = A_arbace_test_A_const_pool.A[160]; A_arbace_test_A_const_85 = A_arbace_test_A_const_pool.A[161]; A_arbace_test_A_const_86 = A_arbace_test_A_const_pool.A[162] }

func A_arbace_test_A_clinit_p7() { A_arbace_test_A_const_87 = A_arbace_test_A_const_pool.A[163]; A_arbace_test_A_const_88 = A_arbace_test_A_const_pool.A[164]; A_arbace_test_A_const_89 = A_arbace_test_A_const_pool.A[165]; A_arbace_test_A_const_90 = A_arbace_test_A_const_pool.A[166]; A_arbace_test_A_const_91 = A_arbace_test_A_const_pool.A[167]; A_arbace_test_A_const_92 = A_arbace_test_A_const_pool.A[168]; A_arbace_test_A_const_93 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[169]); A_arbace_test_A_const_94 = lang.Var_Cast(A_arbace_test_A_const_pool.A[170]); A_arbace_test_A_const_95 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[171]); A_arbace_test_A_const_96 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[172]); A_arbace_test_A_const_97 = A_arbace_test_A_const_pool.A[173]; A_arbace_test_A_const_98 = lang.Var_Cast(A_arbace_test_A_const_pool.A[174]); A_arbace_test_A_const_99 = lang.Var_Cast(A_arbace_test_A_const_pool.A[175]) }

func A_arbace_test_A_clinit_p8() { A_arbace_test_A_const_100 = lang.Var_Cast(A_arbace_test_A_const_pool.A[176]); A_arbace_test_A_const_101 = lang.Var_Cast(A_arbace_test_A_const_pool.A[177]); A_arbace_test_A_const_102 = A_arbace_test_A_const_pool.A[178]; A_arbace_test_A_const_103 = A_arbace_test_A_const_pool.A[179]; A_arbace_test_A_const_104 = A_arbace_test_A_const_pool.A[180]; A_arbace_test_A_const_105 = A_arbace_test_A_const_pool.A[181]; A_arbace_test_A_const_106 = A_arbace_test_A_const_pool.A[182]; A_arbace_test_A_const_107 = A_arbace_test_A_const_pool.A[183]; A_arbace_test_A_const_108 = A_arbace_test_A_const_pool.A[184]; A_arbace_test_A_const_109 = A_arbace_test_A_const_pool.A[185]; A_arbace_test_A_const_110 = A_arbace_test_A_const_pool.A[186]; A_arbace_test_A_const_111 = A_arbace_test_A_const_pool.A[187]; A_arbace_test_A_const_112 = A_arbace_test_A_const_pool.A[188]; A_arbace_test_A_const_113 = lang.Var_Cast(A_arbace_test_A_const_pool.A[189]) }

func A_arbace_test_A_clinit_p9() { A_arbace_test_A_const_114 = lang.Var_Cast(A_arbace_test_A_const_pool.A[190]); A_arbace_test_A_const_115 = A_arbace_test_A_const_pool.A[191]; A_arbace_test_A_const_116 = A_arbace_test_A_const_pool.A[192]; A_arbace_test_A_const_117 = A_arbace_test_A_const_pool.A[193]; A_arbace_test_A_const_118 = A_arbace_test_A_const_pool.A[194]; A_arbace_test_A_const_119 = A_arbace_test_A_const_pool.A[195]; A_arbace_test_A_const_120 = A_arbace_test_A_const_pool.A[196]; A_arbace_test_A_const_121 = A_arbace_test_A_const_pool.A[197]; A_arbace_test_A_const_122 = A_arbace_test_A_const_pool.A[198]; A_arbace_test_A_const_123 = A_arbace_test_A_const_pool.A[199]; A_arbace_test_A_const_124 = A_arbace_test_A_const_pool.A[200]; A_arbace_test_A_const_125 = A_arbace_test_A_const_pool.A[201]; A_arbace_test_A_const_126 = A_arbace_test_A_const_pool.A[202]; A_arbace_test_A_const_127 = A_arbace_test_A_const_pool.A[203]; A_arbace_test_A_const_128 = A_arbace_test_A_const_pool.A[204] }

func A_arbace_test_A_clinit_p10() { A_arbace_test_A_const_129 = A_arbace_test_A_const_pool.A[205]; A_arbace_test_A_const_130 = A_arbace_test_A_const_pool.A[206]; A_arbace_test_A_const_131 = A_arbace_test_A_const_pool.A[207]; A_arbace_test_A_const_132 = A_arbace_test_A_const_pool.A[208]; A_arbace_test_A_const_133 = A_arbace_test_A_const_pool.A[209]; A_arbace_test_A_const_134 = lang.Var_Cast(A_arbace_test_A_const_pool.A[210]); A_arbace_test_A_const_135 = A_arbace_test_A_const_pool.A[211]; A_arbace_test_A_const_136 = A_arbace_test_A_const_pool.A[212]; A_arbace_test_A_const_137 = A_arbace_test_A_const_pool.A[213]; A_arbace_test_A_const_138 = A_arbace_test_A_const_pool.A[214]; A_arbace_test_A_const_139 = A_arbace_test_A_const_pool.A[215]; A_arbace_test_A_const_140 = A_arbace_test_A_const_pool.A[216]; A_arbace_test_A_const_141 = lang.Var_Cast(A_arbace_test_A_const_pool.A[217]); A_arbace_test_A_const_142 = lang.Var_Cast(A_arbace_test_A_const_pool.A[218]); A_arbace_test_A_const_143 = A_arbace_test_A_const_pool.A[219] }

func A_arbace_test_A_clinit_p11() { A_arbace_test_A_const_144 = A_arbace_test_A_const_pool.A[220]; A_arbace_test_A_const_145 = A_arbace_test_A_const_pool.A[221]; A_arbace_test_A_const_146 = A_arbace_test_A_const_pool.A[222]; A_arbace_test_A_const_147 = A_arbace_test_A_const_pool.A[223]; A_arbace_test_A_const_148 = A_arbace_test_A_const_pool.A[224]; A_arbace_test_A_const_149 = lang.Var_Cast(A_arbace_test_A_const_pool.A[225]); A_arbace_test_A_const_150 = A_arbace_test_A_const_pool.A[226]; A_arbace_test_A_const_151 = A_arbace_test_A_const_pool.A[227]; A_arbace_test_A_const_152 = A_arbace_test_A_const_pool.A[228]; A_arbace_test_A_const_153 = A_arbace_test_A_const_pool.A[229]; A_arbace_test_A_const_154 = A_arbace_test_A_const_pool.A[230]; A_arbace_test_A_const_155 = lang.Var_Cast(A_arbace_test_A_const_pool.A[231]); A_arbace_test_A_const_156 = lang.Var_Cast(A_arbace_test_A_const_pool.A[232]); A_arbace_test_A_const_157 = A_arbace_test_A_const_pool.A[233]; A_arbace_test_A_const_158 = A_arbace_test_A_const_pool.A[234] }

func A_arbace_test_A_clinit_p12() { A_arbace_test_A_const_159 = A_arbace_test_A_const_pool.A[235]; A_arbace_test_A_const_160 = A_arbace_test_A_const_pool.A[236]; A_arbace_test_A_const_161 = A_arbace_test_A_const_pool.A[237]; A_arbace_test_A_const_162 = A_arbace_test_A_const_pool.A[238]; A_arbace_test_A_const_163 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[239]); A_arbace_test_A_const_164 = A_arbace_test_A_const_pool.A[240]; A_arbace_test_A_const_165 = A_arbace_test_A_const_pool.A[241]; A_arbace_test_A_const_166 = A_arbace_test_A_const_pool.A[242]; A_arbace_test_A_const_167 = A_arbace_test_A_const_pool.A[243]; A_arbace_test_A_const_168 = A_arbace_test_A_const_pool.A[244]; A_arbace_test_A_const_169 = A_arbace_test_A_const_pool.A[245]; A_arbace_test_A_const_170 = A_arbace_test_A_const_pool.A[246]; A_arbace_test_A_const_171 = lang.Var_Cast(A_arbace_test_A_const_pool.A[247]); A_arbace_test_A_const_172 = lang.Var_Cast(A_arbace_test_A_const_pool.A[248]) }

func A_arbace_test_A_clinit_p13() { A_arbace_test_A_const_173 = lang.Var_Cast(A_arbace_test_A_const_pool.A[249]); A_arbace_test_A_const_174 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[250]); A_arbace_test_A_const_175 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[251]); A_arbace_test_A_const_176 = lang.Var_Cast(A_arbace_test_A_const_pool.A[252]); A_arbace_test_A_const_177 = lang.Var_Cast(A_arbace_test_A_const_pool.A[253]); A_arbace_test_A_const_178 = lang.Var_Cast(A_arbace_test_A_const_pool.A[254]); A_arbace_test_A_const_179 = lang.Var_Cast(A_arbace_test_A_const_pool.A[255]); A_arbace_test_A_const_180 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[256]); A_arbace_test_A_const_181 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[257]); A_arbace_test_A_const_182 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[258]); A_arbace_test_A_const_183 = lang.Var_Cast(A_arbace_test_A_const_pool.A[259]); A_arbace_test_A_const_184 = lang.Var_Cast(A_arbace_test_A_const_pool.A[260]) }

func A_arbace_test_A_clinit_p14() { A_arbace_test_A_const_185 = lang.Var_Cast(A_arbace_test_A_const_pool.A[261]); A_arbace_test_A_const_186 = lang.Var_Cast(A_arbace_test_A_const_pool.A[262]); A_arbace_test_A_const_187 = lang.Var_Cast(A_arbace_test_A_const_pool.A[263]); A_arbace_test_A_const_188 = lang.Var_Cast(A_arbace_test_A_const_pool.A[264]); A_arbace_test_A_const_189 = lang.Var_Cast(A_arbace_test_A_const_pool.A[265]); A_arbace_test_A_const_190 = lang.Var_Cast(A_arbace_test_A_const_pool.A[266]); A_arbace_test_A_const_191 = lang.Var_Cast(A_arbace_test_A_const_pool.A[267]); A_arbace_test_A_const_192 = lang.Var_Cast(A_arbace_test_A_const_pool.A[268]); A_arbace_test_A_const_193 = lang.Var_Cast(A_arbace_test_A_const_pool.A[269]); A_arbace_test_A_const_194 = lang.Var_Cast(A_arbace_test_A_const_pool.A[270]); A_arbace_test_A_const_195 = lang.Var_Cast(A_arbace_test_A_const_pool.A[271]); A_arbace_test_A_const_196 = lang.Var_Cast(A_arbace_test_A_const_pool.A[272]) }

func A_arbace_test_A_clinit_p15() { A_arbace_test_A_const_197 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[273]); A_arbace_test_A_const_198 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[274]); A_arbace_test_A_const_199 = lang.Var_Cast(A_arbace_test_A_const_pool.A[275]); A_arbace_test_A_const_200 = lang.Var_Cast(A_arbace_test_A_const_pool.A[276]); A_arbace_test_A_const_201 = lang.Var_Cast(A_arbace_test_A_const_pool.A[277]); A_arbace_test_A_const_202 = lang.Var_Cast(A_arbace_test_A_const_pool.A[278]); A_arbace_test_A_const_203 = lang.Var_Cast(A_arbace_test_A_const_pool.A[279]); A_arbace_test_A_const_204 = lang.Var_Cast(A_arbace_test_A_const_pool.A[280]); A_arbace_test_A_const_205 = lang.Keyword_Cast(A_arbace_test_A_const_pool.A[281]); A_arbace_test_A_const_206 = lang.Var_Cast(A_arbace_test_A_const_pool.A[282]); A_arbace_test_A_const_207 = lang.Var_Cast(A_arbace_test_A_const_pool.A[283]); A_arbace_test_A_const_208 = lang.Var_Cast(A_arbace_test_A_const_pool.A[284]) }

func A_arbace_test_A_clinit_p16() { A_arbace_test_A_const_209 = lang.Var_Cast(A_arbace_test_A_const_pool.A[285]); A_arbace_test_A_const_210 = lang.Var_Cast(A_arbace_test_A_const_pool.A[286]); A_arbace_test_A_const_211 = A_arbace_test_A_const_pool.A[287]; A_arbace_test_A_const_212 = lang.Var_Cast(A_arbace_test_A_const_pool.A[288]) }

func A_arbace_test_A_New() *A_arbace_test_A { A_arbace_test_A_Init(); t := &A_arbace_test_A{}; t.Ctor(); return t }

func (t *A_arbace_test_A) Ctor() {}

func (t *A_arbace_test_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_A) GetClass__Class() *jrt.Class { return A_arbace_test_A_class }

func (t *A_arbace_test_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_A); return ok }

func A_arbace_test_A_Cast(x any) *A_arbace_test_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_A_class)) }; return v }



type A_arbace_test_add_ns_meta_A struct{ j2g_header uint64 }

var A_arbace_test_add_ns_meta_A_fn_class *jrt.Class



type A_arbace_test_are_A struct{ j2g_header uint64 }

var A_arbace_test_are_A_fn_class *jrt.Class



type A_arbace_test_assert_any_A struct{ j2g_header uint64 }

var A_arbace_test_assert_any_A_fn_class *jrt.Class



type A_arbace_test_assert_predicate_A struct{ j2g_header uint64 }

var A_arbace_test_assert_predicate_A_fn_class *jrt.Class



type A_arbace_test_compose_fixtures_A struct{ j2g_header uint64 }

var A_arbace_test_compose_fixtures_A_fn_class *jrt.Class



type A_arbace_test_compose_fixtures_fn__196000167_A struct{ j2g_header uint64; F_f1, F_f2 any }

var A_arbace_test_compose_fixtures_fn__196000167_A_fn_class *jrt.Class



type A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A struct{ j2g_header uint64; F_g, F_f2 any }

var A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_fn_class *jrt.Class



type A_arbace_test_default_fixture_A struct{ j2g_header uint64 }

var A_arbace_test_default_fixture_A_fn_class *jrt.Class



type A_arbace_test_deftest_A struct{ j2g_header uint64 }

var A_arbace_test_deftest_A_fn_class *jrt.Class



type A_arbace_test_deftest__A struct{ j2g_header uint64 }

var A_arbace_test_deftest__A_fn_class *jrt.Class



type A_arbace_test_do_report_A struct{ j2g_header uint64 }

var A_arbace_test_do_report_A_fn_class *jrt.Class



type A_arbace_test_do_report_fn__196000036_A struct{ j2g_header uint64 }

var A_arbace_test_do_report_fn__196000036_A_fn_class *jrt.Class



type A_arbace_test_eval196000004_A struct{ jrt.Object }

func A_arbace_test_eval196000004_A_New() *A_arbace_test_eval196000004_A { t := &A_arbace_test_eval196000004_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000004_A) Ctor() {}

func (t *A_arbace_test_eval196000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000004_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000004_A_class }

func (t *A_arbace_test_eval196000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000004_A); return ok }

func A_arbace_test_eval196000004_A_Cast(x any) *A_arbace_test_eval196000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000004_A_class)) }; return v }



type A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_fn_class *jrt.Class



type A_arbace_test_eval196000008_A struct{ jrt.Object }

func A_arbace_test_eval196000008_A_New() *A_arbace_test_eval196000008_A { t := &A_arbace_test_eval196000008_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000008_A) Ctor() {}

func (t *A_arbace_test_eval196000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000008_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000008_A_class }

func (t *A_arbace_test_eval196000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000008_A); return ok }

func A_arbace_test_eval196000008_A_Cast(x any) *A_arbace_test_eval196000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000008_A_class)) }; return v }



type A_arbace_test_eval196000008_fn__196000009_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000008_fn__196000009_A_fn_class *jrt.Class



type A_arbace_test_eval196000039_A struct{ jrt.Object }

func A_arbace_test_eval196000039_A_New() *A_arbace_test_eval196000039_A { t := &A_arbace_test_eval196000039_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000039_A) Ctor() {}

func (t *A_arbace_test_eval196000039_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000039_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000039_A_class }

func (t *A_arbace_test_eval196000039_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000039_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000039_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000039_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000039_A); return ok }

func A_arbace_test_eval196000039_A_Cast(x any) *A_arbace_test_eval196000039_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000039_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000039_A_class)) }; return v }



type A_arbace_test_eval196000039_fn__196000040_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000039_fn__196000040_A_fn_class *jrt.Class



type A_arbace_test_eval196000043_A struct{ jrt.Object }

func A_arbace_test_eval196000043_A_New() *A_arbace_test_eval196000043_A { t := &A_arbace_test_eval196000043_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000043_A) Ctor() {}

func (t *A_arbace_test_eval196000043_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000043_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000043_A_class }

func (t *A_arbace_test_eval196000043_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000043_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000043_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000043_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000043_A); return ok }

func A_arbace_test_eval196000043_A_Cast(x any) *A_arbace_test_eval196000043_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000043_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000043_A_class)) }; return v }



type A_arbace_test_eval196000043_fn__196000044_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000043_fn__196000044_A_fn_class *jrt.Class



type A_arbace_test_eval196000047_A struct{ jrt.Object }

func A_arbace_test_eval196000047_A_New() *A_arbace_test_eval196000047_A { t := &A_arbace_test_eval196000047_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000047_A) Ctor() {}

func (t *A_arbace_test_eval196000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000047_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000047_A_class }

func (t *A_arbace_test_eval196000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000047_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000047_A); return ok }

func A_arbace_test_eval196000047_A_Cast(x any) *A_arbace_test_eval196000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000047_A_class)) }; return v }



type A_arbace_test_eval196000047_fn__196000048_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000047_fn__196000048_A_fn_class *jrt.Class



type A_arbace_test_eval196000051_A struct{ jrt.Object }

func A_arbace_test_eval196000051_A_New() *A_arbace_test_eval196000051_A { t := &A_arbace_test_eval196000051_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000051_A) Ctor() {}

func (t *A_arbace_test_eval196000051_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000051_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000051_A_class }

func (t *A_arbace_test_eval196000051_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000051_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000051_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000051_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000051_A); return ok }

func A_arbace_test_eval196000051_A_Cast(x any) *A_arbace_test_eval196000051_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000051_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000051_A_class)) }; return v }



type A_arbace_test_eval196000051_fn__196000052_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000051_fn__196000052_A_fn_class *jrt.Class



type A_arbace_test_eval196000055_A struct{ jrt.Object }

func A_arbace_test_eval196000055_A_New() *A_arbace_test_eval196000055_A { t := &A_arbace_test_eval196000055_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000055_A) Ctor() {}

func (t *A_arbace_test_eval196000055_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000055_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000055_A_class }

func (t *A_arbace_test_eval196000055_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000055_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000055_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000055_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000055_A); return ok }

func A_arbace_test_eval196000055_A_Cast(x any) *A_arbace_test_eval196000055_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000055_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000055_A_class)) }; return v }



type A_arbace_test_eval196000055_fn__196000056_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000055_fn__196000056_A_fn_class *jrt.Class



type A_arbace_test_eval196000059_A struct{ jrt.Object }

func A_arbace_test_eval196000059_A_New() *A_arbace_test_eval196000059_A { t := &A_arbace_test_eval196000059_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000059_A) Ctor() {}

func (t *A_arbace_test_eval196000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000059_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000059_A_class }

func (t *A_arbace_test_eval196000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000059_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000059_A); return ok }

func A_arbace_test_eval196000059_A_Cast(x any) *A_arbace_test_eval196000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000059_A_class)) }; return v }



type A_arbace_test_eval196000059_fn__196000060_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000059_fn__196000060_A_fn_class *jrt.Class



type A_arbace_test_eval196000063_A struct{ jrt.Object }

func A_arbace_test_eval196000063_A_New() *A_arbace_test_eval196000063_A { t := &A_arbace_test_eval196000063_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000063_A) Ctor() {}

func (t *A_arbace_test_eval196000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000063_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000063_A_class }

func (t *A_arbace_test_eval196000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000063_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000063_A); return ok }

func A_arbace_test_eval196000063_A_Cast(x any) *A_arbace_test_eval196000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000063_A_class)) }; return v }



type A_arbace_test_eval196000063_fn__196000064_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000063_fn__196000064_A_fn_class *jrt.Class



type A_arbace_test_eval196000067_A struct{ jrt.Object }

func A_arbace_test_eval196000067_A_New() *A_arbace_test_eval196000067_A { t := &A_arbace_test_eval196000067_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000067_A) Ctor() {}

func (t *A_arbace_test_eval196000067_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000067_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000067_A_class }

func (t *A_arbace_test_eval196000067_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000067_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000067_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000067_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000067_A); return ok }

func A_arbace_test_eval196000067_A_Cast(x any) *A_arbace_test_eval196000067_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000067_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000067_A_class)) }; return v }



type A_arbace_test_eval196000067_fn__196000068_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000067_fn__196000068_A_fn_class *jrt.Class



type A_arbace_test_eval196000071_A struct{ jrt.Object }

func A_arbace_test_eval196000071_A_New() *A_arbace_test_eval196000071_A { t := &A_arbace_test_eval196000071_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000071_A) Ctor() {}

func (t *A_arbace_test_eval196000071_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000071_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000071_A_class }

func (t *A_arbace_test_eval196000071_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000071_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000071_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000071_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000071_A); return ok }

func A_arbace_test_eval196000071_A_Cast(x any) *A_arbace_test_eval196000071_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000071_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000071_A_class)) }; return v }



type A_arbace_test_eval196000071_fn__196000072_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000071_fn__196000072_A_fn_class *jrt.Class



type A_arbace_test_eval196000082_A struct{ jrt.Object }

func A_arbace_test_eval196000082_A_New() *A_arbace_test_eval196000082_A { t := &A_arbace_test_eval196000082_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000082_A) Ctor() {}

func (t *A_arbace_test_eval196000082_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000082_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000082_A_class }

func (t *A_arbace_test_eval196000082_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000082_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000082_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000082_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000082_A); return ok }

func A_arbace_test_eval196000082_A_Cast(x any) *A_arbace_test_eval196000082_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000082_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000082_A_class)) }; return v }



type A_arbace_test_eval196000082_fn__196000083_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000082_fn__196000083_A_fn_class *jrt.Class



type A_arbace_test_eval196000086_A struct{ jrt.Object }

func A_arbace_test_eval196000086_A_New() *A_arbace_test_eval196000086_A { t := &A_arbace_test_eval196000086_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000086_A) Ctor() {}

func (t *A_arbace_test_eval196000086_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000086_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000086_A_class }

func (t *A_arbace_test_eval196000086_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000086_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000086_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000086_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000086_A); return ok }

func A_arbace_test_eval196000086_A_Cast(x any) *A_arbace_test_eval196000086_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000086_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000086_A_class)) }; return v }



type A_arbace_test_eval196000086_fn__196000087_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000086_fn__196000087_A_fn_class *jrt.Class



type A_arbace_test_eval196000090_A struct{ jrt.Object }

func A_arbace_test_eval196000090_A_New() *A_arbace_test_eval196000090_A { t := &A_arbace_test_eval196000090_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000090_A) Ctor() {}

func (t *A_arbace_test_eval196000090_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000090_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000090_A_class }

func (t *A_arbace_test_eval196000090_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000090_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000090_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000090_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000090_A); return ok }

func A_arbace_test_eval196000090_A_Cast(x any) *A_arbace_test_eval196000090_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000090_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000090_A_class)) }; return v }



type A_arbace_test_eval196000090_fn__196000091_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000090_fn__196000091_A_fn_class *jrt.Class



type A_arbace_test_eval196000097_A struct{ jrt.Object }

func A_arbace_test_eval196000097_A_New() *A_arbace_test_eval196000097_A { t := &A_arbace_test_eval196000097_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000097_A) Ctor() {}

func (t *A_arbace_test_eval196000097_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000097_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000097_A_class }

func (t *A_arbace_test_eval196000097_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000097_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000097_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000097_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000097_A); return ok }

func A_arbace_test_eval196000097_A_Cast(x any) *A_arbace_test_eval196000097_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000097_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000097_A_class)) }; return v }



type A_arbace_test_eval196000097_fn__196000098_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000097_fn__196000098_A_fn_class *jrt.Class



type A_arbace_test_eval196000102_A struct{ jrt.Object }

func A_arbace_test_eval196000102_A_New() *A_arbace_test_eval196000102_A { t := &A_arbace_test_eval196000102_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000102_A) Ctor() {}

func (t *A_arbace_test_eval196000102_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000102_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000102_A_class }

func (t *A_arbace_test_eval196000102_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000102_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000102_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000102_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000102_A); return ok }

func A_arbace_test_eval196000102_A_Cast(x any) *A_arbace_test_eval196000102_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000102_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000102_A_class)) }; return v }



type A_arbace_test_eval196000102_fn__196000103_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000102_fn__196000103_A_fn_class *jrt.Class



type A_arbace_test_eval196000108_A struct{ jrt.Object }

func A_arbace_test_eval196000108_A_New() *A_arbace_test_eval196000108_A { t := &A_arbace_test_eval196000108_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000108_A) Ctor() {}

func (t *A_arbace_test_eval196000108_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000108_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000108_A_class }

func (t *A_arbace_test_eval196000108_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000108_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000108_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000108_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000108_A); return ok }

func A_arbace_test_eval196000108_A_Cast(x any) *A_arbace_test_eval196000108_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000108_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000108_A_class)) }; return v }



type A_arbace_test_eval196000108_fn__196000109_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000108_fn__196000109_A_fn_class *jrt.Class



type A_arbace_test_eval196000154_A struct{ jrt.Object }

func A_arbace_test_eval196000154_A_New() *A_arbace_test_eval196000154_A { t := &A_arbace_test_eval196000154_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000154_A) Ctor() {}

func (t *A_arbace_test_eval196000154_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000154_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000154_A_class }

func (t *A_arbace_test_eval196000154_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000154_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000154_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000154_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000154_A); return ok }

func A_arbace_test_eval196000154_A_Cast(x any) *A_arbace_test_eval196000154_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000154_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000154_A_class)) }; return v }



type A_arbace_test_eval196000154_fn__196000155_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000154_fn__196000155_A_fn_class *jrt.Class



type A_arbace_test_eval196000158_A struct{ jrt.Object }

func A_arbace_test_eval196000158_A_New() *A_arbace_test_eval196000158_A { t := &A_arbace_test_eval196000158_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000158_A) Ctor() {}

func (t *A_arbace_test_eval196000158_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000158_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000158_A_class }

func (t *A_arbace_test_eval196000158_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000158_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000158_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000158_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000158_A); return ok }

func A_arbace_test_eval196000158_A_Cast(x any) *A_arbace_test_eval196000158_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000158_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000158_A_class)) }; return v }



type A_arbace_test_eval196000158_fn__196000159_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000158_fn__196000159_A_fn_class *jrt.Class



type A_arbace_test_eval196000162_A struct{ jrt.Object }

func A_arbace_test_eval196000162_A_New() *A_arbace_test_eval196000162_A { t := &A_arbace_test_eval196000162_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000162_A) Ctor() {}

func (t *A_arbace_test_eval196000162_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000162_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000162_A_class }

func (t *A_arbace_test_eval196000162_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000162_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000162_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000162_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000162_A); return ok }

func A_arbace_test_eval196000162_A_Cast(x any) *A_arbace_test_eval196000162_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000162_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000162_A_class)) }; return v }



type A_arbace_test_eval196000162_fn__196000163_A struct{ j2g_header uint64 }

var A_arbace_test_eval196000162_fn__196000163_A_fn_class *jrt.Class



type A_arbace_test_file_and_line_A struct{ j2g_header uint64 }

var A_arbace_test_file_and_line_A_fn_class *jrt.Class



type A_arbace_test_file_position_A struct{ j2g_header uint64 }

var A_arbace_test_file_position_A_fn_class *jrt.Class



type A_arbace_test_function_QMARK__A struct{ j2g_header uint64 }

var A_arbace_test_function_QMARK__A_fn_class *jrt.Class



type A_arbace_test_get_possibly_unbound_var_A struct{ j2g_header uint64 }

var A_arbace_test_get_possibly_unbound_var_A_fn_class *jrt.Class



type A_arbace_test_inc_report_counter_A struct{ j2g_header uint64 }

var A_arbace_test_inc_report_counter_A_fn_class *jrt.Class



type A_arbace_test_inc_report_counter_fn__196000027_A struct{ j2g_header uint64; F_name any }

var A_arbace_test_inc_report_counter_fn__196000027_A_fn_class *jrt.Class



type A_arbace_test_is_A struct{ j2g_header uint64 }

var A_arbace_test_is_A_fn_class *jrt.Class



type A_arbace_test_join_fixtures_A struct{ j2g_header uint64 }

var A_arbace_test_join_fixtures_A_fn_class *jrt.Class



type A_arbace_test_run_all_tests_A struct{ j2g_header uint64 }

var A_arbace_test_run_all_tests_A_fn_class *jrt.Class



type A_arbace_test_run_all_tests_fn__196000211_A struct{ j2g_header uint64; F_re any }

var A_arbace_test_run_all_tests_fn__196000211_A_fn_class *jrt.Class



type A_arbace_test_run_test_A struct{ j2g_header uint64 }

var A_arbace_test_run_test_A_fn_class *jrt.Class



type A_arbace_test_run_test_var_A struct{ j2g_header uint64 }

var A_arbace_test_run_test_var_A_fn_class *jrt.Class



type A_arbace_test_run_tests_A struct{ j2g_header uint64 }

var A_arbace_test_run_tests_A_fn_class *jrt.Class



type A_arbace_test_set_test_A struct{ j2g_header uint64 }

var A_arbace_test_set_test_A_fn_class *jrt.Class



type A_arbace_test_stacktrace_file_and_line_A struct{ j2g_header uint64 }

var A_arbace_test_stacktrace_file_and_line_A_fn_class *jrt.Class



type A_arbace_test_successful_QMARK__A struct{ j2g_header uint64 }

var A_arbace_test_successful_QMARK__A_fn_class *jrt.Class



type A_arbace_test_test_all_vars_A struct{ j2g_header uint64 }

var A_arbace_test_test_all_vars_A_fn_class *jrt.Class



type A_arbace_test_test_ns_A struct{ j2g_header uint64 }

var A_arbace_test_test_ns_A_fn_class *jrt.Class



type A_arbace_test_test_var_A struct{ j2g_header uint64 }

var A_arbace_test_test_var_A_fn_class *jrt.Class



type A_arbace_test_test_var_fn__196000173_A struct{ j2g_header uint64; F_t any }

var A_arbace_test_test_var_fn__196000173_A_fn_class *jrt.Class



type A_arbace_test_test_vars_A struct{ j2g_header uint64 }

var A_arbace_test_test_vars_A_fn_class *jrt.Class



type A_arbace_test_test_vars_fn__196000183_A struct{ j2g_header uint64; F_vars, F_each_fixture_fn any }

var A_arbace_test_test_vars_fn__196000183_A_fn_class *jrt.Class



type A_arbace_test_test_vars_fn__196000183_fn__196000188_A struct{ j2g_header uint64; F_v any }

var A_arbace_test_test_vars_fn__196000183_fn__196000188_A_fn_class *jrt.Class



type A_arbace_test_test_vars_fn__196000183_fn__196000190_A struct{ j2g_header uint64; F_v any }

var A_arbace_test_test_vars_fn__196000183_fn__196000190_A_fn_class *jrt.Class



type A_arbace_test_test_vars_fn__196000196_A struct{ j2g_header uint64; F_vars, F_each_fixture_fn any }

var A_arbace_test_test_vars_fn__196000196_A_fn_class *jrt.Class



type A_arbace_test_test_vars_fn__196000196_fn__196000201_A struct{ j2g_header uint64; F_v any }

var A_arbace_test_test_vars_fn__196000196_fn__196000201_A_fn_class *jrt.Class



type A_arbace_test_test_vars_fn__196000196_fn__196000203_A struct{ j2g_header uint64; F_v any }

var A_arbace_test_test_vars_fn__196000196_fn__196000203_A_fn_class *jrt.Class



type A_arbace_test_testing_A struct{ j2g_header uint64 }

var A_arbace_test_testing_A_fn_class *jrt.Class



type A_arbace_test_testing_contexts_str_A struct{ j2g_header uint64 }

var A_arbace_test_testing_contexts_str_A_fn_class *jrt.Class



type A_arbace_test_testing_vars_str_A struct{ j2g_header uint64 }

var A_arbace_test_testing_vars_str_A_fn_class *jrt.Class



type A_arbace_test_testing_vars_str_fn__196000023_A struct{ j2g_header uint64 }

var A_arbace_test_testing_vars_str_fn__196000023_A_fn_class *jrt.Class



type A_arbace_test_try_expr_A struct{ j2g_header uint64 }

var A_arbace_test_try_expr_A_fn_class *jrt.Class



type A_arbace_test_with_test_A struct{ j2g_header uint64 }

var A_arbace_test_with_test_A_fn_class *jrt.Class



type A_arbace_test_with_test_out_A struct{ j2g_header uint64 }

var A_arbace_test_with_test_out_A_fn_class *jrt.Class
