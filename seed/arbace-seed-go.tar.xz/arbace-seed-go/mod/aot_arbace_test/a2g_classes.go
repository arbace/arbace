//line a2g_classes.ae:1
package aot_arbace_test

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_test_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_A_New()}; return nil }

var A_arbace_test_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_A_new}

var A_arbace_test_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_test.A_arbace_test_A"})

func init() { i := A_arbace_test_A_class.Info(); i.IsInstance = A_arbace_test_A_InstanceOf; i.Init = A_arbace_test_A_Init; i.Table = A_arbace_test_A_members; jrt.RegisterGoType(A_arbace_test_A_class, reflect.TypeFor[A_arbace_test_A]()) }

func A_arbace_test_add_ns_meta_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_add_ns_meta_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_add_ns_meta_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_add_ns_meta_A_New()}; return nil }

func A_arbace_test_add_ns_meta_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_add_ns_meta_A_fn_class)}; return nil }

var A_arbace_test_add_ns_meta_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_add_ns_meta_A_invoke, New: A_arbace_test_add_ns_meta_A_new, Get: A_arbace_test_add_ns_meta_A_get}

var A_arbace_test_add_ns_meta_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$add_ns_meta", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_test_A_class, Simple: "add_ns_meta", Go: "arbace/aot_arbace_test.A_arbace_test_add_ns_meta_A", Source: "test.ae"})

func init() { i := A_arbace_test_add_ns_meta_A_class.Info(); i.IsInstance = A_arbace_test_add_ns_meta_A_InstanceOf; i.Init = A_arbace_test_add_ns_meta_A_Init; i.Table = A_arbace_test_add_ns_meta_A_members; jrt.RegisterGoType(A_arbace_test_add_ns_meta_A_class, reflect.TypeFor[A_arbace_test_add_ns_meta_A]()) }

func A_arbace_test_are_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_are_A).DoInvoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_test_are_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_are_A_New()}; return nil }

func A_arbace_test_are_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_are_A_fn_class)}; return nil }

var A_arbace_test_are_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_are_A_invoke, New: A_arbace_test_are_A_new, Get: A_arbace_test_are_A_get}

var A_arbace_test_are_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$are", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR4_class}, Declaring: A_arbace_test_A_class, Simple: "are", Go: "arbace/aot_arbace_test.A_arbace_test_are_A", Source: "test.ae"})

func init() { i := A_arbace_test_are_A_class.Info(); i.IsInstance = A_arbace_test_are_A_InstanceOf; i.Init = A_arbace_test_are_A_Init; i.Table = A_arbace_test_are_A_members; jrt.RegisterGoType(A_arbace_test_are_A_class, reflect.TypeFor[A_arbace_test_are_A]()) }

func A_arbace_test_assert_any_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_assert_any_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_assert_any_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_assert_any_A_New()}; return nil }

func A_arbace_test_assert_any_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_assert_any_A_fn_class)}; return nil }

var A_arbace_test_assert_any_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_assert_any_A_invoke, New: A_arbace_test_assert_any_A_new, Get: A_arbace_test_assert_any_A_get}

var A_arbace_test_assert_any_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$assert_any", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_test_A_class, Simple: "assert_any", Go: "arbace/aot_arbace_test.A_arbace_test_assert_any_A", Source: "test.ae"})

func init() { i := A_arbace_test_assert_any_A_class.Info(); i.IsInstance = A_arbace_test_assert_any_A_InstanceOf; i.Init = A_arbace_test_assert_any_A_Init; i.Table = A_arbace_test_assert_any_A_members; jrt.RegisterGoType(A_arbace_test_assert_any_A_class, reflect.TypeFor[A_arbace_test_assert_any_A]()) }

func A_arbace_test_assert_predicate_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_assert_predicate_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_assert_predicate_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_assert_predicate_A_New()}; return nil }

func A_arbace_test_assert_predicate_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_assert_predicate_A_fn_class)}; return nil }

var A_arbace_test_assert_predicate_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_assert_predicate_A_invoke, New: A_arbace_test_assert_predicate_A_new, Get: A_arbace_test_assert_predicate_A_get}

var A_arbace_test_assert_predicate_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$assert_predicate", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_test_A_class, Simple: "assert_predicate", Go: "arbace/aot_arbace_test.A_arbace_test_assert_predicate_A", Source: "test.ae"})

func init() { i := A_arbace_test_assert_predicate_A_class.Info(); i.IsInstance = A_arbace_test_assert_predicate_A_InstanceOf; i.Init = A_arbace_test_assert_predicate_A_Init; i.Table = A_arbace_test_assert_predicate_A_members; jrt.RegisterGoType(A_arbace_test_assert_predicate_A_class, reflect.TypeFor[A_arbace_test_assert_predicate_A]()) }

func A_arbace_test_compose_fixtures_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_compose_fixtures_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_compose_fixtures_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_compose_fixtures_A_New()}; return nil }

func A_arbace_test_compose_fixtures_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_compose_fixtures_A_fn_class)}; return nil }

var A_arbace_test_compose_fixtures_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_compose_fixtures_A_invoke, New: A_arbace_test_compose_fixtures_A_new, Get: A_arbace_test_compose_fixtures_A_get}

var A_arbace_test_compose_fixtures_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$compose_fixtures", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_test_A_class, Simple: "compose_fixtures", Go: "arbace/aot_arbace_test.A_arbace_test_compose_fixtures_A", Source: "test.ae"})

func init() { i := A_arbace_test_compose_fixtures_A_class.Info(); i.IsInstance = A_arbace_test_compose_fixtures_A_InstanceOf; i.Init = A_arbace_test_compose_fixtures_A_Init; i.Table = A_arbace_test_compose_fixtures_A_members; jrt.RegisterGoType(A_arbace_test_compose_fixtures_A_class, reflect.TypeFor[A_arbace_test_compose_fixtures_A]()) }

func A_arbace_test_compose_fixtures_fn__196000167_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_compose_fixtures_fn__196000167_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_compose_fixtures_fn__196000167_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_compose_fixtures_fn__196000167_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_test_compose_fixtures_fn__196000167_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_compose_fixtures_fn__196000167_A_fn_class)}; return nil }

var A_arbace_test_compose_fixtures_fn__196000167_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_compose_fixtures_fn__196000167_A_invoke, New: A_arbace_test_compose_fixtures_fn__196000167_A_new, Get: A_arbace_test_compose_fixtures_fn__196000167_A_get}

var A_arbace_test_compose_fixtures_fn__196000167_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$compose_fixtures$fn__196000167", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_compose_fixtures_A_class, Simple: "fn__196000167", Go: "arbace/aot_arbace_test.A_arbace_test_compose_fixtures_fn__196000167_A", Source: "test.ae"})

func init() { i := A_arbace_test_compose_fixtures_fn__196000167_A_class.Info(); i.IsInstance = A_arbace_test_compose_fixtures_fn__196000167_A_InstanceOf; i.Init = A_arbace_test_compose_fixtures_fn__196000167_A_Init; i.Table = A_arbace_test_compose_fixtures_fn__196000167_A_members; jrt.RegisterGoType(A_arbace_test_compose_fixtures_fn__196000167_A_class, reflect.TypeFor[A_arbace_test_compose_fixtures_fn__196000167_A]()) }

func A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_fn_class)}; return nil }

var A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_invoke, New: A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_new, Get: A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_get}

var A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$compose_fixtures$fn__196000167$fn__196000168", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_compose_fixtures_fn__196000167_A_class, Simple: "fn__196000168", Go: "arbace/aot_arbace_test.A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A", Source: "test.ae"})

func init() { i := A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_class.Info(); i.IsInstance = A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_InstanceOf; i.Init = A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_Init; i.Table = A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_members; jrt.RegisterGoType(A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_class, reflect.TypeFor[A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A]()) }

func A_arbace_test_default_fixture_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_default_fixture_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_default_fixture_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_default_fixture_A_New()}; return nil }

func A_arbace_test_default_fixture_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_default_fixture_A_fn_class)}; return nil }

var A_arbace_test_default_fixture_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_default_fixture_A_invoke, New: A_arbace_test_default_fixture_A_new, Get: A_arbace_test_default_fixture_A_get}

var A_arbace_test_default_fixture_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$default_fixture", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_A_class, Simple: "default_fixture", Go: "arbace/aot_arbace_test.A_arbace_test_default_fixture_A", Source: "test.ae"})

func init() { i := A_arbace_test_default_fixture_A_class.Info(); i.IsInstance = A_arbace_test_default_fixture_A_InstanceOf; i.Init = A_arbace_test_default_fixture_A_Init; i.Table = A_arbace_test_default_fixture_A_members; jrt.RegisterGoType(A_arbace_test_default_fixture_A_class, reflect.TypeFor[A_arbace_test_default_fixture_A]()) }

func A_arbace_test_deftest_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_deftest_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_test_deftest_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_deftest_A_New()}; return nil }

func A_arbace_test_deftest_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_deftest_A_fn_class)}; return nil }

var A_arbace_test_deftest_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_deftest_A_invoke, New: A_arbace_test_deftest_A_new, Get: A_arbace_test_deftest_A_get}

var A_arbace_test_deftest_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$deftest", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_test_A_class, Simple: "deftest", Go: "arbace/aot_arbace_test.A_arbace_test_deftest_A", Source: "test.ae"})

func init() { i := A_arbace_test_deftest_A_class.Info(); i.IsInstance = A_arbace_test_deftest_A_InstanceOf; i.Init = A_arbace_test_deftest_A_Init; i.Table = A_arbace_test_deftest_A_members; jrt.RegisterGoType(A_arbace_test_deftest_A_class, reflect.TypeFor[A_arbace_test_deftest_A]()) }

func A_arbace_test_deftest__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_deftest__A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_test_deftest__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_deftest__A_New()}; return nil }

func A_arbace_test_deftest__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_deftest__A_fn_class)}; return nil }

var A_arbace_test_deftest__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_deftest__A_invoke, New: A_arbace_test_deftest__A_new, Get: A_arbace_test_deftest__A_get}

var A_arbace_test_deftest__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$deftest_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_test_A_class, Simple: "deftest_", Go: "arbace/aot_arbace_test.A_arbace_test_deftest__A", Source: "test.ae"})

func init() { i := A_arbace_test_deftest__A_class.Info(); i.IsInstance = A_arbace_test_deftest__A_InstanceOf; i.Init = A_arbace_test_deftest__A_Init; i.Table = A_arbace_test_deftest__A_members; jrt.RegisterGoType(A_arbace_test_deftest__A_class, reflect.TypeFor[A_arbace_test_deftest__A]()) }

func A_arbace_test_do_report_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_do_report_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_do_report_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_do_report_A_New()}; return nil }

func A_arbace_test_do_report_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_do_report_A_fn_class)}; return nil }

var A_arbace_test_do_report_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_do_report_A_invoke, New: A_arbace_test_do_report_A_new, Get: A_arbace_test_do_report_A_get}

var A_arbace_test_do_report_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$do_report", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_A_class, Simple: "do_report", Go: "arbace/aot_arbace_test.A_arbace_test_do_report_A", Source: "test.ae"})

func init() { i := A_arbace_test_do_report_A_class.Info(); i.IsInstance = A_arbace_test_do_report_A_InstanceOf; i.Init = A_arbace_test_do_report_A_Init; i.Table = A_arbace_test_do_report_A_members; jrt.RegisterGoType(A_arbace_test_do_report_A_class, reflect.TypeFor[A_arbace_test_do_report_A]()) }

func A_arbace_test_do_report_fn__196000036_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_do_report_fn__196000036_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_do_report_fn__196000036_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_do_report_fn__196000036_A_New()}; return nil }

func A_arbace_test_do_report_fn__196000036_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_do_report_fn__196000036_A_fn_class)}; return nil }

var A_arbace_test_do_report_fn__196000036_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_do_report_fn__196000036_A_invoke, New: A_arbace_test_do_report_fn__196000036_A_new, Get: A_arbace_test_do_report_fn__196000036_A_get}

var A_arbace_test_do_report_fn__196000036_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$do_report$fn__196000036", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_do_report_A_class, Simple: "fn__196000036", Go: "arbace/aot_arbace_test.A_arbace_test_do_report_fn__196000036_A", Source: "test.ae"})

func init() { i := A_arbace_test_do_report_fn__196000036_A_class.Info(); i.IsInstance = A_arbace_test_do_report_fn__196000036_A_InstanceOf; i.Init = A_arbace_test_do_report_fn__196000036_A_Init; i.Table = A_arbace_test_do_report_fn__196000036_A_members; jrt.RegisterGoType(A_arbace_test_do_report_fn__196000036_A_class, reflect.TypeFor[A_arbace_test_do_report_fn__196000036_A]()) }

func A_arbace_test_eval196000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000004_A_New()}; return nil }

var A_arbace_test_eval196000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000004_A_new}

var A_arbace_test_eval196000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000004", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000004_A"})

func init() { i := A_arbace_test_eval196000004_A_class.Info(); i.IsInstance = A_arbace_test_eval196000004_A_InstanceOf; i.Table = A_arbace_test_eval196000004_A_members; jrt.RegisterGoType(A_arbace_test_eval196000004_A_class, reflect.TypeFor[A_arbace_test_eval196000004_A]()) }

func A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_New()}; return nil }

func A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_fn_class)}; return nil }

var A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_invoke, New: A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_new, Get: A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_get}

var A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000004$loading__1927001464__auto____196000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_eval196000004_A_class, Simple: "loading__1927001464__auto____196000005", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_class.Info(); i.IsInstance = A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_InstanceOf; i.Init = A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_Init; i.Table = A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_members; jrt.RegisterGoType(A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_class, reflect.TypeFor[A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A]()) }

func A_arbace_test_eval196000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000008_A_New()}; return nil }

var A_arbace_test_eval196000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000008_A_new}

var A_arbace_test_eval196000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000008", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000008_A"})

func init() { i := A_arbace_test_eval196000008_A_class.Info(); i.IsInstance = A_arbace_test_eval196000008_A_InstanceOf; i.Table = A_arbace_test_eval196000008_A_members; jrt.RegisterGoType(A_arbace_test_eval196000008_A_class, reflect.TypeFor[A_arbace_test_eval196000008_A]()) }

func A_arbace_test_eval196000008_fn__196000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000008_fn__196000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_eval196000008_fn__196000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000008_fn__196000009_A_New()}; return nil }

func A_arbace_test_eval196000008_fn__196000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000008_fn__196000009_A_fn_class)}; return nil }

var A_arbace_test_eval196000008_fn__196000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000008_fn__196000009_A_invoke, New: A_arbace_test_eval196000008_fn__196000009_A_new, Get: A_arbace_test_eval196000008_fn__196000009_A_get}

var A_arbace_test_eval196000008_fn__196000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000008$fn__196000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_eval196000008_A_class, Simple: "fn__196000009", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000008_fn__196000009_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000008_fn__196000009_A_class.Info(); i.IsInstance = A_arbace_test_eval196000008_fn__196000009_A_InstanceOf; i.Init = A_arbace_test_eval196000008_fn__196000009_A_Init; i.Table = A_arbace_test_eval196000008_fn__196000009_A_members; jrt.RegisterGoType(A_arbace_test_eval196000008_fn__196000009_A_class, reflect.TypeFor[A_arbace_test_eval196000008_fn__196000009_A]()) }

func A_arbace_test_eval196000039_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000039_A_New()}; return nil }

var A_arbace_test_eval196000039_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000039_A_new}

var A_arbace_test_eval196000039_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000039", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000039", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000039_A"})

func init() { i := A_arbace_test_eval196000039_A_class.Info(); i.IsInstance = A_arbace_test_eval196000039_A_InstanceOf; i.Table = A_arbace_test_eval196000039_A_members; jrt.RegisterGoType(A_arbace_test_eval196000039_A_class, reflect.TypeFor[A_arbace_test_eval196000039_A]()) }

func A_arbace_test_eval196000039_fn__196000040_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000039_fn__196000040_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_eval196000039_fn__196000040_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000039_fn__196000040_A_New()}; return nil }

func A_arbace_test_eval196000039_fn__196000040_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000039_fn__196000040_A_fn_class)}; return nil }

var A_arbace_test_eval196000039_fn__196000040_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000039_fn__196000040_A_invoke, New: A_arbace_test_eval196000039_fn__196000040_A_new, Get: A_arbace_test_eval196000039_fn__196000040_A_get}

var A_arbace_test_eval196000039_fn__196000040_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000039$fn__196000040", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_eval196000039_A_class, Simple: "fn__196000040", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000039_fn__196000040_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000039_fn__196000040_A_class.Info(); i.IsInstance = A_arbace_test_eval196000039_fn__196000040_A_InstanceOf; i.Init = A_arbace_test_eval196000039_fn__196000040_A_Init; i.Table = A_arbace_test_eval196000039_fn__196000040_A_members; jrt.RegisterGoType(A_arbace_test_eval196000039_fn__196000040_A_class, reflect.TypeFor[A_arbace_test_eval196000039_fn__196000040_A]()) }

func A_arbace_test_eval196000043_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000043_A_New()}; return nil }

var A_arbace_test_eval196000043_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000043_A_new}

var A_arbace_test_eval196000043_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000043", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000043", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000043_A"})

func init() { i := A_arbace_test_eval196000043_A_class.Info(); i.IsInstance = A_arbace_test_eval196000043_A_InstanceOf; i.Table = A_arbace_test_eval196000043_A_members; jrt.RegisterGoType(A_arbace_test_eval196000043_A_class, reflect.TypeFor[A_arbace_test_eval196000043_A]()) }

func A_arbace_test_eval196000043_fn__196000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000043_fn__196000044_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_eval196000043_fn__196000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000043_fn__196000044_A_New()}; return nil }

func A_arbace_test_eval196000043_fn__196000044_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000043_fn__196000044_A_fn_class)}; return nil }

var A_arbace_test_eval196000043_fn__196000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000043_fn__196000044_A_invoke, New: A_arbace_test_eval196000043_fn__196000044_A_new, Get: A_arbace_test_eval196000043_fn__196000044_A_get}

var A_arbace_test_eval196000043_fn__196000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000043$fn__196000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_eval196000043_A_class, Simple: "fn__196000044", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000043_fn__196000044_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000043_fn__196000044_A_class.Info(); i.IsInstance = A_arbace_test_eval196000043_fn__196000044_A_InstanceOf; i.Init = A_arbace_test_eval196000043_fn__196000044_A_Init; i.Table = A_arbace_test_eval196000043_fn__196000044_A_members; jrt.RegisterGoType(A_arbace_test_eval196000043_fn__196000044_A_class, reflect.TypeFor[A_arbace_test_eval196000043_fn__196000044_A]()) }

func A_arbace_test_eval196000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000047_A_New()}; return nil }

var A_arbace_test_eval196000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000047_A_new}

var A_arbace_test_eval196000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000047", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000047_A"})

func init() { i := A_arbace_test_eval196000047_A_class.Info(); i.IsInstance = A_arbace_test_eval196000047_A_InstanceOf; i.Table = A_arbace_test_eval196000047_A_members; jrt.RegisterGoType(A_arbace_test_eval196000047_A_class, reflect.TypeFor[A_arbace_test_eval196000047_A]()) }

func A_arbace_test_eval196000047_fn__196000048_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000047_fn__196000048_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_eval196000047_fn__196000048_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000047_fn__196000048_A_New()}; return nil }

func A_arbace_test_eval196000047_fn__196000048_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000047_fn__196000048_A_fn_class)}; return nil }

var A_arbace_test_eval196000047_fn__196000048_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000047_fn__196000048_A_invoke, New: A_arbace_test_eval196000047_fn__196000048_A_new, Get: A_arbace_test_eval196000047_fn__196000048_A_get}

var A_arbace_test_eval196000047_fn__196000048_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000047$fn__196000048", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_eval196000047_A_class, Simple: "fn__196000048", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000047_fn__196000048_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000047_fn__196000048_A_class.Info(); i.IsInstance = A_arbace_test_eval196000047_fn__196000048_A_InstanceOf; i.Init = A_arbace_test_eval196000047_fn__196000048_A_Init; i.Table = A_arbace_test_eval196000047_fn__196000048_A_members; jrt.RegisterGoType(A_arbace_test_eval196000047_fn__196000048_A_class, reflect.TypeFor[A_arbace_test_eval196000047_fn__196000048_A]()) }

func A_arbace_test_eval196000051_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000051_A_New()}; return nil }

var A_arbace_test_eval196000051_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000051_A_new}

var A_arbace_test_eval196000051_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000051", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000051", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000051_A"})

func init() { i := A_arbace_test_eval196000051_A_class.Info(); i.IsInstance = A_arbace_test_eval196000051_A_InstanceOf; i.Table = A_arbace_test_eval196000051_A_members; jrt.RegisterGoType(A_arbace_test_eval196000051_A_class, reflect.TypeFor[A_arbace_test_eval196000051_A]()) }

func A_arbace_test_eval196000051_fn__196000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000051_fn__196000052_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_eval196000051_fn__196000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000051_fn__196000052_A_New()}; return nil }

func A_arbace_test_eval196000051_fn__196000052_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000051_fn__196000052_A_fn_class)}; return nil }

var A_arbace_test_eval196000051_fn__196000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000051_fn__196000052_A_invoke, New: A_arbace_test_eval196000051_fn__196000052_A_new, Get: A_arbace_test_eval196000051_fn__196000052_A_get}

var A_arbace_test_eval196000051_fn__196000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000051$fn__196000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_eval196000051_A_class, Simple: "fn__196000052", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000051_fn__196000052_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000051_fn__196000052_A_class.Info(); i.IsInstance = A_arbace_test_eval196000051_fn__196000052_A_InstanceOf; i.Init = A_arbace_test_eval196000051_fn__196000052_A_Init; i.Table = A_arbace_test_eval196000051_fn__196000052_A_members; jrt.RegisterGoType(A_arbace_test_eval196000051_fn__196000052_A_class, reflect.TypeFor[A_arbace_test_eval196000051_fn__196000052_A]()) }

func A_arbace_test_eval196000055_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000055_A_New()}; return nil }

var A_arbace_test_eval196000055_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000055_A_new}

var A_arbace_test_eval196000055_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000055", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000055", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000055_A"})

func init() { i := A_arbace_test_eval196000055_A_class.Info(); i.IsInstance = A_arbace_test_eval196000055_A_InstanceOf; i.Table = A_arbace_test_eval196000055_A_members; jrt.RegisterGoType(A_arbace_test_eval196000055_A_class, reflect.TypeFor[A_arbace_test_eval196000055_A]()) }

func A_arbace_test_eval196000055_fn__196000056_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000055_fn__196000056_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_eval196000055_fn__196000056_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000055_fn__196000056_A_New()}; return nil }

func A_arbace_test_eval196000055_fn__196000056_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000055_fn__196000056_A_fn_class)}; return nil }

var A_arbace_test_eval196000055_fn__196000056_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000055_fn__196000056_A_invoke, New: A_arbace_test_eval196000055_fn__196000056_A_new, Get: A_arbace_test_eval196000055_fn__196000056_A_get}

var A_arbace_test_eval196000055_fn__196000056_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000055$fn__196000056", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_eval196000055_A_class, Simple: "fn__196000056", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000055_fn__196000056_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000055_fn__196000056_A_class.Info(); i.IsInstance = A_arbace_test_eval196000055_fn__196000056_A_InstanceOf; i.Init = A_arbace_test_eval196000055_fn__196000056_A_Init; i.Table = A_arbace_test_eval196000055_fn__196000056_A_members; jrt.RegisterGoType(A_arbace_test_eval196000055_fn__196000056_A_class, reflect.TypeFor[A_arbace_test_eval196000055_fn__196000056_A]()) }

func A_arbace_test_eval196000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000059_A_New()}; return nil }

var A_arbace_test_eval196000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000059_A_new}

var A_arbace_test_eval196000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000059", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000059_A"})

func init() { i := A_arbace_test_eval196000059_A_class.Info(); i.IsInstance = A_arbace_test_eval196000059_A_InstanceOf; i.Table = A_arbace_test_eval196000059_A_members; jrt.RegisterGoType(A_arbace_test_eval196000059_A_class, reflect.TypeFor[A_arbace_test_eval196000059_A]()) }

func A_arbace_test_eval196000059_fn__196000060_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000059_fn__196000060_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_eval196000059_fn__196000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000059_fn__196000060_A_New()}; return nil }

func A_arbace_test_eval196000059_fn__196000060_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000059_fn__196000060_A_fn_class)}; return nil }

var A_arbace_test_eval196000059_fn__196000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000059_fn__196000060_A_invoke, New: A_arbace_test_eval196000059_fn__196000060_A_new, Get: A_arbace_test_eval196000059_fn__196000060_A_get}

var A_arbace_test_eval196000059_fn__196000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000059$fn__196000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_eval196000059_A_class, Simple: "fn__196000060", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000059_fn__196000060_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000059_fn__196000060_A_class.Info(); i.IsInstance = A_arbace_test_eval196000059_fn__196000060_A_InstanceOf; i.Init = A_arbace_test_eval196000059_fn__196000060_A_Init; i.Table = A_arbace_test_eval196000059_fn__196000060_A_members; jrt.RegisterGoType(A_arbace_test_eval196000059_fn__196000060_A_class, reflect.TypeFor[A_arbace_test_eval196000059_fn__196000060_A]()) }

func A_arbace_test_eval196000063_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000063_A_New()}; return nil }

var A_arbace_test_eval196000063_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000063_A_new}

var A_arbace_test_eval196000063_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000063", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000063", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000063_A"})

func init() { i := A_arbace_test_eval196000063_A_class.Info(); i.IsInstance = A_arbace_test_eval196000063_A_InstanceOf; i.Table = A_arbace_test_eval196000063_A_members; jrt.RegisterGoType(A_arbace_test_eval196000063_A_class, reflect.TypeFor[A_arbace_test_eval196000063_A]()) }

func A_arbace_test_eval196000063_fn__196000064_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000063_fn__196000064_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_eval196000063_fn__196000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000063_fn__196000064_A_New()}; return nil }

func A_arbace_test_eval196000063_fn__196000064_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000063_fn__196000064_A_fn_class)}; return nil }

var A_arbace_test_eval196000063_fn__196000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000063_fn__196000064_A_invoke, New: A_arbace_test_eval196000063_fn__196000064_A_new, Get: A_arbace_test_eval196000063_fn__196000064_A_get}

var A_arbace_test_eval196000063_fn__196000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000063$fn__196000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_eval196000063_A_class, Simple: "fn__196000064", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000063_fn__196000064_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000063_fn__196000064_A_class.Info(); i.IsInstance = A_arbace_test_eval196000063_fn__196000064_A_InstanceOf; i.Init = A_arbace_test_eval196000063_fn__196000064_A_Init; i.Table = A_arbace_test_eval196000063_fn__196000064_A_members; jrt.RegisterGoType(A_arbace_test_eval196000063_fn__196000064_A_class, reflect.TypeFor[A_arbace_test_eval196000063_fn__196000064_A]()) }

func A_arbace_test_eval196000067_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000067_A_New()}; return nil }

var A_arbace_test_eval196000067_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000067_A_new}

var A_arbace_test_eval196000067_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000067", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000067", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000067_A"})

func init() { i := A_arbace_test_eval196000067_A_class.Info(); i.IsInstance = A_arbace_test_eval196000067_A_InstanceOf; i.Table = A_arbace_test_eval196000067_A_members; jrt.RegisterGoType(A_arbace_test_eval196000067_A_class, reflect.TypeFor[A_arbace_test_eval196000067_A]()) }

func A_arbace_test_eval196000067_fn__196000068_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000067_fn__196000068_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_eval196000067_fn__196000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000067_fn__196000068_A_New()}; return nil }

func A_arbace_test_eval196000067_fn__196000068_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000067_fn__196000068_A_fn_class)}; return nil }

var A_arbace_test_eval196000067_fn__196000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000067_fn__196000068_A_invoke, New: A_arbace_test_eval196000067_fn__196000068_A_new, Get: A_arbace_test_eval196000067_fn__196000068_A_get}

var A_arbace_test_eval196000067_fn__196000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000067$fn__196000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_eval196000067_A_class, Simple: "fn__196000068", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000067_fn__196000068_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000067_fn__196000068_A_class.Info(); i.IsInstance = A_arbace_test_eval196000067_fn__196000068_A_InstanceOf; i.Init = A_arbace_test_eval196000067_fn__196000068_A_Init; i.Table = A_arbace_test_eval196000067_fn__196000068_A_members; jrt.RegisterGoType(A_arbace_test_eval196000067_fn__196000068_A_class, reflect.TypeFor[A_arbace_test_eval196000067_fn__196000068_A]()) }

func A_arbace_test_eval196000071_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000071_A_New()}; return nil }

var A_arbace_test_eval196000071_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000071_A_new}

var A_arbace_test_eval196000071_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000071", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000071", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000071_A"})

func init() { i := A_arbace_test_eval196000071_A_class.Info(); i.IsInstance = A_arbace_test_eval196000071_A_InstanceOf; i.Table = A_arbace_test_eval196000071_A_members; jrt.RegisterGoType(A_arbace_test_eval196000071_A_class, reflect.TypeFor[A_arbace_test_eval196000071_A]()) }

func A_arbace_test_eval196000071_fn__196000072_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000071_fn__196000072_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_eval196000071_fn__196000072_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000071_fn__196000072_A_New()}; return nil }

func A_arbace_test_eval196000071_fn__196000072_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000071_fn__196000072_A_fn_class)}; return nil }

var A_arbace_test_eval196000071_fn__196000072_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000071_fn__196000072_A_invoke, New: A_arbace_test_eval196000071_fn__196000072_A_new, Get: A_arbace_test_eval196000071_fn__196000072_A_get}

var A_arbace_test_eval196000071_fn__196000072_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000071$fn__196000072", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_eval196000071_A_class, Simple: "fn__196000072", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000071_fn__196000072_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000071_fn__196000072_A_class.Info(); i.IsInstance = A_arbace_test_eval196000071_fn__196000072_A_InstanceOf; i.Init = A_arbace_test_eval196000071_fn__196000072_A_Init; i.Table = A_arbace_test_eval196000071_fn__196000072_A_members; jrt.RegisterGoType(A_arbace_test_eval196000071_fn__196000072_A_class, reflect.TypeFor[A_arbace_test_eval196000071_fn__196000072_A]()) }

func A_arbace_test_eval196000082_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000082_A_New()}; return nil }

var A_arbace_test_eval196000082_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000082_A_new}

var A_arbace_test_eval196000082_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000082", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000082", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000082_A"})

func init() { i := A_arbace_test_eval196000082_A_class.Info(); i.IsInstance = A_arbace_test_eval196000082_A_InstanceOf; i.Table = A_arbace_test_eval196000082_A_members; jrt.RegisterGoType(A_arbace_test_eval196000082_A_class, reflect.TypeFor[A_arbace_test_eval196000082_A]()) }

func A_arbace_test_eval196000082_fn__196000083_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000082_fn__196000083_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_eval196000082_fn__196000083_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000082_fn__196000083_A_New()}; return nil }

func A_arbace_test_eval196000082_fn__196000083_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000082_fn__196000083_A_fn_class)}; return nil }

var A_arbace_test_eval196000082_fn__196000083_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000082_fn__196000083_A_invoke, New: A_arbace_test_eval196000082_fn__196000083_A_new, Get: A_arbace_test_eval196000082_fn__196000083_A_get}

var A_arbace_test_eval196000082_fn__196000083_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000082$fn__196000083", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_test_eval196000082_A_class, Simple: "fn__196000083", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000082_fn__196000083_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000082_fn__196000083_A_class.Info(); i.IsInstance = A_arbace_test_eval196000082_fn__196000083_A_InstanceOf; i.Init = A_arbace_test_eval196000082_fn__196000083_A_Init; i.Table = A_arbace_test_eval196000082_fn__196000083_A_members; jrt.RegisterGoType(A_arbace_test_eval196000082_fn__196000083_A_class, reflect.TypeFor[A_arbace_test_eval196000082_fn__196000083_A]()) }

func A_arbace_test_eval196000086_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000086_A_New()}; return nil }

var A_arbace_test_eval196000086_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000086_A_new}

var A_arbace_test_eval196000086_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000086", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000086", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000086_A"})

func init() { i := A_arbace_test_eval196000086_A_class.Info(); i.IsInstance = A_arbace_test_eval196000086_A_InstanceOf; i.Table = A_arbace_test_eval196000086_A_members; jrt.RegisterGoType(A_arbace_test_eval196000086_A_class, reflect.TypeFor[A_arbace_test_eval196000086_A]()) }

func A_arbace_test_eval196000086_fn__196000087_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000086_fn__196000087_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_eval196000086_fn__196000087_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000086_fn__196000087_A_New()}; return nil }

func A_arbace_test_eval196000086_fn__196000087_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000086_fn__196000087_A_fn_class)}; return nil }

var A_arbace_test_eval196000086_fn__196000087_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000086_fn__196000087_A_invoke, New: A_arbace_test_eval196000086_fn__196000087_A_new, Get: A_arbace_test_eval196000086_fn__196000087_A_get}

var A_arbace_test_eval196000086_fn__196000087_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000086$fn__196000087", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_test_eval196000086_A_class, Simple: "fn__196000087", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000086_fn__196000087_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000086_fn__196000087_A_class.Info(); i.IsInstance = A_arbace_test_eval196000086_fn__196000087_A_InstanceOf; i.Init = A_arbace_test_eval196000086_fn__196000087_A_Init; i.Table = A_arbace_test_eval196000086_fn__196000087_A_members; jrt.RegisterGoType(A_arbace_test_eval196000086_fn__196000087_A_class, reflect.TypeFor[A_arbace_test_eval196000086_fn__196000087_A]()) }

func A_arbace_test_eval196000090_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000090_A_New()}; return nil }

var A_arbace_test_eval196000090_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000090_A_new}

var A_arbace_test_eval196000090_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000090", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000090", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000090_A"})

func init() { i := A_arbace_test_eval196000090_A_class.Info(); i.IsInstance = A_arbace_test_eval196000090_A_InstanceOf; i.Table = A_arbace_test_eval196000090_A_members; jrt.RegisterGoType(A_arbace_test_eval196000090_A_class, reflect.TypeFor[A_arbace_test_eval196000090_A]()) }

func A_arbace_test_eval196000090_fn__196000091_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000090_fn__196000091_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_eval196000090_fn__196000091_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000090_fn__196000091_A_New()}; return nil }

func A_arbace_test_eval196000090_fn__196000091_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000090_fn__196000091_A_fn_class)}; return nil }

var A_arbace_test_eval196000090_fn__196000091_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000090_fn__196000091_A_invoke, New: A_arbace_test_eval196000090_fn__196000091_A_new, Get: A_arbace_test_eval196000090_fn__196000091_A_get}

var A_arbace_test_eval196000090_fn__196000091_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000090$fn__196000091", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_test_eval196000090_A_class, Simple: "fn__196000091", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000090_fn__196000091_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000090_fn__196000091_A_class.Info(); i.IsInstance = A_arbace_test_eval196000090_fn__196000091_A_InstanceOf; i.Init = A_arbace_test_eval196000090_fn__196000091_A_Init; i.Table = A_arbace_test_eval196000090_fn__196000091_A_members; jrt.RegisterGoType(A_arbace_test_eval196000090_fn__196000091_A_class, reflect.TypeFor[A_arbace_test_eval196000090_fn__196000091_A]()) }

func A_arbace_test_eval196000097_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000097_A_New()}; return nil }

var A_arbace_test_eval196000097_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000097_A_new}

var A_arbace_test_eval196000097_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000097", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000097", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000097_A"})

func init() { i := A_arbace_test_eval196000097_A_class.Info(); i.IsInstance = A_arbace_test_eval196000097_A_InstanceOf; i.Table = A_arbace_test_eval196000097_A_members; jrt.RegisterGoType(A_arbace_test_eval196000097_A_class, reflect.TypeFor[A_arbace_test_eval196000097_A]()) }

func A_arbace_test_eval196000097_fn__196000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000097_fn__196000098_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_eval196000097_fn__196000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000097_fn__196000098_A_New()}; return nil }

func A_arbace_test_eval196000097_fn__196000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000097_fn__196000098_A_fn_class)}; return nil }

var A_arbace_test_eval196000097_fn__196000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000097_fn__196000098_A_invoke, New: A_arbace_test_eval196000097_fn__196000098_A_new, Get: A_arbace_test_eval196000097_fn__196000098_A_get}

var A_arbace_test_eval196000097_fn__196000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000097$fn__196000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_test_eval196000097_A_class, Simple: "fn__196000098", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000097_fn__196000098_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000097_fn__196000098_A_class.Info(); i.IsInstance = A_arbace_test_eval196000097_fn__196000098_A_InstanceOf; i.Init = A_arbace_test_eval196000097_fn__196000098_A_Init; i.Table = A_arbace_test_eval196000097_fn__196000098_A_members; jrt.RegisterGoType(A_arbace_test_eval196000097_fn__196000098_A_class, reflect.TypeFor[A_arbace_test_eval196000097_fn__196000098_A]()) }

func A_arbace_test_eval196000102_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000102_A_New()}; return nil }

var A_arbace_test_eval196000102_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000102_A_new}

var A_arbace_test_eval196000102_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000102", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000102", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000102_A"})

func init() { i := A_arbace_test_eval196000102_A_class.Info(); i.IsInstance = A_arbace_test_eval196000102_A_InstanceOf; i.Table = A_arbace_test_eval196000102_A_members; jrt.RegisterGoType(A_arbace_test_eval196000102_A_class, reflect.TypeFor[A_arbace_test_eval196000102_A]()) }

func A_arbace_test_eval196000102_fn__196000103_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000102_fn__196000103_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_eval196000102_fn__196000103_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000102_fn__196000103_A_New()}; return nil }

func A_arbace_test_eval196000102_fn__196000103_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000102_fn__196000103_A_fn_class)}; return nil }

var A_arbace_test_eval196000102_fn__196000103_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000102_fn__196000103_A_invoke, New: A_arbace_test_eval196000102_fn__196000103_A_new, Get: A_arbace_test_eval196000102_fn__196000103_A_get}

var A_arbace_test_eval196000102_fn__196000103_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000102$fn__196000103", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_test_eval196000102_A_class, Simple: "fn__196000103", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000102_fn__196000103_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000102_fn__196000103_A_class.Info(); i.IsInstance = A_arbace_test_eval196000102_fn__196000103_A_InstanceOf; i.Init = A_arbace_test_eval196000102_fn__196000103_A_Init; i.Table = A_arbace_test_eval196000102_fn__196000103_A_members; jrt.RegisterGoType(A_arbace_test_eval196000102_fn__196000103_A_class, reflect.TypeFor[A_arbace_test_eval196000102_fn__196000103_A]()) }

func A_arbace_test_eval196000108_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000108_A_New()}; return nil }

var A_arbace_test_eval196000108_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000108_A_new}

var A_arbace_test_eval196000108_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000108", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000108", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000108_A"})

func init() { i := A_arbace_test_eval196000108_A_class.Info(); i.IsInstance = A_arbace_test_eval196000108_A_InstanceOf; i.Table = A_arbace_test_eval196000108_A_members; jrt.RegisterGoType(A_arbace_test_eval196000108_A_class, reflect.TypeFor[A_arbace_test_eval196000108_A]()) }

func A_arbace_test_eval196000108_fn__196000109_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000108_fn__196000109_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_eval196000108_fn__196000109_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000108_fn__196000109_A_New()}; return nil }

func A_arbace_test_eval196000108_fn__196000109_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000108_fn__196000109_A_fn_class)}; return nil }

var A_arbace_test_eval196000108_fn__196000109_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000108_fn__196000109_A_invoke, New: A_arbace_test_eval196000108_fn__196000109_A_new, Get: A_arbace_test_eval196000108_fn__196000109_A_get}

var A_arbace_test_eval196000108_fn__196000109_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000108$fn__196000109", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_test_eval196000108_A_class, Simple: "fn__196000109", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000108_fn__196000109_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000108_fn__196000109_A_class.Info(); i.IsInstance = A_arbace_test_eval196000108_fn__196000109_A_InstanceOf; i.Init = A_arbace_test_eval196000108_fn__196000109_A_Init; i.Table = A_arbace_test_eval196000108_fn__196000109_A_members; jrt.RegisterGoType(A_arbace_test_eval196000108_fn__196000109_A_class, reflect.TypeFor[A_arbace_test_eval196000108_fn__196000109_A]()) }

func A_arbace_test_eval196000154_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000154_A_New()}; return nil }

var A_arbace_test_eval196000154_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000154_A_new}

var A_arbace_test_eval196000154_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000154", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000154", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000154_A"})

func init() { i := A_arbace_test_eval196000154_A_class.Info(); i.IsInstance = A_arbace_test_eval196000154_A_InstanceOf; i.Table = A_arbace_test_eval196000154_A_members; jrt.RegisterGoType(A_arbace_test_eval196000154_A_class, reflect.TypeFor[A_arbace_test_eval196000154_A]()) }

func A_arbace_test_eval196000154_fn__196000155_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000154_fn__196000155_A).DoInvoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_eval196000154_fn__196000155_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000154_fn__196000155_A_New()}; return nil }

func A_arbace_test_eval196000154_fn__196000155_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000154_fn__196000155_A_fn_class)}; return nil }

var A_arbace_test_eval196000154_fn__196000155_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000154_fn__196000155_A_invoke, New: A_arbace_test_eval196000154_fn__196000155_A_new, Get: A_arbace_test_eval196000154_fn__196000155_A_get}

var A_arbace_test_eval196000154_fn__196000155_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000154$fn__196000155", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR1_class}, Declaring: A_arbace_test_eval196000154_A_class, Simple: "fn__196000155", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000154_fn__196000155_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000154_fn__196000155_A_class.Info(); i.IsInstance = A_arbace_test_eval196000154_fn__196000155_A_InstanceOf; i.Init = A_arbace_test_eval196000154_fn__196000155_A_Init; i.Table = A_arbace_test_eval196000154_fn__196000155_A_members; jrt.RegisterGoType(A_arbace_test_eval196000154_fn__196000155_A_class, reflect.TypeFor[A_arbace_test_eval196000154_fn__196000155_A]()) }

func A_arbace_test_eval196000158_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000158_A_New()}; return nil }

var A_arbace_test_eval196000158_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000158_A_new}

var A_arbace_test_eval196000158_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000158", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000158", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000158_A"})

func init() { i := A_arbace_test_eval196000158_A_class.Info(); i.IsInstance = A_arbace_test_eval196000158_A_InstanceOf; i.Table = A_arbace_test_eval196000158_A_members; jrt.RegisterGoType(A_arbace_test_eval196000158_A_class, reflect.TypeFor[A_arbace_test_eval196000158_A]()) }

func A_arbace_test_eval196000158_fn__196000159_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000158_fn__196000159_A).DoInvoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_eval196000158_fn__196000159_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000158_fn__196000159_A_New()}; return nil }

func A_arbace_test_eval196000158_fn__196000159_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000158_fn__196000159_A_fn_class)}; return nil }

var A_arbace_test_eval196000158_fn__196000159_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000158_fn__196000159_A_invoke, New: A_arbace_test_eval196000158_fn__196000159_A_new, Get: A_arbace_test_eval196000158_fn__196000159_A_get}

var A_arbace_test_eval196000158_fn__196000159_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000158$fn__196000159", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR1_class}, Declaring: A_arbace_test_eval196000158_A_class, Simple: "fn__196000159", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000158_fn__196000159_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000158_fn__196000159_A_class.Info(); i.IsInstance = A_arbace_test_eval196000158_fn__196000159_A_InstanceOf; i.Init = A_arbace_test_eval196000158_fn__196000159_A_Init; i.Table = A_arbace_test_eval196000158_fn__196000159_A_members; jrt.RegisterGoType(A_arbace_test_eval196000158_fn__196000159_A_class, reflect.TypeFor[A_arbace_test_eval196000158_fn__196000159_A]()) }

func A_arbace_test_eval196000162_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000162_A_New()}; return nil }

var A_arbace_test_eval196000162_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000162_A_new}

var A_arbace_test_eval196000162_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000162", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000162", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000162_A"})

func init() { i := A_arbace_test_eval196000162_A_class.Info(); i.IsInstance = A_arbace_test_eval196000162_A_InstanceOf; i.Table = A_arbace_test_eval196000162_A_members; jrt.RegisterGoType(A_arbace_test_eval196000162_A_class, reflect.TypeFor[A_arbace_test_eval196000162_A]()) }

func A_arbace_test_eval196000162_fn__196000163_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_eval196000162_fn__196000163_A).DoInvoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_eval196000162_fn__196000163_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000162_fn__196000163_A_New()}; return nil }

func A_arbace_test_eval196000162_fn__196000163_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_eval196000162_fn__196000163_A_fn_class)}; return nil }

var A_arbace_test_eval196000162_fn__196000163_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_eval196000162_fn__196000163_A_invoke, New: A_arbace_test_eval196000162_fn__196000163_A_new, Get: A_arbace_test_eval196000162_fn__196000163_A_get}

var A_arbace_test_eval196000162_fn__196000163_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000162$fn__196000163", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR1_class}, Declaring: A_arbace_test_eval196000162_A_class, Simple: "fn__196000163", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000162_fn__196000163_A", Source: "test.ae"})

func init() { i := A_arbace_test_eval196000162_fn__196000163_A_class.Info(); i.IsInstance = A_arbace_test_eval196000162_fn__196000163_A_InstanceOf; i.Init = A_arbace_test_eval196000162_fn__196000163_A_Init; i.Table = A_arbace_test_eval196000162_fn__196000163_A_members; jrt.RegisterGoType(A_arbace_test_eval196000162_fn__196000163_A_class, reflect.TypeFor[A_arbace_test_eval196000162_fn__196000163_A]()) }

func A_arbace_test_file_and_line_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_file_and_line_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_file_and_line_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_file_and_line_A_New()}; return nil }

func A_arbace_test_file_and_line_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_file_and_line_A_fn_class)}; return nil }

var A_arbace_test_file_and_line_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_file_and_line_A_invoke, New: A_arbace_test_file_and_line_A_new, Get: A_arbace_test_file_and_line_A_get}

var A_arbace_test_file_and_line_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$file_and_line", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_test_A_class, Simple: "file_and_line", Go: "arbace/aot_arbace_test.A_arbace_test_file_and_line_A", Source: "test.ae"})

func init() { i := A_arbace_test_file_and_line_A_class.Info(); i.IsInstance = A_arbace_test_file_and_line_A_InstanceOf; i.Init = A_arbace_test_file_and_line_A_Init; i.Table = A_arbace_test_file_and_line_A_members; jrt.RegisterGoType(A_arbace_test_file_and_line_A_class, reflect.TypeFor[A_arbace_test_file_and_line_A]()) }

func A_arbace_test_file_position_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_file_position_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_file_position_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_file_position_A_New()}; return nil }

func A_arbace_test_file_position_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_file_position_A_fn_class)}; return nil }

var A_arbace_test_file_position_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_file_position_A_invoke, New: A_arbace_test_file_position_A_new, Get: A_arbace_test_file_position_A_get}

var A_arbace_test_file_position_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$file_position", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_A_class, Simple: "file_position", Go: "arbace/aot_arbace_test.A_arbace_test_file_position_A", Source: "test.ae"})

func init() { i := A_arbace_test_file_position_A_class.Info(); i.IsInstance = A_arbace_test_file_position_A_InstanceOf; i.Init = A_arbace_test_file_position_A_Init; i.Table = A_arbace_test_file_position_A_members; jrt.RegisterGoType(A_arbace_test_file_position_A_class, reflect.TypeFor[A_arbace_test_file_position_A]()) }

func A_arbace_test_function_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_function_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_function_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_function_QMARK__A_New()}; return nil }

func A_arbace_test_function_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_function_QMARK__A_fn_class)}; return nil }

var A_arbace_test_function_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_function_QMARK__A_invoke, New: A_arbace_test_function_QMARK__A_new, Get: A_arbace_test_function_QMARK__A_get}

var A_arbace_test_function_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$function_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_A_class, Simple: "function_QMARK_", Go: "arbace/aot_arbace_test.A_arbace_test_function_QMARK__A", Source: "test.ae"})

func init() { i := A_arbace_test_function_QMARK__A_class.Info(); i.IsInstance = A_arbace_test_function_QMARK__A_InstanceOf; i.Init = A_arbace_test_function_QMARK__A_Init; i.Table = A_arbace_test_function_QMARK__A_members; jrt.RegisterGoType(A_arbace_test_function_QMARK__A_class, reflect.TypeFor[A_arbace_test_function_QMARK__A]()) }

func A_arbace_test_get_possibly_unbound_var_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_get_possibly_unbound_var_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_get_possibly_unbound_var_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_get_possibly_unbound_var_A_New()}; return nil }

func A_arbace_test_get_possibly_unbound_var_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_get_possibly_unbound_var_A_fn_class)}; return nil }

var A_arbace_test_get_possibly_unbound_var_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_get_possibly_unbound_var_A_invoke, New: A_arbace_test_get_possibly_unbound_var_A_new, Get: A_arbace_test_get_possibly_unbound_var_A_get}

var A_arbace_test_get_possibly_unbound_var_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$get_possibly_unbound_var", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_A_class, Simple: "get_possibly_unbound_var", Go: "arbace/aot_arbace_test.A_arbace_test_get_possibly_unbound_var_A", Source: "test.ae"})

func init() { i := A_arbace_test_get_possibly_unbound_var_A_class.Info(); i.IsInstance = A_arbace_test_get_possibly_unbound_var_A_InstanceOf; i.Init = A_arbace_test_get_possibly_unbound_var_A_Init; i.Table = A_arbace_test_get_possibly_unbound_var_A_members; jrt.RegisterGoType(A_arbace_test_get_possibly_unbound_var_A_class, reflect.TypeFor[A_arbace_test_get_possibly_unbound_var_A]()) }

func A_arbace_test_inc_report_counter_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_inc_report_counter_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_inc_report_counter_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_inc_report_counter_A_New()}; return nil }

func A_arbace_test_inc_report_counter_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_inc_report_counter_A_fn_class)}; return nil }

var A_arbace_test_inc_report_counter_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_inc_report_counter_A_invoke, New: A_arbace_test_inc_report_counter_A_new, Get: A_arbace_test_inc_report_counter_A_get}

var A_arbace_test_inc_report_counter_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$inc_report_counter", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_A_class, Simple: "inc_report_counter", Go: "arbace/aot_arbace_test.A_arbace_test_inc_report_counter_A", Source: "test.ae"})

func init() { i := A_arbace_test_inc_report_counter_A_class.Info(); i.IsInstance = A_arbace_test_inc_report_counter_A_InstanceOf; i.Init = A_arbace_test_inc_report_counter_A_Init; i.Table = A_arbace_test_inc_report_counter_A_members; jrt.RegisterGoType(A_arbace_test_inc_report_counter_A_class, reflect.TypeFor[A_arbace_test_inc_report_counter_A]()) }

func A_arbace_test_inc_report_counter_fn__196000027_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_inc_report_counter_fn__196000027_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_inc_report_counter_fn__196000027_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_inc_report_counter_fn__196000027_A_New_O(args[0])}; return nil }

func A_arbace_test_inc_report_counter_fn__196000027_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_inc_report_counter_fn__196000027_A_fn_class)}; return nil }

var A_arbace_test_inc_report_counter_fn__196000027_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_inc_report_counter_fn__196000027_A_invoke, New: A_arbace_test_inc_report_counter_fn__196000027_A_new, Get: A_arbace_test_inc_report_counter_fn__196000027_A_get}

var A_arbace_test_inc_report_counter_fn__196000027_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$inc_report_counter$fn__196000027", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_inc_report_counter_A_class, Simple: "fn__196000027", Go: "arbace/aot_arbace_test.A_arbace_test_inc_report_counter_fn__196000027_A", Source: "test.ae"})

func init() { i := A_arbace_test_inc_report_counter_fn__196000027_A_class.Info(); i.IsInstance = A_arbace_test_inc_report_counter_fn__196000027_A_InstanceOf; i.Init = A_arbace_test_inc_report_counter_fn__196000027_A_Init; i.Table = A_arbace_test_inc_report_counter_fn__196000027_A_members; jrt.RegisterGoType(A_arbace_test_inc_report_counter_fn__196000027_A_class, reflect.TypeFor[A_arbace_test_inc_report_counter_fn__196000027_A]()) }

func A_arbace_test_is_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_is_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3]); case 1: return this.(*A_arbace_test_is_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_test_is_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_is_A_New()}; return nil }

func A_arbace_test_is_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_is_A_fn_class)}; return nil }

var A_arbace_test_is_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_is_A_invoke, New: A_arbace_test_is_A_new, Get: A_arbace_test_is_A_get}

var A_arbace_test_is_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$is", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class, lang.Compiler_AOTF3_class}, Declaring: A_arbace_test_A_class, Simple: "is", Go: "arbace/aot_arbace_test.A_arbace_test_is_A", Source: "test.ae"})

func init() { i := A_arbace_test_is_A_class.Info(); i.IsInstance = A_arbace_test_is_A_InstanceOf; i.Init = A_arbace_test_is_A_Init; i.Table = A_arbace_test_is_A_members; jrt.RegisterGoType(A_arbace_test_is_A_class, reflect.TypeFor[A_arbace_test_is_A]()) }

func A_arbace_test_join_fixtures_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_join_fixtures_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_join_fixtures_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_join_fixtures_A_New()}; return nil }

func A_arbace_test_join_fixtures_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_join_fixtures_A_fn_class)}; return nil }

var A_arbace_test_join_fixtures_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_join_fixtures_A_invoke, New: A_arbace_test_join_fixtures_A_new, Get: A_arbace_test_join_fixtures_A_get}

var A_arbace_test_join_fixtures_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$join_fixtures", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_A_class, Simple: "join_fixtures", Go: "arbace/aot_arbace_test.A_arbace_test_join_fixtures_A", Source: "test.ae"})

func init() { i := A_arbace_test_join_fixtures_A_class.Info(); i.IsInstance = A_arbace_test_join_fixtures_A_InstanceOf; i.Init = A_arbace_test_join_fixtures_A_Init; i.Table = A_arbace_test_join_fixtures_A_members; jrt.RegisterGoType(A_arbace_test_join_fixtures_A_class, reflect.TypeFor[A_arbace_test_join_fixtures_A]()) }

func A_arbace_test_run_all_tests_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_run_all_tests_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_test_run_all_tests_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_run_all_tests_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_run_all_tests_A_New()}; return nil }

func A_arbace_test_run_all_tests_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_run_all_tests_A_fn_class)}; return nil }

var A_arbace_test_run_all_tests_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_run_all_tests_A_invoke, New: A_arbace_test_run_all_tests_A_new, Get: A_arbace_test_run_all_tests_A_get}

var A_arbace_test_run_all_tests_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$run_all_tests", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_A_class, Simple: "run_all_tests", Go: "arbace/aot_arbace_test.A_arbace_test_run_all_tests_A", Source: "test.ae"})

func init() { i := A_arbace_test_run_all_tests_A_class.Info(); i.IsInstance = A_arbace_test_run_all_tests_A_InstanceOf; i.Init = A_arbace_test_run_all_tests_A_Init; i.Table = A_arbace_test_run_all_tests_A_members; jrt.RegisterGoType(A_arbace_test_run_all_tests_A_class, reflect.TypeFor[A_arbace_test_run_all_tests_A]()) }

func A_arbace_test_run_all_tests_fn__196000211_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_run_all_tests_fn__196000211_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_run_all_tests_fn__196000211_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_run_all_tests_fn__196000211_A_New_O(args[0])}; return nil }

func A_arbace_test_run_all_tests_fn__196000211_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_run_all_tests_fn__196000211_A_fn_class)}; return nil }

var A_arbace_test_run_all_tests_fn__196000211_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_run_all_tests_fn__196000211_A_invoke, New: A_arbace_test_run_all_tests_fn__196000211_A_new, Get: A_arbace_test_run_all_tests_fn__196000211_A_get}

var A_arbace_test_run_all_tests_fn__196000211_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$run_all_tests$fn__196000211", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_run_all_tests_A_class, Simple: "fn__196000211", Go: "arbace/aot_arbace_test.A_arbace_test_run_all_tests_fn__196000211_A", Source: "test.ae"})

func init() { i := A_arbace_test_run_all_tests_fn__196000211_A_class.Info(); i.IsInstance = A_arbace_test_run_all_tests_fn__196000211_A_InstanceOf; i.Init = A_arbace_test_run_all_tests_fn__196000211_A_Init; i.Table = A_arbace_test_run_all_tests_fn__196000211_A_members; jrt.RegisterGoType(A_arbace_test_run_all_tests_fn__196000211_A_class, reflect.TypeFor[A_arbace_test_run_all_tests_fn__196000211_A]()) }

func A_arbace_test_run_test_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_run_test_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_test_run_test_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_run_test_A_New()}; return nil }

func A_arbace_test_run_test_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_run_test_A_fn_class)}; return nil }

var A_arbace_test_run_test_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_run_test_A_invoke, New: A_arbace_test_run_test_A_new, Get: A_arbace_test_run_test_A_get}

var A_arbace_test_run_test_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$run_test", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_test_A_class, Simple: "run_test", Go: "arbace/aot_arbace_test.A_arbace_test_run_test_A", Source: "test.ae"})

func init() { i := A_arbace_test_run_test_A_class.Info(); i.IsInstance = A_arbace_test_run_test_A_InstanceOf; i.Init = A_arbace_test_run_test_A_Init; i.Table = A_arbace_test_run_test_A_members; jrt.RegisterGoType(A_arbace_test_run_test_A_class, reflect.TypeFor[A_arbace_test_run_test_A]()) }

func A_arbace_test_run_test_var_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_run_test_var_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_run_test_var_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_run_test_var_A_New()}; return nil }

func A_arbace_test_run_test_var_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_run_test_var_A_fn_class)}; return nil }

var A_arbace_test_run_test_var_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_run_test_var_A_invoke, New: A_arbace_test_run_test_var_A_new, Get: A_arbace_test_run_test_var_A_get}

var A_arbace_test_run_test_var_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$run_test_var", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_A_class, Simple: "run_test_var", Go: "arbace/aot_arbace_test.A_arbace_test_run_test_var_A", Source: "test.ae"})

func init() { i := A_arbace_test_run_test_var_A_class.Info(); i.IsInstance = A_arbace_test_run_test_var_A_InstanceOf; i.Init = A_arbace_test_run_test_var_A_Init; i.Table = A_arbace_test_run_test_var_A_members; jrt.RegisterGoType(A_arbace_test_run_test_var_A_class, reflect.TypeFor[A_arbace_test_run_test_var_A]()) }

func A_arbace_test_run_tests_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_run_tests_A).DoInvoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_test_run_tests_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_run_tests_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_run_tests_A_New()}; return nil }

func A_arbace_test_run_tests_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_run_tests_A_fn_class)}; return nil }

var A_arbace_test_run_tests_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_run_tests_A_invoke, New: A_arbace_test_run_tests_A_new, Get: A_arbace_test_run_tests_A_get}

var A_arbace_test_run_tests_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$run_tests", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_A_class, Simple: "run_tests", Go: "arbace/aot_arbace_test.A_arbace_test_run_tests_A", Source: "test.ae"})

func init() { i := A_arbace_test_run_tests_A_class.Info(); i.IsInstance = A_arbace_test_run_tests_A_InstanceOf; i.Init = A_arbace_test_run_tests_A_Init; i.Table = A_arbace_test_run_tests_A_members; jrt.RegisterGoType(A_arbace_test_run_tests_A_class, reflect.TypeFor[A_arbace_test_run_tests_A]()) }

func A_arbace_test_set_test_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_set_test_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_test_set_test_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_set_test_A_New()}; return nil }

func A_arbace_test_set_test_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_set_test_A_fn_class)}; return nil }

var A_arbace_test_set_test_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_set_test_A_invoke, New: A_arbace_test_set_test_A_new, Get: A_arbace_test_set_test_A_get}

var A_arbace_test_set_test_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$set_test", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_test_A_class, Simple: "set_test", Go: "arbace/aot_arbace_test.A_arbace_test_set_test_A", Source: "test.ae"})

func init() { i := A_arbace_test_set_test_A_class.Info(); i.IsInstance = A_arbace_test_set_test_A_InstanceOf; i.Init = A_arbace_test_set_test_A_Init; i.Table = A_arbace_test_set_test_A_members; jrt.RegisterGoType(A_arbace_test_set_test_A_class, reflect.TypeFor[A_arbace_test_set_test_A]()) }

func A_arbace_test_stacktrace_file_and_line_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_stacktrace_file_and_line_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_stacktrace_file_and_line_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_stacktrace_file_and_line_A_New()}; return nil }

func A_arbace_test_stacktrace_file_and_line_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_stacktrace_file_and_line_A_fn_class)}; return nil }

var A_arbace_test_stacktrace_file_and_line_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_stacktrace_file_and_line_A_invoke, New: A_arbace_test_stacktrace_file_and_line_A_new, Get: A_arbace_test_stacktrace_file_and_line_A_get}

var A_arbace_test_stacktrace_file_and_line_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$stacktrace_file_and_line", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_A_class, Simple: "stacktrace_file_and_line", Go: "arbace/aot_arbace_test.A_arbace_test_stacktrace_file_and_line_A", Source: "test.ae"})

func init() { i := A_arbace_test_stacktrace_file_and_line_A_class.Info(); i.IsInstance = A_arbace_test_stacktrace_file_and_line_A_InstanceOf; i.Init = A_arbace_test_stacktrace_file_and_line_A_Init; i.Table = A_arbace_test_stacktrace_file_and_line_A_members; jrt.RegisterGoType(A_arbace_test_stacktrace_file_and_line_A_class, reflect.TypeFor[A_arbace_test_stacktrace_file_and_line_A]()) }

func A_arbace_test_successful_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_successful_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_successful_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_successful_QMARK__A_New()}; return nil }

func A_arbace_test_successful_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_successful_QMARK__A_fn_class)}; return nil }

var A_arbace_test_successful_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_successful_QMARK__A_invoke, New: A_arbace_test_successful_QMARK__A_new, Get: A_arbace_test_successful_QMARK__A_get}

var A_arbace_test_successful_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$successful_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_A_class, Simple: "successful_QMARK_", Go: "arbace/aot_arbace_test.A_arbace_test_successful_QMARK__A", Source: "test.ae"})

func init() { i := A_arbace_test_successful_QMARK__A_class.Info(); i.IsInstance = A_arbace_test_successful_QMARK__A_InstanceOf; i.Init = A_arbace_test_successful_QMARK__A_Init; i.Table = A_arbace_test_successful_QMARK__A_members; jrt.RegisterGoType(A_arbace_test_successful_QMARK__A_class, reflect.TypeFor[A_arbace_test_successful_QMARK__A]()) }

func A_arbace_test_test_all_vars_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_test_all_vars_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_test_all_vars_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_test_all_vars_A_New()}; return nil }

func A_arbace_test_test_all_vars_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_test_all_vars_A_fn_class)}; return nil }

var A_arbace_test_test_all_vars_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_test_all_vars_A_invoke, New: A_arbace_test_test_all_vars_A_new, Get: A_arbace_test_test_all_vars_A_get}

var A_arbace_test_test_all_vars_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$test_all_vars", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_A_class, Simple: "test_all_vars", Go: "arbace/aot_arbace_test.A_arbace_test_test_all_vars_A", Source: "test.ae"})

func init() { i := A_arbace_test_test_all_vars_A_class.Info(); i.IsInstance = A_arbace_test_test_all_vars_A_InstanceOf; i.Init = A_arbace_test_test_all_vars_A_Init; i.Table = A_arbace_test_test_all_vars_A_members; jrt.RegisterGoType(A_arbace_test_test_all_vars_A_class, reflect.TypeFor[A_arbace_test_test_all_vars_A]()) }

func A_arbace_test_test_ns_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_test_ns_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_test_ns_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_test_ns_A_New()}; return nil }

func A_arbace_test_test_ns_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_test_ns_A_fn_class)}; return nil }

var A_arbace_test_test_ns_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_test_ns_A_invoke, New: A_arbace_test_test_ns_A_new, Get: A_arbace_test_test_ns_A_get}

var A_arbace_test_test_ns_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$test_ns", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_A_class, Simple: "test_ns", Go: "arbace/aot_arbace_test.A_arbace_test_test_ns_A", Source: "test.ae"})

func init() { i := A_arbace_test_test_ns_A_class.Info(); i.IsInstance = A_arbace_test_test_ns_A_InstanceOf; i.Init = A_arbace_test_test_ns_A_Init; i.Table = A_arbace_test_test_ns_A_members; jrt.RegisterGoType(A_arbace_test_test_ns_A_class, reflect.TypeFor[A_arbace_test_test_ns_A]()) }

func A_arbace_test_test_var_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_test_var_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_test_var_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_test_var_A_New()}; return nil }

func A_arbace_test_test_var_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_test_var_A_fn_class)}; return nil }

var A_arbace_test_test_var_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_test_var_A_invoke, New: A_arbace_test_test_var_A_new, Get: A_arbace_test_test_var_A_get}

var A_arbace_test_test_var_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$test_var", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_A_class, Simple: "test_var", Go: "arbace/aot_arbace_test.A_arbace_test_test_var_A", Source: "test.ae"})

func init() { i := A_arbace_test_test_var_A_class.Info(); i.IsInstance = A_arbace_test_test_var_A_InstanceOf; i.Init = A_arbace_test_test_var_A_Init; i.Table = A_arbace_test_test_var_A_members; jrt.RegisterGoType(A_arbace_test_test_var_A_class, reflect.TypeFor[A_arbace_test_test_var_A]()) }

func A_arbace_test_test_var_fn__196000173_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_test_var_fn__196000173_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_test_var_fn__196000173_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_test_var_fn__196000173_A_New_O(args[0])}; return nil }

func A_arbace_test_test_var_fn__196000173_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_test_var_fn__196000173_A_fn_class)}; return nil }

var A_arbace_test_test_var_fn__196000173_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_test_var_fn__196000173_A_invoke, New: A_arbace_test_test_var_fn__196000173_A_new, Get: A_arbace_test_test_var_fn__196000173_A_get}

var A_arbace_test_test_var_fn__196000173_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$test_var$fn__196000173", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_test_var_A_class, Simple: "fn__196000173", Go: "arbace/aot_arbace_test.A_arbace_test_test_var_fn__196000173_A", Source: "test.ae"})

func init() { i := A_arbace_test_test_var_fn__196000173_A_class.Info(); i.IsInstance = A_arbace_test_test_var_fn__196000173_A_InstanceOf; i.Init = A_arbace_test_test_var_fn__196000173_A_Init; i.Table = A_arbace_test_test_var_fn__196000173_A_members; jrt.RegisterGoType(A_arbace_test_test_var_fn__196000173_A_class, reflect.TypeFor[A_arbace_test_test_var_fn__196000173_A]()) }

func A_arbace_test_test_vars_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_test_vars_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_test_vars_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_test_vars_A_New()}; return nil }

func A_arbace_test_test_vars_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_test_vars_A_fn_class)}; return nil }

var A_arbace_test_test_vars_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_test_vars_A_invoke, New: A_arbace_test_test_vars_A_new, Get: A_arbace_test_test_vars_A_get}

var A_arbace_test_test_vars_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$test_vars", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_A_class, Simple: "test_vars", Go: "arbace/aot_arbace_test.A_arbace_test_test_vars_A", Source: "test.ae"})

func init() { i := A_arbace_test_test_vars_A_class.Info(); i.IsInstance = A_arbace_test_test_vars_A_InstanceOf; i.Init = A_arbace_test_test_vars_A_Init; i.Table = A_arbace_test_test_vars_A_members; jrt.RegisterGoType(A_arbace_test_test_vars_A_class, reflect.TypeFor[A_arbace_test_test_vars_A]()) }

func A_arbace_test_test_vars_fn__196000183_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_test_vars_fn__196000183_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_test_vars_fn__196000183_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_test_vars_fn__196000183_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_test_test_vars_fn__196000183_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_test_vars_fn__196000183_A_fn_class)}; return nil }

var A_arbace_test_test_vars_fn__196000183_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_test_vars_fn__196000183_A_invoke, New: A_arbace_test_test_vars_fn__196000183_A_new, Get: A_arbace_test_test_vars_fn__196000183_A_get}

var A_arbace_test_test_vars_fn__196000183_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$test_vars$fn__196000183", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_test_vars_A_class, Simple: "fn__196000183", Go: "arbace/aot_arbace_test.A_arbace_test_test_vars_fn__196000183_A", Source: "test.ae"})

func init() { i := A_arbace_test_test_vars_fn__196000183_A_class.Info(); i.IsInstance = A_arbace_test_test_vars_fn__196000183_A_InstanceOf; i.Init = A_arbace_test_test_vars_fn__196000183_A_Init; i.Table = A_arbace_test_test_vars_fn__196000183_A_members; jrt.RegisterGoType(A_arbace_test_test_vars_fn__196000183_A_class, reflect.TypeFor[A_arbace_test_test_vars_fn__196000183_A]()) }

func A_arbace_test_test_vars_fn__196000183_fn__196000188_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_test_vars_fn__196000183_fn__196000188_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_test_vars_fn__196000183_fn__196000188_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_test_vars_fn__196000183_fn__196000188_A_New_O(args[0])}; return nil }

func A_arbace_test_test_vars_fn__196000183_fn__196000188_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_test_vars_fn__196000183_fn__196000188_A_fn_class)}; return nil }

var A_arbace_test_test_vars_fn__196000183_fn__196000188_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_test_vars_fn__196000183_fn__196000188_A_invoke, New: A_arbace_test_test_vars_fn__196000183_fn__196000188_A_new, Get: A_arbace_test_test_vars_fn__196000183_fn__196000188_A_get}

var A_arbace_test_test_vars_fn__196000183_fn__196000188_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$test_vars$fn__196000183$fn__196000188", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_test_vars_fn__196000183_A_class, Simple: "fn__196000188", Go: "arbace/aot_arbace_test.A_arbace_test_test_vars_fn__196000183_fn__196000188_A", Source: "test.ae"})

func init() { i := A_arbace_test_test_vars_fn__196000183_fn__196000188_A_class.Info(); i.IsInstance = A_arbace_test_test_vars_fn__196000183_fn__196000188_A_InstanceOf; i.Init = A_arbace_test_test_vars_fn__196000183_fn__196000188_A_Init; i.Table = A_arbace_test_test_vars_fn__196000183_fn__196000188_A_members; jrt.RegisterGoType(A_arbace_test_test_vars_fn__196000183_fn__196000188_A_class, reflect.TypeFor[A_arbace_test_test_vars_fn__196000183_fn__196000188_A]()) }

func A_arbace_test_test_vars_fn__196000183_fn__196000190_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_test_vars_fn__196000183_fn__196000190_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_test_vars_fn__196000183_fn__196000190_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_test_vars_fn__196000183_fn__196000190_A_New_O(args[0])}; return nil }

func A_arbace_test_test_vars_fn__196000183_fn__196000190_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_test_vars_fn__196000183_fn__196000190_A_fn_class)}; return nil }

var A_arbace_test_test_vars_fn__196000183_fn__196000190_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_test_vars_fn__196000183_fn__196000190_A_invoke, New: A_arbace_test_test_vars_fn__196000183_fn__196000190_A_new, Get: A_arbace_test_test_vars_fn__196000183_fn__196000190_A_get}

var A_arbace_test_test_vars_fn__196000183_fn__196000190_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$test_vars$fn__196000183$fn__196000190", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_test_vars_fn__196000183_A_class, Simple: "fn__196000190", Go: "arbace/aot_arbace_test.A_arbace_test_test_vars_fn__196000183_fn__196000190_A", Source: "test.ae"})

func init() { i := A_arbace_test_test_vars_fn__196000183_fn__196000190_A_class.Info(); i.IsInstance = A_arbace_test_test_vars_fn__196000183_fn__196000190_A_InstanceOf; i.Init = A_arbace_test_test_vars_fn__196000183_fn__196000190_A_Init; i.Table = A_arbace_test_test_vars_fn__196000183_fn__196000190_A_members; jrt.RegisterGoType(A_arbace_test_test_vars_fn__196000183_fn__196000190_A_class, reflect.TypeFor[A_arbace_test_test_vars_fn__196000183_fn__196000190_A]()) }

func A_arbace_test_test_vars_fn__196000196_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_test_vars_fn__196000196_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_test_vars_fn__196000196_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_test_vars_fn__196000196_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_test_test_vars_fn__196000196_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_test_vars_fn__196000196_A_fn_class)}; return nil }

var A_arbace_test_test_vars_fn__196000196_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_test_vars_fn__196000196_A_invoke, New: A_arbace_test_test_vars_fn__196000196_A_new, Get: A_arbace_test_test_vars_fn__196000196_A_get}

var A_arbace_test_test_vars_fn__196000196_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$test_vars$fn__196000196", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_test_vars_A_class, Simple: "fn__196000196", Go: "arbace/aot_arbace_test.A_arbace_test_test_vars_fn__196000196_A", Source: "test.ae"})

func init() { i := A_arbace_test_test_vars_fn__196000196_A_class.Info(); i.IsInstance = A_arbace_test_test_vars_fn__196000196_A_InstanceOf; i.Init = A_arbace_test_test_vars_fn__196000196_A_Init; i.Table = A_arbace_test_test_vars_fn__196000196_A_members; jrt.RegisterGoType(A_arbace_test_test_vars_fn__196000196_A_class, reflect.TypeFor[A_arbace_test_test_vars_fn__196000196_A]()) }

func A_arbace_test_test_vars_fn__196000196_fn__196000201_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_test_vars_fn__196000196_fn__196000201_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_test_vars_fn__196000196_fn__196000201_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_test_vars_fn__196000196_fn__196000201_A_New_O(args[0])}; return nil }

func A_arbace_test_test_vars_fn__196000196_fn__196000201_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_test_vars_fn__196000196_fn__196000201_A_fn_class)}; return nil }

var A_arbace_test_test_vars_fn__196000196_fn__196000201_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_test_vars_fn__196000196_fn__196000201_A_invoke, New: A_arbace_test_test_vars_fn__196000196_fn__196000201_A_new, Get: A_arbace_test_test_vars_fn__196000196_fn__196000201_A_get}

var A_arbace_test_test_vars_fn__196000196_fn__196000201_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$test_vars$fn__196000196$fn__196000201", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_test_vars_fn__196000196_A_class, Simple: "fn__196000201", Go: "arbace/aot_arbace_test.A_arbace_test_test_vars_fn__196000196_fn__196000201_A", Source: "test.ae"})

func init() { i := A_arbace_test_test_vars_fn__196000196_fn__196000201_A_class.Info(); i.IsInstance = A_arbace_test_test_vars_fn__196000196_fn__196000201_A_InstanceOf; i.Init = A_arbace_test_test_vars_fn__196000196_fn__196000201_A_Init; i.Table = A_arbace_test_test_vars_fn__196000196_fn__196000201_A_members; jrt.RegisterGoType(A_arbace_test_test_vars_fn__196000196_fn__196000201_A_class, reflect.TypeFor[A_arbace_test_test_vars_fn__196000196_fn__196000201_A]()) }

func A_arbace_test_test_vars_fn__196000196_fn__196000203_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_test_vars_fn__196000196_fn__196000203_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_test_vars_fn__196000196_fn__196000203_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_test_vars_fn__196000196_fn__196000203_A_New_O(args[0])}; return nil }

func A_arbace_test_test_vars_fn__196000196_fn__196000203_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_test_vars_fn__196000196_fn__196000203_A_fn_class)}; return nil }

var A_arbace_test_test_vars_fn__196000196_fn__196000203_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_test_vars_fn__196000196_fn__196000203_A_invoke, New: A_arbace_test_test_vars_fn__196000196_fn__196000203_A_new, Get: A_arbace_test_test_vars_fn__196000196_fn__196000203_A_get}

var A_arbace_test_test_vars_fn__196000196_fn__196000203_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$test_vars$fn__196000196$fn__196000203", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_test_vars_fn__196000196_A_class, Simple: "fn__196000203", Go: "arbace/aot_arbace_test.A_arbace_test_test_vars_fn__196000196_fn__196000203_A", Source: "test.ae"})

func init() { i := A_arbace_test_test_vars_fn__196000196_fn__196000203_A_class.Info(); i.IsInstance = A_arbace_test_test_vars_fn__196000196_fn__196000203_A_InstanceOf; i.Init = A_arbace_test_test_vars_fn__196000196_fn__196000203_A_Init; i.Table = A_arbace_test_test_vars_fn__196000196_fn__196000203_A_members; jrt.RegisterGoType(A_arbace_test_test_vars_fn__196000196_fn__196000203_A_class, reflect.TypeFor[A_arbace_test_test_vars_fn__196000196_fn__196000203_A]()) }

func A_arbace_test_testing_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_testing_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_test_testing_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_testing_A_New()}; return nil }

func A_arbace_test_testing_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_testing_A_fn_class)}; return nil }

var A_arbace_test_testing_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_testing_A_invoke, New: A_arbace_test_testing_A_new, Get: A_arbace_test_testing_A_get}

var A_arbace_test_testing_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$testing", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_test_A_class, Simple: "testing", Go: "arbace/aot_arbace_test.A_arbace_test_testing_A", Source: "test.ae"})

func init() { i := A_arbace_test_testing_A_class.Info(); i.IsInstance = A_arbace_test_testing_A_InstanceOf; i.Init = A_arbace_test_testing_A_Init; i.Table = A_arbace_test_testing_A_members; jrt.RegisterGoType(A_arbace_test_testing_A_class, reflect.TypeFor[A_arbace_test_testing_A]()) }

func A_arbace_test_testing_contexts_str_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_testing_contexts_str_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_testing_contexts_str_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_testing_contexts_str_A_New()}; return nil }

func A_arbace_test_testing_contexts_str_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_testing_contexts_str_A_fn_class)}; return nil }

var A_arbace_test_testing_contexts_str_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_testing_contexts_str_A_invoke, New: A_arbace_test_testing_contexts_str_A_new, Get: A_arbace_test_testing_contexts_str_A_get}

var A_arbace_test_testing_contexts_str_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$testing_contexts_str", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_A_class, Simple: "testing_contexts_str", Go: "arbace/aot_arbace_test.A_arbace_test_testing_contexts_str_A", Source: "test.ae"})

func init() { i := A_arbace_test_testing_contexts_str_A_class.Info(); i.IsInstance = A_arbace_test_testing_contexts_str_A_InstanceOf; i.Init = A_arbace_test_testing_contexts_str_A_Init; i.Table = A_arbace_test_testing_contexts_str_A_members; jrt.RegisterGoType(A_arbace_test_testing_contexts_str_A_class, reflect.TypeFor[A_arbace_test_testing_contexts_str_A]()) }

func A_arbace_test_testing_vars_str_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_testing_vars_str_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_testing_vars_str_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_testing_vars_str_A_New()}; return nil }

func A_arbace_test_testing_vars_str_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_testing_vars_str_A_fn_class)}; return nil }

var A_arbace_test_testing_vars_str_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_testing_vars_str_A_invoke, New: A_arbace_test_testing_vars_str_A_new, Get: A_arbace_test_testing_vars_str_A_get}

var A_arbace_test_testing_vars_str_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$testing_vars_str", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_A_class, Simple: "testing_vars_str", Go: "arbace/aot_arbace_test.A_arbace_test_testing_vars_str_A", Source: "test.ae"})

func init() { i := A_arbace_test_testing_vars_str_A_class.Info(); i.IsInstance = A_arbace_test_testing_vars_str_A_InstanceOf; i.Init = A_arbace_test_testing_vars_str_A_Init; i.Table = A_arbace_test_testing_vars_str_A_members; jrt.RegisterGoType(A_arbace_test_testing_vars_str_A_class, reflect.TypeFor[A_arbace_test_testing_vars_str_A]()) }

func A_arbace_test_testing_vars_str_fn__196000023_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_testing_vars_str_fn__196000023_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_testing_vars_str_fn__196000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_testing_vars_str_fn__196000023_A_New()}; return nil }

func A_arbace_test_testing_vars_str_fn__196000023_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_testing_vars_str_fn__196000023_A_fn_class)}; return nil }

var A_arbace_test_testing_vars_str_fn__196000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_testing_vars_str_fn__196000023_A_invoke, New: A_arbace_test_testing_vars_str_fn__196000023_A_new, Get: A_arbace_test_testing_vars_str_fn__196000023_A_get}

var A_arbace_test_testing_vars_str_fn__196000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$testing_vars_str$fn__196000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_testing_vars_str_A_class, Simple: "fn__196000023", Go: "arbace/aot_arbace_test.A_arbace_test_testing_vars_str_fn__196000023_A", Source: "test.ae"})

func init() { i := A_arbace_test_testing_vars_str_fn__196000023_A_class.Info(); i.IsInstance = A_arbace_test_testing_vars_str_fn__196000023_A_InstanceOf; i.Init = A_arbace_test_testing_vars_str_fn__196000023_A_Init; i.Table = A_arbace_test_testing_vars_str_fn__196000023_A_members; jrt.RegisterGoType(A_arbace_test_testing_vars_str_fn__196000023_A_class, reflect.TypeFor[A_arbace_test_testing_vars_str_fn__196000023_A]()) }

func A_arbace_test_try_expr_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_try_expr_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_test_try_expr_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_try_expr_A_New()}; return nil }

func A_arbace_test_try_expr_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_try_expr_A_fn_class)}; return nil }

var A_arbace_test_try_expr_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_try_expr_A_invoke, New: A_arbace_test_try_expr_A_new, Get: A_arbace_test_try_expr_A_get}

var A_arbace_test_try_expr_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$try_expr", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_test_A_class, Simple: "try_expr", Go: "arbace/aot_arbace_test.A_arbace_test_try_expr_A", Source: "test.ae"})

func init() { i := A_arbace_test_try_expr_A_class.Info(); i.IsInstance = A_arbace_test_try_expr_A_InstanceOf; i.Init = A_arbace_test_try_expr_A_Init; i.Table = A_arbace_test_try_expr_A_members; jrt.RegisterGoType(A_arbace_test_try_expr_A_class, reflect.TypeFor[A_arbace_test_try_expr_A]()) }

func A_arbace_test_with_test_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_with_test_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_test_with_test_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_with_test_A_New()}; return nil }

func A_arbace_test_with_test_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_with_test_A_fn_class)}; return nil }

var A_arbace_test_with_test_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_with_test_A_invoke, New: A_arbace_test_with_test_A_new, Get: A_arbace_test_with_test_A_get}

var A_arbace_test_with_test_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$with_test", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_test_A_class, Simple: "with_test", Go: "arbace/aot_arbace_test.A_arbace_test_with_test_A", Source: "test.ae"})

func init() { i := A_arbace_test_with_test_A_class.Info(); i.IsInstance = A_arbace_test_with_test_A_InstanceOf; i.Init = A_arbace_test_with_test_A_Init; i.Table = A_arbace_test_with_test_A_members; jrt.RegisterGoType(A_arbace_test_with_test_A_class, reflect.TypeFor[A_arbace_test_with_test_A]()) }

func A_arbace_test_with_test_out_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_with_test_out_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_test_with_test_out_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_with_test_out_A_New()}; return nil }

func A_arbace_test_with_test_out_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_with_test_out_A_fn_class)}; return nil }

var A_arbace_test_with_test_out_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_with_test_out_A_invoke, New: A_arbace_test_with_test_out_A_new, Get: A_arbace_test_with_test_out_A_get}

var A_arbace_test_with_test_out_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$with_test_out", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_test_A_class, Simple: "with_test_out", Go: "arbace/aot_arbace_test.A_arbace_test_with_test_out_A", Source: "test.ae"})

func init() { i := A_arbace_test_with_test_out_A_class.Info(); i.IsInstance = A_arbace_test_with_test_out_A_InstanceOf; i.Init = A_arbace_test_with_test_out_A_Init; i.Table = A_arbace_test_with_test_out_A_members; jrt.RegisterGoType(A_arbace_test_with_test_out_A_class, reflect.TypeFor[A_arbace_test_with_test_out_A]()) }

func A_arbace_test__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_test__init_A_Load__O(); case 1: return A_arbace_test__init_A_Unit0__O(); case 2: return A_arbace_test__init_A_Unit1__O(); case 3: return A_arbace_test__init_A_Unit10__O(); case 4: return A_arbace_test__init_A_Unit11__O(); case 5: return A_arbace_test__init_A_Unit12__O(); case 6: return A_arbace_test__init_A_Unit13__O(); case 7: return A_arbace_test__init_A_Unit14__O(); case 8: return A_arbace_test__init_A_Unit15__O(); case 9: return A_arbace_test__init_A_Unit16__O(); case 10: return A_arbace_test__init_A_Unit17__O(); case 11: return A_arbace_test__init_A_Unit18__O(); case 12: return A_arbace_test__init_A_Unit19__O(); case 13: return A_arbace_test__init_A_Unit2__O(); case 14: return A_arbace_test__init_A_Unit20__O(); case 15: return A_arbace_test__init_A_Unit21__O(); case 16: return A_arbace_test__init_A_Unit22__O(); case 17: return A_arbace_test__init_A_Unit23__O(); case 18: return A_arbace_test__init_A_Unit24__O(); case 19: return A_arbace_test__init_A_Unit25__O(); case 20: return A_arbace_test__init_A_Unit26__O(); case 21: return A_arbace_test__init_A_Unit27__O(); case 22: return A_arbace_test__init_A_Unit28__O(); case 23: return A_arbace_test__init_A_Unit29__O(); case 24: return A_arbace_test__init_A_Unit3__O(); case 25: return A_arbace_test__init_A_Unit30__O(); case 26: return A_arbace_test__init_A_Unit31__O(); case 27: return A_arbace_test__init_A_Unit32__O(); case 28: return A_arbace_test__init_A_Unit33__O(); case 29: return A_arbace_test__init_A_Unit34__O(); case 30: return A_arbace_test__init_A_Unit35__O(); case 31: return A_arbace_test__init_A_Unit36__O(); case 32: return A_arbace_test__init_A_Unit37__O(); case 33: return A_arbace_test__init_A_Unit38__O(); case 34: return A_arbace_test__init_A_Unit39__O(); case 35: return A_arbace_test__init_A_Unit4__O(); case 36: return A_arbace_test__init_A_Unit40__O(); case 37: return A_arbace_test__init_A_Unit41__O(); case 38: return A_arbace_test__init_A_Unit42__O(); case 39: return A_arbace_test__init_A_Unit43__O(); case 40: return A_arbace_test__init_A_Unit44__O(); case 41: return A_arbace_test__init_A_Unit45__O(); case 42: return A_arbace_test__init_A_Unit46__O(); case 43: return A_arbace_test__init_A_Unit47__O(); case 44: return A_arbace_test__init_A_Unit48__O(); case 45: return A_arbace_test__init_A_Unit49__O(); case 46: return A_arbace_test__init_A_Unit5__O(); case 47: return A_arbace_test__init_A_Unit50__O(); case 48: return A_arbace_test__init_A_Unit51__O(); case 49: return A_arbace_test__init_A_Unit52__O(); case 50: return A_arbace_test__init_A_Unit53__O(); case 51: return A_arbace_test__init_A_Unit54__O(); case 52: return A_arbace_test__init_A_Unit55__O(); case 53: return A_arbace_test__init_A_Unit56__O(); case 54: return A_arbace_test__init_A_Unit57__O(); case 55: return A_arbace_test__init_A_Unit58__O(); case 56: return A_arbace_test__init_A_Unit59__O(); case 57: return A_arbace_test__init_A_Unit6__O(); case 58: return A_arbace_test__init_A_Unit60__O(); case 59: return A_arbace_test__init_A_Unit61__O(); case 60: return A_arbace_test__init_A_Unit62__O(); case 61: return A_arbace_test__init_A_Unit63__O(); case 62: return A_arbace_test__init_A_Unit64__O(); case 63: return A_arbace_test__init_A_Unit65__O(); case 64: return A_arbace_test__init_A_Unit66__O(); case 65: return A_arbace_test__init_A_Unit67__O(); case 66: return A_arbace_test__init_A_Unit68__O(); case 67: return A_arbace_test__init_A_Unit69__O(); case 68: return A_arbace_test__init_A_Unit7__O(); case 69: return A_arbace_test__init_A_Unit70__O(); case 70: return A_arbace_test__init_A_Unit71__O(); case 71: return A_arbace_test__init_A_Unit72__O(); case 72: return A_arbace_test__init_A_Unit73__O(); case 73: return A_arbace_test__init_A_Unit74__O(); case 74: return A_arbace_test__init_A_Unit75__O(); case 75: return A_arbace_test__init_A_Unit76__O(); case 76: return A_arbace_test__init_A_Unit77__O(); case 77: return A_arbace_test__init_A_Unit78__O(); case 78: return A_arbace_test__init_A_Unit79__O(); case 79: return A_arbace_test__init_A_Unit8__O(); case 80: return A_arbace_test__init_A_Unit80__O(); case 81: return A_arbace_test__init_A_Unit81__O(); case 82: return A_arbace_test__init_A_Unit82__O(); case 83: return A_arbace_test__init_A_Unit9__O()}; return nil }

func A_arbace_test__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test__init_A_New()}; return nil }

var A_arbace_test__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit47 ()Ljava.lang.Object;\nM9 unit48 ()Ljava.lang.Object;\nM9 unit49 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit50 ()Ljava.lang.Object;\nM9 unit51 ()Ljava.lang.Object;\nM9 unit52 ()Ljava.lang.Object;\nM9 unit53 ()Ljava.lang.Object;\nM9 unit54 ()Ljava.lang.Object;\nM9 unit55 ()Ljava.lang.Object;\nM9 unit56 ()Ljava.lang.Object;\nM9 unit57 ()Ljava.lang.Object;\nM9 unit58 ()Ljava.lang.Object;\nM9 unit59 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit60 ()Ljava.lang.Object;\nM9 unit61 ()Ljava.lang.Object;\nM9 unit62 ()Ljava.lang.Object;\nM9 unit63 ()Ljava.lang.Object;\nM9 unit64 ()Ljava.lang.Object;\nM9 unit65 ()Ljava.lang.Object;\nM9 unit66 ()Ljava.lang.Object;\nM9 unit67 ()Ljava.lang.Object;\nM9 unit68 ()Ljava.lang.Object;\nM9 unit69 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit70 ()Ljava.lang.Object;\nM9 unit71 ()Ljava.lang.Object;\nM9 unit72 ()Ljava.lang.Object;\nM9 unit73 ()Ljava.lang.Object;\nM9 unit74 ()Ljava.lang.Object;\nM9 unit75 ()Ljava.lang.Object;\nM9 unit76 ()Ljava.lang.Object;\nM9 unit77 ()Ljava.lang.Object;\nM9 unit78 ()Ljava.lang.Object;\nM9 unit79 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit80 ()Ljava.lang.Object;\nM9 unit81 ()Ljava.lang.Object;\nM9 unit82 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_test__init_A_invoke, New: A_arbace_test__init_A_new}

var A_arbace_test__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_test.A_arbace_test__init_A", Source: "test.ae"})

func init() { i := A_arbace_test__init_A_class.Info(); i.IsInstance = A_arbace_test__init_A_InstanceOf; i.Init = A_arbace_test__init_A_Init; i.Table = A_arbace_test__init_A_members; jrt.RegisterGoType(A_arbace_test__init_A_class, reflect.TypeFor[A_arbace_test__init_A]()) }
