//line a2g_classes.ae:1
package aot_arbace_test

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_test_add_ns_meta_A_class, Name: "arbace.test$add_ns_meta", Modifiers: 25, Simple: "add_ns_meta", Go: "arbace/aot_arbace_test.A_arbace_test_add_ns_meta_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_test_are_A_class, Name: "arbace.test$are", Modifiers: 25, Simple: "are", Go: "arbace/aot_arbace_test.A_arbace_test_are_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR4_class}}, jrt.CodeDecl{Out: &A_arbace_test_assert_any_A_class, Name: "arbace.test$assert_any", Modifiers: 25, Simple: "assert_any", Go: "arbace/aot_arbace_test.A_arbace_test_assert_any_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_test_assert_predicate_A_class, Name: "arbace.test$assert_predicate", Modifiers: 25, Simple: "assert_predicate", Go: "arbace/aot_arbace_test.A_arbace_test_assert_predicate_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_test_compose_fixtures_A_class, Name: "arbace.test$compose_fixtures", Modifiers: 25, Simple: "compose_fixtures", Go: "arbace/aot_arbace_test.A_arbace_test_compose_fixtures_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_test_compose_fixtures_fn__196000167_A_class, Name: "arbace.test$compose_fixtures$fn__196000167", Modifiers: 25, Simple: "fn__196000167", Go: "arbace/aot_arbace_test.A_arbace_test_compose_fixtures_fn__196000167_A", Source: "test.ae", Declaring: &A_arbace_test_compose_fixtures_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_class, Name: "arbace.test$compose_fixtures$fn__196000167$fn__196000168", Modifiers: 25, Simple: "fn__196000168", Go: "arbace/aot_arbace_test.A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A", Source: "test.ae", Declaring: &A_arbace_test_compose_fixtures_fn__196000167_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_default_fixture_A_class, Name: "arbace.test$default_fixture", Modifiers: 25, Simple: "default_fixture", Go: "arbace/aot_arbace_test.A_arbace_test_default_fixture_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_deftest_A_class, Name: "arbace.test$deftest", Modifiers: 25, Simple: "deftest", Go: "arbace/aot_arbace_test.A_arbace_test_deftest_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}, jrt.CodeDecl{Out: &A_arbace_test_deftest__A_class, Name: "arbace.test$deftest_", Modifiers: 25, Simple: "deftest_", Go: "arbace/aot_arbace_test.A_arbace_test_deftest__A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}, jrt.CodeDecl{Out: &A_arbace_test_do_report_A_class, Name: "arbace.test$do_report", Modifiers: 25, Simple: "do_report", Go: "arbace/aot_arbace_test.A_arbace_test_do_report_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_do_report_fn__196000036_A_class, Name: "arbace.test$do_report$fn__196000036", Modifiers: 25, Simple: "fn__196000036", Go: "arbace/aot_arbace_test.A_arbace_test_do_report_fn__196000036_A", Source: "test.ae", Declaring: &A_arbace_test_do_report_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_class, Name: "arbace.test$eval196000004$loading__1927001464__auto____196000005", Modifiers: 25, Simple: "loading__1927001464__auto____196000005", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000008_fn__196000009_A_class, Name: "arbace.test$eval196000008$fn__196000009", Modifiers: 25, Simple: "fn__196000009", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000008_fn__196000009_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000039_fn__196000040_A_class, Name: "arbace.test$eval196000039$fn__196000040", Modifiers: 25, Simple: "fn__196000040", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000039_fn__196000040_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000039_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000043_fn__196000044_A_class, Name: "arbace.test$eval196000043$fn__196000044", Modifiers: 25, Simple: "fn__196000044", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000043_fn__196000044_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000043_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000047_fn__196000048_A_class, Name: "arbace.test$eval196000047$fn__196000048", Modifiers: 25, Simple: "fn__196000048", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000047_fn__196000048_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000047_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000051_fn__196000052_A_class, Name: "arbace.test$eval196000051$fn__196000052", Modifiers: 25, Simple: "fn__196000052", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000051_fn__196000052_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000051_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000055_fn__196000056_A_class, Name: "arbace.test$eval196000055$fn__196000056", Modifiers: 25, Simple: "fn__196000056", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000055_fn__196000056_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000055_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000059_fn__196000060_A_class, Name: "arbace.test$eval196000059$fn__196000060", Modifiers: 25, Simple: "fn__196000060", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000059_fn__196000060_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000059_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000063_fn__196000064_A_class, Name: "arbace.test$eval196000063$fn__196000064", Modifiers: 25, Simple: "fn__196000064", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000063_fn__196000064_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000063_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000067_fn__196000068_A_class, Name: "arbace.test$eval196000067$fn__196000068", Modifiers: 25, Simple: "fn__196000068", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000067_fn__196000068_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000067_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000071_fn__196000072_A_class, Name: "arbace.test$eval196000071$fn__196000072", Modifiers: 25, Simple: "fn__196000072", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000071_fn__196000072_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000071_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000082_fn__196000083_A_class, Name: "arbace.test$eval196000082$fn__196000083", Modifiers: 25, Simple: "fn__196000083", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000082_fn__196000083_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000082_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000086_fn__196000087_A_class, Name: "arbace.test$eval196000086$fn__196000087", Modifiers: 25, Simple: "fn__196000087", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000086_fn__196000087_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000086_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000090_fn__196000091_A_class, Name: "arbace.test$eval196000090$fn__196000091", Modifiers: 25, Simple: "fn__196000091", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000090_fn__196000091_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000090_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000097_fn__196000098_A_class, Name: "arbace.test$eval196000097$fn__196000098", Modifiers: 25, Simple: "fn__196000098", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000097_fn__196000098_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000097_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000102_fn__196000103_A_class, Name: "arbace.test$eval196000102$fn__196000103", Modifiers: 25, Simple: "fn__196000103", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000102_fn__196000103_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000102_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000108_fn__196000109_A_class, Name: "arbace.test$eval196000108$fn__196000109", Modifiers: 25, Simple: "fn__196000109", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000108_fn__196000109_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000108_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000154_fn__196000155_A_class, Name: "arbace.test$eval196000154$fn__196000155", Modifiers: 25, Simple: "fn__196000155", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000154_fn__196000155_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000154_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000158_fn__196000159_A_class, Name: "arbace.test$eval196000158$fn__196000159", Modifiers: 25, Simple: "fn__196000159", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000158_fn__196000159_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000158_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_test_eval196000162_fn__196000163_A_class, Name: "arbace.test$eval196000162$fn__196000163", Modifiers: 25, Simple: "fn__196000163", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000162_fn__196000163_A", Source: "test.ae", Declaring: &A_arbace_test_eval196000162_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_test_file_and_line_A_class, Name: "arbace.test$file_and_line", Modifiers: 25, Simple: "file_and_line", Go: "arbace/aot_arbace_test.A_arbace_test_file_and_line_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_test_file_position_A_class, Name: "arbace.test$file_position", Modifiers: 25, Simple: "file_position", Go: "arbace/aot_arbace_test.A_arbace_test_file_position_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_function_QMARK__A_class, Name: "arbace.test$function_QMARK_", Modifiers: 25, Simple: "function_QMARK_", Go: "arbace/aot_arbace_test.A_arbace_test_function_QMARK__A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_get_possibly_unbound_var_A_class, Name: "arbace.test$get_possibly_unbound_var", Modifiers: 25, Simple: "get_possibly_unbound_var", Go: "arbace/aot_arbace_test.A_arbace_test_get_possibly_unbound_var_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_inc_report_counter_A_class, Name: "arbace.test$inc_report_counter", Modifiers: 25, Simple: "inc_report_counter", Go: "arbace/aot_arbace_test.A_arbace_test_inc_report_counter_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_inc_report_counter_fn__196000027_A_class, Name: "arbace.test$inc_report_counter$fn__196000027", Modifiers: 25, Simple: "fn__196000027", Go: "arbace/aot_arbace_test.A_arbace_test_inc_report_counter_fn__196000027_A", Source: "test.ae", Declaring: &A_arbace_test_inc_report_counter_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_is_A_class, Name: "arbace.test$is", Modifiers: 25, Simple: "is", Go: "arbace/aot_arbace_test.A_arbace_test_is_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class, &lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_test_join_fixtures_A_class, Name: "arbace.test$join_fixtures", Modifiers: 25, Simple: "join_fixtures", Go: "arbace/aot_arbace_test.A_arbace_test_join_fixtures_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_run_all_tests_A_class, Name: "arbace.test$run_all_tests", Modifiers: 25, Simple: "run_all_tests", Go: "arbace/aot_arbace_test.A_arbace_test_run_all_tests_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_run_all_tests_fn__196000211_A_class, Name: "arbace.test$run_all_tests$fn__196000211", Modifiers: 25, Simple: "fn__196000211", Go: "arbace/aot_arbace_test.A_arbace_test_run_all_tests_fn__196000211_A", Source: "test.ae", Declaring: &A_arbace_test_run_all_tests_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_run_test_A_class, Name: "arbace.test$run_test", Modifiers: 25, Simple: "run_test", Go: "arbace/aot_arbace_test.A_arbace_test_run_test_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_test_run_test_var_A_class, Name: "arbace.test$run_test_var", Modifiers: 25, Simple: "run_test_var", Go: "arbace/aot_arbace_test.A_arbace_test_run_test_var_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_run_tests_A_class, Name: "arbace.test$run_tests", Modifiers: 25, Simple: "run_tests", Go: "arbace/aot_arbace_test.A_arbace_test_run_tests_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_set_test_A_class, Name: "arbace.test$set_test", Modifiers: 25, Simple: "set_test", Go: "arbace/aot_arbace_test.A_arbace_test_set_test_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}, jrt.CodeDecl{Out: &A_arbace_test_stacktrace_file_and_line_A_class, Name: "arbace.test$stacktrace_file_and_line", Modifiers: 25, Simple: "stacktrace_file_and_line", Go: "arbace/aot_arbace_test.A_arbace_test_stacktrace_file_and_line_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_successful_QMARK__A_class, Name: "arbace.test$successful_QMARK_", Modifiers: 25, Simple: "successful_QMARK_", Go: "arbace/aot_arbace_test.A_arbace_test_successful_QMARK__A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_test_all_vars_A_class, Name: "arbace.test$test_all_vars", Modifiers: 25, Simple: "test_all_vars", Go: "arbace/aot_arbace_test.A_arbace_test_test_all_vars_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_test_ns_A_class, Name: "arbace.test$test_ns", Modifiers: 25, Simple: "test_ns", Go: "arbace/aot_arbace_test.A_arbace_test_test_ns_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_test_var_A_class, Name: "arbace.test$test_var", Modifiers: 25, Simple: "test_var", Go: "arbace/aot_arbace_test.A_arbace_test_test_var_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_test_var_fn__196000173_A_class, Name: "arbace.test$test_var$fn__196000173", Modifiers: 25, Simple: "fn__196000173", Go: "arbace/aot_arbace_test.A_arbace_test_test_var_fn__196000173_A", Source: "test.ae", Declaring: &A_arbace_test_test_var_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_test_vars_A_class, Name: "arbace.test$test_vars", Modifiers: 25, Simple: "test_vars", Go: "arbace/aot_arbace_test.A_arbace_test_test_vars_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_test_vars_fn__196000183_A_class, Name: "arbace.test$test_vars$fn__196000183", Modifiers: 25, Simple: "fn__196000183", Go: "arbace/aot_arbace_test.A_arbace_test_test_vars_fn__196000183_A", Source: "test.ae", Declaring: &A_arbace_test_test_vars_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_test_vars_fn__196000183_fn__196000188_A_class, Name: "arbace.test$test_vars$fn__196000183$fn__196000188", Modifiers: 25, Simple: "fn__196000188", Go: "arbace/aot_arbace_test.A_arbace_test_test_vars_fn__196000183_fn__196000188_A", Source: "test.ae", Declaring: &A_arbace_test_test_vars_fn__196000183_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_test_vars_fn__196000183_fn__196000190_A_class, Name: "arbace.test$test_vars$fn__196000183$fn__196000190", Modifiers: 25, Simple: "fn__196000190", Go: "arbace/aot_arbace_test.A_arbace_test_test_vars_fn__196000183_fn__196000190_A", Source: "test.ae", Declaring: &A_arbace_test_test_vars_fn__196000183_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_test_vars_fn__196000196_A_class, Name: "arbace.test$test_vars$fn__196000196", Modifiers: 25, Simple: "fn__196000196", Go: "arbace/aot_arbace_test.A_arbace_test_test_vars_fn__196000196_A", Source: "test.ae", Declaring: &A_arbace_test_test_vars_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_test_vars_fn__196000196_fn__196000201_A_class, Name: "arbace.test$test_vars$fn__196000196$fn__196000201", Modifiers: 25, Simple: "fn__196000201", Go: "arbace/aot_arbace_test.A_arbace_test_test_vars_fn__196000196_fn__196000201_A", Source: "test.ae", Declaring: &A_arbace_test_test_vars_fn__196000196_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_test_vars_fn__196000196_fn__196000203_A_class, Name: "arbace.test$test_vars$fn__196000196$fn__196000203", Modifiers: 25, Simple: "fn__196000203", Go: "arbace/aot_arbace_test.A_arbace_test_test_vars_fn__196000196_fn__196000203_A", Source: "test.ae", Declaring: &A_arbace_test_test_vars_fn__196000196_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_testing_A_class, Name: "arbace.test$testing", Modifiers: 25, Simple: "testing", Go: "arbace/aot_arbace_test.A_arbace_test_testing_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}, jrt.CodeDecl{Out: &A_arbace_test_testing_contexts_str_A_class, Name: "arbace.test$testing_contexts_str", Modifiers: 25, Simple: "testing_contexts_str", Go: "arbace/aot_arbace_test.A_arbace_test_testing_contexts_str_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_testing_vars_str_A_class, Name: "arbace.test$testing_vars_str", Modifiers: 25, Simple: "testing_vars_str", Go: "arbace/aot_arbace_test.A_arbace_test_testing_vars_str_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_testing_vars_str_fn__196000023_A_class, Name: "arbace.test$testing_vars_str$fn__196000023", Modifiers: 25, Simple: "fn__196000023", Go: "arbace/aot_arbace_test.A_arbace_test_testing_vars_str_fn__196000023_A", Source: "test.ae", Declaring: &A_arbace_test_testing_vars_str_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_try_expr_A_class, Name: "arbace.test$try_expr", Modifiers: 25, Simple: "try_expr", Go: "arbace/aot_arbace_test.A_arbace_test_try_expr_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_test_with_test_A_class, Name: "arbace.test$with_test", Modifiers: 25, Simple: "with_test", Go: "arbace/aot_arbace_test.A_arbace_test_with_test_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}, jrt.CodeDecl{Out: &A_arbace_test_with_test_out_A_class, Name: "arbace.test$with_test_out", Modifiers: 25, Simple: "with_test_out", Go: "arbace/aot_arbace_test.A_arbace_test_with_test_out_A", Source: "test.ae", Declaring: &A_arbace_test_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_test_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_A_New()}; return nil }

var A_arbace_test_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_A_new}

var A_arbace_test_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_test.A_arbace_test_A"})

func init() { i := A_arbace_test_A_class.Info(); i.IsInstance = A_arbace_test_A_InstanceOf; i.Init = A_arbace_test_A_Init; i.Table = A_arbace_test_A_members }

var A_arbace_test_add_ns_meta_A_class *jrt.Class

var A_arbace_test_are_A_class *jrt.Class

var A_arbace_test_assert_any_A_class *jrt.Class

var A_arbace_test_assert_predicate_A_class *jrt.Class

var A_arbace_test_compose_fixtures_A_class *jrt.Class

var A_arbace_test_compose_fixtures_fn__196000167_A_class *jrt.Class

var A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_class *jrt.Class

var A_arbace_test_default_fixture_A_class *jrt.Class

var A_arbace_test_deftest_A_class *jrt.Class

var A_arbace_test_deftest__A_class *jrt.Class

var A_arbace_test_do_report_A_class *jrt.Class

var A_arbace_test_do_report_fn__196000036_A_class *jrt.Class

func A_arbace_test_eval196000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000004_A_New()}; return nil }

var A_arbace_test_eval196000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000004_A_new}

var A_arbace_test_eval196000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000004", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000004_A"})

func init() { i := A_arbace_test_eval196000004_A_class.Info(); i.IsInstance = A_arbace_test_eval196000004_A_InstanceOf; i.Table = A_arbace_test_eval196000004_A_members }

var A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_class *jrt.Class

func A_arbace_test_eval196000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000008_A_New()}; return nil }

var A_arbace_test_eval196000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000008_A_new}

var A_arbace_test_eval196000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000008", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000008_A"})

func init() { i := A_arbace_test_eval196000008_A_class.Info(); i.IsInstance = A_arbace_test_eval196000008_A_InstanceOf; i.Table = A_arbace_test_eval196000008_A_members }

var A_arbace_test_eval196000008_fn__196000009_A_class *jrt.Class

func A_arbace_test_eval196000039_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000039_A_New()}; return nil }

var A_arbace_test_eval196000039_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000039_A_new}

var A_arbace_test_eval196000039_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000039", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000039", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000039_A"})

func init() { i := A_arbace_test_eval196000039_A_class.Info(); i.IsInstance = A_arbace_test_eval196000039_A_InstanceOf; i.Table = A_arbace_test_eval196000039_A_members }

var A_arbace_test_eval196000039_fn__196000040_A_class *jrt.Class

func A_arbace_test_eval196000043_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000043_A_New()}; return nil }

var A_arbace_test_eval196000043_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000043_A_new}

var A_arbace_test_eval196000043_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000043", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000043", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000043_A"})

func init() { i := A_arbace_test_eval196000043_A_class.Info(); i.IsInstance = A_arbace_test_eval196000043_A_InstanceOf; i.Table = A_arbace_test_eval196000043_A_members }

var A_arbace_test_eval196000043_fn__196000044_A_class *jrt.Class

func A_arbace_test_eval196000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000047_A_New()}; return nil }

var A_arbace_test_eval196000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000047_A_new}

var A_arbace_test_eval196000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000047", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000047_A"})

func init() { i := A_arbace_test_eval196000047_A_class.Info(); i.IsInstance = A_arbace_test_eval196000047_A_InstanceOf; i.Table = A_arbace_test_eval196000047_A_members }

var A_arbace_test_eval196000047_fn__196000048_A_class *jrt.Class

func A_arbace_test_eval196000051_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000051_A_New()}; return nil }

var A_arbace_test_eval196000051_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000051_A_new}

var A_arbace_test_eval196000051_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000051", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000051", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000051_A"})

func init() { i := A_arbace_test_eval196000051_A_class.Info(); i.IsInstance = A_arbace_test_eval196000051_A_InstanceOf; i.Table = A_arbace_test_eval196000051_A_members }

var A_arbace_test_eval196000051_fn__196000052_A_class *jrt.Class

func A_arbace_test_eval196000055_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000055_A_New()}; return nil }

var A_arbace_test_eval196000055_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000055_A_new}

var A_arbace_test_eval196000055_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000055", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000055", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000055_A"})

func init() { i := A_arbace_test_eval196000055_A_class.Info(); i.IsInstance = A_arbace_test_eval196000055_A_InstanceOf; i.Table = A_arbace_test_eval196000055_A_members }

var A_arbace_test_eval196000055_fn__196000056_A_class *jrt.Class

func A_arbace_test_eval196000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000059_A_New()}; return nil }

var A_arbace_test_eval196000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000059_A_new}

var A_arbace_test_eval196000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000059", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000059_A"})

func init() { i := A_arbace_test_eval196000059_A_class.Info(); i.IsInstance = A_arbace_test_eval196000059_A_InstanceOf; i.Table = A_arbace_test_eval196000059_A_members }

var A_arbace_test_eval196000059_fn__196000060_A_class *jrt.Class

func A_arbace_test_eval196000063_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000063_A_New()}; return nil }

var A_arbace_test_eval196000063_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000063_A_new}

var A_arbace_test_eval196000063_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000063", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000063", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000063_A"})

func init() { i := A_arbace_test_eval196000063_A_class.Info(); i.IsInstance = A_arbace_test_eval196000063_A_InstanceOf; i.Table = A_arbace_test_eval196000063_A_members }

var A_arbace_test_eval196000063_fn__196000064_A_class *jrt.Class

func A_arbace_test_eval196000067_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000067_A_New()}; return nil }

var A_arbace_test_eval196000067_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000067_A_new}

var A_arbace_test_eval196000067_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000067", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000067", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000067_A"})

func init() { i := A_arbace_test_eval196000067_A_class.Info(); i.IsInstance = A_arbace_test_eval196000067_A_InstanceOf; i.Table = A_arbace_test_eval196000067_A_members }

var A_arbace_test_eval196000067_fn__196000068_A_class *jrt.Class

func A_arbace_test_eval196000071_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000071_A_New()}; return nil }

var A_arbace_test_eval196000071_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000071_A_new}

var A_arbace_test_eval196000071_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000071", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000071", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000071_A"})

func init() { i := A_arbace_test_eval196000071_A_class.Info(); i.IsInstance = A_arbace_test_eval196000071_A_InstanceOf; i.Table = A_arbace_test_eval196000071_A_members }

var A_arbace_test_eval196000071_fn__196000072_A_class *jrt.Class

func A_arbace_test_eval196000082_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000082_A_New()}; return nil }

var A_arbace_test_eval196000082_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000082_A_new}

var A_arbace_test_eval196000082_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000082", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000082", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000082_A"})

func init() { i := A_arbace_test_eval196000082_A_class.Info(); i.IsInstance = A_arbace_test_eval196000082_A_InstanceOf; i.Table = A_arbace_test_eval196000082_A_members }

var A_arbace_test_eval196000082_fn__196000083_A_class *jrt.Class

func A_arbace_test_eval196000086_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000086_A_New()}; return nil }

var A_arbace_test_eval196000086_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000086_A_new}

var A_arbace_test_eval196000086_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000086", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000086", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000086_A"})

func init() { i := A_arbace_test_eval196000086_A_class.Info(); i.IsInstance = A_arbace_test_eval196000086_A_InstanceOf; i.Table = A_arbace_test_eval196000086_A_members }

var A_arbace_test_eval196000086_fn__196000087_A_class *jrt.Class

func A_arbace_test_eval196000090_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000090_A_New()}; return nil }

var A_arbace_test_eval196000090_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000090_A_new}

var A_arbace_test_eval196000090_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000090", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000090", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000090_A"})

func init() { i := A_arbace_test_eval196000090_A_class.Info(); i.IsInstance = A_arbace_test_eval196000090_A_InstanceOf; i.Table = A_arbace_test_eval196000090_A_members }

var A_arbace_test_eval196000090_fn__196000091_A_class *jrt.Class

func A_arbace_test_eval196000097_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000097_A_New()}; return nil }

var A_arbace_test_eval196000097_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000097_A_new}

var A_arbace_test_eval196000097_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000097", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000097", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000097_A"})

func init() { i := A_arbace_test_eval196000097_A_class.Info(); i.IsInstance = A_arbace_test_eval196000097_A_InstanceOf; i.Table = A_arbace_test_eval196000097_A_members }

var A_arbace_test_eval196000097_fn__196000098_A_class *jrt.Class

func A_arbace_test_eval196000102_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000102_A_New()}; return nil }

var A_arbace_test_eval196000102_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000102_A_new}

var A_arbace_test_eval196000102_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000102", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000102", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000102_A"})

func init() { i := A_arbace_test_eval196000102_A_class.Info(); i.IsInstance = A_arbace_test_eval196000102_A_InstanceOf; i.Table = A_arbace_test_eval196000102_A_members }

var A_arbace_test_eval196000102_fn__196000103_A_class *jrt.Class

func A_arbace_test_eval196000108_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000108_A_New()}; return nil }

var A_arbace_test_eval196000108_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000108_A_new}

var A_arbace_test_eval196000108_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000108", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000108", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000108_A"})

func init() { i := A_arbace_test_eval196000108_A_class.Info(); i.IsInstance = A_arbace_test_eval196000108_A_InstanceOf; i.Table = A_arbace_test_eval196000108_A_members }

var A_arbace_test_eval196000108_fn__196000109_A_class *jrt.Class

func A_arbace_test_eval196000154_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000154_A_New()}; return nil }

var A_arbace_test_eval196000154_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000154_A_new}

var A_arbace_test_eval196000154_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000154", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000154", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000154_A"})

func init() { i := A_arbace_test_eval196000154_A_class.Info(); i.IsInstance = A_arbace_test_eval196000154_A_InstanceOf; i.Table = A_arbace_test_eval196000154_A_members }

var A_arbace_test_eval196000154_fn__196000155_A_class *jrt.Class

func A_arbace_test_eval196000158_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000158_A_New()}; return nil }

var A_arbace_test_eval196000158_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000158_A_new}

var A_arbace_test_eval196000158_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000158", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000158", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000158_A"})

func init() { i := A_arbace_test_eval196000158_A_class.Info(); i.IsInstance = A_arbace_test_eval196000158_A_InstanceOf; i.Table = A_arbace_test_eval196000158_A_members }

var A_arbace_test_eval196000158_fn__196000159_A_class *jrt.Class

func A_arbace_test_eval196000162_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_eval196000162_A_New()}; return nil }

var A_arbace_test_eval196000162_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_eval196000162_A_new}

var A_arbace_test_eval196000162_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test$eval196000162", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_A_class, Simple: "eval196000162", Go: "arbace/aot_arbace_test.A_arbace_test_eval196000162_A"})

func init() { i := A_arbace_test_eval196000162_A_class.Info(); i.IsInstance = A_arbace_test_eval196000162_A_InstanceOf; i.Table = A_arbace_test_eval196000162_A_members }

var A_arbace_test_eval196000162_fn__196000163_A_class *jrt.Class

var A_arbace_test_file_and_line_A_class *jrt.Class

var A_arbace_test_file_position_A_class *jrt.Class

var A_arbace_test_function_QMARK__A_class *jrt.Class

var A_arbace_test_get_possibly_unbound_var_A_class *jrt.Class

var A_arbace_test_inc_report_counter_A_class *jrt.Class

var A_arbace_test_inc_report_counter_fn__196000027_A_class *jrt.Class

var A_arbace_test_is_A_class *jrt.Class

var A_arbace_test_join_fixtures_A_class *jrt.Class

var A_arbace_test_run_all_tests_A_class *jrt.Class

var A_arbace_test_run_all_tests_fn__196000211_A_class *jrt.Class

var A_arbace_test_run_test_A_class *jrt.Class

var A_arbace_test_run_test_var_A_class *jrt.Class

var A_arbace_test_run_tests_A_class *jrt.Class

var A_arbace_test_set_test_A_class *jrt.Class

var A_arbace_test_stacktrace_file_and_line_A_class *jrt.Class

var A_arbace_test_successful_QMARK__A_class *jrt.Class

var A_arbace_test_test_all_vars_A_class *jrt.Class

var A_arbace_test_test_ns_A_class *jrt.Class

var A_arbace_test_test_var_A_class *jrt.Class

var A_arbace_test_test_var_fn__196000173_A_class *jrt.Class

var A_arbace_test_test_vars_A_class *jrt.Class

var A_arbace_test_test_vars_fn__196000183_A_class *jrt.Class

var A_arbace_test_test_vars_fn__196000183_fn__196000188_A_class *jrt.Class

var A_arbace_test_test_vars_fn__196000183_fn__196000190_A_class *jrt.Class

var A_arbace_test_test_vars_fn__196000196_A_class *jrt.Class

var A_arbace_test_test_vars_fn__196000196_fn__196000201_A_class *jrt.Class

var A_arbace_test_test_vars_fn__196000196_fn__196000203_A_class *jrt.Class

var A_arbace_test_testing_A_class *jrt.Class

var A_arbace_test_testing_contexts_str_A_class *jrt.Class

var A_arbace_test_testing_vars_str_A_class *jrt.Class

var A_arbace_test_testing_vars_str_fn__196000023_A_class *jrt.Class

var A_arbace_test_try_expr_A_class *jrt.Class

var A_arbace_test_with_test_A_class *jrt.Class

var A_arbace_test_with_test_out_A_class *jrt.Class

func A_arbace_test__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_test__init_A_Load__O()}; return nil }

func A_arbace_test__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test__init_A_New()}; return nil }

var A_arbace_test__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_test__init_A_invoke, New: A_arbace_test__init_A_new}

var A_arbace_test__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_test.A_arbace_test__init_A", Source: "test.ae"})

func init() { i := A_arbace_test__init_A_class.Info(); i.IsInstance = A_arbace_test__init_A_InstanceOf; i.Init = A_arbace_test__init_A_Init; i.Table = A_arbace_test__init_A_members }
