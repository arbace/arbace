//line aot_arbace_test_a2g.ae:1
package aot_arbace_test

import (
	"arbace/jrt"
	"arbace/lang"
)










func A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_New() *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A { A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_Init(); t := &A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A) Ctor() {}
//line :17:1
func (t *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_test_A_Init(); tmp6 = A_arbace_test_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_5; tmp3 = tmp8.Invoke_O_O_O__O(tmp10, tmp12, tmp13) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp14 != nil { panic(tmp14) }; return tmp3 }
//line :17:1
func A_arbace_test_eval196000008_fn__196000009_A_New() *A_arbace_test_eval196000008_fn__196000009_A { A_arbace_test_eval196000008_fn__196000009_A_Init(); t := &A_arbace_test_eval196000008_fn__196000009_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_test_eval196000008_fn__196000009_A) Ctor() {}
//line :17:1
func (t *A_arbace_test_eval196000008_fn__196000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_7; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_10; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_8; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_9; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }

























































































































































































































































func A_arbace_test_with_test_out_A_New() *A_arbace_test_with_test_out_A { A_arbace_test_with_test_out_A_Init(); t := &A_arbace_test_with_test_out_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_test_with_test_out_A) Ctor() {}
//line :267:1
func (t *A_arbace_test_with_test_out_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_12; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_13; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_14; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_13; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_15; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_16; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_11; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_12; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_test_A_Init(); tmp19 = A_arbace_test_A_const_13; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_test_A_Init(); tmp21 = A_arbace_test_A_const_17; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_test_A_Init(); tmp23 = A_arbace_test_A_const_13; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_18; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp22, tmp24.Invoke_O__O(tmp25))))), body__2)) }








func A_arbace_test_file_position_A_New() *A_arbace_test_file_position_A { A_arbace_test_file_position_A_Init(); t := &A_arbace_test_file_position_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_test_file_position_A) Ctor() {}
//line :276:1
func (t *A_arbace_test_file_position_A) Invoke_O_O__O(self, n__0 any) any { var s__2 any = lang.RT_Nth_O_I__O(jrt.Throwable_New().GetStackTrace__StackTraceElement1().Ref(), lang.RT_IntCast_O__I(n__0)); return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.As[*jrt.StackTraceElement](s__2)).GetFileName__String().Ref(), jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.As[*jrt.StackTraceElement](s__2)).GetLineNumber__I()).Ref()) }











func A_arbace_test_testing_vars_str_A_New() *A_arbace_test_testing_vars_str_A { A_arbace_test_testing_vars_str_A_Init(); t := &A_arbace_test_testing_vars_str_A{}; t.Ctor(); return t }
//line :288:1
func (t *A_arbace_test_testing_vars_str_A) Ctor() {}
//line :288:1
func (t *A_arbace_test_testing_vars_str_A) Invoke_O_O__O(self, m__0 any) any { var map__196000021__2 any = m__0; var map__196000021__3 any; if





	lang.ISeq_InstanceOf(map__196000021__2) { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_19; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__196000021__2)) { var tmp2 *lang.Var; A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_20; map__196000021__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__196000021__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_11; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__196000021__2)) { var tmp4 *lang.Var; A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_21; map__196000021__3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__196000021__2) } else { lang.PersistentArrayMap_Init(); map__196000021__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__196000021__3 = map__196000021__2 }; var file__4 any; var tmp5 /*line :288:1*/*lang.Keyword;





	A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_22; file__4 = lang.RT_Get_O_O__O(map__196000021__3, tmp5.Ref()); var line__5 any; var tmp6 /*line :288:1*/*lang.Keyword;





	A_arbace_test_A_Init(); tmp6 = A_arbace_test_A_const_23; line__5 = lang.RT_Get_O_O__O(map__196000021__3, tmp6.Ref()); var tmp7 /*line :295:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_245, nil, Lit_246, nil, Lit_247); var tmp8 *lang.Var; A_arbace_test_A_Init(); tmp8 = A_arbace_test_A_const_24; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_test_A_Init(); tmp10 = A_arbace_test_A_const_25; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = A_arbace_test_testing_vars_str_fn__196000023_A_New(); var tmp13 *jrt.Class; A_arbace_test_testing_vars_str_fn__196000023_A_Init(); tmp13 = A_arbace_test_testing_vars_str_fn__196000023_A_fn_class; var tmp14 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var tmp15 *lang.Var; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_27; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp9.Invoke_O__O(tmp11.Invoke_O_O__O(tmp14, jrt.NN(tmp15).Get__O())), nil, file__4, nil, line__5, nil)).Ref() }


func A_arbace_test_testing_vars_str_fn__196000023_A_New() *A_arbace_test_testing_vars_str_fn__196000023_A { A_arbace_test_testing_vars_str_fn__196000023_A_Init(); t := &A_arbace_test_testing_vars_str_fn__196000023_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_test_testing_vars_str_fn__196000023_A) Ctor() {}
//line :298:1
func (t *A_arbace_test_testing_vars_str_fn__196000023_A) Invoke_O_O__O(self, p1__196000020_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_26; var tmp2 *lang.Keyword = tmp1; return jrt.NN(tmp2).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__196000020_SHARP___1)) }


func A_arbace_test_testing_contexts_str_A_New() *A_arbace_test_testing_contexts_str_A { A_arbace_test_testing_contexts_str_A_Init(); t := &A_arbace_test_testing_contexts_str_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_test_testing_contexts_str_A) Ctor() {}
//line :301:1
func (t *A_arbace_test_testing_contexts_str_A) Invoke_O__O(self any) any {




	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_15; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_28; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_29; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_24; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_30; return tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(Lit_243, tmp8.Invoke_O__O(jrt.NN(tmp9).Get__O())))
}
func A_arbace_test_inc_report_counter_A_New() *A_arbace_test_inc_report_counter_A { A_arbace_test_inc_report_counter_A_Init(); t := &A_arbace_test_inc_report_counter_A{}; t.Ctor(); return t }
//line :308:1
func (t *A_arbace_test_inc_report_counter_A) Ctor() {}
//line :308:1
func (t *A_arbace_test_inc_report_counter_A) Invoke_O_O__O(self, name__0 any) any {




	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_31; if jrt.A2g_Truth(jrt.NN(tmp1).Get__O()) {
		var tmp2 any = A_arbace_test_inc_report_counter_fn__196000027_A_New_O(name__0); var tmp3 *jrt.Class; A_arbace_test_inc_report_counter_fn__196000027_A_Init(); tmp3 = A_arbace_test_inc_report_counter_fn__196000027_A_fn_class; return lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) } else {
//line :313:1
			return nil } }
func A_arbace_test_inc_report_counter_fn__196000027_A_New_O(p0 any) *A_arbace_test_inc_report_counter_fn__196000027_A { A_arbace_test_inc_report_counter_fn__196000027_A_Init(); t := &A_arbace_test_inc_report_counter_fn__196000027_A{}; t.Ctor_O(p0); return t }
//line :314:1
func (t *A_arbace_test_inc_report_counter_fn__196000027_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :314:1
func (t *A_arbace_test_inc_report_counter_fn__196000027_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_31; var tmp4 any = jrt.NN(tmp3).Get__O(); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_32; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 any = lang.Tuple_Create_O__IPersistentVector(t.F_name); var tmp8 *lang.Var; A_arbace_test_A_Init(); tmp8 = A_arbace_test_A_const_33; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_test_A_Init(); tmp10 = A_arbace_test_A_const_34; var tmp11 any = jrt.NN(tmp10).GetRawRoot__O(); var tmp12 any; A_arbace_test_A_Init(); tmp12 = A_arbace_test_A_const_35; return tmp2.Invoke_O_O_O_O__O(tmp4, tmp6, tmp7, tmp9.Invoke_O_O__O(tmp11, tmp12)) }














func A_arbace_test_file_and_line_A_New() *A_arbace_test_file_and_line_A { A_arbace_test_file_and_line_A_Init(); t := &A_arbace_test_file_and_line_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_test_file_and_line_A) Ctor() {}
//line :329:1
func (t *A_arbace_test_file_and_line_A) Invoke_O_O_O__O(self, exception__0, depth__1 any) any { var stacktrace__3 any = jrt.Throwable_Cast(exception__0).GetStackTrace__StackTraceElement1().Ref(); if



	lang.Numbers_Lt_O_J__Z(depth__1, int64(lang.RT_Count_O__I(stacktrace__3))) { var s__4 any = lang.RT_Nth_O_I__O(stacktrace__3, lang.RT_IntCast_O__I(depth__1)); var tmp1 *lang.Keyword; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_22; var tmp2 any = tmp1.Ref(); var tmp3 any = jrt.NN(jrt.As[*jrt.StackTraceElement](s__4)).GetFileName__String().Ref(); var tmp4 *lang.Keyword; A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_23; var tmp5 any = tmp4.Ref(); return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp5, jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.As[*jrt.StackTraceElement](s__4)).GetLineNumber__I()).Ref())) } else { A_arbace_test_A_Init(); return A_arbace_test_A_const_36 } }




func A_arbace_test_stacktrace_file_and_line_A_New() *A_arbace_test_stacktrace_file_and_line_A { A_arbace_test_stacktrace_file_and_line_A_Init(); t := &A_arbace_test_stacktrace_file_and_line_A{}; t.Ctor(); return t }
//line :338:1
func (t *A_arbace_test_stacktrace_file_and_line_A) Ctor() {}
//line :338:1
func (t *A_arbace_test_stacktrace_file_and_line_A) Invoke_O_O__O(self, stacktrace__0 any) any {

	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_11; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(stacktrace__0)) { var s__2 any; var tmp2 *lang.Var
		A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_21; s__2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(stacktrace__0)
//line :340:1
		var tmp3 *lang.Keyword; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_22; var tmp4 any = tmp3.Ref(); var tmp5 any = jrt.NN(jrt.As[*jrt.StackTraceElement](s__2)).GetFileName__String().Ref(); var tmp6 *lang.Keyword; A_arbace_test_A_Init(); tmp6 = A_arbace_test_A_const_23; var tmp7 any = tmp6.Ref(); return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp7, jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.As[*jrt.StackTraceElement](s__2)).GetLineNumber__I()).Ref())) } else { A_arbace_test_A_Init(); return A_arbace_test_A_const_37
		}
}


func A_arbace_test_do_report_A_New() *A_arbace_test_do_report_A { A_arbace_test_do_report_A_Init(); t := &A_arbace_test_do_report_A{}; t.Ctor(); return t }
//line :345:1
func (t *A_arbace_test_do_report_A) Ctor() {}
//line :345:1
func (t *A_arbace_test_do_report_A) Invoke_O_O__O(self, m__0 any) any {





	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_38; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).Get__O()); var tmp3 any; var G__196000035__2_ any; var tmp4 *lang.Keyword

	A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_39; G__196000035__2_ = jrt.NN(tmp4).Invoke_O__O(m__0)
//line :352:1
L1: switch { default: switch lang.Util_Hash_O__I(G__196000035__2_) >> 0 & 1 { case 0: var tmp5 *lang.Keyword; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_40; if any(G__196000035__2_) == any(tmp5.Ref()) {







	var tmp6 *lang.Var; A_arbace_test_A_Init(); tmp6 = A_arbace_test_A_const_41; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_test_A_Init(); tmp8 = A_arbace_test_A_const_43; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_test_A_Init(); tmp10 = A_arbace_test_A_const_44; tmp3 = tmp7.Invoke_O_O__O(tmp9.Invoke_O__O(jrt.Throwable_Cast(jrt.NN(tmp10).Invoke_O__O(m__0)).GetStackTrace__StackTraceElement1().Ref()), m__0)
//line :352:1
	break L1 }; case 1: var tmp11 *lang.Keyword; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_42; if any(G__196000035__2_) == any(tmp11.Ref()) {

		var tmp12 *lang.Var; A_arbace_test_A_Init(); tmp12 = A_arbace_test_A_const_41; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_test_A_Init(); tmp14 = A_arbace_test_A_const_43; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_test_A_Init(); tmp16 = A_arbace_test_A_const_45; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any = A_arbace_test_do_report_fn__196000036_A_New(); var tmp19 *jrt.Class; A_arbace_test_do_report_fn__196000036_A_Init(); tmp19 = A_arbace_test_do_report_fn__196000036_A_fn_class; tmp3 = tmp13.Invoke_O_O__O(tmp15.Invoke_O__O(tmp17.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil), jrt.Thread_CurrentThread__Thread().GetStackTrace__StackTraceElement1().Ref())), m__0)
//line :352:1
		break L1 }; default:}; tmp3 = m__0}
//line :351:1
	return tmp2.Invoke_O__O(tmp3)
}

func A_arbace_test_do_report_fn__196000036_A_New() *A_arbace_test_do_report_fn__196000036_A { A_arbace_test_do_report_fn__196000036_A_Init(); t := &A_arbace_test_do_report_fn__196000036_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_test_do_report_fn__196000036_A) Ctor() {}
//line :354:1
func (t *A_arbace_test_do_report_fn__196000036_A) Invoke_O_O__O(self, p1__196000034_SHARP___1 any) any { var cl_name__2 any = jrt.NN(jrt.As[*jrt.StackTraceElement](p1__196000034_SHARP___1)).GetClassName__String().Ref(); var or__1927000174__auto____3 any; var tmp1 *lang.Var;

	A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_46; or__1927000174__auto____3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(cl_name__2, Lit_175); if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var tmp2 *lang.Var
		A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_46; or__1927000174__auto____4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(cl_name__2, Lit_176)
//line :356:1
		if jrt.A2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {

			var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_46; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(cl_name__2, Lit_177) } } }




func A_arbace_test_eval196000039_fn__196000040_A_New() *A_arbace_test_eval196000039_fn__196000040_A { A_arbace_test_eval196000039_fn__196000040_A_Init(); t := &A_arbace_test_eval196000039_fn__196000040_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_test_eval196000039_fn__196000040_A) Ctor() {}
//line :363:1
func (t *A_arbace_test_eval196000039_fn__196000040_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_49; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_50; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_51; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_52; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :363:1
	var tmp8 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_47; tmp8 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(m__1) }
//line :363:1
		return nil }(); var tmp11 *lang.Var
	A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_48; lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke__O()
//line :363:1
	if tmp10 != nil { panic(tmp10) }; return tmp8
}

func A_arbace_test_eval196000043_fn__196000044_A_New() *A_arbace_test_eval196000043_fn__196000044_A { A_arbace_test_eval196000043_fn__196000044_A_Init(); t := &A_arbace_test_eval196000043_fn__196000044_A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_test_eval196000043_fn__196000044_A) Ctor() {}
//line :366:1
func (t *A_arbace_test_eval196000043_fn__196000044_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_49; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_50; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_51; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_52; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :366:1
	var tmp8 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_53; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_54; tmp8 = tmp10.Invoke_O__O(tmp11.Ref()) }
//line :366:1
		return nil }(); var tmp13 *lang.Var
	A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_48; lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke__O()
//line :366:1
	if tmp12 != nil { panic(tmp12) }; return tmp8
}

func A_arbace_test_eval196000047_fn__196000048_A_New() *A_arbace_test_eval196000047_fn__196000048_A { A_arbace_test_eval196000047_fn__196000048_A_Init(); t := &A_arbace_test_eval196000047_fn__196000048_A{}; t.Ctor(); return t }
//line :369:1
func (t *A_arbace_test_eval196000047_fn__196000048_A) Ctor() {}
//line :369:1
func (t *A_arbace_test_eval196000047_fn__196000048_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_49; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_50; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_51; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_52; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :369:1
	var tmp8 any; tmp33 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_53; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_42; tmp10.Invoke_O__O(tmp11.Ref())
			var tmp12 *lang.Var; A_arbace_test_A_Init(); tmp12 = A_arbace_test_A_const_55; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_test_A_Init(); tmp14 = A_arbace_test_A_const_57; tmp13.Invoke_O_O__O(Lit_183, lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(m__1))
			var tmp15 *lang.Var; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_11; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_30; if jrt.A2g_Truth(tmp16.Invoke_O__O(jrt.NN(tmp17).Get__O())) { var tmp18 *lang.Var; A_arbace_test_A_Init(); tmp18 = A_arbace_test_A_const_55; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_test_A_Init(); tmp20 = A_arbace_test_A_const_58; tmp19.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke__O()) }
//line :369:1
			var temp__1927000414__auto____4 any; var tmp21 *lang.Keyword




			A_arbace_test_A_Init(); tmp21 = A_arbace_test_A_const_56; temp__1927000414__auto____4 = jrt.NN(tmp21).Invoke_O__O(m__1); if jrt.A2g_Truth(temp__1927000414__auto____4) { var message__5 any = temp__1927000414__auto____4; var tmp22 *lang.Var; A_arbace_test_A_Init(); tmp22 = A_arbace_test_A_const_55; lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(message__5) }
			var tmp23 *lang.Var; A_arbace_test_A_Init(); tmp23 = A_arbace_test_A_const_55; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_59; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_test_A_Init(); tmp27 = A_arbace_test_A_const_60; tmp24.Invoke_O_O__O(Lit_184, tmp26.Invoke_O__O(jrt.NN(tmp27).Invoke_O__O(m__1)))
			var tmp28 *lang.Var; A_arbace_test_A_Init(); tmp28 = A_arbace_test_A_const_55; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_test_A_Init(); tmp30 = A_arbace_test_A_const_59; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Keyword; A_arbace_test_A_Init(); tmp32 = A_arbace_test_A_const_44; tmp8 = tmp29.Invoke_O_O__O(Lit_185, tmp31.Invoke_O__O(jrt.NN(tmp32).Invoke_O__O(m__1))) }
//line :369:1
		return nil }(); var tmp34 *lang.Var
	A_arbace_test_A_Init(); tmp34 = A_arbace_test_A_const_48; lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke__O()
//line :369:1
	if tmp33 != nil { panic(tmp33) }; return tmp8
}







func A_arbace_test_eval196000051_fn__196000052_A_New() *A_arbace_test_eval196000051_fn__196000052_A { A_arbace_test_eval196000051_fn__196000052_A_Init(); t := &A_arbace_test_eval196000051_fn__196000052_A{}; t.Ctor(); return t }
//line :378:1
func (t *A_arbace_test_eval196000051_fn__196000052_A) Ctor() {}
//line :378:1
func (t *A_arbace_test_eval196000051_fn__196000052_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_49; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_50; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_51; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_52; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :378:1
	var tmp8 any; tmp34 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_53; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_40; tmp10.Invoke_O__O(tmp11.Ref())
			var tmp12 *lang.Var; A_arbace_test_A_Init(); tmp12 = A_arbace_test_A_const_55; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_test_A_Init(); tmp14 = A_arbace_test_A_const_57; tmp13.Invoke_O_O__O(Lit_187, lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(m__1))
			var tmp15 *lang.Var; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_11; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_30; if jrt.A2g_Truth(tmp16.Invoke_O__O(jrt.NN(tmp17).Get__O())) { var tmp18 *lang.Var; A_arbace_test_A_Init(); tmp18 = A_arbace_test_A_const_55; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_test_A_Init(); tmp20 = A_arbace_test_A_const_58; tmp19.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke__O()) }
//line :378:1
			var temp__1927000414__auto____4 any; var tmp21 *lang.Keyword




			A_arbace_test_A_Init(); tmp21 = A_arbace_test_A_const_56; temp__1927000414__auto____4 = jrt.NN(tmp21).Invoke_O__O(m__1); if jrt.A2g_Truth(temp__1927000414__auto____4) { var message__5 any = temp__1927000414__auto____4; var tmp22 *lang.Var; A_arbace_test_A_Init(); tmp22 = A_arbace_test_A_const_55; lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(message__5) }
			var tmp23 *lang.Var; A_arbace_test_A_Init(); tmp23 = A_arbace_test_A_const_55; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_59; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_test_A_Init(); tmp27 = A_arbace_test_A_const_60; tmp24.Invoke_O_O__O(Lit_184, tmp26.Invoke_O__O(jrt.NN(tmp27).Invoke_O__O(m__1)))
			var tmp28 *lang.Var; A_arbace_test_A_Init(); tmp28 = A_arbace_test_A_const_62; lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(Lit_188)
//line :378:1
			var actual__4 any; var tmp29 *lang.Keyword







			A_arbace_test_A_Init(); tmp29 = A_arbace_test_A_const_44; actual__4 = jrt.NN(tmp29).Invoke_O__O(m__1)
			if jrt.Throwable_InstanceOf(actual__4) {
				var tmp30 *lang.Var; A_arbace_test_A_Init(); tmp30 = A_arbace_test_A_const_61; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_test_A_Init(); tmp32 = A_arbace_test_A_const_63; tmp8 = tmp31.Invoke_O_O__O(actual__4, jrt.NN(tmp32).Get__O()) } else {
					var tmp33 *lang.Var; A_arbace_test_A_Init(); tmp33 = A_arbace_test_A_const_47; tmp8 = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(actual__4) } }
//line :378:1
		return nil }(); var tmp35 *lang.Var
	A_arbace_test_A_Init(); tmp35 = A_arbace_test_A_const_48; lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke__O()
//line :378:1
	if tmp34 != nil { panic(tmp34) }; return tmp8
}











func A_arbace_test_eval196000055_fn__196000056_A_New() *A_arbace_test_eval196000055_fn__196000056_A { A_arbace_test_eval196000055_fn__196000056_A_Init(); t := &A_arbace_test_eval196000055_fn__196000056_A{}; t.Ctor(); return t }
//line :391:1
func (t *A_arbace_test_eval196000055_fn__196000056_A) Ctor() {}
//line :391:1
func (t *A_arbace_test_eval196000055_fn__196000056_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_49; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_50; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_51; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_52; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :391:1
	var tmp8 any; tmp23 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_55; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_64; var tmp12 any = jrt.NN(tmp11).Invoke_O__O(m__1); var tmp13 *lang.Keyword; A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_54; var tmp14 any = jrt.NN(tmp13).Invoke_O__O(m__1); var tmp15 *lang.Keyword; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_42; var tmp16 any = lang.Numbers_Add_O_O__Number(tmp14, jrt.NN(tmp15).Invoke_O__O(m__1)); var tmp17 *lang.Keyword; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_40; tmp10.Invoke_O_O_O_O_O__O(Lit_190, tmp12, Lit_191, lang.Numbers_Add_O_O__Number(tmp16, jrt.NN(tmp17).Invoke_O__O(m__1)), Lit_192)

			var tmp18 *lang.Var; A_arbace_test_A_Init(); tmp18 = A_arbace_test_A_const_55; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Keyword; A_arbace_test_A_Init(); tmp20 = A_arbace_test_A_const_42; var tmp21 any = jrt.NN(tmp20).Invoke_O__O(m__1); var tmp22 *lang.Keyword; A_arbace_test_A_Init(); tmp22 = A_arbace_test_A_const_40; tmp8 = tmp19.Invoke_O_O_O_O__O(tmp21, Lit_193, jrt.NN(tmp22).Invoke_O__O(m__1), Lit_194) }
//line :391:1
		return nil }(); var tmp24 *lang.Var
	A_arbace_test_A_Init(); tmp24 = A_arbace_test_A_const_48; lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke__O()
//line :391:1
	if tmp23 != nil { panic(tmp23) }; return tmp8
}




func A_arbace_test_eval196000059_fn__196000060_A_New() *A_arbace_test_eval196000059_fn__196000060_A { A_arbace_test_eval196000059_fn__196000060_A_Init(); t := &A_arbace_test_eval196000059_fn__196000060_A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_test_eval196000059_fn__196000060_A) Ctor() {}
//line :397:1
func (t *A_arbace_test_eval196000059_fn__196000060_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_49; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_50; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_51; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_52; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :397:1
	var tmp8 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_55; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_65; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Keyword; A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_66; tmp8 = tmp10.Invoke_O_O__O(Lit_196, tmp12.Invoke_O__O(jrt.NN(tmp13).Invoke_O__O(m__1))) }
//line :397:1
		return nil }(); var tmp15 *lang.Var
	A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_48; lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke__O()
//line :397:1
	if tmp14 != nil { panic(tmp14) }; return tmp8
}



func A_arbace_test_eval196000063_fn__196000064_A_New() *A_arbace_test_eval196000063_fn__196000064_A { A_arbace_test_eval196000063_fn__196000064_A_Init(); t := &A_arbace_test_eval196000063_fn__196000064_A{}; t.Ctor(); return t }
//line :402:1
func (t *A_arbace_test_eval196000063_fn__196000064_A) Ctor() {}
//line :402:1
func (t *A_arbace_test_eval196000063_fn__196000064_A) Invoke_O_O__O(self, m__1 any) any { return nil }
func A_arbace_test_eval196000067_fn__196000068_A_New() *A_arbace_test_eval196000067_fn__196000068_A { A_arbace_test_eval196000067_fn__196000068_A_Init(); t := &A_arbace_test_eval196000067_fn__196000068_A{}; t.Ctor(); return t }
//line :403:1
func (t *A_arbace_test_eval196000067_fn__196000068_A) Ctor() {}
//line :403:1
func (t *A_arbace_test_eval196000067_fn__196000068_A) Invoke_O_O__O(self, m__1 any) any { return nil }
func A_arbace_test_eval196000071_fn__196000072_A_New() *A_arbace_test_eval196000071_fn__196000072_A { A_arbace_test_eval196000071_fn__196000072_A_Init(); t := &A_arbace_test_eval196000071_fn__196000072_A{}; t.Ctor(); return t }
//line :404:1
func (t *A_arbace_test_eval196000071_fn__196000072_A) Ctor() {}
//line :404:1
func (t *A_arbace_test_eval196000071_fn__196000072_A) Invoke_O_O__O(self, m__1 any) any { return nil }



func A_arbace_test_get_possibly_unbound_var_A_New() *A_arbace_test_get_possibly_unbound_var_A { A_arbace_test_get_possibly_unbound_var_A_Init(); t := &A_arbace_test_get_possibly_unbound_var_A{}; t.Ctor(); return t }
//line :408:1
func (t *A_arbace_test_get_possibly_unbound_var_A) Ctor() {}
//line :408:1
func (t *A_arbace_test_get_possibly_unbound_var_A) Invoke_O_O__O(self, v__0 any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



	{ var tmp2 *lang.Var; A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_67; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(v__0) }
//line :408:1
	return nil }(); if tmp3 != nil { if jrt.IllegalStateException_InstanceOf(tmp3) { var e__4 jrt.IllegalStateException_I = jrt.IllegalStateException_Cast(tmp3); _ = e__4; tmp1 = nil } else { panic(tmp3) } }; return tmp1 }







func A_arbace_test_function_QMARK__A_New() *A_arbace_test_function_QMARK__A { A_arbace_test_function_QMARK__A_Init(); t := &A_arbace_test_function_QMARK__A{}; t.Ctor(); return t }
//line :416:1
func (t *A_arbace_test_function_QMARK__A) Ctor() {}
//line :416:1
func (t *A_arbace_test_function_QMARK__A) Invoke_O_O__O(self, x__0 any) any {




	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_68; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0)) { var temp__1927000414__auto____2 any; var tmp2 *lang.Var
		A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_69; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(temp__1927000414__auto____2) { var v__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any; var tmp3 *lang.Var
			A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_70; temp__1927000414__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(v__3); if jrt.A2g_Truth(temp__1927000414__auto____4) { var value__5 any = temp__1927000414__auto____4; var and__1927000168__auto____6 any; var tmp4 *lang.Var
				A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_71; and__1927000168__auto____6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(value__5); if jrt.A2g_Truth(and__1927000168__auto____6) {
					var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_72; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_73; var tmp8 *lang.Keyword = tmp7; return tmp6.Invoke_O__O(jrt.NN(tmp8).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__3))) } else {
//line :424:1
						return and__1927000168__auto____6 } } else {
//line :423:1
							return nil } } else {
//line :422:1
								return nil } } else {



									var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_71; return lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(x__0)
								} }
func A_arbace_test_assert_predicate_A_New() *A_arbace_test_assert_predicate_A { A_arbace_test_assert_predicate_A_Init(); t := &A_arbace_test_assert_predicate_A{}; t.Ctor(); return t }
//line :428:1
func (t *A_arbace_test_assert_predicate_A) Ctor() {}
//line :428:1
func (t *A_arbace_test_assert_predicate_A) Invoke_O_O_O__O(self, msg__0, form__1 any) any { var args__3 any; var tmp1 *lang.Var;







	A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_74; args__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(form__1); var pred__4 any; var tmp2 /*line :428:1*/*lang.Var;








	A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_21; pred__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(form__1); var tmp3 /*line :436:1*/*lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_11; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_12; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_13; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_75; var tmp10 any = tmp8.Invoke_O__O(tmp9); var tmp11 *lang.Var; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_13; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_15; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_16; var tmp16 any = jrt.NN(tmp15).GetRawRoot__O(); var tmp17 *lang.Var; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_11; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_test_A_Init(); tmp19 = A_arbace_test_A_const_12; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_test_A_Init(); tmp21 = A_arbace_test_A_const_13; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any; A_arbace_test_A_Init(); tmp23 = A_arbace_test_A_const_76; var tmp24 any = tmp22.Invoke_O__O(tmp23); var tmp25 *lang.Var; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_13; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_test_A_Init(); tmp27 = A_arbace_test_A_const_11; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_test_A_Init(); tmp29 = A_arbace_test_A_const_12; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_test_A_Init(); tmp31 = A_arbace_test_A_const_13; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 any; A_arbace_test_A_Init(); tmp33 = A_arbace_test_A_const_77; var tmp34 any = tmp26.Invoke_O__O(tmp28.Invoke_O__O(tmp30.Invoke_O_O__O(tmp32.Invoke_O__O(tmp33), args__3))); var tmp35 *lang.Var; A_arbace_test_A_Init(); tmp35 = A_arbace_test_A_const_13; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any; A_arbace_test_A_Init(); tmp37 = A_arbace_test_A_const_78; var tmp38 any = tmp36.Invoke_O__O(tmp37); var tmp39 *lang.Var; A_arbace_test_A_Init(); tmp39 = A_arbace_test_A_const_13; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 *lang.Var; A_arbace_test_A_Init(); tmp41 = A_arbace_test_A_const_11; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Var; A_arbace_test_A_Init(); tmp43 = A_arbace_test_A_const_12; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Var; A_arbace_test_A_Init(); tmp45 = A_arbace_test_A_const_13; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 any; A_arbace_test_A_Init(); tmp47 = A_arbace_test_A_const_79; var tmp48 any = tmp46.Invoke_O__O(tmp47); var tmp49 *lang.Var; A_arbace_test_A_Init(); tmp49 = A_arbace_test_A_const_13; var tmp50 any = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()).Invoke_O__O(pred__4); var tmp51 *lang.Var; A_arbace_test_A_Init(); tmp51 = A_arbace_test_A_const_13; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 any; A_arbace_test_A_Init(); tmp53 = A_arbace_test_A_const_76; var tmp54 any = tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp16, tmp18.Invoke_O__O(tmp20.Invoke_O_O_O_O__O(tmp24, tmp34, tmp38, tmp40.Invoke_O__O(tmp42.Invoke_O__O(tmp44.Invoke_O_O_O__O(tmp48, tmp50, tmp52.Invoke_O__O(tmp53)))))))); var tmp55 *lang.Var; A_arbace_test_A_Init(); tmp55 = A_arbace_test_A_const_13; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.Var; A_arbace_test_A_Init(); tmp57 = A_arbace_test_A_const_11; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 *lang.Var; A_arbace_test_A_Init(); tmp59 = A_arbace_test_A_const_12; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 *lang.Var; A_arbace_test_A_Init(); tmp61 = A_arbace_test_A_const_13; var tmp62 lang.IFn = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()); var tmp63 any; A_arbace_test_A_Init(); tmp63 = A_arbace_test_A_const_80; var tmp64 any = tmp62.Invoke_O__O(tmp63); var tmp65 *lang.Var; A_arbace_test_A_Init(); tmp65 = A_arbace_test_A_const_13; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 any; A_arbace_test_A_Init(); tmp67 = A_arbace_test_A_const_78; var tmp68 any = tmp66.Invoke_O__O(tmp67); var tmp69 *lang.Var; A_arbace_test_A_Init(); tmp69 = A_arbace_test_A_const_13; var tmp70 lang.IFn = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()); var tmp71 *lang.Var; A_arbace_test_A_Init(); tmp71 = A_arbace_test_A_const_11; var tmp72 lang.IFn = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()); var tmp73 *lang.Var; A_arbace_test_A_Init(); tmp73 = A_arbace_test_A_const_12; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *lang.Var; A_arbace_test_A_Init(); tmp75 = A_arbace_test_A_const_13; var tmp76 lang.IFn = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()); var tmp77 any; A_arbace_test_A_Init(); tmp77 = A_arbace_test_A_const_81; var tmp78 any = tmp76.Invoke_O__O(tmp77); var tmp79 *lang.Var; A_arbace_test_A_Init(); tmp79 = A_arbace_test_A_const_13; var tmp80 lang.IFn = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()); var tmp81 *lang.Var; A_arbace_test_A_Init(); tmp81 = A_arbace_test_A_const_15; var tmp82 lang.IFn = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()); var tmp83 *lang.Var; A_arbace_test_A_Init(); tmp83 = A_arbace_test_A_const_50; var tmp84 any = jrt.NN(tmp83).GetRawRoot__O(); var tmp85 *lang.Var; A_arbace_test_A_Init(); tmp85 = A_arbace_test_A_const_11; var tmp86 lang.IFn = lang.IFn_Cast(jrt.NN(tmp85).GetRawRoot__O()); var tmp87 *lang.Var; A_arbace_test_A_Init(); tmp87 = A_arbace_test_A_const_12; var tmp88 lang.IFn = lang.IFn_Cast(jrt.NN(tmp87).GetRawRoot__O()); var tmp89 *lang.Var; A_arbace_test_A_Init(); tmp89 = A_arbace_test_A_const_13; var tmp90 lang.IFn = lang.IFn_Cast(jrt.NN(tmp89).GetRawRoot__O()); var tmp91 *lang.Keyword; A_arbace_test_A_Init(); tmp91 = A_arbace_test_A_const_39; var tmp92 any = tmp90.Invoke_O__O(tmp91.Ref()); var tmp93 *lang.Var; A_arbace_test_A_Init(); tmp93 = A_arbace_test_A_const_13; var tmp94 lang.IFn = lang.IFn_Cast(jrt.NN(tmp93).GetRawRoot__O()); var tmp95 *lang.Keyword; A_arbace_test_A_Init(); tmp95 = A_arbace_test_A_const_54; var tmp96 any = tmp94.Invoke_O__O(tmp95.Ref()); var tmp97 *lang.Var; A_arbace_test_A_Init(); tmp97 = A_arbace_test_A_const_13; var tmp98 lang.IFn = lang.IFn_Cast(jrt.NN(tmp97).GetRawRoot__O()); var tmp99 *lang.Keyword; A_arbace_test_A_Init(); tmp99 = A_arbace_test_A_const_56; var tmp100 any = tmp98.Invoke_O__O(tmp99.Ref()); var tmp101 *lang.Var; A_arbace_test_A_Init(); tmp101 = A_arbace_test_A_const_13; var tmp102 any = lang.IFn_Cast(jrt.NN(tmp101).GetRawRoot__O()).Invoke_O__O(msg__0); var tmp103 *lang.Var; A_arbace_test_A_Init(); tmp103 = A_arbace_test_A_const_13; var tmp104 lang.IFn = lang.IFn_Cast(jrt.NN(tmp103).GetRawRoot__O()); var tmp105 *lang.Keyword; A_arbace_test_A_Init(); tmp105 = A_arbace_test_A_const_60; var tmp106 any = tmp104.Invoke_O__O(tmp105.Ref()); var tmp107 *lang.Var; A_arbace_test_A_Init(); tmp107 = A_arbace_test_A_const_13; var tmp108 lang.IFn = lang.IFn_Cast(jrt.NN(tmp107).GetRawRoot__O()); var tmp109 *lang.Var; A_arbace_test_A_Init(); tmp109 = A_arbace_test_A_const_11; var tmp110 lang.IFn = lang.IFn_Cast(jrt.NN(tmp109).GetRawRoot__O()); var tmp111 *lang.Var; A_arbace_test_A_Init(); tmp111 = A_arbace_test_A_const_12; var tmp112 lang.IFn = lang.IFn_Cast(jrt.NN(tmp111).GetRawRoot__O()); var tmp113 *lang.Var; A_arbace_test_A_Init(); tmp113 = A_arbace_test_A_const_13; var tmp114 lang.IFn = lang.IFn_Cast(jrt.NN(tmp113).GetRawRoot__O()); var tmp115 any; A_arbace_test_A_Init(); tmp115 = A_arbace_test_A_const_82; var tmp116 any = tmp114.Invoke_O__O(tmp115); var tmp117 *lang.Var; A_arbace_test_A_Init(); tmp117 = A_arbace_test_A_const_13; var tmp118 any = tmp108.Invoke_O__O(tmp110.Invoke_O__O(tmp112.Invoke_O_O__O(tmp116, lang.IFn_Cast(jrt.NN(tmp117).GetRawRoot__O()).Invoke_O__O(form__1)))); var tmp119 *lang.Var; A_arbace_test_A_Init(); tmp119 = A_arbace_test_A_const_13; var tmp120 lang.IFn = lang.IFn_Cast(jrt.NN(tmp119).GetRawRoot__O()); var tmp121 *lang.Keyword; A_arbace_test_A_Init(); tmp121 = A_arbace_test_A_const_44; var tmp122 any = tmp120.Invoke_O__O(tmp121.Ref()); var tmp123 *lang.Var; A_arbace_test_A_Init(); tmp123 = A_arbace_test_A_const_13; var tmp124 lang.IFn = lang.IFn_Cast(jrt.NN(tmp123).GetRawRoot__O()); var tmp125 *lang.Var; A_arbace_test_A_Init(); tmp125 = A_arbace_test_A_const_11; var tmp126 lang.IFn = lang.IFn_Cast(jrt.NN(tmp125).GetRawRoot__O()); var tmp127 *lang.Var; A_arbace_test_A_Init(); tmp127 = A_arbace_test_A_const_12; var tmp128 lang.IFn = lang.IFn_Cast(jrt.NN(tmp127).GetRawRoot__O()); var tmp129 *lang.Var; A_arbace_test_A_Init(); tmp129 = A_arbace_test_A_const_13; var tmp130 lang.IFn = lang.IFn_Cast(jrt.NN(tmp129).GetRawRoot__O()); var tmp131 any; A_arbace_test_A_Init(); tmp131 = A_arbace_test_A_const_83; var tmp132 any = tmp130.Invoke_O__O(tmp131); var tmp133 *lang.Var; A_arbace_test_A_Init(); tmp133 = A_arbace_test_A_const_13; var tmp134 lang.IFn = lang.IFn_Cast(jrt.NN(tmp133).GetRawRoot__O()); var tmp135 *lang.Var; A_arbace_test_A_Init(); tmp135 = A_arbace_test_A_const_11; var tmp136 lang.IFn = lang.IFn_Cast(jrt.NN(tmp135).GetRawRoot__O()); var tmp137 *lang.Var; A_arbace_test_A_Init(); tmp137 = A_arbace_test_A_const_12; var tmp138 lang.IFn = lang.IFn_Cast(jrt.NN(tmp137).GetRawRoot__O()); var tmp139 *lang.Var; A_arbace_test_A_Init(); tmp139 = A_arbace_test_A_const_13; var tmp140 lang.IFn = lang.IFn_Cast(jrt.NN(tmp139).GetRawRoot__O()); var tmp141 any; A_arbace_test_A_Init(); tmp141 = A_arbace_test_A_const_82; var tmp142 any = tmp140.Invoke_O__O(tmp141); var tmp143 *lang.Var; A_arbace_test_A_Init(); tmp143 = A_arbace_test_A_const_13; var tmp144 any = tmp134.Invoke_O__O(tmp136.Invoke_O__O(tmp138.Invoke_O_O__O(tmp142, lang.IFn_Cast(jrt.NN(tmp143).GetRawRoot__O()).Invoke_O__O(pred__4)))); var tmp145 *lang.Var; A_arbace_test_A_Init(); tmp145 = A_arbace_test_A_const_13; var tmp146 lang.IFn = lang.IFn_Cast(jrt.NN(tmp145).GetRawRoot__O()); var tmp147 any; A_arbace_test_A_Init(); tmp147 = A_arbace_test_A_const_76; var tmp148 any = tmp70.Invoke_O__O(tmp72.Invoke_O__O(tmp74.Invoke_O_O__O(tmp78, tmp80.Invoke_O__O(tmp82.Invoke_O_O__O(tmp84, tmp86.Invoke_O__O(tmp88.Invoke_O_O_O_O_O_O_O_O__O(tmp92, tmp96, tmp100, tmp102, tmp106, tmp118, tmp122, tmp124.Invoke_O__O(tmp126.Invoke_O__O(tmp128.Invoke_O_O_O__O(tmp132, tmp144, tmp146.Invoke_O__O(tmp147))))))))))); var tmp149 *lang.Var; A_arbace_test_A_Init(); tmp149 = A_arbace_test_A_const_13; var tmp150 lang.IFn = lang.IFn_Cast(jrt.NN(tmp149).GetRawRoot__O()); var tmp151 *lang.Var; A_arbace_test_A_Init(); tmp151 = A_arbace_test_A_const_11; var tmp152 lang.IFn = lang.IFn_Cast(jrt.NN(tmp151).GetRawRoot__O()); var tmp153 *lang.Var; A_arbace_test_A_Init(); tmp153 = A_arbace_test_A_const_12; var tmp154 lang.IFn = lang.IFn_Cast(jrt.NN(tmp153).GetRawRoot__O()); var tmp155 *lang.Var; A_arbace_test_A_Init(); tmp155 = A_arbace_test_A_const_13; var tmp156 lang.IFn = lang.IFn_Cast(jrt.NN(tmp155).GetRawRoot__O()); var tmp157 any; A_arbace_test_A_Init(); tmp157 = A_arbace_test_A_const_84; var tmp158 any = tmp156.Invoke_O__O(tmp157); var tmp159 *lang.Var; A_arbace_test_A_Init(); tmp159 = A_arbace_test_A_const_13; var tmp160 lang.IFn = lang.IFn_Cast(jrt.NN(tmp159).GetRawRoot__O()); var tmp161 *lang.Var; A_arbace_test_A_Init(); tmp161 = A_arbace_test_A_const_15; var tmp162 lang.IFn = lang.IFn_Cast(jrt.NN(tmp161).GetRawRoot__O()); var tmp163 *lang.Var; A_arbace_test_A_Init(); tmp163 = A_arbace_test_A_const_50; var tmp164 any = jrt.NN(tmp163).GetRawRoot__O(); var tmp165 *lang.Var; A_arbace_test_A_Init(); tmp165 = A_arbace_test_A_const_11; var tmp166 lang.IFn = lang.IFn_Cast(jrt.NN(tmp165).GetRawRoot__O()); var tmp167 *lang.Var; A_arbace_test_A_Init(); tmp167 = A_arbace_test_A_const_12; var tmp168 lang.IFn = lang.IFn_Cast(jrt.NN(tmp167).GetRawRoot__O()); var tmp169 *lang.Var; A_arbace_test_A_Init(); tmp169 = A_arbace_test_A_const_13; var tmp170 lang.IFn = lang.IFn_Cast(jrt.NN(tmp169).GetRawRoot__O()); var tmp171 *lang.Keyword; A_arbace_test_A_Init(); tmp171 = A_arbace_test_A_const_39; var tmp172 any = tmp170.Invoke_O__O(tmp171.Ref()); var tmp173 *lang.Var; A_arbace_test_A_Init(); tmp173 = A_arbace_test_A_const_13; var tmp174 lang.IFn = lang.IFn_Cast(jrt.NN(tmp173).GetRawRoot__O()); var tmp175 *lang.Keyword; A_arbace_test_A_Init(); tmp175 = A_arbace_test_A_const_42; var tmp176 any = tmp174.Invoke_O__O(tmp175.Ref()); var tmp177 *lang.Var; A_arbace_test_A_Init(); tmp177 = A_arbace_test_A_const_13; var tmp178 lang.IFn = lang.IFn_Cast(jrt.NN(tmp177).GetRawRoot__O()); var tmp179 *lang.Keyword; A_arbace_test_A_Init(); tmp179 = A_arbace_test_A_const_56; var tmp180 any = tmp178.Invoke_O__O(tmp179.Ref()); var tmp181 *lang.Var; A_arbace_test_A_Init(); tmp181 = A_arbace_test_A_const_13; var tmp182 any = lang.IFn_Cast(jrt.NN(tmp181).GetRawRoot__O()).Invoke_O__O(msg__0); var tmp183 *lang.Var; A_arbace_test_A_Init(); tmp183 = A_arbace_test_A_const_13; var tmp184 lang.IFn = lang.IFn_Cast(jrt.NN(tmp183).GetRawRoot__O()); var tmp185 *lang.Keyword; A_arbace_test_A_Init(); tmp185 = A_arbace_test_A_const_60; var tmp186 any = tmp184.Invoke_O__O(tmp185.Ref()); var tmp187 *lang.Var; A_arbace_test_A_Init(); tmp187 = A_arbace_test_A_const_13; var tmp188 lang.IFn = lang.IFn_Cast(jrt.NN(tmp187).GetRawRoot__O()); var tmp189 *lang.Var; A_arbace_test_A_Init(); tmp189 = A_arbace_test_A_const_11; var tmp190 lang.IFn = lang.IFn_Cast(jrt.NN(tmp189).GetRawRoot__O()); var tmp191 *lang.Var; A_arbace_test_A_Init(); tmp191 = A_arbace_test_A_const_12; var tmp192 lang.IFn = lang.IFn_Cast(jrt.NN(tmp191).GetRawRoot__O()); var tmp193 *lang.Var; A_arbace_test_A_Init(); tmp193 = A_arbace_test_A_const_13; var tmp194 lang.IFn = lang.IFn_Cast(jrt.NN(tmp193).GetRawRoot__O()); var tmp195 any; A_arbace_test_A_Init(); tmp195 = A_arbace_test_A_const_82; var tmp196 any = tmp194.Invoke_O__O(tmp195); var tmp197 *lang.Var; A_arbace_test_A_Init(); tmp197 = A_arbace_test_A_const_13; var tmp198 any = tmp188.Invoke_O__O(tmp190.Invoke_O__O(tmp192.Invoke_O_O__O(tmp196, lang.IFn_Cast(jrt.NN(tmp197).GetRawRoot__O()).Invoke_O__O(form__1)))); var tmp199 *lang.Var; A_arbace_test_A_Init(); tmp199 = A_arbace_test_A_const_13; var tmp200 lang.IFn = lang.IFn_Cast(jrt.NN(tmp199).GetRawRoot__O()); var tmp201 *lang.Keyword; A_arbace_test_A_Init(); tmp201 = A_arbace_test_A_const_44; var tmp202 any = tmp200.Invoke_O__O(tmp201.Ref()); var tmp203 *lang.Var; A_arbace_test_A_Init(); tmp203 = A_arbace_test_A_const_13; var tmp204 lang.IFn = lang.IFn_Cast(jrt.NN(tmp203).GetRawRoot__O()); var tmp205 *lang.Var; A_arbace_test_A_Init(); tmp205 = A_arbace_test_A_const_11; var tmp206 lang.IFn = lang.IFn_Cast(jrt.NN(tmp205).GetRawRoot__O()); var tmp207 *lang.Var; A_arbace_test_A_Init(); tmp207 = A_arbace_test_A_const_12; var tmp208 lang.IFn = lang.IFn_Cast(jrt.NN(tmp207).GetRawRoot__O()); var tmp209 *lang.Var; A_arbace_test_A_Init(); tmp209 = A_arbace_test_A_const_13; var tmp210 lang.IFn = lang.IFn_Cast(jrt.NN(tmp209).GetRawRoot__O()); var tmp211 any; A_arbace_test_A_Init(); tmp211 = A_arbace_test_A_const_85; var tmp212 any = tmp210.Invoke_O__O(tmp211); var tmp213 *lang.Var; A_arbace_test_A_Init(); tmp213 = A_arbace_test_A_const_13; var tmp214 lang.IFn = lang.IFn_Cast(jrt.NN(tmp213).GetRawRoot__O()); var tmp215 *lang.Var; A_arbace_test_A_Init(); tmp215 = A_arbace_test_A_const_11; var tmp216 lang.IFn = lang.IFn_Cast(jrt.NN(tmp215).GetRawRoot__O()); var tmp217 *lang.Var; A_arbace_test_A_Init(); tmp217 = A_arbace_test_A_const_12; var tmp218 lang.IFn = lang.IFn_Cast(jrt.NN(tmp217).GetRawRoot__O()); var tmp219 *lang.Var; A_arbace_test_A_Init(); tmp219 = A_arbace_test_A_const_13; var tmp220 lang.IFn = lang.IFn_Cast(jrt.NN(tmp219).GetRawRoot__O()); var tmp221 any; A_arbace_test_A_Init(); tmp221 = A_arbace_test_A_const_82; var tmp222 any = tmp220.Invoke_O__O(tmp221); var tmp223 *lang.Var; A_arbace_test_A_Init(); tmp223 = A_arbace_test_A_const_13; var tmp224 lang.IFn = lang.IFn_Cast(jrt.NN(tmp223).GetRawRoot__O()); var tmp225 any; A_arbace_test_A_Init(); tmp225 = A_arbace_test_A_const_86; var tmp226 any = tmp214.Invoke_O__O(tmp216.Invoke_O__O(tmp218.Invoke_O_O__O(tmp222, tmp224.Invoke_O__O(tmp225)))); var tmp227 *lang.Var; A_arbace_test_A_Init(); tmp227 = A_arbace_test_A_const_13; var tmp228 lang.IFn = lang.IFn_Cast(jrt.NN(tmp227).GetRawRoot__O()); var tmp229 *lang.Var; A_arbace_test_A_Init(); tmp229 = A_arbace_test_A_const_11; var tmp230 lang.IFn = lang.IFn_Cast(jrt.NN(tmp229).GetRawRoot__O()); var tmp231 *lang.Var; A_arbace_test_A_Init(); tmp231 = A_arbace_test_A_const_12; var tmp232 lang.IFn = lang.IFn_Cast(jrt.NN(tmp231).GetRawRoot__O()); var tmp233 *lang.Var; A_arbace_test_A_Init(); tmp233 = A_arbace_test_A_const_13; var tmp234 lang.IFn = lang.IFn_Cast(jrt.NN(tmp233).GetRawRoot__O()); var tmp235 any; A_arbace_test_A_Init(); tmp235 = A_arbace_test_A_const_87; var tmp236 any = tmp234.Invoke_O__O(tmp235); var tmp237 *lang.Var; A_arbace_test_A_Init(); tmp237 = A_arbace_test_A_const_13; var tmp238 lang.IFn = lang.IFn_Cast(jrt.NN(tmp237).GetRawRoot__O()); var tmp239 *lang.Var; A_arbace_test_A_Init(); tmp239 = A_arbace_test_A_const_11; var tmp240 lang.IFn = lang.IFn_Cast(jrt.NN(tmp239).GetRawRoot__O()); var tmp241 *lang.Var; A_arbace_test_A_Init(); tmp241 = A_arbace_test_A_const_12; var tmp242 lang.IFn = lang.IFn_Cast(jrt.NN(tmp241).GetRawRoot__O()); var tmp243 *lang.Var; A_arbace_test_A_Init(); tmp243 = A_arbace_test_A_const_13; var tmp244 lang.IFn = lang.IFn_Cast(jrt.NN(tmp243).GetRawRoot__O()); var tmp245 any; A_arbace_test_A_Init(); tmp245 = A_arbace_test_A_const_82; var tmp246 any = tmp244.Invoke_O__O(tmp245); var tmp247 *lang.Var; A_arbace_test_A_Init(); tmp247 = A_arbace_test_A_const_13; var tmp248 any = tmp238.Invoke_O__O(tmp240.Invoke_O__O(tmp242.Invoke_O_O__O(tmp246, lang.IFn_Cast(jrt.NN(tmp247).GetRawRoot__O()).Invoke_O__O(pred__4)))); var tmp249 *lang.Var; A_arbace_test_A_Init(); tmp249 = A_arbace_test_A_const_13; var tmp250 lang.IFn = lang.IFn_Cast(jrt.NN(tmp249).GetRawRoot__O()); var tmp251 any; A_arbace_test_A_Init(); tmp251 = A_arbace_test_A_const_76; var tmp252 any = tmp56.Invoke_O__O(tmp58.Invoke_O__O(tmp60.Invoke_O_O_O_O__O(tmp64, tmp68, tmp148, tmp150.Invoke_O__O(tmp152.Invoke_O__O(tmp154.Invoke_O_O__O(tmp158, tmp160.Invoke_O__O(tmp162.Invoke_O_O__O(tmp164, tmp166.Invoke_O__O(tmp168.Invoke_O_O_O_O_O_O_O_O__O(tmp172, tmp176, tmp180, tmp182, tmp186, tmp198, tmp202, tmp204.Invoke_O__O(tmp206.Invoke_O__O(tmp208.Invoke_O_O_O__O(tmp212, tmp226, tmp228.Invoke_O__O(tmp230.Invoke_O__O(tmp232.Invoke_O_O_O__O(tmp236, tmp248, tmp250.Invoke_O__O(tmp251))))))))))))))))); var tmp253 *lang.Var; A_arbace_test_A_Init(); tmp253 = A_arbace_test_A_const_13; var tmp254 lang.IFn = lang.IFn_Cast(jrt.NN(tmp253).GetRawRoot__O()); var tmp255 any; A_arbace_test_A_Init(); tmp255 = A_arbace_test_A_const_78; return tmp4.Invoke_O__O(tmp6.Invoke_O_O_O_O__O(tmp10, tmp54, tmp252, tmp254.Invoke_O__O(tmp255))) }










func A_arbace_test_assert_any_A_New() *A_arbace_test_assert_any_A { A_arbace_test_assert_any_A_Init(); t := &A_arbace_test_assert_any_A{}; t.Ctor(); return t }
//line :447:1
func (t *A_arbace_test_assert_any_A) Ctor() {}
//line :447:1
func (t *A_arbace_test_assert_any_A) Invoke_O_O_O__O(self, msg__0, form__1 any) any { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_12; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_13; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_88; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_13; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_15; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_16; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_11; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_12; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_test_A_Init(); tmp19 = A_arbace_test_A_const_13; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_test_A_Init(); tmp21 = A_arbace_test_A_const_89; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_test_A_Init(); tmp23 = A_arbace_test_A_const_13; var tmp24 any = tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp22, lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(form__1))))); var tmp25 *lang.Var; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_13; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_test_A_Init(); tmp27 = A_arbace_test_A_const_11; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_test_A_Init(); tmp29 = A_arbace_test_A_const_12; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_test_A_Init(); tmp31 = A_arbace_test_A_const_13; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 any; A_arbace_test_A_Init(); tmp33 = A_arbace_test_A_const_90; var tmp34 any = tmp32.Invoke_O__O(tmp33); var tmp35 *lang.Var; A_arbace_test_A_Init(); tmp35 = A_arbace_test_A_const_13; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any; A_arbace_test_A_Init(); tmp37 = A_arbace_test_A_const_89; var tmp38 any = tmp36.Invoke_O__O(tmp37); var tmp39 *lang.Var; A_arbace_test_A_Init(); tmp39 = A_arbace_test_A_const_13; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 *lang.Var; A_arbace_test_A_Init(); tmp41 = A_arbace_test_A_const_11; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Var; A_arbace_test_A_Init(); tmp43 = A_arbace_test_A_const_12; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Var; A_arbace_test_A_Init(); tmp45 = A_arbace_test_A_const_13; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 any; A_arbace_test_A_Init(); tmp47 = A_arbace_test_A_const_91; var tmp48 any = tmp46.Invoke_O__O(tmp47); var tmp49 *lang.Var; A_arbace_test_A_Init(); tmp49 = A_arbace_test_A_const_13; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *lang.Var; A_arbace_test_A_Init(); tmp51 = A_arbace_test_A_const_15; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 *lang.Var; A_arbace_test_A_Init(); tmp53 = A_arbace_test_A_const_50; var tmp54 any = jrt.NN(tmp53).GetRawRoot__O(); var tmp55 *lang.Var; A_arbace_test_A_Init(); tmp55 = A_arbace_test_A_const_11; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.Var; A_arbace_test_A_Init(); tmp57 = A_arbace_test_A_const_12; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 *lang.Var; A_arbace_test_A_Init(); tmp59 = A_arbace_test_A_const_13; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 *lang.Keyword; A_arbace_test_A_Init(); tmp61 = A_arbace_test_A_const_39; var tmp62 any = tmp60.Invoke_O__O(tmp61.Ref()); var tmp63 *lang.Var; A_arbace_test_A_Init(); tmp63 = A_arbace_test_A_const_13; var tmp64 lang.IFn = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()); var tmp65 *lang.Keyword; A_arbace_test_A_Init(); tmp65 = A_arbace_test_A_const_54; var tmp66 any = tmp64.Invoke_O__O(tmp65.Ref()); var tmp67 *lang.Var; A_arbace_test_A_Init(); tmp67 = A_arbace_test_A_const_13; var tmp68 lang.IFn = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()); var tmp69 *lang.Keyword; A_arbace_test_A_Init(); tmp69 = A_arbace_test_A_const_56; var tmp70 any = tmp68.Invoke_O__O(tmp69.Ref()); var tmp71 *lang.Var; A_arbace_test_A_Init(); tmp71 = A_arbace_test_A_const_13; var tmp72 any = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()).Invoke_O__O(msg__0); var tmp73 *lang.Var; A_arbace_test_A_Init(); tmp73 = A_arbace_test_A_const_13; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *lang.Keyword; A_arbace_test_A_Init(); tmp75 = A_arbace_test_A_const_60; var tmp76 any = tmp74.Invoke_O__O(tmp75.Ref()); var tmp77 *lang.Var; A_arbace_test_A_Init(); tmp77 = A_arbace_test_A_const_13; var tmp78 lang.IFn = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()); var tmp79 *lang.Var; A_arbace_test_A_Init(); tmp79 = A_arbace_test_A_const_11; var tmp80 lang.IFn = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()); var tmp81 *lang.Var; A_arbace_test_A_Init(); tmp81 = A_arbace_test_A_const_12; var tmp82 lang.IFn = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()); var tmp83 *lang.Var; A_arbace_test_A_Init(); tmp83 = A_arbace_test_A_const_13; var tmp84 lang.IFn = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()); var tmp85 any; A_arbace_test_A_Init(); tmp85 = A_arbace_test_A_const_82; var tmp86 any = tmp84.Invoke_O__O(tmp85); var tmp87 *lang.Var; A_arbace_test_A_Init(); tmp87 = A_arbace_test_A_const_13; var tmp88 any = tmp78.Invoke_O__O(tmp80.Invoke_O__O(tmp82.Invoke_O_O__O(tmp86, lang.IFn_Cast(jrt.NN(tmp87).GetRawRoot__O()).Invoke_O__O(form__1)))); var tmp89 *lang.Var; A_arbace_test_A_Init(); tmp89 = A_arbace_test_A_const_13; var tmp90 lang.IFn = lang.IFn_Cast(jrt.NN(tmp89).GetRawRoot__O()); var tmp91 *lang.Keyword; A_arbace_test_A_Init(); tmp91 = A_arbace_test_A_const_44; var tmp92 any = tmp90.Invoke_O__O(tmp91.Ref()); var tmp93 *lang.Var; A_arbace_test_A_Init(); tmp93 = A_arbace_test_A_const_13; var tmp94 lang.IFn = lang.IFn_Cast(jrt.NN(tmp93).GetRawRoot__O()); var tmp95 any; A_arbace_test_A_Init(); tmp95 = A_arbace_test_A_const_89; var tmp96 any = tmp40.Invoke_O__O(tmp42.Invoke_O__O(tmp44.Invoke_O_O__O(tmp48, tmp50.Invoke_O__O(tmp52.Invoke_O_O__O(tmp54, tmp56.Invoke_O__O(tmp58.Invoke_O_O_O_O_O_O_O_O__O(tmp62, tmp66, tmp70, tmp72, tmp76, tmp88, tmp92, tmp94.Invoke_O__O(tmp95)))))))); var tmp97 *lang.Var; A_arbace_test_A_Init(); tmp97 = A_arbace_test_A_const_13; var tmp98 lang.IFn = lang.IFn_Cast(jrt.NN(tmp97).GetRawRoot__O()); var tmp99 *lang.Var; A_arbace_test_A_Init(); tmp99 = A_arbace_test_A_const_11; var tmp100 lang.IFn = lang.IFn_Cast(jrt.NN(tmp99).GetRawRoot__O()); var tmp101 *lang.Var; A_arbace_test_A_Init(); tmp101 = A_arbace_test_A_const_12; var tmp102 lang.IFn = lang.IFn_Cast(jrt.NN(tmp101).GetRawRoot__O()); var tmp103 *lang.Var; A_arbace_test_A_Init(); tmp103 = A_arbace_test_A_const_13; var tmp104 lang.IFn = lang.IFn_Cast(jrt.NN(tmp103).GetRawRoot__O()); var tmp105 any; A_arbace_test_A_Init(); tmp105 = A_arbace_test_A_const_92; var tmp106 any = tmp104.Invoke_O__O(tmp105); var tmp107 *lang.Var; A_arbace_test_A_Init(); tmp107 = A_arbace_test_A_const_13; var tmp108 lang.IFn = lang.IFn_Cast(jrt.NN(tmp107).GetRawRoot__O()); var tmp109 *lang.Var; A_arbace_test_A_Init(); tmp109 = A_arbace_test_A_const_15; var tmp110 lang.IFn = lang.IFn_Cast(jrt.NN(tmp109).GetRawRoot__O()); var tmp111 *lang.Var; A_arbace_test_A_Init(); tmp111 = A_arbace_test_A_const_50; var tmp112 any = jrt.NN(tmp111).GetRawRoot__O(); var tmp113 *lang.Var; A_arbace_test_A_Init(); tmp113 = A_arbace_test_A_const_11; var tmp114 lang.IFn = lang.IFn_Cast(jrt.NN(tmp113).GetRawRoot__O()); var tmp115 *lang.Var; A_arbace_test_A_Init(); tmp115 = A_arbace_test_A_const_12; var tmp116 lang.IFn = lang.IFn_Cast(jrt.NN(tmp115).GetRawRoot__O()); var tmp117 *lang.Var; A_arbace_test_A_Init(); tmp117 = A_arbace_test_A_const_13; var tmp118 lang.IFn = lang.IFn_Cast(jrt.NN(tmp117).GetRawRoot__O()); var tmp119 *lang.Keyword; A_arbace_test_A_Init(); tmp119 = A_arbace_test_A_const_39; var tmp120 any = tmp118.Invoke_O__O(tmp119.Ref()); var tmp121 *lang.Var; A_arbace_test_A_Init(); tmp121 = A_arbace_test_A_const_13; var tmp122 lang.IFn = lang.IFn_Cast(jrt.NN(tmp121).GetRawRoot__O()); var tmp123 *lang.Keyword; A_arbace_test_A_Init(); tmp123 = A_arbace_test_A_const_42; var tmp124 any = tmp122.Invoke_O__O(tmp123.Ref()); var tmp125 *lang.Var; A_arbace_test_A_Init(); tmp125 = A_arbace_test_A_const_13; var tmp126 lang.IFn = lang.IFn_Cast(jrt.NN(tmp125).GetRawRoot__O()); var tmp127 *lang.Keyword; A_arbace_test_A_Init(); tmp127 = A_arbace_test_A_const_56; var tmp128 any = tmp126.Invoke_O__O(tmp127.Ref()); var tmp129 *lang.Var; A_arbace_test_A_Init(); tmp129 = A_arbace_test_A_const_13; var tmp130 any = lang.IFn_Cast(jrt.NN(tmp129).GetRawRoot__O()).Invoke_O__O(msg__0); var tmp131 *lang.Var; A_arbace_test_A_Init(); tmp131 = A_arbace_test_A_const_13; var tmp132 lang.IFn = lang.IFn_Cast(jrt.NN(tmp131).GetRawRoot__O()); var tmp133 *lang.Keyword; A_arbace_test_A_Init(); tmp133 = A_arbace_test_A_const_60; var tmp134 any = tmp132.Invoke_O__O(tmp133.Ref()); var tmp135 *lang.Var; A_arbace_test_A_Init(); tmp135 = A_arbace_test_A_const_13; var tmp136 lang.IFn = lang.IFn_Cast(jrt.NN(tmp135).GetRawRoot__O()); var tmp137 *lang.Var; A_arbace_test_A_Init(); tmp137 = A_arbace_test_A_const_11; var tmp138 lang.IFn = lang.IFn_Cast(jrt.NN(tmp137).GetRawRoot__O()); var tmp139 *lang.Var; A_arbace_test_A_Init(); tmp139 = A_arbace_test_A_const_12; var tmp140 lang.IFn = lang.IFn_Cast(jrt.NN(tmp139).GetRawRoot__O()); var tmp141 *lang.Var; A_arbace_test_A_Init(); tmp141 = A_arbace_test_A_const_13; var tmp142 lang.IFn = lang.IFn_Cast(jrt.NN(tmp141).GetRawRoot__O()); var tmp143 any; A_arbace_test_A_Init(); tmp143 = A_arbace_test_A_const_82; var tmp144 any = tmp142.Invoke_O__O(tmp143); var tmp145 *lang.Var; A_arbace_test_A_Init(); tmp145 = A_arbace_test_A_const_13; var tmp146 any = tmp136.Invoke_O__O(tmp138.Invoke_O__O(tmp140.Invoke_O_O__O(tmp144, lang.IFn_Cast(jrt.NN(tmp145).GetRawRoot__O()).Invoke_O__O(form__1)))); var tmp147 *lang.Var; A_arbace_test_A_Init(); tmp147 = A_arbace_test_A_const_13; var tmp148 lang.IFn = lang.IFn_Cast(jrt.NN(tmp147).GetRawRoot__O()); var tmp149 *lang.Keyword; A_arbace_test_A_Init(); tmp149 = A_arbace_test_A_const_44; var tmp150 any = tmp148.Invoke_O__O(tmp149.Ref()); var tmp151 *lang.Var; A_arbace_test_A_Init(); tmp151 = A_arbace_test_A_const_13; var tmp152 lang.IFn = lang.IFn_Cast(jrt.NN(tmp151).GetRawRoot__O()); var tmp153 any; A_arbace_test_A_Init(); tmp153 = A_arbace_test_A_const_89; var tmp154 any = tmp26.Invoke_O__O(tmp28.Invoke_O__O(tmp30.Invoke_O_O_O_O__O(tmp34, tmp38, tmp96, tmp98.Invoke_O__O(tmp100.Invoke_O__O(tmp102.Invoke_O_O__O(tmp106, tmp108.Invoke_O__O(tmp110.Invoke_O_O__O(tmp112, tmp114.Invoke_O__O(tmp116.Invoke_O_O_O_O_O_O_O_O__O(tmp120, tmp124, tmp128, tmp130, tmp134, tmp146, tmp150, tmp152.Invoke_O__O(tmp153))))))))))); var tmp155 *lang.Var; A_arbace_test_A_Init(); tmp155 = A_arbace_test_A_const_13; var tmp156 lang.IFn = lang.IFn_Cast(jrt.NN(tmp155).GetRawRoot__O()); var tmp157 any; A_arbace_test_A_Init(); tmp157 = A_arbace_test_A_const_89; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O_O__O(tmp8, tmp24, tmp154, tmp156.Invoke_O__O(tmp157))) }



















func A_arbace_test_eval196000082_fn__196000083_A_New() *A_arbace_test_eval196000082_fn__196000083_A { A_arbace_test_eval196000082_fn__196000083_A_Init(); t := &A_arbace_test_eval196000082_fn__196000083_A{}; t.Ctor(); return t }
//line :467:1
func (t *A_arbace_test_eval196000082_fn__196000083_A) Ctor() {}
//line :467:1
func (t *A_arbace_test_eval196000082_fn__196000083_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any {
	if lang.Util_Identical_O_O__Z(form__2, nil) { A_arbace_test_A_Init(); return A_arbace_test_A_const_93.Ref() } else { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_94; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(form__2)) {

		var tmp2 *lang.Var; A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_21; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(form__2) } else {
//line :468:1
			var tmp3 *lang.Keyword; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_95; if tmp3 != nil { A_arbace_test_A_Init(); return A_arbace_test_A_const_96.Ref() } else { return nil
			}
		}
	}
}
func A_arbace_test_eval196000086_fn__196000087_A_New() *A_arbace_test_eval196000086_fn__196000087_A { A_arbace_test_eval196000086_fn__196000087_A_Init(); t := &A_arbace_test_eval196000086_fn__196000087_A{}; t.Ctor(); return t }
//line :473:1
func (t *A_arbace_test_eval196000086_fn__196000087_A) Ctor() {}
//line :473:1
func (t *A_arbace_test_eval196000086_fn__196000087_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_12; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_13; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_97; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_13; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_15; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_50; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_11; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_12; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_test_A_Init(); tmp19 = A_arbace_test_A_const_13; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Keyword; A_arbace_test_A_Init(); tmp21 = A_arbace_test_A_const_39; var tmp22 any = tmp20.Invoke_O__O(tmp21.Ref()); var tmp23 *lang.Var; A_arbace_test_A_Init(); tmp23 = A_arbace_test_A_const_13; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Keyword; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_42; var tmp26 any = tmp24.Invoke_O__O(tmp25.Ref()); var tmp27 *lang.Var; A_arbace_test_A_Init(); tmp27 = A_arbace_test_A_const_13; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Keyword; A_arbace_test_A_Init(); tmp29 = A_arbace_test_A_const_56; var tmp30 any = tmp28.Invoke_O__O(tmp29.Ref()); var tmp31 *lang.Var; A_arbace_test_A_Init(); tmp31 = A_arbace_test_A_const_13; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(tmp18.Invoke_O_O_O_O__O(tmp22, tmp26, tmp30, lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(msg__1))))))) }



func A_arbace_test_eval196000090_fn__196000091_A_New() *A_arbace_test_eval196000090_fn__196000091_A { A_arbace_test_eval196000090_fn__196000091_A_Init(); t := &A_arbace_test_eval196000090_fn__196000091_A{}; t.Ctor(); return t }
//line :477:1
func (t *A_arbace_test_eval196000090_fn__196000091_A) Ctor() {}
//line :477:1
func (t *A_arbace_test_eval196000090_fn__196000091_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any; var tmp2 *lang.Var; A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_98; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(form__2); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_99; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_21; tmp1 = tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(form__2)) } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) {
		var tmp6 *lang.Var; A_arbace_test_A_Init(); tmp6 = A_arbace_test_A_const_100; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(msg__1, form__2) } else {
			var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_101; return lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(msg__1, form__2)
		} }
func A_arbace_test_eval196000097_fn__196000098_A_New() *A_arbace_test_eval196000097_fn__196000098_A { A_arbace_test_eval196000097_fn__196000098_A_Init(); t := &A_arbace_test_eval196000097_fn__196000098_A{}; t.Ctor(); return t }
//line :482:1
func (t *A_arbace_test_eval196000097_fn__196000098_A) Ctor() {}
//line :482:1
func (t *A_arbace_test_eval196000097_fn__196000098_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_12; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_13; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_102; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_13; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_15; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_16; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_11; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_12; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_test_A_Init(); tmp19 = A_arbace_test_A_const_13; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_test_A_Init(); tmp21 = A_arbace_test_A_const_103; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_test_A_Init(); tmp23 = A_arbace_test_A_const_13; var tmp24 any = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(form__2, lang.RT_IntCast_J__I(1))); var tmp25 *lang.Var; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_13; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any; A_arbace_test_A_Init(); tmp27 = A_arbace_test_A_const_104; var tmp28 any = tmp26.Invoke_O__O(tmp27); var tmp29 *lang.Var; A_arbace_test_A_Init(); tmp29 = A_arbace_test_A_const_13; var tmp30 any = tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(tmp18.Invoke_O_O_O_O__O(tmp22, tmp24, tmp28, lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(form__2, lang.RT_IntCast_J__I(2))))))); var tmp31 *lang.Var; A_arbace_test_A_Init(); tmp31 = A_arbace_test_A_const_13; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_test_A_Init(); tmp33 = A_arbace_test_A_const_11; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_test_A_Init(); tmp35 = A_arbace_test_A_const_12; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_test_A_Init(); tmp37 = A_arbace_test_A_const_13; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 any; A_arbace_test_A_Init(); tmp39 = A_arbace_test_A_const_105; var tmp40 any = tmp38.Invoke_O__O(tmp39); var tmp41 *lang.Var; A_arbace_test_A_Init(); tmp41 = A_arbace_test_A_const_13; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Var; A_arbace_test_A_Init(); tmp43 = A_arbace_test_A_const_15; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Var; A_arbace_test_A_Init(); tmp45 = A_arbace_test_A_const_16; var tmp46 any = jrt.NN(tmp45).GetRawRoot__O(); var tmp47 *lang.Var; A_arbace_test_A_Init(); tmp47 = A_arbace_test_A_const_11; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Var; A_arbace_test_A_Init(); tmp49 = A_arbace_test_A_const_12; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *lang.Var; A_arbace_test_A_Init(); tmp51 = A_arbace_test_A_const_13; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 any; A_arbace_test_A_Init(); tmp53 = A_arbace_test_A_const_106; var tmp54 any = tmp52.Invoke_O__O(tmp53); var tmp55 *lang.Var; A_arbace_test_A_Init(); tmp55 = A_arbace_test_A_const_13; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.Var; A_arbace_test_A_Init(); tmp57 = A_arbace_test_A_const_11; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 *lang.Var; A_arbace_test_A_Init(); tmp59 = A_arbace_test_A_const_12; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 *lang.Var; A_arbace_test_A_Init(); tmp61 = A_arbace_test_A_const_13; var tmp62 lang.IFn = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()); var tmp63 any; A_arbace_test_A_Init(); tmp63 = A_arbace_test_A_const_107; var tmp64 any = tmp62.Invoke_O__O(tmp63); var tmp65 *lang.Var; A_arbace_test_A_Init(); tmp65 = A_arbace_test_A_const_13; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 any; A_arbace_test_A_Init(); tmp67 = A_arbace_test_A_const_103; var tmp68 any = tmp66.Invoke_O__O(tmp67); var tmp69 *lang.Var; A_arbace_test_A_Init(); tmp69 = A_arbace_test_A_const_13; var tmp70 lang.IFn = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()); var tmp71 any; A_arbace_test_A_Init(); tmp71 = A_arbace_test_A_const_104; var tmp72 any = tmp42.Invoke_O__O(tmp44.Invoke_O_O__O(tmp46, tmp48.Invoke_O__O(tmp50.Invoke_O_O__O(tmp54, tmp56.Invoke_O__O(tmp58.Invoke_O__O(tmp60.Invoke_O_O_O__O(tmp64, tmp68, tmp70.Invoke_O__O(tmp71)))))))); var tmp73 *lang.Var; A_arbace_test_A_Init(); tmp73 = A_arbace_test_A_const_13; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *lang.Var; A_arbace_test_A_Init(); tmp75 = A_arbace_test_A_const_11; var tmp76 lang.IFn = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()); var tmp77 *lang.Var; A_arbace_test_A_Init(); tmp77 = A_arbace_test_A_const_12; var tmp78 lang.IFn = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()); var tmp79 *lang.Var; A_arbace_test_A_Init(); tmp79 = A_arbace_test_A_const_13; var tmp80 lang.IFn = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()); var tmp81 any; A_arbace_test_A_Init(); tmp81 = A_arbace_test_A_const_108; var tmp82 any = tmp80.Invoke_O__O(tmp81); var tmp83 *lang.Var; A_arbace_test_A_Init(); tmp83 = A_arbace_test_A_const_13; var tmp84 lang.IFn = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()); var tmp85 any; A_arbace_test_A_Init(); tmp85 = A_arbace_test_A_const_106; var tmp86 any = tmp84.Invoke_O__O(tmp85); var tmp87 *lang.Var; A_arbace_test_A_Init(); tmp87 = A_arbace_test_A_const_13; var tmp88 lang.IFn = lang.IFn_Cast(jrt.NN(tmp87).GetRawRoot__O()); var tmp89 *lang.Var; A_arbace_test_A_Init(); tmp89 = A_arbace_test_A_const_11; var tmp90 lang.IFn = lang.IFn_Cast(jrt.NN(tmp89).GetRawRoot__O()); var tmp91 *lang.Var; A_arbace_test_A_Init(); tmp91 = A_arbace_test_A_const_12; var tmp92 lang.IFn = lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()); var tmp93 *lang.Var; A_arbace_test_A_Init(); tmp93 = A_arbace_test_A_const_13; var tmp94 lang.IFn = lang.IFn_Cast(jrt.NN(tmp93).GetRawRoot__O()); var tmp95 any; A_arbace_test_A_Init(); tmp95 = A_arbace_test_A_const_109; var tmp96 any = tmp94.Invoke_O__O(tmp95); var tmp97 *lang.Var; A_arbace_test_A_Init(); tmp97 = A_arbace_test_A_const_13; var tmp98 lang.IFn = lang.IFn_Cast(jrt.NN(tmp97).GetRawRoot__O()); var tmp99 *lang.Var; A_arbace_test_A_Init(); tmp99 = A_arbace_test_A_const_15; var tmp100 lang.IFn = lang.IFn_Cast(jrt.NN(tmp99).GetRawRoot__O()); var tmp101 *lang.Var; A_arbace_test_A_Init(); tmp101 = A_arbace_test_A_const_50; var tmp102 any = jrt.NN(tmp101).GetRawRoot__O(); var tmp103 *lang.Var; A_arbace_test_A_Init(); tmp103 = A_arbace_test_A_const_11; var tmp104 lang.IFn = lang.IFn_Cast(jrt.NN(tmp103).GetRawRoot__O()); var tmp105 *lang.Var; A_arbace_test_A_Init(); tmp105 = A_arbace_test_A_const_12; var tmp106 lang.IFn = lang.IFn_Cast(jrt.NN(tmp105).GetRawRoot__O()); var tmp107 *lang.Var; A_arbace_test_A_Init(); tmp107 = A_arbace_test_A_const_13; var tmp108 lang.IFn = lang.IFn_Cast(jrt.NN(tmp107).GetRawRoot__O()); var tmp109 *lang.Keyword; A_arbace_test_A_Init(); tmp109 = A_arbace_test_A_const_39; var tmp110 any = tmp108.Invoke_O__O(tmp109.Ref()); var tmp111 *lang.Var; A_arbace_test_A_Init(); tmp111 = A_arbace_test_A_const_13; var tmp112 lang.IFn = lang.IFn_Cast(jrt.NN(tmp111).GetRawRoot__O()); var tmp113 *lang.Keyword; A_arbace_test_A_Init(); tmp113 = A_arbace_test_A_const_54; var tmp114 any = tmp112.Invoke_O__O(tmp113.Ref()); var tmp115 *lang.Var; A_arbace_test_A_Init(); tmp115 = A_arbace_test_A_const_13; var tmp116 lang.IFn = lang.IFn_Cast(jrt.NN(tmp115).GetRawRoot__O()); var tmp117 *lang.Keyword; A_arbace_test_A_Init(); tmp117 = A_arbace_test_A_const_56; var tmp118 any = tmp116.Invoke_O__O(tmp117.Ref()); var tmp119 *lang.Var; A_arbace_test_A_Init(); tmp119 = A_arbace_test_A_const_13; var tmp120 any = lang.IFn_Cast(jrt.NN(tmp119).GetRawRoot__O()).Invoke_O__O(msg__1); var tmp121 *lang.Var; A_arbace_test_A_Init(); tmp121 = A_arbace_test_A_const_13; var tmp122 lang.IFn = lang.IFn_Cast(jrt.NN(tmp121).GetRawRoot__O()); var tmp123 *lang.Keyword; A_arbace_test_A_Init(); tmp123 = A_arbace_test_A_const_60; var tmp124 any = tmp122.Invoke_O__O(tmp123.Ref()); var tmp125 *lang.Var; A_arbace_test_A_Init(); tmp125 = A_arbace_test_A_const_13; var tmp126 lang.IFn = lang.IFn_Cast(jrt.NN(tmp125).GetRawRoot__O()); var tmp127 *lang.Var; A_arbace_test_A_Init(); tmp127 = A_arbace_test_A_const_11; var tmp128 lang.IFn = lang.IFn_Cast(jrt.NN(tmp127).GetRawRoot__O()); var tmp129 *lang.Var; A_arbace_test_A_Init(); tmp129 = A_arbace_test_A_const_12; var tmp130 lang.IFn = lang.IFn_Cast(jrt.NN(tmp129).GetRawRoot__O()); var tmp131 *lang.Var; A_arbace_test_A_Init(); tmp131 = A_arbace_test_A_const_13; var tmp132 lang.IFn = lang.IFn_Cast(jrt.NN(tmp131).GetRawRoot__O()); var tmp133 any; A_arbace_test_A_Init(); tmp133 = A_arbace_test_A_const_82; var tmp134 any = tmp132.Invoke_O__O(tmp133); var tmp135 *lang.Var; A_arbace_test_A_Init(); tmp135 = A_arbace_test_A_const_13; var tmp136 any = tmp126.Invoke_O__O(tmp128.Invoke_O__O(tmp130.Invoke_O_O__O(tmp134, lang.IFn_Cast(jrt.NN(tmp135).GetRawRoot__O()).Invoke_O__O(form__2)))); var tmp137 *lang.Var; A_arbace_test_A_Init(); tmp137 = A_arbace_test_A_const_13; var tmp138 lang.IFn = lang.IFn_Cast(jrt.NN(tmp137).GetRawRoot__O()); var tmp139 *lang.Keyword; A_arbace_test_A_Init(); tmp139 = A_arbace_test_A_const_44; var tmp140 any = tmp138.Invoke_O__O(tmp139.Ref()); var tmp141 *lang.Var; A_arbace_test_A_Init(); tmp141 = A_arbace_test_A_const_13; var tmp142 lang.IFn = lang.IFn_Cast(jrt.NN(tmp141).GetRawRoot__O()); var tmp143 *lang.Var; A_arbace_test_A_Init(); tmp143 = A_arbace_test_A_const_11; var tmp144 lang.IFn = lang.IFn_Cast(jrt.NN(tmp143).GetRawRoot__O()); var tmp145 *lang.Var; A_arbace_test_A_Init(); tmp145 = A_arbace_test_A_const_12; var tmp146 lang.IFn = lang.IFn_Cast(jrt.NN(tmp145).GetRawRoot__O()); var tmp147 *lang.Var; A_arbace_test_A_Init(); tmp147 = A_arbace_test_A_const_13; var tmp148 lang.IFn = lang.IFn_Cast(jrt.NN(tmp147).GetRawRoot__O()); var tmp149 any; A_arbace_test_A_Init(); tmp149 = A_arbace_test_A_const_110; var tmp150 any = tmp148.Invoke_O__O(tmp149); var tmp151 *lang.Var; A_arbace_test_A_Init(); tmp151 = A_arbace_test_A_const_13; var tmp152 lang.IFn = lang.IFn_Cast(jrt.NN(tmp151).GetRawRoot__O()); var tmp153 any; A_arbace_test_A_Init(); tmp153 = A_arbace_test_A_const_104; var tmp154 any = tmp88.Invoke_O__O(tmp90.Invoke_O__O(tmp92.Invoke_O_O__O(tmp96, tmp98.Invoke_O__O(tmp100.Invoke_O_O__O(tmp102, tmp104.Invoke_O__O(tmp106.Invoke_O_O_O_O_O_O_O_O__O(tmp110, tmp114, tmp118, tmp120, tmp124, tmp136, tmp140, tmp142.Invoke_O__O(tmp144.Invoke_O__O(tmp146.Invoke_O_O__O(tmp150, tmp152.Invoke_O__O(tmp153))))))))))); var tmp155 *lang.Var; A_arbace_test_A_Init(); tmp155 = A_arbace_test_A_const_13; var tmp156 lang.IFn = lang.IFn_Cast(jrt.NN(tmp155).GetRawRoot__O()); var tmp157 *lang.Var; A_arbace_test_A_Init(); tmp157 = A_arbace_test_A_const_11; var tmp158 lang.IFn = lang.IFn_Cast(jrt.NN(tmp157).GetRawRoot__O()); var tmp159 *lang.Var; A_arbace_test_A_Init(); tmp159 = A_arbace_test_A_const_12; var tmp160 lang.IFn = lang.IFn_Cast(jrt.NN(tmp159).GetRawRoot__O()); var tmp161 *lang.Var; A_arbace_test_A_Init(); tmp161 = A_arbace_test_A_const_13; var tmp162 lang.IFn = lang.IFn_Cast(jrt.NN(tmp161).GetRawRoot__O()); var tmp163 any; A_arbace_test_A_Init(); tmp163 = A_arbace_test_A_const_111; var tmp164 any = tmp162.Invoke_O__O(tmp163); var tmp165 *lang.Var; A_arbace_test_A_Init(); tmp165 = A_arbace_test_A_const_13; var tmp166 lang.IFn = lang.IFn_Cast(jrt.NN(tmp165).GetRawRoot__O()); var tmp167 *lang.Var; A_arbace_test_A_Init(); tmp167 = A_arbace_test_A_const_15; var tmp168 lang.IFn = lang.IFn_Cast(jrt.NN(tmp167).GetRawRoot__O()); var tmp169 *lang.Var; A_arbace_test_A_Init(); tmp169 = A_arbace_test_A_const_50; var tmp170 any = jrt.NN(tmp169).GetRawRoot__O(); var tmp171 *lang.Var; A_arbace_test_A_Init(); tmp171 = A_arbace_test_A_const_11; var tmp172 lang.IFn = lang.IFn_Cast(jrt.NN(tmp171).GetRawRoot__O()); var tmp173 *lang.Var; A_arbace_test_A_Init(); tmp173 = A_arbace_test_A_const_12; var tmp174 lang.IFn = lang.IFn_Cast(jrt.NN(tmp173).GetRawRoot__O()); var tmp175 *lang.Var; A_arbace_test_A_Init(); tmp175 = A_arbace_test_A_const_13; var tmp176 lang.IFn = lang.IFn_Cast(jrt.NN(tmp175).GetRawRoot__O()); var tmp177 *lang.Keyword; A_arbace_test_A_Init(); tmp177 = A_arbace_test_A_const_39; var tmp178 any = tmp176.Invoke_O__O(tmp177.Ref()); var tmp179 *lang.Var; A_arbace_test_A_Init(); tmp179 = A_arbace_test_A_const_13; var tmp180 lang.IFn = lang.IFn_Cast(jrt.NN(tmp179).GetRawRoot__O()); var tmp181 *lang.Keyword; A_arbace_test_A_Init(); tmp181 = A_arbace_test_A_const_42; var tmp182 any = tmp180.Invoke_O__O(tmp181.Ref()); var tmp183 *lang.Var; A_arbace_test_A_Init(); tmp183 = A_arbace_test_A_const_13; var tmp184 lang.IFn = lang.IFn_Cast(jrt.NN(tmp183).GetRawRoot__O()); var tmp185 *lang.Keyword; A_arbace_test_A_Init(); tmp185 = A_arbace_test_A_const_56; var tmp186 any = tmp184.Invoke_O__O(tmp185.Ref()); var tmp187 *lang.Var; A_arbace_test_A_Init(); tmp187 = A_arbace_test_A_const_13; var tmp188 any = lang.IFn_Cast(jrt.NN(tmp187).GetRawRoot__O()).Invoke_O__O(msg__1); var tmp189 *lang.Var; A_arbace_test_A_Init(); tmp189 = A_arbace_test_A_const_13; var tmp190 lang.IFn = lang.IFn_Cast(jrt.NN(tmp189).GetRawRoot__O()); var tmp191 *lang.Keyword; A_arbace_test_A_Init(); tmp191 = A_arbace_test_A_const_60; var tmp192 any = tmp190.Invoke_O__O(tmp191.Ref()); var tmp193 *lang.Var; A_arbace_test_A_Init(); tmp193 = A_arbace_test_A_const_13; var tmp194 lang.IFn = lang.IFn_Cast(jrt.NN(tmp193).GetRawRoot__O()); var tmp195 *lang.Var; A_arbace_test_A_Init(); tmp195 = A_arbace_test_A_const_11; var tmp196 lang.IFn = lang.IFn_Cast(jrt.NN(tmp195).GetRawRoot__O()); var tmp197 *lang.Var; A_arbace_test_A_Init(); tmp197 = A_arbace_test_A_const_12; var tmp198 lang.IFn = lang.IFn_Cast(jrt.NN(tmp197).GetRawRoot__O()); var tmp199 *lang.Var; A_arbace_test_A_Init(); tmp199 = A_arbace_test_A_const_13; var tmp200 lang.IFn = lang.IFn_Cast(jrt.NN(tmp199).GetRawRoot__O()); var tmp201 any; A_arbace_test_A_Init(); tmp201 = A_arbace_test_A_const_82; var tmp202 any = tmp200.Invoke_O__O(tmp201); var tmp203 *lang.Var; A_arbace_test_A_Init(); tmp203 = A_arbace_test_A_const_13; var tmp204 any = tmp194.Invoke_O__O(tmp196.Invoke_O__O(tmp198.Invoke_O_O__O(tmp202, lang.IFn_Cast(jrt.NN(tmp203).GetRawRoot__O()).Invoke_O__O(form__2)))); var tmp205 *lang.Var; A_arbace_test_A_Init(); tmp205 = A_arbace_test_A_const_13; var tmp206 lang.IFn = lang.IFn_Cast(jrt.NN(tmp205).GetRawRoot__O()); var tmp207 *lang.Keyword; A_arbace_test_A_Init(); tmp207 = A_arbace_test_A_const_44; var tmp208 any = tmp206.Invoke_O__O(tmp207.Ref()); var tmp209 *lang.Var; A_arbace_test_A_Init(); tmp209 = A_arbace_test_A_const_13; var tmp210 lang.IFn = lang.IFn_Cast(jrt.NN(tmp209).GetRawRoot__O()); var tmp211 *lang.Var; A_arbace_test_A_Init(); tmp211 = A_arbace_test_A_const_11; var tmp212 lang.IFn = lang.IFn_Cast(jrt.NN(tmp211).GetRawRoot__O()); var tmp213 *lang.Var; A_arbace_test_A_Init(); tmp213 = A_arbace_test_A_const_12; var tmp214 lang.IFn = lang.IFn_Cast(jrt.NN(tmp213).GetRawRoot__O()); var tmp215 *lang.Var; A_arbace_test_A_Init(); tmp215 = A_arbace_test_A_const_13; var tmp216 lang.IFn = lang.IFn_Cast(jrt.NN(tmp215).GetRawRoot__O()); var tmp217 any; A_arbace_test_A_Init(); tmp217 = A_arbace_test_A_const_112; var tmp218 any = tmp216.Invoke_O__O(tmp217); var tmp219 *lang.Var; A_arbace_test_A_Init(); tmp219 = A_arbace_test_A_const_13; var tmp220 lang.IFn = lang.IFn_Cast(jrt.NN(tmp219).GetRawRoot__O()); var tmp221 any; A_arbace_test_A_Init(); tmp221 = A_arbace_test_A_const_104; var tmp222 any = tmp74.Invoke_O__O(tmp76.Invoke_O__O(tmp78.Invoke_O_O_O_O__O(tmp82, tmp86, tmp154, tmp156.Invoke_O__O(tmp158.Invoke_O__O(tmp160.Invoke_O_O__O(tmp164, tmp166.Invoke_O__O(tmp168.Invoke_O_O__O(tmp170, tmp172.Invoke_O__O(tmp174.Invoke_O_O_O_O_O_O_O_O__O(tmp178, tmp182, tmp186, tmp188, tmp192, tmp204, tmp208, tmp210.Invoke_O__O(tmp212.Invoke_O__O(tmp214.Invoke_O_O__O(tmp218, tmp220.Invoke_O__O(tmp221)))))))))))))); var tmp223 *lang.Var; A_arbace_test_A_Init(); tmp223 = A_arbace_test_A_const_13; var tmp224 lang.IFn = lang.IFn_Cast(jrt.NN(tmp223).GetRawRoot__O()); var tmp225 any; A_arbace_test_A_Init(); tmp225 = A_arbace_test_A_const_106; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp30, tmp32.Invoke_O__O(tmp34.Invoke_O__O(tmp36.Invoke_O_O_O_O__O(tmp40, tmp72, tmp222, tmp224.Invoke_O__O(tmp225)))))) }











func A_arbace_test_eval196000102_fn__196000103_A_New() *A_arbace_test_eval196000102_fn__196000103_A { A_arbace_test_eval196000102_fn__196000103_A_Init(); t := &A_arbace_test_eval196000102_fn__196000103_A{}; t.Ctor(); return t }
//line :494:1
func (t *A_arbace_test_eval196000102_fn__196000103_A) Ctor() {}
//line :494:1
func (t *A_arbace_test_eval196000102_fn__196000103_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any { var klass__3 any; var tmp1 *lang.Var;



	A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_113; klass__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(form__2); var body__4 any; var tmp2 /*line :494:1*/*lang.Var;




	A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_114; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_115; body__4 = tmp3.Invoke_O_O__O(form__2, tmp4); var tmp5 /*line :498:1*/*lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_11; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_12; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_13; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_116; var tmp12 any = tmp10.Invoke_O__O(tmp11); var tmp13 *lang.Var; A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_13; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_11; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_12; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_test_A_Init(); tmp19 = A_arbace_test_A_const_13; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_test_A_Init(); tmp21 = A_arbace_test_A_const_117; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_test_A_Init(); tmp23 = A_arbace_test_A_const_13; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_15; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_test_A_Init(); tmp27 = A_arbace_test_A_const_50; var tmp28 any = jrt.NN(tmp27).GetRawRoot__O(); var tmp29 *lang.Var; A_arbace_test_A_Init(); tmp29 = A_arbace_test_A_const_11; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_test_A_Init(); tmp31 = A_arbace_test_A_const_12; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_test_A_Init(); tmp33 = A_arbace_test_A_const_13; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Keyword; A_arbace_test_A_Init(); tmp35 = A_arbace_test_A_const_39; var tmp36 any = tmp34.Invoke_O__O(tmp35.Ref()); var tmp37 *lang.Var; A_arbace_test_A_Init(); tmp37 = A_arbace_test_A_const_13; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Keyword; A_arbace_test_A_Init(); tmp39 = A_arbace_test_A_const_42; var tmp40 any = tmp38.Invoke_O__O(tmp39.Ref()); var tmp41 *lang.Var; A_arbace_test_A_Init(); tmp41 = A_arbace_test_A_const_13; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Keyword; A_arbace_test_A_Init(); tmp43 = A_arbace_test_A_const_56; var tmp44 any = tmp42.Invoke_O__O(tmp43.Ref()); var tmp45 *lang.Var; A_arbace_test_A_Init(); tmp45 = A_arbace_test_A_const_13; var tmp46 any = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()).Invoke_O__O(msg__1); var tmp47 *lang.Var; A_arbace_test_A_Init(); tmp47 = A_arbace_test_A_const_13; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Keyword; A_arbace_test_A_Init(); tmp49 = A_arbace_test_A_const_60; var tmp50 any = tmp48.Invoke_O__O(tmp49.Ref()); var tmp51 *lang.Var; A_arbace_test_A_Init(); tmp51 = A_arbace_test_A_const_13; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 *lang.Var; A_arbace_test_A_Init(); tmp53 = A_arbace_test_A_const_11; var tmp54 lang.IFn = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()); var tmp55 *lang.Var; A_arbace_test_A_Init(); tmp55 = A_arbace_test_A_const_12; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.Var; A_arbace_test_A_Init(); tmp57 = A_arbace_test_A_const_13; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 any; A_arbace_test_A_Init(); tmp59 = A_arbace_test_A_const_82; var tmp60 any = tmp58.Invoke_O__O(tmp59); var tmp61 *lang.Var; A_arbace_test_A_Init(); tmp61 = A_arbace_test_A_const_13; var tmp62 any = tmp52.Invoke_O__O(tmp54.Invoke_O__O(tmp56.Invoke_O_O__O(tmp60, lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()).Invoke_O__O(form__2)))); var tmp63 *lang.Var; A_arbace_test_A_Init(); tmp63 = A_arbace_test_A_const_13; var tmp64 lang.IFn = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()); var tmp65 *lang.Keyword; A_arbace_test_A_Init(); tmp65 = A_arbace_test_A_const_44; var tmp66 any = tmp64.Invoke_O__O(tmp65.Ref()); var tmp67 *lang.Var; A_arbace_test_A_Init(); tmp67 = A_arbace_test_A_const_13; var tmp68 any = tmp14.Invoke_O__O(tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp22, tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp28, tmp30.Invoke_O__O(tmp32.Invoke_O_O_O_O_O_O_O_O__O(tmp36, tmp40, tmp44, tmp46, tmp50, tmp62, tmp66, lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()).Invoke_O__O(nil)))))))); var tmp69 *lang.Var; A_arbace_test_A_Init(); tmp69 = A_arbace_test_A_const_13; var tmp70 lang.IFn = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()); var tmp71 *lang.Var; A_arbace_test_A_Init(); tmp71 = A_arbace_test_A_const_11; var tmp72 lang.IFn = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()); var tmp73 *lang.Var; A_arbace_test_A_Init(); tmp73 = A_arbace_test_A_const_12; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *lang.Var; A_arbace_test_A_Init(); tmp75 = A_arbace_test_A_const_13; var tmp76 lang.IFn = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()); var tmp77 any; A_arbace_test_A_Init(); tmp77 = A_arbace_test_A_const_118; var tmp78 any = tmp76.Invoke_O__O(tmp77); var tmp79 *lang.Var; A_arbace_test_A_Init(); tmp79 = A_arbace_test_A_const_13; var tmp80 any = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()).Invoke_O__O(klass__3); var tmp81 *lang.Var; A_arbace_test_A_Init(); tmp81 = A_arbace_test_A_const_13; var tmp82 lang.IFn = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()); var tmp83 any; A_arbace_test_A_Init(); tmp83 = A_arbace_test_A_const_119; var tmp84 any = tmp82.Invoke_O__O(tmp83); var tmp85 *lang.Var; A_arbace_test_A_Init(); tmp85 = A_arbace_test_A_const_13; var tmp86 lang.IFn = lang.IFn_Cast(jrt.NN(tmp85).GetRawRoot__O()); var tmp87 *lang.Var; A_arbace_test_A_Init(); tmp87 = A_arbace_test_A_const_11; var tmp88 lang.IFn = lang.IFn_Cast(jrt.NN(tmp87).GetRawRoot__O()); var tmp89 *lang.Var; A_arbace_test_A_Init(); tmp89 = A_arbace_test_A_const_12; var tmp90 lang.IFn = lang.IFn_Cast(jrt.NN(tmp89).GetRawRoot__O()); var tmp91 *lang.Var; A_arbace_test_A_Init(); tmp91 = A_arbace_test_A_const_13; var tmp92 lang.IFn = lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()); var tmp93 any; A_arbace_test_A_Init(); tmp93 = A_arbace_test_A_const_120; var tmp94 any = tmp92.Invoke_O__O(tmp93); var tmp95 *lang.Var; A_arbace_test_A_Init(); tmp95 = A_arbace_test_A_const_13; var tmp96 lang.IFn = lang.IFn_Cast(jrt.NN(tmp95).GetRawRoot__O()); var tmp97 *lang.Var; A_arbace_test_A_Init(); tmp97 = A_arbace_test_A_const_15; var tmp98 lang.IFn = lang.IFn_Cast(jrt.NN(tmp97).GetRawRoot__O()); var tmp99 *lang.Var; A_arbace_test_A_Init(); tmp99 = A_arbace_test_A_const_50; var tmp100 any = jrt.NN(tmp99).GetRawRoot__O(); var tmp101 *lang.Var; A_arbace_test_A_Init(); tmp101 = A_arbace_test_A_const_11; var tmp102 lang.IFn = lang.IFn_Cast(jrt.NN(tmp101).GetRawRoot__O()); var tmp103 *lang.Var; A_arbace_test_A_Init(); tmp103 = A_arbace_test_A_const_12; var tmp104 lang.IFn = lang.IFn_Cast(jrt.NN(tmp103).GetRawRoot__O()); var tmp105 *lang.Var; A_arbace_test_A_Init(); tmp105 = A_arbace_test_A_const_13; var tmp106 lang.IFn = lang.IFn_Cast(jrt.NN(tmp105).GetRawRoot__O()); var tmp107 *lang.Keyword; A_arbace_test_A_Init(); tmp107 = A_arbace_test_A_const_39; var tmp108 any = tmp106.Invoke_O__O(tmp107.Ref()); var tmp109 *lang.Var; A_arbace_test_A_Init(); tmp109 = A_arbace_test_A_const_13; var tmp110 lang.IFn = lang.IFn_Cast(jrt.NN(tmp109).GetRawRoot__O()); var tmp111 *lang.Keyword; A_arbace_test_A_Init(); tmp111 = A_arbace_test_A_const_54; var tmp112 any = tmp110.Invoke_O__O(tmp111.Ref()); var tmp113 *lang.Var; A_arbace_test_A_Init(); tmp113 = A_arbace_test_A_const_13; var tmp114 lang.IFn = lang.IFn_Cast(jrt.NN(tmp113).GetRawRoot__O()); var tmp115 *lang.Keyword; A_arbace_test_A_Init(); tmp115 = A_arbace_test_A_const_56; var tmp116 any = tmp114.Invoke_O__O(tmp115.Ref()); var tmp117 *lang.Var; A_arbace_test_A_Init(); tmp117 = A_arbace_test_A_const_13; var tmp118 any = lang.IFn_Cast(jrt.NN(tmp117).GetRawRoot__O()).Invoke_O__O(msg__1); var tmp119 *lang.Var; A_arbace_test_A_Init(); tmp119 = A_arbace_test_A_const_13; var tmp120 lang.IFn = lang.IFn_Cast(jrt.NN(tmp119).GetRawRoot__O()); var tmp121 *lang.Keyword; A_arbace_test_A_Init(); tmp121 = A_arbace_test_A_const_60; var tmp122 any = tmp120.Invoke_O__O(tmp121.Ref()); var tmp123 *lang.Var; A_arbace_test_A_Init(); tmp123 = A_arbace_test_A_const_13; var tmp124 lang.IFn = lang.IFn_Cast(jrt.NN(tmp123).GetRawRoot__O()); var tmp125 *lang.Var; A_arbace_test_A_Init(); tmp125 = A_arbace_test_A_const_11; var tmp126 lang.IFn = lang.IFn_Cast(jrt.NN(tmp125).GetRawRoot__O()); var tmp127 *lang.Var; A_arbace_test_A_Init(); tmp127 = A_arbace_test_A_const_12; var tmp128 lang.IFn = lang.IFn_Cast(jrt.NN(tmp127).GetRawRoot__O()); var tmp129 *lang.Var; A_arbace_test_A_Init(); tmp129 = A_arbace_test_A_const_13; var tmp130 lang.IFn = lang.IFn_Cast(jrt.NN(tmp129).GetRawRoot__O()); var tmp131 any; A_arbace_test_A_Init(); tmp131 = A_arbace_test_A_const_82; var tmp132 any = tmp130.Invoke_O__O(tmp131); var tmp133 *lang.Var; A_arbace_test_A_Init(); tmp133 = A_arbace_test_A_const_13; var tmp134 any = tmp124.Invoke_O__O(tmp126.Invoke_O__O(tmp128.Invoke_O_O__O(tmp132, lang.IFn_Cast(jrt.NN(tmp133).GetRawRoot__O()).Invoke_O__O(form__2)))); var tmp135 *lang.Var; A_arbace_test_A_Init(); tmp135 = A_arbace_test_A_const_13; var tmp136 lang.IFn = lang.IFn_Cast(jrt.NN(tmp135).GetRawRoot__O()); var tmp137 *lang.Keyword; A_arbace_test_A_Init(); tmp137 = A_arbace_test_A_const_44; var tmp138 any = tmp136.Invoke_O__O(tmp137.Ref()); var tmp139 *lang.Var; A_arbace_test_A_Init(); tmp139 = A_arbace_test_A_const_13; var tmp140 lang.IFn = lang.IFn_Cast(jrt.NN(tmp139).GetRawRoot__O()); var tmp141 any; A_arbace_test_A_Init(); tmp141 = A_arbace_test_A_const_119; var tmp142 any = tmp86.Invoke_O__O(tmp88.Invoke_O__O(tmp90.Invoke_O_O__O(tmp94, tmp96.Invoke_O__O(tmp98.Invoke_O_O__O(tmp100, tmp102.Invoke_O__O(tmp104.Invoke_O_O_O_O_O_O_O_O__O(tmp108, tmp112, tmp116, tmp118, tmp122, tmp134, tmp138, tmp140.Invoke_O__O(tmp141)))))))); var tmp143 *lang.Var; A_arbace_test_A_Init(); tmp143 = A_arbace_test_A_const_13; var tmp144 lang.IFn = lang.IFn_Cast(jrt.NN(tmp143).GetRawRoot__O()); var tmp145 any; A_arbace_test_A_Init(); tmp145 = A_arbace_test_A_const_119; return tmp6.Invoke_O__O(tmp8.Invoke_O_O_O_O__O(tmp12, body__4, tmp68, tmp70.Invoke_O__O(tmp72.Invoke_O__O(tmp74.Invoke_O_O_O_O_O__O(tmp78, tmp80, tmp84, tmp142, tmp144.Invoke_O__O(tmp145)))))) }









func A_arbace_test_eval196000108_fn__196000109_A_New() *A_arbace_test_eval196000108_fn__196000109_A { A_arbace_test_eval196000108_fn__196000109_A_Init(); t := &A_arbace_test_eval196000108_fn__196000109_A{}; t.Ctor(); return t }
//line :508:1
func (t *A_arbace_test_eval196000108_fn__196000109_A) Ctor() {}
//line :508:1
func (t *A_arbace_test_eval196000108_fn__196000109_A) Invoke_O_O_O__O(self, msg__1, form__2 any) any { var klass__3 any = lang.RT_Nth_O_I__O(form__2, lang.RT_IntCast_J__I(1)); var re__4 any = lang.RT_Nth_O_I__O(form__2, lang.RT_IntCast_J__I(2)); var body__5 any; var tmp1 *lang.Var;






	A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_114; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_121; body__5 = tmp2.Invoke_O_O__O(form__2, tmp3); var tmp4 /*line :513:1*/*lang.Var; A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_11; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_test_A_Init(); tmp6 = A_arbace_test_A_const_12; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_test_A_Init(); tmp8 = A_arbace_test_A_const_13; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; A_arbace_test_A_Init(); tmp10 = A_arbace_test_A_const_122; var tmp11 any = tmp9.Invoke_O__O(tmp10); var tmp12 *lang.Var; A_arbace_test_A_Init(); tmp12 = A_arbace_test_A_const_13; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_test_A_Init(); tmp14 = A_arbace_test_A_const_11; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_test_A_Init(); tmp16 = A_arbace_test_A_const_12; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_test_A_Init(); tmp18 = A_arbace_test_A_const_13; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any; A_arbace_test_A_Init(); tmp20 = A_arbace_test_A_const_123; var tmp21 any = tmp19.Invoke_O__O(tmp20); var tmp22 *lang.Var; A_arbace_test_A_Init(); tmp22 = A_arbace_test_A_const_13; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_test_A_Init(); tmp24 = A_arbace_test_A_const_15; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_test_A_Init(); tmp26 = A_arbace_test_A_const_50; var tmp27 any = jrt.NN(tmp26).GetRawRoot__O(); var tmp28 *lang.Var; A_arbace_test_A_Init(); tmp28 = A_arbace_test_A_const_11; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_test_A_Init(); tmp30 = A_arbace_test_A_const_12; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_test_A_Init(); tmp32 = A_arbace_test_A_const_13; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Keyword; A_arbace_test_A_Init(); tmp34 = A_arbace_test_A_const_39; var tmp35 any = tmp33.Invoke_O__O(tmp34.Ref()); var tmp36 *lang.Var; A_arbace_test_A_Init(); tmp36 = A_arbace_test_A_const_13; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 *lang.Keyword; A_arbace_test_A_Init(); tmp38 = A_arbace_test_A_const_42; var tmp39 any = tmp37.Invoke_O__O(tmp38.Ref()); var tmp40 *lang.Var; A_arbace_test_A_Init(); tmp40 = A_arbace_test_A_const_13; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 *lang.Keyword; A_arbace_test_A_Init(); tmp42 = A_arbace_test_A_const_56; var tmp43 any = tmp41.Invoke_O__O(tmp42.Ref()); var tmp44 *lang.Var; A_arbace_test_A_Init(); tmp44 = A_arbace_test_A_const_13; var tmp45 any = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(msg__1); var tmp46 *lang.Var; A_arbace_test_A_Init(); tmp46 = A_arbace_test_A_const_13; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *lang.Keyword; A_arbace_test_A_Init(); tmp48 = A_arbace_test_A_const_60; var tmp49 any = tmp47.Invoke_O__O(tmp48.Ref()); var tmp50 *lang.Var; A_arbace_test_A_Init(); tmp50 = A_arbace_test_A_const_13; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 *lang.Var; A_arbace_test_A_Init(); tmp52 = A_arbace_test_A_const_11; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Var; A_arbace_test_A_Init(); tmp54 = A_arbace_test_A_const_12; var tmp55 lang.IFn = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()); var tmp56 *lang.Var; A_arbace_test_A_Init(); tmp56 = A_arbace_test_A_const_13; var tmp57 lang.IFn = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()); var tmp58 any; A_arbace_test_A_Init(); tmp58 = A_arbace_test_A_const_82; var tmp59 any = tmp57.Invoke_O__O(tmp58); var tmp60 *lang.Var; A_arbace_test_A_Init(); tmp60 = A_arbace_test_A_const_13; var tmp61 any = tmp51.Invoke_O__O(tmp53.Invoke_O__O(tmp55.Invoke_O_O__O(tmp59, lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke_O__O(form__2)))); var tmp62 *lang.Var; A_arbace_test_A_Init(); tmp62 = A_arbace_test_A_const_13; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 *lang.Keyword; A_arbace_test_A_Init(); tmp64 = A_arbace_test_A_const_44; var tmp65 any = tmp63.Invoke_O__O(tmp64.Ref()); var tmp66 *lang.Var; A_arbace_test_A_Init(); tmp66 = A_arbace_test_A_const_13; var tmp67 any = tmp13.Invoke_O__O(tmp15.Invoke_O__O(tmp17.Invoke_O_O__O(tmp21, tmp23.Invoke_O__O(tmp25.Invoke_O_O__O(tmp27, tmp29.Invoke_O__O(tmp31.Invoke_O_O_O_O_O_O_O_O__O(tmp35, tmp39, tmp43, tmp45, tmp49, tmp61, tmp65, lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()).Invoke_O__O(nil)))))))); var tmp68 *lang.Var; A_arbace_test_A_Init(); tmp68 = A_arbace_test_A_const_13; var tmp69 lang.IFn = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()); var tmp70 *lang.Var; A_arbace_test_A_Init(); tmp70 = A_arbace_test_A_const_11; var tmp71 lang.IFn = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()); var tmp72 *lang.Var; A_arbace_test_A_Init(); tmp72 = A_arbace_test_A_const_12; var tmp73 lang.IFn = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()); var tmp74 *lang.Var; A_arbace_test_A_Init(); tmp74 = A_arbace_test_A_const_13; var tmp75 lang.IFn = lang.IFn_Cast(jrt.NN(tmp74).GetRawRoot__O()); var tmp76 any; A_arbace_test_A_Init(); tmp76 = A_arbace_test_A_const_124; var tmp77 any = tmp75.Invoke_O__O(tmp76); var tmp78 *lang.Var; A_arbace_test_A_Init(); tmp78 = A_arbace_test_A_const_13; var tmp79 any = lang.IFn_Cast(jrt.NN(tmp78).GetRawRoot__O()).Invoke_O__O(klass__3); var tmp80 *lang.Var; A_arbace_test_A_Init(); tmp80 = A_arbace_test_A_const_13; var tmp81 lang.IFn = lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()); var tmp82 any; A_arbace_test_A_Init(); tmp82 = A_arbace_test_A_const_125; var tmp83 any = tmp81.Invoke_O__O(tmp82); var tmp84 *lang.Var; A_arbace_test_A_Init(); tmp84 = A_arbace_test_A_const_13; var tmp85 lang.IFn = lang.IFn_Cast(jrt.NN(tmp84).GetRawRoot__O()); var tmp86 *lang.Var; A_arbace_test_A_Init(); tmp86 = A_arbace_test_A_const_11; var tmp87 lang.IFn = lang.IFn_Cast(jrt.NN(tmp86).GetRawRoot__O()); var tmp88 *lang.Var; A_arbace_test_A_Init(); tmp88 = A_arbace_test_A_const_12; var tmp89 lang.IFn = lang.IFn_Cast(jrt.NN(tmp88).GetRawRoot__O()); var tmp90 *lang.Var; A_arbace_test_A_Init(); tmp90 = A_arbace_test_A_const_13; var tmp91 lang.IFn = lang.IFn_Cast(jrt.NN(tmp90).GetRawRoot__O()); var tmp92 any; A_arbace_test_A_Init(); tmp92 = A_arbace_test_A_const_126; var tmp93 any = tmp91.Invoke_O__O(tmp92); var tmp94 *lang.Var; A_arbace_test_A_Init(); tmp94 = A_arbace_test_A_const_13; var tmp95 lang.IFn = lang.IFn_Cast(jrt.NN(tmp94).GetRawRoot__O()); var tmp96 *lang.Var; A_arbace_test_A_Init(); tmp96 = A_arbace_test_A_const_15; var tmp97 lang.IFn = lang.IFn_Cast(jrt.NN(tmp96).GetRawRoot__O()); var tmp98 *lang.Var; A_arbace_test_A_Init(); tmp98 = A_arbace_test_A_const_16; var tmp99 any = jrt.NN(tmp98).GetRawRoot__O(); var tmp100 *lang.Var; A_arbace_test_A_Init(); tmp100 = A_arbace_test_A_const_11; var tmp101 lang.IFn = lang.IFn_Cast(jrt.NN(tmp100).GetRawRoot__O()); var tmp102 *lang.Var; A_arbace_test_A_Init(); tmp102 = A_arbace_test_A_const_12; var tmp103 lang.IFn = lang.IFn_Cast(jrt.NN(tmp102).GetRawRoot__O()); var tmp104 *lang.Var; A_arbace_test_A_Init(); tmp104 = A_arbace_test_A_const_13; var tmp105 lang.IFn = lang.IFn_Cast(jrt.NN(tmp104).GetRawRoot__O()); var tmp106 any; A_arbace_test_A_Init(); tmp106 = A_arbace_test_A_const_127; var tmp107 any = tmp105.Invoke_O__O(tmp106); var tmp108 *lang.Var; A_arbace_test_A_Init(); tmp108 = A_arbace_test_A_const_13; var tmp109 lang.IFn = lang.IFn_Cast(jrt.NN(tmp108).GetRawRoot__O()); var tmp110 *lang.Var; A_arbace_test_A_Init(); tmp110 = A_arbace_test_A_const_11; var tmp111 lang.IFn = lang.IFn_Cast(jrt.NN(tmp110).GetRawRoot__O()); var tmp112 *lang.Var; A_arbace_test_A_Init(); tmp112 = A_arbace_test_A_const_12; var tmp113 lang.IFn = lang.IFn_Cast(jrt.NN(tmp112).GetRawRoot__O()); var tmp114 *lang.Var; A_arbace_test_A_Init(); tmp114 = A_arbace_test_A_const_13; var tmp115 lang.IFn = lang.IFn_Cast(jrt.NN(tmp114).GetRawRoot__O()); var tmp116 any; A_arbace_test_A_Init(); tmp116 = A_arbace_test_A_const_128; var tmp117 any = tmp115.Invoke_O__O(tmp116); var tmp118 *lang.Var; A_arbace_test_A_Init(); tmp118 = A_arbace_test_A_const_13; var tmp119 lang.IFn = lang.IFn_Cast(jrt.NN(tmp118).GetRawRoot__O()); var tmp120 any; A_arbace_test_A_Init(); tmp120 = A_arbace_test_A_const_125; var tmp121 any = tmp95.Invoke_O__O(tmp97.Invoke_O_O__O(tmp99, tmp101.Invoke_O__O(tmp103.Invoke_O_O__O(tmp107, tmp109.Invoke_O__O(tmp111.Invoke_O__O(tmp113.Invoke_O_O__O(tmp117, tmp119.Invoke_O__O(tmp120)))))))); var tmp122 *lang.Var; A_arbace_test_A_Init(); tmp122 = A_arbace_test_A_const_13; var tmp123 lang.IFn = lang.IFn_Cast(jrt.NN(tmp122).GetRawRoot__O()); var tmp124 *lang.Var; A_arbace_test_A_Init(); tmp124 = A_arbace_test_A_const_11; var tmp125 lang.IFn = lang.IFn_Cast(jrt.NN(tmp124).GetRawRoot__O()); var tmp126 *lang.Var; A_arbace_test_A_Init(); tmp126 = A_arbace_test_A_const_12; var tmp127 lang.IFn = lang.IFn_Cast(jrt.NN(tmp126).GetRawRoot__O()); var tmp128 *lang.Var; A_arbace_test_A_Init(); tmp128 = A_arbace_test_A_const_13; var tmp129 lang.IFn = lang.IFn_Cast(jrt.NN(tmp128).GetRawRoot__O()); var tmp130 any; A_arbace_test_A_Init(); tmp130 = A_arbace_test_A_const_129; var tmp131 any = tmp129.Invoke_O__O(tmp130); var tmp132 *lang.Var; A_arbace_test_A_Init(); tmp132 = A_arbace_test_A_const_13; var tmp133 lang.IFn = lang.IFn_Cast(jrt.NN(tmp132).GetRawRoot__O()); var tmp134 *lang.Var; A_arbace_test_A_Init(); tmp134 = A_arbace_test_A_const_11; var tmp135 lang.IFn = lang.IFn_Cast(jrt.NN(tmp134).GetRawRoot__O()); var tmp136 *lang.Var; A_arbace_test_A_Init(); tmp136 = A_arbace_test_A_const_12; var tmp137 lang.IFn = lang.IFn_Cast(jrt.NN(tmp136).GetRawRoot__O()); var tmp138 *lang.Var; A_arbace_test_A_Init(); tmp138 = A_arbace_test_A_const_13; var tmp139 lang.IFn = lang.IFn_Cast(jrt.NN(tmp138).GetRawRoot__O()); var tmp140 any; A_arbace_test_A_Init(); tmp140 = A_arbace_test_A_const_130; var tmp141 any = tmp139.Invoke_O__O(tmp140); var tmp142 *lang.Var; A_arbace_test_A_Init(); tmp142 = A_arbace_test_A_const_13; var tmp143 any = lang.IFn_Cast(jrt.NN(tmp142).GetRawRoot__O()).Invoke_O__O(re__4); var tmp144 *lang.Var; A_arbace_test_A_Init(); tmp144 = A_arbace_test_A_const_13; var tmp145 lang.IFn = lang.IFn_Cast(jrt.NN(tmp144).GetRawRoot__O()); var tmp146 any; A_arbace_test_A_Init(); tmp146 = A_arbace_test_A_const_127; var tmp147 any = tmp133.Invoke_O__O(tmp135.Invoke_O__O(tmp137.Invoke_O_O_O__O(tmp141, tmp143, tmp145.Invoke_O__O(tmp146)))); var tmp148 *lang.Var; A_arbace_test_A_Init(); tmp148 = A_arbace_test_A_const_13; var tmp149 lang.IFn = lang.IFn_Cast(jrt.NN(tmp148).GetRawRoot__O()); var tmp150 *lang.Var; A_arbace_test_A_Init(); tmp150 = A_arbace_test_A_const_11; var tmp151 lang.IFn = lang.IFn_Cast(jrt.NN(tmp150).GetRawRoot__O()); var tmp152 *lang.Var; A_arbace_test_A_Init(); tmp152 = A_arbace_test_A_const_12; var tmp153 lang.IFn = lang.IFn_Cast(jrt.NN(tmp152).GetRawRoot__O()); var tmp154 *lang.Var; A_arbace_test_A_Init(); tmp154 = A_arbace_test_A_const_13; var tmp155 lang.IFn = lang.IFn_Cast(jrt.NN(tmp154).GetRawRoot__O()); var tmp156 any; A_arbace_test_A_Init(); tmp156 = A_arbace_test_A_const_131; var tmp157 any = tmp155.Invoke_O__O(tmp156); var tmp158 *lang.Var; A_arbace_test_A_Init(); tmp158 = A_arbace_test_A_const_13; var tmp159 lang.IFn = lang.IFn_Cast(jrt.NN(tmp158).GetRawRoot__O()); var tmp160 *lang.Var; A_arbace_test_A_Init(); tmp160 = A_arbace_test_A_const_15; var tmp161 lang.IFn = lang.IFn_Cast(jrt.NN(tmp160).GetRawRoot__O()); var tmp162 *lang.Var; A_arbace_test_A_Init(); tmp162 = A_arbace_test_A_const_50; var tmp163 any = jrt.NN(tmp162).GetRawRoot__O(); var tmp164 *lang.Var; A_arbace_test_A_Init(); tmp164 = A_arbace_test_A_const_11; var tmp165 lang.IFn = lang.IFn_Cast(jrt.NN(tmp164).GetRawRoot__O()); var tmp166 *lang.Var; A_arbace_test_A_Init(); tmp166 = A_arbace_test_A_const_12; var tmp167 lang.IFn = lang.IFn_Cast(jrt.NN(tmp166).GetRawRoot__O()); var tmp168 *lang.Var; A_arbace_test_A_Init(); tmp168 = A_arbace_test_A_const_13; var tmp169 lang.IFn = lang.IFn_Cast(jrt.NN(tmp168).GetRawRoot__O()); var tmp170 *lang.Keyword; A_arbace_test_A_Init(); tmp170 = A_arbace_test_A_const_39; var tmp171 any = tmp169.Invoke_O__O(tmp170.Ref()); var tmp172 *lang.Var; A_arbace_test_A_Init(); tmp172 = A_arbace_test_A_const_13; var tmp173 lang.IFn = lang.IFn_Cast(jrt.NN(tmp172).GetRawRoot__O()); var tmp174 *lang.Keyword; A_arbace_test_A_Init(); tmp174 = A_arbace_test_A_const_54; var tmp175 any = tmp173.Invoke_O__O(tmp174.Ref()); var tmp176 *lang.Var; A_arbace_test_A_Init(); tmp176 = A_arbace_test_A_const_13; var tmp177 lang.IFn = lang.IFn_Cast(jrt.NN(tmp176).GetRawRoot__O()); var tmp178 *lang.Keyword; A_arbace_test_A_Init(); tmp178 = A_arbace_test_A_const_56; var tmp179 any = tmp177.Invoke_O__O(tmp178.Ref()); var tmp180 *lang.Var; A_arbace_test_A_Init(); tmp180 = A_arbace_test_A_const_13; var tmp181 any = lang.IFn_Cast(jrt.NN(tmp180).GetRawRoot__O()).Invoke_O__O(msg__1); var tmp182 *lang.Var; A_arbace_test_A_Init(); tmp182 = A_arbace_test_A_const_13; var tmp183 lang.IFn = lang.IFn_Cast(jrt.NN(tmp182).GetRawRoot__O()); var tmp184 *lang.Keyword; A_arbace_test_A_Init(); tmp184 = A_arbace_test_A_const_60; var tmp185 any = tmp183.Invoke_O__O(tmp184.Ref()); var tmp186 *lang.Var; A_arbace_test_A_Init(); tmp186 = A_arbace_test_A_const_13; var tmp187 lang.IFn = lang.IFn_Cast(jrt.NN(tmp186).GetRawRoot__O()); var tmp188 *lang.Var; A_arbace_test_A_Init(); tmp188 = A_arbace_test_A_const_11; var tmp189 lang.IFn = lang.IFn_Cast(jrt.NN(tmp188).GetRawRoot__O()); var tmp190 *lang.Var; A_arbace_test_A_Init(); tmp190 = A_arbace_test_A_const_12; var tmp191 lang.IFn = lang.IFn_Cast(jrt.NN(tmp190).GetRawRoot__O()); var tmp192 *lang.Var; A_arbace_test_A_Init(); tmp192 = A_arbace_test_A_const_13; var tmp193 lang.IFn = lang.IFn_Cast(jrt.NN(tmp192).GetRawRoot__O()); var tmp194 any; A_arbace_test_A_Init(); tmp194 = A_arbace_test_A_const_82; var tmp195 any = tmp193.Invoke_O__O(tmp194); var tmp196 *lang.Var; A_arbace_test_A_Init(); tmp196 = A_arbace_test_A_const_13; var tmp197 any = tmp187.Invoke_O__O(tmp189.Invoke_O__O(tmp191.Invoke_O_O__O(tmp195, lang.IFn_Cast(jrt.NN(tmp196).GetRawRoot__O()).Invoke_O__O(form__2)))); var tmp198 *lang.Var; A_arbace_test_A_Init(); tmp198 = A_arbace_test_A_const_13; var tmp199 lang.IFn = lang.IFn_Cast(jrt.NN(tmp198).GetRawRoot__O()); var tmp200 *lang.Keyword; A_arbace_test_A_Init(); tmp200 = A_arbace_test_A_const_44; var tmp201 any = tmp199.Invoke_O__O(tmp200.Ref()); var tmp202 *lang.Var; A_arbace_test_A_Init(); tmp202 = A_arbace_test_A_const_13; var tmp203 lang.IFn = lang.IFn_Cast(jrt.NN(tmp202).GetRawRoot__O()); var tmp204 any; A_arbace_test_A_Init(); tmp204 = A_arbace_test_A_const_125; var tmp205 any = tmp149.Invoke_O__O(tmp151.Invoke_O__O(tmp153.Invoke_O_O__O(tmp157, tmp159.Invoke_O__O(tmp161.Invoke_O_O__O(tmp163, tmp165.Invoke_O__O(tmp167.Invoke_O_O_O_O_O_O_O_O__O(tmp171, tmp175, tmp179, tmp181, tmp185, tmp197, tmp201, tmp203.Invoke_O__O(tmp204)))))))); var tmp206 *lang.Var; A_arbace_test_A_Init(); tmp206 = A_arbace_test_A_const_13; var tmp207 lang.IFn = lang.IFn_Cast(jrt.NN(tmp206).GetRawRoot__O()); var tmp208 *lang.Var; A_arbace_test_A_Init(); tmp208 = A_arbace_test_A_const_11; var tmp209 lang.IFn = lang.IFn_Cast(jrt.NN(tmp208).GetRawRoot__O()); var tmp210 *lang.Var; A_arbace_test_A_Init(); tmp210 = A_arbace_test_A_const_12; var tmp211 lang.IFn = lang.IFn_Cast(jrt.NN(tmp210).GetRawRoot__O()); var tmp212 *lang.Var; A_arbace_test_A_Init(); tmp212 = A_arbace_test_A_const_13; var tmp213 lang.IFn = lang.IFn_Cast(jrt.NN(tmp212).GetRawRoot__O()); var tmp214 any; A_arbace_test_A_Init(); tmp214 = A_arbace_test_A_const_132; var tmp215 any = tmp213.Invoke_O__O(tmp214); var tmp216 *lang.Var; A_arbace_test_A_Init(); tmp216 = A_arbace_test_A_const_13; var tmp217 lang.IFn = lang.IFn_Cast(jrt.NN(tmp216).GetRawRoot__O()); var tmp218 *lang.Var; A_arbace_test_A_Init(); tmp218 = A_arbace_test_A_const_15; var tmp219 lang.IFn = lang.IFn_Cast(jrt.NN(tmp218).GetRawRoot__O()); var tmp220 *lang.Var; A_arbace_test_A_Init(); tmp220 = A_arbace_test_A_const_50; var tmp221 any = jrt.NN(tmp220).GetRawRoot__O(); var tmp222 *lang.Var; A_arbace_test_A_Init(); tmp222 = A_arbace_test_A_const_11; var tmp223 lang.IFn = lang.IFn_Cast(jrt.NN(tmp222).GetRawRoot__O()); var tmp224 *lang.Var; A_arbace_test_A_Init(); tmp224 = A_arbace_test_A_const_12; var tmp225 lang.IFn = lang.IFn_Cast(jrt.NN(tmp224).GetRawRoot__O()); var tmp226 *lang.Var; A_arbace_test_A_Init(); tmp226 = A_arbace_test_A_const_13; var tmp227 lang.IFn = lang.IFn_Cast(jrt.NN(tmp226).GetRawRoot__O()); var tmp228 *lang.Keyword; A_arbace_test_A_Init(); tmp228 = A_arbace_test_A_const_39; var tmp229 any = tmp227.Invoke_O__O(tmp228.Ref()); var tmp230 *lang.Var; A_arbace_test_A_Init(); tmp230 = A_arbace_test_A_const_13; var tmp231 lang.IFn = lang.IFn_Cast(jrt.NN(tmp230).GetRawRoot__O()); var tmp232 *lang.Keyword; A_arbace_test_A_Init(); tmp232 = A_arbace_test_A_const_42; var tmp233 any = tmp231.Invoke_O__O(tmp232.Ref()); var tmp234 *lang.Var; A_arbace_test_A_Init(); tmp234 = A_arbace_test_A_const_13; var tmp235 lang.IFn = lang.IFn_Cast(jrt.NN(tmp234).GetRawRoot__O()); var tmp236 *lang.Keyword; A_arbace_test_A_Init(); tmp236 = A_arbace_test_A_const_56; var tmp237 any = tmp235.Invoke_O__O(tmp236.Ref()); var tmp238 *lang.Var; A_arbace_test_A_Init(); tmp238 = A_arbace_test_A_const_13; var tmp239 any = lang.IFn_Cast(jrt.NN(tmp238).GetRawRoot__O()).Invoke_O__O(msg__1); var tmp240 *lang.Var; A_arbace_test_A_Init(); tmp240 = A_arbace_test_A_const_13; var tmp241 lang.IFn = lang.IFn_Cast(jrt.NN(tmp240).GetRawRoot__O()); var tmp242 *lang.Keyword; A_arbace_test_A_Init(); tmp242 = A_arbace_test_A_const_60; var tmp243 any = tmp241.Invoke_O__O(tmp242.Ref()); var tmp244 *lang.Var; A_arbace_test_A_Init(); tmp244 = A_arbace_test_A_const_13; var tmp245 lang.IFn = lang.IFn_Cast(jrt.NN(tmp244).GetRawRoot__O()); var tmp246 *lang.Var; A_arbace_test_A_Init(); tmp246 = A_arbace_test_A_const_11; var tmp247 lang.IFn = lang.IFn_Cast(jrt.NN(tmp246).GetRawRoot__O()); var tmp248 *lang.Var; A_arbace_test_A_Init(); tmp248 = A_arbace_test_A_const_12; var tmp249 lang.IFn = lang.IFn_Cast(jrt.NN(tmp248).GetRawRoot__O()); var tmp250 *lang.Var; A_arbace_test_A_Init(); tmp250 = A_arbace_test_A_const_13; var tmp251 lang.IFn = lang.IFn_Cast(jrt.NN(tmp250).GetRawRoot__O()); var tmp252 any; A_arbace_test_A_Init(); tmp252 = A_arbace_test_A_const_82; var tmp253 any = tmp251.Invoke_O__O(tmp252); var tmp254 *lang.Var; A_arbace_test_A_Init(); tmp254 = A_arbace_test_A_const_13; var tmp255 any = tmp245.Invoke_O__O(tmp247.Invoke_O__O(tmp249.Invoke_O_O__O(tmp253, lang.IFn_Cast(jrt.NN(tmp254).GetRawRoot__O()).Invoke_O__O(form__2)))); var tmp256 *lang.Var; A_arbace_test_A_Init(); tmp256 = A_arbace_test_A_const_13; var tmp257 lang.IFn = lang.IFn_Cast(jrt.NN(tmp256).GetRawRoot__O()); var tmp258 *lang.Keyword; A_arbace_test_A_Init(); tmp258 = A_arbace_test_A_const_44; var tmp259 any = tmp257.Invoke_O__O(tmp258.Ref()); var tmp260 *lang.Var; A_arbace_test_A_Init(); tmp260 = A_arbace_test_A_const_13; var tmp261 lang.IFn = lang.IFn_Cast(jrt.NN(tmp260).GetRawRoot__O()); var tmp262 any; A_arbace_test_A_Init(); tmp262 = A_arbace_test_A_const_125; var tmp263 any = tmp85.Invoke_O__O(tmp87.Invoke_O__O(tmp89.Invoke_O_O_O__O(tmp93, tmp121, tmp123.Invoke_O__O(tmp125.Invoke_O__O(tmp127.Invoke_O_O_O_O__O(tmp131, tmp147, tmp205, tmp207.Invoke_O__O(tmp209.Invoke_O__O(tmp211.Invoke_O_O__O(tmp215, tmp217.Invoke_O__O(tmp219.Invoke_O_O__O(tmp221, tmp223.Invoke_O__O(tmp225.Invoke_O_O_O_O_O_O_O_O__O(tmp229, tmp233, tmp237, tmp239, tmp243, tmp255, tmp259, tmp261.Invoke_O__O(tmp262)))))))))))))); var tmp264 *lang.Var; A_arbace_test_A_Init(); tmp264 = A_arbace_test_A_const_13; var tmp265 lang.IFn = lang.IFn_Cast(jrt.NN(tmp264).GetRawRoot__O()); var tmp266 any; A_arbace_test_A_Init(); tmp266 = A_arbace_test_A_const_125; return tmp5.Invoke_O__O(tmp7.Invoke_O_O_O_O__O(tmp11, body__5, tmp67, tmp69.Invoke_O__O(tmp71.Invoke_O__O(tmp73.Invoke_O_O_O_O_O__O(tmp77, tmp79, tmp83, tmp263, tmp265.Invoke_O__O(tmp266)))))) }













func A_arbace_test_try_expr_A_New() *A_arbace_test_try_expr_A { A_arbace_test_try_expr_A_Init(); t := &A_arbace_test_try_expr_A{}; t.Ctor(); return t }
//line :527:1
func (t *A_arbace_test_try_expr_A) Ctor() {}
//line :527:1
func (t *A_arbace_test_try_expr_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, msg__2, form__3 any) any { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_12; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_13; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_133; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_13; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_134; var tmp12 any = tmp10.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O__O(msg__2, form__3)); var tmp13 *lang.Var; A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_13; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_11; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_12; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_test_A_Init(); tmp19 = A_arbace_test_A_const_13; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_test_A_Init(); tmp21 = A_arbace_test_A_const_135; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_test_A_Init(); tmp23 = A_arbace_test_A_const_13; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_136; var tmp26 any = tmp24.Invoke_O__O(tmp25); var tmp27 *lang.Var; A_arbace_test_A_Init(); tmp27 = A_arbace_test_A_const_13; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_test_A_Init(); tmp29 = A_arbace_test_A_const_137; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 *lang.Var; A_arbace_test_A_Init(); tmp31 = A_arbace_test_A_const_13; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_test_A_Init(); tmp33 = A_arbace_test_A_const_11; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_test_A_Init(); tmp35 = A_arbace_test_A_const_12; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_test_A_Init(); tmp37 = A_arbace_test_A_const_13; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 any; A_arbace_test_A_Init(); tmp39 = A_arbace_test_A_const_138; var tmp40 any = tmp38.Invoke_O__O(tmp39); var tmp41 *lang.Var; A_arbace_test_A_Init(); tmp41 = A_arbace_test_A_const_13; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Var; A_arbace_test_A_Init(); tmp43 = A_arbace_test_A_const_15; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Var; A_arbace_test_A_Init(); tmp45 = A_arbace_test_A_const_50; var tmp46 any = jrt.NN(tmp45).GetRawRoot__O(); var tmp47 *lang.Var; A_arbace_test_A_Init(); tmp47 = A_arbace_test_A_const_11; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Var; A_arbace_test_A_Init(); tmp49 = A_arbace_test_A_const_12; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *lang.Var; A_arbace_test_A_Init(); tmp51 = A_arbace_test_A_const_13; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 *lang.Keyword; A_arbace_test_A_Init(); tmp53 = A_arbace_test_A_const_39; var tmp54 any = tmp52.Invoke_O__O(tmp53.Ref()); var tmp55 *lang.Var; A_arbace_test_A_Init(); tmp55 = A_arbace_test_A_const_13; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.Keyword; A_arbace_test_A_Init(); tmp57 = A_arbace_test_A_const_40; var tmp58 any = tmp56.Invoke_O__O(tmp57.Ref()); var tmp59 *lang.Var; A_arbace_test_A_Init(); tmp59 = A_arbace_test_A_const_13; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 *lang.Keyword; A_arbace_test_A_Init(); tmp61 = A_arbace_test_A_const_56; var tmp62 any = tmp60.Invoke_O__O(tmp61.Ref()); var tmp63 *lang.Var; A_arbace_test_A_Init(); tmp63 = A_arbace_test_A_const_13; var tmp64 any = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()).Invoke_O__O(msg__2); var tmp65 *lang.Var; A_arbace_test_A_Init(); tmp65 = A_arbace_test_A_const_13; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 *lang.Keyword; A_arbace_test_A_Init(); tmp67 = A_arbace_test_A_const_60; var tmp68 any = tmp66.Invoke_O__O(tmp67.Ref()); var tmp69 *lang.Var; A_arbace_test_A_Init(); tmp69 = A_arbace_test_A_const_13; var tmp70 lang.IFn = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()); var tmp71 *lang.Var; A_arbace_test_A_Init(); tmp71 = A_arbace_test_A_const_11; var tmp72 lang.IFn = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()); var tmp73 *lang.Var; A_arbace_test_A_Init(); tmp73 = A_arbace_test_A_const_12; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *lang.Var; A_arbace_test_A_Init(); tmp75 = A_arbace_test_A_const_13; var tmp76 lang.IFn = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()); var tmp77 any; A_arbace_test_A_Init(); tmp77 = A_arbace_test_A_const_82; var tmp78 any = tmp76.Invoke_O__O(tmp77); var tmp79 *lang.Var; A_arbace_test_A_Init(); tmp79 = A_arbace_test_A_const_13; var tmp80 any = tmp70.Invoke_O__O(tmp72.Invoke_O__O(tmp74.Invoke_O_O__O(tmp78, lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()).Invoke_O__O(form__3)))); var tmp81 *lang.Var; A_arbace_test_A_Init(); tmp81 = A_arbace_test_A_const_13; var tmp82 lang.IFn = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()); var tmp83 *lang.Keyword; A_arbace_test_A_Init(); tmp83 = A_arbace_test_A_const_44; var tmp84 any = tmp82.Invoke_O__O(tmp83.Ref()); var tmp85 *lang.Var; A_arbace_test_A_Init(); tmp85 = A_arbace_test_A_const_13; var tmp86 lang.IFn = lang.IFn_Cast(jrt.NN(tmp85).GetRawRoot__O()); var tmp87 any; A_arbace_test_A_Init(); tmp87 = A_arbace_test_A_const_137; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp12, tmp14.Invoke_O__O(tmp16.Invoke_O__O(tmp18.Invoke_O_O_O_O__O(tmp22, tmp26, tmp30, tmp32.Invoke_O__O(tmp34.Invoke_O__O(tmp36.Invoke_O_O__O(tmp40, tmp42.Invoke_O__O(tmp44.Invoke_O_O__O(tmp46, tmp48.Invoke_O__O(tmp50.Invoke_O_O_O_O_O_O_O_O__O(tmp54, tmp58, tmp62, tmp64, tmp68, tmp80, tmp84, tmp86.Invoke_O__O(tmp87))))))))))))) }













func A_arbace_test_is_A_New() *A_arbace_test_is_A { A_arbace_test_is_A_Init(); t := &A_arbace_test_is_A{}; t.Ctor(); return t }
//line :541:1
func (t *A_arbace_test_is_A) Ctor() {}
//line :541:1
func (t *A_arbace_test_is_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, form__2, msg__3 any) any { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_12; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_13; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_139; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_13; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(msg__3); var tmp11 *lang.Var; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_13; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp10, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(form__2))) }
//line :541:1
func (t *A_arbace_test_is_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, form__2 any) any { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_12; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_13; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_140; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_13; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(form__2); var tmp11 *lang.Var; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_13; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp10, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(nil))) }

















func A_arbace_test_are_A_New() *A_arbace_test_are_A { A_arbace_test_are_A_Init(); t := &A_arbace_test_are_A{}; t.Ctor(); return t }
//line :559:1
func (t *A_arbace_test_are_A) Ctor() {}
//line :559:1
func (t *A_arbace_test_are_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, argv__2, expr__3, args__4 any) any {














	var tmp1 any; var or__1927000174__auto____6 any; var and__1927000168__auto____6 any; var tmp2 *lang.Var

	A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_141; and__1927000168__auto____6 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(argv__2); if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_141; or__1927000174__auto____6 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(args__4) } else { or__1927000174__auto____6 = and__1927000168__auto____6 }
//line :574:1
	if jrt.A2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { var and__1927000168__auto____7 bool = lang.Numbers_IsPos_J__Z(int64(lang.RT_Count_O__I(argv__2)))



		if and__1927000168__auto____7 { var and__1927000168__auto____8 bool = lang.Numbers_IsPos_J__Z(int64(lang.RT_Count_O__I(args__4))); if and__1927000168__auto____8 {

			var tmp4 *lang.Var; A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_142; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_O__Z(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(args__4)).Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(argv__2)).Ref()))).Ref() } else {
//line :578:1
				tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() } }
//line :574:1
	if jrt.A2g_Truth(tmp1) { var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_11; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_12; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_13; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_143; var tmp12 any = tmp10.Invoke_O__O(tmp11); var tmp13 *lang.Var; A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_13; var tmp14 any = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(argv__2); var tmp15 *lang.Var; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_13; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_11; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_test_A_Init(); tmp19 = A_arbace_test_A_const_12; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_test_A_Init(); tmp21 = A_arbace_test_A_const_13; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any; A_arbace_test_A_Init(); tmp23 = A_arbace_test_A_const_144; var tmp24 any = tmp22.Invoke_O__O(tmp23); var tmp25 *lang.Var; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_13; return tmp6.Invoke_O__O(tmp8.Invoke_O_O_O_O__O(tmp12, tmp14, tmp16.Invoke_O__O(tmp18.Invoke_O__O(tmp20.Invoke_O_O__O(tmp24, lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(expr__3)))), args__4)) } else { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(Lit_164)))
	}
}







func A_arbace_test_testing_A_New() *A_arbace_test_testing_A { A_arbace_test_testing_A_Init(); t := &A_arbace_test_testing_A{}; t.Ctor(); return t }
//line :584:1
func (t *A_arbace_test_testing_A) Ctor() {}
//line :584:1
func (t *A_arbace_test_testing_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, string__2, body__3 any) any { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_12; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_13; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_145; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_13; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_15; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_16; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_11; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_12; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_test_A_Init(); tmp19 = A_arbace_test_A_const_13; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_test_A_Init(); tmp21 = A_arbace_test_A_const_146; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_test_A_Init(); tmp23 = A_arbace_test_A_const_13; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_11; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_test_A_Init(); tmp27 = A_arbace_test_A_const_12; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_test_A_Init(); tmp29 = A_arbace_test_A_const_13; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 any; A_arbace_test_A_Init(); tmp31 = A_arbace_test_A_const_147; var tmp32 any = tmp30.Invoke_O__O(tmp31); var tmp33 *lang.Var; A_arbace_test_A_Init(); tmp33 = A_arbace_test_A_const_13; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 any; A_arbace_test_A_Init(); tmp35 = A_arbace_test_A_const_148; var tmp36 any = tmp34.Invoke_O__O(tmp35); var tmp37 *lang.Var; A_arbace_test_A_Init(); tmp37 = A_arbace_test_A_const_13; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp22, tmp24.Invoke_O__O(tmp26.Invoke_O__O(tmp28.Invoke_O_O_O__O(tmp32, tmp36, lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(string__2)))))))), body__3)) }









func A_arbace_test_with_test_A_New() *A_arbace_test_with_test_A { A_arbace_test_with_test_A_Init(); t := &A_arbace_test_with_test_A{}; t.Ctor(); return t }
//line :594:1
func (t *A_arbace_test_with_test_A) Ctor() {}
//line :594:1
func (t *A_arbace_test_with_test_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, definition__2, body__3 any) any {







	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_149; if jrt.A2g_Truth(jrt.NN(tmp1).Get__O()) { var tmp2 *lang.Var; A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_11; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_12; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_test_A_Init(); tmp6 = A_arbace_test_A_const_13; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_test_A_Init(); tmp8 = A_arbace_test_A_const_150; var tmp9 any = tmp7.Invoke_O__O(tmp8); var tmp10 *lang.Var; A_arbace_test_A_Init(); tmp10 = A_arbace_test_A_const_13; var tmp11 any = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(definition__2); var tmp12 *lang.Var; A_arbace_test_A_Init(); tmp12 = A_arbace_test_A_const_13; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_test_A_Init(); tmp14 = A_arbace_test_A_const_11; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_test_A_Init(); tmp16 = A_arbace_test_A_const_12; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_test_A_Init(); tmp18 = A_arbace_test_A_const_13; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any; A_arbace_test_A_Init(); tmp20 = A_arbace_test_A_const_151; var tmp21 any = tmp19.Invoke_O__O(tmp20); var tmp22 *lang.Var; A_arbace_test_A_Init(); tmp22 = A_arbace_test_A_const_13; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any; A_arbace_test_A_Init(); tmp24 = A_arbace_test_A_const_152; var tmp25 any = tmp23.Invoke_O__O(tmp24); var tmp26 *lang.Var; A_arbace_test_A_Init(); tmp26 = A_arbace_test_A_const_13; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Keyword; A_arbace_test_A_Init(); tmp28 = A_arbace_test_A_const_64; var tmp29 any = tmp27.Invoke_O__O(tmp28.Ref()); var tmp30 *lang.Var; A_arbace_test_A_Init(); tmp30 = A_arbace_test_A_const_13; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_test_A_Init(); tmp32 = A_arbace_test_A_const_11; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_test_A_Init(); tmp34 = A_arbace_test_A_const_12; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 *lang.Var; A_arbace_test_A_Init(); tmp36 = A_arbace_test_A_const_13; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 any; A_arbace_test_A_Init(); tmp38 = A_arbace_test_A_const_153; var tmp39 any = tmp37.Invoke_O__O(tmp38); var tmp40 *lang.Var; A_arbace_test_A_Init(); tmp40 = A_arbace_test_A_const_13; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 *lang.Var; A_arbace_test_A_Init(); tmp42 = A_arbace_test_A_const_15; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 *lang.Var; A_arbace_test_A_Init(); tmp44 = A_arbace_test_A_const_16; var tmp45 any = jrt.NN(tmp44).GetRawRoot__O(); var tmp46 *lang.Var; A_arbace_test_A_Init(); tmp46 = A_arbace_test_A_const_11; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *lang.Var; A_arbace_test_A_Init(); tmp48 = A_arbace_test_A_const_12; return tmp3.Invoke_O__O(tmp5.Invoke_O_O_O__O(tmp9, tmp11, tmp13.Invoke_O__O(tmp15.Invoke_O__O(tmp17.Invoke_O_O_O_O__O(tmp21, tmp25, tmp29, tmp31.Invoke_O__O(tmp33.Invoke_O__O(tmp35.Invoke_O_O_O__O(tmp39, tmp41.Invoke_O__O(tmp43.Invoke_O_O__O(tmp45, tmp47.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()).Invoke__O()))), body__3)))))))) } else { return definition__2
	}
}

func A_arbace_test_deftest_A_New() *A_arbace_test_deftest_A { A_arbace_test_deftest_A_Init(); t := &A_arbace_test_deftest_A{}; t.Ctor(); return t }
//line :606:1
func (t *A_arbace_test_deftest_A) Ctor() {}
//line :606:1
func (t *A_arbace_test_deftest_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, body__3 any) any {












	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_149; if jrt.A2g_Truth(jrt.NN(tmp1).Get__O()) { var tmp2 *lang.Var; A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_11; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_12; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_test_A_Init(); tmp6 = A_arbace_test_A_const_13; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_test_A_Init(); tmp8 = A_arbace_test_A_const_154; var tmp9 any = tmp7.Invoke_O__O(tmp8); var tmp10 *lang.Var; A_arbace_test_A_Init(); tmp10 = A_arbace_test_A_const_13; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_test_A_Init(); tmp12 = A_arbace_test_A_const_155; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_test_A_Init(); tmp14 = A_arbace_test_A_const_156; var tmp15 any = jrt.NN(tmp14).GetRawRoot__O(); var tmp16 *lang.Keyword; A_arbace_test_A_Init(); tmp16 = A_arbace_test_A_const_64; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Var; A_arbace_test_A_Init(); tmp18 = A_arbace_test_A_const_11; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_test_A_Init(); tmp20 = A_arbace_test_A_const_12; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_test_A_Init(); tmp22 = A_arbace_test_A_const_13; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any; A_arbace_test_A_Init(); tmp24 = A_arbace_test_A_const_157; var tmp25 any = tmp23.Invoke_O__O(tmp24); var tmp26 *lang.Var; A_arbace_test_A_Init(); tmp26 = A_arbace_test_A_const_13; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_test_A_Init(); tmp28 = A_arbace_test_A_const_15; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_test_A_Init(); tmp30 = A_arbace_test_A_const_16; var tmp31 any = jrt.NN(tmp30).GetRawRoot__O(); var tmp32 *lang.Var; A_arbace_test_A_Init(); tmp32 = A_arbace_test_A_const_11; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_test_A_Init(); tmp34 = A_arbace_test_A_const_12; var tmp35 any = tmp11.Invoke_O__O(tmp13.Invoke_O_O_O_O__O(name__2, tmp15, tmp17, tmp19.Invoke_O__O(tmp21.Invoke_O_O_O__O(tmp25, tmp27.Invoke_O__O(tmp29.Invoke_O_O__O(tmp31, tmp33.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke__O()))), body__3)))); var tmp36 *lang.Var; A_arbace_test_A_Init(); tmp36 = A_arbace_test_A_const_13; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 *lang.Var; A_arbace_test_A_Init(); tmp38 = A_arbace_test_A_const_11; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 *lang.Var; A_arbace_test_A_Init(); tmp40 = A_arbace_test_A_const_12; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 *lang.Var; A_arbace_test_A_Init(); tmp42 = A_arbace_test_A_const_13; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 any; A_arbace_test_A_Init(); tmp44 = A_arbace_test_A_const_158; var tmp45 any = tmp43.Invoke_O__O(tmp44); var tmp46 *lang.Var; A_arbace_test_A_Init(); tmp46 = A_arbace_test_A_const_13; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *lang.Var; A_arbace_test_A_Init(); tmp48 = A_arbace_test_A_const_15; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 *lang.Var; A_arbace_test_A_Init(); tmp50 = A_arbace_test_A_const_16; var tmp51 any = jrt.NN(tmp50).GetRawRoot__O(); var tmp52 *lang.Var; A_arbace_test_A_Init(); tmp52 = A_arbace_test_A_const_11; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Var; A_arbace_test_A_Init(); tmp54 = A_arbace_test_A_const_12; var tmp55 any = tmp47.Invoke_O__O(tmp49.Invoke_O_O__O(tmp51, tmp53.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()).Invoke__O()))); var tmp56 *lang.Var; A_arbace_test_A_Init(); tmp56 = A_arbace_test_A_const_13; var tmp57 lang.IFn = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()); var tmp58 *lang.Var; A_arbace_test_A_Init(); tmp58 = A_arbace_test_A_const_11; var tmp59 lang.IFn = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()); var tmp60 *lang.Var; A_arbace_test_A_Init(); tmp60 = A_arbace_test_A_const_12; var tmp61 lang.IFn = lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()); var tmp62 *lang.Var; A_arbace_test_A_Init(); tmp62 = A_arbace_test_A_const_13; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 any; A_arbace_test_A_Init(); tmp64 = A_arbace_test_A_const_159; var tmp65 any = tmp63.Invoke_O__O(tmp64); var tmp66 *lang.Var; A_arbace_test_A_Init(); tmp66 = A_arbace_test_A_const_13; var tmp67 lang.IFn = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()); var tmp68 *lang.Var; A_arbace_test_A_Init(); tmp68 = A_arbace_test_A_const_11; var tmp69 lang.IFn = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()); var tmp70 *lang.Var; A_arbace_test_A_Init(); tmp70 = A_arbace_test_A_const_12; var tmp71 lang.IFn = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()); var tmp72 *lang.Var; A_arbace_test_A_Init(); tmp72 = A_arbace_test_A_const_13; var tmp73 lang.IFn = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()); var tmp74 any; A_arbace_test_A_Init(); tmp74 = A_arbace_test_A_const_160; var tmp75 any = tmp73.Invoke_O__O(tmp74); var tmp76 *lang.Var; A_arbace_test_A_Init(); tmp76 = A_arbace_test_A_const_13; return tmp3.Invoke_O__O(tmp5.Invoke_O_O_O__O(tmp9, tmp35, tmp37.Invoke_O__O(tmp39.Invoke_O__O(tmp41.Invoke_O_O_O__O(tmp45, tmp55, tmp57.Invoke_O__O(tmp59.Invoke_O__O(tmp61.Invoke_O_O__O(tmp65, tmp67.Invoke_O__O(tmp69.Invoke_O__O(tmp71.Invoke_O_O__O(tmp75, lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()).Invoke_O__O(name__2)))))))))))) } else { return nil
	}
}

func A_arbace_test_deftest__A_New() *A_arbace_test_deftest__A { A_arbace_test_deftest__A_Init(); t := &A_arbace_test_deftest__A{}; t.Ctor(); return t }
//line :623:1
func (t *A_arbace_test_deftest__A) Ctor() {}
//line :623:1
func (t *A_arbace_test_deftest__A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, body__3 any) any {



	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_149; if jrt.A2g_Truth(jrt.NN(tmp1).Get__O()) { var tmp2 *lang.Var; A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_11; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_12; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_test_A_Init(); tmp6 = A_arbace_test_A_const_13; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_test_A_Init(); tmp8 = A_arbace_test_A_const_161; var tmp9 any = tmp7.Invoke_O__O(tmp8); var tmp10 *lang.Var; A_arbace_test_A_Init(); tmp10 = A_arbace_test_A_const_13; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_test_A_Init(); tmp12 = A_arbace_test_A_const_155; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_test_A_Init(); tmp14 = A_arbace_test_A_const_156; var tmp15 any = jrt.NN(tmp14).GetRawRoot__O(); var tmp16 *lang.Keyword; A_arbace_test_A_Init(); tmp16 = A_arbace_test_A_const_64; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Var; A_arbace_test_A_Init(); tmp18 = A_arbace_test_A_const_11; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_test_A_Init(); tmp20 = A_arbace_test_A_const_12; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_test_A_Init(); tmp22 = A_arbace_test_A_const_13; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any; A_arbace_test_A_Init(); tmp24 = A_arbace_test_A_const_163; var tmp25 any = tmp23.Invoke_O__O(tmp24); var tmp26 *lang.Var; A_arbace_test_A_Init(); tmp26 = A_arbace_test_A_const_13; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_test_A_Init(); tmp28 = A_arbace_test_A_const_15; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_test_A_Init(); tmp30 = A_arbace_test_A_const_16; var tmp31 any = jrt.NN(tmp30).GetRawRoot__O(); var tmp32 *lang.Var; A_arbace_test_A_Init(); tmp32 = A_arbace_test_A_const_11; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_test_A_Init(); tmp34 = A_arbace_test_A_const_12; var tmp35 any = tmp19.Invoke_O__O(tmp21.Invoke_O_O_O__O(tmp25, tmp27.Invoke_O__O(tmp29.Invoke_O_O__O(tmp31, tmp33.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke__O()))), body__3)); var tmp36 *lang.Keyword; A_arbace_test_A_Init(); tmp36 = A_arbace_test_A_const_162; var tmp37 any = tmp36.Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp11.Invoke_O__O(tmp13.Invoke_O_O_O_O_O_O__O(name__2, tmp15, tmp17, tmp35, tmp37, tmp38.Ref())); var tmp40 *lang.Var; A_arbace_test_A_Init(); tmp40 = A_arbace_test_A_const_13; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 *lang.Var; A_arbace_test_A_Init(); tmp42 = A_arbace_test_A_const_11; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 *lang.Var; A_arbace_test_A_Init(); tmp44 = A_arbace_test_A_const_12; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Var; A_arbace_test_A_Init(); tmp46 = A_arbace_test_A_const_13; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 any; A_arbace_test_A_Init(); tmp48 = A_arbace_test_A_const_164; var tmp49 any = tmp47.Invoke_O__O(tmp48); var tmp50 *lang.Var; A_arbace_test_A_Init(); tmp50 = A_arbace_test_A_const_13; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 *lang.Var; A_arbace_test_A_Init(); tmp52 = A_arbace_test_A_const_15; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Var; A_arbace_test_A_Init(); tmp54 = A_arbace_test_A_const_16; var tmp55 any = jrt.NN(tmp54).GetRawRoot__O(); var tmp56 *lang.Var; A_arbace_test_A_Init(); tmp56 = A_arbace_test_A_const_11; var tmp57 lang.IFn = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()); var tmp58 *lang.Var; A_arbace_test_A_Init(); tmp58 = A_arbace_test_A_const_12; var tmp59 any = tmp51.Invoke_O__O(tmp53.Invoke_O_O__O(tmp55, tmp57.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()).Invoke__O()))); var tmp60 *lang.Var; A_arbace_test_A_Init(); tmp60 = A_arbace_test_A_const_13; var tmp61 lang.IFn = lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()); var tmp62 *lang.Var; A_arbace_test_A_Init(); tmp62 = A_arbace_test_A_const_11; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 *lang.Var; A_arbace_test_A_Init(); tmp64 = A_arbace_test_A_const_12; var tmp65 lang.IFn = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()); var tmp66 *lang.Var; A_arbace_test_A_Init(); tmp66 = A_arbace_test_A_const_13; var tmp67 lang.IFn = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()); var tmp68 any; A_arbace_test_A_Init(); tmp68 = A_arbace_test_A_const_165; var tmp69 any = tmp67.Invoke_O__O(tmp68); var tmp70 *lang.Var; A_arbace_test_A_Init(); tmp70 = A_arbace_test_A_const_13; var tmp71 lang.IFn = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()); var tmp72 *lang.Var; A_arbace_test_A_Init(); tmp72 = A_arbace_test_A_const_11; var tmp73 lang.IFn = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()); var tmp74 *lang.Var; A_arbace_test_A_Init(); tmp74 = A_arbace_test_A_const_12; var tmp75 lang.IFn = lang.IFn_Cast(jrt.NN(tmp74).GetRawRoot__O()); var tmp76 *lang.Var; A_arbace_test_A_Init(); tmp76 = A_arbace_test_A_const_13; var tmp77 lang.IFn = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()); var tmp78 any; A_arbace_test_A_Init(); tmp78 = A_arbace_test_A_const_166; var tmp79 any = tmp77.Invoke_O__O(tmp78); var tmp80 *lang.Var; A_arbace_test_A_Init(); tmp80 = A_arbace_test_A_const_13; return tmp3.Invoke_O__O(tmp5.Invoke_O_O_O__O(tmp9, tmp39, tmp41.Invoke_O__O(tmp43.Invoke_O__O(tmp45.Invoke_O_O_O__O(tmp49, tmp59, tmp61.Invoke_O__O(tmp63.Invoke_O__O(tmp65.Invoke_O_O__O(tmp69, tmp71.Invoke_O__O(tmp73.Invoke_O__O(tmp75.Invoke_O_O__O(tmp79, lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke_O__O(name__2)))))))))))) } else { return nil
	}
}

func A_arbace_test_set_test_A_New() *A_arbace_test_set_test_A { A_arbace_test_set_test_A_Init(); t := &A_arbace_test_set_test_A{}; t.Ctor(); return t }
//line :631:1
func (t *A_arbace_test_set_test_A) Ctor() {}
//line :631:1
func (t *A_arbace_test_set_test_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, body__3 any) any {







	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_149; if jrt.A2g_Truth(jrt.NN(tmp1).Get__O()) { var tmp2 *lang.Var; A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_11; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_12; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_test_A_Init(); tmp6 = A_arbace_test_A_const_13; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_test_A_Init(); tmp8 = A_arbace_test_A_const_167; var tmp9 any = tmp7.Invoke_O__O(tmp8); var tmp10 *lang.Var; A_arbace_test_A_Init(); tmp10 = A_arbace_test_A_const_13; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_test_A_Init(); tmp12 = A_arbace_test_A_const_11; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_test_A_Init(); tmp14 = A_arbace_test_A_const_12; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_test_A_Init(); tmp16 = A_arbace_test_A_const_13; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any; A_arbace_test_A_Init(); tmp18 = A_arbace_test_A_const_168; var tmp19 any = tmp17.Invoke_O__O(tmp18); var tmp20 *lang.Var; A_arbace_test_A_Init(); tmp20 = A_arbace_test_A_const_13; var tmp21 any = tmp11.Invoke_O__O(tmp13.Invoke_O__O(tmp15.Invoke_O_O__O(tmp19, lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(name__2)))); var tmp22 *lang.Var; A_arbace_test_A_Init(); tmp22 = A_arbace_test_A_const_13; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any; A_arbace_test_A_Init(); tmp24 = A_arbace_test_A_const_169; var tmp25 any = tmp23.Invoke_O__O(tmp24); var tmp26 *lang.Var; A_arbace_test_A_Init(); tmp26 = A_arbace_test_A_const_13; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Keyword; A_arbace_test_A_Init(); tmp28 = A_arbace_test_A_const_64; var tmp29 any = tmp27.Invoke_O__O(tmp28.Ref()); var tmp30 *lang.Var; A_arbace_test_A_Init(); tmp30 = A_arbace_test_A_const_13; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_test_A_Init(); tmp32 = A_arbace_test_A_const_11; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_test_A_Init(); tmp34 = A_arbace_test_A_const_12; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 *lang.Var; A_arbace_test_A_Init(); tmp36 = A_arbace_test_A_const_13; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 any; A_arbace_test_A_Init(); tmp38 = A_arbace_test_A_const_170; var tmp39 any = tmp37.Invoke_O__O(tmp38); var tmp40 *lang.Var; A_arbace_test_A_Init(); tmp40 = A_arbace_test_A_const_13; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 *lang.Var; A_arbace_test_A_Init(); tmp42 = A_arbace_test_A_const_15; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 *lang.Var; A_arbace_test_A_Init(); tmp44 = A_arbace_test_A_const_16; var tmp45 any = jrt.NN(tmp44).GetRawRoot__O(); var tmp46 *lang.Var; A_arbace_test_A_Init(); tmp46 = A_arbace_test_A_const_11; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *lang.Var; A_arbace_test_A_Init(); tmp48 = A_arbace_test_A_const_12; return tmp3.Invoke_O__O(tmp5.Invoke_O_O_O_O_O__O(tmp9, tmp21, tmp25, tmp29, tmp31.Invoke_O__O(tmp33.Invoke_O__O(tmp35.Invoke_O_O_O__O(tmp39, tmp41.Invoke_O__O(tmp43.Invoke_O_O__O(tmp45, tmp47.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()).Invoke__O()))), body__3))))) } else { return nil
	}
}


func A_arbace_test_add_ns_meta_A_New() *A_arbace_test_add_ns_meta_A { A_arbace_test_add_ns_meta_A_Init(); t := &A_arbace_test_add_ns_meta_A{}; t.Ctor(); return t }
//line :644:1
func (t *A_arbace_test_add_ns_meta_A) Ctor() {}
//line :644:1
func (t *A_arbace_test_add_ns_meta_A) Invoke_O_O_O__O(self, key__0, coll__1 any) any {




	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_171; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_172; var tmp4 any = jrt.NN(tmp3).Get__O(); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_156; return tmp2.Invoke_O_O_O_O__O(tmp4, jrt.NN(tmp5).GetRawRoot__O(), key__0, coll__1)
}





func A_arbace_test_eval196000154_fn__196000155_A_New() *A_arbace_test_eval196000154_fn__196000155_A { A_arbace_test_eval196000154_fn__196000155_A_Init(); t := &A_arbace_test_eval196000154_fn__196000155_A{}; t.Ctor(); return t }
//line :656:1
func (t *A_arbace_test_eval196000154_fn__196000155_A) Ctor() {}
//line :656:1
func (t *A_arbace_test_eval196000154_fn__196000155_A) DoInvoke_O_O_O__O(self, fixture_type__1, args__2 any) any { return fixture_type__1 }

func A_arbace_test_eval196000158_fn__196000159_A_New() *A_arbace_test_eval196000158_fn__196000159_A { A_arbace_test_eval196000158_fn__196000159_A_Init(); t := &A_arbace_test_eval196000158_fn__196000159_A{}; t.Ctor(); return t }
//line :658:1
func (t *A_arbace_test_eval196000158_fn__196000159_A) Ctor() {}
//line :658:1
func (t *A_arbace_test_eval196000158_fn__196000159_A) DoInvoke_O_O_O__O(self, fixture_type__1, args__2 any) any {
	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_173; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_174; return tmp2.Invoke_O_O__O(tmp3.Ref(), args__2)
}
func A_arbace_test_eval196000162_fn__196000163_A_New() *A_arbace_test_eval196000162_fn__196000163_A { A_arbace_test_eval196000162_fn__196000163_A_Init(); t := &A_arbace_test_eval196000162_fn__196000163_A{}; t.Ctor(); return t }
//line :661:1
func (t *A_arbace_test_eval196000162_fn__196000163_A) Ctor() {}
//line :661:1
func (t *A_arbace_test_eval196000162_fn__196000163_A) DoInvoke_O_O_O__O(self, fixture_type__1, args__2 any) any {
	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_173; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_175; return tmp2.Invoke_O_O__O(tmp3.Ref(), args__2)
}
func A_arbace_test_default_fixture_A_New() *A_arbace_test_default_fixture_A { A_arbace_test_default_fixture_A_Init(); t := &A_arbace_test_default_fixture_A{}; t.Ctor(); return t }
//line :664:1
func (t *A_arbace_test_default_fixture_A) Ctor() {}
//line :664:1
func (t *A_arbace_test_default_fixture_A) Invoke_O_O__O(self, f__0 any) any {



	return lang.IFn_Cast(f__0).Invoke__O()
}
func A_arbace_test_compose_fixtures_A_New() *A_arbace_test_compose_fixtures_A { A_arbace_test_compose_fixtures_A_Init(); t := &A_arbace_test_compose_fixtures_A{}; t.Ctor(); return t }
//line :670:1
func (t *A_arbace_test_compose_fixtures_A) Ctor() {}
//line :670:1
func (t *A_arbace_test_compose_fixtures_A) Invoke_O_O_O__O(self, f1__0, f2__1 any) any {




	var tmp1 any = A_arbace_test_compose_fixtures_fn__196000167_A_New_O_O(f1__0, f2__1); var tmp2 *jrt.Class; A_arbace_test_compose_fixtures_fn__196000167_A_Init(); tmp2 = A_arbace_test_compose_fixtures_fn__196000167_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :675:1
func A_arbace_test_compose_fixtures_fn__196000167_A_New_O_O(p0, p1 any) *A_arbace_test_compose_fixtures_fn__196000167_A { A_arbace_test_compose_fixtures_fn__196000167_A_Init(); t := &A_arbace_test_compose_fixtures_fn__196000167_A{}; t.Ctor_O_O(p0, p1); return t }
//line :675:1
func (t *A_arbace_test_compose_fixtures_fn__196000167_A) Ctor_O_O(c__f1, c__f2 any) { t.F_f1 = c__f1; t.F_f2 = c__f2 }
//line :675:1
func (t *A_arbace_test_compose_fixtures_fn__196000167_A) Invoke_O_O__O(self, g__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_f1); var tmp2 any = A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_New_O_O(g__1, t.F_f2); var tmp3 *jrt.Class; A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_Init(); tmp3 = A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_fn_class; return tmp1.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)) }
//line :675:1
func A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_New_O_O(p0, p1 any) *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A { A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_Init(); t := &A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A{}; t.Ctor_O_O(p0, p1); return t }
//line :675:1
func (t *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A) Ctor_O_O(c__g, c__f2 any) { t.F_g = c__g; t.F_f2 = c__f2 }
//line :675:1
func (t *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_f2).Invoke_O__O(t.F_g) }

func A_arbace_test_join_fixtures_A_New() *A_arbace_test_join_fixtures_A { A_arbace_test_join_fixtures_A_Init(); t := &A_arbace_test_join_fixtures_A{}; t.Ctor(); return t }
//line :677:1
func (t *A_arbace_test_join_fixtures_A) Ctor() {}
//line :677:1
func (t *A_arbace_test_join_fixtures_A) Invoke_O_O__O(self, fixtures__0 any) any {




	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_176; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_177; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_178; return tmp2.Invoke_O_O_O__O(tmp4, jrt.NN(tmp5).GetRawRoot__O(), fixtures__0)
}


func A_arbace_test_test_var_A_New() *A_arbace_test_test_var_A { A_arbace_test_test_var_A_Init(); t := &A_arbace_test_test_var_A{}; t.Ctor(); return t }
//line :686:1
func (t *A_arbace_test_test_var_A) Ctor() {}
//line :686:1
func (t *A_arbace_test_test_var_A) Invoke_O_O__O(self, v__0 any) any { var temp__1927000414__auto____2 any; var tmp1 *lang.Keyword;




	A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_64; var tmp2 *lang.Keyword = tmp1; temp__1927000414__auto____2 = jrt.NN(tmp2).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__0)); if jrt.A2g_Truth(temp__1927000414__auto____2) { var t__3 any = temp__1927000414__auto____2; var tmp3 *lang.Var
		A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_49; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_50; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_27; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_8; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_27; tmp4.Invoke_O__O(tmp6.Invoke_O_O__O(tmp8, tmp10.Invoke_O_O__O(jrt.NN(tmp11).Get__O(), v__0)))
//line :691:1
		var tmp12 any; tmp32 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

			{ var tmp13 *lang.Var; A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_179; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_39; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Keyword; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_180; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Keyword; A_arbace_test_A_Init(); tmp19 = A_arbace_test_A_const_181; tmp14.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, tmp19.Ref(), v__0)))
				var tmp20 *lang.Var; A_arbace_test_A_Init(); tmp20 = A_arbace_test_A_const_53; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Keyword; A_arbace_test_A_Init(); tmp22 = A_arbace_test_A_const_64; tmp21.Invoke_O__O(tmp22.Ref())
				var tmp23 any = A_arbace_test_test_var_fn__196000173_A_New_O(t__3); var tmp24 *jrt.Class; A_arbace_test_test_var_fn__196000173_A_Init(); tmp24 = A_arbace_test_test_var_fn__196000173_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil).Invoke__O()



				var tmp25 *lang.Var; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_179; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_test_A_Init(); tmp27 = A_arbace_test_A_const_39; var tmp28 any = tmp27.Ref(); var tmp29 *lang.Keyword; A_arbace_test_A_Init(); tmp29 = A_arbace_test_A_const_182; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Keyword; A_arbace_test_A_Init(); tmp31 = A_arbace_test_A_const_181; tmp12 = tmp26.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, tmp31.Ref(), v__0))) }
//line :691:1
			return nil }(); var tmp33 *lang.Var
		A_arbace_test_A_Init(); tmp33 = A_arbace_test_A_const_48; lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke__O()
//line :691:1
		if tmp32 != nil { panic(tmp32) }; return tmp12 } else { return nil } }



func A_arbace_test_test_var_fn__196000173_A_New_O(p0 any) *A_arbace_test_test_var_fn__196000173_A { A_arbace_test_test_var_fn__196000173_A_Init(); t := &A_arbace_test_test_var_fn__196000173_A{}; t.Ctor_O(p0); return t }
//line :695:1
func (t *A_arbace_test_test_var_fn__196000173_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :695:1
func (t *A_arbace_test_test_var_fn__196000173_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_t; t.F_t = nil; tmp2 = t_; tmp1 = lang.IFn_Cast(tmp2).Invoke__O() }; return nil }(); if tmp3 != nil { if true { var e__3 jrt.Throwable_I = tmp3; var tmp4 *lang.Var

	A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_179; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_test_A_Init(); tmp6 = A_arbace_test_A_const_39; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Keyword; A_arbace_test_A_Init(); tmp8 = A_arbace_test_A_const_40; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Keyword; A_arbace_test_A_Init(); tmp10 = A_arbace_test_A_const_56; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Keyword; A_arbace_test_A_Init(); tmp12 = A_arbace_test_A_const_60; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Keyword; A_arbace_test_A_Init(); tmp14 = A_arbace_test_A_const_44; tmp1 = tmp5.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, tmp11, Lit_233, tmp13, nil, tmp14.Ref(), e__3))) } }; return tmp1 }



func A_arbace_test_test_vars_A_New() *A_arbace_test_test_vars_A { A_arbace_test_test_vars_A_Init(); t := &A_arbace_test_test_vars_A{}; t.Ctor(); return t }
//line :701:1
func (t *A_arbace_test_test_vars_A) Ctor() {}
//line :701:1
func (t *A_arbace_test_test_vars_A) Invoke_O_O__O(self, vars__0 any) any { { var seq_196000176__2 any; var tmp1 *lang.Var




	A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_185; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_186; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_66; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_187; seq_196000176__2 = tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6.Invoke_O_O__O(tmp8, jrt.NN(tmp9).GetRawRoot__O()), vars__0))
//line :701:1
	var chunk_196000177__3 any; var count_196000178__4 int64 = 0; var i_196000179__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z(i_196000179__5, count_196000178__4) { var vec__196000180__6 any = lang.Indexed_Cast(chunk_196000177__3).Nth_I__O(lang.RT_IntCast_J__I(i_196000179__5)); var ns__7 any = lang.RT_Nth_O_I_O__O(vec__196000180__6, lang.RT_IntCast_J__I(0), nil); var vars__8 any = lang.RT_Nth_O_I_O__O(vec__196000180__6, lang.RT_IntCast_J__I(1), nil); var once_fixture_fn__9 any; var tmp10 *lang.Var
			A_arbace_test_A_Init(); tmp10 = A_arbace_test_A_const_188; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_test_A_Init(); tmp12 = A_arbace_test_A_const_175; var tmp13 *lang.Keyword = tmp12; once_fixture_fn__9 = tmp11.Invoke_O__O(jrt.NN(tmp13).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(ns__7)))
//line :706:1
			var each_fixture_fn__10 any; var tmp14 *lang.Var

			A_arbace_test_A_Init(); tmp14 = A_arbace_test_A_const_188; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Keyword; A_arbace_test_A_Init(); tmp16 = A_arbace_test_A_const_174; var tmp17 *lang.Keyword = tmp16; each_fixture_fn__10 = tmp15.Invoke_O__O(jrt.NN(tmp17).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(ns__7)))
			var tmp18 lang.IFn = lang.IFn_Cast(once_fixture_fn__9); var tmp19 any = A_arbace_test_test_vars_fn__196000183_A_New_O_O(vars__8, each_fixture_fn__10); var tmp20 *jrt.Class; A_arbace_test_test_vars_fn__196000183_A_Init(); tmp20 = A_arbace_test_test_vars_fn__196000183_A_fn_class; tmp18.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil))
//line :706:1
			seq_196000176__2, chunk_196000177__3, count_196000178__4, i_196000179__5 = seq_196000176__2, chunk_196000177__3, count_196000178__4, lang.Numbers_Unchecked_inc_J__J(i_196000179__5); continue L1 } else { var temp__1927000414__auto____6 any; var tmp21 *lang.Var; A_arbace_test_A_Init(); tmp21 = A_arbace_test_A_const_11; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(seq_196000176__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_196000176__7 any = temp__1927000414__auto____6; var tmp22 *lang.Var; A_arbace_test_A_Init(); tmp22 = A_arbace_test_A_const_183; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_196000176__7)) { var c__1927000678__auto____8 any; var tmp23 *lang.Var; A_arbace_test_A_Init(); tmp23 = A_arbace_test_A_const_184; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(seq_196000176__7); var tmp24 *lang.Var; A_arbace_test_A_Init(); tmp24 = A_arbace_test_A_const_190; seq_196000176__2, chunk_196000177__3, count_196000178__4, i_196000179__5 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seq_196000176__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__196000193__8 any; var tmp25 *lang.Var; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_21; vec__196000193__8 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(seq_196000176__7); var ns__9 any = lang.RT_Nth_O_I_O__O(vec__196000193__8, lang.RT_IntCast_J__I(0), nil); var vars__10 any = lang.RT_Nth_O_I_O__O(vec__196000193__8, lang.RT_IntCast_J__I(1), nil); var once_fixture_fn__11 any; var tmp26 *lang.Var
				A_arbace_test_A_Init(); tmp26 = A_arbace_test_A_const_188; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Keyword; A_arbace_test_A_Init(); tmp28 = A_arbace_test_A_const_175; var tmp29 *lang.Keyword = tmp28; once_fixture_fn__11 = tmp27.Invoke_O__O(jrt.NN(tmp29).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(ns__9)))
//line :706:1
				var each_fixture_fn__12 any; var tmp30 *lang.Var

				A_arbace_test_A_Init(); tmp30 = A_arbace_test_A_const_188; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Keyword; A_arbace_test_A_Init(); tmp32 = A_arbace_test_A_const_174; var tmp33 *lang.Keyword = tmp32; each_fixture_fn__12 = tmp31.Invoke_O__O(jrt.NN(tmp33).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(ns__9)))
				var tmp34 lang.IFn = lang.IFn_Cast(once_fixture_fn__11); var tmp35 any = A_arbace_test_test_vars_fn__196000196_A_New_O_O(vars__10, each_fixture_fn__12); var tmp36 *jrt.Class; A_arbace_test_test_vars_fn__196000196_A_Init(); tmp36 = A_arbace_test_test_vars_fn__196000196_A_fn_class; tmp34.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil))
//line :706:1
				var tmp37 *lang.Var; A_arbace_test_A_Init(); tmp37 = A_arbace_test_A_const_19; seq_196000176__2, chunk_196000177__3, count_196000178__4, i_196000179__5 = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(seq_196000176__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :701:1*/panic("a2g: unreachable") }








func A_arbace_test_test_vars_fn__196000183_A_New_O_O(p0, p1 any) *A_arbace_test_test_vars_fn__196000183_A { A_arbace_test_test_vars_fn__196000183_A_Init(); t := &A_arbace_test_test_vars_fn__196000183_A{}; t.Ctor_O_O(p0, p1); return t }
//line :710:1
func (t *A_arbace_test_test_vars_fn__196000183_A) Ctor_O_O(c__vars, c__each_fixture_fn any) { t.F_vars = c__vars; t.F_each_fixture_fn = c__each_fixture_fn }
//line :710:1
func (t *A_arbace_test_test_vars_fn__196000183_A) Invoke_O__O(self any) any { { var seq_196000184__1 any; var tmp1 *lang.Var
										A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_11; seq_196000184__1 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_vars)
//line :710:1
	var chunk_196000185__2 any; var count_196000186__3 int64 = 0; var i_196000187__4 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_196000187__4, count_196000186__3) { var v__5 any = lang.Indexed_Cast(chunk_196000185__2).Nth_I__O(lang.RT_IntCast_J__I(i_196000187__4)); var tmp2 *lang.Keyword
			A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_64; var tmp3 *lang.Keyword = tmp2; if jrt.A2g_Truth(jrt.NN(tmp3).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__5))) {
				var tmp4 lang.IFn = lang.IFn_Cast(t.F_each_fixture_fn); var tmp5 any = A_arbace_test_test_vars_fn__196000183_fn__196000188_A_New_O(v__5); var tmp6 *jrt.Class; A_arbace_test_test_vars_fn__196000183_fn__196000188_A_Init(); tmp6 = A_arbace_test_test_vars_fn__196000183_fn__196000188_A_fn_class; tmp4.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :711:1
			seq_196000184__1, chunk_196000185__2, count_196000186__3, i_196000187__4 = seq_196000184__1, chunk_196000185__2, count_196000186__3, lang.Numbers_Unchecked_inc_J__J(i_196000187__4); continue L1 } else { var temp__1927000414__auto____5 any; var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_11; temp__1927000414__auto____5 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq_196000184__1); if jrt.A2g_Truth(temp__1927000414__auto____5) { var seq_196000184__6 any = temp__1927000414__auto____5; var tmp8 *lang.Var; A_arbace_test_A_Init(); tmp8 = A_arbace_test_A_const_183; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq_196000184__6)) { var c__1927000678__auto____7 any; var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_184; c__1927000678__auto____7 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq_196000184__6); var tmp10 *lang.Var; A_arbace_test_A_Init(); tmp10 = A_arbace_test_A_const_190; seq_196000184__1, chunk_196000185__2, count_196000186__3, i_196000187__4 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq_196000184__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var v__7 any; var tmp11 *lang.Var; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_21; v__7 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq_196000184__6)
				var tmp12 *lang.Keyword; A_arbace_test_A_Init(); tmp12 = A_arbace_test_A_const_64; var tmp13 *lang.Keyword = tmp12; if jrt.A2g_Truth(jrt.NN(tmp13).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__7))) {
					var tmp14 lang.IFn = lang.IFn_Cast(t.F_each_fixture_fn); var tmp15 any = A_arbace_test_test_vars_fn__196000183_fn__196000190_A_New_O(v__7); var tmp16 *jrt.Class; A_arbace_test_test_vars_fn__196000183_fn__196000190_A_Init(); tmp16 = A_arbace_test_test_vars_fn__196000183_fn__196000190_A_fn_class; tmp14.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil)) }
//line :711:1
				var tmp17 *lang.Var; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_19; seq_196000184__1, chunk_196000185__2, count_196000186__3, i_196000187__4 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(seq_196000184__6), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :710:1*/panic("a2g: unreachable") }
//line :710:1
func A_arbace_test_test_vars_fn__196000196_A_New_O_O(p0, p1 any) *A_arbace_test_test_vars_fn__196000196_A { A_arbace_test_test_vars_fn__196000196_A_Init(); t := &A_arbace_test_test_vars_fn__196000196_A{}; t.Ctor_O_O(p0, p1); return t }
//line :710:1
func (t *A_arbace_test_test_vars_fn__196000196_A) Ctor_O_O(c__vars, c__each_fixture_fn any) { t.F_vars = c__vars; t.F_each_fixture_fn = c__each_fixture_fn }
//line :710:1
func (t *A_arbace_test_test_vars_fn__196000196_A) Invoke_O__O(self any) any { { var seq_196000197__1 any; var tmp1 *lang.Var
										A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_11; seq_196000197__1 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_vars)
//line :710:1
	var chunk_196000198__2 any; var count_196000199__3 int64 = 0; var i_196000200__4 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_196000200__4, count_196000199__3) { var v__5 any = lang.Indexed_Cast(chunk_196000198__2).Nth_I__O(lang.RT_IntCast_J__I(i_196000200__4)); var tmp2 *lang.Keyword
			A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_64; var tmp3 *lang.Keyword = tmp2; if jrt.A2g_Truth(jrt.NN(tmp3).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__5))) {
				var tmp4 lang.IFn = lang.IFn_Cast(t.F_each_fixture_fn); var tmp5 any = A_arbace_test_test_vars_fn__196000196_fn__196000201_A_New_O(v__5); var tmp6 *jrt.Class; A_arbace_test_test_vars_fn__196000196_fn__196000201_A_Init(); tmp6 = A_arbace_test_test_vars_fn__196000196_fn__196000201_A_fn_class; tmp4.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :711:1
			seq_196000197__1, chunk_196000198__2, count_196000199__3, i_196000200__4 = seq_196000197__1, chunk_196000198__2, count_196000199__3, lang.Numbers_Unchecked_inc_J__J(i_196000200__4); continue L1 } else { var temp__1927000414__auto____5 any; var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_11; temp__1927000414__auto____5 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq_196000197__1); if jrt.A2g_Truth(temp__1927000414__auto____5) { var seq_196000197__6 any = temp__1927000414__auto____5; var tmp8 *lang.Var; A_arbace_test_A_Init(); tmp8 = A_arbace_test_A_const_183; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq_196000197__6)) { var c__1927000678__auto____7 any; var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_184; c__1927000678__auto____7 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq_196000197__6); var tmp10 *lang.Var; A_arbace_test_A_Init(); tmp10 = A_arbace_test_A_const_190; seq_196000197__1, chunk_196000198__2, count_196000199__3, i_196000200__4 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq_196000197__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var v__7 any; var tmp11 *lang.Var; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_21; v__7 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq_196000197__6)
				var tmp12 *lang.Keyword; A_arbace_test_A_Init(); tmp12 = A_arbace_test_A_const_64; var tmp13 *lang.Keyword = tmp12; if jrt.A2g_Truth(jrt.NN(tmp13).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__7))) {
					var tmp14 lang.IFn = lang.IFn_Cast(t.F_each_fixture_fn); var tmp15 any = A_arbace_test_test_vars_fn__196000196_fn__196000203_A_New_O(v__7); var tmp16 *jrt.Class; A_arbace_test_test_vars_fn__196000196_fn__196000203_A_Init(); tmp16 = A_arbace_test_test_vars_fn__196000196_fn__196000203_A_fn_class; tmp14.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil)) }
//line :711:1
				var tmp17 *lang.Var; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_19; seq_196000197__1, chunk_196000198__2, count_196000199__3, i_196000200__4 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(seq_196000197__6), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :710:1*/panic("a2g: unreachable") }


func A_arbace_test_test_vars_fn__196000183_fn__196000188_A_New_O(p0 any) *A_arbace_test_test_vars_fn__196000183_fn__196000188_A { A_arbace_test_test_vars_fn__196000183_fn__196000188_A_Init(); t := &A_arbace_test_test_vars_fn__196000183_fn__196000188_A{}; t.Ctor_O(p0); return t }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000183_fn__196000188_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000183_fn__196000188_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_189; return lang.IFn_Cast(jrt.NN(tmp1).Get__O()).Invoke_O__O(t.F_v) }
//line :713:1
func A_arbace_test_test_vars_fn__196000183_fn__196000190_A_New_O(p0 any) *A_arbace_test_test_vars_fn__196000183_fn__196000190_A { A_arbace_test_test_vars_fn__196000183_fn__196000190_A_Init(); t := &A_arbace_test_test_vars_fn__196000183_fn__196000190_A{}; t.Ctor_O(p0); return t }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000183_fn__196000190_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000183_fn__196000190_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_189; return lang.IFn_Cast(jrt.NN(tmp1).Get__O()).Invoke_O__O(t.F_v) }
//line :713:1
func A_arbace_test_test_vars_fn__196000196_fn__196000201_A_New_O(p0 any) *A_arbace_test_test_vars_fn__196000196_fn__196000201_A { A_arbace_test_test_vars_fn__196000196_fn__196000201_A_Init(); t := &A_arbace_test_test_vars_fn__196000196_fn__196000201_A{}; t.Ctor_O(p0); return t }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000196_fn__196000201_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000196_fn__196000201_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_189; return lang.IFn_Cast(jrt.NN(tmp1).Get__O()).Invoke_O__O(t.F_v) }
//line :713:1
func A_arbace_test_test_vars_fn__196000196_fn__196000203_A_New_O(p0 any) *A_arbace_test_test_vars_fn__196000196_fn__196000203_A { A_arbace_test_test_vars_fn__196000196_fn__196000203_A_Init(); t := &A_arbace_test_test_vars_fn__196000196_fn__196000203_A{}; t.Ctor_O(p0); return t }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000196_fn__196000203_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :713:1
func (t *A_arbace_test_test_vars_fn__196000196_fn__196000203_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_189; return lang.IFn_Cast(jrt.NN(tmp1).Get__O()).Invoke_O__O(t.F_v) }

func A_arbace_test_test_all_vars_A_New() *A_arbace_test_test_all_vars_A { A_arbace_test_test_all_vars_A_Init(); t := &A_arbace_test_test_all_vars_A{}; t.Ctor(); return t }
//line :715:1
func (t *A_arbace_test_test_all_vars_A) Ctor() {}
//line :715:1
func (t *A_arbace_test_test_all_vars_A) Invoke_O_O__O(self, ns__0 any) any {



	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_191; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_192; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_193; return tmp2.Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(ns__0)))
}
func A_arbace_test_test_ns_A_New() *A_arbace_test_test_ns_A { A_arbace_test_test_ns_A_Init(); t := &A_arbace_test_test_ns_A{}; t.Ctor(); return t }
//line :721:1
func (t *A_arbace_test_test_ns_A) Ctor() {}
//line :721:1
func (t *A_arbace_test_test_ns_A) Invoke_O_O__O(self, ns__0 any) any {









	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_49; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_50; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_31; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_194; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_195; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, tmp8.Invoke_O__O(jrt.NN(tmp9).Get__O())))
//line :721:1
	var tmp10 any; tmp38 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var ns_obj__4 any; var tmp11 *lang.Var










		A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_196; ns_obj__4 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(ns__0)
		var tmp12 *lang.Var; A_arbace_test_A_Init(); tmp12 = A_arbace_test_A_const_179; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_test_A_Init(); tmp14 = A_arbace_test_A_const_39; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Keyword; A_arbace_test_A_Init(); tmp16 = A_arbace_test_A_const_199; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Keyword; A_arbace_test_A_Init(); tmp18 = A_arbace_test_A_const_66; tmp13.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp17, tmp18.Ref(), ns_obj__4)))
//line :721:1
		var temp__1927000408__auto____5 any; var tmp19 *lang.Var













		A_arbace_test_A_Init(); tmp19 = A_arbace_test_A_const_197; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_test_A_Init(); tmp21 = A_arbace_test_A_const_200; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_test_A_Init(); tmp23 = A_arbace_test_A_const_28; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_65; temp__1927000408__auto____5 = tmp20.Invoke_O__O(tmp22.Invoke_O_O__O(tmp24.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(ns_obj__4)), Lit_230)); if jrt.A2g_Truth(temp__1927000408__auto____5) { var v__6 any = temp__1927000408__auto____5; var tmp26 *lang.Var
			A_arbace_test_A_Init(); tmp26 = A_arbace_test_A_const_67; lang.IFn_Cast(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(v__6)).Invoke__O() } else {

				var tmp27 *lang.Var; A_arbace_test_A_Init(); tmp27 = A_arbace_test_A_const_198; lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(ns_obj__4) }
		var tmp28 *lang.Var; A_arbace_test_A_Init(); tmp28 = A_arbace_test_A_const_179; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Keyword; A_arbace_test_A_Init(); tmp30 = A_arbace_test_A_const_39; var tmp31 any = tmp30.Ref(); var tmp32 *lang.Keyword; A_arbace_test_A_Init(); tmp32 = A_arbace_test_A_const_201; var tmp33 any = tmp32.Ref(); var tmp34 *lang.Keyword; A_arbace_test_A_Init(); tmp34 = A_arbace_test_A_const_66; tmp29.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, tmp34.Ref(), ns_obj__4)))
//line :731:1
		var tmp35 *lang.Var; A_arbace_test_A_Init(); tmp35 = A_arbace_test_A_const_7; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_test_A_Init(); tmp37 = A_arbace_test_A_const_31; tmp10 = tmp36.Invoke_O__O(jrt.NN(tmp37).Get__O()) }; return nil }()
//line :721:1
	var tmp39 *lang.Var









	A_arbace_test_A_Init(); tmp39 = A_arbace_test_A_const_48; lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke__O()
//line :721:1
	if tmp38 != nil { panic(tmp38) }; return tmp10
}





















func A_arbace_test_run_tests_A_New() *A_arbace_test_run_tests_A { A_arbace_test_run_tests_A_Init(); t := &A_arbace_test_run_tests_A{}; t.Ctor(); return t }
//line :744:1
func (t *A_arbace_test_run_tests_A) Ctor() {}
//line :744:1
func (t *A_arbace_test_run_tests_A) DoInvoke_O_O__O(self, namespaces__0 any) any { var summary__2 any; var tmp1 *lang.Var;






	A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_156; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_15; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_203; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_204; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_25; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_205; var tmp12 any = tmp4.Invoke_O_O_O__O(tmp6, tmp8, tmp10.Invoke_O_O__O(jrt.NN(tmp11).GetRawRoot__O(), namespaces__0)); var tmp13 *lang.Keyword; A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_39; var tmp14 any = tmp13.Ref(); var tmp15 *lang.Keyword; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_202; summary__2 = tmp2.Invoke_O_O_O__O(tmp12, tmp14, tmp15.Ref()); var tmp16 /*line :753:1*/*lang.Var; A_arbace_test_A_Init(); tmp16 = A_arbace_test_A_const_179; lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(summary__2); return summary__2 }
//line :744:1
func (t *A_arbace_test_run_tests_A) Invoke_O__O(self any) any {




	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_206; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_172; return tmp2.Invoke_O__O(jrt.NN(tmp3).Get__O())
}





func A_arbace_test_run_all_tests_A_New() *A_arbace_test_run_all_tests_A { A_arbace_test_run_all_tests_A_Init(); t := &A_arbace_test_run_all_tests_A{}; t.Ctor(); return t }
//line :756:1
func (t *A_arbace_test_run_all_tests_A) Ctor() {}
//line :756:1
func (t *A_arbace_test_run_all_tests_A) Invoke_O_O__O(self, re__0 any) any {






	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_15; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_206; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_207; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_test_run_all_tests_fn__196000211_A_New_O(re__0); var tmp8 *jrt.Class; A_arbace_test_run_all_tests_fn__196000211_A_Init(); tmp8 = A_arbace_test_run_all_tests_fn__196000211_A_fn_class; var tmp9 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 *lang.Var; A_arbace_test_A_Init(); tmp10 = A_arbace_test_A_const_210; return tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(tmp9, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke__O())) }
//line :756:1
func (t *A_arbace_test_run_all_tests_A) Invoke_O__O(self any) any {





	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_15; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_206; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_210; return tmp2.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke__O()) }
func A_arbace_test_run_all_tests_fn__196000211_A_New_O(p0 any) *A_arbace_test_run_all_tests_fn__196000211_A { A_arbace_test_run_all_tests_fn__196000211_A_Init(); t := &A_arbace_test_run_all_tests_fn__196000211_A{}; t.Ctor_O(p0); return t }
//line :763:1
func (t *A_arbace_test_run_all_tests_fn__196000211_A) Ctor_O(c__re any) { t.F_re = c__re }
//line :763:1
func (t *A_arbace_test_run_all_tests_fn__196000211_A) Invoke_O_O__O(self, p1__196000210_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_208; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_re; var tmp4 *lang.Var; A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_209; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_test_A_Init(); tmp6 = A_arbace_test_A_const_65; return tmp2.Invoke_O_O__O(tmp3, tmp5.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(p1__196000210_SHARP___1))) }

func A_arbace_test_successful_QMARK__A_New() *A_arbace_test_successful_QMARK__A { A_arbace_test_successful_QMARK__A_Init(); t := &A_arbace_test_successful_QMARK__A{}; t.Ctor(); return t }
//line :765:1
func (t *A_arbace_test_successful_QMARK__A) Ctor() {}
//line :765:1
func (t *A_arbace_test_successful_QMARK__A) Invoke_O_O__O(self, summary__0 any) any { var and__1927000168__auto____2 bool; var tmp1 *lang.Keyword;




	A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_42; var tmp2 lang.IFn = Up_Keyword_IFn(tmp1); var tmp3 any; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_35; and__1927000168__auto____2 = lang.Numbers_IsZero_O__Z(tmp2.Invoke_O_O__O(summary__0, tmp3)); if and__1927000168__auto____2 {
		var tmp4 *lang.Keyword; A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_40; var tmp5 lang.IFn = Up_Keyword_IFn(tmp4); var tmp6 any; A_arbace_test_A_Init(); tmp6 = A_arbace_test_A_const_35; return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_O__Z(tmp5.Invoke_O_O__O(summary__0, tmp6))).Ref() } else {
//line :770:1
			return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }


func A_arbace_test_run_test_var_A_New() *A_arbace_test_run_test_var_A { A_arbace_test_run_test_var_A_Init(); t := &A_arbace_test_run_test_var_A{}; t.Ctor(); return t }
//line :773:1
func (t *A_arbace_test_run_test_var_A) Ctor() {}
//line :773:1
func (t *A_arbace_test_run_test_var_A) Invoke_O_O__O(self, v__0 any) any {



	var tmp1 *lang.Var; A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_49; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_A_Init(); tmp3 = A_arbace_test_A_const_50; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_A_Init(); tmp5 = A_arbace_test_A_const_31; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_A_Init(); tmp7 = A_arbace_test_A_const_194; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_test_A_Init(); tmp9 = A_arbace_test_A_const_195; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, tmp8.Invoke_O__O(jrt.NN(tmp9).Get__O())))
//line :773:1
	var tmp10 any; tmp38 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var ns_obj__4 any; var tmp11 *lang.Keyword




		A_arbace_test_A_Init(); tmp11 = A_arbace_test_A_const_66; var tmp12 *lang.Keyword = tmp11; ns_obj__4 = jrt.NN(tmp12).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__0))
//line :773:1
		var summary__5 any; var tmp13 *lang.Var






		A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_179; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_39; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Keyword; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_199; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Keyword; A_arbace_test_A_Init(); tmp19 = A_arbace_test_A_const_66; tmp14.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, tmp19.Ref(), ns_obj__4)))

		var tmp20 *lang.Var; A_arbace_test_A_Init(); tmp20 = A_arbace_test_A_const_191; lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O__IPersistentVector(v__0))
		var tmp21 *lang.Var; A_arbace_test_A_Init(); tmp21 = A_arbace_test_A_const_179; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Keyword; A_arbace_test_A_Init(); tmp23 = A_arbace_test_A_const_39; var tmp24 any = tmp23.Ref(); var tmp25 *lang.Keyword; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_201; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Keyword; A_arbace_test_A_Init(); tmp27 = A_arbace_test_A_const_66; tmp22.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp24, tmp26, tmp27.Ref(), ns_obj__4)))

		var tmp28 *lang.Var; A_arbace_test_A_Init(); tmp28 = A_arbace_test_A_const_156; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_test_A_Init(); tmp30 = A_arbace_test_A_const_7; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_test_A_Init(); tmp32 = A_arbace_test_A_const_31; var tmp33 any = tmp31.Invoke_O__O(jrt.NN(tmp32).Get__O()); var tmp34 *lang.Keyword; A_arbace_test_A_Init(); tmp34 = A_arbace_test_A_const_39; var tmp35 any = tmp34.Ref(); var tmp36 *lang.Keyword; A_arbace_test_A_Init(); tmp36 = A_arbace_test_A_const_202; summary__5 = tmp29.Invoke_O_O_O__O(tmp33, tmp35, tmp36.Ref())
		var tmp37 *lang.Var; A_arbace_test_A_Init(); tmp37 = A_arbace_test_A_const_179; lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(summary__5)
//line :773:1
		tmp10 = summary__5 }; return nil }(); var tmp39 *lang.Var



	A_arbace_test_A_Init(); tmp39 = A_arbace_test_A_const_48; lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke__O()
//line :773:1
	if tmp38 != nil { panic(tmp38) }; return tmp10
}














func A_arbace_test_run_test_A_New() *A_arbace_test_run_test_A { A_arbace_test_run_test_A_Init(); t := &A_arbace_test_run_test_A{}; t.Ctor(); return t }
//line :789:1
func (t *A_arbace_test_run_test_A) Ctor() {}
//line :789:1
func (t *A_arbace_test_run_test_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, test_symbol__2 any) any { var test_var__4 any; var tmp1 *lang.Var;





	A_arbace_test_A_Init(); tmp1 = A_arbace_test_A_const_69; test_var__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(test_symbol__2); if
	lang.Util_Identical_O_O__Z(test_var__4, nil) {

		var tmp2 *lang.Var; A_arbace_test_A_Init(); tmp2 = A_arbace_test_A_const_49; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_test_A_Init(); tmp4 = A_arbace_test_A_const_50; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_test_A_Init(); tmp6 = A_arbace_test_A_const_51; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Var; A_arbace_test_A_Init(); tmp8 = A_arbace_test_A_const_211; tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(tmp7, jrt.NN(tmp8).Get__O()))
//line :796:1
		var tmp9 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


			{ var tmp10 *lang.Var; A_arbace_test_A_Init(); tmp10 = A_arbace_test_A_const_55; tmp9 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O_O__O(Lit_220, test_symbol__2, Lit_221) }
//line :796:1
			return nil }(); var tmp12 *lang.Var

		A_arbace_test_A_Init(); tmp12 = A_arbace_test_A_const_48; lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke__O()
//line :796:1
		if tmp11 != nil { panic(tmp11) }; return tmp9 } else { var tmp13 *lang.Var; A_arbace_test_A_Init(); tmp13 = A_arbace_test_A_const_72; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_test_A_Init(); tmp15 = A_arbace_test_A_const_64; var tmp16 *lang.Keyword = tmp15; if jrt.A2g_Truth(tmp14.Invoke_O__O(jrt.NN(tmp16).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(test_var__4)))) {





			var tmp17 *lang.Var; A_arbace_test_A_Init(); tmp17 = A_arbace_test_A_const_49; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_test_A_Init(); tmp19 = A_arbace_test_A_const_50; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_test_A_Init(); tmp21 = A_arbace_test_A_const_51; var tmp22 any = tmp21.Ref(); var tmp23 *lang.Var; A_arbace_test_A_Init(); tmp23 = A_arbace_test_A_const_211; tmp18.Invoke_O__O(tmp20.Invoke_O_O__O(tmp22, jrt.NN(tmp23).Get__O()))
//line :796:1
			var tmp24 any; tmp26 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






				{ var tmp25 *lang.Var; A_arbace_test_A_Init(); tmp25 = A_arbace_test_A_const_55; tmp24 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O_O__O(test_symbol__2, Lit_222) }
//line :796:1
				return nil }(); var tmp27 *lang.Var





			A_arbace_test_A_Init(); tmp27 = A_arbace_test_A_const_48; lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke__O()
//line :796:1
			if tmp26 != nil { panic(tmp26) }; return tmp24 } else { var tmp28 *lang.Keyword; A_arbace_test_A_Init(); tmp28 = A_arbace_test_A_const_95; if tmp28 != nil { var tmp29 *lang.Var; A_arbace_test_A_Init(); tmp29 = A_arbace_test_A_const_11; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_test_A_Init(); tmp31 = A_arbace_test_A_const_12; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_test_A_Init(); tmp33 = A_arbace_test_A_const_13; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 any; A_arbace_test_A_Init(); tmp35 = A_arbace_test_A_const_212; var tmp36 any = tmp34.Invoke_O__O(tmp35); var tmp37 *lang.Var; A_arbace_test_A_Init(); tmp37 = A_arbace_test_A_const_13; return tmp30.Invoke_O__O(tmp32.Invoke_O_O__O(tmp36, lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(test_var__4))) } else { return nil } } } }















type A_arbace_test_A struct{ jrt.Object }

var A_arbace_test_A_const_0 *lang.Var

var A_arbace_test_A_const_1 *lang.Var

var A_arbace_test_A_const_2 any

var A_arbace_test_A_const_3 any

var A_arbace_test_A_const_4 any

var A_arbace_test_A_const_5 any

var A_arbace_test_A_const_6 *lang.Var

var A_arbace_test_A_const_7 *lang.Var

var A_arbace_test_A_const_8 *lang.Var

var A_arbace_test_A_const_9 any

var A_arbace_test_A_const_10 *lang.Var

var A_arbace_test_A_const_11 *lang.Var

var A_arbace_test_A_const_12 *lang.Var

var A_arbace_test_A_const_13 *lang.Var

var A_arbace_test_A_const_14 any

var A_arbace_test_A_const_15 *lang.Var

var A_arbace_test_A_const_16 *lang.Var

var A_arbace_test_A_const_17 any

var A_arbace_test_A_const_18 any

var A_arbace_test_A_const_19 *lang.Var

var A_arbace_test_A_const_20 *lang.Var

var A_arbace_test_A_const_21 *lang.Var

var A_arbace_test_A_const_22 *lang.Keyword

var A_arbace_test_A_const_23 *lang.Keyword

var A_arbace_test_A_const_24 *lang.Var

var A_arbace_test_A_const_25 *lang.Var

var A_arbace_test_A_const_26 *lang.Keyword

var A_arbace_test_A_const_27 *lang.Var

var A_arbace_test_A_const_28 *lang.Var

var A_arbace_test_A_const_29 *lang.Var

var A_arbace_test_A_const_30 *lang.Var

var A_arbace_test_A_const_31 *lang.Var

var A_arbace_test_A_const_32 *lang.Var

var A_arbace_test_A_const_33 *lang.Var

var A_arbace_test_A_const_34 *lang.Var

var A_arbace_test_A_const_35 any

var A_arbace_test_A_const_36 any

var A_arbace_test_A_const_37 any

var A_arbace_test_A_const_38 *lang.Var

var A_arbace_test_A_const_39 *lang.Keyword

var A_arbace_test_A_const_40 *lang.Keyword

var A_arbace_test_A_const_41 *lang.Var

var A_arbace_test_A_const_42 *lang.Keyword

var A_arbace_test_A_const_43 *lang.Var

var A_arbace_test_A_const_44 *lang.Keyword

var A_arbace_test_A_const_45 *lang.Var

var A_arbace_test_A_const_46 *lang.Var

var A_arbace_test_A_const_47 *lang.Var

var A_arbace_test_A_const_48 *lang.Var

var A_arbace_test_A_const_49 *lang.Var

var A_arbace_test_A_const_50 *lang.Var

var A_arbace_test_A_const_51 *lang.Var

var A_arbace_test_A_const_52 *lang.Var

var A_arbace_test_A_const_53 *lang.Var

var A_arbace_test_A_const_54 *lang.Keyword

var A_arbace_test_A_const_55 *lang.Var

var A_arbace_test_A_const_56 *lang.Keyword

var A_arbace_test_A_const_57 *lang.Var

var A_arbace_test_A_const_58 *lang.Var

var A_arbace_test_A_const_59 *lang.Var

var A_arbace_test_A_const_60 *lang.Keyword

var A_arbace_test_A_const_61 *lang.Var

var A_arbace_test_A_const_62 *lang.Var

var A_arbace_test_A_const_63 *lang.Var

var A_arbace_test_A_const_64 *lang.Keyword

var A_arbace_test_A_const_65 *lang.Var

var A_arbace_test_A_const_66 *lang.Keyword

var A_arbace_test_A_const_67 *lang.Var

var A_arbace_test_A_const_68 *lang.Var

var A_arbace_test_A_const_69 *lang.Var

var A_arbace_test_A_const_70 *lang.Var

var A_arbace_test_A_const_71 *lang.Var

var A_arbace_test_A_const_72 *lang.Var

var A_arbace_test_A_const_73 *lang.Keyword

var A_arbace_test_A_const_74 *lang.Var

var A_arbace_test_A_const_75 any

var A_arbace_test_A_const_76 any

var A_arbace_test_A_const_77 any

var A_arbace_test_A_const_78 any

var A_arbace_test_A_const_79 any

var A_arbace_test_A_const_80 any

var A_arbace_test_A_const_81 any

var A_arbace_test_A_const_82 any

var A_arbace_test_A_const_83 any

var A_arbace_test_A_const_84 any

var A_arbace_test_A_const_85 any

var A_arbace_test_A_const_86 any

var A_arbace_test_A_const_87 any

var A_arbace_test_A_const_88 any

var A_arbace_test_A_const_89 any

var A_arbace_test_A_const_90 any

var A_arbace_test_A_const_91 any

var A_arbace_test_A_const_92 any

var A_arbace_test_A_const_93 *lang.Keyword

var A_arbace_test_A_const_94 *lang.Var

var A_arbace_test_A_const_95 *lang.Keyword

var A_arbace_test_A_const_96 *lang.Keyword

var A_arbace_test_A_const_97 any

var A_arbace_test_A_const_98 *lang.Var

var A_arbace_test_A_const_99 *lang.Var

var A_arbace_test_A_const_100 *lang.Var

var A_arbace_test_A_const_101 *lang.Var

var A_arbace_test_A_const_102 any

var A_arbace_test_A_const_103 any

var A_arbace_test_A_const_104 any

var A_arbace_test_A_const_105 any

var A_arbace_test_A_const_106 any

var A_arbace_test_A_const_107 any

var A_arbace_test_A_const_108 any

var A_arbace_test_A_const_109 any

var A_arbace_test_A_const_110 any

var A_arbace_test_A_const_111 any

var A_arbace_test_A_const_112 any

var A_arbace_test_A_const_113 *lang.Var

var A_arbace_test_A_const_114 *lang.Var

var A_arbace_test_A_const_115 any

var A_arbace_test_A_const_116 any

var A_arbace_test_A_const_117 any

var A_arbace_test_A_const_118 any

var A_arbace_test_A_const_119 any

var A_arbace_test_A_const_120 any

var A_arbace_test_A_const_121 any

var A_arbace_test_A_const_122 any

var A_arbace_test_A_const_123 any

var A_arbace_test_A_const_124 any

var A_arbace_test_A_const_125 any

var A_arbace_test_A_const_126 any

var A_arbace_test_A_const_127 any

var A_arbace_test_A_const_128 any

var A_arbace_test_A_const_129 any

var A_arbace_test_A_const_130 any

var A_arbace_test_A_const_131 any

var A_arbace_test_A_const_132 any

var A_arbace_test_A_const_133 any

var A_arbace_test_A_const_134 *lang.Var

var A_arbace_test_A_const_135 any

var A_arbace_test_A_const_136 any

var A_arbace_test_A_const_137 any

var A_arbace_test_A_const_138 any

var A_arbace_test_A_const_139 any

var A_arbace_test_A_const_140 any

var A_arbace_test_A_const_141 *lang.Var

var A_arbace_test_A_const_142 *lang.Var

var A_arbace_test_A_const_143 any

var A_arbace_test_A_const_144 any

var A_arbace_test_A_const_145 any

var A_arbace_test_A_const_146 any

var A_arbace_test_A_const_147 any

var A_arbace_test_A_const_148 any

var A_arbace_test_A_const_149 *lang.Var

var A_arbace_test_A_const_150 any

var A_arbace_test_A_const_151 any

var A_arbace_test_A_const_152 any

var A_arbace_test_A_const_153 any

var A_arbace_test_A_const_154 any

var A_arbace_test_A_const_155 *lang.Var

var A_arbace_test_A_const_156 *lang.Var

var A_arbace_test_A_const_157 any

var A_arbace_test_A_const_158 any

var A_arbace_test_A_const_159 any

var A_arbace_test_A_const_160 any

var A_arbace_test_A_const_161 any

var A_arbace_test_A_const_162 *lang.Keyword

var A_arbace_test_A_const_163 any

var A_arbace_test_A_const_164 any

var A_arbace_test_A_const_165 any

var A_arbace_test_A_const_166 any

var A_arbace_test_A_const_167 any

var A_arbace_test_A_const_168 any

var A_arbace_test_A_const_169 any

var A_arbace_test_A_const_170 any

var A_arbace_test_A_const_171 *lang.Var

var A_arbace_test_A_const_172 *lang.Var

var A_arbace_test_A_const_173 *lang.Var

var A_arbace_test_A_const_174 *lang.Keyword

var A_arbace_test_A_const_175 *lang.Keyword

var A_arbace_test_A_const_176 *lang.Var

var A_arbace_test_A_const_177 *lang.Var

var A_arbace_test_A_const_178 *lang.Var

var A_arbace_test_A_const_179 *lang.Var

var A_arbace_test_A_const_180 *lang.Keyword

var A_arbace_test_A_const_181 *lang.Keyword

var A_arbace_test_A_const_182 *lang.Keyword

var A_arbace_test_A_const_183 *lang.Var

var A_arbace_test_A_const_184 *lang.Var

var A_arbace_test_A_const_185 *lang.Var

var A_arbace_test_A_const_186 *lang.Var

var A_arbace_test_A_const_187 *lang.Var

var A_arbace_test_A_const_188 *lang.Var

var A_arbace_test_A_const_189 *lang.Var

var A_arbace_test_A_const_190 *lang.Var

var A_arbace_test_A_const_191 *lang.Var

var A_arbace_test_A_const_192 *lang.Var

var A_arbace_test_A_const_193 *lang.Var

var A_arbace_test_A_const_194 *lang.Var

var A_arbace_test_A_const_195 *lang.Var

var A_arbace_test_A_const_196 *lang.Var

var A_arbace_test_A_const_197 *lang.Var

var A_arbace_test_A_const_198 *lang.Var

var A_arbace_test_A_const_199 *lang.Keyword

var A_arbace_test_A_const_200 *lang.Var

var A_arbace_test_A_const_201 *lang.Keyword

var A_arbace_test_A_const_202 *lang.Keyword

var A_arbace_test_A_const_203 *lang.Var

var A_arbace_test_A_const_204 *lang.Var

var A_arbace_test_A_const_205 *lang.Var

var A_arbace_test_A_const_206 *lang.Var

var A_arbace_test_A_const_207 *lang.Var

var A_arbace_test_A_const_208 *lang.Var

var A_arbace_test_A_const_209 *lang.Var

var A_arbace_test_A_const_210 *lang.Var

var A_arbace_test_A_const_211 *lang.Var

var A_arbace_test_A_const_212 any

var A_arbace_test_A_init jrt.ClassInit

func A_arbace_test_A_Init() { if !A_arbace_test_A_init.Done() { A_arbace_test_A_init.Run(A_arbace_test_A_clinit) } }

func A_arbace_test_A_clinit() { A_arbace_test_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_test_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_test_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_test_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_test_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_test_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_test_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_test_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_test_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_test_A_const_9 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17))); A_arbace_test_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_test_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_test_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_test_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_test_A_const_14 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_22).Ref(); A_arbace_test_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_test_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_test_A_const_17 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_25).Ref(); A_arbace_test_A_const_18 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_26).Ref(); A_arbace_test_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_test_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_test_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_test_A_const_22 = lang.RT_Keyword_String_String__Keyword(nil, Lit_30); A_arbace_test_A_const_23 = lang.RT_Keyword_String_String__Keyword(nil, Lit_31); A_arbace_test_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_test_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_test_A_const_26 = lang.RT_Keyword_String_String__Keyword(nil, Lit_34); A_arbace_test_A_const_27 = lang.RT_Var_String_String__Var(Lit_13, Lit_35); A_arbace_test_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_test_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_test_A_const_30 = lang.RT_Var_String_String__Var(Lit_13, Lit_37); A_arbace_test_A_const_31 = lang.RT_Var_String_String__Var(Lit_13, Lit_38); A_arbace_test_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_test_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_test_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_test_A_const_35 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_test_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), nil)); A_arbace_test_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_30).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), nil)); A_arbace_test_A_const_38 = lang.RT_Var_String_String__Var(Lit_13, Lit_42); A_arbace_test_A_const_39 = lang.RT_Keyword_String_String__Keyword(nil, Lit_43); A_arbace_test_A_const_40 = lang.RT_Keyword_String_String__Keyword(nil, Lit_44); A_arbace_test_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_test_A_const_42 = lang.RT_Keyword_String_String__Keyword(nil, Lit_46); A_arbace_test_A_const_43 = lang.RT_Var_String_String__Var(Lit_13, Lit_47); A_arbace_test_A_const_44 = lang.RT_Keyword_String_String__Keyword(nil, Lit_48); A_arbace_test_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_49); A_arbace_test_A_const_46 = lang.RT_Var_String_String__Var(Lit_8, Lit_50); A_arbace_test_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_test_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_test_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_test_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_test_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_test_A_const_52 = lang.RT_Var_String_String__Var(Lit_13, Lit_26); A_arbace_test_A_const_53 = lang.RT_Var_String_String__Var(Lit_13, Lit_55); A_arbace_test_A_const_54 = lang.RT_Keyword_String_String__Keyword(nil, Lit_56); A_arbace_test_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_test_A_const_56 = lang.RT_Keyword_String_String__Keyword(nil, Lit_58); A_arbace_test_A_const_57 = lang.RT_Var_String_String__Var(Lit_13, Lit_59); A_arbace_test_A_const_58 = lang.RT_Var_String_String__Var(Lit_13, Lit_60); A_arbace_test_A_const_59 = lang.RT_Var_String_String__Var(Lit_0, Lit_61); A_arbace_test_A_const_60 = lang.RT_Keyword_String_String__Keyword(nil, Lit_62); A_arbace_test_A_const_61 = lang.RT_Var_String_String__Var(Lit_6, Lit_63); A_arbace_test_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_test_A_const_63 = lang.RT_Var_String_String__Var(Lit_13, Lit_65); A_arbace_test_A_const_64 = lang.RT_Keyword_String_String__Keyword(nil, Lit_66); A_arbace_test_A_const_65 = lang.RT_Var_String_String__Var(Lit_0, Lit_67); A_arbace_test_A_const_66 = lang.RT_Keyword_String_String__Keyword(nil, Lit_68); A_arbace_test_A_const_67 = lang.RT_Var_String_String__Var(Lit_0, Lit_69); A_arbace_test_A_const_68 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_test_A_const_69 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); A_arbace_test_A_const_70 = lang.RT_Var_String_String__Var(Lit_13, Lit_72); A_arbace_test_A_const_71 = lang.RT_Var_String_String__Var(Lit_0, Lit_73); A_arbace_test_A_const_72 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); A_arbace_test_A_const_73 = lang.RT_Keyword_String_String__Keyword(nil, Lit_75); A_arbace_test_A_const_74 = lang.RT_Var_String_String__Var(Lit_0, Lit_76); A_arbace_test_A_const_75 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_77).Ref(); A_arbace_test_A_const_76 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref(); A_arbace_test_A_const_77 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_21).Ref(); A_arbace_test_A_const_78 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref(); A_arbace_test_A_const_79 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_23).Ref(); A_arbace_test_A_const_80 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_80).Ref(); A_arbace_test_A_const_81 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_81).Ref(); A_arbace_test_A_const_82 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_82).Ref(); A_arbace_test_A_const_83 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_83).Ref(); A_arbace_test_A_const_84 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_81).Ref(); A_arbace_test_A_const_85 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_21).Ref(); A_arbace_test_A_const_86 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_74).Ref(); A_arbace_test_A_const_87 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_83).Ref(); A_arbace_test_A_const_88 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_77).Ref(); A_arbace_test_A_const_89 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(); A_arbace_test_A_const_90 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_80).Ref(); A_arbace_test_A_const_91 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_81).Ref(); A_arbace_test_A_const_92 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_81).Ref(); A_arbace_test_A_const_93 = lang.RT_Keyword_String_String__Keyword(nil, Lit_85); A_arbace_test_A_const_94 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_test_A_const_95 = lang.RT_Keyword_String_String__Keyword(nil, Lit_87); A_arbace_test_A_const_96 = lang.RT_Keyword_String_String__Keyword(nil, Lit_88); A_arbace_test_A_const_97 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_81).Ref(); A_arbace_test_A_const_98 = lang.RT_Var_String_String__Var(Lit_0, Lit_89); A_arbace_test_A_const_99 = lang.RT_Var_String_String__Var(Lit_13, Lit_90); A_arbace_test_A_const_100 = lang.RT_Var_String_String__Var(Lit_13, Lit_91); A_arbace_test_A_const_101 = lang.RT_Var_String_String__Var(Lit_13, Lit_92); A_arbace_test_A_const_102 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_77).Ref(); A_arbace_test_A_const_103 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref(); A_arbace_test_A_const_104 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref(); A_arbace_test_A_const_105 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_77).Ref(); A_arbace_test_A_const_106 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref(); A_arbace_test_A_const_107 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_96).Ref(); A_arbace_test_A_const_108 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_80).Ref(); A_arbace_test_A_const_109 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_81).Ref(); A_arbace_test_A_const_110 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_97).Ref(); A_arbace_test_A_const_111 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_81).Ref(); A_arbace_test_A_const_112 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_97).Ref(); A_arbace_test_A_const_113 = lang.RT_Var_String_String__Var(Lit_0, Lit_98); A_arbace_test_A_const_114 = lang.RT_Var_String_String__Var(Lit_0, Lit_99); A_arbace_test_A_const_115 = jrt.Long_ValueOf_J__Long(2).Ref(); A_arbace_test_A_const_116 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref(); A_arbace_test_A_const_117 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_81).Ref(); A_arbace_test_A_const_118 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref(); A_arbace_test_A_const_119 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref(); A_arbace_test_A_const_120 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_81).Ref(); A_arbace_test_A_const_121 = jrt.Long_ValueOf_J__Long(3).Ref(); A_arbace_test_A_const_122 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref(); A_arbace_test_A_const_123 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_81).Ref(); A_arbace_test_A_const_124 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref(); A_arbace_test_A_const_125 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref(); A_arbace_test_A_const_126 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_77).Ref(); A_arbace_test_A_const_127 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_104).Ref(); A_arbace_test_A_const_128 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_105).Ref(); A_arbace_test_A_const_129 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_80).Ref(); A_arbace_test_A_const_130 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_106).Ref(); A_arbace_test_A_const_131 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_81).Ref(); A_arbace_test_A_const_132 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_81).Ref(); A_arbace_test_A_const_133 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref(); A_arbace_test_A_const_134 = lang.RT_Var_String_String__Var(Lit_13, Lit_107); A_arbace_test_A_const_135 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref(); A_arbace_test_A_const_136 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref(); A_arbace_test_A_const_137 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref(); A_arbace_test_A_const_138 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_81).Ref(); A_arbace_test_A_const_139 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_110).Ref(); A_arbace_test_A_const_140 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_111).Ref(); A_arbace_test_A_const_141 = lang.RT_Var_String_String__Var(Lit_0, Lit_112); A_arbace_test_A_const_142 = lang.RT_Var_String_String__Var(Lit_0, Lit_113); A_arbace_test_A_const_143 = lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_114).Ref(); A_arbace_test_A_const_144 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_111).Ref(); A_arbace_test_A_const_145 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_22).Ref(); A_arbace_test_A_const_146 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_37).Ref(); A_arbace_test_A_const_147 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_12).Ref(); A_arbace_test_A_const_148 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_37).Ref(); A_arbace_test_A_const_149 = lang.RT_Var_String_String__Var(Lit_13, Lit_115); A_arbace_test_A_const_150 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_116).Ref(); A_arbace_test_A_const_151 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_117).Ref(); A_arbace_test_A_const_152 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_118).Ref(); A_arbace_test_A_const_153 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_119).Ref(); A_arbace_test_A_const_154 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_120).Ref(); A_arbace_test_A_const_155 = lang.RT_Var_String_String__Var(Lit_0, Lit_121); A_arbace_test_A_const_156 = lang.RT_Var_String_String__Var(Lit_0, Lit_118); A_arbace_test_A_const_157 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_119).Ref(); A_arbace_test_A_const_158 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_119).Ref(); A_arbace_test_A_const_159 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_122).Ref(); A_arbace_test_A_const_160 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_123).Ref(); A_arbace_test_A_const_161 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_120).Ref(); A_arbace_test_A_const_162 = lang.RT_Keyword_String_String__Keyword(nil, Lit_124); A_arbace_test_A_const_163 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_119).Ref(); A_arbace_test_A_const_164 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_119).Ref(); A_arbace_test_A_const_165 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_122).Ref(); A_arbace_test_A_const_166 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_123).Ref(); A_arbace_test_A_const_167 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_117).Ref(); A_arbace_test_A_const_168 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_123).Ref(); A_arbace_test_A_const_169 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_118).Ref(); A_arbace_test_A_const_170 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_119).Ref(); A_arbace_test_A_const_171 = lang.RT_Var_String_String__Var(Lit_0, Lit_117); A_arbace_test_A_const_172 = lang.RT_Var_String_String__Var(Lit_0, Lit_125); A_arbace_test_A_const_173 = lang.RT_Var_String_String__Var(Lit_13, Lit_126); A_arbace_test_A_const_174 = lang.RT_Keyword_String_String__Keyword(Lit_13, Lit_127); A_arbace_test_A_const_175 = lang.RT_Keyword_String_String__Keyword(Lit_13, Lit_128); A_arbace_test_A_const_176 = lang.RT_Var_String_String__Var(Lit_0, Lit_129); A_arbace_test_A_const_177 = lang.RT_Var_String_String__Var(Lit_13, Lit_130); A_arbace_test_A_const_178 = lang.RT_Var_String_String__Var(Lit_13, Lit_131); A_arbace_test_A_const_179 = lang.RT_Var_String_String__Var(Lit_13, Lit_81); A_arbace_test_A_const_180 = lang.RT_Keyword_String_String__Keyword(nil, Lit_132); A_arbace_test_A_const_181 = lang.RT_Keyword_String_String__Keyword(nil, Lit_123); A_arbace_test_A_const_182 = lang.RT_Keyword_String_String__Keyword(nil, Lit_133); A_arbace_test_A_const_183 = lang.RT_Var_String_String__Var(Lit_0, Lit_134); A_arbace_test_A_const_184 = lang.RT_Var_String_String__Var(Lit_0, Lit_135); A_arbace_test_A_const_185 = lang.RT_Var_String_String__Var(Lit_0, Lit_136); A_arbace_test_A_const_186 = lang.RT_Var_String_String__Var(Lit_0, Lit_137); A_arbace_test_A_const_187 = lang.RT_Var_String_String__Var(Lit_0, Lit_138); A_arbace_test_A_const_188 = lang.RT_Var_String_String__Var(Lit_13, Lit_139); A_arbace_test_A_const_189 = lang.RT_Var_String_String__Var(Lit_13, Lit_122); A_arbace_test_A_const_190 = lang.RT_Var_String_String__Var(Lit_0, Lit_140); A_arbace_test_A_const_191 = lang.RT_Var_String_String__Var(Lit_13, Lit_141); A_arbace_test_A_const_192 = lang.RT_Var_String_String__Var(Lit_0, Lit_142); A_arbace_test_A_const_193 = lang.RT_Var_String_String__Var(Lit_0, Lit_143); A_arbace_test_A_const_194 = lang.RT_Var_String_String__Var(Lit_0, Lit_144); A_arbace_test_A_const_195 = lang.RT_Var_String_String__Var(Lit_13, Lit_145); A_arbace_test_A_const_196 = lang.RT_Var_String_String__Var(Lit_0, Lit_146); A_arbace_test_A_const_197 = lang.RT_Var_String_String__Var(Lit_0, Lit_147); A_arbace_test_A_const_198 = lang.RT_Var_String_String__Var(Lit_13, Lit_148); A_arbace_test_A_const_199 = lang.RT_Keyword_String_String__Keyword(nil, Lit_149); A_arbace_test_A_const_200 = lang.RT_Var_String_String__Var(Lit_0, Lit_150); A_arbace_test_A_const_201 = lang.RT_Keyword_String_String__Keyword(nil, Lit_151); A_arbace_test_A_const_202 = lang.RT_Keyword_String_String__Keyword(nil, Lit_152); A_arbace_test_A_const_203 = lang.RT_Var_String_String__Var(Lit_0, Lit_153); A_arbace_test_A_const_204 = lang.RT_Var_String_String__Var(Lit_0, Lit_154); A_arbace_test_A_const_205 = lang.RT_Var_String_String__Var(Lit_13, Lit_155); A_arbace_test_A_const_206 = lang.RT_Var_String_String__Var(Lit_13, Lit_156); A_arbace_test_A_const_207 = lang.RT_Var_String_String__Var(Lit_0, Lit_157); A_arbace_test_A_const_208 = lang.RT_Var_String_String__Var(Lit_0, Lit_158); A_arbace_test_A_const_209 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_test_A_const_210 = lang.RT_Var_String_String__Var(Lit_0, Lit_159); A_arbace_test_A_const_211 = lang.RT_Var_String_String__Var(Lit_0, Lit_160); A_arbace_test_A_const_212 = lang.Symbol_Intern_String_String__Symbol(Lit_13, Lit_161).Ref() }

func A_arbace_test_A_New() *A_arbace_test_A { A_arbace_test_A_Init(); t := &A_arbace_test_A{}; t.Ctor(); return t }

func (t *A_arbace_test_A) Ctor() {}

func (t *A_arbace_test_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_A) GetClass__Class() *jrt.Class { return A_arbace_test_A_class }

func (t *A_arbace_test_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_A); return ok }

func A_arbace_test_A_Cast(x any) *A_arbace_test_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_A_class)) }; return v }



type A_arbace_test_add_ns_meta_A struct{ jrt.Object }

func (t *A_arbace_test_add_ns_meta_A) Is_Compiler_AOTF2() {}

var A_arbace_test_add_ns_meta_A_fn_class *jrt.Class

var A_arbace_test_add_ns_meta_A_init jrt.ClassInit

func A_arbace_test_add_ns_meta_A_Init() { if !A_arbace_test_add_ns_meta_A_init.Done() { A_arbace_test_add_ns_meta_A_init.Run(A_arbace_test_add_ns_meta_A_clinit) } }

func A_arbace_test_add_ns_meta_A_clinit() { A_arbace_test_add_ns_meta_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_162, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_add_ns_meta_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_add_ns_meta_A) GetClass__Class() *jrt.Class { return A_arbace_test_add_ns_meta_A_class }

func (t *A_arbace_test_add_ns_meta_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_add_ns_meta_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_add_ns_meta_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_add_ns_meta_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_add_ns_meta_A); return ok }

func A_arbace_test_add_ns_meta_A_Cast(x any) *A_arbace_test_add_ns_meta_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_add_ns_meta_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_add_ns_meta_A_class)) }; return v }



type A_arbace_test_are_A struct{ jrt.Object }

func (t *A_arbace_test_are_A) Is_Compiler_AOTR4() {}

var A_arbace_test_are_A_fn_class *jrt.Class

var A_arbace_test_are_A_init jrt.ClassInit

func A_arbace_test_are_A_Init() { if !A_arbace_test_are_A_init.Done() { A_arbace_test_are_A_init.Run(A_arbace_test_are_A_clinit) } }

func A_arbace_test_are_A_clinit() { A_arbace_test_are_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_163, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_test_are_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_are_A) GetClass__Class() *jrt.Class { return A_arbace_test_are_A_class }

func (t *A_arbace_test_are_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_are_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_are_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_are_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_are_A); return ok }

func A_arbace_test_are_A_Cast(x any) *A_arbace_test_are_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_are_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_are_A_class)) }; return v }



type A_arbace_test_assert_any_A struct{ jrt.Object }

func (t *A_arbace_test_assert_any_A) Is_Compiler_AOTF2() {}

var A_arbace_test_assert_any_A_fn_class *jrt.Class

var A_arbace_test_assert_any_A_init jrt.ClassInit

func A_arbace_test_assert_any_A_Init() { if !A_arbace_test_assert_any_A_init.Done() { A_arbace_test_assert_any_A_init.Run(A_arbace_test_assert_any_A_clinit) } }

func A_arbace_test_assert_any_A_clinit() { A_arbace_test_assert_any_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_165, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_assert_any_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_assert_any_A) GetClass__Class() *jrt.Class { return A_arbace_test_assert_any_A_class }

func (t *A_arbace_test_assert_any_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_assert_any_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_assert_any_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_assert_any_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_assert_any_A); return ok }

func A_arbace_test_assert_any_A_Cast(x any) *A_arbace_test_assert_any_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_assert_any_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_assert_any_A_class)) }; return v }



type A_arbace_test_assert_predicate_A struct{ jrt.Object }

func (t *A_arbace_test_assert_predicate_A) Is_Compiler_AOTF2() {}

var A_arbace_test_assert_predicate_A_fn_class *jrt.Class

var A_arbace_test_assert_predicate_A_init jrt.ClassInit

func A_arbace_test_assert_predicate_A_Init() { if !A_arbace_test_assert_predicate_A_init.Done() { A_arbace_test_assert_predicate_A_init.Run(A_arbace_test_assert_predicate_A_clinit) } }

func A_arbace_test_assert_predicate_A_clinit() { A_arbace_test_assert_predicate_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_166, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_assert_predicate_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_assert_predicate_A) GetClass__Class() *jrt.Class { return A_arbace_test_assert_predicate_A_class }

func (t *A_arbace_test_assert_predicate_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_assert_predicate_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_assert_predicate_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_assert_predicate_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_assert_predicate_A); return ok }

func A_arbace_test_assert_predicate_A_Cast(x any) *A_arbace_test_assert_predicate_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_assert_predicate_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_assert_predicate_A_class)) }; return v }



type A_arbace_test_compose_fixtures_A struct{ jrt.Object }

func (t *A_arbace_test_compose_fixtures_A) Is_Compiler_AOTF2() {}

var A_arbace_test_compose_fixtures_A_fn_class *jrt.Class

var A_arbace_test_compose_fixtures_A_init jrt.ClassInit

func A_arbace_test_compose_fixtures_A_Init() { if !A_arbace_test_compose_fixtures_A_init.Done() { A_arbace_test_compose_fixtures_A_init.Run(A_arbace_test_compose_fixtures_A_clinit) } }

func A_arbace_test_compose_fixtures_A_clinit() { A_arbace_test_compose_fixtures_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_167, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_compose_fixtures_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_compose_fixtures_A) GetClass__Class() *jrt.Class { return A_arbace_test_compose_fixtures_A_class }

func (t *A_arbace_test_compose_fixtures_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_compose_fixtures_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_compose_fixtures_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_compose_fixtures_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_compose_fixtures_A); return ok }

func A_arbace_test_compose_fixtures_A_Cast(x any) *A_arbace_test_compose_fixtures_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_compose_fixtures_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_compose_fixtures_A_class)) }; return v }



type A_arbace_test_compose_fixtures_fn__196000167_A struct{ jrt.Object; F_f1, F_f2 any }

func (t *A_arbace_test_compose_fixtures_fn__196000167_A) Is_Compiler_AOTF1() {}

var A_arbace_test_compose_fixtures_fn__196000167_A_fn_class *jrt.Class

var A_arbace_test_compose_fixtures_fn__196000167_A_init jrt.ClassInit

func A_arbace_test_compose_fixtures_fn__196000167_A_Init() { if !A_arbace_test_compose_fixtures_fn__196000167_A_init.Done() { A_arbace_test_compose_fixtures_fn__196000167_A_init.Run(A_arbace_test_compose_fixtures_fn__196000167_A_clinit) } }

func A_arbace_test_compose_fixtures_fn__196000167_A_clinit() { A_arbace_test_compose_fixtures_fn__196000167_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_168, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_compose_fixtures_fn__196000167_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_compose_fixtures_fn__196000167_A) GetClass__Class() *jrt.Class { return A_arbace_test_compose_fixtures_fn__196000167_A_class }

func (t *A_arbace_test_compose_fixtures_fn__196000167_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_compose_fixtures_fn__196000167_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_compose_fixtures_fn__196000167_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_compose_fixtures_fn__196000167_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_compose_fixtures_fn__196000167_A); return ok }

func A_arbace_test_compose_fixtures_fn__196000167_A_Cast(x any) *A_arbace_test_compose_fixtures_fn__196000167_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_compose_fixtures_fn__196000167_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_compose_fixtures_fn__196000167_A_class)) }; return v }



type A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A struct{ jrt.Object; F_g, F_f2 any }

func (t *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A) Is_Compiler_AOTF0() {}

var A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_fn_class *jrt.Class

var A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_init jrt.ClassInit

func A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_Init() { if !A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_init.Done() { A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_init.Run(A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_clinit) } }

func A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_clinit() { A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_169, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A) GetClass__Class() *jrt.Class { return A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_class }

func (t *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A); return ok }

func A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_Cast(x any) *A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_compose_fixtures_fn__196000167_fn__196000168_A_class)) }; return v }



type A_arbace_test_default_fixture_A struct{ jrt.Object }

func (t *A_arbace_test_default_fixture_A) Is_Compiler_AOTF1() {}

var A_arbace_test_default_fixture_A_fn_class *jrt.Class

var A_arbace_test_default_fixture_A_init jrt.ClassInit

func A_arbace_test_default_fixture_A_Init() { if !A_arbace_test_default_fixture_A_init.Done() { A_arbace_test_default_fixture_A_init.Run(A_arbace_test_default_fixture_A_clinit) } }

func A_arbace_test_default_fixture_A_clinit() { A_arbace_test_default_fixture_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_170, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_default_fixture_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_default_fixture_A) GetClass__Class() *jrt.Class { return A_arbace_test_default_fixture_A_class }

func (t *A_arbace_test_default_fixture_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_default_fixture_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_default_fixture_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_default_fixture_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_default_fixture_A); return ok }

func A_arbace_test_default_fixture_A_Cast(x any) *A_arbace_test_default_fixture_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_default_fixture_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_default_fixture_A_class)) }; return v }



type A_arbace_test_deftest_A struct{ jrt.Object }

func (t *A_arbace_test_deftest_A) Is_Compiler_AOTR3() {}

var A_arbace_test_deftest_A_fn_class *jrt.Class

var A_arbace_test_deftest_A_init jrt.ClassInit

func A_arbace_test_deftest_A_Init() { if !A_arbace_test_deftest_A_init.Done() { A_arbace_test_deftest_A_init.Run(A_arbace_test_deftest_A_clinit) } }

func A_arbace_test_deftest_A_clinit() { A_arbace_test_deftest_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_171, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_test_deftest_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_deftest_A) GetClass__Class() *jrt.Class { return A_arbace_test_deftest_A_class }

func (t *A_arbace_test_deftest_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_deftest_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_deftest_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_deftest_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_deftest_A); return ok }

func A_arbace_test_deftest_A_Cast(x any) *A_arbace_test_deftest_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_deftest_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_deftest_A_class)) }; return v }



type A_arbace_test_deftest__A struct{ jrt.Object }

func (t *A_arbace_test_deftest__A) Is_Compiler_AOTR3() {}

var A_arbace_test_deftest__A_fn_class *jrt.Class

var A_arbace_test_deftest__A_init jrt.ClassInit

func A_arbace_test_deftest__A_Init() { if !A_arbace_test_deftest__A_init.Done() { A_arbace_test_deftest__A_init.Run(A_arbace_test_deftest__A_clinit) } }

func A_arbace_test_deftest__A_clinit() { A_arbace_test_deftest__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_172, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_test_deftest__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_deftest__A) GetClass__Class() *jrt.Class { return A_arbace_test_deftest__A_class }

func (t *A_arbace_test_deftest__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_deftest__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_deftest__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_deftest__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_deftest__A); return ok }

func A_arbace_test_deftest__A_Cast(x any) *A_arbace_test_deftest__A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_deftest__A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_deftest__A_class)) }; return v }



type A_arbace_test_do_report_A struct{ jrt.Object }

func (t *A_arbace_test_do_report_A) Is_Compiler_AOTF1() {}

var A_arbace_test_do_report_A_fn_class *jrt.Class

var A_arbace_test_do_report_A_init jrt.ClassInit

func A_arbace_test_do_report_A_Init() { if !A_arbace_test_do_report_A_init.Done() { A_arbace_test_do_report_A_init.Run(A_arbace_test_do_report_A_clinit) } }

func A_arbace_test_do_report_A_clinit() { A_arbace_test_do_report_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_173, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_do_report_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_do_report_A) GetClass__Class() *jrt.Class { return A_arbace_test_do_report_A_class }

func (t *A_arbace_test_do_report_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_do_report_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_do_report_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_do_report_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_do_report_A); return ok }

func A_arbace_test_do_report_A_Cast(x any) *A_arbace_test_do_report_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_do_report_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_do_report_A_class)) }; return v }



type A_arbace_test_do_report_fn__196000036_A struct{ jrt.Object }

func (t *A_arbace_test_do_report_fn__196000036_A) Is_Compiler_AOTF1() {}

var A_arbace_test_do_report_fn__196000036_A_fn_class *jrt.Class

var A_arbace_test_do_report_fn__196000036_A_init jrt.ClassInit

func A_arbace_test_do_report_fn__196000036_A_Init() { if !A_arbace_test_do_report_fn__196000036_A_init.Done() { A_arbace_test_do_report_fn__196000036_A_init.Run(A_arbace_test_do_report_fn__196000036_A_clinit) } }

func A_arbace_test_do_report_fn__196000036_A_clinit() { A_arbace_test_do_report_fn__196000036_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_174, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_do_report_fn__196000036_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_do_report_fn__196000036_A) GetClass__Class() *jrt.Class { return A_arbace_test_do_report_fn__196000036_A_class }

func (t *A_arbace_test_do_report_fn__196000036_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_do_report_fn__196000036_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_do_report_fn__196000036_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_do_report_fn__196000036_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_do_report_fn__196000036_A); return ok }

func A_arbace_test_do_report_fn__196000036_A_Cast(x any) *A_arbace_test_do_report_fn__196000036_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_do_report_fn__196000036_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_do_report_fn__196000036_A_class)) }; return v }



type A_arbace_test_eval196000004_A struct{ jrt.Object }

func A_arbace_test_eval196000004_A_New() *A_arbace_test_eval196000004_A { t := &A_arbace_test_eval196000004_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000004_A) Ctor() {}

func (t *A_arbace_test_eval196000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000004_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000004_A_class }

func (t *A_arbace_test_eval196000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000004_A); return ok }

func A_arbace_test_eval196000004_A_Cast(x any) *A_arbace_test_eval196000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000004_A_class)) }; return v }



type A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A) Is_Compiler_AOTF0() {}

var A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_fn_class *jrt.Class

var A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_init jrt.ClassInit

func A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_Init() { if !A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_init.Done() { A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_init.Run(A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_clinit) } }

func A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_clinit() { A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_178, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_class }

func (t *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A); return ok }

func A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_Cast(x any) *A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000004_loading__1927001464__auto____196000005_A_class)) }; return v }



type A_arbace_test_eval196000008_A struct{ jrt.Object }

func A_arbace_test_eval196000008_A_New() *A_arbace_test_eval196000008_A { t := &A_arbace_test_eval196000008_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000008_A) Ctor() {}

func (t *A_arbace_test_eval196000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000008_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000008_A_class }

func (t *A_arbace_test_eval196000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000008_A); return ok }

func A_arbace_test_eval196000008_A_Cast(x any) *A_arbace_test_eval196000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000008_A_class)) }; return v }



type A_arbace_test_eval196000008_fn__196000009_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000008_fn__196000009_A) Is_Compiler_AOTF0() {}

var A_arbace_test_eval196000008_fn__196000009_A_fn_class *jrt.Class

var A_arbace_test_eval196000008_fn__196000009_A_init jrt.ClassInit

func A_arbace_test_eval196000008_fn__196000009_A_Init() { if !A_arbace_test_eval196000008_fn__196000009_A_init.Done() { A_arbace_test_eval196000008_fn__196000009_A_init.Run(A_arbace_test_eval196000008_fn__196000009_A_clinit) } }

func A_arbace_test_eval196000008_fn__196000009_A_clinit() { A_arbace_test_eval196000008_fn__196000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_179, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000008_fn__196000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000008_fn__196000009_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000008_fn__196000009_A_class }

func (t *A_arbace_test_eval196000008_fn__196000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000008_fn__196000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000008_fn__196000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000008_fn__196000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000008_fn__196000009_A); return ok }

func A_arbace_test_eval196000008_fn__196000009_A_Cast(x any) *A_arbace_test_eval196000008_fn__196000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000008_fn__196000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000008_fn__196000009_A_class)) }; return v }



type A_arbace_test_eval196000039_A struct{ jrt.Object }

func A_arbace_test_eval196000039_A_New() *A_arbace_test_eval196000039_A { t := &A_arbace_test_eval196000039_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000039_A) Ctor() {}

func (t *A_arbace_test_eval196000039_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000039_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000039_A_class }

func (t *A_arbace_test_eval196000039_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000039_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000039_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000039_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000039_A); return ok }

func A_arbace_test_eval196000039_A_Cast(x any) *A_arbace_test_eval196000039_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000039_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000039_A_class)) }; return v }



type A_arbace_test_eval196000039_fn__196000040_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000039_fn__196000040_A) Is_Compiler_AOTF1() {}

var A_arbace_test_eval196000039_fn__196000040_A_fn_class *jrt.Class

var A_arbace_test_eval196000039_fn__196000040_A_init jrt.ClassInit

func A_arbace_test_eval196000039_fn__196000040_A_Init() { if !A_arbace_test_eval196000039_fn__196000040_A_init.Done() { A_arbace_test_eval196000039_fn__196000040_A_init.Run(A_arbace_test_eval196000039_fn__196000040_A_clinit) } }

func A_arbace_test_eval196000039_fn__196000040_A_clinit() { A_arbace_test_eval196000039_fn__196000040_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_180, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000039_fn__196000040_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000039_fn__196000040_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000039_fn__196000040_A_class }

func (t *A_arbace_test_eval196000039_fn__196000040_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000039_fn__196000040_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000039_fn__196000040_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000039_fn__196000040_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000039_fn__196000040_A); return ok }

func A_arbace_test_eval196000039_fn__196000040_A_Cast(x any) *A_arbace_test_eval196000039_fn__196000040_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000039_fn__196000040_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000039_fn__196000040_A_class)) }; return v }



type A_arbace_test_eval196000043_A struct{ jrt.Object }

func A_arbace_test_eval196000043_A_New() *A_arbace_test_eval196000043_A { t := &A_arbace_test_eval196000043_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000043_A) Ctor() {}

func (t *A_arbace_test_eval196000043_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000043_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000043_A_class }

func (t *A_arbace_test_eval196000043_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000043_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000043_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000043_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000043_A); return ok }

func A_arbace_test_eval196000043_A_Cast(x any) *A_arbace_test_eval196000043_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000043_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000043_A_class)) }; return v }



type A_arbace_test_eval196000043_fn__196000044_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000043_fn__196000044_A) Is_Compiler_AOTF1() {}

var A_arbace_test_eval196000043_fn__196000044_A_fn_class *jrt.Class

var A_arbace_test_eval196000043_fn__196000044_A_init jrt.ClassInit

func A_arbace_test_eval196000043_fn__196000044_A_Init() { if !A_arbace_test_eval196000043_fn__196000044_A_init.Done() { A_arbace_test_eval196000043_fn__196000044_A_init.Run(A_arbace_test_eval196000043_fn__196000044_A_clinit) } }

func A_arbace_test_eval196000043_fn__196000044_A_clinit() { A_arbace_test_eval196000043_fn__196000044_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_181, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000043_fn__196000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000043_fn__196000044_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000043_fn__196000044_A_class }

func (t *A_arbace_test_eval196000043_fn__196000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000043_fn__196000044_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000043_fn__196000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000043_fn__196000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000043_fn__196000044_A); return ok }

func A_arbace_test_eval196000043_fn__196000044_A_Cast(x any) *A_arbace_test_eval196000043_fn__196000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000043_fn__196000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000043_fn__196000044_A_class)) }; return v }



type A_arbace_test_eval196000047_A struct{ jrt.Object }

func A_arbace_test_eval196000047_A_New() *A_arbace_test_eval196000047_A { t := &A_arbace_test_eval196000047_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000047_A) Ctor() {}

func (t *A_arbace_test_eval196000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000047_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000047_A_class }

func (t *A_arbace_test_eval196000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000047_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000047_A); return ok }

func A_arbace_test_eval196000047_A_Cast(x any) *A_arbace_test_eval196000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000047_A_class)) }; return v }



type A_arbace_test_eval196000047_fn__196000048_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000047_fn__196000048_A) Is_Compiler_AOTF1() {}

var A_arbace_test_eval196000047_fn__196000048_A_fn_class *jrt.Class

var A_arbace_test_eval196000047_fn__196000048_A_init jrt.ClassInit

func A_arbace_test_eval196000047_fn__196000048_A_Init() { if !A_arbace_test_eval196000047_fn__196000048_A_init.Done() { A_arbace_test_eval196000047_fn__196000048_A_init.Run(A_arbace_test_eval196000047_fn__196000048_A_clinit) } }

func A_arbace_test_eval196000047_fn__196000048_A_clinit() { A_arbace_test_eval196000047_fn__196000048_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_182, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000047_fn__196000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000047_fn__196000048_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000047_fn__196000048_A_class }

func (t *A_arbace_test_eval196000047_fn__196000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000047_fn__196000048_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000047_fn__196000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000047_fn__196000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000047_fn__196000048_A); return ok }

func A_arbace_test_eval196000047_fn__196000048_A_Cast(x any) *A_arbace_test_eval196000047_fn__196000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000047_fn__196000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000047_fn__196000048_A_class)) }; return v }



type A_arbace_test_eval196000051_A struct{ jrt.Object }

func A_arbace_test_eval196000051_A_New() *A_arbace_test_eval196000051_A { t := &A_arbace_test_eval196000051_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000051_A) Ctor() {}

func (t *A_arbace_test_eval196000051_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000051_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000051_A_class }

func (t *A_arbace_test_eval196000051_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000051_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000051_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000051_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000051_A); return ok }

func A_arbace_test_eval196000051_A_Cast(x any) *A_arbace_test_eval196000051_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000051_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000051_A_class)) }; return v }



type A_arbace_test_eval196000051_fn__196000052_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000051_fn__196000052_A) Is_Compiler_AOTF1() {}

var A_arbace_test_eval196000051_fn__196000052_A_fn_class *jrt.Class

var A_arbace_test_eval196000051_fn__196000052_A_init jrt.ClassInit

func A_arbace_test_eval196000051_fn__196000052_A_Init() { if !A_arbace_test_eval196000051_fn__196000052_A_init.Done() { A_arbace_test_eval196000051_fn__196000052_A_init.Run(A_arbace_test_eval196000051_fn__196000052_A_clinit) } }

func A_arbace_test_eval196000051_fn__196000052_A_clinit() { A_arbace_test_eval196000051_fn__196000052_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_186, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000051_fn__196000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000051_fn__196000052_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000051_fn__196000052_A_class }

func (t *A_arbace_test_eval196000051_fn__196000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000051_fn__196000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000051_fn__196000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000051_fn__196000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000051_fn__196000052_A); return ok }

func A_arbace_test_eval196000051_fn__196000052_A_Cast(x any) *A_arbace_test_eval196000051_fn__196000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000051_fn__196000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000051_fn__196000052_A_class)) }; return v }



type A_arbace_test_eval196000055_A struct{ jrt.Object }

func A_arbace_test_eval196000055_A_New() *A_arbace_test_eval196000055_A { t := &A_arbace_test_eval196000055_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000055_A) Ctor() {}

func (t *A_arbace_test_eval196000055_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000055_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000055_A_class }

func (t *A_arbace_test_eval196000055_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000055_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000055_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000055_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000055_A); return ok }

func A_arbace_test_eval196000055_A_Cast(x any) *A_arbace_test_eval196000055_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000055_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000055_A_class)) }; return v }



type A_arbace_test_eval196000055_fn__196000056_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000055_fn__196000056_A) Is_Compiler_AOTF1() {}

var A_arbace_test_eval196000055_fn__196000056_A_fn_class *jrt.Class

var A_arbace_test_eval196000055_fn__196000056_A_init jrt.ClassInit

func A_arbace_test_eval196000055_fn__196000056_A_Init() { if !A_arbace_test_eval196000055_fn__196000056_A_init.Done() { A_arbace_test_eval196000055_fn__196000056_A_init.Run(A_arbace_test_eval196000055_fn__196000056_A_clinit) } }

func A_arbace_test_eval196000055_fn__196000056_A_clinit() { A_arbace_test_eval196000055_fn__196000056_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_189, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000055_fn__196000056_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000055_fn__196000056_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000055_fn__196000056_A_class }

func (t *A_arbace_test_eval196000055_fn__196000056_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000055_fn__196000056_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000055_fn__196000056_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000055_fn__196000056_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000055_fn__196000056_A); return ok }

func A_arbace_test_eval196000055_fn__196000056_A_Cast(x any) *A_arbace_test_eval196000055_fn__196000056_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000055_fn__196000056_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000055_fn__196000056_A_class)) }; return v }



type A_arbace_test_eval196000059_A struct{ jrt.Object }

func A_arbace_test_eval196000059_A_New() *A_arbace_test_eval196000059_A { t := &A_arbace_test_eval196000059_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000059_A) Ctor() {}

func (t *A_arbace_test_eval196000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000059_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000059_A_class }

func (t *A_arbace_test_eval196000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000059_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000059_A); return ok }

func A_arbace_test_eval196000059_A_Cast(x any) *A_arbace_test_eval196000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000059_A_class)) }; return v }



type A_arbace_test_eval196000059_fn__196000060_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000059_fn__196000060_A) Is_Compiler_AOTF1() {}

var A_arbace_test_eval196000059_fn__196000060_A_fn_class *jrt.Class

var A_arbace_test_eval196000059_fn__196000060_A_init jrt.ClassInit

func A_arbace_test_eval196000059_fn__196000060_A_Init() { if !A_arbace_test_eval196000059_fn__196000060_A_init.Done() { A_arbace_test_eval196000059_fn__196000060_A_init.Run(A_arbace_test_eval196000059_fn__196000060_A_clinit) } }

func A_arbace_test_eval196000059_fn__196000060_A_clinit() { A_arbace_test_eval196000059_fn__196000060_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_195, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000059_fn__196000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000059_fn__196000060_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000059_fn__196000060_A_class }

func (t *A_arbace_test_eval196000059_fn__196000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000059_fn__196000060_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000059_fn__196000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000059_fn__196000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000059_fn__196000060_A); return ok }

func A_arbace_test_eval196000059_fn__196000060_A_Cast(x any) *A_arbace_test_eval196000059_fn__196000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000059_fn__196000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000059_fn__196000060_A_class)) }; return v }



type A_arbace_test_eval196000063_A struct{ jrt.Object }

func A_arbace_test_eval196000063_A_New() *A_arbace_test_eval196000063_A { t := &A_arbace_test_eval196000063_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000063_A) Ctor() {}

func (t *A_arbace_test_eval196000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000063_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000063_A_class }

func (t *A_arbace_test_eval196000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000063_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000063_A); return ok }

func A_arbace_test_eval196000063_A_Cast(x any) *A_arbace_test_eval196000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000063_A_class)) }; return v }



type A_arbace_test_eval196000063_fn__196000064_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000063_fn__196000064_A) Is_Compiler_AOTF1() {}

var A_arbace_test_eval196000063_fn__196000064_A_fn_class *jrt.Class

var A_arbace_test_eval196000063_fn__196000064_A_init jrt.ClassInit

func A_arbace_test_eval196000063_fn__196000064_A_Init() { if !A_arbace_test_eval196000063_fn__196000064_A_init.Done() { A_arbace_test_eval196000063_fn__196000064_A_init.Run(A_arbace_test_eval196000063_fn__196000064_A_clinit) } }

func A_arbace_test_eval196000063_fn__196000064_A_clinit() { A_arbace_test_eval196000063_fn__196000064_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_197, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000063_fn__196000064_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000063_fn__196000064_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000063_fn__196000064_A_class }

func (t *A_arbace_test_eval196000063_fn__196000064_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000063_fn__196000064_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000063_fn__196000064_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000063_fn__196000064_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000063_fn__196000064_A); return ok }

func A_arbace_test_eval196000063_fn__196000064_A_Cast(x any) *A_arbace_test_eval196000063_fn__196000064_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000063_fn__196000064_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000063_fn__196000064_A_class)) }; return v }



type A_arbace_test_eval196000067_A struct{ jrt.Object }

func A_arbace_test_eval196000067_A_New() *A_arbace_test_eval196000067_A { t := &A_arbace_test_eval196000067_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000067_A) Ctor() {}

func (t *A_arbace_test_eval196000067_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000067_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000067_A_class }

func (t *A_arbace_test_eval196000067_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000067_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000067_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000067_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000067_A); return ok }

func A_arbace_test_eval196000067_A_Cast(x any) *A_arbace_test_eval196000067_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000067_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000067_A_class)) }; return v }



type A_arbace_test_eval196000067_fn__196000068_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000067_fn__196000068_A) Is_Compiler_AOTF1() {}

var A_arbace_test_eval196000067_fn__196000068_A_fn_class *jrt.Class

var A_arbace_test_eval196000067_fn__196000068_A_init jrt.ClassInit

func A_arbace_test_eval196000067_fn__196000068_A_Init() { if !A_arbace_test_eval196000067_fn__196000068_A_init.Done() { A_arbace_test_eval196000067_fn__196000068_A_init.Run(A_arbace_test_eval196000067_fn__196000068_A_clinit) } }

func A_arbace_test_eval196000067_fn__196000068_A_clinit() { A_arbace_test_eval196000067_fn__196000068_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_198, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000067_fn__196000068_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000067_fn__196000068_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000067_fn__196000068_A_class }

func (t *A_arbace_test_eval196000067_fn__196000068_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000067_fn__196000068_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000067_fn__196000068_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000067_fn__196000068_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000067_fn__196000068_A); return ok }

func A_arbace_test_eval196000067_fn__196000068_A_Cast(x any) *A_arbace_test_eval196000067_fn__196000068_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000067_fn__196000068_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000067_fn__196000068_A_class)) }; return v }



type A_arbace_test_eval196000071_A struct{ jrt.Object }

func A_arbace_test_eval196000071_A_New() *A_arbace_test_eval196000071_A { t := &A_arbace_test_eval196000071_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000071_A) Ctor() {}

func (t *A_arbace_test_eval196000071_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000071_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000071_A_class }

func (t *A_arbace_test_eval196000071_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000071_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000071_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000071_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000071_A); return ok }

func A_arbace_test_eval196000071_A_Cast(x any) *A_arbace_test_eval196000071_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000071_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000071_A_class)) }; return v }



type A_arbace_test_eval196000071_fn__196000072_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000071_fn__196000072_A) Is_Compiler_AOTF1() {}

var A_arbace_test_eval196000071_fn__196000072_A_fn_class *jrt.Class

var A_arbace_test_eval196000071_fn__196000072_A_init jrt.ClassInit

func A_arbace_test_eval196000071_fn__196000072_A_Init() { if !A_arbace_test_eval196000071_fn__196000072_A_init.Done() { A_arbace_test_eval196000071_fn__196000072_A_init.Run(A_arbace_test_eval196000071_fn__196000072_A_clinit) } }

func A_arbace_test_eval196000071_fn__196000072_A_clinit() { A_arbace_test_eval196000071_fn__196000072_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_199, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000071_fn__196000072_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000071_fn__196000072_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000071_fn__196000072_A_class }

func (t *A_arbace_test_eval196000071_fn__196000072_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000071_fn__196000072_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000071_fn__196000072_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000071_fn__196000072_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000071_fn__196000072_A); return ok }

func A_arbace_test_eval196000071_fn__196000072_A_Cast(x any) *A_arbace_test_eval196000071_fn__196000072_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000071_fn__196000072_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000071_fn__196000072_A_class)) }; return v }



type A_arbace_test_eval196000082_A struct{ jrt.Object }

func A_arbace_test_eval196000082_A_New() *A_arbace_test_eval196000082_A { t := &A_arbace_test_eval196000082_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000082_A) Ctor() {}

func (t *A_arbace_test_eval196000082_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000082_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000082_A_class }

func (t *A_arbace_test_eval196000082_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000082_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000082_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000082_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000082_A); return ok }

func A_arbace_test_eval196000082_A_Cast(x any) *A_arbace_test_eval196000082_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000082_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000082_A_class)) }; return v }



type A_arbace_test_eval196000082_fn__196000083_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000082_fn__196000083_A) Is_Compiler_AOTF2() {}

var A_arbace_test_eval196000082_fn__196000083_A_fn_class *jrt.Class

var A_arbace_test_eval196000082_fn__196000083_A_init jrt.ClassInit

func A_arbace_test_eval196000082_fn__196000083_A_Init() { if !A_arbace_test_eval196000082_fn__196000083_A_init.Done() { A_arbace_test_eval196000082_fn__196000083_A_init.Run(A_arbace_test_eval196000082_fn__196000083_A_clinit) } }

func A_arbace_test_eval196000082_fn__196000083_A_clinit() { A_arbace_test_eval196000082_fn__196000083_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_200, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000082_fn__196000083_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000082_fn__196000083_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000082_fn__196000083_A_class }

func (t *A_arbace_test_eval196000082_fn__196000083_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000082_fn__196000083_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000082_fn__196000083_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000082_fn__196000083_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000082_fn__196000083_A); return ok }

func A_arbace_test_eval196000082_fn__196000083_A_Cast(x any) *A_arbace_test_eval196000082_fn__196000083_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000082_fn__196000083_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000082_fn__196000083_A_class)) }; return v }



type A_arbace_test_eval196000086_A struct{ jrt.Object }

func A_arbace_test_eval196000086_A_New() *A_arbace_test_eval196000086_A { t := &A_arbace_test_eval196000086_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000086_A) Ctor() {}

func (t *A_arbace_test_eval196000086_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000086_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000086_A_class }

func (t *A_arbace_test_eval196000086_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000086_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000086_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000086_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000086_A); return ok }

func A_arbace_test_eval196000086_A_Cast(x any) *A_arbace_test_eval196000086_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000086_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000086_A_class)) }; return v }



type A_arbace_test_eval196000086_fn__196000087_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000086_fn__196000087_A) Is_Compiler_AOTF2() {}

var A_arbace_test_eval196000086_fn__196000087_A_fn_class *jrt.Class

var A_arbace_test_eval196000086_fn__196000087_A_init jrt.ClassInit

func A_arbace_test_eval196000086_fn__196000087_A_Init() { if !A_arbace_test_eval196000086_fn__196000087_A_init.Done() { A_arbace_test_eval196000086_fn__196000087_A_init.Run(A_arbace_test_eval196000086_fn__196000087_A_clinit) } }

func A_arbace_test_eval196000086_fn__196000087_A_clinit() { A_arbace_test_eval196000086_fn__196000087_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_201, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000086_fn__196000087_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000086_fn__196000087_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000086_fn__196000087_A_class }

func (t *A_arbace_test_eval196000086_fn__196000087_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000086_fn__196000087_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000086_fn__196000087_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000086_fn__196000087_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000086_fn__196000087_A); return ok }

func A_arbace_test_eval196000086_fn__196000087_A_Cast(x any) *A_arbace_test_eval196000086_fn__196000087_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000086_fn__196000087_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000086_fn__196000087_A_class)) }; return v }



type A_arbace_test_eval196000090_A struct{ jrt.Object }

func A_arbace_test_eval196000090_A_New() *A_arbace_test_eval196000090_A { t := &A_arbace_test_eval196000090_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000090_A) Ctor() {}

func (t *A_arbace_test_eval196000090_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000090_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000090_A_class }

func (t *A_arbace_test_eval196000090_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000090_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000090_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000090_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000090_A); return ok }

func A_arbace_test_eval196000090_A_Cast(x any) *A_arbace_test_eval196000090_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000090_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000090_A_class)) }; return v }



type A_arbace_test_eval196000090_fn__196000091_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000090_fn__196000091_A) Is_Compiler_AOTF2() {}

var A_arbace_test_eval196000090_fn__196000091_A_fn_class *jrt.Class

var A_arbace_test_eval196000090_fn__196000091_A_init jrt.ClassInit

func A_arbace_test_eval196000090_fn__196000091_A_Init() { if !A_arbace_test_eval196000090_fn__196000091_A_init.Done() { A_arbace_test_eval196000090_fn__196000091_A_init.Run(A_arbace_test_eval196000090_fn__196000091_A_clinit) } }

func A_arbace_test_eval196000090_fn__196000091_A_clinit() { A_arbace_test_eval196000090_fn__196000091_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_202, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000090_fn__196000091_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000090_fn__196000091_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000090_fn__196000091_A_class }

func (t *A_arbace_test_eval196000090_fn__196000091_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000090_fn__196000091_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000090_fn__196000091_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000090_fn__196000091_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000090_fn__196000091_A); return ok }

func A_arbace_test_eval196000090_fn__196000091_A_Cast(x any) *A_arbace_test_eval196000090_fn__196000091_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000090_fn__196000091_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000090_fn__196000091_A_class)) }; return v }



type A_arbace_test_eval196000097_A struct{ jrt.Object }

func A_arbace_test_eval196000097_A_New() *A_arbace_test_eval196000097_A { t := &A_arbace_test_eval196000097_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000097_A) Ctor() {}

func (t *A_arbace_test_eval196000097_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000097_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000097_A_class }

func (t *A_arbace_test_eval196000097_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000097_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000097_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000097_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000097_A); return ok }

func A_arbace_test_eval196000097_A_Cast(x any) *A_arbace_test_eval196000097_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000097_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000097_A_class)) }; return v }



type A_arbace_test_eval196000097_fn__196000098_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000097_fn__196000098_A) Is_Compiler_AOTF2() {}

var A_arbace_test_eval196000097_fn__196000098_A_fn_class *jrt.Class

var A_arbace_test_eval196000097_fn__196000098_A_init jrt.ClassInit

func A_arbace_test_eval196000097_fn__196000098_A_Init() { if !A_arbace_test_eval196000097_fn__196000098_A_init.Done() { A_arbace_test_eval196000097_fn__196000098_A_init.Run(A_arbace_test_eval196000097_fn__196000098_A_clinit) } }

func A_arbace_test_eval196000097_fn__196000098_A_clinit() { A_arbace_test_eval196000097_fn__196000098_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_203, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000097_fn__196000098_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000097_fn__196000098_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000097_fn__196000098_A_class }

func (t *A_arbace_test_eval196000097_fn__196000098_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000097_fn__196000098_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000097_fn__196000098_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000097_fn__196000098_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000097_fn__196000098_A); return ok }

func A_arbace_test_eval196000097_fn__196000098_A_Cast(x any) *A_arbace_test_eval196000097_fn__196000098_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000097_fn__196000098_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000097_fn__196000098_A_class)) }; return v }



type A_arbace_test_eval196000102_A struct{ jrt.Object }

func A_arbace_test_eval196000102_A_New() *A_arbace_test_eval196000102_A { t := &A_arbace_test_eval196000102_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000102_A) Ctor() {}

func (t *A_arbace_test_eval196000102_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000102_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000102_A_class }

func (t *A_arbace_test_eval196000102_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000102_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000102_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000102_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000102_A); return ok }

func A_arbace_test_eval196000102_A_Cast(x any) *A_arbace_test_eval196000102_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000102_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000102_A_class)) }; return v }



type A_arbace_test_eval196000102_fn__196000103_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000102_fn__196000103_A) Is_Compiler_AOTF2() {}

var A_arbace_test_eval196000102_fn__196000103_A_fn_class *jrt.Class

var A_arbace_test_eval196000102_fn__196000103_A_init jrt.ClassInit

func A_arbace_test_eval196000102_fn__196000103_A_Init() { if !A_arbace_test_eval196000102_fn__196000103_A_init.Done() { A_arbace_test_eval196000102_fn__196000103_A_init.Run(A_arbace_test_eval196000102_fn__196000103_A_clinit) } }

func A_arbace_test_eval196000102_fn__196000103_A_clinit() { A_arbace_test_eval196000102_fn__196000103_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_204, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000102_fn__196000103_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000102_fn__196000103_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000102_fn__196000103_A_class }

func (t *A_arbace_test_eval196000102_fn__196000103_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000102_fn__196000103_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000102_fn__196000103_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000102_fn__196000103_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000102_fn__196000103_A); return ok }

func A_arbace_test_eval196000102_fn__196000103_A_Cast(x any) *A_arbace_test_eval196000102_fn__196000103_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000102_fn__196000103_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000102_fn__196000103_A_class)) }; return v }



type A_arbace_test_eval196000108_A struct{ jrt.Object }

func A_arbace_test_eval196000108_A_New() *A_arbace_test_eval196000108_A { t := &A_arbace_test_eval196000108_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000108_A) Ctor() {}

func (t *A_arbace_test_eval196000108_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000108_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000108_A_class }

func (t *A_arbace_test_eval196000108_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000108_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000108_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000108_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000108_A); return ok }

func A_arbace_test_eval196000108_A_Cast(x any) *A_arbace_test_eval196000108_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000108_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000108_A_class)) }; return v }



type A_arbace_test_eval196000108_fn__196000109_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000108_fn__196000109_A) Is_Compiler_AOTF2() {}

var A_arbace_test_eval196000108_fn__196000109_A_fn_class *jrt.Class

var A_arbace_test_eval196000108_fn__196000109_A_init jrt.ClassInit

func A_arbace_test_eval196000108_fn__196000109_A_Init() { if !A_arbace_test_eval196000108_fn__196000109_A_init.Done() { A_arbace_test_eval196000108_fn__196000109_A_init.Run(A_arbace_test_eval196000108_fn__196000109_A_clinit) } }

func A_arbace_test_eval196000108_fn__196000109_A_clinit() { A_arbace_test_eval196000108_fn__196000109_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_205, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_eval196000108_fn__196000109_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000108_fn__196000109_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000108_fn__196000109_A_class }

func (t *A_arbace_test_eval196000108_fn__196000109_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000108_fn__196000109_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000108_fn__196000109_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000108_fn__196000109_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000108_fn__196000109_A); return ok }

func A_arbace_test_eval196000108_fn__196000109_A_Cast(x any) *A_arbace_test_eval196000108_fn__196000109_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000108_fn__196000109_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000108_fn__196000109_A_class)) }; return v }



type A_arbace_test_eval196000154_A struct{ jrt.Object }

func A_arbace_test_eval196000154_A_New() *A_arbace_test_eval196000154_A { t := &A_arbace_test_eval196000154_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000154_A) Ctor() {}

func (t *A_arbace_test_eval196000154_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000154_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000154_A_class }

func (t *A_arbace_test_eval196000154_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000154_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000154_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000154_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000154_A); return ok }

func A_arbace_test_eval196000154_A_Cast(x any) *A_arbace_test_eval196000154_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000154_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000154_A_class)) }; return v }



type A_arbace_test_eval196000154_fn__196000155_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000154_fn__196000155_A) Is_Compiler_AOTR1() {}

var A_arbace_test_eval196000154_fn__196000155_A_fn_class *jrt.Class

var A_arbace_test_eval196000154_fn__196000155_A_init jrt.ClassInit

func A_arbace_test_eval196000154_fn__196000155_A_Init() { if !A_arbace_test_eval196000154_fn__196000155_A_init.Done() { A_arbace_test_eval196000154_fn__196000155_A_init.Run(A_arbace_test_eval196000154_fn__196000155_A_clinit) } }

func A_arbace_test_eval196000154_fn__196000155_A_clinit() { A_arbace_test_eval196000154_fn__196000155_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_206, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_test_eval196000154_fn__196000155_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000154_fn__196000155_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000154_fn__196000155_A_class }

func (t *A_arbace_test_eval196000154_fn__196000155_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000154_fn__196000155_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000154_fn__196000155_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000154_fn__196000155_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000154_fn__196000155_A); return ok }

func A_arbace_test_eval196000154_fn__196000155_A_Cast(x any) *A_arbace_test_eval196000154_fn__196000155_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000154_fn__196000155_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000154_fn__196000155_A_class)) }; return v }



type A_arbace_test_eval196000158_A struct{ jrt.Object }

func A_arbace_test_eval196000158_A_New() *A_arbace_test_eval196000158_A { t := &A_arbace_test_eval196000158_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000158_A) Ctor() {}

func (t *A_arbace_test_eval196000158_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000158_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000158_A_class }

func (t *A_arbace_test_eval196000158_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000158_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000158_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000158_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000158_A); return ok }

func A_arbace_test_eval196000158_A_Cast(x any) *A_arbace_test_eval196000158_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000158_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000158_A_class)) }; return v }



type A_arbace_test_eval196000158_fn__196000159_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000158_fn__196000159_A) Is_Compiler_AOTR1() {}

var A_arbace_test_eval196000158_fn__196000159_A_fn_class *jrt.Class

var A_arbace_test_eval196000158_fn__196000159_A_init jrt.ClassInit

func A_arbace_test_eval196000158_fn__196000159_A_Init() { if !A_arbace_test_eval196000158_fn__196000159_A_init.Done() { A_arbace_test_eval196000158_fn__196000159_A_init.Run(A_arbace_test_eval196000158_fn__196000159_A_clinit) } }

func A_arbace_test_eval196000158_fn__196000159_A_clinit() { A_arbace_test_eval196000158_fn__196000159_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_207, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_test_eval196000158_fn__196000159_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000158_fn__196000159_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000158_fn__196000159_A_class }

func (t *A_arbace_test_eval196000158_fn__196000159_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000158_fn__196000159_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000158_fn__196000159_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000158_fn__196000159_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000158_fn__196000159_A); return ok }

func A_arbace_test_eval196000158_fn__196000159_A_Cast(x any) *A_arbace_test_eval196000158_fn__196000159_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000158_fn__196000159_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000158_fn__196000159_A_class)) }; return v }



type A_arbace_test_eval196000162_A struct{ jrt.Object }

func A_arbace_test_eval196000162_A_New() *A_arbace_test_eval196000162_A { t := &A_arbace_test_eval196000162_A{}; t.Ctor(); return t }

func (t *A_arbace_test_eval196000162_A) Ctor() {}

func (t *A_arbace_test_eval196000162_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000162_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000162_A_class }

func (t *A_arbace_test_eval196000162_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000162_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000162_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000162_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000162_A); return ok }

func A_arbace_test_eval196000162_A_Cast(x any) *A_arbace_test_eval196000162_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000162_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000162_A_class)) }; return v }



type A_arbace_test_eval196000162_fn__196000163_A struct{ jrt.Object }

func (t *A_arbace_test_eval196000162_fn__196000163_A) Is_Compiler_AOTR1() {}

var A_arbace_test_eval196000162_fn__196000163_A_fn_class *jrt.Class

var A_arbace_test_eval196000162_fn__196000163_A_init jrt.ClassInit

func A_arbace_test_eval196000162_fn__196000163_A_Init() { if !A_arbace_test_eval196000162_fn__196000163_A_init.Done() { A_arbace_test_eval196000162_fn__196000163_A_init.Run(A_arbace_test_eval196000162_fn__196000163_A_clinit) } }

func A_arbace_test_eval196000162_fn__196000163_A_clinit() { A_arbace_test_eval196000162_fn__196000163_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_208, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_test_eval196000162_fn__196000163_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_eval196000162_fn__196000163_A) GetClass__Class() *jrt.Class { return A_arbace_test_eval196000162_fn__196000163_A_class }

func (t *A_arbace_test_eval196000162_fn__196000163_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_eval196000162_fn__196000163_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_eval196000162_fn__196000163_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_eval196000162_fn__196000163_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_eval196000162_fn__196000163_A); return ok }

func A_arbace_test_eval196000162_fn__196000163_A_Cast(x any) *A_arbace_test_eval196000162_fn__196000163_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_eval196000162_fn__196000163_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_eval196000162_fn__196000163_A_class)) }; return v }



type A_arbace_test_file_and_line_A struct{ jrt.Object }

func (t *A_arbace_test_file_and_line_A) Is_Compiler_AOTF2() {}

var A_arbace_test_file_and_line_A_fn_class *jrt.Class

var A_arbace_test_file_and_line_A_init jrt.ClassInit

func A_arbace_test_file_and_line_A_Init() { if !A_arbace_test_file_and_line_A_init.Done() { A_arbace_test_file_and_line_A_init.Run(A_arbace_test_file_and_line_A_clinit) } }

func A_arbace_test_file_and_line_A_clinit() { A_arbace_test_file_and_line_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_209, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_file_and_line_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_file_and_line_A) GetClass__Class() *jrt.Class { return A_arbace_test_file_and_line_A_class }

func (t *A_arbace_test_file_and_line_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_file_and_line_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_file_and_line_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_file_and_line_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_file_and_line_A); return ok }

func A_arbace_test_file_and_line_A_Cast(x any) *A_arbace_test_file_and_line_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_file_and_line_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_file_and_line_A_class)) }; return v }



type A_arbace_test_file_position_A struct{ jrt.Object }

func (t *A_arbace_test_file_position_A) Is_Compiler_AOTF1() {}

var A_arbace_test_file_position_A_fn_class *jrt.Class

var A_arbace_test_file_position_A_init jrt.ClassInit

func A_arbace_test_file_position_A_Init() { if !A_arbace_test_file_position_A_init.Done() { A_arbace_test_file_position_A_init.Run(A_arbace_test_file_position_A_clinit) } }

func A_arbace_test_file_position_A_clinit() { A_arbace_test_file_position_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_210, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_file_position_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_file_position_A) GetClass__Class() *jrt.Class { return A_arbace_test_file_position_A_class }

func (t *A_arbace_test_file_position_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_file_position_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_file_position_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_file_position_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_file_position_A); return ok }

func A_arbace_test_file_position_A_Cast(x any) *A_arbace_test_file_position_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_file_position_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_file_position_A_class)) }; return v }



type A_arbace_test_function_QMARK__A struct{ jrt.Object }

func (t *A_arbace_test_function_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_test_function_QMARK__A_fn_class *jrt.Class

var A_arbace_test_function_QMARK__A_init jrt.ClassInit

func A_arbace_test_function_QMARK__A_Init() { if !A_arbace_test_function_QMARK__A_init.Done() { A_arbace_test_function_QMARK__A_init.Run(A_arbace_test_function_QMARK__A_clinit) } }

func A_arbace_test_function_QMARK__A_clinit() { A_arbace_test_function_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_211, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_function_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_function_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_test_function_QMARK__A_class }

func (t *A_arbace_test_function_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_function_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_function_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_function_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_function_QMARK__A); return ok }

func A_arbace_test_function_QMARK__A_Cast(x any) *A_arbace_test_function_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_function_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_function_QMARK__A_class)) }; return v }



type A_arbace_test_get_possibly_unbound_var_A struct{ jrt.Object }

func (t *A_arbace_test_get_possibly_unbound_var_A) Is_Compiler_AOTF1() {}

var A_arbace_test_get_possibly_unbound_var_A_fn_class *jrt.Class

var A_arbace_test_get_possibly_unbound_var_A_init jrt.ClassInit

func A_arbace_test_get_possibly_unbound_var_A_Init() { if !A_arbace_test_get_possibly_unbound_var_A_init.Done() { A_arbace_test_get_possibly_unbound_var_A_init.Run(A_arbace_test_get_possibly_unbound_var_A_clinit) } }

func A_arbace_test_get_possibly_unbound_var_A_clinit() { A_arbace_test_get_possibly_unbound_var_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_212, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_get_possibly_unbound_var_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_get_possibly_unbound_var_A) GetClass__Class() *jrt.Class { return A_arbace_test_get_possibly_unbound_var_A_class }

func (t *A_arbace_test_get_possibly_unbound_var_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_get_possibly_unbound_var_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_get_possibly_unbound_var_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_get_possibly_unbound_var_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_get_possibly_unbound_var_A); return ok }

func A_arbace_test_get_possibly_unbound_var_A_Cast(x any) *A_arbace_test_get_possibly_unbound_var_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_get_possibly_unbound_var_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_get_possibly_unbound_var_A_class)) }; return v }



type A_arbace_test_inc_report_counter_A struct{ jrt.Object }

func (t *A_arbace_test_inc_report_counter_A) Is_Compiler_AOTF1() {}

var A_arbace_test_inc_report_counter_A_fn_class *jrt.Class

var A_arbace_test_inc_report_counter_A_init jrt.ClassInit

func A_arbace_test_inc_report_counter_A_Init() { if !A_arbace_test_inc_report_counter_A_init.Done() { A_arbace_test_inc_report_counter_A_init.Run(A_arbace_test_inc_report_counter_A_clinit) } }

func A_arbace_test_inc_report_counter_A_clinit() { A_arbace_test_inc_report_counter_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_213, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_inc_report_counter_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_inc_report_counter_A) GetClass__Class() *jrt.Class { return A_arbace_test_inc_report_counter_A_class }

func (t *A_arbace_test_inc_report_counter_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_inc_report_counter_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_inc_report_counter_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_inc_report_counter_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_inc_report_counter_A); return ok }

func A_arbace_test_inc_report_counter_A_Cast(x any) *A_arbace_test_inc_report_counter_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_inc_report_counter_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_inc_report_counter_A_class)) }; return v }



type A_arbace_test_inc_report_counter_fn__196000027_A struct{ jrt.Object; F_name any }

func (t *A_arbace_test_inc_report_counter_fn__196000027_A) Is_Compiler_AOTF0() {}

var A_arbace_test_inc_report_counter_fn__196000027_A_fn_class *jrt.Class

var A_arbace_test_inc_report_counter_fn__196000027_A_init jrt.ClassInit

func A_arbace_test_inc_report_counter_fn__196000027_A_Init() { if !A_arbace_test_inc_report_counter_fn__196000027_A_init.Done() { A_arbace_test_inc_report_counter_fn__196000027_A_init.Run(A_arbace_test_inc_report_counter_fn__196000027_A_clinit) } }

func A_arbace_test_inc_report_counter_fn__196000027_A_clinit() { A_arbace_test_inc_report_counter_fn__196000027_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_214, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_inc_report_counter_fn__196000027_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_inc_report_counter_fn__196000027_A) GetClass__Class() *jrt.Class { return A_arbace_test_inc_report_counter_fn__196000027_A_class }

func (t *A_arbace_test_inc_report_counter_fn__196000027_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_inc_report_counter_fn__196000027_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_inc_report_counter_fn__196000027_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_inc_report_counter_fn__196000027_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_inc_report_counter_fn__196000027_A); return ok }

func A_arbace_test_inc_report_counter_fn__196000027_A_Cast(x any) *A_arbace_test_inc_report_counter_fn__196000027_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_inc_report_counter_fn__196000027_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_inc_report_counter_fn__196000027_A_class)) }; return v }



type A_arbace_test_is_A struct{ jrt.Object }

func (t *A_arbace_test_is_A) Is_Compiler_AOTF4() {}

func (t *A_arbace_test_is_A) Is_Compiler_AOTF3() {}

var A_arbace_test_is_A_fn_class *jrt.Class

var A_arbace_test_is_A_init jrt.ClassInit

func A_arbace_test_is_A_Init() { if !A_arbace_test_is_A_init.Done() { A_arbace_test_is_A_init.Run(A_arbace_test_is_A_clinit) } }

func A_arbace_test_is_A_clinit() { A_arbace_test_is_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_215, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_is_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_is_A) GetClass__Class() *jrt.Class { return A_arbace_test_is_A_class }

func (t *A_arbace_test_is_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_is_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_is_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_is_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_is_A); return ok }

func A_arbace_test_is_A_Cast(x any) *A_arbace_test_is_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_is_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_is_A_class)) }; return v }



type A_arbace_test_join_fixtures_A struct{ jrt.Object }

func (t *A_arbace_test_join_fixtures_A) Is_Compiler_AOTF1() {}

var A_arbace_test_join_fixtures_A_fn_class *jrt.Class

var A_arbace_test_join_fixtures_A_init jrt.ClassInit

func A_arbace_test_join_fixtures_A_Init() { if !A_arbace_test_join_fixtures_A_init.Done() { A_arbace_test_join_fixtures_A_init.Run(A_arbace_test_join_fixtures_A_clinit) } }

func A_arbace_test_join_fixtures_A_clinit() { A_arbace_test_join_fixtures_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_216, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_join_fixtures_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_join_fixtures_A) GetClass__Class() *jrt.Class { return A_arbace_test_join_fixtures_A_class }

func (t *A_arbace_test_join_fixtures_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_join_fixtures_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_join_fixtures_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_join_fixtures_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_join_fixtures_A); return ok }

func A_arbace_test_join_fixtures_A_Cast(x any) *A_arbace_test_join_fixtures_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_join_fixtures_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_join_fixtures_A_class)) }; return v }



type A_arbace_test_run_all_tests_A struct{ jrt.Object }

func (t *A_arbace_test_run_all_tests_A) Is_Compiler_AOTF1() {}

func (t *A_arbace_test_run_all_tests_A) Is_Compiler_AOTF0() {}

var A_arbace_test_run_all_tests_A_fn_class *jrt.Class

var A_arbace_test_run_all_tests_A_init jrt.ClassInit

func A_arbace_test_run_all_tests_A_Init() { if !A_arbace_test_run_all_tests_A_init.Done() { A_arbace_test_run_all_tests_A_init.Run(A_arbace_test_run_all_tests_A_clinit) } }

func A_arbace_test_run_all_tests_A_clinit() { A_arbace_test_run_all_tests_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_217, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_run_all_tests_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_run_all_tests_A) GetClass__Class() *jrt.Class { return A_arbace_test_run_all_tests_A_class }

func (t *A_arbace_test_run_all_tests_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_run_all_tests_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_run_all_tests_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_run_all_tests_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_run_all_tests_A); return ok }

func A_arbace_test_run_all_tests_A_Cast(x any) *A_arbace_test_run_all_tests_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_run_all_tests_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_run_all_tests_A_class)) }; return v }



type A_arbace_test_run_all_tests_fn__196000211_A struct{ jrt.Object; F_re any }

func (t *A_arbace_test_run_all_tests_fn__196000211_A) Is_Compiler_AOTF1() {}

var A_arbace_test_run_all_tests_fn__196000211_A_fn_class *jrt.Class

var A_arbace_test_run_all_tests_fn__196000211_A_init jrt.ClassInit

func A_arbace_test_run_all_tests_fn__196000211_A_Init() { if !A_arbace_test_run_all_tests_fn__196000211_A_init.Done() { A_arbace_test_run_all_tests_fn__196000211_A_init.Run(A_arbace_test_run_all_tests_fn__196000211_A_clinit) } }

func A_arbace_test_run_all_tests_fn__196000211_A_clinit() { A_arbace_test_run_all_tests_fn__196000211_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_218, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_run_all_tests_fn__196000211_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_run_all_tests_fn__196000211_A) GetClass__Class() *jrt.Class { return A_arbace_test_run_all_tests_fn__196000211_A_class }

func (t *A_arbace_test_run_all_tests_fn__196000211_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_run_all_tests_fn__196000211_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_run_all_tests_fn__196000211_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_run_all_tests_fn__196000211_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_run_all_tests_fn__196000211_A); return ok }

func A_arbace_test_run_all_tests_fn__196000211_A_Cast(x any) *A_arbace_test_run_all_tests_fn__196000211_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_run_all_tests_fn__196000211_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_run_all_tests_fn__196000211_A_class)) }; return v }



type A_arbace_test_run_test_A struct{ jrt.Object }

func (t *A_arbace_test_run_test_A) Is_Compiler_AOTF3() {}

var A_arbace_test_run_test_A_fn_class *jrt.Class

var A_arbace_test_run_test_A_init jrt.ClassInit

func A_arbace_test_run_test_A_Init() { if !A_arbace_test_run_test_A_init.Done() { A_arbace_test_run_test_A_init.Run(A_arbace_test_run_test_A_clinit) } }

func A_arbace_test_run_test_A_clinit() { A_arbace_test_run_test_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_219, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_run_test_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_run_test_A) GetClass__Class() *jrt.Class { return A_arbace_test_run_test_A_class }

func (t *A_arbace_test_run_test_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_run_test_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_run_test_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_run_test_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_run_test_A); return ok }

func A_arbace_test_run_test_A_Cast(x any) *A_arbace_test_run_test_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_run_test_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_run_test_A_class)) }; return v }



type A_arbace_test_run_test_var_A struct{ jrt.Object }

func (t *A_arbace_test_run_test_var_A) Is_Compiler_AOTF1() {}

var A_arbace_test_run_test_var_A_fn_class *jrt.Class

var A_arbace_test_run_test_var_A_init jrt.ClassInit

func A_arbace_test_run_test_var_A_Init() { if !A_arbace_test_run_test_var_A_init.Done() { A_arbace_test_run_test_var_A_init.Run(A_arbace_test_run_test_var_A_clinit) } }

func A_arbace_test_run_test_var_A_clinit() { A_arbace_test_run_test_var_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_223, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_run_test_var_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_run_test_var_A) GetClass__Class() *jrt.Class { return A_arbace_test_run_test_var_A_class }

func (t *A_arbace_test_run_test_var_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_run_test_var_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_run_test_var_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_run_test_var_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_run_test_var_A); return ok }

func A_arbace_test_run_test_var_A_Cast(x any) *A_arbace_test_run_test_var_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_run_test_var_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_run_test_var_A_class)) }; return v }



type A_arbace_test_run_tests_A struct{ jrt.Object }

func (t *A_arbace_test_run_tests_A) Is_Compiler_AOTR0() {}

func (t *A_arbace_test_run_tests_A) Is_Compiler_AOTF0() {}

var A_arbace_test_run_tests_A_fn_class *jrt.Class

var A_arbace_test_run_tests_A_init jrt.ClassInit

func A_arbace_test_run_tests_A_Init() { if !A_arbace_test_run_tests_A_init.Done() { A_arbace_test_run_tests_A_init.Run(A_arbace_test_run_tests_A_clinit) } }

func A_arbace_test_run_tests_A_clinit() { A_arbace_test_run_tests_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_224, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_test_run_tests_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_run_tests_A) GetClass__Class() *jrt.Class { return A_arbace_test_run_tests_A_class }

func (t *A_arbace_test_run_tests_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_run_tests_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_run_tests_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_run_tests_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_run_tests_A); return ok }

func A_arbace_test_run_tests_A_Cast(x any) *A_arbace_test_run_tests_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_run_tests_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_run_tests_A_class)) }; return v }



type A_arbace_test_set_test_A struct{ jrt.Object }

func (t *A_arbace_test_set_test_A) Is_Compiler_AOTR3() {}

var A_arbace_test_set_test_A_fn_class *jrt.Class

var A_arbace_test_set_test_A_init jrt.ClassInit

func A_arbace_test_set_test_A_Init() { if !A_arbace_test_set_test_A_init.Done() { A_arbace_test_set_test_A_init.Run(A_arbace_test_set_test_A_clinit) } }

func A_arbace_test_set_test_A_clinit() { A_arbace_test_set_test_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_225, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_test_set_test_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_set_test_A) GetClass__Class() *jrt.Class { return A_arbace_test_set_test_A_class }

func (t *A_arbace_test_set_test_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_set_test_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_set_test_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_set_test_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_set_test_A); return ok }

func A_arbace_test_set_test_A_Cast(x any) *A_arbace_test_set_test_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_set_test_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_set_test_A_class)) }; return v }



type A_arbace_test_stacktrace_file_and_line_A struct{ jrt.Object }

func (t *A_arbace_test_stacktrace_file_and_line_A) Is_Compiler_AOTF1() {}

var A_arbace_test_stacktrace_file_and_line_A_fn_class *jrt.Class

var A_arbace_test_stacktrace_file_and_line_A_init jrt.ClassInit

func A_arbace_test_stacktrace_file_and_line_A_Init() { if !A_arbace_test_stacktrace_file_and_line_A_init.Done() { A_arbace_test_stacktrace_file_and_line_A_init.Run(A_arbace_test_stacktrace_file_and_line_A_clinit) } }

func A_arbace_test_stacktrace_file_and_line_A_clinit() { A_arbace_test_stacktrace_file_and_line_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_226, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_stacktrace_file_and_line_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_stacktrace_file_and_line_A) GetClass__Class() *jrt.Class { return A_arbace_test_stacktrace_file_and_line_A_class }

func (t *A_arbace_test_stacktrace_file_and_line_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_stacktrace_file_and_line_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_stacktrace_file_and_line_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_stacktrace_file_and_line_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_stacktrace_file_and_line_A); return ok }

func A_arbace_test_stacktrace_file_and_line_A_Cast(x any) *A_arbace_test_stacktrace_file_and_line_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_stacktrace_file_and_line_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_stacktrace_file_and_line_A_class)) }; return v }



type A_arbace_test_successful_QMARK__A struct{ jrt.Object }

func (t *A_arbace_test_successful_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_test_successful_QMARK__A_fn_class *jrt.Class

var A_arbace_test_successful_QMARK__A_init jrt.ClassInit

func A_arbace_test_successful_QMARK__A_Init() { if !A_arbace_test_successful_QMARK__A_init.Done() { A_arbace_test_successful_QMARK__A_init.Run(A_arbace_test_successful_QMARK__A_clinit) } }

func A_arbace_test_successful_QMARK__A_clinit() { A_arbace_test_successful_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_227, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_successful_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_successful_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_test_successful_QMARK__A_class }

func (t *A_arbace_test_successful_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_successful_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_successful_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_successful_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_successful_QMARK__A); return ok }

func A_arbace_test_successful_QMARK__A_Cast(x any) *A_arbace_test_successful_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_successful_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_successful_QMARK__A_class)) }; return v }



type A_arbace_test_test_all_vars_A struct{ jrt.Object }

func (t *A_arbace_test_test_all_vars_A) Is_Compiler_AOTF1() {}

var A_arbace_test_test_all_vars_A_fn_class *jrt.Class

var A_arbace_test_test_all_vars_A_init jrt.ClassInit

func A_arbace_test_test_all_vars_A_Init() { if !A_arbace_test_test_all_vars_A_init.Done() { A_arbace_test_test_all_vars_A_init.Run(A_arbace_test_test_all_vars_A_clinit) } }

func A_arbace_test_test_all_vars_A_clinit() { A_arbace_test_test_all_vars_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_228, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_test_all_vars_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_test_all_vars_A) GetClass__Class() *jrt.Class { return A_arbace_test_test_all_vars_A_class }

func (t *A_arbace_test_test_all_vars_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_test_all_vars_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_test_all_vars_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_test_all_vars_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_test_all_vars_A); return ok }

func A_arbace_test_test_all_vars_A_Cast(x any) *A_arbace_test_test_all_vars_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_test_all_vars_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_test_all_vars_A_class)) }; return v }



type A_arbace_test_test_ns_A struct{ jrt.Object }

func (t *A_arbace_test_test_ns_A) Is_Compiler_AOTF1() {}

var A_arbace_test_test_ns_A_fn_class *jrt.Class

var A_arbace_test_test_ns_A_init jrt.ClassInit

func A_arbace_test_test_ns_A_Init() { if !A_arbace_test_test_ns_A_init.Done() { A_arbace_test_test_ns_A_init.Run(A_arbace_test_test_ns_A_clinit) } }

func A_arbace_test_test_ns_A_clinit() { A_arbace_test_test_ns_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_229, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_test_ns_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_test_ns_A) GetClass__Class() *jrt.Class { return A_arbace_test_test_ns_A_class }

func (t *A_arbace_test_test_ns_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_test_ns_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_test_ns_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_test_ns_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_test_ns_A); return ok }

func A_arbace_test_test_ns_A_Cast(x any) *A_arbace_test_test_ns_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_test_ns_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_test_ns_A_class)) }; return v }



type A_arbace_test_test_var_A struct{ jrt.Object }

func (t *A_arbace_test_test_var_A) Is_Compiler_AOTF1() {}

var A_arbace_test_test_var_A_fn_class *jrt.Class

var A_arbace_test_test_var_A_init jrt.ClassInit

func A_arbace_test_test_var_A_Init() { if !A_arbace_test_test_var_A_init.Done() { A_arbace_test_test_var_A_init.Run(A_arbace_test_test_var_A_clinit) } }

func A_arbace_test_test_var_A_clinit() { A_arbace_test_test_var_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_231, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_test_var_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_test_var_A) GetClass__Class() *jrt.Class { return A_arbace_test_test_var_A_class }

func (t *A_arbace_test_test_var_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_test_var_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_test_var_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_test_var_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_test_var_A); return ok }

func A_arbace_test_test_var_A_Cast(x any) *A_arbace_test_test_var_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_test_var_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_test_var_A_class)) }; return v }



type A_arbace_test_test_var_fn__196000173_A struct{ jrt.Object; F_t any }

func (t *A_arbace_test_test_var_fn__196000173_A) Is_Compiler_AOTF0() {}

var A_arbace_test_test_var_fn__196000173_A_fn_class *jrt.Class

var A_arbace_test_test_var_fn__196000173_A_init jrt.ClassInit

func A_arbace_test_test_var_fn__196000173_A_Init() { if !A_arbace_test_test_var_fn__196000173_A_init.Done() { A_arbace_test_test_var_fn__196000173_A_init.Run(A_arbace_test_test_var_fn__196000173_A_clinit) } }

func A_arbace_test_test_var_fn__196000173_A_clinit() { A_arbace_test_test_var_fn__196000173_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_232, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_test_var_fn__196000173_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_test_var_fn__196000173_A) GetClass__Class() *jrt.Class { return A_arbace_test_test_var_fn__196000173_A_class }

func (t *A_arbace_test_test_var_fn__196000173_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_test_var_fn__196000173_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_test_var_fn__196000173_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_test_var_fn__196000173_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_test_var_fn__196000173_A); return ok }

func A_arbace_test_test_var_fn__196000173_A_Cast(x any) *A_arbace_test_test_var_fn__196000173_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_test_var_fn__196000173_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_test_var_fn__196000173_A_class)) }; return v }



type A_arbace_test_test_vars_A struct{ jrt.Object }

func (t *A_arbace_test_test_vars_A) Is_Compiler_AOTF1() {}

var A_arbace_test_test_vars_A_fn_class *jrt.Class

var A_arbace_test_test_vars_A_init jrt.ClassInit

func A_arbace_test_test_vars_A_Init() { if !A_arbace_test_test_vars_A_init.Done() { A_arbace_test_test_vars_A_init.Run(A_arbace_test_test_vars_A_clinit) } }

func A_arbace_test_test_vars_A_clinit() { A_arbace_test_test_vars_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_234, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_test_vars_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_test_vars_A) GetClass__Class() *jrt.Class { return A_arbace_test_test_vars_A_class }

func (t *A_arbace_test_test_vars_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_test_vars_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_test_vars_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_test_vars_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_test_vars_A); return ok }

func A_arbace_test_test_vars_A_Cast(x any) *A_arbace_test_test_vars_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_test_vars_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_test_vars_A_class)) }; return v }



type A_arbace_test_test_vars_fn__196000183_A struct{ jrt.Object; F_vars, F_each_fixture_fn any }

func (t *A_arbace_test_test_vars_fn__196000183_A) Is_Compiler_AOTF0() {}

var A_arbace_test_test_vars_fn__196000183_A_fn_class *jrt.Class

var A_arbace_test_test_vars_fn__196000183_A_init jrt.ClassInit

func A_arbace_test_test_vars_fn__196000183_A_Init() { if !A_arbace_test_test_vars_fn__196000183_A_init.Done() { A_arbace_test_test_vars_fn__196000183_A_init.Run(A_arbace_test_test_vars_fn__196000183_A_clinit) } }

func A_arbace_test_test_vars_fn__196000183_A_clinit() { A_arbace_test_test_vars_fn__196000183_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_235, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_test_vars_fn__196000183_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_test_vars_fn__196000183_A) GetClass__Class() *jrt.Class { return A_arbace_test_test_vars_fn__196000183_A_class }

func (t *A_arbace_test_test_vars_fn__196000183_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_test_vars_fn__196000183_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_test_vars_fn__196000183_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_test_vars_fn__196000183_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_test_vars_fn__196000183_A); return ok }

func A_arbace_test_test_vars_fn__196000183_A_Cast(x any) *A_arbace_test_test_vars_fn__196000183_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_test_vars_fn__196000183_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_test_vars_fn__196000183_A_class)) }; return v }



type A_arbace_test_test_vars_fn__196000183_fn__196000188_A struct{ jrt.Object; F_v any }

func (t *A_arbace_test_test_vars_fn__196000183_fn__196000188_A) Is_Compiler_AOTF0() {}

var A_arbace_test_test_vars_fn__196000183_fn__196000188_A_fn_class *jrt.Class

var A_arbace_test_test_vars_fn__196000183_fn__196000188_A_init jrt.ClassInit

func A_arbace_test_test_vars_fn__196000183_fn__196000188_A_Init() { if !A_arbace_test_test_vars_fn__196000183_fn__196000188_A_init.Done() { A_arbace_test_test_vars_fn__196000183_fn__196000188_A_init.Run(A_arbace_test_test_vars_fn__196000183_fn__196000188_A_clinit) } }

func A_arbace_test_test_vars_fn__196000183_fn__196000188_A_clinit() { A_arbace_test_test_vars_fn__196000183_fn__196000188_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_236, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_test_vars_fn__196000183_fn__196000188_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_test_vars_fn__196000183_fn__196000188_A) GetClass__Class() *jrt.Class { return A_arbace_test_test_vars_fn__196000183_fn__196000188_A_class }

func (t *A_arbace_test_test_vars_fn__196000183_fn__196000188_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_test_vars_fn__196000183_fn__196000188_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_test_vars_fn__196000183_fn__196000188_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_test_vars_fn__196000183_fn__196000188_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_test_vars_fn__196000183_fn__196000188_A); return ok }

func A_arbace_test_test_vars_fn__196000183_fn__196000188_A_Cast(x any) *A_arbace_test_test_vars_fn__196000183_fn__196000188_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_test_vars_fn__196000183_fn__196000188_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_test_vars_fn__196000183_fn__196000188_A_class)) }; return v }



type A_arbace_test_test_vars_fn__196000183_fn__196000190_A struct{ jrt.Object; F_v any }

func (t *A_arbace_test_test_vars_fn__196000183_fn__196000190_A) Is_Compiler_AOTF0() {}

var A_arbace_test_test_vars_fn__196000183_fn__196000190_A_fn_class *jrt.Class

var A_arbace_test_test_vars_fn__196000183_fn__196000190_A_init jrt.ClassInit

func A_arbace_test_test_vars_fn__196000183_fn__196000190_A_Init() { if !A_arbace_test_test_vars_fn__196000183_fn__196000190_A_init.Done() { A_arbace_test_test_vars_fn__196000183_fn__196000190_A_init.Run(A_arbace_test_test_vars_fn__196000183_fn__196000190_A_clinit) } }

func A_arbace_test_test_vars_fn__196000183_fn__196000190_A_clinit() { A_arbace_test_test_vars_fn__196000183_fn__196000190_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_237, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_test_vars_fn__196000183_fn__196000190_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_test_vars_fn__196000183_fn__196000190_A) GetClass__Class() *jrt.Class { return A_arbace_test_test_vars_fn__196000183_fn__196000190_A_class }

func (t *A_arbace_test_test_vars_fn__196000183_fn__196000190_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_test_vars_fn__196000183_fn__196000190_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_test_vars_fn__196000183_fn__196000190_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_test_vars_fn__196000183_fn__196000190_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_test_vars_fn__196000183_fn__196000190_A); return ok }

func A_arbace_test_test_vars_fn__196000183_fn__196000190_A_Cast(x any) *A_arbace_test_test_vars_fn__196000183_fn__196000190_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_test_vars_fn__196000183_fn__196000190_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_test_vars_fn__196000183_fn__196000190_A_class)) }; return v }



type A_arbace_test_test_vars_fn__196000196_A struct{ jrt.Object; F_vars, F_each_fixture_fn any }

func (t *A_arbace_test_test_vars_fn__196000196_A) Is_Compiler_AOTF0() {}

var A_arbace_test_test_vars_fn__196000196_A_fn_class *jrt.Class

var A_arbace_test_test_vars_fn__196000196_A_init jrt.ClassInit

func A_arbace_test_test_vars_fn__196000196_A_Init() { if !A_arbace_test_test_vars_fn__196000196_A_init.Done() { A_arbace_test_test_vars_fn__196000196_A_init.Run(A_arbace_test_test_vars_fn__196000196_A_clinit) } }

func A_arbace_test_test_vars_fn__196000196_A_clinit() { A_arbace_test_test_vars_fn__196000196_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_238, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_test_vars_fn__196000196_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_test_vars_fn__196000196_A) GetClass__Class() *jrt.Class { return A_arbace_test_test_vars_fn__196000196_A_class }

func (t *A_arbace_test_test_vars_fn__196000196_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_test_vars_fn__196000196_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_test_vars_fn__196000196_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_test_vars_fn__196000196_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_test_vars_fn__196000196_A); return ok }

func A_arbace_test_test_vars_fn__196000196_A_Cast(x any) *A_arbace_test_test_vars_fn__196000196_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_test_vars_fn__196000196_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_test_vars_fn__196000196_A_class)) }; return v }



type A_arbace_test_test_vars_fn__196000196_fn__196000201_A struct{ jrt.Object; F_v any }

func (t *A_arbace_test_test_vars_fn__196000196_fn__196000201_A) Is_Compiler_AOTF0() {}

var A_arbace_test_test_vars_fn__196000196_fn__196000201_A_fn_class *jrt.Class

var A_arbace_test_test_vars_fn__196000196_fn__196000201_A_init jrt.ClassInit

func A_arbace_test_test_vars_fn__196000196_fn__196000201_A_Init() { if !A_arbace_test_test_vars_fn__196000196_fn__196000201_A_init.Done() { A_arbace_test_test_vars_fn__196000196_fn__196000201_A_init.Run(A_arbace_test_test_vars_fn__196000196_fn__196000201_A_clinit) } }

func A_arbace_test_test_vars_fn__196000196_fn__196000201_A_clinit() { A_arbace_test_test_vars_fn__196000196_fn__196000201_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_239, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_test_vars_fn__196000196_fn__196000201_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_test_vars_fn__196000196_fn__196000201_A) GetClass__Class() *jrt.Class { return A_arbace_test_test_vars_fn__196000196_fn__196000201_A_class }

func (t *A_arbace_test_test_vars_fn__196000196_fn__196000201_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_test_vars_fn__196000196_fn__196000201_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_test_vars_fn__196000196_fn__196000201_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_test_vars_fn__196000196_fn__196000201_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_test_vars_fn__196000196_fn__196000201_A); return ok }

func A_arbace_test_test_vars_fn__196000196_fn__196000201_A_Cast(x any) *A_arbace_test_test_vars_fn__196000196_fn__196000201_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_test_vars_fn__196000196_fn__196000201_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_test_vars_fn__196000196_fn__196000201_A_class)) }; return v }



type A_arbace_test_test_vars_fn__196000196_fn__196000203_A struct{ jrt.Object; F_v any }

func (t *A_arbace_test_test_vars_fn__196000196_fn__196000203_A) Is_Compiler_AOTF0() {}

var A_arbace_test_test_vars_fn__196000196_fn__196000203_A_fn_class *jrt.Class

var A_arbace_test_test_vars_fn__196000196_fn__196000203_A_init jrt.ClassInit

func A_arbace_test_test_vars_fn__196000196_fn__196000203_A_Init() { if !A_arbace_test_test_vars_fn__196000196_fn__196000203_A_init.Done() { A_arbace_test_test_vars_fn__196000196_fn__196000203_A_init.Run(A_arbace_test_test_vars_fn__196000196_fn__196000203_A_clinit) } }

func A_arbace_test_test_vars_fn__196000196_fn__196000203_A_clinit() { A_arbace_test_test_vars_fn__196000196_fn__196000203_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_240, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_test_vars_fn__196000196_fn__196000203_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_test_vars_fn__196000196_fn__196000203_A) GetClass__Class() *jrt.Class { return A_arbace_test_test_vars_fn__196000196_fn__196000203_A_class }

func (t *A_arbace_test_test_vars_fn__196000196_fn__196000203_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_test_vars_fn__196000196_fn__196000203_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_test_vars_fn__196000196_fn__196000203_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_test_vars_fn__196000196_fn__196000203_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_test_vars_fn__196000196_fn__196000203_A); return ok }

func A_arbace_test_test_vars_fn__196000196_fn__196000203_A_Cast(x any) *A_arbace_test_test_vars_fn__196000196_fn__196000203_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_test_vars_fn__196000196_fn__196000203_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_test_vars_fn__196000196_fn__196000203_A_class)) }; return v }



type A_arbace_test_testing_A struct{ jrt.Object }

func (t *A_arbace_test_testing_A) Is_Compiler_AOTR3() {}

var A_arbace_test_testing_A_fn_class *jrt.Class

var A_arbace_test_testing_A_init jrt.ClassInit

func A_arbace_test_testing_A_Init() { if !A_arbace_test_testing_A_init.Done() { A_arbace_test_testing_A_init.Run(A_arbace_test_testing_A_clinit) } }

func A_arbace_test_testing_A_clinit() { A_arbace_test_testing_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_241, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_test_testing_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_testing_A) GetClass__Class() *jrt.Class { return A_arbace_test_testing_A_class }

func (t *A_arbace_test_testing_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_testing_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_testing_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_testing_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_testing_A); return ok }

func A_arbace_test_testing_A_Cast(x any) *A_arbace_test_testing_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_testing_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_testing_A_class)) }; return v }



type A_arbace_test_testing_contexts_str_A struct{ jrt.Object }

func (t *A_arbace_test_testing_contexts_str_A) Is_Compiler_AOTF0() {}

var A_arbace_test_testing_contexts_str_A_fn_class *jrt.Class

var A_arbace_test_testing_contexts_str_A_init jrt.ClassInit

func A_arbace_test_testing_contexts_str_A_Init() { if !A_arbace_test_testing_contexts_str_A_init.Done() { A_arbace_test_testing_contexts_str_A_init.Run(A_arbace_test_testing_contexts_str_A_clinit) } }

func A_arbace_test_testing_contexts_str_A_clinit() { A_arbace_test_testing_contexts_str_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_242, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_testing_contexts_str_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_testing_contexts_str_A) GetClass__Class() *jrt.Class { return A_arbace_test_testing_contexts_str_A_class }

func (t *A_arbace_test_testing_contexts_str_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_testing_contexts_str_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_testing_contexts_str_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_testing_contexts_str_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_testing_contexts_str_A); return ok }

func A_arbace_test_testing_contexts_str_A_Cast(x any) *A_arbace_test_testing_contexts_str_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_testing_contexts_str_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_testing_contexts_str_A_class)) }; return v }



type A_arbace_test_testing_vars_str_A struct{ jrt.Object }

func (t *A_arbace_test_testing_vars_str_A) Is_Compiler_AOTF1() {}

var A_arbace_test_testing_vars_str_A_fn_class *jrt.Class

var A_arbace_test_testing_vars_str_A_init jrt.ClassInit

func A_arbace_test_testing_vars_str_A_Init() { if !A_arbace_test_testing_vars_str_A_init.Done() { A_arbace_test_testing_vars_str_A_init.Run(A_arbace_test_testing_vars_str_A_clinit) } }

func A_arbace_test_testing_vars_str_A_clinit() { A_arbace_test_testing_vars_str_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_244, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_testing_vars_str_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_testing_vars_str_A) GetClass__Class() *jrt.Class { return A_arbace_test_testing_vars_str_A_class }

func (t *A_arbace_test_testing_vars_str_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_testing_vars_str_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_testing_vars_str_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_testing_vars_str_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_testing_vars_str_A); return ok }

func A_arbace_test_testing_vars_str_A_Cast(x any) *A_arbace_test_testing_vars_str_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_testing_vars_str_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_testing_vars_str_A_class)) }; return v }



type A_arbace_test_testing_vars_str_fn__196000023_A struct{ jrt.Object }

func (t *A_arbace_test_testing_vars_str_fn__196000023_A) Is_Compiler_AOTF1() {}

var A_arbace_test_testing_vars_str_fn__196000023_A_fn_class *jrt.Class

var A_arbace_test_testing_vars_str_fn__196000023_A_init jrt.ClassInit

func A_arbace_test_testing_vars_str_fn__196000023_A_Init() { if !A_arbace_test_testing_vars_str_fn__196000023_A_init.Done() { A_arbace_test_testing_vars_str_fn__196000023_A_init.Run(A_arbace_test_testing_vars_str_fn__196000023_A_clinit) } }

func A_arbace_test_testing_vars_str_fn__196000023_A_clinit() { A_arbace_test_testing_vars_str_fn__196000023_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_248, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_testing_vars_str_fn__196000023_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_testing_vars_str_fn__196000023_A) GetClass__Class() *jrt.Class { return A_arbace_test_testing_vars_str_fn__196000023_A_class }

func (t *A_arbace_test_testing_vars_str_fn__196000023_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_testing_vars_str_fn__196000023_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_testing_vars_str_fn__196000023_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_testing_vars_str_fn__196000023_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_testing_vars_str_fn__196000023_A); return ok }

func A_arbace_test_testing_vars_str_fn__196000023_A_Cast(x any) *A_arbace_test_testing_vars_str_fn__196000023_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_testing_vars_str_fn__196000023_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_testing_vars_str_fn__196000023_A_class)) }; return v }



type A_arbace_test_try_expr_A struct{ jrt.Object }

func (t *A_arbace_test_try_expr_A) Is_Compiler_AOTF4() {}

var A_arbace_test_try_expr_A_fn_class *jrt.Class

var A_arbace_test_try_expr_A_init jrt.ClassInit

func A_arbace_test_try_expr_A_Init() { if !A_arbace_test_try_expr_A_init.Done() { A_arbace_test_try_expr_A_init.Run(A_arbace_test_try_expr_A_clinit) } }

func A_arbace_test_try_expr_A_clinit() { A_arbace_test_try_expr_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_249, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_try_expr_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_try_expr_A) GetClass__Class() *jrt.Class { return A_arbace_test_try_expr_A_class }

func (t *A_arbace_test_try_expr_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_try_expr_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_try_expr_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_try_expr_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_try_expr_A); return ok }

func A_arbace_test_try_expr_A_Cast(x any) *A_arbace_test_try_expr_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_try_expr_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_try_expr_A_class)) }; return v }



type A_arbace_test_with_test_A struct{ jrt.Object }

func (t *A_arbace_test_with_test_A) Is_Compiler_AOTR3() {}

var A_arbace_test_with_test_A_fn_class *jrt.Class

var A_arbace_test_with_test_A_init jrt.ClassInit

func A_arbace_test_with_test_A_Init() { if !A_arbace_test_with_test_A_init.Done() { A_arbace_test_with_test_A_init.Run(A_arbace_test_with_test_A_clinit) } }

func A_arbace_test_with_test_A_clinit() { A_arbace_test_with_test_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_250, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_test_with_test_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_with_test_A) GetClass__Class() *jrt.Class { return A_arbace_test_with_test_A_class }

func (t *A_arbace_test_with_test_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_with_test_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_with_test_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_with_test_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_with_test_A); return ok }

func A_arbace_test_with_test_A_Cast(x any) *A_arbace_test_with_test_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_with_test_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_with_test_A_class)) }; return v }



type A_arbace_test_with_test_out_A struct{ jrt.Object }

func (t *A_arbace_test_with_test_out_A) Is_Compiler_AOTR2() {}

var A_arbace_test_with_test_out_A_fn_class *jrt.Class

var A_arbace_test_with_test_out_A_init jrt.ClassInit

func A_arbace_test_with_test_out_A_Init() { if !A_arbace_test_with_test_out_A_init.Done() { A_arbace_test_with_test_out_A_init.Run(A_arbace_test_with_test_out_A_clinit) } }

func A_arbace_test_with_test_out_A_clinit() { A_arbace_test_with_test_out_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_251, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_test_with_test_out_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_with_test_out_A) GetClass__Class() *jrt.Class { return A_arbace_test_with_test_out_A_class }

func (t *A_arbace_test_with_test_out_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_with_test_out_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_with_test_out_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_with_test_out_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_with_test_out_A); return ok }

func A_arbace_test_with_test_out_A_Cast(x any) *A_arbace_test_with_test_out_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_with_test_out_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_with_test_out_A_class)) }; return v }
