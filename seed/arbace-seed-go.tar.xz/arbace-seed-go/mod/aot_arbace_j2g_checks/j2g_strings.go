//line j2g_strings.ae:1
package aot_arbace_j2g_checks

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn22,arbace.classes.analyzeyn1,ayn16,arbace.j2g.modelyn1,myn14,arbace.j2g.jrtyn3,jrtyn22,arbace.classes.opcodesyn7,Opcodesyn11,arbace.corekn3,dockn3,tagyn1,*kn4,elsekn3,pkgkn3,jrtkn5,funcskn4,varskn6,constskn5,typeskn7,methodskn4,namekn7,sourceskn5,fileskn5,flagskn4,desckn6,methodkn9,hidden-byv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,v11,arbace.core5,referR11,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn17,arbace.j2g.checksm2,R12,s233,j2g's checks of its output (J2G-SPEC §4.4, §8.3): duplicate Go names in a package or a\n  method set, package-private methods that Go would let a subclass in another Java package\n  override, and the report of candidate two-word races.v11,arbace.core7,symbol?v11,arbace.core4,namev11,arbace.core5,firstv11,arbace.core6,filterv11,arbace.core7,vector?v11,arbace.core4,dropl2,R13,v11,arbace.core4,seq?R14,v17,arbace.j2g.checks8,sym-namev11,arbace.core6,secondR15,v11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core3,notS2,s1,_s4,initv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restS2,s1,_s4,initv11,arbace.core4,consv11,arbace.core4,restv17,arbace.j2g.checks9,recv-typeR16,v11,arbace.core6,concatv11,arbace.core5,applyv16,arbace.j2g.model8,par-mapvv16,arbace.j2g.model4,jobsv11,arbace.core4,mapvv17,arbace.j2g.checks14,declared-namesv13,arbace.string12,starts-with?S2,s1,_s4,initR17,S2,s1,_s4,initR18,R19,R20,v11,arbace.core4,keysR21,R22,v11,arbace.core8,group-byv11,arbace.core7,re-findp66,_(amd64|arm64|386|arm|riscv64|ppc64le|s390x|loong64|mips64le)\\.ae$v11,arbace.core3,mapv11,arbace.core4,compv11,arbace.core4,somev11,arbace.core4,nil?v11,arbace.core4,not=v11,arbace.core8,distinctv11,arbace.core3,vecR23,R24,v11,arbace.core4,sortv11,arbace.core7,sort-byv11,arbace.core3,strv11,arbace.core3,keyv11,arbace.core3,valR25,v11,arbace.core4,subsl0,v11,arbace.core6,reducev11,arbace.core6,updatev11,arbace.core4,fnilv16,arbace.j2g.model16,superclass-chainv22,arbace.classes.analyze4,declv16,arbace.j2g.model10,interface?v16,arbace.j2g.model7,static?v16,arbace.j2g.model8,private?R26,v17,arbace.j2g.checks4,jpkgR27,R28,R29,v11,arbace.core4,intov11,arbace.core10,sorted-mapv13,arbace.string4,joinv11,arbace.core4,peekv11,arbace.core6,subvecl4,")

var Lit_1 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$fn__1323000074")

var Lit_2 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000084__1323000090")

var Lit_3 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$arch__1323000132")

var Lit_4 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$dup_QMARK___1323000134")

var Lit_5 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000136__1323000140")

var Lit_6 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$fn__1323000164")

var Lit_7 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$fn__1323000074$fn__1323000081")

var Lit_8 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000084__1323000090$fn__1323000091")

var Lit_9 *jrt.String = jrt.Intern("standin_")

var Lit_10 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000084__1323000090$fn__1323000091$iter__1323000086__1323000095")

var Lit_11 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000084__1323000090$fn__1323000091$iter__1323000101__1323000105")

var Lit_12 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000084__1323000090$fn__1323000091$iter__1323000111__1323000117")

var Lit_13 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000084__1323000090$fn__1323000091$iter__1323000086__1323000095$fn__1323000096")

var Lit_14 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000084__1323000090$fn__1323000091$iter__1323000086__1323000095$fn__1323000096$fn__1323000097")

var Lit_15 *jrt.String = jrt.Intern("jrt/")

var Lit_16 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000084__1323000090$fn__1323000091$iter__1323000101__1323000105$fn__1323000106")

var Lit_17 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000084__1323000090$fn__1323000091$iter__1323000101__1323000105$fn__1323000106$fn__1323000107")

var Lit_18 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000084__1323000090$fn__1323000091$iter__1323000111__1323000117$fn__1323000118")

var Lit_19 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000084__1323000090$fn__1323000091$iter__1323000111__1323000117$fn__1323000118$iter__1323000113__1323000122")

var Lit_20 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000084__1323000090$fn__1323000091$iter__1323000111__1323000117$fn__1323000118$iter__1323000113__1323000122$fn__1323000123")

var Lit_21 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000084__1323000090$fn__1323000091$iter__1323000111__1323000117$fn__1323000118$iter__1323000113__1323000122$fn__1323000123$fn__1323000124")

var Lit_22 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000136__1323000140$fn__1323000141")

var Lit_23 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions$iter__1323000136__1323000140$fn__1323000141$fn__1323000142")

var Lit_24 *jrt.String = jrt.Intern("(")

var Lit_25 *jrt.String = jrt.Intern(").")

var Lit_26 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020")

var Lit_27 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021")

var Lit_28 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021$iter__1323000016__1323000022")

var Lit_29 *jrt.String = jrt.Intern("method")

var Lit_30 *jrt.String = jrt.Intern("type")

var Lit_31 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021$iter__1323000029__1323000033")

var Lit_32 *jrt.String = jrt.Intern("const")

var Lit_33 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021$iter__1323000039__1323000043")

var Lit_34 *jrt.String = jrt.Intern("func")

var Lit_35 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021$iter__1323000049__1323000053")

var Lit_36 *jrt.String = jrt.Intern("var")

var Lit_37 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021$iter__1323000059__1323000063")

var Lit_38 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021$iter__1323000016__1323000022$fn__1323000023")

var Lit_39 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021$iter__1323000016__1323000022$fn__1323000023$fn__1323000024")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021$iter__1323000029__1323000033$fn__1323000034")

var Lit_41 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021$iter__1323000029__1323000033$fn__1323000034$fn__1323000035")

var Lit_42 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021$iter__1323000039__1323000043$fn__1323000044")

var Lit_43 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021$iter__1323000039__1323000043$fn__1323000044$fn__1323000045")

var Lit_44 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021$iter__1323000049__1323000053$fn__1323000054")

var Lit_45 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021$iter__1323000049__1323000053$fn__1323000054$fn__1323000055")

var Lit_46 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021$iter__1323000059__1323000063$fn__1323000064")

var Lit_47 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names$iter__1323000014__1323000020$fn__1323000021$iter__1323000059__1323000063$fn__1323000064$fn__1323000065")

var Lit_48 *jrt.String = jrt.Intern("/")

var Lit_49 *jrt.String = jrt.Intern("")

var Lit_50 *jrt.String = jrt.Intern("arbace.j2g.checks$package_private_overrides$fn__1323000170")

var Lit_51 *jrt.String = jrt.Intern("arbace.j2g.checks$package_private_overrides$iter__1323000174__1323000184")

var Lit_52 *jrt.String = jrt.Intern("arbace.j2g.checks$package_private_overrides$fn__1323000170$fn__1323000171")

var Lit_53 *jrt.String = jrt.Intern("arbace.j2g.checks$package_private_overrides$iter__1323000174__1323000184$fn__1323000185")

var Lit_54 *jrt.String = jrt.Intern("arbace.j2g.checks$package_private_overrides$iter__1323000174__1323000184$fn__1323000185$iter__1323000176__1323000186")

var Lit_55 *jrt.String = jrt.Intern("arbace.j2g.checks$package_private_overrides$iter__1323000174__1323000184$fn__1323000185$iter__1323000176__1323000186$fn__1323000187")

var Lit_56 *jrt.String = jrt.Intern("<init>")

var Lit_57 *jrt.String = jrt.Intern("arbace.j2g.checks$package_private_overrides$iter__1323000174__1323000184$fn__1323000185$iter__1323000176__1323000186$fn__1323000187$iter__1323000178__1323000188")

var Lit_58 *jrt.String = jrt.Intern("arbace.j2g.checks$package_private_overrides$iter__1323000174__1323000184$fn__1323000185$iter__1323000176__1323000186$fn__1323000187$iter__1323000178__1323000188$fn__1323000189")

var Lit_59 *jrt.String = jrt.Intern("arbace.j2g.checks$package_private_overrides$iter__1323000174__1323000184$fn__1323000185$iter__1323000176__1323000186$fn__1323000187$iter__1323000178__1323000188$fn__1323000189$iter__1323000180__1323000190")

var Lit_60 *jrt.String = jrt.Intern("arbace.j2g.checks$package_private_overrides$iter__1323000174__1323000184$fn__1323000185$iter__1323000176__1323000186$fn__1323000187$iter__1323000178__1323000188$fn__1323000189$iter__1323000180__1323000190$fn__1323000191")

var Lit_61 *jrt.String = jrt.Intern("arbace.j2g.checks$package_private_overrides$iter__1323000174__1323000184$fn__1323000185$iter__1323000176__1323000186$fn__1323000187$iter__1323000178__1323000188$fn__1323000189$iter__1323000180__1323000190$fn__1323000191$fn__1323000192")

var Lit_62 *jrt.String = jrt.Intern(".")

var Lit_63 *jrt.String = jrt.Intern("arbace.j2g.checks$race_report$iter__1323000204__1323000208")

var Lit_64 *jrt.String = jrt.Intern("arbace.j2g.checks$race_report$iter__1323000204__1323000208$fn__1323000209")

var Lit_65 *jrt.String = jrt.Intern("arbace.j2g.checks$race_report$iter__1323000204__1323000208$fn__1323000209$fn__1323000210")

var Lit_66 *jrt.String = jrt.Intern("arbace.j2g.checks$race_report$iter__1323000204__1323000208$fn__1323000209$iter__1323000242__1323000246")

var Lit_67 *jrt.String = jrt.Intern("arbace.j2g.checks$race_report$iter__1323000204__1323000208$fn__1323000209$fn__1323000264")

var Lit_68 *jrt.String = jrt.Intern("arbace.j2g.checks$race_report$iter__1323000204__1323000208$fn__1323000209$fn__1323000210$iter__1323000214__1323000218")

var Lit_69 *jrt.String = jrt.Intern("arbace.j2g.checks$race_report$iter__1323000204__1323000208$fn__1323000209$fn__1323000210$fn__1323000236")

var Lit_70 *jrt.String = jrt.Intern("arbace.j2g.checks$race_report$iter__1323000204__1323000208$fn__1323000209$fn__1323000210$iter__1323000214__1323000218$fn__1323000219")

var Lit_71 *jrt.String = jrt.Intern("arbace.j2g.checks$race_report$iter__1323000204__1323000208$fn__1323000209$fn__1323000210$iter__1323000214__1323000218$fn__1323000219$fn__1323000220")

var Lit_72 *jrt.String = jrt.Intern(" ")

var Lit_73 *jrt.String = jrt.Intern(" written in ")

var Lit_74 *jrt.String = jrt.Intern("static ")

var Lit_75 *jrt.String = jrt.Intern(", ")

var Lit_76 *jrt.String = jrt.Intern("arbace.j2g.checks$race_report$iter__1323000204__1323000208$fn__1323000209$iter__1323000242__1323000246$fn__1323000247")

var Lit_77 *jrt.String = jrt.Intern("arbace.j2g.checks$race_report$iter__1323000204__1323000208$fn__1323000209$iter__1323000242__1323000246$fn__1323000247$fn__1323000248")

var Lit_78 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn1,xkn4,linekn6,columnkn4,fileyn1,fyn5,formsyn5,filesyn4,scanyn1,nyn1,Tyn5,racesv11,arbace.core5,in-nsMyn17,arbace.j2g.checksm2,R0,s233,j2g's checks of its output (J2G-SPEC §4.4, §8.3): duplicate Go names in a package or a\n  method set, package-private methods that Go would let a subclass in another Java package\n  override, and the report of candidate two-word races.m2,R0,s233,j2g's checks of its output (J2G-SPEC §4.4, §8.3): duplicate Go names in a package or a\n  method set, package-private methods that Go would let a subclass in another Java package\n  override, and the report of candidate two-word races.R1,v17,arbace.j2g.checks8,sym-namem10,R2,TR3,L1,V1,R4,R5,i11,R6,i1,R7,s20,arbace/j2g/checks.aev17,arbace.j2g.checks9,recv-typem12,R2,TR3,L1,V1,R8,R0,s63,The receiver's type name of a go/method form: T for (* T) or T.R5,i13,R6,i1,R7,s20,arbace/j2g/checks.aev17,arbace.j2g.checks14,declared-namesm10,R3,L1,V1,R9,R0,s157,[kind name] of the Go declarations of forms: [:pkg n] for package-level names, [T m] for\n  a method m of type T. init functions and blank names are left out.R5,i22,R6,i1,R7,s20,arbace/j2g/checks.aev17,arbace.j2g.checks10,collisionsm10,R3,L1,V2,R10,R11,R0,s216,Duplicate Go names among the generated files (files: {[pkg file] forms}) and jrt's\n  hand-written declarations (scan; the stand-in files left out, as translated classes replace\n  them): [{:pkg :name :sources [...]}].R5,i40,R6,i1,R7,s20,arbace/j2g/checks.aev17,arbace.j2g.checks4,jpkgm10,R2,TR3,L1,V1,R12,R5,i69,R6,i1,R7,s20,arbace/j2g/checks.aev17,arbace.j2g.checks25,package-private-overridesm10,R3,L1,V1,R13,R0,s265,Package-private instance methods of translated classes that a translated subclass in\n  another Java package declares again with the same name and descriptor: Java does not\n  override them (JVMS 5.4.5), Go's method sets would (J2G-SPEC §4.4). [{:method :hidden-by}].R5,i71,R6,i1,R7,s20,arbace/j2g/checks.aev17,arbace.j2g.checks11,race-reportm10,R3,L1,V1,R14,R0,s70,The candidate two-word races (§8.3) as {class [\"field (writers...)\"]}.R5,i93,R6,i1,R7,s20,arbace/j2g/checks.ae")

var Lit_79 *jrt.String = jrt.Intern("arbace.j2g.checks$eval1323000004$loading__1927001464__auto____1323000005")

var Lit_80 *jrt.String = jrt.Intern("arbace.j2g.checks$eval1323000008$fn__1323000009")

var Lit_81 *jrt.String = jrt.Intern("arbace.j2g.checks$sym_name")

var Lit_82 *jrt.String = jrt.Intern("arbace.j2g.checks$recv_type")

var Lit_83 *jrt.String = jrt.Intern("arbace.j2g.checks$declared_names")

var Lit_84 *jrt.String = jrt.Intern("arbace.j2g.checks$collisions")

var Lit_85 *jrt.String = jrt.Intern("arbace.j2g.checks$jpkg")

var Lit_86 *jrt.String = jrt.Intern("arbace.j2g.checks$package_private_overrides")

var Lit_87 *jrt.String = jrt.Intern("arbace.j2g.checks$race_report")
