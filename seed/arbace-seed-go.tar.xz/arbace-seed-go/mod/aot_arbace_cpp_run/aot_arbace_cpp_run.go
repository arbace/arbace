//line aot_arbace_cpp_run.ae:1
package aot_arbace_cpp_run

import (
	"arbace/aot_arbace_c_build"
	"arbace/aot_arbace_c_musl"
	"arbace/aot_arbace_c_run"
	"arbace/aot_arbace_c_runtime"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_cpp_lower"
	"arbace/aot_arbace_repr_c"
	"arbace/aot_arbace_repr_c_host"
	"arbace/aot_arbace_repr_llvm"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_cpp_run_eval97000004_loading__1927001464__auto____97000005_A_New() *A_arbace_cpp_run_eval97000004_loading__1927001464__auto____97000005_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_eval97000004_loading__1927001464__auto____97000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_cpp_run_eval97000004_loading__1927001464__auto____97000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_cpp_run_eval97000004_loading__1927001464__auto____97000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_cpp_run_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_cpp_run_A_const_1); lang.IFn_Cast(A_arbace_cpp_run_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O__O(A_arbace_cpp_run_A_const_3, A_arbace_cpp_run_A_const_4, A_arbace_cpp_run_A_const_5, A_arbace_cpp_run_A_const_6, A_arbace_cpp_run_A_const_7, A_arbace_cpp_run_A_const_8, A_arbace_cpp_run_A_const_9, A_arbace_cpp_run_A_const_10, A_arbace_cpp_run_A_const_11); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_101)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_102)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_103)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_104)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_105)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_106)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_cpp_run_eval97000008_fn__97000009_A_New() *A_arbace_cpp_run_eval97000008_fn__97000009_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_eval97000008_fn__97000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_cpp_run_eval97000008_fn__97000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_cpp_run_eval97000008_fn__97000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_12.GetRawRoot__O()); var tmp2 any; var root_23 any = A_arbace_cpp_run_A_const_13.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = A_arbace_cpp_run_A_const_14; if linked_24 == nil { tmp2 = ifn_25.Invoke_O__O(arg_26) } else { tmp2 = linked_24.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_23, arg_26) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_cpp_run_A_const_15.GetRawRoot__O(), A_arbace_cpp_run_A_const_16) }



































func A_arbace_cpp_run_fn__97000014_A_New() *A_arbace_cpp_run_fn__97000014_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_fn__97000014_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_cpp_run_fn__97000014_A) Ctor() {}
//line :37:1
func (t *A_arbace_cpp_run_fn__97000014_A) Invoke_O__O(self any) any { var rmw__1 any; var fnbody__28 any = A_arbace_cpp_run_fn__97000014_rmw__97000015_A_New(); var tmp1 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_cpp_run_fn__97000014_rmw__97000015_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_107, false, nil); A_arbace_cpp_run_fn__97000014_rmw__97000015_A_fn_class = fncls__27d; tmp1 = fncls__27d } else { tmp1 = fncls__27 }; rmw__1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp1, nil); var root_29 any =



	A_arbace_cpp_run_A_const_17.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = A_arbace_cpp_run_A_const_18; var arg_33 any; var iter__1927001039__auto____2 any; var fnbody__124 any = A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_A_New_O(rmw__1); var tmp2 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_A_fn_class; if












	fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_108, false, fnbody__124); A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_A_fn_class = fncls__123d; tmp2 = fncls__123d } else { tmp2 = fncls__123 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp2, nil); arg_33 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(A_arbace_cpp_run_A_const_31); if /*line :41:1*/ linked_30 == nil { return ifn_31.Invoke_O_O__O(arg_32, arg_33) } else { return linked_30.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_29, arg_32, arg_33) } }
//line :37:1
func A_arbace_cpp_run_fn__97000014_rmw__97000015_A_New() *A_arbace_cpp_run_fn__97000014_rmw__97000015_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_fn__97000014_rmw__97000015_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_cpp_run_fn__97000014_rmw__97000015_A) Ctor() {}
//line :37:1
func (t *A_arbace_cpp_run_fn__97000014_rmw__97000015_A) Invoke_O_O_O_O__O(self, nm__1, op__2, new_QMARK___3 any) any { var tmp1 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_115, nil, Lit_116), jrt.RefArrayOf(jrt.Object_class, nil, nm__1, nil)).Ref(); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_117, nil, Lit_118, nil, Lit_119); var tmp3 *jrt.String; if


	jrt.J2g_Truth(new_QMARK___3) { tmp3 = Lit_120 } else { tmp3 = Lit_121 }; return /*line :37:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, op__2, nil, tmp3.Ref(), nil)).Ref()) }
















func A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_A_New_O(p0 any) *A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_A{}; t.Ctor_O(p0); return t }
//line :54:1
func (t *A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_A) Ctor_O(c__rmw any) { t.F_rmw = c__rmw }
//line :54:1
func (t *A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_A) Invoke_O_O__O(self, s__97000018__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_A_New_O_O_O(s__97000018__1, t.F_rmw, self); var tmp2 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_109, false, fnbody__122); A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_A_fn_class = fncls__121d; tmp2 = fncls__121d } else { tmp2 = fncls__121 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :54:1
func A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :54:1
func (t *A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_A) Ctor_O_O_O(c__s__97000018, c__rmw, c__iter__97000017 any) { t.F_s__97000018 = c__s__97000018; t.F_rmw = c__rmw; t.F_iter__97000017 = c__iter__97000017 }
//line :54:1
func (t *A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_A) Invoke_O__O(self any) any { { var s__97000018__1 any; var t_ any = t.F_s__97000018; t.F_s__97000018 = nil; s__97000018__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_34 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = s__97000018__1; if linked_35 == nil { temp__1927000414__auto____2 = ifn_36.Invoke_O__O(arg_37) } else { temp__1927000414__auto____2 = linked_35.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_34, arg_37) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__97000025__4 any; var root_38 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = xs__1927001018__auto____3; if linked_39 == nil { vec__97000025__4 = ifn_40.Invoke_O__O(arg_41) } else { vec__97000025__4 = linked_39.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_38, arg_41) }; var nm__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000025__4, lang.RT_IntCast_J__I_NoInit(0), nil); var op__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000025__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var fnbody__103 any = A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_A_New_O_O(t.F_rmw, op__6); var tmp1 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_A_fn_class; if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_110, false, fnbody__103); A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_A_fn_class = fncls__102d; tmp1 = fncls__102d } else { tmp1 = fncls__102 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__103, tmp1, nil); var fs__1927001036__auto____8 any; var root_104 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = lang.IFn_Cast(iterys__1927001035__auto____7).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_111, nil), jrt.RefArrayOf(jrt.Object_class, nil, nm__5)).Ref(), jrt.Boolean_FALSE.Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_112), jrt.RefArrayOf(jrt.Object_class, nm__5, nil)).Ref(), jrt.Boolean_TRUE.Ref()))); if linked_105 == nil { fs__1927001036__auto____8 = ifn_106.Invoke_O__O(arg_107) } else { fs__1927001036__auto____8 = linked_105.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_104, arg_107) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_108 any = A_arbace_cpp_run_A_const_30.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = fs__1927001036__auto____8; var arg_112 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_iter__97000017); var tmp3 any; var root_113 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = s__97000018__1; if linked_114 == nil { tmp3 = ifn_115.Invoke_O__O(arg_116) } else { tmp3 = linked_114.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_113, arg_116) }; arg_112 = tmp2.Invoke_O__O(tmp3); if linked_109 == nil { return ifn_110.Invoke_O_O__O(arg_111, arg_112) } else { return linked_109.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_108, arg_111, arg_112) } } else { var tmp4 any; var root_117 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = s__97000018__1; if linked_118 == nil { tmp4 = ifn_119.Invoke_O__O(arg_120) } else { tmp4 = linked_118.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_117, arg_120) }; s__97000018__1 = tmp4; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :54:1
func A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_A{}; t.Ctor_O_O(p0, p1); return t }
//line :54:1
func (t *A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_A) Ctor_O_O(c__rmw, c__op any) { t.F_rmw = c__rmw; t.F_op = c__op }
//line :54:1
func (t *A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_A) Invoke_O_O__O(self, s__97000020__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__101 any = A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_A_New_O_O_O_O(s__97000020__1, t.F_rmw, t.F_op, self); var tmp2 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_113, false, fnbody__101); A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_A_fn_class = fncls__100d; tmp2 = fncls__100d } else { tmp2 = fncls__100 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__101, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :54:1
func A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :54:1
func (t *A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_A) Ctor_O_O_O_O(c__s__97000020, c__rmw, c__op, c__iter__97000019 any) { t.F_s__97000020 = c__s__97000020; t.F_rmw = c__rmw; t.F_op = c__op; t.F_iter__97000019 = c__iter__97000019 }
//line :54:1
func (t *A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_A) Invoke_O__O(self any) any { { var s__97000020__1 any; var t_ any = t.F_s__97000020; t.F_s__97000020 = nil; s__97000020__1 = t_; for { var temp__1927000414__auto____2 any; var root_42 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = s__97000020__1; if linked_43 == nil { temp__1927000414__auto____2 = ifn_44.Invoke_O__O(arg_45) } else { temp__1927000414__auto____2 = linked_43.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_42, arg_45) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__97000020__3 any = temp__1927000414__auto____2; var tmp1 any; var root_46 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = s__97000020__3; if linked_47 == nil { tmp1 = ifn_48.Invoke_O__O(arg_49) } else { tmp1 = linked_47.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_46, arg_49) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_50 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = s__97000020__3; if linked_51 == nil { c__1927001037__auto____4 = ifn_52.Invoke_O__O(arg_53) } else { c__1927001037__auto____4 = linked_51.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_50, arg_53) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__97000022__6 any; var root_54 any = A_arbace_cpp_run_A_const_23.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_55 == nil { b__97000022__6 = ifn_56.Invoke_O__O(arg_57) } else { b__97000022__6 = linked_55.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_54, arg_57) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_fn__97000030_A_New_O_O_O_I_O(b__97000022__6, t.F_rmw, t.F_op, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_fn__97000030_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_114, false, fnbody__64); A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_fn__97000030_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_65 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any; var root_70 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = b__97000022__6; if linked_71 == nil { arg_68 = ifn_72.Invoke_O__O(arg_73) } else { arg_68 = linked_71.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_70, arg_73) }; var arg_69 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__97000019); var tmp5 any; var root_74 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = s__97000020__3; if linked_75 == nil { tmp5 = ifn_76.Invoke_O__O(arg_77) } else { tmp5 = linked_75.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_74, arg_77) }; arg_69 = tmp4.Invoke_O__O(tmp5); if linked_66 == nil { return ifn_67.Invoke_O_O__O(arg_68, arg_69) } else { return linked_66.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_65, arg_68, arg_69) } } else { var root_78 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any; var root_83 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = b__97000022__6; if linked_84 == nil { arg_81 = ifn_85.Invoke_O__O(arg_86) } else { arg_81 = linked_84.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_83, arg_86) }; var arg_82 any; if linked_79 == nil { return ifn_80.Invoke_O_O__O(arg_81, arg_82) } else { return linked_79.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_78, arg_81, arg_82) } } } else { var vec__97000035__4 any; var root_87 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = s__97000020__3; if linked_88 == nil { vec__97000035__4 = ifn_89.Invoke_O__O(arg_90) } else { vec__97000035__4 = linked_88.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_87, arg_90) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000035__4, lang.RT_IntCast_J__I_NoInit(0), nil); var new_QMARK___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000035__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_91 any = A_arbace_cpp_run_A_const_28.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = lang.IFn_Cast(t.F_rmw).Invoke_O_O_O__O(k__5, t.F_op, new_QMARK___6); var arg_95 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__97000019); var tmp7 any; var root_96 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = s__97000020__3; if linked_97 == nil { tmp7 = ifn_98.Invoke_O__O(arg_99) } else { tmp7 = linked_97.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_96, arg_99) }; arg_95 = tmp6.Invoke_O__O(tmp7); if linked_92 == nil { return ifn_93.Invoke_O_O__O(arg_94, arg_95) } else { return linked_92.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_91, arg_94, arg_95) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :54:1
func A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_fn__97000030_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_fn__97000030_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_fn__97000030_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :54:1
func (t *A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_fn__97000030_A) Ctor_O_O_O_I_O(c__b__97000022, c__rmw, c__op any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__97000022 = c__b__97000022; t.F_rmw = c__rmw; t.F_op = c__op; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :54:1
func (t *A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_fn__97000030_A) Invoke_O__O(self any) any { { var i__97000021__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__97000021__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__97000031__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__97000021__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000031__2, lang.RT_IntCast_J__I_NoInit(0), nil); var new_QMARK___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000031__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_58 any = A_arbace_cpp_run_A_const_24.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = t.F_b__97000022; var arg_62 any = lang.IFn_Cast(t.F_rmw).Invoke_O_O_O__O(k__3, t.F_op, new_QMARK___4); if linked_59 == nil { ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { linked_59.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_58, arg_61, arg_62) }; i__97000021__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__97000021__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_cpp_run_fn__97000047_A_New() *A_arbace_cpp_run_fn__97000047_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_fn__97000047_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_cpp_run_fn__97000047_A) Ctor() {}
//line :63:1
func (t *A_arbace_cpp_run_fn__97000047_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var fnbody__186 any = A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_A_New(); var tmp1 *jrt.Class; var fncls__185 *jrt.Class = A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_A_fn_class; if fncls__185 == nil { var fncls__185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, nil); A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_A_fn_class = fncls__185d; tmp1 = fncls__185d } else { tmp1 = fncls__185 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__186, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____1); var tmp3 any; var root_187 any = A_arbace_cpp_run_A_const_30.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = A_arbace_cpp_run_A_const_32.GetRawRoot__O(); var tmp4 *lang.Keyword = A_arbace_cpp_run_A_const_33; var arg_191 any = tmp4.Invoke_O__O(A_arbace_cpp_run_A_const_34.GetRawRoot__O()); if linked_188 == nil { tmp3 = ifn_189.Invoke_O_O__O(arg_190, arg_191) } else { tmp3 = linked_188.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_187, arg_190, arg_191) }; return tmp2.Invoke_O__O(tmp3) }
//line :63:1
func A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_A_New() *A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_A) Ctor() {}
//line :63:1
func (t *A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_A) Invoke_O_O__O(self, s__97000044__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__184 any = A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_A_New_O_O(s__97000044__1, self); var tmp2 *jrt.Class; var fncls__183 *jrt.Class = A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_A_fn_class; if fncls__183 == nil { var fncls__183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_123, false, fnbody__184); A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_A_fn_class = fncls__183d; tmp2 = fncls__183d } else { tmp2 = fncls__183 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__184, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :63:1
func A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_A{}; t.Ctor_O_O(p0, p1); return t }
//line :63:1
func (t *A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_A) Ctor_O_O(c__s__97000044, c__iter__97000043 any) { t.F_s__97000044 = c__s__97000044; t.F_iter__97000043 = c__iter__97000043 }
//line :63:1
func (t *A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_A) Invoke_O__O(self any) any { { var s__97000044__1 any; var t_ any = t.F_s__97000044; t.F_s__97000044 = nil; s__97000044__1 = t_; for { var temp__1927000414__auto____2 any; var root_125 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = s__97000044__1; if linked_126 == nil { temp__1927000414__auto____2 = ifn_127.Invoke_O__O(arg_128) } else { temp__1927000414__auto____2 = linked_126.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_125, arg_128) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__97000044__3 any = temp__1927000414__auto____2; var tmp1 any; var root_129 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = s__97000044__3; if linked_130 == nil { tmp1 = ifn_131.Invoke_O__O(arg_132) } else { tmp1 = linked_130.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_129, arg_132) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_133 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = s__97000044__3; if linked_134 == nil { c__1927001037__auto____4 = ifn_135.Invoke_O__O(arg_136) } else { c__1927001037__auto____4 = linked_134.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_133, arg_136) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__97000046__6 any; var root_137 any = A_arbace_cpp_run_A_const_23.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_138 == nil { b__97000046__6 = ifn_139.Invoke_O__O(arg_140) } else { b__97000046__6 = linked_138.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_137, arg_140) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__147 any = A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_fn__97000050_A_New_O_I_O(b__97000046__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__146 *jrt.Class = A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_fn__97000050_A_fn_class; if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, fnbody__147); A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_fn__97000050_A_fn_class = fncls__146d; tmp3 = fncls__146d } else { tmp3 = fncls__146 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__147, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_148 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any; var root_153 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = b__97000046__6; if linked_154 == nil { arg_151 = ifn_155.Invoke_O__O(arg_156) } else { arg_151 = linked_154.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_153, arg_156) }; var arg_152 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__97000043); var tmp5 any; var root_157 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = s__97000044__3; if linked_158 == nil { tmp5 = ifn_159.Invoke_O__O(arg_160) } else { tmp5 = linked_158.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_157, arg_160) }; arg_152 = tmp4.Invoke_O__O(tmp5); if linked_149 == nil { return ifn_150.Invoke_O_O__O(arg_151, arg_152) } else { return linked_149.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_148, arg_151, arg_152) } } else { var root_161 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any; var root_166 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = b__97000046__6; if linked_167 == nil { arg_164 = ifn_168.Invoke_O__O(arg_169) } else { arg_164 = linked_167.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_166, arg_169) }; var arg_165 any; if linked_162 == nil { return ifn_163.Invoke_O_O__O(arg_164, arg_165) } else { return linked_162.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_161, arg_164, arg_165) } } } else { var vec__97000055__4 any; var root_170 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = s__97000044__3; if linked_171 == nil { vec__97000055__4 = ifn_172.Invoke_O__O(arg_173) } else { vec__97000055__4 = linked_171.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_170, arg_173) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000055__4, lang.RT_IntCast_J__I_NoInit(0), nil); var d__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000055__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_174 any = A_arbace_cpp_run_A_const_28.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_125, nil, Lit_126, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__5, nil, d__6)).Ref(); var arg_178 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__97000043); var tmp7 any; var root_179 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = s__97000044__3; if linked_180 == nil { tmp7 = ifn_181.Invoke_O__O(arg_182) } else { tmp7 = linked_180.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_179, arg_182) }; arg_178 = tmp6.Invoke_O__O(tmp7); if linked_175 == nil { return ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { return linked_175.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_174, arg_177, arg_178) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :63:1
func A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_fn__97000050_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_fn__97000050_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_fn__97000050_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :63:1
func (t *A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_fn__97000050_A) Ctor_O_I_O(c__b__97000046 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__97000046 = c__b__97000046; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :63:1
func (t *A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_fn__97000050_A) Invoke_O__O(self any) any { { var i__97000045__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__97000045__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__97000051__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__97000045__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000051__2, lang.RT_IntCast_J__I_NoInit(0), nil); var d__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000051__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_141 any = A_arbace_cpp_run_A_const_24.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = t.F_b__97000046; var arg_145 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_125, nil, Lit_126, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__3, nil, d__4)).Ref(); if linked_142 == nil { ifn_143.Invoke_O_O__O(arg_144, arg_145) } else { linked_142.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_141, arg_144, arg_145) }; i__97000045__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__97000045__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_cpp_run_spit_mk_A_New() *A_arbace_cpp_run_spit_mk_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_spit_mk_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_cpp_run_spit_mk_A) Ctor() {}
//line :65:1
func (t *A_arbace_cpp_run_spit_mk_A) Invoke_O_O_O__O(self, path__0, s__1 any) any {
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_New_String(jrt.String_Cast(path__0)).GetParentFile__File().Mkdirs__Z())
	return lang.IFn_Cast(A_arbace_cpp_run_A_const_35.GetRawRoot__O()).Invoke_O_O__O(path__0, s__1)
}
func A_arbace_cpp_run_clean_A_New() *A_arbace_cpp_run_clean_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_clean_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_cpp_run_clean_A) Ctor() {}
//line :69:1
func (t *A_arbace_cpp_run_clean_A) Invoke_O_O__O(self, s__0 any) any { var root_197 any = A_arbace_cpp_run_A_const_36.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any; var root_203 any = A_arbace_cpp_run_A_const_37.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = s__0; if linked_204 == nil { arg_200 = ifn_205.Invoke_O__O(arg_206) } else { arg_200 = linked_204.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_203, arg_206) }; var arg_201 any = A_arbace_cpp_run_A_const_38; var arg_202 any = Lit_20; if linked_198 == nil { return ifn_199.Invoke_O_O_O__O(arg_200, arg_201, arg_202) } else { return linked_198.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_197, arg_200, arg_201, arg_202) } }

func A_arbace_cpp_run_tsv_A_New() *A_arbace_cpp_run_tsv_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_tsv_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_cpp_run_tsv_A) Ctor() {}
//line :71:1
func (t *A_arbace_cpp_run_tsv_A) Invoke_O_O__O(self, f__0 any) any { var x__2 any = jrt.File_New_String(jrt.String_Cast(f__0)); if

	jrt.File_Cast(x__2).Exists__Z() { var root_207 any = A_arbace_cpp_run_A_const_39.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any; var fnbody__219 any = A_arbace_cpp_run_tsv_fn__97000064_A_New(); var tmp1 *jrt.Class; var fncls__218 *jrt.Class = A_arbace_cpp_run_tsv_fn__97000064_A_fn_class; if fncls__218 == nil { var fncls__218d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_213, false, nil); A_arbace_cpp_run_tsv_fn__97000064_A_fn_class = fncls__218d; tmp1 = fncls__218d } else { tmp1 = fncls__218 }; arg_210 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__219, tmp1, nil); var arg_211 any; var root_220 any = A_arbace_cpp_run_A_const_43.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = A_arbace_cpp_run_A_const_44.GetRawRoot__O(); var arg_224 any; var root_225 any = A_arbace_cpp_run_A_const_45.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = lang.IFn_Cast(A_arbace_cpp_run_A_const_46.GetRawRoot__O()).Invoke_O__O(x__2); if linked_226 == nil { arg_224 = ifn_227.Invoke_O__O(arg_228) } else { arg_224 = linked_226.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_225, arg_228) }; if linked_221 == nil { arg_211 = ifn_222.Invoke_O_O__O(arg_223, arg_224) } else { arg_211 = linked_221.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_220, arg_223, arg_224) }; if linked_208 == nil { return ifn_209.Invoke_O_O__O(arg_210, arg_211) } else { return linked_208.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_207, arg_210, arg_211) } } else { return lang.PersistentVector_EMPTY.Ref() } }
//line :73:1
func A_arbace_cpp_run_tsv_fn__97000064_A_New() *A_arbace_cpp_run_tsv_fn__97000064_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_tsv_fn__97000064_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_cpp_run_tsv_fn__97000064_A) Ctor() {}
//line :73:1
func (t *A_arbace_cpp_run_tsv_fn__97000064_A) Invoke_O_O__O(self, p1__97000063_SHARP___1 any) any { var root_212 any = A_arbace_cpp_run_A_const_40.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = p1__97000063_SHARP___1; var arg_216 any = A_arbace_cpp_run_A_const_41; var arg_217 any = A_arbace_cpp_run_A_const_42; if linked_213 == nil { return ifn_214.Invoke_O_O_O__O(arg_215, arg_216, arg_217) } else { return linked_213.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_212, arg_215, arg_216, arg_217) } }




func A_arbace_cpp_run_read_one_A_New() *A_arbace_cpp_run_read_one_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_one_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_cpp_run_read_one_A) Ctor() {}
//line :78:1
func (t *A_arbace_cpp_run_read_one_A) Invoke_O_O_O_O_O__O(self, h__0, dir__1, nm__2, path__3 any) any { var f__5 any = jrt.File_New_String(jrt.String_Cast(path__3)); var fc__6 any; var root_233 any = A_arbace_cpp_run_A_const_47.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A_fn_class); var ifn_235 lang.IFn; if



	linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = A_arbace_cpp_run_A_const_48.GetRawRoot__O(); var arg_237 any = Lit_77; if linked_234 == nil { fc__6 = ifn_235.Invoke_O_O__O(arg_236, arg_237) } else { fc__6 = linked_234.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A).Invoke_O_O_O__O(root_233, arg_236, arg_237) }; var rd__7 any; var root_238 any = /*line :78:1*/A_arbace_cpp_run_A_const_49.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_repr_c.A_arbace_repr_c_read_c_A_fn_class); var ifn_240 lang.IFn; if




	linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any; var root_245 any = A_arbace_cpp_run_A_const_50.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_repr_c_host.A_arbace_repr_c_host_config_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = h__0; var arg_249 any = fc__6; var arg_250 any = jrt.File_Cast(f__5).GetParent__String().Ref(); if linked_246 == nil { arg_241 = ifn_247.Invoke_O_O_O__O(arg_248, arg_249, arg_250) } else { arg_241 = linked_246.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_config_A).Invoke_O_O_O_O__O(root_245, arg_248, arg_249, arg_250) }; var arg_242 any = fc__6; var arg_243 any = jrt.File_Cast(f__5).GetName__String().Ref(); var arg_244 any = jrt.Boolean_FALSE.Ref(); if linked_239 == nil { rd__7 = ifn_240.Invoke_O_O_O_O__O(arg_241, arg_242, arg_243, arg_244) } else { rd__7 = linked_239.(*aot_arbace_repr_c.A_arbace_repr_c_read_c_A).Invoke_O_O_O_O_O__O(root_238, arg_241, arg_242, arg_243, arg_244) }; if
	jrt.J2g_Truth(A_arbace_cpp_run_A_const_51.Invoke_O__O(rd__7)) {
		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_208, nil); var tmp2 any; var root_251 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any = Lit_80; var arg_255 any; var root_256 any = A_arbace_cpp_run_A_const_53.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = A_arbace_cpp_run_A_const_54; var arg_260 any = A_arbace_cpp_run_A_const_51.Invoke_O__O(rd__7); if linked_257 == nil { arg_255 = ifn_258.Invoke_O_O__O(arg_259, arg_260) } else { arg_255 = linked_257.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_256, arg_259, arg_260) }; if linked_252 == nil { tmp2 = ifn_253.Invoke_O_O__O(arg_254, arg_255) } else { tmp2 = linked_252.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_251, arg_254, arg_255) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() } else {
//line :84:1
			if jrt.J2g_Truth(A_arbace_cpp_run_A_const_55.Invoke_O__O(rd__7)) {

				var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_209, nil, Lit_19, nil); var tmp4 any; var root_261 any = A_arbace_cpp_run_A_const_56.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = A_arbace_cpp_run_A_const_55.Invoke_O__O(rd__7); if linked_262 == nil { tmp4 = ifn_263.Invoke_O__O(arg_264) } else { tmp4 = linked_262.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_261, arg_264) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, A_arbace_cpp_run_A_const_57.Invoke_O__O(rd__7))).Ref() } else {
//line :84:1
					if A_arbace_cpp_run_A_const_58 != nil { var seq_97000067__8 any; var root_265 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_267 lang.IFn


						if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any; var root_269 any = A_arbace_cpp_run_A_const_59.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_repr_c.A_arbace_repr_c_unit_texts_A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = rd__7; var arg_273 any = jrt.File_Cast(f__5).GetName__String().Ref(); if linked_270 == nil { arg_268 = ifn_271.Invoke_O_O__O(arg_272, arg_273) } else { arg_268 = linked_270.(*aot_arbace_repr_c.A_arbace_repr_c_unit_texts_A).Invoke_O_O_O__O(root_269, arg_272, arg_273) }; if linked_266 == nil { seq_97000067__8 = ifn_267.Invoke_O__O(arg_268) } else { seq_97000067__8 = linked_266.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_265, arg_268) }
//line :84:1
						var chunk_97000068__9 any; var count_97000069__10 int64 = 0; var i_97000070__11 int64 = 0; L1: for {


							if lang.Numbers_Lt_J_J__Z_NoInit(i_97000070__11, count_97000069__10) { var vec__97000071__12 any = lang.Indexed_Cast(chunk_97000068__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000070__11)); var p__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000071__12, lang.RT_IntCast_J__I_NoInit(0), nil); var t__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000071__12, lang.RT_IntCast_J__I_NoInit(1), nil); var out__15 any; var tmp5 any; var root_312 any = A_arbace_cpp_run_A_const_66.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_314 lang.IFn
								if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = p__13; var arg_316 any = Lit_210; if linked_313 == nil { tmp5 = ifn_314.Invoke_O_O__O(arg_315, arg_316) } else { tmp5 = linked_313.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_312, arg_315, arg_316) }; if jrt.J2g_Truth(tmp5) { out__15 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_154, nil), jrt.RefArrayOf(jrt.Object_class, dir__1, nil, p__13)).Ref() } else { out__15 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_154, nil, Lit_155), jrt.RefArrayOf(jrt.Object_class, dir__1, nil, nm__2, nil)).Ref() }
								var tmp6 any; var and__1927000168__auto____16 any; var root_317 any = A_arbace_cpp_run_A_const_66.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = p__13; var arg_321 any = Lit_210; if linked_318 == nil { and__1927000168__auto____16 = ifn_319.Invoke_O_O__O(arg_320, arg_321) } else { and__1927000168__auto____16 = linked_318.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_317, arg_320, arg_321) }; if jrt.J2g_Truth(and__1927000168__auto____16) { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_New_String(jrt.String_Cast(out__15)).Exists__Z()).Ref() } else { tmp6 = and__1927000168__auto____16 }; if jrt.J2g_Truth(tmp6) { } else {
									var root_322 any = A_arbace_cpp_run_A_const_60.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, A_arbace_cpp_run_spit_mk_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = out__15; var arg_326 any = t__14; if linked_323 == nil { ifn_324.Invoke_O_O__O(arg_325, arg_326) } else { linked_323.(*A_arbace_cpp_run_spit_mk_A).Invoke_O_O_O__O(root_322, arg_325, arg_326) } }
//line :87:1
								seq_97000067__8, chunk_97000068__9, count_97000069__10, i_97000070__11 = seq_97000067__8, chunk_97000068__9, count_97000069__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000070__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_274 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_276 lang.IFn; if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = seq_97000067__8; if linked_275 == nil { temp__1927000414__auto____12 = ifn_276.Invoke_O__O(arg_277) } else { temp__1927000414__auto____12 = linked_275.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_274, arg_277) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_97000067__13 any = temp__1927000414__auto____12; var tmp7 any; var root_278 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = seq_97000067__13; if linked_279 == nil { tmp7 = ifn_280.Invoke_O__O(arg_281) } else { tmp7 = linked_279.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_278, arg_281) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____14 any; var root_282 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = seq_97000067__13; if linked_283 == nil { c__1927000678__auto____14 = ifn_284.Invoke_O__O(arg_285) } else { c__1927000678__auto____14 = linked_283.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_282, arg_285) }; var tmp8 any; var root_327 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = seq_97000067__13; if linked_328 == nil { tmp8 = ifn_329.Invoke_O__O(arg_330) } else { tmp8 = linked_328.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_327, arg_330) }; seq_97000067__8, chunk_97000068__9, count_97000069__10, i_97000070__11 = tmp8, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__97000074__14 any; var root_286 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = seq_97000067__13; if linked_287 == nil { vec__97000074__14 = ifn_288.Invoke_O__O(arg_289) } else { vec__97000074__14 = linked_287.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_286, arg_289) }; var p__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000074__14, lang.RT_IntCast_J__I_NoInit(0), nil); var t__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000074__14, lang.RT_IntCast_J__I_NoInit(1), nil); var out__17 any; var tmp9 any; var root_331 any = A_arbace_cpp_run_A_const_66.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_333 lang.IFn
									if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = p__15; var arg_335 any = Lit_210; if linked_332 == nil { tmp9 = ifn_333.Invoke_O_O__O(arg_334, arg_335) } else { tmp9 = linked_332.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_331, arg_334, arg_335) }; if jrt.J2g_Truth(tmp9) { out__17 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_154, nil), jrt.RefArrayOf(jrt.Object_class, dir__1, nil, p__15)).Ref() } else { out__17 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_154, nil, Lit_155), jrt.RefArrayOf(jrt.Object_class, dir__1, nil, nm__2, nil)).Ref() }
									var tmp10 any; var and__1927000168__auto____18 any; var root_336 any = A_arbace_cpp_run_A_const_66.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = p__15; var arg_340 any = Lit_210; if linked_337 == nil { and__1927000168__auto____18 = ifn_338.Invoke_O_O__O(arg_339, arg_340) } else { and__1927000168__auto____18 = linked_337.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_336, arg_339, arg_340) }; if jrt.J2g_Truth(and__1927000168__auto____18) { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_New_String(jrt.String_Cast(out__17)).Exists__Z()).Ref() } else { tmp10 = and__1927000168__auto____18 }; if jrt.J2g_Truth(tmp10) { } else {
										var root_341 any = A_arbace_cpp_run_A_const_60.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, A_arbace_cpp_run_spit_mk_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = out__17; var arg_345 any = t__16; if linked_342 == nil { ifn_343.Invoke_O_O__O(arg_344, arg_345) } else { linked_342.(*A_arbace_cpp_run_spit_mk_A).Invoke_O_O_O__O(root_341, arg_344, arg_345) } }
//line :87:1
									var tmp11 any; var root_346 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = seq_97000067__13; if linked_347 == nil { tmp11 = ifn_348.Invoke_O__O(arg_349) } else { tmp11 = linked_347.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_346, arg_349) }; seq_97000067__8, chunk_97000068__9, count_97000069__10, i_97000070__11 = tmp11, nil, 0, 0; continue L1 } } }
//line :84:1
							break L1
						}





						var root_290 any = A_arbace_cpp_run_A_const_60.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, A_arbace_cpp_run_spit_mk_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_154, nil, Lit_156), jrt.RefArrayOf(jrt.Object_class, dir__1, nil, nm__2, nil)).Ref(); var arg_294 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_61.GetRawRoot__O()); var tmp13 any; var root_299 any = A_arbace_cpp_run_A_const_62.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any; var root_303 any = A_arbace_cpp_run_A_const_63.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = A_arbace_cpp_run_A_const_37.GetRawRoot__O(); var arg_307 any; var root_308 any = A_arbace_cpp_run_A_const_64.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = A_arbace_cpp_run_A_const_65.Invoke_O__O(rd__7); if linked_309 == nil { arg_307 = ifn_310.Invoke_O__O(arg_311) } else { arg_307 = linked_309.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_308, arg_311) }; if linked_304 == nil { arg_302 = ifn_305.Invoke_O_O__O(arg_306, arg_307) } else { arg_302 = linked_304.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_303, arg_306, arg_307) }; if linked_300 == nil { tmp13 = ifn_301.Invoke_O__O(arg_302) } else { tmp13 = linked_300.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_299, arg_302) }; arg_294 = tmp12.Invoke_O__O(tmp13); if linked_291 == nil { ifn_292.Invoke_O_O__O(arg_293, arg_294) } else { linked_291.(*A_arbace_cpp_run_spit_mk_A).Invoke_O_O_O__O(root_290, arg_293, arg_294) }
//line :84:1
						return nil } else { return nil } } } }









func A_arbace_cpp_run_load_unit_A_New() *A_arbace_cpp_run_load_unit_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_load_unit_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_cpp_run_load_unit_A) Ctor() {}
//line :94:1
func (t *A_arbace_cpp_run_load_unit_A) Invoke_O_O_O__O(self, dir__0, nm__1 any) any { var vec__97000078__3 any; var root_350 any = A_arbace_cpp_run_A_const_68.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A_fn_class); var ifn_352 lang.IFn; if


	linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = lang.IFn_Cast(A_arbace_cpp_run_A_const_46.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_154, nil, Lit_155), jrt.RefArrayOf(jrt.Object_class, dir__0, nil, nm__1, nil)).Ref()); if linked_351 == nil { vec__97000078__3 = ifn_352.Invoke_O__O(arg_353) } else { vec__97000078__3 = linked_351.(*aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A).Invoke_O_O__O(root_350, arg_353) }; var ___4 any = /*line :94:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__97000078__3, lang.RT_IntCast_J__I_NoInit(0), nil); var forms__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000078__3, lang.RT_IntCast_J__I_NoInit(1), nil); var us__6 any; var root_358 any = A_arbace_cpp_run_A_const_69.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_360 lang.IFn; _ = ___4; if



	linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = lang.IFn_Cast(A_arbace_cpp_run_A_const_46.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_154, nil, Lit_156), jrt.RefArrayOf(jrt.Object_class, dir__0, nil, nm__1, nil)).Ref()); if linked_359 == nil { us__6 = ifn_360.Invoke_O__O(arg_361) } else { us__6 = linked_359.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_358, arg_361) }; var tmp1 any = A_arbace_cpp_run_A_const_70; var tmp2 any = A_arbace_cpp_run_A_const_65; var tmp3 any; var root_366 any = /*line :94:1*/A_arbace_cpp_run_A_const_17.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_368 lang.IFn; if





	linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_370 any; var iter__1927001039__auto____7 any; var fnbody__474 any = A_arbace_cpp_run_load_unit_iter__97000081__97000085_A_New_O(dir__0); var tmp4 *jrt.Class; var fncls__473 *jrt.Class = A_arbace_cpp_run_load_unit_iter__97000081__97000085_A_fn_class; if fncls__473 == nil { var fncls__473d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_157, false, fnbody__474); A_arbace_cpp_run_load_unit_iter__97000081__97000085_A_fn_class = fncls__473d; tmp4 = fncls__473d } else { tmp4 = fncls__473 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__474, tmp4, nil); arg_370 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(us__6); if linked_367 == nil { tmp3 = ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { tmp3 = linked_367.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_366, arg_369, arg_370) }; return /*line :94:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, forms__5, tmp2, tmp3)) }





func A_arbace_cpp_run_load_unit_iter__97000081__97000085_A_New_O(p0 any) *A_arbace_cpp_run_load_unit_iter__97000081__97000085_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_load_unit_iter__97000081__97000085_A{}; t.Ctor_O(p0); return t }
//line :100:1
func (t *A_arbace_cpp_run_load_unit_iter__97000081__97000085_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :100:1
func (t *A_arbace_cpp_run_load_unit_iter__97000081__97000085_A) Invoke_O_O__O(self, s__97000082__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__472 any = A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_A_New_O_O_O(s__97000082__1, t.F_dir, self); var tmp2 *jrt.Class; var fncls__471 *jrt.Class = A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_A_fn_class; if fncls__471 == nil { var fncls__471d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_158, false, fnbody__472); A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_A_fn_class = fncls__471d; tmp2 = fncls__471d } else { tmp2 = fncls__471 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__472, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :100:1
func A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :100:1
func (t *A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_A) Ctor_O_O_O(c__s__97000082, c__dir, c__iter__97000081 any) { t.F_s__97000082 = c__s__97000082; t.F_dir = c__dir; t.F_iter__97000081 = c__iter__97000081 }
//line :100:1
func (t *A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_A) Invoke_O__O(self any) any { { var s__97000082__1 any; var t_ any = t.F_s__97000082; t.F_s__97000082 = nil; s__97000082__1 = t_; for { var temp__1927000414__auto____2 any; var root_371 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = s__97000082__1; if linked_372 == nil { temp__1927000414__auto____2 = ifn_373.Invoke_O__O(arg_374) } else { temp__1927000414__auto____2 = linked_372.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_371, arg_374) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__97000082__3 any = temp__1927000414__auto____2; var tmp1 any; var root_375 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = s__97000082__3; if linked_376 == nil { tmp1 = ifn_377.Invoke_O__O(arg_378) } else { tmp1 = linked_376.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_375, arg_378) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_379 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = s__97000082__3; if linked_380 == nil { c__1927001037__auto____4 = ifn_381.Invoke_O__O(arg_382) } else { c__1927001037__auto____4 = linked_380.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_379, arg_382) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__97000084__6 any; var root_383 any = A_arbace_cpp_run_A_const_23.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_384 == nil { b__97000084__6 = ifn_385.Invoke_O__O(arg_386) } else { b__97000084__6 = linked_384.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_383, arg_386) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__414 any = A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_fn__97000087_A_New_O_O_I_O(t.F_dir, b__97000084__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__413 *jrt.Class = A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_fn__97000087_A_fn_class; if fncls__413 == nil { var fncls__413d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_159, false, fnbody__414); A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_fn__97000087_A_fn_class = fncls__413d; tmp3 = fncls__413d } else { tmp3 = fncls__413 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__414, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_415 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any; var root_420 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = b__97000084__6; if linked_421 == nil { arg_418 = ifn_422.Invoke_O__O(arg_423) } else { arg_418 = linked_421.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_420, arg_423) }; var arg_419 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__97000081); var tmp5 any; var root_424 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = s__97000082__3; if linked_425 == nil { tmp5 = ifn_426.Invoke_O__O(arg_427) } else { tmp5 = linked_425.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_424, arg_427) }; arg_419 = tmp4.Invoke_O__O(tmp5); if linked_416 == nil { return ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { return linked_416.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) } } else { var root_428 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any; var root_433 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = b__97000084__6; if linked_434 == nil { arg_431 = ifn_435.Invoke_O__O(arg_436) } else { arg_431 = linked_434.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_433, arg_436) }; var arg_432 any; if linked_429 == nil { return ifn_430.Invoke_O_O__O(arg_431, arg_432) } else { return linked_429.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_428, arg_431, arg_432) } } } else { var u__4 any; var root_437 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = s__97000082__3; if linked_438 == nil { u__4 = ifn_439.Invoke_O__O(arg_440) } else { u__4 = linked_438.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_437, arg_440) }; var root_441 any = A_arbace_cpp_run_A_const_28.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any; var vec__97000092__5 any; var root_446 any = A_arbace_cpp_run_A_const_68.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A_fn_class); var ifn_448 lang.IFn
													if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_46.GetRawRoot__O()); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_160, nil, Lit_155); var tmp8 any = t.F_dir; var tmp9 any; var root_454 any = A_arbace_cpp_run_A_const_71.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = u__4; var arg_458 any = A_arbace_cpp_run_A_const_72; if linked_455 == nil { tmp9 = ifn_456.Invoke_O_O__O(arg_457, arg_458) } else { tmp9 = linked_455.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_454, arg_457, arg_458) }; arg_449 = tmp6.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9, nil)).Ref()); if linked_447 == nil { vec__97000092__5 = ifn_448.Invoke_O__O(arg_449) } else { vec__97000092__5 = linked_447.(*aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A).Invoke_O_O__O(root_446, arg_449) }
//line :100:1
	var hf__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000092__5, lang.RT_IntCast_J__I_NoInit(0), nil); var hforms__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000092__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp10 any; var root_459 any = A_arbace_cpp_run_A_const_73.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_461 lang.IFn

	if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = u__4; if linked_460 == nil { tmp10 = ifn_461.Invoke_O__O(arg_462) } else { tmp10 = linked_460.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_459, arg_462) }
//line :100:1
	var tmp11 any = tmp10; var tmp12 any = A_arbace_cpp_run_A_const_70; var tmp13 any = A_arbace_cpp_run_A_const_74; var tmp14 any; var root_463 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_465 lang.IFn

	if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = hf__6; if linked_464 == nil { tmp14 = ifn_465.Invoke_O__O(arg_466) } else { tmp14 = linked_464.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_463, arg_466) }
//line :100:1
	arg_444 = lang.Tuple_Create_O_O__IPersistentVector(tmp11, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, hforms__7, tmp13, tmp14))); var arg_445 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__97000081); var tmp16 any; var root_467 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = s__97000082__3; if linked_468 == nil { tmp16 = ifn_469.Invoke_O__O(arg_470) } else { tmp16 = linked_468.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_467, arg_470) }; arg_445 = tmp15.Invoke_O__O(tmp16); if linked_442 == nil { return ifn_443.Invoke_O_O__O(arg_444, arg_445) } else { return linked_442.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_441, arg_444, arg_445) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :100:1
func A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_fn__97000087_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_fn__97000087_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_fn__97000087_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :100:1
func (t *A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_fn__97000087_A) Ctor_O_O_I_O(c__dir, c__b__97000084 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_dir = c__dir; t.F_b__97000084 = c__b__97000084; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :100:1
func (t *A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_fn__97000087_A) Invoke_O__O(self any) any { { var i__97000083__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__97000083__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var u__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__97000083__1)); var root_387 any = A_arbace_cpp_run_A_const_24.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = t.F_b__97000084; var arg_391 any; var vec__97000088__3 any; var root_392 any = A_arbace_cpp_run_A_const_68.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A_fn_class); var ifn_394 lang.IFn
															if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_46.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_160, nil, Lit_155); var tmp4 any = t.F_dir; var tmp5 any; var root_400 any = A_arbace_cpp_run_A_const_71.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = u__2; var arg_404 any = A_arbace_cpp_run_A_const_72; if linked_401 == nil { tmp5 = ifn_402.Invoke_O_O__O(arg_403, arg_404) } else { tmp5 = linked_401.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_400, arg_403, arg_404) }; arg_395 = tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5, nil)).Ref()); if linked_393 == nil { vec__97000088__3 = ifn_394.Invoke_O__O(arg_395) } else { vec__97000088__3 = linked_393.(*aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A).Invoke_O_O__O(root_392, arg_395) }
//line :100:1
	var hf__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000088__3, lang.RT_IntCast_J__I_NoInit(0), nil); var hforms__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000088__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_405 any = A_arbace_cpp_run_A_const_73.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_407 lang.IFn

	if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = u__2; if linked_406 == nil { tmp6 = ifn_407.Invoke_O__O(arg_408) } else { tmp6 = linked_406.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_405, arg_408) }
//line :100:1
	var tmp7 any = tmp6; var tmp8 any = A_arbace_cpp_run_A_const_70; var tmp9 any = A_arbace_cpp_run_A_const_74; var tmp10 any; var root_409 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_411 lang.IFn

	if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = hf__4; if linked_410 == nil { tmp10 = ifn_411.Invoke_O__O(arg_412) } else { tmp10 = linked_410.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_409, arg_412) }
//line :100:1
	arg_391 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, hforms__5, tmp9, tmp10))); if linked_388 == nil { ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { linked_388.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }; i__97000083__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__97000083__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_cpp_run_read_lib_A_New() *A_arbace_cpp_run_read_lib_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_cpp_run_read_lib_A) Ctor() {}
//line :104:1
func (t *A_arbace_cpp_run_read_lib_A) Invoke_O_O_O_O_O__O(self, h__0, dir__1, list__2, threads__3 any) any { var lines__5 any; var root_475 any = A_arbace_cpp_run_A_const_39.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_477 lang.IFn; if



	linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any; var fnbody__486 any = A_arbace_cpp_run_read_lib_fn__97000100_A_New(); var tmp1 *jrt.Class; var fncls__485 *jrt.Class = A_arbace_cpp_run_read_lib_fn__97000100_A_fn_class; if fncls__485 == nil { var fncls__485d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_175, false, nil); A_arbace_cpp_run_read_lib_fn__97000100_A_fn_class = fncls__485d; tmp1 = fncls__485d } else { tmp1 = fncls__485 }; arg_478 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__486, tmp1, nil); var arg_479 any; var root_487 any = A_arbace_cpp_run_A_const_43.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = A_arbace_cpp_run_A_const_44.GetRawRoot__O(); var arg_491 any; var root_492 any = A_arbace_cpp_run_A_const_45.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = lang.IFn_Cast(A_arbace_cpp_run_A_const_46.GetRawRoot__O()).Invoke_O__O(list__2); if linked_493 == nil { arg_491 = ifn_494.Invoke_O__O(arg_495) } else { arg_491 = linked_493.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_492, arg_495) }; if linked_488 == nil { arg_479 = ifn_489.Invoke_O_O__O(arg_490, arg_491) } else { arg_479 = linked_488.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_487, arg_490, arg_491) }; if linked_476 == nil { lines__5 = ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { lines__5 = linked_476.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) }; var done__6 any; var root_500 any = /*line :104:1*/A_arbace_cpp_run_A_const_17.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_502 lang.IFn; if




	linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_504 any; var root_505 any = A_arbace_cpp_run_A_const_63.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_505, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_507 lang.IFn; if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any; var root_510 any = A_arbace_cpp_run_A_const_77.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var arg_514 any = A_arbace_cpp_run_A_const_78.GetRawRoot__O(); if linked_511 == nil { arg_508 = ifn_512.Invoke_O_O__O(arg_513, arg_514) } else { arg_508 = linked_511.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_510, arg_513, arg_514) }; var arg_509 any; var root_515 any = A_arbace_cpp_run_A_const_79.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, A_arbace_cpp_run_tsv_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_176), jrt.RefArrayOf(jrt.Object_class, dir__1, nil)).Ref(); if linked_516 == nil { arg_509 = ifn_517.Invoke_O__O(arg_518) } else { arg_509 = linked_516.(*A_arbace_cpp_run_tsv_A).Invoke_O_O__O(root_515, arg_518) }; if linked_506 == nil { arg_504 = ifn_507.Invoke_O_O__O(arg_508, arg_509) } else { arg_504 = linked_506.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_505, arg_508, arg_509) }; if linked_501 == nil { done__6 = ifn_502.Invoke_O_O__O(arg_503, arg_504) } else { done__6 = linked_501.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_500, arg_503, arg_504) }; var todo__7 any; var root_519 any = /*line :104:1*/A_arbace_cpp_run_A_const_62.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_521 lang.IFn; if





	linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any; var root_523 any = A_arbace_cpp_run_A_const_43.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any; var fnbody__533 any = A_arbace_cpp_run_read_lib_fn__97000103_A_New_O(done__6); var tmp2 *jrt.Class; var fncls__532 *jrt.Class = A_arbace_cpp_run_read_lib_fn__97000103_A_fn_class; if fncls__532 == nil { var fncls__532d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_177, false, fnbody__533); A_arbace_cpp_run_read_lib_fn__97000103_A_fn_class = fncls__532d; tmp2 = fncls__532d } else { tmp2 = fncls__532 }; arg_526 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__533, tmp2, nil); var arg_527 any = lines__5; if linked_524 == nil { arg_522 = ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { arg_522 = linked_524.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_523, arg_526, arg_527) }; if linked_520 == nil { todo__7 = ifn_521.Invoke_O__O(arg_522) } else { todo__7 = linked_520.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_519, arg_522) }; var q__8 any = /*line :104:1*/jrt.ConcurrentLinkedQueue_New_Collection(jrt.Collection_Cast(todo__7)); var res__9 any = jrt.ConcurrentHashMap_New(); var k__10 any; var root_534 any = A_arbace_cpp_run_A_const_80.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_536 lang.IFn; if








	linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = A_arbace_cpp_run_A_const_81; if linked_535 == nil { k__10 = ifn_536.Invoke_O__O(arg_537) } else { k__10 = linked_535.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_534, arg_537) }; var workers__11 any; var root_538 any = /*line :104:1*/A_arbace_cpp_run_A_const_82.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_540 lang.IFn; if









	linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any; var iter__1927001039__auto____11 any; var fnbody__727 any = A_arbace_cpp_run_read_lib_iter__97000108__97000112_A_New_O_O_O_O_O_O(k__10, h__0, q__8, dir__1, res__9, todo__7); var tmp3 *jrt.Class; var fncls__726 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000108__97000112_A_fn_class; if fncls__726 == nil { var fncls__726d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_178, false, fnbody__727); A_arbace_cpp_run_read_lib_iter__97000108__97000112_A_fn_class = fncls__726d; tmp3 = fncls__726d } else { tmp3 = fncls__726 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__727, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____11); var tmp5 any; var root_728 any = A_arbace_cpp_run_A_const_97.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = threads__3; if linked_729 == nil { tmp5 = ifn_730.Invoke_O__O(arg_731) } else { tmp5 = linked_729.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_728, arg_731) }; arg_541 = tmp4.Invoke_O__O(tmp5); if linked_539 == nil { workers__11 = ifn_540.Invoke_O__O(arg_541) } else { workers__11 = linked_539.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_538, arg_541) }; var seq_97000136__12 any; var root_1010 any = /*line :104:1*/A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1012 lang.IFn; if


















	linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any = workers__11; if linked_1011 == nil { seq_97000136__12 = ifn_1012.Invoke_O__O(arg_1013) } else { seq_97000136__12 = linked_1011.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1010, arg_1013) }; var chunk_97000137__13 any; var count_97000138__14 int64 = 0; var i_97000139__15 int64 = 0; L1:
//line :104:1
	for {


















		if lang.Numbers_Lt_J_J__Z_NoInit(i_97000139__15, count_97000138__14) { var w__16 any = lang.Indexed_Cast(chunk_97000137__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000139__15)); var root_1154 any = A_arbace_cpp_run_A_const_13.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = w__16; if linked_1155 == nil { ifn_1156.Invoke_O__O(arg_1157) } else { linked_1155.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1154, arg_1157) }; seq_97000136__12, chunk_97000137__13, count_97000138__14, i_97000139__15 = seq_97000136__12, chunk_97000137__13, count_97000138__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000139__15); continue L1 } else { var temp__1927000414__auto____16 any; var root_1014 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = seq_97000136__12; if linked_1015 == nil { temp__1927000414__auto____16 = ifn_1016.Invoke_O__O(arg_1017) } else { temp__1927000414__auto____16 = linked_1015.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1014, arg_1017) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_97000136__17 any = temp__1927000414__auto____16; var tmp6 any; var root_1018 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = seq_97000136__17; if linked_1019 == nil { tmp6 = ifn_1020.Invoke_O__O(arg_1021) } else { tmp6 = linked_1019.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1018, arg_1021) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____18 any; var root_1022 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = seq_97000136__17; if linked_1023 == nil { c__1927000678__auto____18 = ifn_1024.Invoke_O__O(arg_1025) } else { c__1927000678__auto____18 = linked_1023.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1022, arg_1025) }; var tmp7 any; var root_1158 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1160 lang.IFn; if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any = seq_97000136__17; if linked_1159 == nil { tmp7 = ifn_1160.Invoke_O__O(arg_1161) } else { tmp7 = linked_1159.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1158, arg_1161) }; seq_97000136__12, chunk_97000137__13, count_97000138__14, i_97000139__15 = tmp7, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var w__18 any; var root_1026 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1028 lang.IFn; if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = seq_97000136__17; if linked_1027 == nil { w__18 = ifn_1028.Invoke_O__O(arg_1029) } else { w__18 = linked_1027.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1026, arg_1029) }; var root_1162 any = A_arbace_cpp_run_A_const_13.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1162, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1164 lang.IFn; if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any = w__18; if linked_1163 == nil { ifn_1164.Invoke_O__O(arg_1165) } else { linked_1163.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1162, arg_1165) }; var tmp8 any; var root_1166 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = seq_97000136__17; if linked_1167 == nil { tmp8 = ifn_1168.Invoke_O__O(arg_1169) } else { tmp8 = linked_1167.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1166, arg_1169) }; seq_97000136__12, chunk_97000137__13, count_97000138__14, i_97000139__15 = tmp8, nil, 0, 0; continue L1 } } }
//line :104:1
		break L1 }; var rows__12 any; var root_1030 any = A_arbace_cpp_run_A_const_109.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1032 lang.IFn; if



















	linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var arg_1034 any; var root_1035 any = A_arbace_cpp_run_A_const_30.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any; var iter__1927001039__auto____12 any; var fnbody__1123 any = A_arbace_cpp_run_read_lib_iter__97000140__97000144_A_New_O(res__9); var tmp9 *jrt.Class; var fncls__1122 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000140__97000144_A_fn_class; if fncls__1122 == nil { var fncls__1122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_179, false, fnbody__1123); A_arbace_cpp_run_read_lib_iter__97000140__97000144_A_fn_class = fncls__1122d; tmp9 = fncls__1122d } else { tmp9 = fncls__1122 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1123, tmp9, nil); arg_1038 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(done__6); var arg_1039 any; var root_1124 any = A_arbace_cpp_run_A_const_101.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1126 lang.IFn; if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any = res__9; if linked_1125 == nil { arg_1039 = ifn_1126.Invoke_O__O(arg_1127) } else { arg_1039 = linked_1125.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1124, arg_1127) }; if linked_1036 == nil { arg_1034 = ifn_1037.Invoke_O_O__O(arg_1038, arg_1039) } else { arg_1034 = linked_1036.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1035, arg_1038, arg_1039) }; if linked_1031 == nil { rows__12 = ifn_1032.Invoke_O_O__O(arg_1033, arg_1034) } else { rows__12 = linked_1031.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1030, arg_1033, arg_1034) }; var rows__13 any; var root_1128 any = /*line :104:1*/A_arbace_cpp_run_A_const_63.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1128, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1130 lang.IFn; if




















	linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any; var fnbody__1143 any = A_arbace_cpp_run_read_lib_fn__97000156_A_New(); var tmp10 *jrt.Class; var fncls__1142 *jrt.Class = A_arbace_cpp_run_read_lib_fn__97000156_A_fn_class; if fncls__1142 == nil { var fncls__1142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_180, false, nil); A_arbace_cpp_run_read_lib_fn__97000156_A_fn_class = fncls__1142d; tmp10 = fncls__1142d } else { tmp10 = fncls__1142 }; arg_1131 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1143, tmp10, nil); var arg_1132 any = rows__12; if linked_1129 == nil { rows__13 = ifn_1130.Invoke_O_O__O(arg_1131, arg_1132) } else { rows__13 = linked_1129.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1128, arg_1131, arg_1132) }; var tmp11 lang.IFn =
	lang.IFn_Cast(A_arbace_cpp_run_A_const_35.GetRawRoot__O()); var tmp12 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_176), jrt.RefArrayOf(jrt.Object_class, dir__1, nil)).Ref(); var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_74); var tmp14 any; var root_1149 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = Lit_74; var arg_1153 any = rows__13; if linked_1150 == nil { tmp14 = ifn_1151.Invoke_O_O__O(arg_1152, arg_1153) } else { tmp14 = linked_1150.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1149, arg_1152, arg_1153) }; tmp11.Invoke_O_O__O(tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, tmp14, nil)).Ref()); var ok__12 any; var iter__1927001039__auto____12_2 any; var fnbody__797 any = /*line :104:1*/A_arbace_cpp_run_read_lib_iter__97000158__97000162_A_New(); var tmp15 *jrt.Class; var fncls__796 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000158__97000162_A_fn_class; if






















	fncls__796 == nil { var fncls__796d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_181, false, nil); A_arbace_cpp_run_read_lib_iter__97000158__97000162_A_fn_class = fncls__796d; tmp15 = fncls__796d } else { tmp15 = fncls__796 }; iter__1927001039__auto____12_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__797, tmp15, nil); var tmp16 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____12_2); var tmp17 any; var root_1170 any = A_arbace_cpp_run_A_const_79.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, A_arbace_cpp_run_tsv_A_fn_class); var ifn_1172 lang.IFn; if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_176), jrt.RefArrayOf(jrt.Object_class, dir__1, nil)).Ref(); if linked_1171 == nil { tmp17 = ifn_1172.Invoke_O__O(arg_1173) } else { tmp17 = linked_1171.(*A_arbace_cpp_run_tsv_A).Invoke_O_O__O(root_1170, arg_1173) }; ok__12 = tmp16.Invoke_O__O(tmp17); var ix__13 any; var root_798 any = /*line :104:1*/A_arbace_cpp_run_A_const_17.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_800 lang.IFn; if























	linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = lang.IFn_Cast(A_arbace_cpp_run_A_const_98.GetRawRoot__O()).Invoke__O(); var arg_802 any; var iter__1927001039__auto____13 any; var fnbody__929 any = A_arbace_cpp_run_read_lib_iter__97000174__97000178_A_New_O(dir__1); var tmp18 *jrt.Class; var fncls__928 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000174__97000178_A_fn_class; if
	fncls__928 == nil { var fncls__928d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_182, false, fnbody__929); A_arbace_cpp_run_read_lib_iter__97000174__97000178_A_fn_class = fncls__928d; tmp18 = fncls__928d } else { tmp18 = fncls__928 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__929, tmp18, nil); arg_802 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(ok__12); if /*line :128:1*/ linked_799 == nil { ix__13 = ifn_800.Invoke_O_O__O(arg_801, arg_802) } else { ix__13 = linked_799.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_798, arg_801, arg_802) };




	lang.IFn_Cast(A_arbace_cpp_run_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_146), jrt.RefArrayOf(jrt.Object_class, dir__1, nil)).Ref(), lang.IFn_Cast(A_arbace_cpp_run_A_const_61.GetRawRoot__O()).Invoke_O__O(ix__13)); var bad__14 any; var iter__1927001039__auto____14 any; var fnbody__1005 any = /*line :104:1*/A_arbace_cpp_run_read_lib_iter__97000184__97000188_A_New(); var tmp19 *jrt.Class; var fncls__1004 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000184__97000188_A_fn_class; if





























	fncls__1004 == nil { var fncls__1004d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_183, false, nil); A_arbace_cpp_run_read_lib_iter__97000184__97000188_A_fn_class = fncls__1004d; tmp19 = fncls__1004d } else { tmp19 = fncls__1004 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1005, tmp19, nil); var tmp20 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____14); var tmp21 any; var root_1183 any = A_arbace_cpp_run_A_const_79.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1183, A_arbace_cpp_run_tsv_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_176), jrt.RefArrayOf(jrt.Object_class, dir__1, nil)).Ref(); if linked_1184 == nil { tmp21 = ifn_1185.Invoke_O__O(arg_1186) } else { tmp21 = linked_1184.(*A_arbace_cpp_run_tsv_A).Invoke_O_O__O(root_1183, arg_1186) }; bad__14 = tmp20.Invoke_O__O(tmp21); var seq_97000200__15 any; var root_1187 any = /*line :104:1*/A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1189 lang.IFn; if






























	linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = bad__14; if linked_1188 == nil { seq_97000200__15 = ifn_1189.Invoke_O__O(arg_1190) } else { seq_97000200__15 = linked_1188.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1187, arg_1190) }; var chunk_97000201__16 any; var count_97000202__17 int64 = 0; var i_97000203__18 int64 = 0; L2:
//line :104:1
	for {






























		if lang.Numbers_Lt_J_J__Z_NoInit(i_97000203__18, count_97000202__17) { var vec__97000204__19 any = lang.Indexed_Cast(chunk_97000201__16).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000203__18)); var n__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000204__19, lang.RT_IntCast_J__I_NoInit(0), nil); var e__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000204__19, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_cpp_run_A_const_91.GetRawRoot__O()).Invoke_O_O_O__O(Lit_184, n__20, e__21); seq_97000200__15, chunk_97000201__16, count_97000202__17, i_97000203__18 = seq_97000200__15, chunk_97000201__16, count_97000202__17, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000203__18); continue L2 } else { var temp__1927000414__auto____19 any; var root_1191 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any = seq_97000200__15; if linked_1192 == nil { temp__1927000414__auto____19 = ifn_1193.Invoke_O__O(arg_1194) } else { temp__1927000414__auto____19 = linked_1192.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1191, arg_1194) }; if jrt.J2g_Truth(temp__1927000414__auto____19) { var seq_97000200__20 any = temp__1927000414__auto____19; var tmp22 any; var root_1195 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = seq_97000200__20; if linked_1196 == nil { tmp22 = ifn_1197.Invoke_O__O(arg_1198) } else { tmp22 = linked_1196.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1195, arg_1198) }; if jrt.J2g_Truth(tmp22) { var c__1927000678__auto____21 any; var root_1199 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = seq_97000200__20; if linked_1200 == nil { c__1927000678__auto____21 = ifn_1201.Invoke_O__O(arg_1202) } else { c__1927000678__auto____21 = linked_1200.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1199, arg_1202) }; var tmp23 any; var root_1222 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1222, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1224 lang.IFn; if linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 any = seq_97000200__20; if linked_1223 == nil { tmp23 = ifn_1224.Invoke_O__O(arg_1225) } else { tmp23 = linked_1223.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1222, arg_1225) }; seq_97000200__15, chunk_97000201__16, count_97000202__17, i_97000203__18 = tmp23, c__1927000678__auto____21, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____21))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__97000207__21 any; var root_1203 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = seq_97000200__20; if linked_1204 == nil { vec__97000207__21 = ifn_1205.Invoke_O__O(arg_1206) } else { vec__97000207__21 = linked_1204.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1203, arg_1206) }; var n__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000207__21, lang.RT_IntCast_J__I_NoInit(0), nil); var e__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000207__21, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_cpp_run_A_const_91.GetRawRoot__O()).Invoke_O_O_O__O(Lit_184, n__22, e__23); var tmp24 any; var root_1232 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = seq_97000200__20; if linked_1233 == nil { tmp24 = ifn_1234.Invoke_O__O(arg_1235) } else { tmp24 = linked_1233.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1232, arg_1235) }; seq_97000200__15, chunk_97000201__16, count_97000202__17, i_97000203__18 = tmp24, nil, 0, 0; continue L2 } } }
//line :104:1
		break L2 };































	lang.IFn_Cast(A_arbace_cpp_run_A_const_91.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(Lit_185, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ok__12)).Ref(), Lit_186, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(lines__5)).Ref(), Lit_187, dir__1); var root_1006 any =
	A_arbace_cpp_run_A_const_108.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = bad__14; if linked_1007 == nil { return ifn_1008.Invoke_O__O(arg_1009) } else { return linked_1007.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1006, arg_1009) } }
//line :108:1
func A_arbace_cpp_run_read_lib_fn__97000100_A_New() *A_arbace_cpp_run_read_lib_fn__97000100_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_fn__97000100_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_cpp_run_read_lib_fn__97000100_A) Ctor() {}
//line :108:1
func (t *A_arbace_cpp_run_read_lib_fn__97000100_A) Invoke_O_O__O(self, p1__97000098_SHARP___1 any) any { var root_480 any = A_arbace_cpp_run_A_const_40.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = p1__97000098_SHARP___1; var arg_484 any = A_arbace_cpp_run_A_const_76; if linked_481 == nil { return ifn_482.Invoke_O_O__O(arg_483, arg_484) } else { return linked_481.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_480, arg_483, arg_484) } }

func A_arbace_cpp_run_read_lib_fn__97000103_A_New_O(p0 any) *A_arbace_cpp_run_read_lib_fn__97000103_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_fn__97000103_A{}; t.Ctor_O(p0); return t }
//line :110:1
func (t *A_arbace_cpp_run_read_lib_fn__97000103_A) Ctor_O(c__done any) { t.F_done = c__done }
//line :110:1
func (t *A_arbace_cpp_run_read_lib_fn__97000103_A) Invoke_O_O__O(self, p__97000102__1 any) any { var vec__97000104__2 any = p__97000102__1; var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000104__2, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 any; var root_528 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = lang.RT_Get_O_O__O_NoInit(t.F_done, n__3); if linked_529 == nil { tmp1 = ifn_530.Invoke_O__O(arg_531) } else { tmp1 = linked_529.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_528, arg_531) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_67, tmp1)).Ref() }



func A_arbace_cpp_run_read_lib_iter__97000108__97000112_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_cpp_run_read_lib_iter__97000108__97000112_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000108__97000112_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :114:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_A) Ctor_O_O_O_O_O_O(c__k, c__h, c__q, c__dir, c__res, c__todo any) { t.F_k = c__k; t.F_h = c__h; t.F_q = c__q; t.F_dir = c__dir; t.F_res = c__res; t.F_todo = c__todo }
//line :114:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_A) Invoke_O_O__O(self, s__97000109__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__725 any = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_A_New_O_O_O_O_O_O_O_O(t.F_k, t.F_h, t.F_q, t.F_dir, t.F_res, s__97000109__1, t.F_todo, self); var tmp2 *jrt.Class; var fncls__724 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_A_fn_class; if fncls__724 == nil { var fncls__724d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_188, false, fnbody__725); A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_A_fn_class = fncls__724d; tmp2 = fncls__724d } else { tmp2 = fncls__724 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__725, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :114:1
func A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :114:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_A) Ctor_O_O_O_O_O_O_O_O(c__k, c__h, c__q, c__dir, c__res, c__s__97000109, c__todo, c__iter__97000108 any) { t.F_k = c__k; t.F_h = c__h; t.F_q = c__q; t.F_dir = c__dir; t.F_res = c__res; t.F_s__97000109 = c__s__97000109; t.F_todo = c__todo; t.F_iter__97000108 = c__iter__97000108 }
//line :114:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_A) Invoke_O__O(self any) any { { var s__97000109__1 any; var t_ any = t.F_s__97000109; t.F_s__97000109 = nil; s__97000109__1 = t_; for { var temp__1927000414__auto____2 any; var root_542 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = s__97000109__1; if linked_543 == nil { temp__1927000414__auto____2 = ifn_544.Invoke_O__O(arg_545) } else { temp__1927000414__auto____2 = linked_543.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_542, arg_545) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__97000109__3 any = temp__1927000414__auto____2; var tmp1 any; var root_546 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = s__97000109__3; if linked_547 == nil { tmp1 = ifn_548.Invoke_O__O(arg_549) } else { tmp1 = linked_547.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_546, arg_549) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_550 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = s__97000109__3; if linked_551 == nil { c__1927001037__auto____4 = ifn_552.Invoke_O__O(arg_553) } else { c__1927001037__auto____4 = linked_551.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_550, arg_553) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__97000111__6 any; var root_554 any = A_arbace_cpp_run_A_const_23.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_555 == nil { b__97000111__6 = ifn_556.Invoke_O__O(arg_557) } else { b__97000111__6 = linked_555.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_554, arg_557) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__626 any = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_A_New_O_O_O_O_O_O_I_O_O(t.F_k, t.F_h, t.F_q, t.F_dir, t.F_res, b__97000111__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_todo); var tmp3 *jrt.Class; var fncls__625 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_A_fn_class; if fncls__625 == nil { var fncls__625d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_189, false, fnbody__626); A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_A_fn_class = fncls__625d; tmp3 = fncls__625d } else { tmp3 = fncls__625 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__626, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_627 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_629 lang.IFn; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any; var root_632 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_634 lang.IFn; if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = b__97000111__6; if linked_633 == nil { arg_630 = ifn_634.Invoke_O__O(arg_635) } else { arg_630 = linked_633.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_632, arg_635) }; var arg_631 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__97000108); var tmp5 any; var root_636 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_638 lang.IFn; if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any = s__97000109__3; if linked_637 == nil { tmp5 = ifn_638.Invoke_O__O(arg_639) } else { tmp5 = linked_637.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_636, arg_639) }; arg_631 = tmp4.Invoke_O__O(tmp5); if linked_628 == nil { return ifn_629.Invoke_O_O__O(arg_630, arg_631) } else { return linked_628.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_627, arg_630, arg_631) } } else { var root_640 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any; var root_645 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = b__97000111__6; if linked_646 == nil { arg_643 = ifn_647.Invoke_O__O(arg_648) } else { arg_643 = linked_646.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_645, arg_648) }; var arg_644 any; if linked_641 == nil { return ifn_642.Invoke_O_O__O(arg_643, arg_644) } else { return linked_641.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_640, arg_643, arg_644) } } } else { var ___4 any; var root_649 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_651 lang.IFn; _ = ___4; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = s__97000109__3; if linked_650 == nil { ___4 = ifn_651.Invoke_O__O(arg_652) } else { ___4 = linked_650.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_649, arg_652) }; var root_653 any = A_arbace_cpp_run_A_const_28.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any; var root_658 any = A_arbace_cpp_run_A_const_83.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_660 lang.IFn
													if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any; var fnbody__719 any = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_A_New_O_O_O_O_O_O(t.F_k, t.F_h, t.F_q, t.F_dir, t.F_res, t.F_todo); var tmp6 *jrt.Class; var fncls__718 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_A_fn_class; if fncls__718 == nil { var fncls__718d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_190, false, fnbody__719); A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_A_fn_class = fncls__718d; tmp6 = fncls__718d } else { tmp6 = fncls__718 }; arg_661 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__719, tmp6, nil); if linked_659 == nil { arg_656 = ifn_660.Invoke_O__O(arg_661) } else { arg_656 = linked_659.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_658, arg_661) }
//line :114:1
	var arg_657 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__97000108); var tmp8 any; var root_720 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = s__97000109__3; if linked_721 == nil { tmp8 = ifn_722.Invoke_O__O(arg_723) } else { tmp8 = linked_721.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_720, arg_723) }; arg_657 = tmp7.Invoke_O__O(tmp8); if linked_654 == nil { return ifn_655.Invoke_O_O__O(arg_656, arg_657) } else { return linked_654.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_653, arg_656, arg_657) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :114:1
func A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_A_New_O_O_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5 any, p6 int32, p7, p8 any) *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_A{}; t.Ctor_O_O_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :114:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_A) Ctor_O_O_O_O_O_O_I_O_O(c__k, c__h, c__q, c__dir, c__res, c__b__97000111 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__todo any) { t.F_k = c__k; t.F_h = c__h; t.F_q = c__q; t.F_dir = c__dir; t.F_res = c__res; t.F_b__97000111 = c__b__97000111; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_todo = c__todo }
//line :114:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_A) Invoke_O__O(self any) any { { var i__97000110__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__97000110__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ___2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__97000110__1)); var root_558 any = A_arbace_cpp_run_A_const_24.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_560 lang.IFn; _ = ___2; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = t.F_b__97000111; var arg_562 any; var root_563 any = A_arbace_cpp_run_A_const_83.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_565 lang.IFn
															if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any; var fnbody__624 any = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_A_New_O_O_O_O_O_O(t.F_k, t.F_h, t.F_q, t.F_dir, t.F_res, t.F_todo); var tmp2 *jrt.Class; var fncls__623 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_A_fn_class; if fncls__623 == nil { var fncls__623d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_191, false, fnbody__624); A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_A_fn_class = fncls__623d; tmp2 = fncls__623d } else { tmp2 = fncls__623 }; arg_566 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__624, tmp2, nil); if linked_564 == nil { arg_562 = ifn_565.Invoke_O__O(arg_566) } else { arg_562 = linked_564.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_563, arg_566) }
//line :114:1
	if linked_559 == nil { ifn_560.Invoke_O_O__O(arg_561, arg_562) } else { linked_559.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_558, arg_561, arg_562) }; i__97000110__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__97000110__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :115:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_A) Ctor_O_O_O_O_O_O(c__k, c__h, c__q, c__dir, c__res, c__todo any) { t.F_k = c__k; t.F_h = c__h; t.F_q = c__q; t.F_dir = c__dir; t.F_res = c__res; t.F_todo = c__todo }
//line :115:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_A) Invoke_O__O(self any) any { for { L2: for { var temp__1927000414__auto____1 any = jrt.NN(jrt.ConcurrentLinkedQueue_Cast(t.F_q)).Poll__O()

	if jrt.J2g_Truth(temp__1927000414__auto____1) { var vec__97000116__2 any = temp__1927000414__auto____1; var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000116__2, lang.RT_IntCast_J__I_NoInit(0), nil); var p__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000116__2, lang.RT_IntCast_J__I_NoInit(1), nil); var t0__5 int64 = jrt.System_NanoTime__J(); var e__6 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__575 any = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000119_A_New_O_O_O_O(t.F_h, n__3, t.F_dir, p__4); var tmp2 *jrt.Class
		var fncls__574 /*line :117:1*/*jrt.Class = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000119_A_fn_class

		if fncls__574 == nil { var fncls__574d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_192, false, fnbody__575); A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000119_A_fn_class = fncls__574d; tmp2 = fncls__574d } else { tmp2 = fncls__574 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__575, tmp2, nil); e__6 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
		var tmp3 jrt.ConcurrentHashMap_I = jrt.ConcurrentHashMap_Cast(t.F_res); var tmp4 any; var root_576 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = Lit_25; var arg_580 any; var tmp5 *jrt.String; if jrt.J2g_Truth(e__6) { tmp5 = Lit_193 } else { tmp5 = Lit_67 }; var tmp6 any = tmp5.Ref(); var tmp7 any; var root_581 any = A_arbace_cpp_run_A_const_85.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, A_arbace_cpp_run_clean_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any; var or__1927000174__auto____7 any = e__6; if jrt.J2g_Truth(or__1927000174__auto____7) { arg_584 = or__1927000174__auto____7 } else { arg_584 = Lit_62 }; if linked_582 == nil { tmp7 = ifn_583.Invoke_O__O(arg_584) } else { tmp7 = linked_582.(*A_arbace_cpp_run_clean_A).Invoke_O_O__O(root_581, arg_584) }; arg_580 = lang.Tuple_Create_O_O_O_O__IPersistentVector(n__3, tmp6, tmp7, lang.IFn_Cast(A_arbace_cpp_run_A_const_86.GetRawRoot__O()).Invoke_O_O__O(Lit_194, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__5), 1.0e9)).Ref())); if linked_577 == nil { tmp4 = ifn_578.Invoke_O_O__O(arg_579, arg_580) } else { tmp4 = linked_577.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_576, arg_579, arg_580) }; tmp3.Put_O_O__O(n__3, tmp4)
//line :117:1
		var i__7 any; var root_590 any = A_arbace_cpp_run_A_const_87.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_592 lang.IFn



		if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = t.F_k; var arg_594 any = A_arbace_cpp_run_A_const_88.GetRawRoot__O(); if linked_591 == nil { i__7 = ifn_592.Invoke_O_O__O(arg_593, arg_594) } else { i__7 = linked_591.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_590, arg_593, arg_594) }; var tmp8 bool; var na_595 any; var root_596 any = A_arbace_cpp_run_A_const_89.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_mod_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = i__7; var arg_600 any = A_arbace_cpp_run_A_const_90; if linked_597 == nil { na_595 = ifn_598.Invoke_O_O__O(arg_599, arg_600) } else { na_595 = linked_597.(*aot_arbace_core.A_arbace_core_mod_A).Invoke_O_O_O__O(root_596, arg_599, arg_600) }; if jrt.Long_InstanceOf(na_595) { var n0_601 int64 = jrt.NN(jrt.Long_Cast(na_595)).LongValue__J(); tmp8 = n0_601 == 0 } else { if jrt.Double_InstanceOf(na_595) { var n0_601_2 float64 = jrt.NN(jrt.Double_Cast(na_595)).DoubleValue__D(); tmp8 = n0_601_2 == 0.0 } else { tmp8 = lang.Numbers_IsZero_O__Z_NoInit(na_595) } }; if tmp8 { var root_614 any = A_arbace_cpp_run_A_const_93.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_94.GetRawRoot__O()); var tmp10 any = A_arbace_cpp_run_A_const_95; var arg_617 any = tmp9.Invoke_O_O__O(tmp10, A_arbace_cpp_run_A_const_96.Get__O()); if linked_615 == nil { ifn_616.Invoke_O__O(arg_617) } else { linked_615.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_614, arg_617) }; var tmp11 *lang.Compiler_AOTFn; var fnbody__613 any = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000121_A_New_O_O(i__7, t.F_todo); var tmp12 *jrt.Class; var fncls__612 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000121_A_fn_class; if fncls__612 == nil { var fncls__612d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_195, false, fnbody__613); A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000121_A_fn_class = fncls__612d; tmp12 = fncls__612d } else { tmp12 = fncls__612 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__613, tmp12, nil); Up_Compiler_AOTFn_IFn(tmp11).Invoke__O() }
		continue L2 } else {
//line :117:1
			return nil } } }; /*line :115:1*/panic("j2g: unreachable") }
//line :115:1
func A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :115:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_A) Ctor_O_O_O_O_O_O(c__k, c__h, c__q, c__dir, c__res, c__todo any) { t.F_k = c__k; t.F_h = c__h; t.F_q = c__q; t.F_dir = c__dir; t.F_res = c__res; t.F_todo = c__todo }
//line :115:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_A) Invoke_O__O(self any) any { for { L2: for { var temp__1927000414__auto____1 any = jrt.NN(jrt.ConcurrentLinkedQueue_Cast(t.F_q)).Poll__O()

	if jrt.J2g_Truth(temp__1927000414__auto____1) { var vec__97000126__2 any = temp__1927000414__auto____1; var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000126__2, lang.RT_IntCast_J__I_NoInit(0), nil); var p__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000126__2, lang.RT_IntCast_J__I_NoInit(1), nil); var t0__5 int64 = jrt.System_NanoTime__J(); var e__6 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__670 any = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000129_A_New_O_O_O_O(t.F_h, n__3, t.F_dir, p__4); var tmp2 *jrt.Class
		var fncls__669 /*line :117:1*/*jrt.Class = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000129_A_fn_class

		if fncls__669 == nil { var fncls__669d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_198, false, fnbody__670); A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000129_A_fn_class = fncls__669d; tmp2 = fncls__669d } else { tmp2 = fncls__669 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__670, tmp2, nil); e__6 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
		var tmp3 jrt.ConcurrentHashMap_I = jrt.ConcurrentHashMap_Cast(t.F_res); var tmp4 any; var root_671 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = Lit_25; var arg_675 any; var tmp5 *jrt.String; if jrt.J2g_Truth(e__6) { tmp5 = Lit_193 } else { tmp5 = Lit_67 }; var tmp6 any = tmp5.Ref(); var tmp7 any; var root_676 any = A_arbace_cpp_run_A_const_85.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, A_arbace_cpp_run_clean_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any; var or__1927000174__auto____7 any = e__6; if jrt.J2g_Truth(or__1927000174__auto____7) { arg_679 = or__1927000174__auto____7 } else { arg_679 = Lit_62 }; if linked_677 == nil { tmp7 = ifn_678.Invoke_O__O(arg_679) } else { tmp7 = linked_677.(*A_arbace_cpp_run_clean_A).Invoke_O_O__O(root_676, arg_679) }; arg_675 = lang.Tuple_Create_O_O_O_O__IPersistentVector(n__3, tmp6, tmp7, lang.IFn_Cast(A_arbace_cpp_run_A_const_86.GetRawRoot__O()).Invoke_O_O__O(Lit_194, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__5), 1.0e9)).Ref())); if linked_672 == nil { tmp4 = ifn_673.Invoke_O_O__O(arg_674, arg_675) } else { tmp4 = linked_672.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_671, arg_674, arg_675) }; tmp3.Put_O_O__O(n__3, tmp4)
//line :117:1
		var i__7 any; var root_685 any = A_arbace_cpp_run_A_const_87.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_685, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_687 lang.IFn



		if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = t.F_k; var arg_689 any = A_arbace_cpp_run_A_const_88.GetRawRoot__O(); if linked_686 == nil { i__7 = ifn_687.Invoke_O_O__O(arg_688, arg_689) } else { i__7 = linked_686.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_685, arg_688, arg_689) }; var tmp8 bool; var na_690 any; var root_691 any = A_arbace_cpp_run_A_const_89.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_mod_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = i__7; var arg_695 any = A_arbace_cpp_run_A_const_90; if linked_692 == nil { na_690 = ifn_693.Invoke_O_O__O(arg_694, arg_695) } else { na_690 = linked_692.(*aot_arbace_core.A_arbace_core_mod_A).Invoke_O_O_O__O(root_691, arg_694, arg_695) }; if jrt.Long_InstanceOf(na_690) { var n0_696 int64 = jrt.NN(jrt.Long_Cast(na_690)).LongValue__J(); tmp8 = n0_696 == 0 } else { if jrt.Double_InstanceOf(na_690) { var n0_696_2 float64 = jrt.NN(jrt.Double_Cast(na_690)).DoubleValue__D(); tmp8 = n0_696_2 == 0.0 } else { tmp8 = lang.Numbers_IsZero_O__Z_NoInit(na_690) } }; if tmp8 { var root_709 any = A_arbace_cpp_run_A_const_93.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_94.GetRawRoot__O()); var tmp10 any = A_arbace_cpp_run_A_const_95; var arg_712 any = tmp9.Invoke_O_O__O(tmp10, A_arbace_cpp_run_A_const_96.Get__O()); if linked_710 == nil { ifn_711.Invoke_O__O(arg_712) } else { linked_710.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_709, arg_712) }; var tmp11 *lang.Compiler_AOTFn; var fnbody__708 any = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000131_A_New_O_O(i__7, t.F_todo); var tmp12 *jrt.Class; var fncls__707 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000131_A_fn_class; if fncls__707 == nil { var fncls__707d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_199, false, fnbody__708); A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000131_A_fn_class = fncls__707d; tmp12 = fncls__707d } else { tmp12 = fncls__707 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__708, tmp12, nil); Up_Compiler_AOTFn_IFn(tmp11).Invoke__O() }
		continue L2 } else {
//line :117:1
			return nil } } }; /*line :115:1*/panic("j2g: unreachable") }



func A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000119_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000119_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000119_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :119:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000119_A) Ctor_O_O_O_O(c__h, c__n, c__dir, c__p any) { t.F_h = c__h; t.F_n = c__n; t.F_dir = c__dir; t.F_p = c__p }
//line :119:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000119_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_567 any = A_arbace_cpp_run_A_const_84.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, A_arbace_cpp_run_read_one_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any; var t_ any = t.F_h; t.F_h = nil; arg_570 = t_; var arg_571 any; var t__2 any = t.F_dir; t.F_dir = nil; arg_571 = t__2; var arg_572 any; var t__3 any = t.F_n; t.F_n = nil; arg_572 = t__3; var arg_573 any; var t__4 any = t.F_p; t.F_p = nil; arg_573 = t__4; if linked_568 == nil { tmp1 = ifn_569.Invoke_O_O_O_O__O(arg_570, arg_571, arg_572, arg_573) } else { tmp1 = linked_568.(*A_arbace_cpp_run_read_one_A).Invoke_O_O_O_O_O__O(root_567, arg_570, arg_571, arg_572, arg_573) } }; return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; tmp1 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_196, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3)).Ref() } }; return tmp1 }
//line :119:1
func A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000129_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000129_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000129_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :119:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000129_A) Ctor_O_O_O_O(c__h, c__n, c__dir, c__p any) { t.F_h = c__h; t.F_n = c__n; t.F_dir = c__dir; t.F_p = c__p }
//line :119:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000129_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_662 any = A_arbace_cpp_run_A_const_84.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_662, A_arbace_cpp_run_read_one_A_fn_class); var ifn_664 lang.IFn; if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any; var t_ any = t.F_h; t.F_h = nil; arg_665 = t_; var arg_666 any; var t__2 any = t.F_dir; t.F_dir = nil; arg_666 = t__2; var arg_667 any; var t__3 any = t.F_n; t.F_n = nil; arg_667 = t__3; var arg_668 any; var t__4 any = t.F_p; t.F_p = nil; arg_668 = t__4; if linked_663 == nil { tmp1 = ifn_664.Invoke_O_O_O_O__O(arg_665, arg_666, arg_667, arg_668) } else { tmp1 = linked_663.(*A_arbace_cpp_run_read_one_A).Invoke_O_O_O_O_O__O(root_662, arg_665, arg_666, arg_667, arg_668) } }; return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; tmp1 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_196, nil), jrt.RefArrayOf(jrt.Object_class, nil, e__3)).Ref() } }; return tmp1 }

func A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000121_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000121_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000121_A{}; t.Ctor_O_O(p0, p1); return t }
//line :121:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000121_A) Ctor_O_O(c__i, c__todo any) { t.F_i = c__i; t.F_todo = c__todo }
//line :121:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000121_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_91.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_i; t.F_i = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_todo; t.F_todo = nil; tmp5 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_185, tmp4, Lit_197, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp5)).Ref()) }; return nil }(); var root_609 any = A_arbace_cpp_run_A_const_92.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; if linked_610 == nil { ifn_611.Invoke__O() } else { linked_610.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_609) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :121:1
func A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000131_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000131_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000131_A{}; t.Ctor_O_O(p0, p1); return t }
//line :121:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000131_A) Ctor_O_O(c__i, c__todo any) { t.F_i = c__i; t.F_todo = c__todo }
//line :121:1
func (t *A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000131_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_91.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_i; t.F_i = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_todo; t.F_todo = nil; tmp5 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_185, tmp4, Lit_197, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp5)).Ref()) }; return nil }(); var root_704 any = A_arbace_cpp_run_A_const_92.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_704, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_706 lang.IFn; if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; if linked_705 == nil { ifn_706.Invoke__O() } else { linked_705.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_704) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }


func A_arbace_cpp_run_read_lib_iter__97000140__97000144_A_New_O(p0 any) *A_arbace_cpp_run_read_lib_iter__97000140__97000144_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000140__97000144_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_cpp_run_read_lib_iter__97000140__97000144_A) Ctor_O(c__res any) { t.F_res = c__res }
//line :124:1
func (t *A_arbace_cpp_run_read_lib_iter__97000140__97000144_A) Invoke_O_O__O(self, s__97000141__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1121 any = A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_A_New_O_O_O(s__97000141__1, self, t.F_res); var tmp2 *jrt.Class; var fncls__1120 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_A_fn_class; if fncls__1120 == nil { var fncls__1120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_200, false, fnbody__1121); A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_A_fn_class = fncls__1120d; tmp2 = fncls__1120d } else { tmp2 = fncls__1120 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1121, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :124:1
func A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :124:1
func (t *A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_A) Ctor_O_O_O(c__s__97000141, c__iter__97000140, c__res any) { t.F_s__97000141 = c__s__97000141; t.F_iter__97000140 = c__iter__97000140; t.F_res = c__res }
//line :124:1
func (t *A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_A) Invoke_O__O(self any) any { { var s__97000141__1 any; var t_ any = t.F_s__97000141; t.F_s__97000141 = nil; s__97000141__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1040 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = s__97000141__1; if linked_1041 == nil { temp__1927000414__auto____2 = ifn_1042.Invoke_O__O(arg_1043) } else { temp__1927000414__auto____2 = linked_1041.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1040, arg_1043) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__97000141__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1044 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1046 lang.IFn; if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = s__97000141__3; if linked_1045 == nil { tmp1 = ifn_1046.Invoke_O__O(arg_1047) } else { tmp1 = linked_1045.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1044, arg_1047) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1048 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = s__97000141__3; if linked_1049 == nil { c__1927001037__auto____4 = ifn_1050.Invoke_O__O(arg_1051) } else { c__1927001037__auto____4 = linked_1049.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1048, arg_1051) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__97000143__6 any; var root_1052 any = A_arbace_cpp_run_A_const_23.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1054 lang.IFn; if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1053 == nil { b__97000143__6 = ifn_1054.Invoke_O__O(arg_1055) } else { b__97000143__6 = linked_1053.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1052, arg_1055) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1071 any = A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_fn__97000146_A_New_O_O_I_O(t.F_res, b__97000143__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1070 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_fn__97000146_A_fn_class; if fncls__1070 == nil { var fncls__1070d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_201, false, fnbody__1071); A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_fn__97000146_A_fn_class = fncls__1070d; tmp3 = fncls__1070d } else { tmp3 = fncls__1070 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1071, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1072 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_1073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1072, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1074 lang.IFn; if linked_1073 == nil { ifn_1074 = lang.IFn_Cast(root_1072) } else { ifn_1074 = nil }; var arg_1075 any; var root_1077 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1079 lang.IFn; if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = b__97000143__6; if linked_1078 == nil { arg_1075 = ifn_1079.Invoke_O__O(arg_1080) } else { arg_1075 = linked_1078.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1077, arg_1080) }; var arg_1076 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__97000140); var tmp5 any; var root_1081 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = s__97000141__3; if linked_1082 == nil { tmp5 = ifn_1083.Invoke_O__O(arg_1084) } else { tmp5 = linked_1082.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1081, arg_1084) }; arg_1076 = tmp4.Invoke_O__O(tmp5); if linked_1073 == nil { return ifn_1074.Invoke_O_O__O(arg_1075, arg_1076) } else { return linked_1073.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1072, arg_1075, arg_1076) } } else { var root_1085 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any; var root_1090 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any = b__97000143__6; if linked_1091 == nil { arg_1088 = ifn_1092.Invoke_O__O(arg_1093) } else { arg_1088 = linked_1091.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1090, arg_1093) }; var arg_1089 any; if linked_1086 == nil { return ifn_1087.Invoke_O_O__O(arg_1088, arg_1089) } else { return linked_1086.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1085, arg_1088, arg_1089) } } } else { var vec__97000151__4 any; var root_1094 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1094, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1096 lang.IFn; if linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any = s__97000141__3; if linked_1095 == nil { vec__97000151__4 = ifn_1096.Invoke_O__O(arg_1097) } else { vec__97000151__4 = linked_1095.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1094, arg_1097) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000151__4, lang.RT_IntCast_J__I_NoInit(0), nil); var r__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000151__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_1098 any = A_arbace_cpp_run_A_const_110.GetRawRoot__O(); var linked_1099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1098, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1100 lang.IFn; if linked_1099 == nil { ifn_1100 = lang.IFn_Cast(root_1098) } else { ifn_1100 = nil }; var arg_1101 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ConcurrentHashMap_Cast(t.F_res).ContainsKey_O__Z(n__5)).Ref(); if linked_1099 == nil { tmp6 = ifn_1100.Invoke_O__O(arg_1101) } else { tmp6 = linked_1099.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1098, arg_1101) }; if jrt.J2g_Truth(tmp6) { var root_1102 any = A_arbace_cpp_run_A_const_28.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1104 lang.IFn; if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any; var root_1107 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = Lit_25; var arg_1111 any = r__6; if linked_1108 == nil { arg_1105 = ifn_1109.Invoke_O_O__O(arg_1110, arg_1111) } else { arg_1105 = linked_1108.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1107, arg_1110, arg_1111) }; var arg_1106 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__97000140); var tmp8 any; var root_1112 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1114 lang.IFn; if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any = s__97000141__3; if linked_1113 == nil { tmp8 = ifn_1114.Invoke_O__O(arg_1115) } else { tmp8 = linked_1113.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1112, arg_1115) }; arg_1106 = tmp7.Invoke_O__O(tmp8); if linked_1103 == nil { return ifn_1104.Invoke_O_O__O(arg_1105, arg_1106) } else { return linked_1103.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1102, arg_1105, arg_1106) } } else { var tmp9 any; var root_1116 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = s__97000141__3; if linked_1117 == nil { tmp9 = ifn_1118.Invoke_O__O(arg_1119) } else { tmp9 = linked_1117.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1116, arg_1119) }; s__97000141__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :124:1
func A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_fn__97000146_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_fn__97000146_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_fn__97000146_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :124:1
func (t *A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_fn__97000146_A) Ctor_O_O_I_O(c__res, c__b__97000143 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_res = c__res; t.F_b__97000143 = c__b__97000143; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :124:1
func (t *A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_fn__97000146_A) Invoke_O__O(self any) any { { var i__97000142__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__97000142__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__97000147__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__97000142__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000147__2, lang.RT_IntCast_J__I_NoInit(0), nil); var r__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000147__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_1056 any = A_arbace_cpp_run_A_const_110.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ConcurrentHashMap_Cast(t.F_res).ContainsKey_O__Z(n__3)).Ref(); if linked_1057 == nil { tmp2 = ifn_1058.Invoke_O__O(arg_1059) } else { tmp2 = linked_1057.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1056, arg_1059) }; if jrt.J2g_Truth(tmp2) { var root_1060 any = A_arbace_cpp_run_A_const_24.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1060, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = t.F_b__97000143; var arg_1064 any; var root_1065 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = Lit_25; var arg_1069 any = r__4; if linked_1066 == nil { arg_1064 = ifn_1067.Invoke_O_O__O(arg_1068, arg_1069) } else { arg_1064 = linked_1066.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1065, arg_1068, arg_1069) }; if linked_1061 == nil { ifn_1062.Invoke_O_O__O(arg_1063, arg_1064) } else { linked_1061.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1060, arg_1063, arg_1064) }; i__97000142__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__97000142__1); continue L1 } else { i__97000142__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__97000142__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_cpp_run_read_lib_fn__97000156_A_New() *A_arbace_cpp_run_read_lib_fn__97000156_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_fn__97000156_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_cpp_run_read_lib_fn__97000156_A) Ctor() {}
//line :125:1
func (t *A_arbace_cpp_run_read_lib_fn__97000156_A) Invoke_O_O__O(self, p1__97000099_SHARP___1 any) any { var tmp1 any; var root_1133 any = A_arbace_cpp_run_A_const_111.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any = p1__97000099_SHARP___1; if linked_1134 == nil { tmp1 = ifn_1135.Invoke_O__O(arg_1136) } else { tmp1 = linked_1134.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1133, arg_1136) }; if jrt.J2g_Truth(tmp1) { return p1__97000099_SHARP___1 } else { var root_1137 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1137, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1139 lang.IFn; if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = Lit_25; var arg_1141 any = p1__97000099_SHARP___1; if linked_1138 == nil { return ifn_1139.Invoke_O_O__O(arg_1140, arg_1141) } else { return linked_1138.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1137, arg_1140, arg_1141) } } }

func A_arbace_cpp_run_read_lib_iter__97000158__97000162_A_New() *A_arbace_cpp_run_read_lib_iter__97000158__97000162_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000158__97000162_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_cpp_run_read_lib_iter__97000158__97000162_A) Ctor() {}
//line :127:1
func (t *A_arbace_cpp_run_read_lib_iter__97000158__97000162_A) Invoke_O_O__O(self, s__97000159__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__795 any = A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_A_New_O_O(s__97000159__1, self); var tmp2 *jrt.Class; var fncls__794 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_A_fn_class; if fncls__794 == nil { var fncls__794d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_202, false, fnbody__795); A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_A_fn_class = fncls__794d; tmp2 = fncls__794d } else { tmp2 = fncls__794 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__795, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :127:1
func A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_A{}; t.Ctor_O_O(p0, p1); return t }
//line :127:1
func (t *A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_A) Ctor_O_O(c__s__97000159, c__iter__97000158 any) { t.F_s__97000159 = c__s__97000159; t.F_iter__97000158 = c__iter__97000158 }
//line :127:1
func (t *A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_A) Invoke_O__O(self any) any { { var s__97000159__1 any; var t_ any = t.F_s__97000159; t.F_s__97000159 = nil; s__97000159__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_732 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = s__97000159__1; if linked_733 == nil { temp__1927000414__auto____2 = ifn_734.Invoke_O__O(arg_735) } else { temp__1927000414__auto____2 = linked_733.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_732, arg_735) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__97000159__3 any = temp__1927000414__auto____2; var tmp1 any; var root_736 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_738 lang.IFn; if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = s__97000159__3; if linked_737 == nil { tmp1 = ifn_738.Invoke_O__O(arg_739) } else { tmp1 = linked_737.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_736, arg_739) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_740 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any = s__97000159__3; if linked_741 == nil { c__1927001037__auto____4 = ifn_742.Invoke_O__O(arg_743) } else { c__1927001037__auto____4 = linked_741.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_740, arg_743) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__97000161__6 any; var root_744 any = A_arbace_cpp_run_A_const_23.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_746 lang.IFn; if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_745 == nil { b__97000161__6 = ifn_746.Invoke_O__O(arg_747) } else { b__97000161__6 = linked_745.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_744, arg_747) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__754 any = A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_fn__97000164_A_New_O_I_O(b__97000161__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__753 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_fn__97000164_A_fn_class; if fncls__753 == nil { var fncls__753d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_203, false, fnbody__754); A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_fn__97000164_A_fn_class = fncls__753d; tmp3 = fncls__753d } else { tmp3 = fncls__753 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__754, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_755 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any; var root_760 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = b__97000161__6; if linked_761 == nil { arg_758 = ifn_762.Invoke_O__O(arg_763) } else { arg_758 = linked_761.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_760, arg_763) }; var arg_759 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__97000158); var tmp5 any; var root_764 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = s__97000159__3; if linked_765 == nil { tmp5 = ifn_766.Invoke_O__O(arg_767) } else { tmp5 = linked_765.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_764, arg_767) }; arg_759 = tmp4.Invoke_O__O(tmp5); if linked_756 == nil { return ifn_757.Invoke_O_O__O(arg_758, arg_759) } else { return linked_756.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_755, arg_758, arg_759) } } else { var root_768 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any; var root_773 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = b__97000161__6; if linked_774 == nil { arg_771 = ifn_775.Invoke_O__O(arg_776) } else { arg_771 = linked_774.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_773, arg_776) }; var arg_772 any; if linked_769 == nil { return ifn_770.Invoke_O_O__O(arg_771, arg_772) } else { return linked_769.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_768, arg_771, arg_772) } } } else { var vec__97000169__4 any; var root_777 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = s__97000159__3; if linked_778 == nil { vec__97000169__4 = ifn_779.Invoke_O__O(arg_780) } else { vec__97000169__4 = linked_778.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_777, arg_780) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000169__4, lang.RT_IntCast_J__I_NoInit(0), nil); var st__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000169__4, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Util_Equiv_O_O__Z_NoInit(st__6, Lit_67) { var root_781 any = A_arbace_cpp_run_A_const_28.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = n__5; var arg_785 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__97000158); var tmp7 any; var root_786 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = s__97000159__3; if linked_787 == nil { tmp7 = ifn_788.Invoke_O__O(arg_789) } else { tmp7 = linked_787.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_786, arg_789) }; arg_785 = tmp6.Invoke_O__O(tmp7); if linked_782 == nil { return ifn_783.Invoke_O_O__O(arg_784, arg_785) } else { return linked_782.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_781, arg_784, arg_785) } } else { var tmp8 any; var root_790 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = s__97000159__3; if linked_791 == nil { tmp8 = ifn_792.Invoke_O__O(arg_793) } else { tmp8 = linked_791.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_790, arg_793) }; s__97000159__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :127:1
func A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_fn__97000164_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_fn__97000164_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_fn__97000164_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :127:1
func (t *A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_fn__97000164_A) Ctor_O_I_O(c__b__97000161 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__97000161 = c__b__97000161; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :127:1
func (t *A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_fn__97000164_A) Invoke_O__O(self any) any { { var i__97000160__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__97000160__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__97000165__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__97000160__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000165__2, lang.RT_IntCast_J__I_NoInit(0), nil); var st__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000165__2, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Util_Equiv_O_O__Z_NoInit(st__4, Lit_67) { var root_748 any = A_arbace_cpp_run_A_const_24.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = t.F_b__97000161; var arg_752 any = n__3; if linked_749 == nil { ifn_750.Invoke_O_O__O(arg_751, arg_752) } else { linked_749.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_748, arg_751, arg_752) }; i__97000160__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__97000160__1); continue L1 } else { i__97000160__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__97000160__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_cpp_run_read_lib_iter__97000174__97000178_A_New_O(p0 any) *A_arbace_cpp_run_read_lib_iter__97000174__97000178_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000174__97000178_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_cpp_run_read_lib_iter__97000174__97000178_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :129:1
func (t *A_arbace_cpp_run_read_lib_iter__97000174__97000178_A) Invoke_O_O__O(self, s__97000175__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__927 any = A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_A_New_O_O_O(t.F_dir, s__97000175__1, self); var tmp2 *jrt.Class; var fncls__926 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_A_fn_class; if fncls__926 == nil { var fncls__926d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_204, false, fnbody__927); A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_A_fn_class = fncls__926d; tmp2 = fncls__926d } else { tmp2 = fncls__926 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__927, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :129:1
func A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :129:1
func (t *A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_A) Ctor_O_O_O(c__dir, c__s__97000175, c__iter__97000174 any) { t.F_dir = c__dir; t.F_s__97000175 = c__s__97000175; t.F_iter__97000174 = c__iter__97000174 }
//line :129:1
func (t *A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_A) Invoke_O__O(self any) any { { var s__97000175__1 any; var t_ any = t.F_s__97000175; t.F_s__97000175 = nil; s__97000175__1 = t_; for { var temp__1927000414__auto____2 any; var root_806 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = s__97000175__1; if linked_807 == nil { temp__1927000414__auto____2 = ifn_808.Invoke_O__O(arg_809) } else { temp__1927000414__auto____2 = linked_807.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_806, arg_809) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__97000175__3 any = temp__1927000414__auto____2; var tmp1 any; var root_810 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_812 lang.IFn; if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any = s__97000175__3; if linked_811 == nil { tmp1 = ifn_812.Invoke_O__O(arg_813) } else { tmp1 = linked_811.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_810, arg_813) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_814 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = s__97000175__3; if linked_815 == nil { c__1927001037__auto____4 = ifn_816.Invoke_O__O(arg_817) } else { c__1927001037__auto____4 = linked_815.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_814, arg_817) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__97000177__6 any; var root_818 any = A_arbace_cpp_run_A_const_23.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_819 == nil { b__97000177__6 = ifn_820.Invoke_O__O(arg_821) } else { b__97000177__6 = linked_819.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_818, arg_821) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__859 any = A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_fn__97000180_A_New_O_O_I_O(t.F_dir, b__97000177__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__858 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_fn__97000180_A_fn_class; if fncls__858 == nil { var fncls__858d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_205, false, fnbody__859); A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_fn__97000180_A_fn_class = fncls__858d; tmp3 = fncls__858d } else { tmp3 = fncls__858 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__859, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_860 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any; var root_865 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = b__97000177__6; if linked_866 == nil { arg_863 = ifn_867.Invoke_O__O(arg_868) } else { arg_863 = linked_866.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_865, arg_868) }; var arg_864 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__97000174); var tmp5 any; var root_869 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = s__97000175__3; if linked_870 == nil { tmp5 = ifn_871.Invoke_O__O(arg_872) } else { tmp5 = linked_870.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_869, arg_872) }; arg_864 = tmp4.Invoke_O__O(tmp5); if linked_861 == nil { return ifn_862.Invoke_O_O__O(arg_863, arg_864) } else { return linked_861.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_860, arg_863, arg_864) } } else { var root_873 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any; var root_878 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = b__97000177__6; if linked_879 == nil { arg_876 = ifn_880.Invoke_O__O(arg_881) } else { arg_876 = linked_879.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_878, arg_881) }; var arg_877 any; if linked_874 == nil { return ifn_875.Invoke_O_O__O(arg_876, arg_877) } else { return linked_874.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_873, arg_876, arg_877) } } } else { var n__4 any; var root_882 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_884 lang.IFn; if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = s__97000175__3; if linked_883 == nil { n__4 = ifn_884.Invoke_O__O(arg_885) } else { n__4 = linked_883.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_882, arg_885) }; var root_886 any = A_arbace_cpp_run_A_const_28.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any; var u__5 any; var root_891 any = A_arbace_cpp_run_A_const_99.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, A_arbace_cpp_run_load_unit_A_fn_class); var ifn_893 lang.IFn
													if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = t.F_dir; var arg_895 any = n__4; if linked_892 == nil { u__5 = ifn_893.Invoke_O_O__O(arg_894, arg_895) } else { u__5 = linked_892.(*A_arbace_cpp_run_load_unit_A).Invoke_O_O_O__O(root_891, arg_894, arg_895) }
//line :129:1
	var all__6 any; var root_896 any = A_arbace_cpp_run_A_const_30.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_896, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_898 lang.IFn

	if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = A_arbace_cpp_run_A_const_70.Invoke_O__O(u__5); var arg_900 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_100.GetRawRoot__O()); var tmp7 any = A_arbace_cpp_run_A_const_70; var tmp8 any; var root_906 any = A_arbace_cpp_run_A_const_101.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = A_arbace_cpp_run_A_const_65.Invoke_O__O(u__5); if linked_907 == nil { tmp8 = ifn_908.Invoke_O__O(arg_909) } else { tmp8 = linked_907.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_906, arg_909) }; arg_900 = tmp6.Invoke_O_O__O(tmp7, tmp8); if linked_897 == nil { all__6 = ifn_898.Invoke_O_O__O(arg_899, arg_900) } else { all__6 = linked_897.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_896, arg_899, arg_900) }
//line :129:1
	var tmp9 any = A_arbace_cpp_run_A_const_102; var tmp10 any; var root_910 any = A_arbace_cpp_run_A_const_103.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, aot_arbace_c_musl.A_arbace_c_musl_unit_defs_A_fn_class); var ifn_912 lang.IFn


	if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = A_arbace_cpp_run_A_const_70.Invoke_O__O(u__5); if linked_911 == nil { tmp10 = ifn_912.Invoke_O__O(arg_913) } else { tmp10 = linked_911.(*aot_arbace_c_musl.A_arbace_c_musl_unit_defs_A).Invoke_O_O__O(root_910, arg_913) }
//line :129:1
	var tmp11 any = tmp10; var tmp12 any = A_arbace_cpp_run_A_const_104; var tmp13 any; var root_914 any = A_arbace_cpp_run_A_const_105.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_916 lang.IFn


	if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any; var root_918 any = A_arbace_cpp_run_A_const_106.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_c_musl.A_arbace_c_musl_refs_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = all__6; if linked_919 == nil { arg_917 = ifn_920.Invoke_O__O(arg_921) } else { arg_917 = linked_919.(*aot_arbace_c_musl.A_arbace_c_musl_refs_A).Invoke_O_O__O(root_918, arg_921) }; if linked_915 == nil { tmp13 = ifn_916.Invoke_O__O(arg_917) } else { tmp13 = linked_915.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_914, arg_917) }
//line :129:1
	arg_889 = lang.Tuple_Create_O_O__IPersistentVector(n__4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp11, tmp12, tmp13))); var arg_890 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__97000174); var tmp15 any; var root_922 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = s__97000175__3; if linked_923 == nil { tmp15 = ifn_924.Invoke_O__O(arg_925) } else { tmp15 = linked_923.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_922, arg_925) }; arg_890 = tmp14.Invoke_O__O(tmp15); if linked_887 == nil { return ifn_888.Invoke_O_O__O(arg_889, arg_890) } else { return linked_887.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_886, arg_889, arg_890) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :129:1
func A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_fn__97000180_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_fn__97000180_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_fn__97000180_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :129:1
func (t *A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_fn__97000180_A) Ctor_O_O_I_O(c__dir, c__b__97000177 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_dir = c__dir; t.F_b__97000177 = c__b__97000177; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :129:1
func (t *A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_fn__97000180_A) Invoke_O__O(self any) any { { var i__97000176__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__97000176__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__97000176__1)); var root_822 any = A_arbace_cpp_run_A_const_24.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = t.F_b__97000177; var arg_826 any; var u__3 any; var root_827 any = A_arbace_cpp_run_A_const_99.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, A_arbace_cpp_run_load_unit_A_fn_class); var ifn_829 lang.IFn
															if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = t.F_dir; var arg_831 any = n__2; if linked_828 == nil { u__3 = ifn_829.Invoke_O_O__O(arg_830, arg_831) } else { u__3 = linked_828.(*A_arbace_cpp_run_load_unit_A).Invoke_O_O_O__O(root_827, arg_830, arg_831) }
//line :129:1
	var all__4 any; var root_832 any = A_arbace_cpp_run_A_const_30.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_834 lang.IFn

	if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = A_arbace_cpp_run_A_const_70.Invoke_O__O(u__3); var arg_836 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_100.GetRawRoot__O()); var tmp3 any = A_arbace_cpp_run_A_const_70; var tmp4 any; var root_842 any = A_arbace_cpp_run_A_const_101.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = A_arbace_cpp_run_A_const_65.Invoke_O__O(u__3); if linked_843 == nil { tmp4 = ifn_844.Invoke_O__O(arg_845) } else { tmp4 = linked_843.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_842, arg_845) }; arg_836 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_833 == nil { all__4 = ifn_834.Invoke_O_O__O(arg_835, arg_836) } else { all__4 = linked_833.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_832, arg_835, arg_836) }
//line :129:1
	var tmp5 any = A_arbace_cpp_run_A_const_102; var tmp6 any; var root_846 any = A_arbace_cpp_run_A_const_103.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_c_musl.A_arbace_c_musl_unit_defs_A_fn_class); var ifn_848 lang.IFn


	if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = A_arbace_cpp_run_A_const_70.Invoke_O__O(u__3); if linked_847 == nil { tmp6 = ifn_848.Invoke_O__O(arg_849) } else { tmp6 = linked_847.(*aot_arbace_c_musl.A_arbace_c_musl_unit_defs_A).Invoke_O_O__O(root_846, arg_849) }
//line :129:1
	var tmp7 any = tmp6; var tmp8 any = A_arbace_cpp_run_A_const_104; var tmp9 any; var root_850 any = A_arbace_cpp_run_A_const_105.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_852 lang.IFn


	if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any; var root_854 any = A_arbace_cpp_run_A_const_106.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, aot_arbace_c_musl.A_arbace_c_musl_refs_A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any = all__4; if linked_855 == nil { arg_853 = ifn_856.Invoke_O__O(arg_857) } else { arg_853 = linked_855.(*aot_arbace_c_musl.A_arbace_c_musl_refs_A).Invoke_O_O__O(root_854, arg_857) }; if linked_851 == nil { tmp9 = ifn_852.Invoke_O__O(arg_853) } else { tmp9 = linked_851.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_850, arg_853) }
//line :129:1
	arg_826 = lang.Tuple_Create_O_O__IPersistentVector(n__2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp7, tmp8, tmp9))); if linked_823 == nil { ifn_824.Invoke_O_O__O(arg_825, arg_826) } else { linked_823.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_822, arg_825, arg_826) }; i__97000176__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__97000176__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_cpp_run_read_lib_iter__97000184__97000188_A_New() *A_arbace_cpp_run_read_lib_iter__97000184__97000188_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000184__97000188_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_cpp_run_read_lib_iter__97000184__97000188_A) Ctor() {}
//line :134:1
func (t *A_arbace_cpp_run_read_lib_iter__97000184__97000188_A) Invoke_O_O__O(self, s__97000185__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1003 any = A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_A_New_O_O(s__97000185__1, self); var tmp2 *jrt.Class; var fncls__1002 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_A_fn_class; if fncls__1002 == nil { var fncls__1002d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_206, false, fnbody__1003); A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_A_fn_class = fncls__1002d; tmp2 = fncls__1002d } else { tmp2 = fncls__1002 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1003, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :134:1
func A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_A{}; t.Ctor_O_O(p0, p1); return t }
//line :134:1
func (t *A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_A) Ctor_O_O(c__s__97000185, c__iter__97000184 any) { t.F_s__97000185 = c__s__97000185; t.F_iter__97000184 = c__iter__97000184 }
//line :134:1
func (t *A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_A) Invoke_O__O(self any) any { { var s__97000185__1 any; var t_ any = t.F_s__97000185; t.F_s__97000185 = nil; s__97000185__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_930 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = s__97000185__1; if linked_931 == nil { temp__1927000414__auto____2 = ifn_932.Invoke_O__O(arg_933) } else { temp__1927000414__auto____2 = linked_931.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_930, arg_933) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__97000185__3 any = temp__1927000414__auto____2; var tmp1 any; var root_934 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = s__97000185__3; if linked_935 == nil { tmp1 = ifn_936.Invoke_O__O(arg_937) } else { tmp1 = linked_935.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_934, arg_937) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_938 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = s__97000185__3; if linked_939 == nil { c__1927001037__auto____4 = ifn_940.Invoke_O__O(arg_941) } else { c__1927001037__auto____4 = linked_939.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_938, arg_941) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__97000187__6 any; var root_942 any = A_arbace_cpp_run_A_const_23.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_943 == nil { b__97000187__6 = ifn_944.Invoke_O__O(arg_945) } else { b__97000187__6 = linked_943.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_942, arg_945) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__957 any = A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_fn__97000190_A_New_O_I_O(b__97000187__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__956 *jrt.Class = A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_fn__97000190_A_fn_class; if fncls__956 == nil { var fncls__956d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_207, false, fnbody__957); A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_fn__97000190_A_fn_class = fncls__956d; tmp3 = fncls__956d } else { tmp3 = fncls__956 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__957, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_958 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any; var root_963 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = b__97000187__6; if linked_964 == nil { arg_961 = ifn_965.Invoke_O__O(arg_966) } else { arg_961 = linked_964.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_963, arg_966) }; var arg_962 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__97000184); var tmp5 any; var root_967 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = s__97000185__3; if linked_968 == nil { tmp5 = ifn_969.Invoke_O__O(arg_970) } else { tmp5 = linked_968.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_967, arg_970) }; arg_962 = tmp4.Invoke_O__O(tmp5); if linked_959 == nil { return ifn_960.Invoke_O_O__O(arg_961, arg_962) } else { return linked_959.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_958, arg_961, arg_962) } } else { var root_971 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any; var root_976 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = b__97000187__6; if linked_977 == nil { arg_974 = ifn_978.Invoke_O__O(arg_979) } else { arg_974 = linked_977.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_976, arg_979) }; var arg_975 any; if linked_972 == nil { return ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { return linked_972.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_971, arg_974, arg_975) } } } else { var vec__97000195__4 any; var root_980 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = s__97000185__3; if linked_981 == nil { vec__97000195__4 = ifn_982.Invoke_O__O(arg_983) } else { vec__97000195__4 = linked_981.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_980, arg_983) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000195__4, lang.RT_IntCast_J__I_NoInit(0), nil); var st__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000195__4, lang.RT_IntCast_J__I_NoInit(1), nil); var e__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000195__4, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp6 any; var root_984 any = A_arbace_cpp_run_A_const_107.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = st__6; var arg_988 any = Lit_67; if linked_985 == nil { tmp6 = ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { tmp6 = linked_985.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_984, arg_987, arg_988) }; if jrt.J2g_Truth(tmp6) { var root_989 any = A_arbace_cpp_run_A_const_28.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, e__7); var arg_993 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__97000184); var tmp8 any; var root_994 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = s__97000185__3; if linked_995 == nil { tmp8 = ifn_996.Invoke_O__O(arg_997) } else { tmp8 = linked_995.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_994, arg_997) }; arg_993 = tmp7.Invoke_O__O(tmp8); if linked_990 == nil { return ifn_991.Invoke_O_O__O(arg_992, arg_993) } else { return linked_990.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_989, arg_992, arg_993) } } else { var tmp9 any; var root_998 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = s__97000185__3; if linked_999 == nil { tmp9 = ifn_1000.Invoke_O__O(arg_1001) } else { tmp9 = linked_999.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_998, arg_1001) }; s__97000185__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :134:1
func A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_fn__97000190_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_fn__97000190_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_fn__97000190_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :134:1
func (t *A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_fn__97000190_A) Ctor_O_I_O(c__b__97000187 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__97000187 = c__b__97000187; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :134:1
func (t *A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_fn__97000190_A) Invoke_O__O(self any) any { { var i__97000186__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__97000186__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__97000191__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__97000186__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000191__2, lang.RT_IntCast_J__I_NoInit(0), nil); var st__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000191__2, lang.RT_IntCast_J__I_NoInit(1), nil); var e__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000191__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp2 any; var root_946 any = A_arbace_cpp_run_A_const_107.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = st__4; var arg_950 any = Lit_67; if linked_947 == nil { tmp2 = ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { tmp2 = linked_947.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_946, arg_949, arg_950) }; if jrt.J2g_Truth(tmp2) { var root_951 any = A_arbace_cpp_run_A_const_24.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = t.F_b__97000187; var arg_955 any = lang.Tuple_Create_O_O__IPersistentVector(n__3, e__5); if linked_952 == nil { ifn_953.Invoke_O_O__O(arg_954, arg_955) } else { linked_952.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_951, arg_954, arg_955) }; i__97000186__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__97000186__1); continue L1 } else { i__97000186__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__97000186__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_cpp_run_library_A_New() *A_arbace_cpp_run_library_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_library_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_cpp_run_library_A) Ctor() {}
//line :141:1
func (t *A_arbace_cpp_run_library_A) Invoke_O_O__O(self, dir__0 any) any { var ix__2 any; var root_1236 any = A_arbace_cpp_run_A_const_69.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_1238 lang.IFn; if


	linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = lang.IFn_Cast(A_arbace_cpp_run_A_const_46.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_146), jrt.RefArrayOf(jrt.Object_class, dir__0, nil)).Ref()); if linked_1237 == nil { ix__2 = ifn_1238.Invoke_O__O(arg_1239) } else { ix__2 = linked_1237.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_1236, arg_1239) }; var by__3 any = /*line :141:1*/jrt.HashMap_New(); var seq_97000211__4 any; var root_1244 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1246 lang.IFn; if




	linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = ix__2; if linked_1245 == nil { seq_97000211__4 = ifn_1246.Invoke_O__O(arg_1247) } else { seq_97000211__4 = linked_1245.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1244, arg_1247) }; var chunk_97000212__5 any; var count_97000213__6 int64 = 0; var i_97000214__7 int64 = 0; L1:
//line :141:1
	for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_97000214__7, count_97000213__6) { var vec__97000223__8 any = lang.Indexed_Cast(chunk_97000212__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000214__7)); var s__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000223__8, lang.RT_IntCast_J__I_NoInit(0), nil); var map__97000226__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000223__8, lang.RT_IntCast_J__I_NoInit(1), nil); var map__97000226__11 any; if lang.ISeq_InstanceOf(map__97000226__10) { var tmp1 any; var root_1248 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any = map__97000226__10; if linked_1249 == nil { tmp1 = ifn_1250.Invoke_O__O(arg_1251) } else { tmp1 = linked_1249.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1248, arg_1251) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1252 any = A_arbace_cpp_run_A_const_116.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1254 lang.IFn; if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any = map__97000226__10; if linked_1253 == nil { tmp2 = ifn_1254.Invoke_O__O(arg_1255) } else { tmp2 = linked_1253.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1252, arg_1255) }; map__97000226__11 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1256 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = map__97000226__10; if linked_1257 == nil { tmp3 = ifn_1258.Invoke_O__O(arg_1259) } else { tmp3 = linked_1257.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1256, arg_1259) }; if jrt.J2g_Truth(tmp3) { var root_1260 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = map__97000226__10; if linked_1261 == nil { map__97000226__11 = ifn_1262.Invoke_O__O(arg_1263) } else { map__97000226__11 = linked_1261.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1260, arg_1263) } } else { map__97000226__11 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__97000226__11 = map__97000226__10 }; var defs__12 any = lang.RT_Get_O_O__O_NoInit(map__97000226__11, A_arbace_cpp_run_A_const_102); var seq_97000219__13 any; var root_1296 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1296, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1298 lang.IFn; if linked_1297 == nil { ifn_1298 = lang.IFn_Cast(root_1296) } else { ifn_1298 = nil }; var arg_1299 any = defs__12; if linked_1297 == nil { seq_97000219__13 = ifn_1298.Invoke_O__O(arg_1299) } else { seq_97000219__13 = linked_1297.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1296, arg_1299) }; var chunk_97000220__14 any; var count_97000221__15 int64 = 0; var i_97000222__16 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_97000222__16, count_97000221__15) { var vec__97000228__17 any = lang.Indexed_Cast(chunk_97000220__14).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000222__16)); var n__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000228__17, lang.RT_IntCast_J__I_NoInit(0), nil); var d__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000228__17, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp4 jrt.HashMap_I = jrt.HashMap_Cast(by__3); var tmp5 any; var root_1316 any = A_arbace_cpp_run_A_const_15.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1316, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1318 lang.IFn

			if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any; var or__1927000174__auto____20 any = jrt.HashMap_Cast(by__3).Get_O__O(n__18); if jrt.J2g_Truth(or__1927000174__auto____20) { arg_1319 = or__1927000174__auto____20 } else { arg_1319 = lang.PersistentVector_EMPTY.Ref() }; var arg_1320 any = lang.Tuple_Create_O_O__IPersistentVector(s__9, A_arbace_cpp_run_A_const_117.Invoke_O__O(d__19)); if linked_1317 == nil { tmp5 = ifn_1318.Invoke_O_O__O(arg_1319, arg_1320) } else { tmp5 = linked_1317.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1316, arg_1319, arg_1320) }; tmp4.Put_O_O__O(n__18, tmp5)
//line :146:1
			seq_97000219__13, chunk_97000220__14, count_97000221__15, i_97000222__16 = seq_97000219__13, chunk_97000220__14, count_97000221__15, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000222__16); continue L2 } else { var temp__1927000414__auto____17 any; var root_1300 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1300, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1302 lang.IFn; if linked_1301 == nil { ifn_1302 = lang.IFn_Cast(root_1300) } else { ifn_1302 = nil }; var arg_1303 any = seq_97000219__13; if linked_1301 == nil { temp__1927000414__auto____17 = ifn_1302.Invoke_O__O(arg_1303) } else { temp__1927000414__auto____17 = linked_1301.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1300, arg_1303) }; if jrt.J2g_Truth(temp__1927000414__auto____17) { var seq_97000219__18 any = temp__1927000414__auto____17; var tmp6 any; var root_1304 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1306 lang.IFn; if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = seq_97000219__18; if linked_1305 == nil { tmp6 = ifn_1306.Invoke_O__O(arg_1307) } else { tmp6 = linked_1305.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1304, arg_1307) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____19 any; var root_1308 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1310 lang.IFn; if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any = seq_97000219__18; if linked_1309 == nil { c__1927000678__auto____19 = ifn_1310.Invoke_O__O(arg_1311) } else { c__1927000678__auto____19 = linked_1309.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1308, arg_1311) }; var tmp7 any; var root_1321 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1323 lang.IFn; if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any = seq_97000219__18; if linked_1322 == nil { tmp7 = ifn_1323.Invoke_O__O(arg_1324) } else { tmp7 = linked_1322.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1321, arg_1324) }; seq_97000219__13, chunk_97000220__14, count_97000221__15, i_97000222__16 = tmp7, c__1927000678__auto____19, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____19))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__97000231__19 any; var root_1312 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1314 lang.IFn; if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = seq_97000219__18; if linked_1313 == nil { vec__97000231__19 = ifn_1314.Invoke_O__O(arg_1315) } else { vec__97000231__19 = linked_1313.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1312, arg_1315) }; var n__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000231__19, lang.RT_IntCast_J__I_NoInit(0), nil); var d__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000231__19, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp8 jrt.HashMap_I = jrt.HashMap_Cast(by__3); var tmp9 any; var root_1325 any = A_arbace_cpp_run_A_const_15.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1325, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1327 lang.IFn

				if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any; var or__1927000174__auto____22 any = jrt.HashMap_Cast(by__3).Get_O__O(n__20); if jrt.J2g_Truth(or__1927000174__auto____22) { arg_1328 = or__1927000174__auto____22 } else { arg_1328 = lang.PersistentVector_EMPTY.Ref() }; var arg_1329 any = lang.Tuple_Create_O_O__IPersistentVector(s__9, A_arbace_cpp_run_A_const_117.Invoke_O__O(d__21)); if linked_1326 == nil { tmp9 = ifn_1327.Invoke_O_O__O(arg_1328, arg_1329) } else { tmp9 = linked_1326.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1325, arg_1328, arg_1329) }; tmp8.Put_O_O__O(n__20, tmp9)
//line :146:1
				var tmp10 any; var root_1330 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = seq_97000219__18; if linked_1331 == nil { tmp10 = ifn_1332.Invoke_O__O(arg_1333) } else { tmp10 = linked_1331.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1330, arg_1333) }; seq_97000219__13, chunk_97000220__14, count_97000221__15, i_97000222__16 = tmp10, nil, 0, 0; continue L2 } } }; break L2 }; seq_97000211__4, chunk_97000212__5, count_97000213__6, i_97000214__7 = seq_97000211__4, chunk_97000212__5, count_97000213__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000214__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_1264 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any = seq_97000211__4; if linked_1265 == nil { temp__1927000414__auto____8 = ifn_1266.Invoke_O__O(arg_1267) } else { temp__1927000414__auto____8 = linked_1265.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1264, arg_1267) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_97000211__9 any = temp__1927000414__auto____8; var tmp11 any; var root_1268 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1268, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1270 lang.IFn; if linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any = seq_97000211__9; if linked_1269 == nil { tmp11 = ifn_1270.Invoke_O__O(arg_1271) } else { tmp11 = linked_1269.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1268, arg_1271) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____10 any; var root_1272 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1272, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1274 lang.IFn; if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any = seq_97000211__9; if linked_1273 == nil { c__1927000678__auto____10 = ifn_1274.Invoke_O__O(arg_1275) } else { c__1927000678__auto____10 = linked_1273.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1272, arg_1275) }; var tmp12 any; var root_1334 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = seq_97000211__9; if linked_1335 == nil { tmp12 = ifn_1336.Invoke_O__O(arg_1337) } else { tmp12 = linked_1335.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1334, arg_1337) }; seq_97000211__4, chunk_97000212__5, count_97000213__6, i_97000214__7 = tmp12, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__97000234__10 any; var root_1276 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1276, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1278 lang.IFn; if linked_1277 == nil { ifn_1278 = lang.IFn_Cast(root_1276) } else { ifn_1278 = nil }; var arg_1279 any = seq_97000211__9; if linked_1277 == nil { vec__97000234__10 = ifn_1278.Invoke_O__O(arg_1279) } else { vec__97000234__10 = linked_1277.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1276, arg_1279) }; var s__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000234__10, lang.RT_IntCast_J__I_NoInit(0), nil); var map__97000237__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000234__10, lang.RT_IntCast_J__I_NoInit(1), nil); var map__97000237__13 any; if lang.ISeq_InstanceOf(map__97000237__12) { var tmp13 any; var root_1280 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = map__97000237__12; if linked_1281 == nil { tmp13 = ifn_1282.Invoke_O__O(arg_1283) } else { tmp13 = linked_1281.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1280, arg_1283) }; if jrt.J2g_Truth(tmp13) { var tmp14 any; var root_1284 any = A_arbace_cpp_run_A_const_116.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = map__97000237__12; if linked_1285 == nil { tmp14 = ifn_1286.Invoke_O__O(arg_1287) } else { tmp14 = linked_1285.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1284, arg_1287) }; map__97000237__13 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp14)).Ref() } else { var tmp15 any; var root_1288 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1288, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1290 lang.IFn; if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any = map__97000237__12; if linked_1289 == nil { tmp15 = ifn_1290.Invoke_O__O(arg_1291) } else { tmp15 = linked_1289.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1288, arg_1291) }; if jrt.J2g_Truth(tmp15) { var root_1292 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1292, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1294 lang.IFn; if linked_1293 == nil { ifn_1294 = lang.IFn_Cast(root_1292) } else { ifn_1294 = nil }; var arg_1295 any = map__97000237__12; if linked_1293 == nil { map__97000237__13 = ifn_1294.Invoke_O__O(arg_1295) } else { map__97000237__13 = linked_1293.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1292, arg_1295) } } else { map__97000237__13 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__97000237__13 = map__97000237__12 }; var defs__14 any = lang.RT_Get_O_O__O_NoInit(map__97000237__13, A_arbace_cpp_run_A_const_102); var seq_97000215__15 any; var root_1338 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = defs__14; if linked_1339 == nil { seq_97000215__15 = ifn_1340.Invoke_O__O(arg_1341) } else { seq_97000215__15 = linked_1339.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1338, arg_1341) }; var chunk_97000216__16 any; var count_97000217__17 int64 = 0; var i_97000218__18 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_97000218__18, count_97000217__17) { var vec__97000239__19 any = lang.Indexed_Cast(chunk_97000216__16).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000218__18)); var n__20_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000239__19, lang.RT_IntCast_J__I_NoInit(0), nil); var d__21_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000239__19, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp16 jrt.HashMap_I = jrt.HashMap_Cast(by__3); var tmp17 any; var root_1358 any = A_arbace_cpp_run_A_const_15.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1360 lang.IFn

					if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any; var or__1927000174__auto____22_2 any = jrt.HashMap_Cast(by__3).Get_O__O(n__20_2); if jrt.J2g_Truth(or__1927000174__auto____22_2) { arg_1361 = or__1927000174__auto____22_2 } else { arg_1361 = lang.PersistentVector_EMPTY.Ref() }; var arg_1362 any = lang.Tuple_Create_O_O__IPersistentVector(s__11, A_arbace_cpp_run_A_const_117.Invoke_O__O(d__21_2)); if linked_1359 == nil { tmp17 = ifn_1360.Invoke_O_O__O(arg_1361, arg_1362) } else { tmp17 = linked_1359.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1358, arg_1361, arg_1362) }; tmp16.Put_O_O__O(n__20_2, tmp17)
//line :146:1
					seq_97000215__15, chunk_97000216__16, count_97000217__17, i_97000218__18 = seq_97000215__15, chunk_97000216__16, count_97000217__17, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000218__18); continue L3 } else { var temp__1927000414__auto____19 any; var root_1342 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = seq_97000215__15; if linked_1343 == nil { temp__1927000414__auto____19 = ifn_1344.Invoke_O__O(arg_1345) } else { temp__1927000414__auto____19 = linked_1343.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1342, arg_1345) }; if jrt.J2g_Truth(temp__1927000414__auto____19) { var seq_97000215__20 any = temp__1927000414__auto____19; var tmp18 any; var root_1346 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1348 lang.IFn; if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = seq_97000215__20; if linked_1347 == nil { tmp18 = ifn_1348.Invoke_O__O(arg_1349) } else { tmp18 = linked_1347.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1346, arg_1349) }; if jrt.J2g_Truth(tmp18) { var c__1927000678__auto____21 any; var root_1350 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_1351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1350, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1352 lang.IFn; if linked_1351 == nil { ifn_1352 = lang.IFn_Cast(root_1350) } else { ifn_1352 = nil }; var arg_1353 any = seq_97000215__20; if linked_1351 == nil { c__1927000678__auto____21 = ifn_1352.Invoke_O__O(arg_1353) } else { c__1927000678__auto____21 = linked_1351.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1350, arg_1353) }; var tmp19 any; var root_1363 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = seq_97000215__20; if linked_1364 == nil { tmp19 = ifn_1365.Invoke_O__O(arg_1366) } else { tmp19 = linked_1364.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1363, arg_1366) }; seq_97000215__15, chunk_97000216__16, count_97000217__17, i_97000218__18 = tmp19, c__1927000678__auto____21, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____21))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__97000242__21 any; var root_1354 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1354, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1356 lang.IFn; if linked_1355 == nil { ifn_1356 = lang.IFn_Cast(root_1354) } else { ifn_1356 = nil }; var arg_1357 any = seq_97000215__20; if linked_1355 == nil { vec__97000242__21 = ifn_1356.Invoke_O__O(arg_1357) } else { vec__97000242__21 = linked_1355.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1354, arg_1357) }; var n__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000242__21, lang.RT_IntCast_J__I_NoInit(0), nil); var d__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000242__21, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp20 jrt.HashMap_I = jrt.HashMap_Cast(by__3); var tmp21 any; var root_1367 any = A_arbace_cpp_run_A_const_15.GetRawRoot__O(); var linked_1368 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1367, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1369 lang.IFn

						if linked_1368 == nil { ifn_1369 = lang.IFn_Cast(root_1367) } else { ifn_1369 = nil }; var arg_1370 any; var or__1927000174__auto____24 any = jrt.HashMap_Cast(by__3).Get_O__O(n__22); if jrt.J2g_Truth(or__1927000174__auto____24) { arg_1370 = or__1927000174__auto____24 } else { arg_1370 = lang.PersistentVector_EMPTY.Ref() }; var arg_1371 any = lang.Tuple_Create_O_O__IPersistentVector(s__11, A_arbace_cpp_run_A_const_117.Invoke_O__O(d__23)); if linked_1368 == nil { tmp21 = ifn_1369.Invoke_O_O__O(arg_1370, arg_1371) } else { tmp21 = linked_1368.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1367, arg_1370, arg_1371) }; tmp20.Put_O_O__O(n__22, tmp21)
//line :146:1
						var tmp22 any; var root_1372 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_1373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1372, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1374 lang.IFn; if linked_1373 == nil { ifn_1374 = lang.IFn_Cast(root_1372) } else { ifn_1374 = nil }; var arg_1375 any = seq_97000215__20; if linked_1373 == nil { tmp22 = ifn_1374.Invoke_O__O(arg_1375) } else { tmp22 = linked_1373.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1372, arg_1375) }; seq_97000215__15, chunk_97000216__16, count_97000217__17, i_97000218__18 = tmp22, nil, 0, 0; continue L3 } } }; break L3 }; var tmp23 any; var root_1376 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_1377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1376, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1378 lang.IFn; if linked_1377 == nil { ifn_1378 = lang.IFn_Cast(root_1376) } else { ifn_1378 = nil }; var arg_1379 any = seq_97000211__9; if linked_1377 == nil { tmp23 = ifn_1378.Invoke_O__O(arg_1379) } else { tmp23 = linked_1377.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1376, arg_1379) }; seq_97000211__4, chunk_97000212__5, count_97000213__6, i_97000214__7 = tmp23, nil, 0, 0; continue L1 } } }
//line :141:1
		break L1 }; var tmp24 any = A_arbace_cpp_run_A_const_112; var tmp25 any = A_arbace_cpp_run_A_const_113; var tmp26 any = A_arbace_cpp_run_A_const_114; var tmp27 any = A_arbace_cpp_run_A_const_115; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, dir__0, tmp25, ix__2, tmp26, by__3, tmp27, jrt.ConcurrentHashMap_New())) }















func A_arbace_cpp_run_ctor_attr_A_New() *A_arbace_cpp_run_ctor_attr_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_ctor_attr_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_cpp_run_ctor_attr_A) Ctor() {}
//line :157:1
func (t *A_arbace_cpp_run_ctor_attr_A) Invoke_O_O__O(self, m__0 any) any {


	var root_1380 any = A_arbace_cpp_run_A_const_118.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1382 lang.IFn; if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any; var fnbody__1417 any = A_arbace_cpp_run_ctor_attr_fn__97000246_A_New(); var tmp1 *jrt.Class; var fncls__1416 *jrt.Class = A_arbace_cpp_run_ctor_attr_fn__97000246_A_fn_class; if fncls__1416 == nil { var fncls__1416d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, nil); A_arbace_cpp_run_ctor_attr_fn__97000246_A_fn_class = fncls__1416d; tmp1 = fncls__1416d } else { tmp1 = fncls__1416 }; arg_1383 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1417, tmp1, nil); var arg_1384 any = A_arbace_cpp_run_A_const_125.Invoke_O__O(m__0); if linked_1381 == nil { return ifn_1382.Invoke_O_O__O(arg_1383, arg_1384) } else { return linked_1381.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1380, arg_1383, arg_1384) } }
//line :160:1
func A_arbace_cpp_run_ctor_attr_fn__97000246_A_New() *A_arbace_cpp_run_ctor_attr_fn__97000246_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_ctor_attr_fn__97000246_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_cpp_run_ctor_attr_fn__97000246_A) Ctor() {}
//line :160:1
func (t *A_arbace_cpp_run_ctor_attr_fn__97000246_A) Invoke_O_O__O(self, a__1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_1385 any = A_arbace_cpp_run_A_const_119.GetRawRoot__O(); var linked_1386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1385, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1387 lang.IFn; if linked_1386 == nil { ifn_1387 = lang.IFn_Cast(root_1385) } else { ifn_1387 = nil }; var arg_1388 any = a__1; if linked_1386 == nil { and__1927000168__auto____2 = ifn_1387.Invoke_O__O(arg_1388) } else { and__1927000168__auto____2 = linked_1386.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1385, arg_1388) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_cpp_run_A_const_120; var tmp3 any; var root_1389 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1389, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1391 lang.IFn; if linked_1390 == nil { ifn_1391 = lang.IFn_Cast(root_1389) } else { ifn_1391 = nil }; var arg_1392 any = a__1; if linked_1390 == nil { tmp3 = ifn_1391.Invoke_O__O(arg_1392) } else { tmp3 = linked_1390.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1389, arg_1392) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
											var root_1393 any = A_arbace_cpp_run_A_const_118.GetRawRoot__O(); var linked_1394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1393, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1395 lang.IFn; if linked_1394 == nil { ifn_1395 = lang.IFn_Cast(root_1393) } else { ifn_1395 = nil }; var arg_1396 any; var fnbody__1411 any = A_arbace_cpp_run_ctor_attr_fn__97000246_fn__97000247_A_New(); var tmp4 *jrt.Class; var fncls__1410 *jrt.Class = A_arbace_cpp_run_ctor_attr_fn__97000246_fn__97000247_A_fn_class; if fncls__1410 == nil { var fncls__1410d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, nil); A_arbace_cpp_run_ctor_attr_fn__97000246_fn__97000247_A_fn_class = fncls__1410d; tmp4 = fncls__1410d } else { tmp4 = fncls__1410 }; arg_1396 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1411, tmp4, nil); var arg_1397 any; var root_1412 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1414 lang.IFn

	if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = a__1; if linked_1413 == nil { arg_1397 = ifn_1414.Invoke_O__O(arg_1415) } else { arg_1397 = linked_1413.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1412, arg_1415) }
//line :161:1
	if linked_1394 == nil { return ifn_1395.Invoke_O_O__O(arg_1396, arg_1397) } else { return linked_1394.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1393, arg_1396, arg_1397) } } else {
//line :160:1
		return nil } }
func A_arbace_cpp_run_ctor_attr_fn__97000246_fn__97000247_A_New() *A_arbace_cpp_run_ctor_attr_fn__97000246_fn__97000247_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_ctor_attr_fn__97000246_fn__97000247_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_cpp_run_ctor_attr_fn__97000246_fn__97000247_A) Ctor() {}
//line :161:1
func (t *A_arbace_cpp_run_ctor_attr_fn__97000246_fn__97000247_A) Invoke_O_O__O(self, x__1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_cpp_run_A_const_121, x__1) { return A_arbace_cpp_run_A_const_122 } else { var tmp1 any; var and__1927000168__auto____2 any; var root_1398 any = A_arbace_cpp_run_A_const_123.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1400 lang.IFn
													if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = x__1; if linked_1399 == nil { and__1927000168__auto____2 = ifn_1400.Invoke_O__O(arg_1401) } else { and__1927000168__auto____2 = linked_1399.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1398, arg_1401) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_cpp_run_A_const_124; var tmp3 any; var root_1402 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = x__1; if linked_1403 == nil { tmp3 = ifn_1404.Invoke_O__O(arg_1405) } else { tmp3 = linked_1403.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1402, arg_1405) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :161:1
	if jrt.J2g_Truth(tmp1) {
		var tmp4 any; var root_1406 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1408 lang.IFn; if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any = x__1; if linked_1407 == nil { tmp4 = ifn_1408.Invoke_O__O(arg_1409) } else { tmp4 = linked_1407.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1406, arg_1409) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(tmp4)).Ref() } else {
//line :161:1
			return nil } } }




func A_arbace_cpp_run_ctors_A_New() *A_arbace_cpp_run_ctors_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_ctors_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_cpp_run_ctors_A) Ctor() {}
//line :166:1
func (t *A_arbace_cpp_run_ctors_A) Invoke_O_O_O__O(self, forms__0, tag__1 any) any { var acc__3 any = jrt.ArrayList_New(); var tag__4 any; var root_1418 any = A_arbace_cpp_run_A_const_36.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1420 lang.IFn; if



	linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any = tag__1; var arg_1422 any = A_arbace_cpp_run_A_const_126; var arg_1423 any = Lit_76; if linked_1419 == nil { tag__4 = ifn_1420.Invoke_O_O_O__O(arg_1421, arg_1422, arg_1423) } else { tag__4 = linked_1419.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1418, arg_1421, arg_1422, arg_1423) }; var fs__5 any; var root_1424 any = /*line :166:1*/A_arbace_cpp_run_A_const_39.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1424, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1426 lang.IFn; if




	linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any; var fnbody__1531 any = A_arbace_cpp_run_ctors_fn__97000252_A_New_O_O(tag__4, acc__3); var tmp1 *jrt.Class; var fncls__1530 *jrt.Class = A_arbace_cpp_run_ctors_fn__97000252_A_fn_class; if fncls__1530 == nil { var fncls__1530d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, fnbody__1531); A_arbace_cpp_run_ctors_fn__97000252_A_fn_class = fncls__1530d; tmp1 = fncls__1530d } else { tmp1 = fncls__1530 }; arg_1427 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1531, tmp1, nil); var arg_1428 any = forms__0; if linked_1425 == nil { fs__5 = ifn_1426.Invoke_O_O__O(arg_1427, arg_1428) } else { fs__5 = linked_1425.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1424, arg_1427, arg_1428) }; var tmp2 any; var root_1532 any = /*line :166:1*/A_arbace_cpp_run_A_const_62.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1534 lang.IFn; if















	linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any = acc__3; if linked_1533 == nil { tmp2 = ifn_1534.Invoke_O__O(arg_1535) } else { tmp2 = linked_1533.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1532, arg_1535) }; return /*line :166:1*/ lang.Tuple_Create_O_O__IPersistentVector(fs__5, tmp2) }




func A_arbace_cpp_run_ctors_fn__97000252_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_ctors_fn__97000252_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_ctors_fn__97000252_A{}; t.Ctor_O_O(p0, p1); return t }
//line :171:1
func (t *A_arbace_cpp_run_ctors_fn__97000252_A) Ctor_O_O(c__tag, c__acc any) { t.F_tag = c__tag; t.F_acc = c__acc }
//line :171:1
func (t *A_arbace_cpp_run_ctors_fn__97000252_A) Invoke_O_O__O(self, f__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_1429 any = A_arbace_cpp_run_A_const_119.GetRawRoot__O(); var linked_1430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1429, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1431 lang.IFn; if linked_1430 == nil { ifn_1431 = lang.IFn_Cast(root_1429) } else { ifn_1431 = nil }; var arg_1432 any = f__1; if linked_1430 == nil { and__1927000168__auto____2 = ifn_1431.Invoke_O__O(arg_1432) } else { and__1927000168__auto____2 = linked_1430.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1429, arg_1432) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_cpp_run_A_const_127; var tmp3 any; var root_1433 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = f__1; if linked_1434 == nil { tmp3 = ifn_1435.Invoke_O__O(arg_1436) } else { tmp3 = linked_1434.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1433, arg_1436) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var nm__2 any; var root_1437 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1439 lang.IFn
		if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = f__1; if linked_1438 == nil { nm__2 = ifn_1439.Invoke_O__O(arg_1440) } else { nm__2 = linked_1438.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1437, arg_1440) }
//line :172:1
		var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(nm__2); var temp__1927000408__auto____4 any; var root_1441 any = A_arbace_cpp_run_A_const_128.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1441, A_arbace_cpp_run_ctor_attr_A_fn_class); var ifn_1443 lang.IFn

		if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any = m__3; if linked_1442 == nil { temp__1927000408__auto____4 = ifn_1443.Invoke_O__O(arg_1444) } else { temp__1927000408__auto____4 = linked_1442.(*A_arbace_cpp_run_ctor_attr_A).Invoke_O_O__O(root_1441, arg_1444) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var pr__5 any = temp__1927000408__auto____4; var n2__6 any; var root_1445 any = A_arbace_cpp_run_A_const_73.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1447 lang.IFn
			if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_96, nil, Lit_97, nil); var tmp5 any = t.F_tag; var tmp6 any; var root_1449 any = A_arbace_cpp_run_A_const_56.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1451 lang.IFn; if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = nm__2; if linked_1450 == nil { tmp6 = ifn_1451.Invoke_O__O(arg_1452) } else { tmp6 = linked_1450.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1449, arg_1452) }; arg_1448 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp6)).Ref(); if linked_1446 == nil { n2__6 = ifn_1447.Invoke_O__O(arg_1448) } else { n2__6 = linked_1446.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1445, arg_1448) }
			var tmp7 jrt.ArrayList_I = jrt.ArrayList_Cast(t.F_acc); var tmp8 any; var root_1526 any = A_arbace_cpp_run_A_const_56.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = n2__6; if linked_1527 == nil { tmp8 = ifn_1528.Invoke_O__O(arg_1529) } else { tmp8 = linked_1527.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1526, arg_1529) }; jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp7.Add_O__Z(lang.Tuple_Create_O_O__IPersistentVector(pr__5, tmp8)))
			var root_1453 any = A_arbace_cpp_run_A_const_129.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1453, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = A_arbace_cpp_run_A_const_130.GetRawRoot__O(); var arg_1457 any; var root_1460 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1462 lang.IFn; if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any = f__1; if linked_1461 == nil { arg_1457 = ifn_1462.Invoke_O__O(arg_1463) } else { arg_1457 = linked_1461.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1460, arg_1463) }; var arg_1458 any; var root_1464 any = A_arbace_cpp_run_A_const_131.GetRawRoot__O(); var linked_1465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1464, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1466 lang.IFn; if linked_1465 == nil { ifn_1466 = lang.IFn_Cast(root_1464) } else { ifn_1466 = nil }; var arg_1467 any = n2__6; var arg_1468 any; var root_1469 any = A_arbace_cpp_run_A_const_132.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any; var root_1475 any = A_arbace_cpp_run_A_const_133.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any = m__3; var arg_1479 any = A_arbace_cpp_run_A_const_134; if linked_1476 == nil { arg_1472 = ifn_1477.Invoke_O_O__O(arg_1478, arg_1479) } else { arg_1472 = linked_1476.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_1475, arg_1478, arg_1479) }; var arg_1473 any = A_arbace_cpp_run_A_const_125; var arg_1474 any; var fnbody__1520 any = A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_A_New(); var tmp9 *jrt.Class; var fncls__1519 *jrt.Class = A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_A_fn_class; if fncls__1519 == nil { var fncls__1519d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, nil); A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_A_fn_class = fncls__1519d; tmp9 = fncls__1519d } else { tmp9 = fncls__1519 }; arg_1474 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1520, tmp9, nil); if linked_1470 == nil { arg_1468 = ifn_1471.Invoke_O_O_O__O(arg_1472, arg_1473, arg_1474) } else { arg_1468 = linked_1470.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1469, arg_1472, arg_1473, arg_1474) }; if linked_1465 == nil { arg_1458 = ifn_1466.Invoke_O_O__O(arg_1467, arg_1468) } else { arg_1458 = linked_1465.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1464, arg_1467, arg_1468) }; var arg_1459 any; var root_1521 any = A_arbace_cpp_run_A_const_136.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1521, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1523 lang.IFn
			if linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1525 any = f__1; if linked_1522 == nil { arg_1459 = ifn_1523.Invoke_O_O__O(A_arbace_cpp_run_A_const_54, arg_1525) } else { arg_1459 = linked_1522.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1521, 2, A_arbace_cpp_run_A_const_54, arg_1525) }
//line :177:1
			if linked_1454 == nil { return ifn_1455.Invoke_O_O_O_O__O(arg_1456, arg_1457, arg_1458, arg_1459) } else { return linked_1454.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1453, arg_1456, arg_1457, arg_1458, arg_1459) } } else {
//line :174:1
				return f__1 } } else {
//line :172:1
					return f__1
				}
}


func A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_A_New() *A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_A) Ctor() {}
//line :177:1
func (t *A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_A) Invoke_O_O__O(self, p1__97000251_SHARP___1 any) any { var root_1480 any = A_arbace_cpp_run_A_const_62.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any; var root_1484 any = A_arbace_cpp_run_A_const_43.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any; var fnbody__1518 any = A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_A_New(); var tmp1 *jrt.Class; var fncls__1517 *jrt.Class = A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_A_fn_class; if fncls__1517 == nil { var fncls__1517d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, nil); A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_A_fn_class = fncls__1517d; tmp1 = fncls__1517d } else { tmp1 = fncls__1517 }; arg_1487 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1518, tmp1, nil); var arg_1488 any = p1__97000251_SHARP___1; if linked_1485 == nil { arg_1483 = ifn_1486.Invoke_O_O__O(arg_1487, arg_1488) } else { arg_1483 = linked_1485.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1484, arg_1487, arg_1488) }; if linked_1481 == nil { return ifn_1482.Invoke_O__O(arg_1483) } else { return linked_1481.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1480, arg_1483) } }
//line :177:1
func A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_A_New() *A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_A) Ctor() {}
//line :177:1
func (t *A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_A) Invoke_O_O__O(self, a__1 any) any { var and__1927000168__auto____2 any; var root_1489 any = A_arbace_cpp_run_A_const_119.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1491 lang.IFn; if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any = a__1; if linked_1490 == nil { and__1927000168__auto____2 = ifn_1491.Invoke_O__O(arg_1492) } else { and__1927000168__auto____2 = linked_1490.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1489, arg_1492) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1493 any = A_arbace_cpp_run_A_const_118.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any = A_arbace_cpp_run_A_const_135; var arg_1497 any; var root_1498 any = A_arbace_cpp_run_A_const_63.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1498, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1500 lang.IFn; if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any; var fnbody__1512 any = A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_fn__97000255_A_New(); var tmp1 *jrt.Class; var fncls__1511 *jrt.Class = A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_fn__97000255_A_fn_class; if fncls__1511 == nil { var fncls__1511d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, false, nil); A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_fn__97000255_A_fn_class = fncls__1511d; tmp1 = fncls__1511d } else { tmp1 = fncls__1511 }; arg_1501 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1512, tmp1, nil); var arg_1502 any; var root_1513 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = a__1; if linked_1514 == nil { arg_1502 = ifn_1515.Invoke_O__O(arg_1516) } else { arg_1502 = linked_1514.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1513, arg_1516) }; if linked_1499 == nil { arg_1497 = ifn_1500.Invoke_O_O__O(arg_1501, arg_1502) } else { arg_1497 = linked_1499.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1498, arg_1501, arg_1502) }; if linked_1494 == nil { return ifn_1495.Invoke_O_O__O(arg_1496, arg_1497) } else { return linked_1494.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1493, arg_1496, arg_1497) } } else { return and__1927000168__auto____2 } }
//line :177:1
func A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_fn__97000255_A_New() *A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_fn__97000255_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_fn__97000255_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_fn__97000255_A) Ctor() {}
//line :177:1
func (t *A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_fn__97000255_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any; var root_1503 any = A_arbace_cpp_run_A_const_123.GetRawRoot__O(); var linked_1504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1503, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1505 lang.IFn; if linked_1504 == nil { ifn_1505 = lang.IFn_Cast(root_1503) } else { ifn_1505 = nil }; var arg_1506 any = x__1; if linked_1504 == nil { tmp1 = ifn_1505.Invoke_O__O(arg_1506) } else { tmp1 = linked_1504.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1503, arg_1506) }; if jrt.J2g_Truth(tmp1) { var root_1507 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1509 lang.IFn; if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any = x__1; if linked_1508 == nil { return ifn_1509.Invoke_O__O(arg_1510) } else { return linked_1508.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1507, arg_1510) } } else { return x__1 } }






func A_arbace_cpp_run_with_ctors_A_New() *A_arbace_cpp_run_with_ctors_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_with_ctors_A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_cpp_run_with_ctors_A) Ctor() {}
//line :184:1
func (t *A_arbace_cpp_run_with_ctors_A) Invoke_O_O_O__O(self, rd__0, tag__1 any) any { var vec__97000261__3 any; var root_1536 any = A_arbace_cpp_run_A_const_137.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1536, A_arbace_cpp_run_ctors_A_fn_class); var ifn_1538 lang.IFn; if


	linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any = A_arbace_cpp_run_A_const_70.Invoke_O__O(rd__0); var arg_1540 any = tag__1; if linked_1537 == nil { vec__97000261__3 = ifn_1538.Invoke_O_O__O(arg_1539, arg_1540) } else { vec__97000261__3 = linked_1537.(*A_arbace_cpp_run_ctors_A).Invoke_O_O_O__O(root_1536, arg_1539, arg_1540) }; var fs__4 any = /*line :184:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__97000261__3, lang.RT_IntCast_J__I_NoInit(0), nil); var cs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000261__3, lang.RT_IntCast_J__I_NoInit(1), nil); return /*line :187:1*/ lang.IFn_Cast(A_arbace_cpp_run_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O_O__O(rd__0, A_arbace_cpp_run_A_const_70, fs__4, A_arbace_cpp_run_A_const_139, cs__5) }



func A_arbace_cpp_run_checked_lib_unit_A_New() *A_arbace_cpp_run_checked_lib_unit_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_checked_lib_unit_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_cpp_run_checked_lib_unit_A) Ctor() {}
//line :191:1
func (t *A_arbace_cpp_run_checked_lib_unit_A) Invoke_O_O_O_O__O(self, h__0, lib__1, nm__2 any) any { var m__4 any = A_arbace_cpp_run_A_const_115.Invoke_O__O(lib__1); var d__5 any; var or__1927000174__auto____5 any = jrt.ConcurrentHashMap_Cast(m__4).Get_O__O(nm__2); if




	jrt.J2g_Truth(or__1927000174__auto____5) { d__5 = or__1927000174__auto____5 } else { var d__6 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__1556 any = A_arbace_cpp_run_checked_lib_unit_fn__97000265_A_New_O_O_O(lib__1, h__0, nm__2); var tmp2 *jrt.Class; var fncls__1555 *jrt.Class = A_arbace_cpp_run_checked_lib_unit_fn__97000265_A_fn_class; if fncls__1555 == nil { var fncls__1555d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, fnbody__1556); A_arbace_cpp_run_checked_lib_unit_fn__97000265_A_fn_class = fncls__1555d; tmp2 = fncls__1555d } else { tmp2 = fncls__1555 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1556, tmp2, nil); d__6 = lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)); var or__1927000174__auto____7 any = jrt.ConcurrentHashMap_Cast(m__4).PutIfAbsent_O_O__O(nm__2, d__6); if jrt.J2g_Truth(or__1927000174__auto____7) { d__5 = or__1927000174__auto____7 } else { d__5 = d__6 } }; var root_1557 any = /*line :195:1*/A_arbace_cpp_run_A_const_13.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1559 lang.IFn; if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = d__5; if linked_1558 == nil { return ifn_1559.Invoke_O__O(arg_1560) } else { return linked_1558.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1557, arg_1560) } }
func A_arbace_cpp_run_checked_lib_unit_fn__97000265_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_run_checked_lib_unit_fn__97000265_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_checked_lib_unit_fn__97000265_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :196:1
func (t *A_arbace_cpp_run_checked_lib_unit_fn__97000265_A) Ctor_O_O_O(c__lib, c__h, c__nm any) { t.F_lib = c__lib; t.F_h = c__h; t.F_nm = c__nm }
//line :196:1
func (t *A_arbace_cpp_run_checked_lib_unit_fn__97000265_A) Invoke_O__O(self any) any { var root_1549 any = A_arbace_cpp_run_A_const_140.GetRawRoot__O(); var linked_1550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1549, A_arbace_cpp_run_check_lib_unit_A_fn_class); var ifn_1551 lang.IFn; if linked_1550 == nil { ifn_1551 = lang.IFn_Cast(root_1549) } else { ifn_1551 = nil }; var arg_1552 any; var t_ any = t.F_h; t.F_h = nil; arg_1552 = t_; var arg_1553 any; var t__2 any = t.F_lib; t.F_lib = nil; arg_1553 = t__2; var arg_1554 any; var t__3 any = t.F_nm; t.F_nm = nil; arg_1554 = t__3; if linked_1550 == nil { return ifn_1551.Invoke_O_O_O__O(arg_1552, arg_1553, arg_1554) } else { return linked_1550.(*A_arbace_cpp_run_check_lib_unit_A).Invoke_O_O_O_O__O(root_1549, arg_1552, arg_1553, arg_1554) } }


func A_arbace_cpp_run_check_lib_unit_A_New() *A_arbace_cpp_run_check_lib_unit_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_check_lib_unit_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_cpp_run_check_lib_unit_A) Ctor() {}
//line :199:1
func (t *A_arbace_cpp_run_check_lib_unit_A) Invoke_O_O_O_O__O(self, h__0, lib__1, nm__2 any) any { var rd__4 any; var root_1561 any = A_arbace_cpp_run_A_const_141.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1561, A_arbace_cpp_run_with_ctors_A_fn_class); var ifn_1563 lang.IFn; if


	linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any; var root_1566 any = A_arbace_cpp_run_A_const_99.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, A_arbace_cpp_run_load_unit_A_fn_class); var ifn_1568 lang.IFn; if linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = A_arbace_cpp_run_A_const_112.Invoke_O__O(lib__1); var arg_1570 any = nm__2; if linked_1567 == nil { arg_1564 = ifn_1568.Invoke_O_O__O(arg_1569, arg_1570) } else { arg_1564 = linked_1567.(*A_arbace_cpp_run_load_unit_A).Invoke_O_O_O__O(root_1566, arg_1569, arg_1570) }; var arg_1565 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_76, nil), jrt.RefArrayOf(jrt.Object_class, jrt.File_New_String(jrt.String_Cast(A_arbace_cpp_run_A_const_112.Invoke_O__O(lib__1))).GetName__String().Ref(), nil, nm__2)).Ref(); if linked_1562 == nil { rd__4 = ifn_1563.Invoke_O_O__O(arg_1564, arg_1565) } else { rd__4 = linked_1562.(*A_arbace_cpp_run_with_ctors_A).Invoke_O_O_O__O(root_1561, arg_1564, arg_1565) }; var u__5 any; var root_1571 any = /*line :199:1*/A_arbace_cpp_run_A_const_138.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1571, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1573 lang.IFn; if



	linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any; var root_1577 any = A_arbace_cpp_run_A_const_142.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_c_run.A_arbace_c_run_check_read_A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = h__0; var arg_1581 any; var root_1583 any = A_arbace_cpp_run_A_const_47.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A_fn_class); var ifn_1585 lang.IFn; if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = A_arbace_cpp_run_A_const_48.GetRawRoot__O(); var arg_1587 any = Lit_77; if linked_1584 == nil { arg_1581 = ifn_1585.Invoke_O_O__O(arg_1586, arg_1587) } else { arg_1581 = linked_1584.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A).Invoke_O_O_O__O(root_1583, arg_1586, arg_1587) }; var arg_1582 any = rd__4; if linked_1578 == nil { arg_1574 = ifn_1579.Invoke_O_O_O__O(arg_1580, arg_1581, arg_1582) } else { arg_1574 = linked_1578.(*aot_arbace_c_run.A_arbace_c_run_check_read_A).Invoke_O_O_O_O__O(root_1577, arg_1580, arg_1581, arg_1582) }; var arg_1575 any = A_arbace_cpp_run_A_const_143; var arg_1576 any = nm__2; if linked_1572 == nil { u__5 = ifn_1573.Invoke_O_O_O__O(arg_1574, arg_1575, arg_1576) } else { u__5 = linked_1572.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1571, arg_1574, arg_1575, arg_1576) }; var tmp1 any; var root_1588 any =
	A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1588, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1590 lang.IFn; if linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any = A_arbace_cpp_run_A_const_144.Invoke_O__O(u__5); if linked_1589 == nil { tmp1 = ifn_1590.Invoke_O__O(arg_1591) } else { tmp1 = linked_1589.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1588, arg_1591) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1592 any = A_arbace_cpp_run_A_const_145.GetRawRoot__O(); var linked_1593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1592, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1594 lang.IFn
		if linked_1593 == nil { ifn_1594 = lang.IFn_Cast(root_1592) } else { ifn_1594 = nil }; var arg_1595 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_78, nil, Lit_79, nil, nil); var tmp4 any; var root_1597 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1597, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = Lit_80; var arg_1601 any; var root_1602 any = A_arbace_cpp_run_A_const_53.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_1604 lang.IFn; if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = A_arbace_cpp_run_A_const_54; var arg_1606 any = A_arbace_cpp_run_A_const_144.Invoke_O__O(u__5); if linked_1603 == nil { arg_1601 = ifn_1604.Invoke_O_O__O(arg_1605, arg_1606) } else { arg_1601 = linked_1603.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_1602, arg_1605, arg_1606) }; if linked_1598 == nil { tmp4 = ifn_1599.Invoke_O_O__O(arg_1600, arg_1601) } else { tmp4 = linked_1598.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1597, arg_1600, arg_1601) }; var tmp5 any = tmp4; var tmp6 *jrt.String; var tmp7 any; var root_1607 any = A_arbace_cpp_run_A_const_146.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1607, aot_arbace_c_run.A_arbace_c_run_uses_long_double_QMARK__A_fn_class); var ifn_1609 lang.IFn
		if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any = A_arbace_cpp_run_A_const_70.Invoke_O__O(rd__4); if linked_1608 == nil { tmp7 = ifn_1609.Invoke_O__O(arg_1610) } else { tmp7 = linked_1608.(*aot_arbace_c_run.A_arbace_c_run_uses_long_double_QMARK__A).Invoke_O_O__O(root_1607, arg_1610) }; if jrt.J2g_Truth(tmp7) { tmp6 = Lit_81 } else { tmp6 = nil }
//line :205:1
		arg_1595 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, nm__2, nil, tmp5, tmp6.Ref())).Ref(); var arg_1596 any = A_arbace_cpp_run_A_const_147; if linked_1593 == nil { tmp2 = ifn_1594.Invoke_O_O__O(arg_1595, arg_1596) } else { tmp2 = linked_1593.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1592, arg_1595, arg_1596) }
//line :204:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }; return u__5 }





func A_arbace_cpp_run_closure_A_New() *A_arbace_cpp_run_closure_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_closure_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_cpp_run_closure_A) Ctor() {}
//line :210:1
func (t *A_arbace_cpp_run_closure_A) Invoke_O_O_O_O__O(self, libs__0, prog_defs__1, prog_refs__2 any) any { var defined__4 any = jrt.HashSet_New_Collection(jrt.Collection_Cast(prog_defs__1)); var linked__5 any = jrt.LinkedHashSet_New(); var q__6 any = jrt.ArrayDeque_New(); var seq_97000269__7 any; var root_1615 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1615, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1617 lang.IFn; if







	linked_1616 == nil { ifn_1617 = lang.IFn_Cast(root_1615) } else { ifn_1617 = nil }; var arg_1618 any; var root_1619 any = A_arbace_cpp_run_A_const_30.GetRawRoot__O(); var linked_1620 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1619, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1621 lang.IFn; if linked_1620 == nil { ifn_1621 = lang.IFn_Cast(root_1619) } else { ifn_1621 = nil }; var arg_1622 any = A_arbace_cpp_run_A_const_148.GetRawRoot__O(); var arg_1623 any = prog_refs__2; if linked_1620 == nil { arg_1618 = ifn_1621.Invoke_O_O__O(arg_1622, arg_1623) } else { arg_1618 = linked_1620.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1619, arg_1622, arg_1623) }; if linked_1616 == nil { seq_97000269__7 = ifn_1617.Invoke_O__O(arg_1618) } else { seq_97000269__7 = linked_1616.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1615, arg_1618) }; var chunk_97000270__8 any; var count_97000271__9 int64 = 0; var i_97000272__10 int64 = 0; L1:
//line :210:1
	for {







		if lang.Numbers_Lt_J_J__Z_NoInit(i_97000272__10, count_97000271__9) { var r__11 any = lang.Indexed_Cast(chunk_97000270__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000272__10)); jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ArrayDeque_Cast(q__6).Add_O__Z(r__11)); seq_97000269__7, chunk_97000270__8, count_97000271__9, i_97000272__10 = seq_97000269__7, chunk_97000270__8, count_97000271__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000272__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_1624 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any = seq_97000269__7; if linked_1625 == nil { temp__1927000414__auto____11 = ifn_1626.Invoke_O__O(arg_1627) } else { temp__1927000414__auto____11 = linked_1625.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1624, arg_1627) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_97000269__12 any = temp__1927000414__auto____11; var tmp1 any; var root_1628 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1628, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1630 lang.IFn; if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any = seq_97000269__12; if linked_1629 == nil { tmp1 = ifn_1630.Invoke_O__O(arg_1631) } else { tmp1 = linked_1629.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1628, arg_1631) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____13 any; var root_1632 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1634 lang.IFn; if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any = seq_97000269__12; if linked_1633 == nil { c__1927000678__auto____13 = ifn_1634.Invoke_O__O(arg_1635) } else { c__1927000678__auto____13 = linked_1633.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1632, arg_1635) }; var tmp2 any; var root_1644 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1646 lang.IFn; if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any = seq_97000269__12; if linked_1645 == nil { tmp2 = ifn_1646.Invoke_O__O(arg_1647) } else { tmp2 = linked_1645.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1644, arg_1647) }; seq_97000269__7, chunk_97000270__8, count_97000271__9, i_97000272__10 = tmp2, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var r__13 any; var root_1636 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = seq_97000269__12; if linked_1637 == nil { r__13 = ifn_1638.Invoke_O__O(arg_1639) } else { r__13 = linked_1637.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1636, arg_1639) }; jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ArrayDeque_Cast(q__6).Add_O__Z(r__13)); var tmp3 any; var root_1648 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_1649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1648, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1650 lang.IFn; if linked_1649 == nil { ifn_1650 = lang.IFn_Cast(root_1648) } else { ifn_1650 = nil }; var arg_1651 any = seq_97000269__12; if linked_1649 == nil { tmp3 = ifn_1650.Invoke_O__O(arg_1651) } else { tmp3 = linked_1649.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1648, arg_1651) }; seq_97000269__7, chunk_97000270__8, count_97000271__9, i_97000272__10 = tmp3, nil, 0, 0; continue L1 } } }
//line :210:1
		break L1 }; L2: for {








			var tmp4 any; var root_1640 any = A_arbace_cpp_run_A_const_110.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1642 lang.IFn; if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ArrayDeque_Cast(q__6).IsEmpty__Z()).Ref(); if linked_1641 == nil { tmp4 = ifn_1642.Invoke_O__O(arg_1643) } else { tmp4 = linked_1641.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1640, arg_1643) }; if jrt.J2g_Truth(tmp4) { var n__7 any = jrt.ArrayDeque_Cast(q__6).Poll__O()

				if jrt.HashSet_Cast(defined__4).Contains_O__Z(n__7) { } else { var temp__1927000414__auto____8 any; var root_1652 any = A_arbace_cpp_run_A_const_118.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1654 lang.IFn
					if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any; var fnbody__1658 any = A_arbace_cpp_run_closure_fn__97000273_A_New_O(n__7); var tmp5 *jrt.Class; var fncls__1657 *jrt.Class = A_arbace_cpp_run_closure_fn__97000273_A_fn_class; if fncls__1657 == nil { var fncls__1657d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__1658); A_arbace_cpp_run_closure_fn__97000273_A_fn_class = fncls__1657d; tmp5 = fncls__1657d } else { tmp5 = fncls__1657 }; arg_1655 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1658, tmp5, nil); var arg_1656 any = libs__0; if linked_1653 == nil { temp__1927000414__auto____8 = ifn_1654.Invoke_O_O__O(arg_1655, arg_1656) } else { temp__1927000414__auto____8 = linked_1653.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1652, arg_1655, arg_1656) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var vec__97000275__9 any = temp__1927000414__auto____8; var lib__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000275__9, lang.RT_IntCast_J__I_NoInit(0), nil); var cands__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000275__9, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__97000278__12 any; var or__1927000174__auto____12 any; var root_1659 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1659, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1661 lang.IFn
						if linked_1660 == nil { ifn_1661 = lang.IFn_Cast(root_1659) } else { ifn_1661 = nil }; var arg_1662 any; var root_1663 any = A_arbace_cpp_run_A_const_43.GetRawRoot__O(); var linked_1664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1663, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1665 lang.IFn; if linked_1664 == nil { ifn_1665 = lang.IFn_Cast(root_1663) } else { ifn_1665 = nil }; var arg_1666 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var arg_1667 any = cands__11; if linked_1664 == nil { arg_1662 = ifn_1665.Invoke_O_O__O(arg_1666, arg_1667) } else { arg_1662 = linked_1664.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1663, arg_1666, arg_1667) }; if linked_1660 == nil { or__1927000174__auto____12 = ifn_1661.Invoke_O__O(arg_1662) } else { or__1927000174__auto____12 = linked_1660.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1659, arg_1662) }; if jrt.J2g_Truth(or__1927000174__auto____12) { vec__97000278__12 = or__1927000174__auto____12 } else { var root_1668 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = cands__11; if linked_1669 == nil { vec__97000278__12 = ifn_1670.Invoke_O__O(arg_1671) } else { vec__97000278__12 = linked_1669.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1668, arg_1671) } }
//line :222:1
						var s__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000278__12, lang.RT_IntCast_J__I_NoInit(0), nil); var ___14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000278__12, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___14

						if jrt.HashSet_Cast(linked__5).Add_O__Z(lang.Tuple_Create_O_O__IPersistentVector(lib__10, s__13)) { var map__97000281__15 any = lang.RT_Get_O_O__O_NoInit(A_arbace_cpp_run_A_const_113.Invoke_O__O(lib__10), s__13); var map__97000281__16 any
							if lang.ISeq_InstanceOf(map__97000281__15) { var tmp6 any; var root_1672 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1674 lang.IFn; if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; var arg_1675 any = map__97000281__15; if linked_1673 == nil { tmp6 = ifn_1674.Invoke_O__O(arg_1675) } else { tmp6 = linked_1673.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1672, arg_1675) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_1676 any = A_arbace_cpp_run_A_const_116.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1678 lang.IFn; if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any = map__97000281__15; if linked_1677 == nil { tmp7 = ifn_1678.Invoke_O__O(arg_1679) } else { tmp7 = linked_1677.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1676, arg_1679) }; map__97000281__16 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp7)).Ref() } else { var tmp8 any; var root_1680 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = map__97000281__15; if linked_1681 == nil { tmp8 = ifn_1682.Invoke_O__O(arg_1683) } else { tmp8 = linked_1681.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1680, arg_1683) }; if jrt.J2g_Truth(tmp8) { var root_1684 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = map__97000281__15; if linked_1685 == nil { map__97000281__16 = ifn_1686.Invoke_O__O(arg_1687) } else { map__97000281__16 = linked_1685.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1684, arg_1687) } } else { map__97000281__16 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__97000281__16 = map__97000281__15 }
//line :224:1
							var defs__17 any = lang.RT_Get_O_O__O_NoInit(map__97000281__16, A_arbace_cpp_run_A_const_102); var refs__18 any = lang.RT_Get_O_O__O_NoInit(map__97000281__16, A_arbace_cpp_run_A_const_104); var seq_97000283__19 any; var root_1708 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1710 lang.IFn

							if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any; var root_1712 any = A_arbace_cpp_run_A_const_64.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = defs__17; if linked_1713 == nil { arg_1711 = ifn_1714.Invoke_O__O(arg_1715) } else { arg_1711 = linked_1713.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1712, arg_1715) }; if linked_1709 == nil { seq_97000283__19 = ifn_1710.Invoke_O__O(arg_1711) } else { seq_97000283__19 = linked_1709.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1708, arg_1711) }
//line :224:1
							var chunk_97000284__20 any; var count_97000285__21 int64 = 0; var i_97000286__22 int64 = 0; L3: for {

								if lang.Numbers_Lt_J_J__Z_NoInit(i_97000286__22, count_97000285__21) { var d__23 any = lang.Indexed_Cast(chunk_97000284__20).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000286__22)); jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.HashSet_Cast(defined__4).Add_O__Z(d__23)); seq_97000283__19, chunk_97000284__20, count_97000285__21, i_97000286__22 = seq_97000283__19, chunk_97000284__20, count_97000285__21, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000286__22); continue L3 } else { var temp__1927000414__auto____23 any; var root_1716 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1716, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1718 lang.IFn; if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any = seq_97000283__19; if linked_1717 == nil { temp__1927000414__auto____23 = ifn_1718.Invoke_O__O(arg_1719) } else { temp__1927000414__auto____23 = linked_1717.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1716, arg_1719) }; if jrt.J2g_Truth(temp__1927000414__auto____23) { var seq_97000283__24 any = temp__1927000414__auto____23; var tmp9 any; var root_1720 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1720, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1722 lang.IFn; if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = seq_97000283__24; if linked_1721 == nil { tmp9 = ifn_1722.Invoke_O__O(arg_1723) } else { tmp9 = linked_1721.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1720, arg_1723) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____25 any; var root_1724 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1726 lang.IFn; if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any = seq_97000283__24; if linked_1725 == nil { c__1927000678__auto____25 = ifn_1726.Invoke_O__O(arg_1727) } else { c__1927000678__auto____25 = linked_1725.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1724, arg_1727) }; var tmp10 any; var root_1732 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any = seq_97000283__24; if linked_1733 == nil { tmp10 = ifn_1734.Invoke_O__O(arg_1735) } else { tmp10 = linked_1733.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1732, arg_1735) }; seq_97000283__19, chunk_97000284__20, count_97000285__21, i_97000286__22 = tmp10, c__1927000678__auto____25, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____25))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var d__25 any; var root_1728 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1728, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1730 lang.IFn; if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = seq_97000283__24; if linked_1729 == nil { d__25 = ifn_1730.Invoke_O__O(arg_1731) } else { d__25 = linked_1729.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1728, arg_1731) }; jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.HashSet_Cast(defined__4).Add_O__Z(d__25)); var tmp11 any; var root_1736 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1738 lang.IFn; if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any = seq_97000283__24; if linked_1737 == nil { tmp11 = ifn_1738.Invoke_O__O(arg_1739) } else { tmp11 = linked_1737.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1736, arg_1739) }; seq_97000283__19, chunk_97000284__20, count_97000285__21, i_97000286__22 = tmp11, nil, 0, 0; continue L3 } } }
//line :224:1
								break L3 }; var seq_97000287__19 any; var root_1688 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1690 lang.IFn


							if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any = refs__18; if linked_1689 == nil { seq_97000287__19 = ifn_1690.Invoke_O__O(arg_1691) } else { seq_97000287__19 = linked_1689.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1688, arg_1691) }
//line :224:1
							var chunk_97000288__20 any; var count_97000289__21 int64 = 0; var i_97000290__22 int64 = 0; L4: for {


								if lang.Numbers_Lt_J_J__Z_NoInit(i_97000290__22, count_97000289__21) { var r__23 any = lang.Indexed_Cast(chunk_97000288__20).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000290__22))
									if jrt.HashSet_Cast(defined__4).Contains_O__Z(r__23) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ArrayDeque_Cast(q__6).Add_O__Z(r__23)) }
									var tmp12 any; var root_1740 any = A_arbace_cpp_run_A_const_66.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1742 lang.IFn; if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any = r__23; var arg_1744 any = Lit_45; if linked_1741 == nil { tmp12 = ifn_1742.Invoke_O_O__O(arg_1743, arg_1744) } else { tmp12 = linked_1741.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1740, arg_1743, arg_1744) }; if jrt.J2g_Truth(tmp12) { var tmp13 jrt.ArrayDeque_I = jrt.ArrayDeque_Cast(q__6); var tmp14 any; var root_1745 any = A_arbace_cpp_run_A_const_71.GetRawRoot__O(); var linked_1746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1745, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1747 lang.IFn; if linked_1746 == nil { ifn_1747 = lang.IFn_Cast(root_1745) } else { ifn_1747 = nil }; var arg_1748 any = r__23; var arg_1749 any = A_arbace_cpp_run_A_const_149; if linked_1746 == nil { tmp14 = ifn_1747.Invoke_O_O__O(arg_1748, arg_1749) } else { tmp14 = linked_1746.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1745, arg_1748, arg_1749) }; jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp13.Add_O__Z(tmp14)) }
//line :227:1
									seq_97000287__19, chunk_97000288__20, count_97000289__21, i_97000290__22 = seq_97000287__19, chunk_97000288__20, count_97000289__21, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000290__22); continue L4 } else { var temp__1927000414__auto____23_2 any; var root_1692 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1694 lang.IFn; if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any = seq_97000287__19; if linked_1693 == nil { temp__1927000414__auto____23_2 = ifn_1694.Invoke_O__O(arg_1695) } else { temp__1927000414__auto____23_2 = linked_1693.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1692, arg_1695) }; if jrt.J2g_Truth(temp__1927000414__auto____23_2) { var seq_97000287__24 any = temp__1927000414__auto____23_2; var tmp15 any; var root_1696 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1698 lang.IFn; if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = seq_97000287__24; if linked_1697 == nil { tmp15 = ifn_1698.Invoke_O__O(arg_1699) } else { tmp15 = linked_1697.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1696, arg_1699) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____25_2 any; var root_1700 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any = seq_97000287__24; if linked_1701 == nil { c__1927000678__auto____25_2 = ifn_1702.Invoke_O__O(arg_1703) } else { c__1927000678__auto____25_2 = linked_1701.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1700, arg_1703) }; var tmp16 any; var root_1750 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1752 lang.IFn; if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = seq_97000287__24; if linked_1751 == nil { tmp16 = ifn_1752.Invoke_O__O(arg_1753) } else { tmp16 = linked_1751.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1750, arg_1753) }; seq_97000287__19, chunk_97000288__20, count_97000289__21, i_97000290__22 = tmp16, c__1927000678__auto____25_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____25_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var r__25 any; var root_1704 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1706 lang.IFn; if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any = seq_97000287__24; if linked_1705 == nil { r__25 = ifn_1706.Invoke_O__O(arg_1707) } else { r__25 = linked_1705.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1704, arg_1707) }
										if jrt.HashSet_Cast(defined__4).Contains_O__Z(r__25) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ArrayDeque_Cast(q__6).Add_O__Z(r__25)) }
										var tmp17 any; var root_1754 any = A_arbace_cpp_run_A_const_66.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = r__25; var arg_1758 any = Lit_45; if linked_1755 == nil { tmp17 = ifn_1756.Invoke_O_O__O(arg_1757, arg_1758) } else { tmp17 = linked_1755.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1754, arg_1757, arg_1758) }; if jrt.J2g_Truth(tmp17) { var tmp18 jrt.ArrayDeque_I = jrt.ArrayDeque_Cast(q__6); var tmp19 any; var root_1759 any = A_arbace_cpp_run_A_const_71.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1759, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1761 lang.IFn; if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any = r__25; var arg_1763 any = A_arbace_cpp_run_A_const_149; if linked_1760 == nil { tmp19 = ifn_1761.Invoke_O_O__O(arg_1762, arg_1763) } else { tmp19 = linked_1760.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1759, arg_1762, arg_1763) }; jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp18.Add_O__Z(tmp19)) }
//line :227:1
										var tmp20 any; var root_1764 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_1765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1764, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1766 lang.IFn; if linked_1765 == nil { ifn_1766 = lang.IFn_Cast(root_1764) } else { ifn_1766 = nil }; var arg_1767 any = seq_97000287__24; if linked_1765 == nil { tmp20 = ifn_1766.Invoke_O__O(arg_1767) } else { tmp20 = linked_1765.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1764, arg_1767) }; seq_97000287__19, chunk_97000288__20, count_97000289__21, i_97000290__22 = tmp20, nil, 0, 0; continue L4 } } }
//line :224:1
								break L4 } } } }
//line :219:1
				continue L2 }
//line :210:1
			break L2 }; var root_1611 any =



















	A_arbace_cpp_run_A_const_62.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1613 lang.IFn; if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any = linked__5; if linked_1612 == nil { return ifn_1613.Invoke_O__O(arg_1614) } else { return linked_1612.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1611, arg_1614) } }
//line :222:1
func A_arbace_cpp_run_closure_fn__97000273_A_New_O(p0 any) *A_arbace_cpp_run_closure_fn__97000273_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_closure_fn__97000273_A{}; t.Ctor_O(p0); return t }
//line :222:1
func (t *A_arbace_cpp_run_closure_fn__97000273_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :222:1
func (t *A_arbace_cpp_run_closure_fn__97000273_A) Invoke_O_O__O(self, lib__1 any) any { var temp__1927000414__auto____2 any = jrt.HashMap_Cast(A_arbace_cpp_run_A_const_114.Invoke_O__O(lib__1)).Get_O__O(t.F_n); if jrt.J2g_Truth(temp__1927000414__auto____2) { var c__3 any = temp__1927000414__auto____2; return lang.Tuple_Create_O_O__IPersistentVector(lib__1, c__3) } else { return nil } }









func A_arbace_cpp_run_sym_name_A_New() *A_arbace_cpp_run_sym_name_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_sym_name_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_cpp_run_sym_name_A) Ctor() {}
//line :232:1
func (t *A_arbace_cpp_run_sym_name_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_1768 any = A_arbace_cpp_run_A_const_150.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1768, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1770 lang.IFn; if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1771 any = x__0; if linked_1769 == nil { tmp1 = ifn_1770.Invoke_O__O(arg_1771) } else { tmp1 = linked_1769.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1768, arg_1771) }; if jrt.J2g_Truth(tmp1) { var root_1772 any = A_arbace_cpp_run_A_const_56.GetRawRoot__O(); var linked_1773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1772, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1774 lang.IFn; if linked_1773 == nil { ifn_1774 = lang.IFn_Cast(root_1772) } else { ifn_1774 = nil }; var arg_1775 any = x__0; if linked_1773 == nil { return ifn_1774.Invoke_O__O(arg_1775) } else { return linked_1773.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1772, arg_1775) } } else { var tmp2 any; var and__1927000168__auto____2 any; var root_1776 any = A_arbace_cpp_run_A_const_119.GetRawRoot__O(); var linked_1777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1776, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1778 lang.IFn; if linked_1777 == nil { ifn_1778 = lang.IFn_Cast(root_1776) } else { ifn_1778 = nil }; var arg_1779 any = x__0; if linked_1777 == nil { and__1927000168__auto____2 = ifn_1778.Invoke_O__O(arg_1779) } else { and__1927000168__auto____2 = linked_1777.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1776, arg_1779) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp3 any = A_arbace_cpp_run_A_const_151; var tmp4 any; var root_1780 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1780, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1782 lang.IFn; if linked_1781 == nil { ifn_1782 = lang.IFn_Cast(root_1780) } else { ifn_1782 = nil }; var arg_1783 any = x__0; if linked_1781 == nil { tmp4 = ifn_1782.Invoke_O__O(arg_1783) } else { tmp4 = linked_1781.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1780, arg_1783) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp2) { var root_1784 any = A_arbace_cpp_run_A_const_37.GetRawRoot__O(); var linked_1785 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1784, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1786 lang.IFn; if linked_1785 == nil { ifn_1786 = lang.IFn_Cast(root_1784) } else { ifn_1786 = nil }; var arg_1787 any; var root_1788 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var linked_1789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1788, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1790 lang.IFn; if linked_1789 == nil { ifn_1790 = lang.IFn_Cast(root_1788) } else { ifn_1790 = nil }; var arg_1791 any = x__0; if linked_1789 == nil { arg_1787 = ifn_1790.Invoke_O__O(arg_1791) } else { arg_1787 = linked_1789.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1788, arg_1791) }; if linked_1785 == nil { return ifn_1786.Invoke_O__O(arg_1787) } else { return linked_1785.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1784, arg_1787) } } else { return nil } } }

func A_arbace_cpp_run_def_name_A_New() *A_arbace_cpp_run_def_name_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_def_name_A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_cpp_run_def_name_A) Ctor() {}
//line :234:1
func (t *A_arbace_cpp_run_def_name_A) Invoke_O_O__O(self, f__0 any) any {


	var tmp1 any; var root_1792 any = A_arbace_cpp_run_A_const_119.GetRawRoot__O(); var linked_1793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1792, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1794 lang.IFn; if linked_1793 == nil { ifn_1794 = lang.IFn_Cast(root_1792) } else { ifn_1794 = nil }; var arg_1795 any = f__0; if linked_1793 == nil { tmp1 = ifn_1794.Invoke_O__O(arg_1795) } else { tmp1 = linked_1793.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1792, arg_1795) }; if jrt.J2g_Truth(tmp1) { var G__97000293__2_ any; var root_1796 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1798 lang.IFn
		if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = f__0; if linked_1797 == nil { G__97000293__2_ = ifn_1798.Invoke_O__O(arg_1799) } else { G__97000293__2_ = linked_1797.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1796, arg_1799) }; switch lang.Util_Hash_O__I_NoInit(G__97000293__2_) >> 0 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__97000293__2_, A_arbace_cpp_run_A_const_152) { var m__3 any; var tmp2 any; var root_1801 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1803 lang.IFn

			if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = f__0; if linked_1802 == nil { tmp2 = ifn_1803.Invoke_O__O(arg_1804) } else { tmp2 = linked_1802.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1801, arg_1804) }; m__3 = lang.RT_Meta_O__IPersistentMap_NoInit(tmp2); if jrt.J2g_Truth(A_arbace_cpp_run_A_const_153.Invoke_O__O(m__3)) { return nil } else { var tmp3 any; var root_1805 any = A_arbace_cpp_run_A_const_155.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, A_arbace_cpp_run_sym_name_A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any; var root_1809 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1811 lang.IFn; if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = f__0; if linked_1810 == nil { arg_1808 = ifn_1811.Invoke_O__O(arg_1812) } else { arg_1808 = linked_1810.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1809, arg_1812) }; if linked_1806 == nil { tmp3 = ifn_1807.Invoke_O__O(arg_1808) } else { tmp3 = linked_1806.(*A_arbace_cpp_run_sym_name_A).Invoke_O_O__O(root_1805, arg_1808) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_cpp_run_A_const_134.Invoke_O__O(m__3))).Ref()) } }
//line :238:1
		case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__97000293__2_, A_arbace_cpp_run_A_const_154) { var tmp4 any; var root_1813 any = A_arbace_cpp_run_A_const_155.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, A_arbace_cpp_run_sym_name_A_fn_class); var ifn_1815 lang.IFn
			if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any; var root_1817 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var linked_1818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1817, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1819 lang.IFn; if linked_1818 == nil { ifn_1819 = lang.IFn_Cast(root_1817) } else { ifn_1819 = nil }; var arg_1820 any = f__0; if linked_1818 == nil { arg_1816 = ifn_1819.Invoke_O__O(arg_1820) } else { arg_1816 = linked_1818.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1817, arg_1820) }; if linked_1814 == nil { tmp4 = ifn_1815.Invoke_O__O(arg_1816) } else { tmp4 = linked_1814.(*A_arbace_cpp_run_sym_name_A).Invoke_O_O__O(root_1813, arg_1816) }
//line :238:1
			var tmp5 any = tmp4; var tmp6 *lang.Keyword = A_arbace_cpp_run_A_const_134; var tmp7 any; var root_1821 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var linked_1822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1821, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1823 lang.IFn
			if linked_1822 == nil { ifn_1823 = lang.IFn_Cast(root_1821) } else { ifn_1823 = nil }; var arg_1824 any = f__0; if linked_1822 == nil { tmp7 = ifn_1823.Invoke_O__O(arg_1824) } else { tmp7 = linked_1822.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1821, arg_1824) }
//line :238:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp5, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp7)))).Ref()) }; default:}; return nil } else {
//line :237:1
				return nil
			}
}



func A_arbace_cpp_run_prune_A_New() *A_arbace_cpp_run_prune_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_prune_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_cpp_run_prune_A) Ctor() {}
//line :243:1
func (t *A_arbace_cpp_run_prune_A) Invoke_O_O_O__O(self, units__0, roots__1 any) any { var n__3 int32 = lang.RT_Count_O__I_NoInit(units__0); var forms__4 any; var root_1825 any = A_arbace_cpp_run_A_const_39.GetRawRoot__O(); var linked_1826 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1825, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1827 lang.IFn; if







	linked_1826 == nil { ifn_1827 = lang.IFn_Cast(root_1825) } else { ifn_1827 = nil }; var arg_1828 any; var fnbody__1835 any = A_arbace_cpp_run_prune_fn__97000296_A_New(); var tmp1 *jrt.Class; var fncls__1834 *jrt.Class = A_arbace_cpp_run_prune_fn__97000296_A_fn_class; if fncls__1834 == nil { var fncls__1834d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_168, false, nil); A_arbace_cpp_run_prune_fn__97000296_A_fn_class = fncls__1834d; tmp1 = fncls__1834d } else { tmp1 = fncls__1834 }; arg_1828 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1835, tmp1, nil); var arg_1829 any = units__0; if linked_1826 == nil { forms__4 = ifn_1827.Invoke_O_O__O(arg_1828, arg_1829) } else { forms__4 = linked_1826.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1825, arg_1828, arg_1829) }; var local__5 any; var root_1836 any = /*line :243:1*/A_arbace_cpp_run_A_const_39.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1838 lang.IFn; if









	linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any; var fnbody__1897 any = A_arbace_cpp_run_prune_fn__97000298_A_New(); var tmp2 *jrt.Class; var fncls__1896 *jrt.Class = A_arbace_cpp_run_prune_fn__97000298_A_fn_class; if fncls__1896 == nil { var fncls__1896d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_169, false, nil); A_arbace_cpp_run_prune_fn__97000298_A_fn_class = fncls__1896d; tmp2 = fncls__1896d } else { tmp2 = fncls__1896 }; arg_1839 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1897, tmp2, nil); var arg_1840 any = forms__4; if linked_1837 == nil { local__5 = ifn_1838.Invoke_O_O__O(arg_1839, arg_1840) } else { local__5 = linked_1837.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1836, arg_1839, arg_1840) }; var global__6 any; var m__6 any = /*line :243:1*/jrt.HashMap_New(); var seq_97000316__7 any; var root_1998 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1998, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2000 lang.IFn; if















	linked_1999 == nil { ifn_2000 = lang.IFn_Cast(root_1998) } else { ifn_2000 = nil }; var arg_2001 any; var root_2002 any = A_arbace_cpp_run_A_const_97.GetRawRoot__O(); var linked_2003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2002, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_2004 lang.IFn; if linked_2003 == nil { ifn_2004 = lang.IFn_Cast(root_2002) } else { ifn_2004 = nil }; var arg_2005 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref(); if linked_2003 == nil { arg_2001 = ifn_2004.Invoke_O__O(arg_2005) } else { arg_2001 = linked_2003.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_2002, arg_2005) }; if linked_1999 == nil { seq_97000316__7 = ifn_2000.Invoke_O__O(arg_2001) } else { seq_97000316__7 = linked_1999.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1998, arg_2001) }; var chunk_97000317__8 any; var count_97000318__9 int64 = 0; var i_97000319__10 int64 = 0; L1:
//line :243:1
	for {















		if lang.Numbers_Lt_J_J__Z_NoInit(i_97000319__10, count_97000318__9) { var u__11 any = lang.Indexed_Cast(chunk_97000317__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000319__10)); var seq_97000324__12 any; var root_2022 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2022, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2024 lang.IFn; if linked_2023 == nil { ifn_2024 = lang.IFn_Cast(root_2022) } else { ifn_2024 = nil }; var arg_2025 any; var root_2026 any = A_arbace_cpp_run_A_const_157.GetRawRoot__O(); var linked_2027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2026, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2028 lang.IFn; if linked_2027 == nil { ifn_2028 = lang.IFn_Cast(root_2026) } else { ifn_2028 = nil }; var arg_2029 any = A_arbace_cpp_run_A_const_158.GetRawRoot__O(); var arg_2030 any = lang.IFn_Cast(forms__4).Invoke_O__O(u__11); if linked_2027 == nil { arg_2025 = ifn_2028.Invoke_O_O__O(arg_2029, arg_2030) } else { arg_2025 = linked_2027.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2026, arg_2029, arg_2030) }; if linked_2023 == nil { seq_97000324__12 = ifn_2024.Invoke_O__O(arg_2025) } else { seq_97000324__12 = linked_2023.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2022, arg_2025) }; var chunk_97000325__13 any; var count_97000326__14 int64 = 0; var i_97000327__15 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_97000327__15, count_97000326__14) { var vec__97000328__16 any = lang.Indexed_Cast(chunk_97000325__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000327__15)); var i__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000328__16, lang.RT_IntCast_J__I_NoInit(0), nil); var f__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000328__16, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__97000331__19 any; var root_2031 any = A_arbace_cpp_run_A_const_159.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2031, A_arbace_cpp_run_def_name_A_fn_class); var ifn_2033 lang.IFn; if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any = f__18; if linked_2032 == nil { vec__97000331__19 = ifn_2033.Invoke_O__O(arg_2034) } else { vec__97000331__19 = linked_2032.(*A_arbace_cpp_run_def_name_A).Invoke_O_O__O(root_2031, arg_2034) }; var nm__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000331__19, lang.RT_IntCast_J__I_NoInit(0), nil); var st__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000331__19, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp3 any; var and__1927000168__auto____22 any = nm__20; if jrt.J2g_Truth(and__1927000168__auto____22) { var root_2035 any = A_arbace_cpp_run_A_const_110.GetRawRoot__O(); var linked_2036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2035, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2037 lang.IFn; if linked_2036 == nil { ifn_2037 = lang.IFn_Cast(root_2035) } else { ifn_2037 = nil }; var arg_2038 any = st__21; if linked_2036 == nil { tmp3 = ifn_2037.Invoke_O__O(arg_2038) } else { tmp3 = linked_2036.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2035, arg_2038) } } else { tmp3 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp3) {
			var tmp4 jrt.HashMap_I = jrt.HashMap_Cast(m__6); var tmp5 any; var root_2063 any = A_arbace_cpp_run_A_const_15.GetRawRoot__O(); var linked_2064 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2063, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2065 lang.IFn; if linked_2064 == nil { ifn_2065 = lang.IFn_Cast(root_2063) } else { ifn_2065 = nil }; var arg_2066 any; var or__1927000174__auto____22 any = jrt.HashMap_Cast(m__6).Get_O__O(nm__20); if jrt.J2g_Truth(or__1927000174__auto____22) { arg_2066 = or__1927000174__auto____22 } else { arg_2066 = lang.PersistentVector_EMPTY.Ref() }; var arg_2067 any = lang.Tuple_Create_O_O__IPersistentVector(u__11, i__17); if linked_2064 == nil { tmp5 = ifn_2065.Invoke_O_O__O(arg_2066, arg_2067) } else { tmp5 = linked_2064.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2063, arg_2066, arg_2067) }; tmp4.Put_O_O__O(nm__20, tmp5)
//line :259:1
			seq_97000324__12, chunk_97000325__13, count_97000326__14, i_97000327__15 = seq_97000324__12, chunk_97000325__13, count_97000326__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000327__15); continue L2 } else { seq_97000324__12, chunk_97000325__13, count_97000326__14, i_97000327__15 = seq_97000324__12, chunk_97000325__13, count_97000326__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000327__15); continue L2 } } else { var temp__1927000414__auto____16 any; var root_2039 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2039, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2041 lang.IFn; if linked_2040 == nil { ifn_2041 = lang.IFn_Cast(root_2039) } else { ifn_2041 = nil }; var arg_2042 any = seq_97000324__12; if linked_2040 == nil { temp__1927000414__auto____16 = ifn_2041.Invoke_O__O(arg_2042) } else { temp__1927000414__auto____16 = linked_2040.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2039, arg_2042) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_97000324__17 any = temp__1927000414__auto____16; var tmp6 any; var root_2043 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_2044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2043, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2045 lang.IFn; if linked_2044 == nil { ifn_2045 = lang.IFn_Cast(root_2043) } else { ifn_2045 = nil }; var arg_2046 any = seq_97000324__17; if linked_2044 == nil { tmp6 = ifn_2045.Invoke_O__O(arg_2046) } else { tmp6 = linked_2044.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2043, arg_2046) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____18 any; var root_2047 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_2048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2047, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2049 lang.IFn; if linked_2048 == nil { ifn_2049 = lang.IFn_Cast(root_2047) } else { ifn_2049 = nil }; var arg_2050 any = seq_97000324__17; if linked_2048 == nil { c__1927000678__auto____18 = ifn_2049.Invoke_O__O(arg_2050) } else { c__1927000678__auto____18 = linked_2048.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2047, arg_2050) }; var tmp7 any; var root_2068 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_2069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2068, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2070 lang.IFn; if linked_2069 == nil { ifn_2070 = lang.IFn_Cast(root_2068) } else { ifn_2070 = nil }; var arg_2071 any = seq_97000324__17; if linked_2069 == nil { tmp7 = ifn_2070.Invoke_O__O(arg_2071) } else { tmp7 = linked_2069.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2068, arg_2071) }; seq_97000324__12, chunk_97000325__13, count_97000326__14, i_97000327__15 = tmp7, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__97000334__18 any; var root_2051 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_2052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2051, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2053 lang.IFn; if linked_2052 == nil { ifn_2053 = lang.IFn_Cast(root_2051) } else { ifn_2053 = nil }; var arg_2054 any = seq_97000324__17; if linked_2052 == nil { vec__97000334__18 = ifn_2053.Invoke_O__O(arg_2054) } else { vec__97000334__18 = linked_2052.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2051, arg_2054) }; var i__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000334__18, lang.RT_IntCast_J__I_NoInit(0), nil); var f__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000334__18, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__97000337__21 any; var root_2055 any = A_arbace_cpp_run_A_const_159.GetRawRoot__O(); var linked_2056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2055, A_arbace_cpp_run_def_name_A_fn_class); var ifn_2057 lang.IFn; if linked_2056 == nil { ifn_2057 = lang.IFn_Cast(root_2055) } else { ifn_2057 = nil }; var arg_2058 any = f__20; if linked_2056 == nil { vec__97000337__21 = ifn_2057.Invoke_O__O(arg_2058) } else { vec__97000337__21 = linked_2056.(*A_arbace_cpp_run_def_name_A).Invoke_O_O__O(root_2055, arg_2058) }; var nm__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000337__21, lang.RT_IntCast_J__I_NoInit(0), nil); var st__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000337__21, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp8 any; var and__1927000168__auto____24 any = nm__22; if jrt.J2g_Truth(and__1927000168__auto____24) { var root_2059 any = A_arbace_cpp_run_A_const_110.GetRawRoot__O(); var linked_2060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2059, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2061 lang.IFn; if linked_2060 == nil { ifn_2061 = lang.IFn_Cast(root_2059) } else { ifn_2061 = nil }; var arg_2062 any = st__23; if linked_2060 == nil { tmp8 = ifn_2061.Invoke_O__O(arg_2062) } else { tmp8 = linked_2060.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2059, arg_2062) } } else { tmp8 = and__1927000168__auto____24 }; if jrt.J2g_Truth(tmp8) {
				var tmp9 jrt.HashMap_I = jrt.HashMap_Cast(m__6); var tmp10 any; var root_2072 any = A_arbace_cpp_run_A_const_15.GetRawRoot__O(); var linked_2073 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2072, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2074 lang.IFn; if linked_2073 == nil { ifn_2074 = lang.IFn_Cast(root_2072) } else { ifn_2074 = nil }; var arg_2075 any; var or__1927000174__auto____24 any = jrt.HashMap_Cast(m__6).Get_O__O(nm__22); if jrt.J2g_Truth(or__1927000174__auto____24) { arg_2075 = or__1927000174__auto____24 } else { arg_2075 = lang.PersistentVector_EMPTY.Ref() }; var arg_2076 any = lang.Tuple_Create_O_O__IPersistentVector(u__11, i__19); if linked_2073 == nil { tmp10 = ifn_2074.Invoke_O_O__O(arg_2075, arg_2076) } else { tmp10 = linked_2073.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2072, arg_2075, arg_2076) }; tmp9.Put_O_O__O(nm__22, tmp10)
//line :259:1
				var tmp11 any; var root_2077 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_2078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2077, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2079 lang.IFn; if linked_2078 == nil { ifn_2079 = lang.IFn_Cast(root_2077) } else { ifn_2079 = nil }; var arg_2080 any = seq_97000324__17; if linked_2078 == nil { tmp11 = ifn_2079.Invoke_O__O(arg_2080) } else { tmp11 = linked_2078.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2077, arg_2080) }; seq_97000324__12, chunk_97000325__13, count_97000326__14, i_97000327__15 = tmp11, nil, 0, 0; continue L2 } else { var tmp12 any; var root_2081 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_2082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2081, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2083 lang.IFn; if linked_2082 == nil { ifn_2083 = lang.IFn_Cast(root_2081) } else { ifn_2083 = nil }; var arg_2084 any = seq_97000324__17; if linked_2082 == nil { tmp12 = ifn_2083.Invoke_O__O(arg_2084) } else { tmp12 = linked_2082.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2081, arg_2084) }; seq_97000324__12, chunk_97000325__13, count_97000326__14, i_97000327__15 = tmp12, nil, 0, 0; continue L2 } } } }; break L2 }; seq_97000316__7, chunk_97000317__8, count_97000318__9, i_97000319__10 = seq_97000316__7, chunk_97000317__8, count_97000318__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000319__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_2006 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2006, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2008 lang.IFn; if linked_2007 == nil { ifn_2008 = lang.IFn_Cast(root_2006) } else { ifn_2008 = nil }; var arg_2009 any = seq_97000316__7; if linked_2007 == nil { temp__1927000414__auto____11 = ifn_2008.Invoke_O__O(arg_2009) } else { temp__1927000414__auto____11 = linked_2007.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2006, arg_2009) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_97000316__12 any = temp__1927000414__auto____11; var tmp13 any; var root_2010 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_2011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2010, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2012 lang.IFn; if linked_2011 == nil { ifn_2012 = lang.IFn_Cast(root_2010) } else { ifn_2012 = nil }; var arg_2013 any = seq_97000316__12; if linked_2011 == nil { tmp13 = ifn_2012.Invoke_O__O(arg_2013) } else { tmp13 = linked_2011.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2010, arg_2013) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____13 any; var root_2014 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_2015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2014, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2016 lang.IFn; if linked_2015 == nil { ifn_2016 = lang.IFn_Cast(root_2014) } else { ifn_2016 = nil }; var arg_2017 any = seq_97000316__12; if linked_2015 == nil { c__1927000678__auto____13 = ifn_2016.Invoke_O__O(arg_2017) } else { c__1927000678__auto____13 = linked_2015.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2014, arg_2017) }; var tmp14 any; var root_2085 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_2086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2085, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2087 lang.IFn; if linked_2086 == nil { ifn_2087 = lang.IFn_Cast(root_2085) } else { ifn_2087 = nil }; var arg_2088 any = seq_97000316__12; if linked_2086 == nil { tmp14 = ifn_2087.Invoke_O__O(arg_2088) } else { tmp14 = linked_2086.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2085, arg_2088) }; seq_97000316__7, chunk_97000317__8, count_97000318__9, i_97000319__10 = tmp14, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var u__13 any; var root_2018 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_2019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2018, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2020 lang.IFn; if linked_2019 == nil { ifn_2020 = lang.IFn_Cast(root_2018) } else { ifn_2020 = nil }; var arg_2021 any = seq_97000316__12; if linked_2019 == nil { u__13 = ifn_2020.Invoke_O__O(arg_2021) } else { u__13 = linked_2019.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2018, arg_2021) }; var seq_97000320__14 any; var root_2089 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2089, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2091 lang.IFn; if linked_2090 == nil { ifn_2091 = lang.IFn_Cast(root_2089) } else { ifn_2091 = nil }; var arg_2092 any; var root_2093 any = A_arbace_cpp_run_A_const_157.GetRawRoot__O(); var linked_2094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2093, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2095 lang.IFn; if linked_2094 == nil { ifn_2095 = lang.IFn_Cast(root_2093) } else { ifn_2095 = nil }; var arg_2096 any = A_arbace_cpp_run_A_const_158.GetRawRoot__O(); var arg_2097 any = lang.IFn_Cast(forms__4).Invoke_O__O(u__13); if linked_2094 == nil { arg_2092 = ifn_2095.Invoke_O_O__O(arg_2096, arg_2097) } else { arg_2092 = linked_2094.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2093, arg_2096, arg_2097) }; if linked_2090 == nil { seq_97000320__14 = ifn_2091.Invoke_O__O(arg_2092) } else { seq_97000320__14 = linked_2090.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2089, arg_2092) }; var chunk_97000321__15 any; var count_97000322__16 int64 = 0; var i_97000323__17 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_97000323__17, count_97000322__16) { var vec__97000340__18 any = lang.Indexed_Cast(chunk_97000321__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000323__17)); var i__19_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000340__18, lang.RT_IntCast_J__I_NoInit(0), nil); var f__20_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000340__18, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__97000343__21 any; var root_2098 any = A_arbace_cpp_run_A_const_159.GetRawRoot__O(); var linked_2099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2098, A_arbace_cpp_run_def_name_A_fn_class); var ifn_2100 lang.IFn; if linked_2099 == nil { ifn_2100 = lang.IFn_Cast(root_2098) } else { ifn_2100 = nil }; var arg_2101 any = f__20_2; if linked_2099 == nil { vec__97000343__21 = ifn_2100.Invoke_O__O(arg_2101) } else { vec__97000343__21 = linked_2099.(*A_arbace_cpp_run_def_name_A).Invoke_O_O__O(root_2098, arg_2101) }; var nm__22_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000343__21, lang.RT_IntCast_J__I_NoInit(0), nil); var st__23_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000343__21, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp15 any; var and__1927000168__auto____24_2 any = nm__22_2; if jrt.J2g_Truth(and__1927000168__auto____24_2) { var root_2102 any = A_arbace_cpp_run_A_const_110.GetRawRoot__O(); var linked_2103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2102, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2104 lang.IFn; if linked_2103 == nil { ifn_2104 = lang.IFn_Cast(root_2102) } else { ifn_2104 = nil }; var arg_2105 any = st__23_2; if linked_2103 == nil { tmp15 = ifn_2104.Invoke_O__O(arg_2105) } else { tmp15 = linked_2103.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2102, arg_2105) } } else { tmp15 = and__1927000168__auto____24_2 }; if jrt.J2g_Truth(tmp15) {
					var tmp16 jrt.HashMap_I = jrt.HashMap_Cast(m__6); var tmp17 any; var root_2130 any = A_arbace_cpp_run_A_const_15.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2130, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2132 lang.IFn; if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any; var or__1927000174__auto____24_2 any = jrt.HashMap_Cast(m__6).Get_O__O(nm__22_2); if jrt.J2g_Truth(or__1927000174__auto____24_2) { arg_2133 = or__1927000174__auto____24_2 } else { arg_2133 = lang.PersistentVector_EMPTY.Ref() }; var arg_2134 any = lang.Tuple_Create_O_O__IPersistentVector(u__13, i__19_2); if linked_2131 == nil { tmp17 = ifn_2132.Invoke_O_O__O(arg_2133, arg_2134) } else { tmp17 = linked_2131.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2130, arg_2133, arg_2134) }; tmp16.Put_O_O__O(nm__22_2, tmp17)
//line :259:1
					seq_97000320__14, chunk_97000321__15, count_97000322__16, i_97000323__17 = seq_97000320__14, chunk_97000321__15, count_97000322__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000323__17); continue L3 } else { seq_97000320__14, chunk_97000321__15, count_97000322__16, i_97000323__17 = seq_97000320__14, chunk_97000321__15, count_97000322__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000323__17); continue L3 } } else { var temp__1927000414__auto____18 any; var root_2106 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2106, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2108 lang.IFn; if linked_2107 == nil { ifn_2108 = lang.IFn_Cast(root_2106) } else { ifn_2108 = nil }; var arg_2109 any = seq_97000320__14; if linked_2107 == nil { temp__1927000414__auto____18 = ifn_2108.Invoke_O__O(arg_2109) } else { temp__1927000414__auto____18 = linked_2107.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2106, arg_2109) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_97000320__19 any = temp__1927000414__auto____18; var tmp18 any; var root_2110 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_2111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2110, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2112 lang.IFn; if linked_2111 == nil { ifn_2112 = lang.IFn_Cast(root_2110) } else { ifn_2112 = nil }; var arg_2113 any = seq_97000320__19; if linked_2111 == nil { tmp18 = ifn_2112.Invoke_O__O(arg_2113) } else { tmp18 = linked_2111.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2110, arg_2113) }; if jrt.J2g_Truth(tmp18) { var c__1927000678__auto____20 any; var root_2114 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_2115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2114, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2116 lang.IFn; if linked_2115 == nil { ifn_2116 = lang.IFn_Cast(root_2114) } else { ifn_2116 = nil }; var arg_2117 any = seq_97000320__19; if linked_2115 == nil { c__1927000678__auto____20 = ifn_2116.Invoke_O__O(arg_2117) } else { c__1927000678__auto____20 = linked_2115.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2114, arg_2117) }; var tmp19 any; var root_2135 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_2136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2135, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2137 lang.IFn; if linked_2136 == nil { ifn_2137 = lang.IFn_Cast(root_2135) } else { ifn_2137 = nil }; var arg_2138 any = seq_97000320__19; if linked_2136 == nil { tmp19 = ifn_2137.Invoke_O__O(arg_2138) } else { tmp19 = linked_2136.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2135, arg_2138) }; seq_97000320__14, chunk_97000321__15, count_97000322__16, i_97000323__17 = tmp19, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__97000346__20 any; var root_2118 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_2119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2118, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2120 lang.IFn; if linked_2119 == nil { ifn_2120 = lang.IFn_Cast(root_2118) } else { ifn_2120 = nil }; var arg_2121 any = seq_97000320__19; if linked_2119 == nil { vec__97000346__20 = ifn_2120.Invoke_O__O(arg_2121) } else { vec__97000346__20 = linked_2119.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2118, arg_2121) }; var i__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000346__20, lang.RT_IntCast_J__I_NoInit(0), nil); var f__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000346__20, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__97000349__23 any; var root_2122 any = A_arbace_cpp_run_A_const_159.GetRawRoot__O(); var linked_2123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2122, A_arbace_cpp_run_def_name_A_fn_class); var ifn_2124 lang.IFn; if linked_2123 == nil { ifn_2124 = lang.IFn_Cast(root_2122) } else { ifn_2124 = nil }; var arg_2125 any = f__22; if linked_2123 == nil { vec__97000349__23 = ifn_2124.Invoke_O__O(arg_2125) } else { vec__97000349__23 = linked_2123.(*A_arbace_cpp_run_def_name_A).Invoke_O_O__O(root_2122, arg_2125) }; var nm__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000349__23, lang.RT_IntCast_J__I_NoInit(0), nil); var st__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000349__23, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp20 any; var and__1927000168__auto____26 any = nm__24; if jrt.J2g_Truth(and__1927000168__auto____26) { var root_2126 any = A_arbace_cpp_run_A_const_110.GetRawRoot__O(); var linked_2127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2126, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2128 lang.IFn; if linked_2127 == nil { ifn_2128 = lang.IFn_Cast(root_2126) } else { ifn_2128 = nil }; var arg_2129 any = st__25; if linked_2127 == nil { tmp20 = ifn_2128.Invoke_O__O(arg_2129) } else { tmp20 = linked_2127.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2126, arg_2129) } } else { tmp20 = and__1927000168__auto____26 }; if jrt.J2g_Truth(tmp20) {
						var tmp21 jrt.HashMap_I = jrt.HashMap_Cast(m__6); var tmp22 any; var root_2139 any = A_arbace_cpp_run_A_const_15.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2139, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2141 lang.IFn; if linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any; var or__1927000174__auto____26 any = jrt.HashMap_Cast(m__6).Get_O__O(nm__24); if jrt.J2g_Truth(or__1927000174__auto____26) { arg_2142 = or__1927000174__auto____26 } else { arg_2142 = lang.PersistentVector_EMPTY.Ref() }; var arg_2143 any = lang.Tuple_Create_O_O__IPersistentVector(u__13, i__21); if linked_2140 == nil { tmp22 = ifn_2141.Invoke_O_O__O(arg_2142, arg_2143) } else { tmp22 = linked_2140.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2139, arg_2142, arg_2143) }; tmp21.Put_O_O__O(nm__24, tmp22)
//line :259:1
						var tmp23 any; var root_2144 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_2145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2144, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2146 lang.IFn; if linked_2145 == nil { ifn_2146 = lang.IFn_Cast(root_2144) } else { ifn_2146 = nil }; var arg_2147 any = seq_97000320__19; if linked_2145 == nil { tmp23 = ifn_2146.Invoke_O__O(arg_2147) } else { tmp23 = linked_2145.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2144, arg_2147) }; seq_97000320__14, chunk_97000321__15, count_97000322__16, i_97000323__17 = tmp23, nil, 0, 0; continue L3 } else { var tmp24 any; var root_2148 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_2149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2148, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2150 lang.IFn; if linked_2149 == nil { ifn_2150 = lang.IFn_Cast(root_2148) } else { ifn_2150 = nil }; var arg_2151 any = seq_97000320__19; if linked_2149 == nil { tmp24 = ifn_2150.Invoke_O__O(arg_2151) } else { tmp24 = linked_2149.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2148, arg_2151) }; seq_97000320__14, chunk_97000321__15, count_97000322__16, i_97000323__17 = tmp24, nil, 0, 0; continue L3 } } } }; break L3 }; var tmp25 any; var root_2152 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_2153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2152, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2154 lang.IFn; if linked_2153 == nil { ifn_2154 = lang.IFn_Cast(root_2152) } else { ifn_2154 = nil }; var arg_2155 any = seq_97000316__12; if linked_2153 == nil { tmp25 = ifn_2154.Invoke_O__O(arg_2155) } else { tmp25 = linked_2153.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2152, arg_2155) }; seq_97000316__7, chunk_97000317__8, count_97000318__9, i_97000319__10 = tmp25, nil, 0, 0; continue L1 } } }
//line :243:1
		break L1 }; global__6 = m__6; var keep__7 any; var root_1898 any = A_arbace_cpp_run_A_const_39.GetRawRoot__O(); var linked_1899 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1898, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1900 lang.IFn; if


















	linked_1899 == nil { ifn_1900 = lang.IFn_Cast(root_1898) } else { ifn_1900 = nil }; var arg_1901 any; var fnbody__1904 any = A_arbace_cpp_run_prune_fn__97000352_A_New(); var tmp26 *jrt.Class; var fncls__1903 *jrt.Class = A_arbace_cpp_run_prune_fn__97000352_A_fn_class; if fncls__1903 == nil { var fncls__1903d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_170, false, nil); A_arbace_cpp_run_prune_fn__97000352_A_fn_class = fncls__1903d; tmp26 = fncls__1903d } else { tmp26 = fncls__1903 }; arg_1901 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1904, tmp26, nil); var arg_1902 any; var root_1905 any = A_arbace_cpp_run_A_const_97.GetRawRoot__O(); var linked_1906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1905, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1907 lang.IFn; if linked_1906 == nil { ifn_1907 = lang.IFn_Cast(root_1905) } else { ifn_1907 = nil }; var arg_1908 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref(); if linked_1906 == nil { arg_1902 = ifn_1907.Invoke_O__O(arg_1908) } else { arg_1902 = linked_1906.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1905, arg_1908) }; if linked_1899 == nil { keep__7 = ifn_1900.Invoke_O_O__O(arg_1901, arg_1902) } else { keep__7 = linked_1899.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1898, arg_1901, arg_1902) }; var q__8 any = /*line :243:1*/jrt.ArrayDeque_New(); var mark_BANG___9 any; var fnbody__1910 any = A_arbace_cpp_run_prune_mark_BANG___97000354_A_New_O_O(q__8, keep__7); var tmp27 *jrt.Class; var fncls__1909 *jrt.Class = A_arbace_cpp_run_prune_mark_BANG___97000354_A_fn_class; if




















	fncls__1909 == nil { var fncls__1909d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_171, false, fnbody__1910); A_arbace_cpp_run_prune_mark_BANG___97000354_A_fn_class = fncls__1909d; tmp27 = fncls__1909d } else { tmp27 = fncls__1909 }; mark_BANG___9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1910, tmp27, nil); var ref_BANG___10 any; var fnbody__1968 any = /*line :243:1*/A_arbace_cpp_run_prune_ref_BANG___97000356_A_New_O_O_O(local__5, mark_BANG___9, global__6); var tmp28 *jrt.Class; var fncls__1967 *jrt.Class = A_arbace_cpp_run_prune_ref_BANG___97000356_A_fn_class; if





















	fncls__1967 == nil { var fncls__1967d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_172, false, fnbody__1968); A_arbace_cpp_run_prune_ref_BANG___97000356_A_fn_class = fncls__1967d; tmp28 = fncls__1967d } else { tmp28 = fncls__1967 }; ref_BANG___10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1968, tmp28, nil); var seq_97000372__11 any; var root_2156 any = /*line :243:1*/A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2156, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2158 lang.IFn; if
























	linked_2157 == nil { ifn_2158 = lang.IFn_Cast(root_2156) } else { ifn_2158 = nil }; var arg_2159 any = roots__1; if linked_2157 == nil { seq_97000372__11 = ifn_2158.Invoke_O__O(arg_2159) } else { seq_97000372__11 = linked_2157.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2156, arg_2159) }; var chunk_97000373__12 any; var count_97000374__13 int64 = 0; var i_97000375__14 int64 = 0; L4:
//line :243:1
	for {
























		if lang.Numbers_Lt_J_J__Z_NoInit(i_97000375__14, count_97000374__13) { var r__15 any = lang.Indexed_Cast(chunk_97000373__12).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000375__14)); lang.IFn_Cast(ref_BANG___10).Invoke_O_O__O(nil, r__15); seq_97000372__11, chunk_97000373__12, count_97000374__13, i_97000375__14 = seq_97000372__11, chunk_97000373__12, count_97000374__13, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000375__14); continue L4 } else { var temp__1927000414__auto____15 any; var root_2160 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2160, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2162 lang.IFn; if linked_2161 == nil { ifn_2162 = lang.IFn_Cast(root_2160) } else { ifn_2162 = nil }; var arg_2163 any = seq_97000372__11; if linked_2161 == nil { temp__1927000414__auto____15 = ifn_2162.Invoke_O__O(arg_2163) } else { temp__1927000414__auto____15 = linked_2161.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2160, arg_2163) }; if jrt.J2g_Truth(temp__1927000414__auto____15) { var seq_97000372__16 any = temp__1927000414__auto____15; var tmp29 any; var root_2164 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_2165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2164, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2166 lang.IFn; if linked_2165 == nil { ifn_2166 = lang.IFn_Cast(root_2164) } else { ifn_2166 = nil }; var arg_2167 any = seq_97000372__16; if linked_2165 == nil { tmp29 = ifn_2166.Invoke_O__O(arg_2167) } else { tmp29 = linked_2165.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2164, arg_2167) }; if jrt.J2g_Truth(tmp29) { var c__1927000678__auto____17 any; var root_2168 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_2169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2168, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2170 lang.IFn; if linked_2169 == nil { ifn_2170 = lang.IFn_Cast(root_2168) } else { ifn_2170 = nil }; var arg_2171 any = seq_97000372__16; if linked_2169 == nil { c__1927000678__auto____17 = ifn_2170.Invoke_O__O(arg_2171) } else { c__1927000678__auto____17 = linked_2169.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2168, arg_2171) }; var tmp30 any; var root_2204 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_2205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2204, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2206 lang.IFn; if linked_2205 == nil { ifn_2206 = lang.IFn_Cast(root_2204) } else { ifn_2206 = nil }; var arg_2207 any = seq_97000372__16; if linked_2205 == nil { tmp30 = ifn_2206.Invoke_O__O(arg_2207) } else { tmp30 = linked_2205.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2204, arg_2207) }; seq_97000372__11, chunk_97000373__12, count_97000374__13, i_97000375__14 = tmp30, c__1927000678__auto____17, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var r__17 any; var root_2172 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_2173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2172, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2174 lang.IFn; if linked_2173 == nil { ifn_2174 = lang.IFn_Cast(root_2172) } else { ifn_2174 = nil }; var arg_2175 any = seq_97000372__16; if linked_2173 == nil { r__17 = ifn_2174.Invoke_O__O(arg_2175) } else { r__17 = linked_2173.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2172, arg_2175) }; lang.IFn_Cast(ref_BANG___10).Invoke_O_O__O(nil, r__17); var tmp31 any; var root_2208 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_2209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2208, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2210 lang.IFn; if linked_2209 == nil { ifn_2210 = lang.IFn_Cast(root_2208) } else { ifn_2210 = nil }; var arg_2211 any = seq_97000372__16; if linked_2209 == nil { tmp31 = ifn_2210.Invoke_O__O(arg_2211) } else { tmp31 = linked_2209.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2208, arg_2211) }; seq_97000372__11, chunk_97000373__12, count_97000374__13, i_97000375__14 = tmp31, nil, 0, 0; continue L4 } } }
//line :243:1
		break L4 }; var seq_97000376__11 any; var root_2176 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2176, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2178 lang.IFn; if

























	linked_2177 == nil { ifn_2178 = lang.IFn_Cast(root_2176) } else { ifn_2178 = nil }; var arg_2179 any; var root_2180 any = A_arbace_cpp_run_A_const_97.GetRawRoot__O(); var linked_2181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2180, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_2182 lang.IFn; if linked_2181 == nil { ifn_2182 = lang.IFn_Cast(root_2180) } else { ifn_2182 = nil }; var arg_2183 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref(); if linked_2181 == nil { arg_2179 = ifn_2182.Invoke_O__O(arg_2183) } else { arg_2179 = linked_2181.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_2180, arg_2183) }; if linked_2177 == nil { seq_97000376__11 = ifn_2178.Invoke_O__O(arg_2179) } else { seq_97000376__11 = linked_2177.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2176, arg_2179) }; var chunk_97000377__12 any; var count_97000378__13 int64 = 0; var i_97000379__14 int64 = 0; L5:
//line :243:1
	for {

























		if lang.Numbers_Lt_J_J__Z_NoInit(i_97000379__14, count_97000378__13) { var u__15 any = lang.Indexed_Cast(chunk_97000377__12).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000379__14)); var seq_97000384__16 any; var root_2212 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2212, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2214 lang.IFn; if linked_2213 == nil { ifn_2214 = lang.IFn_Cast(root_2212) } else { ifn_2214 = nil }; var arg_2215 any; var root_2216 any = A_arbace_cpp_run_A_const_157.GetRawRoot__O(); var linked_2217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2216, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2218 lang.IFn; if linked_2217 == nil { ifn_2218 = lang.IFn_Cast(root_2216) } else { ifn_2218 = nil }; var arg_2219 any = A_arbace_cpp_run_A_const_158.GetRawRoot__O(); var arg_2220 any = lang.IFn_Cast(forms__4).Invoke_O__O(u__15); if linked_2217 == nil { arg_2215 = ifn_2218.Invoke_O_O__O(arg_2219, arg_2220) } else { arg_2215 = linked_2217.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2216, arg_2219, arg_2220) }; if linked_2213 == nil { seq_97000384__16 = ifn_2214.Invoke_O__O(arg_2215) } else { seq_97000384__16 = linked_2213.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2212, arg_2215) }; var chunk_97000385__17 any; var count_97000386__18 int64 = 0; var i_97000387__19 int64 = 0; L6: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_97000387__19, count_97000386__18) { var vec__97000388__20 any = lang.Indexed_Cast(chunk_97000385__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000387__19)); var i__21_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000388__20, lang.RT_IntCast_J__I_NoInit(0), nil); var f__22_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000388__20, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp32 any; var root_2221 any = A_arbace_cpp_run_A_const_159.GetRawRoot__O(); var linked_2222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2221, A_arbace_cpp_run_def_name_A_fn_class); var ifn_2223 lang.IFn; if linked_2222 == nil { ifn_2223 = lang.IFn_Cast(root_2221) } else { ifn_2223 = nil }; var arg_2224 any = f__22_2; if linked_2222 == nil { tmp32 = ifn_2223.Invoke_O__O(arg_2224) } else { tmp32 = linked_2222.(*A_arbace_cpp_run_def_name_A).Invoke_O_O__O(root_2221, arg_2224) }; if lang.Util_Identical_O_O__Z_NoInit(tmp32, nil) { lang.IFn_Cast(mark_BANG___9).Invoke_O_O__O(u__15, i__21_2); seq_97000384__16, chunk_97000385__17, count_97000386__18, i_97000387__19 = seq_97000384__16, chunk_97000385__17, count_97000386__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000387__19); continue L6 } else { seq_97000384__16, chunk_97000385__17, count_97000386__18, i_97000387__19 = seq_97000384__16, chunk_97000385__17, count_97000386__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000387__19); continue L6 } } else { var temp__1927000414__auto____20 any; var root_2225 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2225, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2227 lang.IFn; if linked_2226 == nil { ifn_2227 = lang.IFn_Cast(root_2225) } else { ifn_2227 = nil }; var arg_2228 any = seq_97000384__16; if linked_2226 == nil { temp__1927000414__auto____20 = ifn_2227.Invoke_O__O(arg_2228) } else { temp__1927000414__auto____20 = linked_2226.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2225, arg_2228) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_97000384__21 any = temp__1927000414__auto____20; var tmp33 any; var root_2229 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_2230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2229, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2231 lang.IFn; if linked_2230 == nil { ifn_2231 = lang.IFn_Cast(root_2229) } else { ifn_2231 = nil }; var arg_2232 any = seq_97000384__21; if linked_2230 == nil { tmp33 = ifn_2231.Invoke_O__O(arg_2232) } else { tmp33 = linked_2230.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2229, arg_2232) }; if jrt.J2g_Truth(tmp33) { var c__1927000678__auto____22 any; var root_2233 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_2234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2233, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2235 lang.IFn; if linked_2234 == nil { ifn_2235 = lang.IFn_Cast(root_2233) } else { ifn_2235 = nil }; var arg_2236 any = seq_97000384__21; if linked_2234 == nil { c__1927000678__auto____22 = ifn_2235.Invoke_O__O(arg_2236) } else { c__1927000678__auto____22 = linked_2234.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2233, arg_2236) }; var tmp34 any; var root_2245 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_2246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2245, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2247 lang.IFn; if linked_2246 == nil { ifn_2247 = lang.IFn_Cast(root_2245) } else { ifn_2247 = nil }; var arg_2248 any = seq_97000384__21; if linked_2246 == nil { tmp34 = ifn_2247.Invoke_O__O(arg_2248) } else { tmp34 = linked_2246.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2245, arg_2248) }; seq_97000384__16, chunk_97000385__17, count_97000386__18, i_97000387__19 = tmp34, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var vec__97000391__22 any; var root_2237 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_2238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2237, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2239 lang.IFn; if linked_2238 == nil { ifn_2239 = lang.IFn_Cast(root_2237) } else { ifn_2239 = nil }; var arg_2240 any = seq_97000384__21; if linked_2238 == nil { vec__97000391__22 = ifn_2239.Invoke_O__O(arg_2240) } else { vec__97000391__22 = linked_2238.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2237, arg_2240) }; var i__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000391__22, lang.RT_IntCast_J__I_NoInit(0), nil); var f__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000391__22, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp35 any; var root_2241 any = A_arbace_cpp_run_A_const_159.GetRawRoot__O(); var linked_2242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2241, A_arbace_cpp_run_def_name_A_fn_class); var ifn_2243 lang.IFn; if linked_2242 == nil { ifn_2243 = lang.IFn_Cast(root_2241) } else { ifn_2243 = nil }; var arg_2244 any = f__24; if linked_2242 == nil { tmp35 = ifn_2243.Invoke_O__O(arg_2244) } else { tmp35 = linked_2242.(*A_arbace_cpp_run_def_name_A).Invoke_O_O__O(root_2241, arg_2244) }; if lang.Util_Identical_O_O__Z_NoInit(tmp35, nil) { lang.IFn_Cast(mark_BANG___9).Invoke_O_O__O(u__15, i__23); var tmp36 any; var root_2249 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_2250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2249, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2251 lang.IFn; if linked_2250 == nil { ifn_2251 = lang.IFn_Cast(root_2249) } else { ifn_2251 = nil }; var arg_2252 any = seq_97000384__21; if linked_2250 == nil { tmp36 = ifn_2251.Invoke_O__O(arg_2252) } else { tmp36 = linked_2250.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2249, arg_2252) }; seq_97000384__16, chunk_97000385__17, count_97000386__18, i_97000387__19 = tmp36, nil, 0, 0; continue L6 } else { var tmp37 any; var root_2253 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_2254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2253, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2255 lang.IFn; if linked_2254 == nil { ifn_2255 = lang.IFn_Cast(root_2253) } else { ifn_2255 = nil }; var arg_2256 any = seq_97000384__21; if linked_2254 == nil { tmp37 = ifn_2255.Invoke_O__O(arg_2256) } else { tmp37 = linked_2254.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2253, arg_2256) }; seq_97000384__16, chunk_97000385__17, count_97000386__18, i_97000387__19 = tmp37, nil, 0, 0; continue L6 } } } }; break L6 }; seq_97000376__11, chunk_97000377__12, count_97000378__13, i_97000379__14 = seq_97000376__11, chunk_97000377__12, count_97000378__13, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000379__14); continue L5 } else { var temp__1927000414__auto____15_2 any; var root_2184 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2184, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2186 lang.IFn; if linked_2185 == nil { ifn_2186 = lang.IFn_Cast(root_2184) } else { ifn_2186 = nil }; var arg_2187 any = seq_97000376__11; if linked_2185 == nil { temp__1927000414__auto____15_2 = ifn_2186.Invoke_O__O(arg_2187) } else { temp__1927000414__auto____15_2 = linked_2185.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2184, arg_2187) }; if jrt.J2g_Truth(temp__1927000414__auto____15_2) { var seq_97000376__16 any = temp__1927000414__auto____15_2; var tmp38 any; var root_2188 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_2189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2188, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2190 lang.IFn; if linked_2189 == nil { ifn_2190 = lang.IFn_Cast(root_2188) } else { ifn_2190 = nil }; var arg_2191 any = seq_97000376__16; if linked_2189 == nil { tmp38 = ifn_2190.Invoke_O__O(arg_2191) } else { tmp38 = linked_2189.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2188, arg_2191) }; if jrt.J2g_Truth(tmp38) { var c__1927000678__auto____17_2 any; var root_2192 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_2193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2192, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2194 lang.IFn; if linked_2193 == nil { ifn_2194 = lang.IFn_Cast(root_2192) } else { ifn_2194 = nil }; var arg_2195 any = seq_97000376__16; if linked_2193 == nil { c__1927000678__auto____17_2 = ifn_2194.Invoke_O__O(arg_2195) } else { c__1927000678__auto____17_2 = linked_2193.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2192, arg_2195) }; var tmp39 any; var root_2257 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_2258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2257, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2259 lang.IFn; if linked_2258 == nil { ifn_2259 = lang.IFn_Cast(root_2257) } else { ifn_2259 = nil }; var arg_2260 any = seq_97000376__16; if linked_2258 == nil { tmp39 = ifn_2259.Invoke_O__O(arg_2260) } else { tmp39 = linked_2258.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2257, arg_2260) }; seq_97000376__11, chunk_97000377__12, count_97000378__13, i_97000379__14 = tmp39, c__1927000678__auto____17_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____17_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var u__17 any; var root_2196 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_2197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2196, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2198 lang.IFn; if linked_2197 == nil { ifn_2198 = lang.IFn_Cast(root_2196) } else { ifn_2198 = nil }; var arg_2199 any = seq_97000376__16; if linked_2197 == nil { u__17 = ifn_2198.Invoke_O__O(arg_2199) } else { u__17 = linked_2197.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2196, arg_2199) }; var seq_97000380__18 any; var root_2261 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2261, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2263 lang.IFn; if linked_2262 == nil { ifn_2263 = lang.IFn_Cast(root_2261) } else { ifn_2263 = nil }; var arg_2264 any; var root_2265 any = A_arbace_cpp_run_A_const_157.GetRawRoot__O(); var linked_2266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2265, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2267 lang.IFn; if linked_2266 == nil { ifn_2267 = lang.IFn_Cast(root_2265) } else { ifn_2267 = nil }; var arg_2268 any = A_arbace_cpp_run_A_const_158.GetRawRoot__O(); var arg_2269 any = lang.IFn_Cast(forms__4).Invoke_O__O(u__17); if linked_2266 == nil { arg_2264 = ifn_2267.Invoke_O_O__O(arg_2268, arg_2269) } else { arg_2264 = linked_2266.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2265, arg_2268, arg_2269) }; if linked_2262 == nil { seq_97000380__18 = ifn_2263.Invoke_O__O(arg_2264) } else { seq_97000380__18 = linked_2262.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2261, arg_2264) }; var chunk_97000381__19 any; var count_97000382__20 int64 = 0; var i_97000383__21 int64 = 0; L7: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_97000383__21, count_97000382__20) { var vec__97000394__22 any = lang.Indexed_Cast(chunk_97000381__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000383__21)); var i__23_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000394__22, lang.RT_IntCast_J__I_NoInit(0), nil); var f__24_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000394__22, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp40 any; var root_2270 any = A_arbace_cpp_run_A_const_159.GetRawRoot__O(); var linked_2271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2270, A_arbace_cpp_run_def_name_A_fn_class); var ifn_2272 lang.IFn; if linked_2271 == nil { ifn_2272 = lang.IFn_Cast(root_2270) } else { ifn_2272 = nil }; var arg_2273 any = f__24_2; if linked_2271 == nil { tmp40 = ifn_2272.Invoke_O__O(arg_2273) } else { tmp40 = linked_2271.(*A_arbace_cpp_run_def_name_A).Invoke_O_O__O(root_2270, arg_2273) }; if lang.Util_Identical_O_O__Z_NoInit(tmp40, nil) { lang.IFn_Cast(mark_BANG___9).Invoke_O_O__O(u__17, i__23_2); seq_97000380__18, chunk_97000381__19, count_97000382__20, i_97000383__21 = seq_97000380__18, chunk_97000381__19, count_97000382__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000383__21); continue L7 } else { seq_97000380__18, chunk_97000381__19, count_97000382__20, i_97000383__21 = seq_97000380__18, chunk_97000381__19, count_97000382__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000383__21); continue L7 } } else { var temp__1927000414__auto____22 any; var root_2274 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2274, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2276 lang.IFn; if linked_2275 == nil { ifn_2276 = lang.IFn_Cast(root_2274) } else { ifn_2276 = nil }; var arg_2277 any = seq_97000380__18; if linked_2275 == nil { temp__1927000414__auto____22 = ifn_2276.Invoke_O__O(arg_2277) } else { temp__1927000414__auto____22 = linked_2275.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2274, arg_2277) }; if jrt.J2g_Truth(temp__1927000414__auto____22) { var seq_97000380__23 any = temp__1927000414__auto____22; var tmp41 any; var root_2278 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_2279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2278, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2280 lang.IFn; if linked_2279 == nil { ifn_2280 = lang.IFn_Cast(root_2278) } else { ifn_2280 = nil }; var arg_2281 any = seq_97000380__23; if linked_2279 == nil { tmp41 = ifn_2280.Invoke_O__O(arg_2281) } else { tmp41 = linked_2279.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2278, arg_2281) }; if jrt.J2g_Truth(tmp41) { var c__1927000678__auto____24 any; var root_2282 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_2283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2282, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2284 lang.IFn; if linked_2283 == nil { ifn_2284 = lang.IFn_Cast(root_2282) } else { ifn_2284 = nil }; var arg_2285 any = seq_97000380__23; if linked_2283 == nil { c__1927000678__auto____24 = ifn_2284.Invoke_O__O(arg_2285) } else { c__1927000678__auto____24 = linked_2283.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2282, arg_2285) }; var tmp42 any; var root_2294 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_2295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2294, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2296 lang.IFn; if linked_2295 == nil { ifn_2296 = lang.IFn_Cast(root_2294) } else { ifn_2296 = nil }; var arg_2297 any = seq_97000380__23; if linked_2295 == nil { tmp42 = ifn_2296.Invoke_O__O(arg_2297) } else { tmp42 = linked_2295.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2294, arg_2297) }; seq_97000380__18, chunk_97000381__19, count_97000382__20, i_97000383__21 = tmp42, c__1927000678__auto____24, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var vec__97000397__24 any; var root_2286 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_2287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2286, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2288 lang.IFn; if linked_2287 == nil { ifn_2288 = lang.IFn_Cast(root_2286) } else { ifn_2288 = nil }; var arg_2289 any = seq_97000380__23; if linked_2287 == nil { vec__97000397__24 = ifn_2288.Invoke_O__O(arg_2289) } else { vec__97000397__24 = linked_2287.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2286, arg_2289) }; var i__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000397__24, lang.RT_IntCast_J__I_NoInit(0), nil); var f__26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000397__24, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp43 any; var root_2290 any = A_arbace_cpp_run_A_const_159.GetRawRoot__O(); var linked_2291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2290, A_arbace_cpp_run_def_name_A_fn_class); var ifn_2292 lang.IFn; if linked_2291 == nil { ifn_2292 = lang.IFn_Cast(root_2290) } else { ifn_2292 = nil }; var arg_2293 any = f__26; if linked_2291 == nil { tmp43 = ifn_2292.Invoke_O__O(arg_2293) } else { tmp43 = linked_2291.(*A_arbace_cpp_run_def_name_A).Invoke_O_O__O(root_2290, arg_2293) }; if lang.Util_Identical_O_O__Z_NoInit(tmp43, nil) { lang.IFn_Cast(mark_BANG___9).Invoke_O_O__O(u__17, i__25); var tmp44 any; var root_2298 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_2299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2298, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2300 lang.IFn; if linked_2299 == nil { ifn_2300 = lang.IFn_Cast(root_2298) } else { ifn_2300 = nil }; var arg_2301 any = seq_97000380__23; if linked_2299 == nil { tmp44 = ifn_2300.Invoke_O__O(arg_2301) } else { tmp44 = linked_2299.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2298, arg_2301) }; seq_97000380__18, chunk_97000381__19, count_97000382__20, i_97000383__21 = tmp44, nil, 0, 0; continue L7 } else { var tmp45 any; var root_2302 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_2303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2302, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2304 lang.IFn; if linked_2303 == nil { ifn_2304 = lang.IFn_Cast(root_2302) } else { ifn_2304 = nil }; var arg_2305 any = seq_97000380__23; if linked_2303 == nil { tmp45 = ifn_2304.Invoke_O__O(arg_2305) } else { tmp45 = linked_2303.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2302, arg_2305) }; seq_97000380__18, chunk_97000381__19, count_97000382__20, i_97000383__21 = tmp45, nil, 0, 0; continue L7 } } } }; break L7 }; var tmp46 any; var root_2306 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_2307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2306, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2308 lang.IFn; if linked_2307 == nil { ifn_2308 = lang.IFn_Cast(root_2306) } else { ifn_2308 = nil }; var arg_2309 any = seq_97000376__16; if linked_2307 == nil { tmp46 = ifn_2308.Invoke_O__O(arg_2309) } else { tmp46 = linked_2307.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2306, arg_2309) }; seq_97000376__11, chunk_97000377__12, count_97000378__13, i_97000379__14 = tmp46, nil, 0, 0; continue L5 } } }
//line :243:1
		break L5 }; L8: for {


























			var tmp47 any; var root_2200 any = A_arbace_cpp_run_A_const_110.GetRawRoot__O(); var linked_2201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2200, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2202 lang.IFn; if linked_2201 == nil { ifn_2202 = lang.IFn_Cast(root_2200) } else { ifn_2202 = nil }; var arg_2203 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ArrayDeque_Cast(q__8).IsEmpty__Z()).Ref(); if linked_2201 == nil { tmp47 = ifn_2202.Invoke_O__O(arg_2203) } else { tmp47 = linked_2201.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2200, arg_2203) }; if jrt.J2g_Truth(tmp47) { var vec__97000400__11 any = jrt.ArrayDeque_Cast(q__8).Poll__O(); var u__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000400__11, lang.RT_IntCast_J__I_NoInit(0), nil); var i__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000400__11, lang.RT_IntCast_J__I_NoInit(1), nil); var seq_97000403__14 any; var root_2310 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2310, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2312 lang.IFn

				if linked_2311 == nil { ifn_2312 = lang.IFn_Cast(root_2310) } else { ifn_2312 = nil }; var arg_2313 any; var root_2314 any = A_arbace_cpp_run_A_const_106.GetRawRoot__O(); var linked_2315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2314, aot_arbace_c_musl.A_arbace_c_musl_refs_A_fn_class); var ifn_2316 lang.IFn; if linked_2315 == nil { ifn_2316 = lang.IFn_Cast(root_2314) } else { ifn_2316 = nil }; var arg_2317 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(lang.IFn_Cast(forms__4).Invoke_O__O(u__12)).Invoke_O__O(i__13)); if linked_2315 == nil { arg_2313 = ifn_2316.Invoke_O__O(arg_2317) } else { arg_2313 = linked_2315.(*aot_arbace_c_musl.A_arbace_c_musl_refs_A).Invoke_O_O__O(root_2314, arg_2317) }; if linked_2311 == nil { seq_97000403__14 = ifn_2312.Invoke_O__O(arg_2313) } else { seq_97000403__14 = linked_2311.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2310, arg_2313) }
//line :270:1
				var chunk_97000404__15 any; var count_97000405__16 int64 = 0; var i_97000406__17 int64 = 0; L9: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(i_97000406__17, count_97000405__16) { var r__18 any = lang.Indexed_Cast(chunk_97000404__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000406__17)); lang.IFn_Cast(ref_BANG___10).Invoke_O_O__O(u__12, r__18); seq_97000403__14, chunk_97000404__15, count_97000405__16, i_97000406__17 = seq_97000403__14, chunk_97000404__15, count_97000405__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000406__17); continue L9 } else { var temp__1927000414__auto____18_2 any; var root_2318 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2318, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2320 lang.IFn; if linked_2319 == nil { ifn_2320 = lang.IFn_Cast(root_2318) } else { ifn_2320 = nil }; var arg_2321 any = seq_97000403__14; if linked_2319 == nil { temp__1927000414__auto____18_2 = ifn_2320.Invoke_O__O(arg_2321) } else { temp__1927000414__auto____18_2 = linked_2319.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2318, arg_2321) }; if jrt.J2g_Truth(temp__1927000414__auto____18_2) { var seq_97000403__19 any = temp__1927000414__auto____18_2; var tmp48 any; var root_2322 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_2323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2322, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2324 lang.IFn; if linked_2323 == nil { ifn_2324 = lang.IFn_Cast(root_2322) } else { ifn_2324 = nil }; var arg_2325 any = seq_97000403__19; if linked_2323 == nil { tmp48 = ifn_2324.Invoke_O__O(arg_2325) } else { tmp48 = linked_2323.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2322, arg_2325) }; if jrt.J2g_Truth(tmp48) { var c__1927000678__auto____20_2 any; var root_2326 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_2327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2326, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2328 lang.IFn; if linked_2327 == nil { ifn_2328 = lang.IFn_Cast(root_2326) } else { ifn_2328 = nil }; var arg_2329 any = seq_97000403__19; if linked_2327 == nil { c__1927000678__auto____20_2 = ifn_2328.Invoke_O__O(arg_2329) } else { c__1927000678__auto____20_2 = linked_2327.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2326, arg_2329) }; var tmp49 any; var root_2334 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_2335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2334, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2336 lang.IFn; if linked_2335 == nil { ifn_2336 = lang.IFn_Cast(root_2334) } else { ifn_2336 = nil }; var arg_2337 any = seq_97000403__19; if linked_2335 == nil { tmp49 = ifn_2336.Invoke_O__O(arg_2337) } else { tmp49 = linked_2335.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2334, arg_2337) }; seq_97000403__14, chunk_97000404__15, count_97000405__16, i_97000406__17 = tmp49, c__1927000678__auto____20_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L9 } else { var r__20 any; var root_2330 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_2331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2330, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2332 lang.IFn; if linked_2331 == nil { ifn_2332 = lang.IFn_Cast(root_2330) } else { ifn_2332 = nil }; var arg_2333 any = seq_97000403__19; if linked_2331 == nil { r__20 = ifn_2332.Invoke_O__O(arg_2333) } else { r__20 = linked_2331.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2330, arg_2333) }; lang.IFn_Cast(ref_BANG___10).Invoke_O_O__O(u__12, r__20); var tmp50 any; var root_2338 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_2339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2338, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2340 lang.IFn; if linked_2339 == nil { ifn_2340 = lang.IFn_Cast(root_2338) } else { ifn_2340 = nil }; var arg_2341 any = seq_97000403__19; if linked_2339 == nil { tmp50 = ifn_2340.Invoke_O__O(arg_2341) } else { tmp50 = linked_2339.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2338, arg_2341) }; seq_97000403__14, chunk_97000404__15, count_97000405__16, i_97000406__17 = tmp50, nil, 0, 0; continue L9 } } }
//line :270:1
					break L9 }; continue L8 }
//line :243:1
			break L8 }; var root_1969 any =





























	A_arbace_cpp_run_A_const_39.GetRawRoot__O(); var linked_1970 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1969, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1971 lang.IFn; if linked_1970 == nil { ifn_1971 = lang.IFn_Cast(root_1969) } else { ifn_1971 = nil }; var arg_1972 any; var fnbody__1993 any = A_arbace_cpp_run_prune_fn__97000407_A_New_O_O(forms__4, keep__7); var tmp51 *jrt.Class; var fncls__1992 *jrt.Class = A_arbace_cpp_run_prune_fn__97000407_A_fn_class; if fncls__1992 == nil { var fncls__1992d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_173, false, fnbody__1993); A_arbace_cpp_run_prune_fn__97000407_A_fn_class = fncls__1992d; tmp51 = fncls__1992d } else { tmp51 = fncls__1992 }; arg_1972 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1993, tmp51, nil); var arg_1973 any; var root_1994 any = A_arbace_cpp_run_A_const_97.GetRawRoot__O(); var linked_1995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1994, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1996 lang.IFn; if
	linked_1995 == nil { ifn_1996 = lang.IFn_Cast(root_1994) } else { ifn_1996 = nil }; var arg_1997 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref(); if linked_1995 == nil { arg_1973 = ifn_1996.Invoke_O__O(arg_1997) } else { arg_1973 = linked_1995.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1994, arg_1997) }; var arg_1974 any = units__0; if /*line :273:1*/ linked_1970 == nil { return ifn_1971.Invoke_O_O_O__O(arg_1972, arg_1973, arg_1974) } else { return linked_1970.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O_O__O(root_1969, arg_1972, arg_1973, arg_1974) } }
//line :251:1
func A_arbace_cpp_run_prune_fn__97000296_A_New() *A_arbace_cpp_run_prune_fn__97000296_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_prune_fn__97000296_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_cpp_run_prune_fn__97000296_A) Ctor() {}
//line :251:1
func (t *A_arbace_cpp_run_prune_fn__97000296_A) Invoke_O_O__O(self, p1__97000295_SHARP___1 any) any { var root_1830 any = A_arbace_cpp_run_A_const_62.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1832 lang.IFn; if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var tmp1 *lang.Keyword = A_arbace_cpp_run_A_const_70; var arg_1833 any = tmp1.Invoke_O__O(A_arbace_cpp_run_A_const_156.Invoke_O__O(p1__97000295_SHARP___1)); if linked_1831 == nil { return ifn_1832.Invoke_O__O(arg_1833) } else { return linked_1831.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1830, arg_1833) } }

func A_arbace_cpp_run_prune_fn__97000298_A_New() *A_arbace_cpp_run_prune_fn__97000298_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_prune_fn__97000298_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_cpp_run_prune_fn__97000298_A) Ctor() {}
//line :253:1
func (t *A_arbace_cpp_run_prune_fn__97000298_A) Invoke_O_O__O(self, fs__1 any) any { var m__2 any = jrt.HashMap_New(); var seq_97000299__3 any; var root_1841 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1843 lang.IFn; if
											linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any; var root_1845 any = A_arbace_cpp_run_A_const_157.GetRawRoot__O(); var linked_1846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1845, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1847 lang.IFn; if linked_1846 == nil { ifn_1847 = lang.IFn_Cast(root_1845) } else { ifn_1847 = nil }; var arg_1848 any = A_arbace_cpp_run_A_const_158.GetRawRoot__O(); var arg_1849 any = fs__1; if linked_1846 == nil { arg_1844 = ifn_1847.Invoke_O_O__O(arg_1848, arg_1849) } else { arg_1844 = linked_1846.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1845, arg_1848, arg_1849) }; if linked_1842 == nil { seq_97000299__3 = ifn_1843.Invoke_O__O(arg_1844) } else { seq_97000299__3 = linked_1842.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1841, arg_1844) }; var chunk_97000300__4 any; var count_97000301__5 int64 = 0; var i_97000302__6 int64 = 0; L1:
//line :253:1
	for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_97000302__6, count_97000301__5) { var vec__97000303__7 any = lang.Indexed_Cast(chunk_97000300__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000302__6)); var i__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000303__7, lang.RT_IntCast_J__I_NoInit(0), nil); var f__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000303__7, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__97000306__10 any; var root_1850 any = A_arbace_cpp_run_A_const_159.GetRawRoot__O(); var linked_1851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1850, A_arbace_cpp_run_def_name_A_fn_class); var ifn_1852 lang.IFn; if linked_1851 == nil { ifn_1852 = lang.IFn_Cast(root_1850) } else { ifn_1852 = nil }; var arg_1853 any = f__9; if linked_1851 == nil { vec__97000306__10 = ifn_1852.Invoke_O__O(arg_1853) } else { vec__97000306__10 = linked_1851.(*A_arbace_cpp_run_def_name_A).Invoke_O_O__O(root_1850, arg_1853) }; var nm__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000306__10, lang.RT_IntCast_J__I_NoInit(0), nil); if jrt.J2g_Truth(nm__11) {
			var tmp1 jrt.HashMap_I = jrt.HashMap_Cast(m__2); var tmp2 any; var root_1874 any = A_arbace_cpp_run_A_const_15.GetRawRoot__O(); var linked_1875 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1874, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1876 lang.IFn; if linked_1875 == nil { ifn_1876 = lang.IFn_Cast(root_1874) } else { ifn_1876 = nil }; var arg_1877 any; var or__1927000174__auto____12 any = jrt.HashMap_Cast(m__2).Get_O__O(nm__11); if jrt.J2g_Truth(or__1927000174__auto____12) { arg_1877 = or__1927000174__auto____12 } else { arg_1877 = lang.PersistentVector_EMPTY.Ref() }; var arg_1878 any = i__8; if linked_1875 == nil { tmp2 = ifn_1876.Invoke_O_O__O(arg_1877, arg_1878) } else { tmp2 = linked_1875.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1874, arg_1877, arg_1878) }; tmp1.Put_O_O__O(nm__11, tmp2)
//line :254:1
			seq_97000299__3, chunk_97000300__4, count_97000301__5, i_97000302__6 = seq_97000299__3, chunk_97000300__4, count_97000301__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000302__6); continue L1 } else { seq_97000299__3, chunk_97000300__4, count_97000301__5, i_97000302__6 = seq_97000299__3, chunk_97000300__4, count_97000301__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000302__6); continue L1 } } else { var temp__1927000414__auto____7 any; var root_1854 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1854, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1856 lang.IFn; if linked_1855 == nil { ifn_1856 = lang.IFn_Cast(root_1854) } else { ifn_1856 = nil }; var arg_1857 any = seq_97000299__3; if linked_1855 == nil { temp__1927000414__auto____7 = ifn_1856.Invoke_O__O(arg_1857) } else { temp__1927000414__auto____7 = linked_1855.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1854, arg_1857) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_97000299__8 any = temp__1927000414__auto____7; var tmp3 any; var root_1858 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_1859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1858, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1860 lang.IFn; if linked_1859 == nil { ifn_1860 = lang.IFn_Cast(root_1858) } else { ifn_1860 = nil }; var arg_1861 any = seq_97000299__8; if linked_1859 == nil { tmp3 = ifn_1860.Invoke_O__O(arg_1861) } else { tmp3 = linked_1859.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1858, arg_1861) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____9 any; var root_1862 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1862, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1864 lang.IFn; if linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; var arg_1865 any = seq_97000299__8; if linked_1863 == nil { c__1927000678__auto____9 = ifn_1864.Invoke_O__O(arg_1865) } else { c__1927000678__auto____9 = linked_1863.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1862, arg_1865) }; var tmp4 any; var root_1879 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_1880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1879, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1881 lang.IFn; if linked_1880 == nil { ifn_1881 = lang.IFn_Cast(root_1879) } else { ifn_1881 = nil }; var arg_1882 any = seq_97000299__8; if linked_1880 == nil { tmp4 = ifn_1881.Invoke_O__O(arg_1882) } else { tmp4 = linked_1880.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1879, arg_1882) }; seq_97000299__3, chunk_97000300__4, count_97000301__5, i_97000302__6 = tmp4, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__97000309__9 any; var root_1866 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1866, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1868 lang.IFn; if linked_1867 == nil { ifn_1868 = lang.IFn_Cast(root_1866) } else { ifn_1868 = nil }; var arg_1869 any = seq_97000299__8; if linked_1867 == nil { vec__97000309__9 = ifn_1868.Invoke_O__O(arg_1869) } else { vec__97000309__9 = linked_1867.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1866, arg_1869) }; var i__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000309__9, lang.RT_IntCast_J__I_NoInit(0), nil); var f__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000309__9, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__97000312__12 any; var root_1870 any = A_arbace_cpp_run_A_const_159.GetRawRoot__O(); var linked_1871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1870, A_arbace_cpp_run_def_name_A_fn_class); var ifn_1872 lang.IFn; if linked_1871 == nil { ifn_1872 = lang.IFn_Cast(root_1870) } else { ifn_1872 = nil }; var arg_1873 any = f__11; if linked_1871 == nil { vec__97000312__12 = ifn_1872.Invoke_O__O(arg_1873) } else { vec__97000312__12 = linked_1871.(*A_arbace_cpp_run_def_name_A).Invoke_O_O__O(root_1870, arg_1873) }; var nm__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000312__12, lang.RT_IntCast_J__I_NoInit(0), nil); if jrt.J2g_Truth(nm__13) {
				var tmp5 jrt.HashMap_I = jrt.HashMap_Cast(m__2); var tmp6 any; var root_1883 any = A_arbace_cpp_run_A_const_15.GetRawRoot__O(); var linked_1884 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1883, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1885 lang.IFn; if linked_1884 == nil { ifn_1885 = lang.IFn_Cast(root_1883) } else { ifn_1885 = nil }; var arg_1886 any; var or__1927000174__auto____14 any = jrt.HashMap_Cast(m__2).Get_O__O(nm__13); if jrt.J2g_Truth(or__1927000174__auto____14) { arg_1886 = or__1927000174__auto____14 } else { arg_1886 = lang.PersistentVector_EMPTY.Ref() }; var arg_1887 any = i__10; if linked_1884 == nil { tmp6 = ifn_1885.Invoke_O_O__O(arg_1886, arg_1887) } else { tmp6 = linked_1884.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1883, arg_1886, arg_1887) }; tmp5.Put_O_O__O(nm__13, tmp6)
//line :254:1
				var tmp7 any; var root_1888 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_1889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1888, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1890 lang.IFn; if linked_1889 == nil { ifn_1890 = lang.IFn_Cast(root_1888) } else { ifn_1890 = nil }; var arg_1891 any = seq_97000299__8; if linked_1889 == nil { tmp7 = ifn_1890.Invoke_O__O(arg_1891) } else { tmp7 = linked_1889.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1888, arg_1891) }; seq_97000299__3, chunk_97000300__4, count_97000301__5, i_97000302__6 = tmp7, nil, 0, 0; continue L1 } else { var tmp8 any; var root_1892 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_1893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1892, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1894 lang.IFn; if linked_1893 == nil { ifn_1894 = lang.IFn_Cast(root_1892) } else { ifn_1894 = nil }; var arg_1895 any = seq_97000299__8; if linked_1893 == nil { tmp8 = ifn_1894.Invoke_O__O(arg_1895) } else { tmp8 = linked_1893.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1892, arg_1895) }; seq_97000299__3, chunk_97000300__4, count_97000301__5, i_97000302__6 = tmp8, nil, 0, 0; continue L1 } } } }
//line :253:1
		break L1 }; return m__2 }








func A_arbace_cpp_run_prune_fn__97000352_A_New() *A_arbace_cpp_run_prune_fn__97000352_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_prune_fn__97000352_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_cpp_run_prune_fn__97000352_A) Ctor() {}
//line :262:1
func (t *A_arbace_cpp_run_prune_fn__97000352_A) Invoke_O_O__O(self, ___1 any) any { return jrt.HashSet_New() }

func A_arbace_cpp_run_prune_mark_BANG___97000354_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_prune_mark_BANG___97000354_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_prune_mark_BANG___97000354_A{}; t.Ctor_O_O(p0, p1); return t }
//line :264:1
func (t *A_arbace_cpp_run_prune_mark_BANG___97000354_A) Ctor_O_O(c__q, c__keep any) { t.F_q = c__q; t.F_keep = c__keep }
//line :264:1
func (t *A_arbace_cpp_run_prune_mark_BANG___97000354_A) Invoke_O_O_O__O(self, u__1, i__2 any) any { if jrt.HashSet_Cast(lang.IFn_Cast(t.F_keep).Invoke_O__O(u__1)).Add_O__Z(i__2) { var tmp1 jrt.ArrayDeque_I = jrt.ArrayDeque_Cast(t.F_q); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1.Add_O__Z(lang.Tuple_Create_O_O__IPersistentVector(u__1, i__2))).Ref() } else { return nil } }
func A_arbace_cpp_run_prune_ref_BANG___97000356_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_run_prune_ref_BANG___97000356_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_prune_ref_BANG___97000356_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :265:1
func (t *A_arbace_cpp_run_prune_ref_BANG___97000356_A) Ctor_O_O_O(c__local, c__mark_BANG_, c__global any) { t.F_local = c__local; t.F_mark_BANG_ = c__mark_BANG_; t.F_global = c__global }
//line :265:1
func (t *A_arbace_cpp_run_prune_ref_BANG___97000356_A) Invoke_O_O_O__O(self, u__1, nm__2 any) any { { var temp__1927000408__auto____3 any; var and__1927000168__auto____3 any = u__1; if jrt.J2g_Truth(and__1927000168__auto____3) { temp__1927000408__auto____3 = jrt.HashMap_Cast(lang.IFn_Cast(t.F_local).Invoke_O__O(u__1)).Get_O__O(nm__2) } else { temp__1927000408__auto____3 = and__1927000168__auto____3 }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var is__4 any = temp__1927000408__auto____3; var seq_97000357__5 any; var root_1911 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1911, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1913 lang.IFn
													if linked_1912 == nil { ifn_1913 = lang.IFn_Cast(root_1911) } else { ifn_1913 = nil }; var arg_1914 any = is__4; if linked_1912 == nil { seq_97000357__5 = ifn_1913.Invoke_O__O(arg_1914) } else { seq_97000357__5 = linked_1912.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1911, arg_1914) }
//line :265:1
	var chunk_97000358__6 any; var count_97000359__7 int64 = 0; var i_97000360__8 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_97000360__8, count_97000359__7) { var i__9 any = lang.Indexed_Cast(chunk_97000358__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000360__8)); lang.IFn_Cast(t.F_mark_BANG_).Invoke_O_O__O(u__1, i__9); seq_97000357__5, chunk_97000358__6, count_97000359__7, i_97000360__8 = seq_97000357__5, chunk_97000358__6, count_97000359__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000360__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1915 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1915, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1917 lang.IFn; if linked_1916 == nil { ifn_1917 = lang.IFn_Cast(root_1915) } else { ifn_1917 = nil }; var arg_1918 any = seq_97000357__5; if linked_1916 == nil { temp__1927000414__auto____9 = ifn_1917.Invoke_O__O(arg_1918) } else { temp__1927000414__auto____9 = linked_1916.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1915, arg_1918) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_97000357__10 any = temp__1927000414__auto____9; var tmp1 any; var root_1919 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1919, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1921 lang.IFn; if linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any = seq_97000357__10; if linked_1920 == nil { tmp1 = ifn_1921.Invoke_O__O(arg_1922) } else { tmp1 = linked_1920.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1919, arg_1922) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____11 any; var root_1923 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1923, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1925 lang.IFn; if linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any = seq_97000357__10; if linked_1924 == nil { c__1927000678__auto____11 = ifn_1925.Invoke_O__O(arg_1926) } else { c__1927000678__auto____11 = linked_1924.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1923, arg_1926) }; var tmp2 any; var root_1951 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1951, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1953 lang.IFn; if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any = seq_97000357__10; if linked_1952 == nil { tmp2 = ifn_1953.Invoke_O__O(arg_1954) } else { tmp2 = linked_1952.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1951, arg_1954) }; seq_97000357__5, chunk_97000358__6, count_97000359__7, i_97000360__8 = tmp2, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var i__11 any; var root_1927 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1927, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1929 lang.IFn; if linked_1928 == nil { ifn_1929 = lang.IFn_Cast(root_1927) } else { ifn_1929 = nil }; var arg_1930 any = seq_97000357__10; if linked_1928 == nil { i__11 = ifn_1929.Invoke_O__O(arg_1930) } else { i__11 = linked_1928.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1927, arg_1930) }; lang.IFn_Cast(t.F_mark_BANG_).Invoke_O_O__O(u__1, i__11); var tmp3 any; var root_1955 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_1956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1955, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1957 lang.IFn; if linked_1956 == nil { ifn_1957 = lang.IFn_Cast(root_1955) } else { ifn_1957 = nil }; var arg_1958 any = seq_97000357__10; if linked_1956 == nil { tmp3 = ifn_1957.Invoke_O__O(arg_1958) } else { tmp3 = linked_1956.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1955, arg_1958) }; seq_97000357__5, chunk_97000358__6, count_97000359__7, i_97000360__8 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :265:1
			var seq_97000361__4 any; var root_1931 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1931, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1933 lang.IFn

			if linked_1932 == nil { ifn_1933 = lang.IFn_Cast(root_1931) } else { ifn_1933 = nil }; var arg_1934 any = jrt.HashMap_Cast(t.F_global).Get_O__O(nm__2); if linked_1932 == nil { seq_97000361__4 = ifn_1933.Invoke_O__O(arg_1934) } else { seq_97000361__4 = linked_1932.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1931, arg_1934) }
//line :265:1
			var chunk_97000362__5 any; var count_97000363__6 int64 = 0; var i_97000364__7 int64 = 0; L2: for {

				if lang.Numbers_Lt_J_J__Z_NoInit(i_97000364__7, count_97000363__6) { var vec__97000365__8 any = lang.Indexed_Cast(chunk_97000362__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000364__7)); var v__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000365__8, lang.RT_IntCast_J__I_NoInit(0), nil); var i__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000365__8, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(t.F_mark_BANG_).Invoke_O_O__O(v__9, i__10); seq_97000361__4, chunk_97000362__5, count_97000363__6, i_97000364__7 = seq_97000361__4, chunk_97000362__5, count_97000363__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000364__7); continue L2 } else { var temp__1927000414__auto____8 any; var root_1935 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_1936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1935, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1937 lang.IFn; if linked_1936 == nil { ifn_1937 = lang.IFn_Cast(root_1935) } else { ifn_1937 = nil }; var arg_1938 any = seq_97000361__4; if linked_1936 == nil { temp__1927000414__auto____8 = ifn_1937.Invoke_O__O(arg_1938) } else { temp__1927000414__auto____8 = linked_1936.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1935, arg_1938) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_97000361__9 any = temp__1927000414__auto____8; var tmp4 any; var root_1939 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_1940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1939, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1941 lang.IFn; if linked_1940 == nil { ifn_1941 = lang.IFn_Cast(root_1939) } else { ifn_1941 = nil }; var arg_1942 any = seq_97000361__9; if linked_1940 == nil { tmp4 = ifn_1941.Invoke_O__O(arg_1942) } else { tmp4 = linked_1940.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1939, arg_1942) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____10 any; var root_1943 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_1944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1943, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1945 lang.IFn; if linked_1944 == nil { ifn_1945 = lang.IFn_Cast(root_1943) } else { ifn_1945 = nil }; var arg_1946 any = seq_97000361__9; if linked_1944 == nil { c__1927000678__auto____10 = ifn_1945.Invoke_O__O(arg_1946) } else { c__1927000678__auto____10 = linked_1944.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1943, arg_1946) }; var tmp5 any; var root_1959 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_1960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1959, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1961 lang.IFn; if linked_1960 == nil { ifn_1961 = lang.IFn_Cast(root_1959) } else { ifn_1961 = nil }; var arg_1962 any = seq_97000361__9; if linked_1960 == nil { tmp5 = ifn_1961.Invoke_O__O(arg_1962) } else { tmp5 = linked_1960.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1959, arg_1962) }; seq_97000361__4, chunk_97000362__5, count_97000363__6, i_97000364__7 = tmp5, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__97000368__10 any; var root_1947 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_1948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1947, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1949 lang.IFn; if linked_1948 == nil { ifn_1949 = lang.IFn_Cast(root_1947) } else { ifn_1949 = nil }; var arg_1950 any = seq_97000361__9; if linked_1948 == nil { vec__97000368__10 = ifn_1949.Invoke_O__O(arg_1950) } else { vec__97000368__10 = linked_1948.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1947, arg_1950) }; var v__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000368__10, lang.RT_IntCast_J__I_NoInit(0), nil); var i__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000368__10, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(t.F_mark_BANG_).Invoke_O_O__O(v__11, i__12); var tmp6 any; var root_1963 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_1964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1963, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1965 lang.IFn; if linked_1964 == nil { ifn_1965 = lang.IFn_Cast(root_1963) } else { ifn_1965 = nil }; var arg_1966 any = seq_97000361__9; if linked_1964 == nil { tmp6 = ifn_1965.Invoke_O__O(arg_1966) } else { tmp6 = linked_1964.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1963, arg_1966) }; seq_97000361__4, chunk_97000362__5, count_97000363__6, i_97000364__7 = tmp6, nil, 0, 0; continue L2 } } else { return nil } } } } }; /*line :265:1*/panic("j2g: unreachable") }







func A_arbace_cpp_run_prune_fn__97000407_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_prune_fn__97000407_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_prune_fn__97000407_A{}; t.Ctor_O_O(p0, p1); return t }
//line :273:1
func (t *A_arbace_cpp_run_prune_fn__97000407_A) Ctor_O_O(c__forms, c__keep any) { t.F_forms = c__forms; t.F_keep = c__keep }
//line :273:1
func (t *A_arbace_cpp_run_prune_fn__97000407_A) Invoke_O_O_O__O(self, u__1, cu__2 any) any { var root_1975 any = A_arbace_cpp_run_A_const_160.GetRawRoot__O(); var linked_1976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1975, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1977 lang.IFn; if linked_1976 == nil { ifn_1977 = lang.IFn_Cast(root_1975) } else { ifn_1977 = nil }; var arg_1978 any = cu__2; var arg_1979 any = A_arbace_cpp_run_A_const_161; var arg_1980 any; var root_1981 any = A_arbace_cpp_run_A_const_62.GetRawRoot__O(); var linked_1982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1981, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1983 lang.IFn; if linked_1982 == nil { ifn_1983 = lang.IFn_Cast(root_1981) } else { ifn_1983 = nil }; var arg_1984 any; var root_1985 any = A_arbace_cpp_run_A_const_162.GetRawRoot__O(); var linked_1986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1985, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_1987 lang.IFn; if linked_1986 == nil { ifn_1987 = lang.IFn_Cast(root_1985) } else { ifn_1987 = nil }; var arg_1988 any; var fnbody__1991 any = A_arbace_cpp_run_prune_fn__97000407_fn__97000408_A_New_O_O(u__1, t.F_keep); var tmp1 *jrt.Class; var fncls__1990 *jrt.Class = A_arbace_cpp_run_prune_fn__97000407_fn__97000408_A_fn_class; if fncls__1990 == nil { var fncls__1990d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_174, false, fnbody__1991); A_arbace_cpp_run_prune_fn__97000407_fn__97000408_A_fn_class = fncls__1990d; tmp1 = fncls__1990d } else { tmp1 = fncls__1990 }; arg_1988 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1991, tmp1, nil); var arg_1989 any = lang.IFn_Cast(t.F_forms).Invoke_O__O(u__1); if linked_1986 == nil { arg_1984 = ifn_1987.Invoke_O_O__O(arg_1988, arg_1989) } else { arg_1984 = linked_1986.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_1985, arg_1988, arg_1989) }; if linked_1982 == nil { arg_1980 = ifn_1983.Invoke_O__O(arg_1984) } else { arg_1980 = linked_1982.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1981, arg_1984) }; if linked_1976 == nil { return ifn_1977.Invoke_O_O_O__O(arg_1978, arg_1979, arg_1980) } else { return linked_1976.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1975, arg_1978, arg_1979, arg_1980) } }
//line :273:1
func A_arbace_cpp_run_prune_fn__97000407_fn__97000408_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_prune_fn__97000407_fn__97000408_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_prune_fn__97000407_fn__97000408_A{}; t.Ctor_O_O(p0, p1); return t }
//line :273:1
func (t *A_arbace_cpp_run_prune_fn__97000407_fn__97000408_A) Ctor_O_O(c__u, c__keep any) { t.F_u = c__u; t.F_keep = c__keep }
//line :273:1
func (t *A_arbace_cpp_run_prune_fn__97000407_fn__97000408_A) Invoke_O_O_O__O(self, i__1, f__2 any) any { if jrt.HashSet_Cast(lang.IFn_Cast(t.F_keep).Invoke_O__O(t.F_u)).Contains_O__Z(i__1) { return f__2 } else { return nil } }


func A_arbace_cpp_run_init_unit_A_New() *A_arbace_cpp_run_init_unit_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_init_unit_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_cpp_run_init_unit_A) Ctor() {}
//line :276:1
func (t *A_arbace_cpp_run_init_unit_A) Invoke_O_O_O__O(self, h__0, names__1 any) any { var f__3 any = jrt.File_CreateTempFile_String_String__File_NoInit(Lit_127, Lit_128); var text__4 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_129, nil, Lit_130); var tmp2 any; var root_2342 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_2343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2342, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2344 lang.IFn; if



	linked_2343 == nil { ifn_2344 = lang.IFn_Cast(root_2342) } else { ifn_2344 = nil }; var arg_2345 any; var iter__1927001039__auto____8 any; var fnbody__2407 any = A_arbace_cpp_run_init_unit_iter__97000412__97000416_A_New(); var tmp3 *jrt.Class; var fncls__2406 *jrt.Class = A_arbace_cpp_run_init_unit_iter__97000412__97000416_A_fn_class; if fncls__2406 == nil { var fncls__2406d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_131, false, nil); A_arbace_cpp_run_init_unit_iter__97000412__97000416_A_fn_class = fncls__2406d; tmp3 = fncls__2406d } else { tmp3 = fncls__2406 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2407, tmp3, nil); arg_2345 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(names__1); if linked_2343 == nil { tmp2 = ifn_2344.Invoke_O__O(arg_2345) } else { tmp2 = linked_2343.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_2342, arg_2345) }; var tmp4 any = tmp2; var tmp5 any; var root_2408 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_2409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2408, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2410 lang.IFn; if
	linked_2409 == nil { ifn_2410 = lang.IFn_Cast(root_2408) } else { ifn_2410 = nil }; var arg_2411 any; var iter__1927001039__auto____8_2 any; var fnbody__2473 any = A_arbace_cpp_run_init_unit_iter__97000422__97000426_A_New(); var tmp6 *jrt.Class; var fncls__2472 *jrt.Class = A_arbace_cpp_run_init_unit_iter__97000422__97000426_A_fn_class; if fncls__2472 == nil { var fncls__2472d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_132, false, nil); A_arbace_cpp_run_init_unit_iter__97000422__97000426_A_fn_class = fncls__2472d; tmp6 = fncls__2472d } else { tmp6 = fncls__2472 }; iter__1927001039__auto____8_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2473, tmp6, nil); arg_2411 = lang.IFn_Cast(iter__1927001039__auto____8_2).Invoke_O__O(names__1); if linked_2409 == nil { tmp5 = ifn_2410.Invoke_O__O(arg_2411) } else { tmp5 = linked_2409.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_2408, arg_2411) }; text__4 = /*line :280:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5, nil)).Ref(); var tmp7 any; tmp12 := /*line :276:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






		lang.IFn_Cast(A_arbace_cpp_run_A_const_35.GetRawRoot__O()).Invoke_O_O__O(f__3, text__4)
//line :276:1
		{ var fc__7 any; var root_2474 any = A_arbace_cpp_run_A_const_47.GetRawRoot__O(); var linked_2475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2474, aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A_fn_class); var ifn_2476 lang.IFn







			if linked_2475 == nil { ifn_2476 = lang.IFn_Cast(root_2474) } else { ifn_2476 = nil }; var arg_2477 any = A_arbace_cpp_run_A_const_48.GetRawRoot__O(); var arg_2478 any = Lit_77; if linked_2475 == nil { fc__7 = ifn_2476.Invoke_O_O__O(arg_2477, arg_2478) } else { fc__7 = linked_2475.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A).Invoke_O_O_O__O(root_2474, arg_2477, arg_2478) }
//line :276:1
			var rd__8 any; var root_2479 any = A_arbace_cpp_run_A_const_49.GetRawRoot__O(); var linked_2480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2479, aot_arbace_repr_c.A_arbace_repr_c_read_c_A_fn_class); var ifn_2481 lang.IFn








			if linked_2480 == nil { ifn_2481 = lang.IFn_Cast(root_2479) } else { ifn_2481 = nil }; var arg_2482 any; var root_2486 any = A_arbace_cpp_run_A_const_50.GetRawRoot__O(); var linked_2487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2486, aot_arbace_repr_c_host.A_arbace_repr_c_host_config_A_fn_class); var ifn_2488 lang.IFn; if linked_2487 == nil { ifn_2488 = lang.IFn_Cast(root_2486) } else { ifn_2488 = nil }; var arg_2489 any = h__0; var arg_2490 any = fc__7; var arg_2491 any = jrt.File_Cast(f__3).GetParent__String().Ref(); if linked_2487 == nil { arg_2482 = ifn_2488.Invoke_O_O_O__O(arg_2489, arg_2490, arg_2491) } else { arg_2482 = linked_2487.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_config_A).Invoke_O_O_O_O__O(root_2486, arg_2489, arg_2490, arg_2491) }; var arg_2483 any = fc__7; var arg_2484 any = jrt.File_Cast(f__3).GetName__String().Ref(); var arg_2485 any = jrt.Boolean_FALSE.Ref(); if linked_2480 == nil { rd__8 = ifn_2481.Invoke_O_O_O_O__O(arg_2482, arg_2483, arg_2484, arg_2485) } else { rd__8 = linked_2480.(*aot_arbace_repr_c.A_arbace_repr_c_read_c_A).Invoke_O_O_O_O_O__O(root_2479, arg_2482, arg_2483, arg_2484, arg_2485) }
//line :276:1
			var u__9 any; var root_2492 any = A_arbace_cpp_run_A_const_142.GetRawRoot__O(); var linked_2493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2492, aot_arbace_c_run.A_arbace_c_run_check_read_A_fn_class); var ifn_2494 lang.IFn









			if linked_2493 == nil { ifn_2494 = lang.IFn_Cast(root_2492) } else { ifn_2494 = nil }; var arg_2495 any = h__0; var arg_2496 any = fc__7; var arg_2497 any = rd__8; if linked_2493 == nil { u__9 = ifn_2494.Invoke_O_O_O__O(arg_2495, arg_2496, arg_2497) } else { u__9 = linked_2493.(*aot_arbace_c_run.A_arbace_c_run_check_read_A).Invoke_O_O_O_O__O(root_2492, arg_2495, arg_2496, arg_2497) }
			var tmp8 any; var or__1927000174__auto____10 any = A_arbace_cpp_run_A_const_51.Invoke_O__O(rd__8); if jrt.J2g_Truth(or__1927000174__auto____10) { tmp8 = or__1927000174__auto____10 } else { var root_2503 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2505 lang.IFn; if linked_2504 == nil { ifn_2505 = lang.IFn_Cast(root_2503) } else { ifn_2505 = nil }; var arg_2506 any = A_arbace_cpp_run_A_const_144.Invoke_O__O(u__9); if linked_2504 == nil { tmp8 = ifn_2505.Invoke_O__O(arg_2506) } else { tmp8 = linked_2504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2503, arg_2506) } }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_2507 any = A_arbace_cpp_run_A_const_145.GetRawRoot__O(); var linked_2508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2507, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2509 lang.IFn
				if linked_2508 == nil { ifn_2509 = lang.IFn_Cast(root_2507) } else { ifn_2509 = nil }; var arg_2510 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_133, nil); var tmp11 any; var or__1927000174__auto____12 any = A_arbace_cpp_run_A_const_51.Invoke_O__O(rd__8); if jrt.J2g_Truth(or__1927000174__auto____12) { tmp11 = or__1927000174__auto____12 } else { tmp11 = A_arbace_cpp_run_A_const_144.Invoke_O__O(u__9) }; arg_2510 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11)).Ref(); var arg_2511 any = A_arbace_cpp_run_A_const_163; if linked_2508 == nil { tmp9 = ifn_2509.Invoke_O_O__O(arg_2510, arg_2511) } else { tmp9 = linked_2508.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2507, arg_2510, arg_2511) }
//line :287:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp9))) }
//line :276:1
			tmp7 = u__9 }; return nil }();













	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__3).Delete__Z()); if /*line :276:1*/ tmp12 != nil { panic(tmp12) }; return tmp7 }



func A_arbace_cpp_run_init_unit_iter__97000412__97000416_A_New() *A_arbace_cpp_run_init_unit_iter__97000412__97000416_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_init_unit_iter__97000412__97000416_A{}; t.Ctor(); return t }
//line :280:1
func (t *A_arbace_cpp_run_init_unit_iter__97000412__97000416_A) Ctor() {}
//line :280:1
func (t *A_arbace_cpp_run_init_unit_iter__97000412__97000416_A) Invoke_O_O__O(self, s__97000413__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2405 any = A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_A_New_O_O(s__97000413__1, self); var tmp2 *jrt.Class; var fncls__2404 *jrt.Class = A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_A_fn_class; if fncls__2404 == nil { var fncls__2404d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, fnbody__2405); A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_A_fn_class = fncls__2404d; tmp2 = fncls__2404d } else { tmp2 = fncls__2404 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2405, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :280:1
func A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_A{}; t.Ctor_O_O(p0, p1); return t }
//line :280:1
func (t *A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_A) Ctor_O_O(c__s__97000413, c__iter__97000412 any) { t.F_s__97000413 = c__s__97000413; t.F_iter__97000412 = c__iter__97000412 }
//line :280:1
func (t *A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_A) Invoke_O__O(self any) any { { var s__97000413__1 any; var t_ any = t.F_s__97000413; t.F_s__97000413 = nil; s__97000413__1 = t_; for { var temp__1927000414__auto____2 any; var root_2346 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2346, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2348 lang.IFn; if linked_2347 == nil { ifn_2348 = lang.IFn_Cast(root_2346) } else { ifn_2348 = nil }; var arg_2349 any = s__97000413__1; if linked_2347 == nil { temp__1927000414__auto____2 = ifn_2348.Invoke_O__O(arg_2349) } else { temp__1927000414__auto____2 = linked_2347.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2346, arg_2349) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__97000413__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2350 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_2351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2350, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2352 lang.IFn; if linked_2351 == nil { ifn_2352 = lang.IFn_Cast(root_2350) } else { ifn_2352 = nil }; var arg_2353 any = s__97000413__3; if linked_2351 == nil { tmp1 = ifn_2352.Invoke_O__O(arg_2353) } else { tmp1 = linked_2351.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2350, arg_2353) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2354 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_2355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2354, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2356 lang.IFn; if linked_2355 == nil { ifn_2356 = lang.IFn_Cast(root_2354) } else { ifn_2356 = nil }; var arg_2357 any = s__97000413__3; if linked_2355 == nil { c__1927001037__auto____4 = ifn_2356.Invoke_O__O(arg_2357) } else { c__1927001037__auto____4 = linked_2355.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2354, arg_2357) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__97000415__6 any; var root_2358 any = A_arbace_cpp_run_A_const_23.GetRawRoot__O(); var linked_2359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2358, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2360 lang.IFn; if linked_2359 == nil { ifn_2360 = lang.IFn_Cast(root_2358) } else { ifn_2360 = nil }; var arg_2361 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2359 == nil { b__97000415__6 = ifn_2360.Invoke_O__O(arg_2361) } else { b__97000415__6 = linked_2359.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2358, arg_2361) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2368 any = A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_fn__97000418_A_New_O_I_O(b__97000415__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2367 *jrt.Class = A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_fn__97000418_A_fn_class; if fncls__2367 == nil { var fncls__2367d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, fnbody__2368); A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_fn__97000418_A_fn_class = fncls__2367d; tmp3 = fncls__2367d } else { tmp3 = fncls__2367 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2368, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2369 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_2370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2369, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2371 lang.IFn; if linked_2370 == nil { ifn_2371 = lang.IFn_Cast(root_2369) } else { ifn_2371 = nil }; var arg_2372 any; var root_2374 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_2375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2374, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2376 lang.IFn; if linked_2375 == nil { ifn_2376 = lang.IFn_Cast(root_2374) } else { ifn_2376 = nil }; var arg_2377 any = b__97000415__6; if linked_2375 == nil { arg_2372 = ifn_2376.Invoke_O__O(arg_2377) } else { arg_2372 = linked_2375.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2374, arg_2377) }; var arg_2373 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__97000412); var tmp5 any; var root_2378 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_2379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2378, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2380 lang.IFn; if linked_2379 == nil { ifn_2380 = lang.IFn_Cast(root_2378) } else { ifn_2380 = nil }; var arg_2381 any = s__97000413__3; if linked_2379 == nil { tmp5 = ifn_2380.Invoke_O__O(arg_2381) } else { tmp5 = linked_2379.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2378, arg_2381) }; arg_2373 = tmp4.Invoke_O__O(tmp5); if linked_2370 == nil { return ifn_2371.Invoke_O_O__O(arg_2372, arg_2373) } else { return linked_2370.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2369, arg_2372, arg_2373) } } else { var root_2382 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_2383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2382, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2384 lang.IFn; if linked_2383 == nil { ifn_2384 = lang.IFn_Cast(root_2382) } else { ifn_2384 = nil }; var arg_2385 any; var root_2387 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_2388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2387, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2389 lang.IFn; if linked_2388 == nil { ifn_2389 = lang.IFn_Cast(root_2387) } else { ifn_2389 = nil }; var arg_2390 any = b__97000415__6; if linked_2388 == nil { arg_2385 = ifn_2389.Invoke_O__O(arg_2390) } else { arg_2385 = linked_2388.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2387, arg_2390) }; var arg_2386 any; if linked_2383 == nil { return ifn_2384.Invoke_O_O__O(arg_2385, arg_2386) } else { return linked_2383.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2382, arg_2385, arg_2386) } } } else { var n__4 any; var root_2391 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_2392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2391, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2393 lang.IFn; if linked_2392 == nil { ifn_2393 = lang.IFn_Cast(root_2391) } else { ifn_2393 = nil }; var arg_2394 any = s__97000413__3; if linked_2392 == nil { n__4 = ifn_2393.Invoke_O__O(arg_2394) } else { n__4 = linked_2392.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2391, arg_2394) }; var root_2395 any = A_arbace_cpp_run_A_const_28.GetRawRoot__O(); var linked_2396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2395, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2397 lang.IFn; if linked_2396 == nil { ifn_2397 = lang.IFn_Cast(root_2395) } else { ifn_2397 = nil }; var arg_2398 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_136, nil, Lit_137), jrt.RefArrayOf(jrt.Object_class, nil, n__4, nil)).Ref(); var arg_2399 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__97000412); var tmp7 any; var root_2400 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_2401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2400, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2402 lang.IFn; if linked_2401 == nil { ifn_2402 = lang.IFn_Cast(root_2400) } else { ifn_2402 = nil }; var arg_2403 any = s__97000413__3; if linked_2401 == nil { tmp7 = ifn_2402.Invoke_O__O(arg_2403) } else { tmp7 = linked_2401.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2400, arg_2403) }; arg_2399 = tmp6.Invoke_O__O(tmp7); if linked_2396 == nil { return ifn_2397.Invoke_O_O__O(arg_2398, arg_2399) } else { return linked_2396.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2395, arg_2398, arg_2399) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :280:1
func A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_fn__97000418_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_fn__97000418_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_fn__97000418_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :280:1
func (t *A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_fn__97000418_A) Ctor_O_I_O(c__b__97000415 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__97000415 = c__b__97000415; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :280:1
func (t *A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_fn__97000418_A) Invoke_O__O(self any) any { { var i__97000414__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__97000414__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__97000414__1)); var root_2362 any = A_arbace_cpp_run_A_const_24.GetRawRoot__O(); var linked_2363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2362, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2364 lang.IFn; if linked_2363 == nil { ifn_2364 = lang.IFn_Cast(root_2362) } else { ifn_2364 = nil }; var arg_2365 any = t.F_b__97000415; var arg_2366 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_136, nil, Lit_137), jrt.RefArrayOf(jrt.Object_class, nil, n__2, nil)).Ref(); if linked_2363 == nil { ifn_2364.Invoke_O_O__O(arg_2365, arg_2366) } else { linked_2363.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2362, arg_2365, arg_2366) }; i__97000414__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__97000414__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_cpp_run_init_unit_iter__97000422__97000426_A_New() *A_arbace_cpp_run_init_unit_iter__97000422__97000426_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_init_unit_iter__97000422__97000426_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_cpp_run_init_unit_iter__97000422__97000426_A) Ctor() {}
//line :281:1
func (t *A_arbace_cpp_run_init_unit_iter__97000422__97000426_A) Invoke_O_O__O(self, s__97000423__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2471 any = A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_A_New_O_O(s__97000423__1, self); var tmp2 *jrt.Class; var fncls__2470 *jrt.Class = A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_A_fn_class; if fncls__2470 == nil { var fncls__2470d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_138, false, fnbody__2471); A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_A_fn_class = fncls__2470d; tmp2 = fncls__2470d } else { tmp2 = fncls__2470 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2471, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :281:1
func A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_A{}; t.Ctor_O_O(p0, p1); return t }
//line :281:1
func (t *A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_A) Ctor_O_O(c__s__97000423, c__iter__97000422 any) { t.F_s__97000423 = c__s__97000423; t.F_iter__97000422 = c__iter__97000422 }
//line :281:1
func (t *A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_A) Invoke_O__O(self any) any { { var s__97000423__1 any; var t_ any = t.F_s__97000423; t.F_s__97000423 = nil; s__97000423__1 = t_; for { var temp__1927000414__auto____2 any; var root_2412 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2412, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2414 lang.IFn; if linked_2413 == nil { ifn_2414 = lang.IFn_Cast(root_2412) } else { ifn_2414 = nil }; var arg_2415 any = s__97000423__1; if linked_2413 == nil { temp__1927000414__auto____2 = ifn_2414.Invoke_O__O(arg_2415) } else { temp__1927000414__auto____2 = linked_2413.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2412, arg_2415) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__97000423__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2416 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_2417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2416, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2418 lang.IFn; if linked_2417 == nil { ifn_2418 = lang.IFn_Cast(root_2416) } else { ifn_2418 = nil }; var arg_2419 any = s__97000423__3; if linked_2417 == nil { tmp1 = ifn_2418.Invoke_O__O(arg_2419) } else { tmp1 = linked_2417.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2416, arg_2419) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2420 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_2421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2420, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2422 lang.IFn; if linked_2421 == nil { ifn_2422 = lang.IFn_Cast(root_2420) } else { ifn_2422 = nil }; var arg_2423 any = s__97000423__3; if linked_2421 == nil { c__1927001037__auto____4 = ifn_2422.Invoke_O__O(arg_2423) } else { c__1927001037__auto____4 = linked_2421.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2420, arg_2423) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__97000425__6 any; var root_2424 any = A_arbace_cpp_run_A_const_23.GetRawRoot__O(); var linked_2425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2424, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2426 lang.IFn; if linked_2425 == nil { ifn_2426 = lang.IFn_Cast(root_2424) } else { ifn_2426 = nil }; var arg_2427 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2425 == nil { b__97000425__6 = ifn_2426.Invoke_O__O(arg_2427) } else { b__97000425__6 = linked_2425.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2424, arg_2427) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2434 any = A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_fn__97000428_A_New_O_I_O(b__97000425__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2433 *jrt.Class = A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_fn__97000428_A_fn_class; if fncls__2433 == nil { var fncls__2433d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_139, false, fnbody__2434); A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_fn__97000428_A_fn_class = fncls__2433d; tmp3 = fncls__2433d } else { tmp3 = fncls__2433 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2434, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2435 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_2436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2435, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2437 lang.IFn; if linked_2436 == nil { ifn_2437 = lang.IFn_Cast(root_2435) } else { ifn_2437 = nil }; var arg_2438 any; var root_2440 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_2441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2440, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2442 lang.IFn; if linked_2441 == nil { ifn_2442 = lang.IFn_Cast(root_2440) } else { ifn_2442 = nil }; var arg_2443 any = b__97000425__6; if linked_2441 == nil { arg_2438 = ifn_2442.Invoke_O__O(arg_2443) } else { arg_2438 = linked_2441.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2440, arg_2443) }; var arg_2439 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__97000422); var tmp5 any; var root_2444 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_2445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2444, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2446 lang.IFn; if linked_2445 == nil { ifn_2446 = lang.IFn_Cast(root_2444) } else { ifn_2446 = nil }; var arg_2447 any = s__97000423__3; if linked_2445 == nil { tmp5 = ifn_2446.Invoke_O__O(arg_2447) } else { tmp5 = linked_2445.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2444, arg_2447) }; arg_2439 = tmp4.Invoke_O__O(tmp5); if linked_2436 == nil { return ifn_2437.Invoke_O_O__O(arg_2438, arg_2439) } else { return linked_2436.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2435, arg_2438, arg_2439) } } else { var root_2448 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_2449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2448, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2450 lang.IFn; if linked_2449 == nil { ifn_2450 = lang.IFn_Cast(root_2448) } else { ifn_2450 = nil }; var arg_2451 any; var root_2453 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_2454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2453, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2455 lang.IFn; if linked_2454 == nil { ifn_2455 = lang.IFn_Cast(root_2453) } else { ifn_2455 = nil }; var arg_2456 any = b__97000425__6; if linked_2454 == nil { arg_2451 = ifn_2455.Invoke_O__O(arg_2456) } else { arg_2451 = linked_2454.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2453, arg_2456) }; var arg_2452 any; if linked_2449 == nil { return ifn_2450.Invoke_O_O__O(arg_2451, arg_2452) } else { return linked_2449.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2448, arg_2451, arg_2452) } } } else { var n__4 any; var root_2457 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_2458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2457, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2459 lang.IFn; if linked_2458 == nil { ifn_2459 = lang.IFn_Cast(root_2457) } else { ifn_2459 = nil }; var arg_2460 any = s__97000423__3; if linked_2458 == nil { n__4 = ifn_2459.Invoke_O__O(arg_2460) } else { n__4 = linked_2458.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2457, arg_2460) }; var root_2461 any = A_arbace_cpp_run_A_const_28.GetRawRoot__O(); var linked_2462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2461, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2463 lang.IFn; if linked_2462 == nil { ifn_2463 = lang.IFn_Cast(root_2461) } else { ifn_2463 = nil }; var arg_2464 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_140, nil, Lit_141), jrt.RefArrayOf(jrt.Object_class, nil, n__4, nil)).Ref(); var arg_2465 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__97000422); var tmp7 any; var root_2466 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_2467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2466, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2468 lang.IFn; if linked_2467 == nil { ifn_2468 = lang.IFn_Cast(root_2466) } else { ifn_2468 = nil }; var arg_2469 any = s__97000423__3; if linked_2467 == nil { tmp7 = ifn_2468.Invoke_O__O(arg_2469) } else { tmp7 = linked_2467.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2466, arg_2469) }; arg_2465 = tmp6.Invoke_O__O(tmp7); if linked_2462 == nil { return ifn_2463.Invoke_O_O__O(arg_2464, arg_2465) } else { return linked_2462.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2461, arg_2464, arg_2465) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :281:1
func A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_fn__97000428_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_fn__97000428_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_fn__97000428_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :281:1
func (t *A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_fn__97000428_A) Ctor_O_I_O(c__b__97000425 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__97000425 = c__b__97000425; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :281:1
func (t *A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_fn__97000428_A) Invoke_O__O(self any) any { { var i__97000424__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__97000424__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__97000424__1)); var root_2428 any = A_arbace_cpp_run_A_const_24.GetRawRoot__O(); var linked_2429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2428, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2430 lang.IFn; if linked_2429 == nil { ifn_2430 = lang.IFn_Cast(root_2428) } else { ifn_2430 = nil }; var arg_2431 any = t.F_b__97000425; var arg_2432 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_140, nil, Lit_141), jrt.RefArrayOf(jrt.Object_class, nil, n__2, nil)).Ref(); if linked_2429 == nil { ifn_2430.Invoke_O_O__O(arg_2431, arg_2432) } else { linked_2429.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2428, arg_2431, arg_2432) }; i__97000424__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__97000424__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_cpp_run_lib_key_A_New() *A_arbace_cpp_run_lib_key_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_lib_key_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_cpp_run_lib_key_A) Ctor() {}
//line :292:1
func (t *A_arbace_cpp_run_lib_key_A) Invoke_O_O__O(self, dir__0 any) any { var md__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_142); var sb__3 any = jrt.StringBuilder_New(); var seq_97000433__4 any; var root_2516 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2516, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2518 lang.IFn; if




	linked_2517 == nil { ifn_2518 = lang.IFn_Cast(root_2516) } else { ifn_2518 = nil }; var arg_2519 any = A_arbace_cpp_run_A_const_164; if linked_2517 == nil { seq_97000433__4 = ifn_2518.Invoke_O__O(arg_2519) } else { seq_97000433__4 = linked_2517.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2516, arg_2519) }; var chunk_97000434__5 any; var count_97000435__6 int64 = 0; var i_97000436__7 int64 = 0; L1:
//line :292:1
	for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_97000436__7, count_97000435__6) { var f__8 any = lang.Indexed_Cast(chunk_97000434__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000436__7)); var x__9 any = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_143, nil), jrt.RefArrayOf(jrt.Object_class, dir__0, nil, f__8)))

			jrt.MessageDigest_Cast(md__2).Update_B1__V(jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_74), jrt.RefArrayOf(jrt.Object_class, f__8, nil))).GetBytes_String__B1(Lit_144))
			if jrt.File_Cast(x__9).Exists__Z() { jrt.MessageDigest_Cast(md__2).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.File_Cast(x__9).ToPath__Path())) }
//line :297:1
			seq_97000433__4, chunk_97000434__5, count_97000435__6, i_97000436__7 = seq_97000433__4, chunk_97000434__5, count_97000435__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000436__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_2520 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2520, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2522 lang.IFn; if linked_2521 == nil { ifn_2522 = lang.IFn_Cast(root_2520) } else { ifn_2522 = nil }; var arg_2523 any = seq_97000433__4; if linked_2521 == nil { temp__1927000414__auto____8 = ifn_2522.Invoke_O__O(arg_2523) } else { temp__1927000414__auto____8 = linked_2521.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2520, arg_2523) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_97000433__9 any = temp__1927000414__auto____8; var tmp1 any; var root_2524 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_2525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2524, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2526 lang.IFn; if linked_2525 == nil { ifn_2526 = lang.IFn_Cast(root_2524) } else { ifn_2526 = nil }; var arg_2527 any = seq_97000433__9; if linked_2525 == nil { tmp1 = ifn_2526.Invoke_O__O(arg_2527) } else { tmp1 = linked_2525.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2524, arg_2527) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____10 any; var root_2528 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_2529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2528, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2530 lang.IFn; if linked_2529 == nil { ifn_2530 = lang.IFn_Cast(root_2528) } else { ifn_2530 = nil }; var arg_2531 any = seq_97000433__9; if linked_2529 == nil { c__1927000678__auto____10 = ifn_2530.Invoke_O__O(arg_2531) } else { c__1927000678__auto____10 = linked_2529.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2528, arg_2531) }; var tmp2 any; var root_2556 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_2557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2556, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2558 lang.IFn; if linked_2557 == nil { ifn_2558 = lang.IFn_Cast(root_2556) } else { ifn_2558 = nil }; var arg_2559 any = seq_97000433__9; if linked_2557 == nil { tmp2 = ifn_2558.Invoke_O__O(arg_2559) } else { tmp2 = linked_2557.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2556, arg_2559) }; seq_97000433__4, chunk_97000434__5, count_97000435__6, i_97000436__7 = tmp2, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__10 any; var root_2532 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_2533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2532, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2534 lang.IFn; if linked_2533 == nil { ifn_2534 = lang.IFn_Cast(root_2532) } else { ifn_2534 = nil }; var arg_2535 any = seq_97000433__9; if linked_2533 == nil { f__10 = ifn_2534.Invoke_O__O(arg_2535) } else { f__10 = linked_2533.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2532, arg_2535) }; var x__11 any = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_143, nil), jrt.RefArrayOf(jrt.Object_class, dir__0, nil, f__10)))

				jrt.MessageDigest_Cast(md__2).Update_B1__V(jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_74), jrt.RefArrayOf(jrt.Object_class, f__10, nil))).GetBytes_String__B1(Lit_144))
				if jrt.File_Cast(x__11).Exists__Z() { jrt.MessageDigest_Cast(md__2).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.File_Cast(x__11).ToPath__Path())) }
//line :297:1
				var tmp3 any; var root_2560 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_2561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2560, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2562 lang.IFn; if linked_2561 == nil { ifn_2562 = lang.IFn_Cast(root_2560) } else { ifn_2562 = nil }; var arg_2563 any = seq_97000433__9; if linked_2561 == nil { tmp3 = ifn_2562.Invoke_O__O(arg_2563) } else { tmp3 = linked_2561.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2560, arg_2563) }; seq_97000433__4, chunk_97000434__5, count_97000435__6, i_97000436__7 = tmp3, nil, 0, 0; continue L1 } } }
//line :292:1
		break L1 }; var seq_97000437__4 any; var root_2536 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2536, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2538 lang.IFn; if








	linked_2537 == nil { ifn_2538 = lang.IFn_Cast(root_2536) } else { ifn_2538 = nil }; var arg_2539 any = jrt.MessageDigest_Cast(md__2).Digest__B1().Ref(); if linked_2537 == nil { seq_97000437__4 = ifn_2538.Invoke_O__O(arg_2539) } else { seq_97000437__4 = linked_2537.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2536, arg_2539) }; var chunk_97000438__5 any; var count_97000439__6 int64 = 0; var i_97000440__7 int64 = 0; L2:
//line :292:1
	for {








		if lang.Numbers_Lt_J_J__Z_NoInit(i_97000440__7, count_97000439__6) { var b__8 any = lang.Indexed_Cast(chunk_97000438__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000440__7)); jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_cpp_run_A_const_86.GetRawRoot__O()).Invoke_O_O__O(Lit_145, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(255, lang.RT_LongCast_O__J_NoInit(b__8))).Ref()))); seq_97000437__4, chunk_97000438__5, count_97000439__6, i_97000440__7 = seq_97000437__4, chunk_97000438__5, count_97000439__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000440__7); continue L2 } else { var temp__1927000414__auto____8_2 any; var root_2540 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2540, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2542 lang.IFn; if linked_2541 == nil { ifn_2542 = lang.IFn_Cast(root_2540) } else { ifn_2542 = nil }; var arg_2543 any = seq_97000437__4; if linked_2541 == nil { temp__1927000414__auto____8_2 = ifn_2542.Invoke_O__O(arg_2543) } else { temp__1927000414__auto____8_2 = linked_2541.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2540, arg_2543) }; if jrt.J2g_Truth(temp__1927000414__auto____8_2) { var seq_97000437__9 any = temp__1927000414__auto____8_2; var tmp4 any; var root_2544 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_2545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2544, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2546 lang.IFn; if linked_2545 == nil { ifn_2546 = lang.IFn_Cast(root_2544) } else { ifn_2546 = nil }; var arg_2547 any = seq_97000437__9; if linked_2545 == nil { tmp4 = ifn_2546.Invoke_O__O(arg_2547) } else { tmp4 = linked_2545.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2544, arg_2547) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____10_2 any; var root_2548 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_2549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2548, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2550 lang.IFn; if linked_2549 == nil { ifn_2550 = lang.IFn_Cast(root_2548) } else { ifn_2550 = nil }; var arg_2551 any = seq_97000437__9; if linked_2549 == nil { c__1927000678__auto____10_2 = ifn_2550.Invoke_O__O(arg_2551) } else { c__1927000678__auto____10_2 = linked_2549.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2548, arg_2551) }; var tmp5 any; var root_2569 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_2570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2569, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2571 lang.IFn; if linked_2570 == nil { ifn_2571 = lang.IFn_Cast(root_2569) } else { ifn_2571 = nil }; var arg_2572 any = seq_97000437__9; if linked_2570 == nil { tmp5 = ifn_2571.Invoke_O__O(arg_2572) } else { tmp5 = linked_2570.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2569, arg_2572) }; seq_97000437__4, chunk_97000438__5, count_97000439__6, i_97000440__7 = tmp5, c__1927000678__auto____10_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var b__10 any; var root_2552 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_2553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2552, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2554 lang.IFn; if linked_2553 == nil { ifn_2554 = lang.IFn_Cast(root_2552) } else { ifn_2554 = nil }; var arg_2555 any = seq_97000437__9; if linked_2553 == nil { b__10 = ifn_2554.Invoke_O__O(arg_2555) } else { b__10 = linked_2553.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2552, arg_2555) }; jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_cpp_run_A_const_86.GetRawRoot__O()).Invoke_O_O__O(Lit_145, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_And_J_J__J_NoInit(255, lang.RT_LongCast_O__J_NoInit(b__10))).Ref()))); var tmp6 any; var root_2578 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_2579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2578, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2580 lang.IFn; if linked_2579 == nil { ifn_2580 = lang.IFn_Cast(root_2578) } else { ifn_2580 = nil }; var arg_2581 any = seq_97000437__9; if linked_2579 == nil { tmp6 = ifn_2580.Invoke_O__O(arg_2581) } else { tmp6 = linked_2579.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2578, arg_2581) }; seq_97000437__4, chunk_97000438__5, count_97000439__6, i_97000440__7 = tmp6, nil, 0, 0; continue L2 } } }
//line :292:1
		break L2 }; var root_2512 any =









	A_arbace_cpp_run_A_const_37.GetRawRoot__O(); var linked_2513 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2512, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2514 lang.IFn; if linked_2513 == nil { ifn_2514 = lang.IFn_Cast(root_2512) } else { ifn_2514 = nil }; var arg_2515 any = sb__3; if linked_2513 == nil { return ifn_2514.Invoke_O__O(arg_2515) } else { return linked_2513.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2512, arg_2515) } }

func A_arbace_cpp_run_prebuilt_lib_A_New() *A_arbace_cpp_run_prebuilt_lib_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_prebuilt_lib_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_cpp_run_prebuilt_lib_A) Ctor() {}
//line :304:1
func (t *A_arbace_cpp_run_prebuilt_lib_A) Invoke_O_O_O__O(self, h__0, lib__1 any) any { var dir__3 any = A_arbace_cpp_run_A_const_112.Invoke_O__O(lib__1); var root_2582 any = A_arbace_cpp_run_A_const_165.GetRawRoot__O(); var linked_2583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2582, aot_arbace_c_runtime.A_arbace_c_runtime_prebuilt_A_fn_class); var ifn_2584 lang.IFn; if



	linked_2583 == nil { ifn_2584 = lang.IFn_Cast(root_2582) } else { ifn_2584 = nil }; var arg_2585 any = lib__1; var arg_2586 any = jrt.System_GetProperty_String__String(Lit_153).Ref(); var arg_2587 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_166, nil); var tmp2 any; var root_2590 any = A_arbace_cpp_run_A_const_71.GetRawRoot__O(); var linked_2591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2590, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2592 lang.IFn; if
	linked_2591 == nil { ifn_2592 = lang.IFn_Cast(root_2590) } else { ifn_2592 = nil }; var arg_2593 any; var root_2596 any = A_arbace_cpp_run_A_const_166.GetRawRoot__O(); var linked_2597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2596, A_arbace_cpp_run_lib_key_A_fn_class); var ifn_2598 lang.IFn; if linked_2597 == nil { ifn_2598 = lang.IFn_Cast(root_2596) } else { ifn_2598 = nil }; var arg_2599 any = jrt.File_New_String(jrt.String_Cast(dir__3)).GetCanonicalPath__String().Ref(); if linked_2597 == nil { arg_2593 = ifn_2598.Invoke_O__O(arg_2599) } else { arg_2593 = linked_2597.(*A_arbace_cpp_run_lib_key_A).Invoke_O_O__O(root_2596, arg_2599) }; var arg_2594 any = A_arbace_cpp_run_A_const_81; var arg_2595 any = A_arbace_cpp_run_A_const_167; if linked_2591 == nil { tmp2 = ifn_2592.Invoke_O_O_O__O(arg_2593, arg_2594, arg_2595) } else { tmp2 = linked_2591.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_2590, arg_2593, arg_2594, arg_2595) }; arg_2587 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); var arg_2588 any; var root_2600 any = /*line :308:1*/A_arbace_cpp_run_A_const_166.GetRawRoot__O(); var linked_2601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2600, A_arbace_cpp_run_lib_key_A_fn_class); var ifn_2602 lang.IFn; if
	linked_2601 == nil { ifn_2602 = lang.IFn_Cast(root_2600) } else { ifn_2602 = nil }; var arg_2603 any = dir__3; if linked_2601 == nil { arg_2588 = ifn_2602.Invoke_O__O(arg_2603) } else { arg_2588 = linked_2601.(*A_arbace_cpp_run_lib_key_A).Invoke_O_O__O(root_2600, arg_2603) }; var arg_2589 any; var fnbody__2611 any = /*line :308:1*/A_arbace_cpp_run_prebuilt_lib_fn__97000443_A_New_O_O(lib__1, h__0); var tmp3 *jrt.Class; var fncls__2610 *jrt.Class = A_arbace_cpp_run_prebuilt_lib_fn__97000443_A_fn_class; if fncls__2610 == nil { var fncls__2610d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_167, false, fnbody__2611); A_arbace_cpp_run_prebuilt_lib_fn__97000443_A_fn_class = fncls__2610d; tmp3 = fncls__2610d } else { tmp3 = fncls__2610 }; arg_2589 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2611, tmp3, nil); if linked_2583 == nil { return ifn_2584.Invoke_O_O_O_O_O__O(arg_2585, arg_2586, arg_2587, arg_2588, arg_2589) } else { return linked_2583.(*aot_arbace_c_runtime.A_arbace_c_runtime_prebuilt_A).Invoke_O_O_O_O_O_O__O(root_2582, arg_2585, arg_2586, arg_2587, arg_2588, arg_2589) } }
//line :308:1
func A_arbace_cpp_run_prebuilt_lib_fn__97000443_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_prebuilt_lib_fn__97000443_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_prebuilt_lib_fn__97000443_A{}; t.Ctor_O_O(p0, p1); return t }
//line :308:1
func (t *A_arbace_cpp_run_prebuilt_lib_fn__97000443_A) Ctor_O_O(c__lib, c__h any) { t.F_lib = c__lib; t.F_h = c__h }
//line :308:1
func (t *A_arbace_cpp_run_prebuilt_lib_fn__97000443_A) Invoke_O_O__O(self, p1__97000442_SHARP___1 any) any {

	var root_2604 any = A_arbace_cpp_run_A_const_140.GetRawRoot__O(); var linked_2605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2604, A_arbace_cpp_run_check_lib_unit_A_fn_class); var ifn_2606 lang.IFn; if linked_2605 == nil { ifn_2606 = lang.IFn_Cast(root_2604) } else { ifn_2606 = nil }; var arg_2607 any = t.F_h; var arg_2608 any = t.F_lib; var arg_2609 any = p1__97000442_SHARP___1; if linked_2605 == nil { return ifn_2606.Invoke_O_O_O__O(arg_2607, arg_2608, arg_2609) } else { return linked_2605.(*A_arbace_cpp_run_check_lib_unit_A).Invoke_O_O_O_O__O(root_2604, arg_2607, arg_2608, arg_2609)
	} }
func A_arbace_cpp_run_build_linked_prebuilt_A_New() *A_arbace_cpp_run_build_linked_prebuilt_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_prebuilt_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_A) Ctor() {}
//line :312:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_A) Invoke_O_O_O_O__O(self, h__0, libs__1, units__2 any) any { var pdefs__4 any; var root_2612 any = A_arbace_cpp_run_A_const_105.GetRawRoot__O(); var linked_2613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2612, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2614 lang.IFn; if




	linked_2613 == nil { ifn_2614 = lang.IFn_Cast(root_2612) } else { ifn_2614 = nil }; var arg_2615 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_100.GetRawRoot__O()); var tmp2 *lang.Compiler_AOTFn; var fnbody__2630 any = A_arbace_cpp_run_build_linked_prebuilt_fn__97000450_A_New(); var tmp3 *jrt.Class; var fncls__2629 *jrt.Class = A_arbace_cpp_run_build_linked_prebuilt_fn__97000450_A_fn_class; if fncls__2629 == nil { var fncls__2629d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, nil); A_arbace_cpp_run_build_linked_prebuilt_fn__97000450_A_fn_class = fncls__2629d; tmp3 = fncls__2629d } else { tmp3 = fncls__2629 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2630, tmp3, nil); arg_2615 = tmp1.Invoke_O_O__O(tmp2.Ref(), units__2); if linked_2613 == nil { pdefs__4 = ifn_2614.Invoke_O__O(arg_2615) } else { pdefs__4 = linked_2613.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2612, arg_2615) }; var prefs__5 any; var root_2631 any = /*line :312:1*/A_arbace_cpp_run_A_const_105.GetRawRoot__O(); var linked_2632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2631, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2633 lang.IFn; if





	linked_2632 == nil { ifn_2633 = lang.IFn_Cast(root_2631) } else { ifn_2633 = nil }; var arg_2634 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_100.GetRawRoot__O()); var tmp5 *lang.Compiler_AOTFn; var fnbody__2659 any = A_arbace_cpp_run_build_linked_prebuilt_fn__97000452_A_New(); var tmp6 *jrt.Class; var fncls__2658 *jrt.Class = A_arbace_cpp_run_build_linked_prebuilt_fn__97000452_A_fn_class; if fncls__2658 == nil { var fncls__2658d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, nil); A_arbace_cpp_run_build_linked_prebuilt_fn__97000452_A_fn_class = fncls__2658d; tmp6 = fncls__2658d } else { tmp6 = fncls__2658 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2659, tmp6, nil); arg_2634 = tmp4.Invoke_O_O__O(tmp5.Ref(), units__2); if linked_2632 == nil { prefs__5 = ifn_2633.Invoke_O__O(arg_2634) } else { prefs__5 = linked_2632.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2631, arg_2634) }; var prefs__6 any; var root_2660 any = /*line :312:1*/A_arbace_cpp_run_A_const_17.GetRawRoot__O(); var linked_2661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2660, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2662 lang.IFn; if






	linked_2661 == nil { ifn_2662 = lang.IFn_Cast(root_2660) } else { ifn_2662 = nil }; var arg_2663 any = prefs__5; var arg_2664 any; var root_2665 any = A_arbace_cpp_run_A_const_168.GetRawRoot__O(); var linked_2666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2665, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2667 lang.IFn; if linked_2666 == nil { ifn_2667 = lang.IFn_Cast(root_2665) } else { ifn_2667 = nil }; var arg_2668 any; var fnbody__2681 any = A_arbace_cpp_run_build_linked_prebuilt_fn__97000454_A_New(); var tmp7 *jrt.Class; var fncls__2680 *jrt.Class = A_arbace_cpp_run_build_linked_prebuilt_fn__97000454_A_fn_class; if fncls__2680 == nil { var fncls__2680d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, nil); A_arbace_cpp_run_build_linked_prebuilt_fn__97000454_A_fn_class = fncls__2680d; tmp7 = fncls__2680d } else { tmp7 = fncls__2680 }; arg_2668 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2681, tmp7, nil); var arg_2669 any = prefs__5; if linked_2666 == nil { arg_2664 = ifn_2667.Invoke_O_O__O(arg_2668, arg_2669) } else { arg_2664 = linked_2666.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2665, arg_2668, arg_2669) }; if linked_2661 == nil { prefs__6 = ifn_2662.Invoke_O_O__O(arg_2663, arg_2664) } else { prefs__6 = linked_2661.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2660, arg_2663, arg_2664) }; var linked__7 any; var root_2682 any = /*line :312:1*/A_arbace_cpp_run_A_const_169.GetRawRoot__O(); var linked_2683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2682, A_arbace_cpp_run_closure_A_fn_class); var ifn_2684 lang.IFn; if







	linked_2683 == nil { ifn_2684 = lang.IFn_Cast(root_2682) } else { ifn_2684 = nil }; var arg_2685 any = libs__1; var arg_2686 any = pdefs__4; var arg_2687 any = prefs__6; if linked_2683 == nil { linked__7 = ifn_2684.Invoke_O_O_O__O(arg_2685, arg_2686, arg_2687) } else { linked__7 = linked_2683.(*A_arbace_cpp_run_closure_A).Invoke_O_O_O_O__O(root_2682, arg_2685, arg_2686, arg_2687) }; var trace__8 any = /*line :312:1*/jrt.System_Getenv_String__String(Lit_33).Ref(); var ___9 any; _ = ___9; if









	jrt.J2g_Truth(trace__8) { var root_2807 any = A_arbace_cpp_run_A_const_93.GetRawRoot__O(); var linked_2808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2807, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2809 lang.IFn; if linked_2808 == nil { ifn_2809 = lang.IFn_Cast(root_2807) } else { ifn_2809 = nil }; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_94.GetRawRoot__O()); var tmp9 any = A_arbace_cpp_run_A_const_95; var arg_2810 any = tmp8.Invoke_O_O__O(tmp9, A_arbace_cpp_run_A_const_96.Get__O()); if linked_2808 == nil { ifn_2809.Invoke_O__O(arg_2810) } else { linked_2808.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2807, arg_2810) }; var tmp10 *lang.Compiler_AOTFn; var fnbody__2703 any = A_arbace_cpp_run_build_linked_prebuilt_fn__97000456_A_New_O(linked__7); var tmp11 *jrt.Class; var fncls__2702 *jrt.Class = A_arbace_cpp_run_build_linked_prebuilt_fn__97000456_A_fn_class; if fncls__2702 == nil { var fncls__2702d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__2703); A_arbace_cpp_run_build_linked_prebuilt_fn__97000456_A_fn_class = fncls__2702d; tmp11 = fncls__2702d } else { tmp11 = fncls__2702 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2703, tmp11, nil); ___9 = Up_Compiler_AOTFn_IFn(tmp10).Invoke__O() } else { ___9 = nil }; var t0__10 int64 = /*line :312:1*/jrt.System_NanoTime__J(); var lfs__11 any; var root_2704 any = A_arbace_cpp_run_A_const_39.GetRawRoot__O(); var linked_2705 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2704, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2706 lang.IFn; if











	linked_2705 == nil { ifn_2706 = lang.IFn_Cast(root_2704) } else { ifn_2706 = nil }; var arg_2707 any; var fnbody__2715 any = A_arbace_cpp_run_build_linked_prebuilt_fn__97000459_A_New(); var tmp12 *jrt.Class; var fncls__2714 *jrt.Class = A_arbace_cpp_run_build_linked_prebuilt_fn__97000459_A_fn_class; if fncls__2714 == nil { var fncls__2714d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_cpp_run_build_linked_prebuilt_fn__97000459_A_fn_class = fncls__2714d; tmp12 = fncls__2714d } else { tmp12 = fncls__2714 }; arg_2707 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2715, tmp12, nil); var arg_2708 any = linked__7; if linked_2705 == nil { lfs__11 = ifn_2706.Invoke_O_O__O(arg_2707, arg_2708) } else { lfs__11 = linked_2705.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2704, arg_2707, arg_2708) }; var t1__12 int64 = /*line :312:1*/jrt.System_NanoTime__J(); var cs__13 any; var root_2716 any = A_arbace_cpp_run_A_const_30.GetRawRoot__O(); var linked_2717 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2716, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2718 lang.IFn; if













	linked_2717 == nil { ifn_2718 = lang.IFn_Cast(root_2716) } else { ifn_2718 = nil }; var arg_2719 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_100.GetRawRoot__O()); var tmp14 *lang.Compiler_AOTFn; var fnbody__2727 any = A_arbace_cpp_run_build_linked_prebuilt_fn__97000464_A_New(); var tmp15 *jrt.Class; var fncls__2726 *jrt.Class = A_arbace_cpp_run_build_linked_prebuilt_fn__97000464_A_fn_class; if fncls__2726 == nil { var fncls__2726d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, nil); A_arbace_cpp_run_build_linked_prebuilt_fn__97000464_A_fn_class = fncls__2726d; tmp15 = fncls__2726d } else { tmp15 = fncls__2726 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2727, tmp15, nil); arg_2719 = tmp13.Invoke_O_O__O(tmp14.Ref(), units__2); var arg_2720 any = lang.IFn_Cast(A_arbace_cpp_run_A_const_100.GetRawRoot__O()).Invoke_O_O__O(A_arbace_cpp_run_A_const_139, lfs__11); if linked_2717 == nil { cs__13 = ifn_2718.Invoke_O_O__O(arg_2719, arg_2720) } else { cs__13 = linked_2717.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2716, arg_2719, arg_2720) }; var init__14 any; var tmp16 any; var root_2733 any = /*line :312:1*/A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_2734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2733, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2735 lang.IFn; if














	linked_2734 == nil { ifn_2735 = lang.IFn_Cast(root_2733) } else { ifn_2735 = nil }; var arg_2736 any = cs__13; if linked_2734 == nil { tmp16 = ifn_2735.Invoke_O__O(arg_2736) } else { tmp16 = linked_2734.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2733, arg_2736) }; if jrt.J2g_Truth(tmp16) { var root_2737 any = A_arbace_cpp_run_A_const_171.GetRawRoot__O(); var linked_2738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2737, A_arbace_cpp_run_init_unit_A_fn_class); var ifn_2739 lang.IFn; if linked_2738 == nil { ifn_2739 = lang.IFn_Cast(root_2737) } else { ifn_2739 = nil }; var arg_2740 any = h__0; var arg_2741 any; var root_2742 any = A_arbace_cpp_run_A_const_63.GetRawRoot__O(); var linked_2743 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2742, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2744 lang.IFn; if linked_2743 == nil { ifn_2744 = lang.IFn_Cast(root_2742) } else { ifn_2744 = nil }; var arg_2745 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var arg_2746 any; var root_2747 any = A_arbace_cpp_run_A_const_109.GetRawRoot__O(); var linked_2748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2747, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2749 lang.IFn; if linked_2748 == nil { ifn_2749 = lang.IFn_Cast(root_2747) } else { ifn_2749 = nil }; var arg_2750 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var arg_2751 any = cs__13; if linked_2748 == nil { arg_2746 = ifn_2749.Invoke_O_O__O(arg_2750, arg_2751) } else { arg_2746 = linked_2748.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2747, arg_2750, arg_2751) }; if linked_2743 == nil { arg_2741 = ifn_2744.Invoke_O_O__O(arg_2745, arg_2746) } else { arg_2741 = linked_2743.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2742, arg_2745, arg_2746) }; if linked_2738 == nil { init__14 = ifn_2739.Invoke_O_O__O(arg_2740, arg_2741) } else { init__14 = linked_2738.(*A_arbace_cpp_run_init_unit_A).Invoke_O_O_O__O(root_2737, arg_2740, arg_2741) } } else { init__14 = nil }; var pre__15 any; var G__97000466__15_ any; var root_2752 any = /*line :312:1*/A_arbace_cpp_run_A_const_39.GetRawRoot__O(); var linked_2753 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2752, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2754 lang.IFn; if















	linked_2753 == nil { ifn_2754 = lang.IFn_Cast(root_2752) } else { ifn_2754 = nil }; var arg_2755 any = A_arbace_cpp_run_A_const_172.GetRawRoot__O(); var arg_2756 any = units__2; if linked_2753 == nil { G__97000466__15_ = ifn_2754.Invoke_O_O__O(arg_2755, arg_2756) } else { G__97000466__15_ = linked_2753.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2752, arg_2755, arg_2756) }; if jrt.J2g_Truth(init__14) { var root_2757 any = A_arbace_cpp_run_A_const_15.GetRawRoot__O(); var linked_2758 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2757, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2759 lang.IFn; if linked_2758 == nil { ifn_2759 = lang.IFn_Cast(root_2757) } else { ifn_2759 = nil }; var arg_2760 any = G__97000466__15_; var arg_2761 any; var root_2762 any = A_arbace_cpp_run_A_const_172.GetRawRoot__O(); var linked_2763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2762, aot_arbace_c_build.A_arbace_c_build_unit_fragment_A_fn_class); var ifn_2764 lang.IFn; if linked_2763 == nil { ifn_2764 = lang.IFn_Cast(root_2762) } else { ifn_2764 = nil }; var arg_2765 any = init__14; if linked_2763 == nil { arg_2761 = ifn_2764.Invoke_O__O(arg_2765) } else { arg_2761 = linked_2763.(*aot_arbace_c_build.A_arbace_c_build_unit_fragment_A).Invoke_O_O__O(root_2762, arg_2765) }; if linked_2758 == nil { pre__15 = ifn_2759.Invoke_O_O__O(arg_2760, arg_2761) } else { pre__15 = linked_2758.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2757, arg_2760, arg_2761) } } else { pre__15 = G__97000466__15_ }; var n__16 int32 = /*line :312:1*/lang.RT_Count_O__I_NoInit(pre__15); var prune__17 any; var root_2766 any = A_arbace_cpp_run_A_const_105.GetRawRoot__O(); var linked_2767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2766, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2768 lang.IFn; if

















	linked_2767 == nil { ifn_2768 = lang.IFn_Cast(root_2766) } else { ifn_2768 = nil }; var arg_2769 any; var root_2770 any = A_arbace_cpp_run_A_const_162.GetRawRoot__O(); var linked_2771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2770, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_2772 lang.IFn; if linked_2771 == nil { ifn_2772 = lang.IFn_Cast(root_2770) } else { ifn_2772 = nil }; var arg_2773 any; var fnbody__2781 any = A_arbace_cpp_run_build_linked_prebuilt_fn__97000468_A_New_I(n__16); var tmp17 *jrt.Class; var fncls__2780 *jrt.Class = A_arbace_cpp_run_build_linked_prebuilt_fn__97000468_A_fn_class; if fncls__2780 == nil { var fncls__2780d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__2781); A_arbace_cpp_run_build_linked_prebuilt_fn__97000468_A_fn_class = fncls__2780d; tmp17 = fncls__2780d } else { tmp17 = fncls__2780 }; arg_2773 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2781, tmp17, nil); var arg_2774 any = linked__7; if linked_2771 == nil { arg_2769 = ifn_2772.Invoke_O_O__O(arg_2773, arg_2774) } else { arg_2769 = linked_2771.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_2770, arg_2773, arg_2774) }; if linked_2767 == nil { prune__17 = ifn_2768.Invoke_O__O(arg_2769) } else { prune__17 = linked_2767.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2766, arg_2769) }; var t2__18 int64 = /*line :312:1*/jrt.System_NanoTime__J(); var text__19 any; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_174.GetRawRoot__O()); var tmp19 any; var root_2792 any = A_arbace_cpp_run_A_const_17.GetRawRoot__O(); var linked_2793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2792, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2794 lang.IFn; if



















	linked_2793 == nil { ifn_2794 = lang.IFn_Cast(root_2792) } else { ifn_2794 = nil }; var arg_2795 any = pre__15; var arg_2796 any = lfs__11; if linked_2793 == nil { tmp19 = ifn_2794.Invoke_O_O__O(arg_2795, arg_2796) } else { tmp19 = linked_2793.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2792, arg_2795, arg_2796) }; var tmp20 any = tmp19; var tmp21 any = A_arbace_cpp_run_A_const_175; var tmp22 any = jrt.Boolean_TRUE.Ref(); var tmp23 any = A_arbace_cpp_run_A_const_176; var tmp24 any; if
	jrt.System_Getenv_String__String(Lit_40) != nil { tmp24 = nil } else { tmp24 = prune__17 }; var tmp25 any = tmp24; var tmp26 any = A_arbace_cpp_run_A_const_177; var tmp27 any; var root_2797 any = /*line :332:1*/A_arbace_cpp_run_A_const_30.GetRawRoot__O(); var linked_2798 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2797, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2799 lang.IFn; if

	linked_2798 == nil { ifn_2799 = lang.IFn_Cast(root_2797) } else { ifn_2799 = nil }; var arg_2800 any; var root_2802 any = A_arbace_cpp_run_A_const_63.GetRawRoot__O(); var linked_2803 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2802, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2804 lang.IFn; if linked_2803 == nil { ifn_2804 = lang.IFn_Cast(root_2802) } else { ifn_2804 = nil }; var arg_2805 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var arg_2806 any = cs__13; if linked_2803 == nil { arg_2800 = ifn_2804.Invoke_O_O__O(arg_2805, arg_2806) } else { arg_2800 = linked_2803.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2802, arg_2805, arg_2806) }; var arg_2801 any = A_arbace_cpp_run_A_const_178; if linked_2798 == nil { tmp27 = ifn_2799.Invoke_O_O__O(arg_2800, arg_2801) } else { tmp27 = linked_2798.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2797, arg_2800, arg_2801) }; text__19 = /*line :332:1*/tmp18.Invoke_O_O_O_O_O_O_O__O(tmp20, tmp21, tmp22, tmp23, tmp25, tmp26, tmp27); if


	jrt.J2g_Truth(trace__8) {
		var root_2833 any = A_arbace_cpp_run_A_const_93.GetRawRoot__O(); var linked_2834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2833, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2835 lang.IFn; if linked_2834 == nil { ifn_2835 = lang.IFn_Cast(root_2833) } else { ifn_2835 = nil }; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_94.GetRawRoot__O()); var tmp29 any = A_arbace_cpp_run_A_const_95; var arg_2836 any = tmp28.Invoke_O_O__O(tmp29, A_arbace_cpp_run_A_const_96.Get__O()); if linked_2834 == nil { ifn_2835.Invoke_O__O(arg_2836) } else { linked_2834.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2833, arg_2836) }; var tmp30 *lang.Compiler_AOTFn; var fnbody__2832 any = A_arbace_cpp_run_build_linked_prebuilt_fn__97000473_A_New_J_J_J_O(t2__18, t1__12, t0__10, text__19); var tmp31 *jrt.Class; var fncls__2831 *jrt.Class = A_arbace_cpp_run_build_linked_prebuilt_fn__97000473_A_fn_class; if fncls__2831 == nil { var fncls__2831d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__2832); A_arbace_cpp_run_build_linked_prebuilt_fn__97000473_A_fn_class = fncls__2831d; tmp31 = fncls__2831d } else { tmp31 = fncls__2831 }; tmp30 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2832, tmp31, nil); Up_Compiler_AOTFn_IFn(tmp30).Invoke__O() }; return text__19 }
//line :317:1
func A_arbace_cpp_run_build_linked_prebuilt_fn__97000450_A_New() *A_arbace_cpp_run_build_linked_prebuilt_fn__97000450_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_prebuilt_fn__97000450_A{}; t.Ctor(); return t }
//line :317:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000450_A) Ctor() {}
//line :317:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000450_A) Invoke_O_O__O(self, p1__97000446_SHARP___1 any) any { var root_2621 any = A_arbace_cpp_run_A_const_64.GetRawRoot__O(); var linked_2622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2621, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2623 lang.IFn; if linked_2622 == nil { ifn_2623 = lang.IFn_Cast(root_2621) } else { ifn_2623 = nil }; var arg_2624 any; var root_2625 any = A_arbace_cpp_run_A_const_103.GetRawRoot__O(); var linked_2626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2625, aot_arbace_c_musl.A_arbace_c_musl_unit_defs_A_fn_class); var ifn_2627 lang.IFn; if linked_2626 == nil { ifn_2627 = lang.IFn_Cast(root_2625) } else { ifn_2627 = nil }; var tmp1 *lang.Keyword = A_arbace_cpp_run_A_const_70; var arg_2628 any = tmp1.Invoke_O__O(A_arbace_cpp_run_A_const_156.Invoke_O__O(p1__97000446_SHARP___1)); if linked_2626 == nil { arg_2624 = ifn_2627.Invoke_O__O(arg_2628) } else { arg_2624 = linked_2626.(*aot_arbace_c_musl.A_arbace_c_musl_unit_defs_A).Invoke_O_O__O(root_2625, arg_2628) }; if linked_2622 == nil { return ifn_2623.Invoke_O__O(arg_2624) } else { return linked_2622.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2621, arg_2624) } }
func A_arbace_cpp_run_build_linked_prebuilt_fn__97000452_A_New() *A_arbace_cpp_run_build_linked_prebuilt_fn__97000452_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_prebuilt_fn__97000452_A{}; t.Ctor(); return t }
//line :318:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000452_A) Ctor() {}
//line :318:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000452_A) Invoke_O_O__O(self, p1__97000447_SHARP___1 any) any { var root_2640 any = A_arbace_cpp_run_A_const_106.GetRawRoot__O(); var linked_2641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2640, aot_arbace_c_musl.A_arbace_c_musl_refs_A_fn_class); var ifn_2642 lang.IFn; if linked_2641 == nil { ifn_2642 = lang.IFn_Cast(root_2640) } else { ifn_2642 = nil }; var arg_2643 any; var root_2644 any = A_arbace_cpp_run_A_const_30.GetRawRoot__O(); var linked_2645 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2644, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2646 lang.IFn; if linked_2645 == nil { ifn_2646 = lang.IFn_Cast(root_2644) } else { ifn_2646 = nil }; var tmp1 *lang.Keyword = A_arbace_cpp_run_A_const_70; var arg_2647 any = tmp1.Invoke_O__O(A_arbace_cpp_run_A_const_156.Invoke_O__O(p1__97000447_SHARP___1)); var arg_2648 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_100.GetRawRoot__O()); var tmp3 any = A_arbace_cpp_run_A_const_70; var tmp4 any; var root_2654 any = A_arbace_cpp_run_A_const_101.GetRawRoot__O(); var linked_2655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2654, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_2656 lang.IFn; if linked_2655 == nil { ifn_2656 = lang.IFn_Cast(root_2654) } else { ifn_2656 = nil }; var tmp5 *lang.Keyword = A_arbace_cpp_run_A_const_65; var arg_2657 any = tmp5.Invoke_O__O(A_arbace_cpp_run_A_const_156.Invoke_O__O(p1__97000447_SHARP___1)); if linked_2655 == nil { tmp4 = ifn_2656.Invoke_O__O(arg_2657) } else { tmp4 = linked_2655.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_2654, arg_2657) }; arg_2648 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_2645 == nil { arg_2643 = ifn_2646.Invoke_O_O__O(arg_2647, arg_2648) } else { arg_2643 = linked_2645.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2644, arg_2647, arg_2648) }; if linked_2641 == nil { return ifn_2642.Invoke_O__O(arg_2643) } else { return linked_2641.(*aot_arbace_c_musl.A_arbace_c_musl_refs_A).Invoke_O_O__O(root_2640, arg_2643) } }
func A_arbace_cpp_run_build_linked_prebuilt_fn__97000454_A_New() *A_arbace_cpp_run_build_linked_prebuilt_fn__97000454_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_prebuilt_fn__97000454_A{}; t.Ctor(); return t }
//line :319:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000454_A) Ctor() {}
//line :319:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000454_A) Invoke_O_O__O(self, p1__97000448_SHARP___1 any) any { var tmp1 any; var root_2670 any = A_arbace_cpp_run_A_const_66.GetRawRoot__O(); var linked_2671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2670, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2672 lang.IFn; if linked_2671 == nil { ifn_2672 = lang.IFn_Cast(root_2670) } else { ifn_2672 = nil }; var arg_2673 any = p1__97000448_SHARP___1; var arg_2674 any = Lit_45; if linked_2671 == nil { tmp1 = ifn_2672.Invoke_O_O__O(arg_2673, arg_2674) } else { tmp1 = linked_2671.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2670, arg_2673, arg_2674) }; if jrt.J2g_Truth(tmp1) { var root_2675 any = A_arbace_cpp_run_A_const_71.GetRawRoot__O(); var linked_2676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2675, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2677 lang.IFn; if linked_2676 == nil { ifn_2677 = lang.IFn_Cast(root_2675) } else { ifn_2677 = nil }; var arg_2678 any = p1__97000448_SHARP___1; var arg_2679 any = A_arbace_cpp_run_A_const_149; if linked_2676 == nil { return ifn_2677.Invoke_O_O__O(arg_2678, arg_2679) } else { return linked_2676.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2675, arg_2678, arg_2679) } } else { return nil } }


func A_arbace_cpp_run_build_linked_prebuilt_fn__97000456_A_New_O(p0 any) *A_arbace_cpp_run_build_linked_prebuilt_fn__97000456_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_prebuilt_fn__97000456_A{}; t.Ctor_O(p0); return t }
//line :322:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000456_A) Ctor_O(c__linked any) { t.F_linked = c__linked }
//line :322:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000456_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_91.GetRawRoot__O()); var tmp3 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(t.F_linked)).Ref(); var tmp4 any; var root_2694 any = A_arbace_cpp_run_A_const_39.GetRawRoot__O(); var linked_2695 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2694, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2696 lang.IFn; if linked_2695 == nil { ifn_2696 = lang.IFn_Cast(root_2694) } else { ifn_2696 = nil }; var arg_2697 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var arg_2698 any; var t_ any = t.F_linked; t.F_linked = nil; arg_2698 = t_; if linked_2695 == nil { tmp4 = ifn_2696.Invoke_O_O__O(arg_2697, arg_2698) } else { tmp4 = linked_2695.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2694, arg_2697, arg_2698) }; tmp1 = tmp2.Invoke_O_O_O__O(Lit_46, tmp3, tmp4) }; return nil }(); var root_2699 any = A_arbace_cpp_run_A_const_92.GetRawRoot__O(); var linked_2700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2699, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2701 lang.IFn; if linked_2700 == nil { ifn_2701 = lang.IFn_Cast(root_2699) } else { ifn_2701 = nil }; if linked_2700 == nil { ifn_2701.Invoke__O() } else { linked_2700.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2699) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }

func A_arbace_cpp_run_build_linked_prebuilt_fn__97000459_A_New() *A_arbace_cpp_run_build_linked_prebuilt_fn__97000459_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_prebuilt_fn__97000459_A{}; t.Ctor(); return t }
//line :324:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000459_A) Ctor() {}
//line :324:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000459_A) Invoke_O_O__O(self, p__97000458__1 any) any { var vec__97000460__2 any = p__97000458__1; var lib__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000460__2, lang.RT_IntCast_J__I_NoInit(0), nil); var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000460__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2709 any = A_arbace_cpp_run_A_const_170.GetRawRoot__O(); var linked_2710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2709, aot_arbace_c_runtime.A_arbace_c_runtime_lib_fragment_A_fn_class); var ifn_2711 lang.IFn; if linked_2710 == nil { ifn_2711 = lang.IFn_Cast(root_2709) } else { ifn_2711 = nil }; var arg_2712 any = lib__3; var arg_2713 any = s__4; if linked_2710 == nil { return ifn_2711.Invoke_O_O__O(arg_2712, arg_2713) } else { return linked_2710.(*aot_arbace_c_runtime.A_arbace_c_runtime_lib_fragment_A).Invoke_O_O_O__O(root_2709, arg_2712, arg_2713) } }

func A_arbace_cpp_run_build_linked_prebuilt_fn__97000464_A_New() *A_arbace_cpp_run_build_linked_prebuilt_fn__97000464_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_prebuilt_fn__97000464_A{}; t.Ctor(); return t }
//line :326:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000464_A) Ctor() {}
//line :326:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000464_A) Invoke_O_O__O(self, p1__97000449_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_cpp_run_A_const_139; return tmp1.Invoke_O__O(A_arbace_cpp_run_A_const_156.Invoke_O__O(p1__97000449_SHARP___1)) }



func A_arbace_cpp_run_build_linked_prebuilt_fn__97000468_A_New_I(p0 int32) *A_arbace_cpp_run_build_linked_prebuilt_fn__97000468_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_prebuilt_fn__97000468_A{}; t.Ctor_I(p0); return t }
//line :330:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000468_A) Ctor_I(c__n int32) { t.F_n = c__n }
//line :330:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000468_A) Invoke_O_O_O__O(self, i__1, p__97000467__2 any) any { var vec__97000469__3 any = p__97000467__2; var lib__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000469__3, lang.RT_IntCast_J__I_NoInit(0), nil); if jrt.J2g_Truth(A_arbace_cpp_run_A_const_173.Invoke_O__O(lib__4)) { return nil } else { var na_2775 int64 = int64(t.F_n); var na_2776 any = i__1; if jrt.Long_InstanceOf(na_2776) { var n0_2777 int64 = na_2775; var n1_2778 int64 = jrt.NN(jrt.Long_Cast(na_2776)).LongValue__J(); var nr_2779 int64 = n0_2777 + n1_2778; if (n0_2777^nr_2779)&(n1_2778^nr_2779) >= 0 { return jrt.Long_ValueOf_J__Long_NoInit(nr_2779).Ref() } else { return lang.Numbers_Add_J_O__Number_NoInit(na_2775, na_2776) } } else { return lang.Numbers_Add_J_O__Number_NoInit(na_2775, na_2776) } } }





func A_arbace_cpp_run_build_linked_prebuilt_fn__97000473_A_New_J_J_J_O(p0, p1, p2 int64, p3 any) *A_arbace_cpp_run_build_linked_prebuilt_fn__97000473_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_prebuilt_fn__97000473_A{}; t.Ctor_J_J_J_O(p0, p1, p2, p3); return t }
//line :336:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000473_A) Ctor_J_J_J_O(c__t2, c__t1, c__t0 int64, c__text any) { t.F_t2 = c__t2; t.F_t1 = c__t1; t.F_t0 = c__t0; t.F_text = c__text }
//line :336:1
func (t *A_arbace_cpp_run_build_linked_prebuilt_fn__97000473_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_91.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_86.GetRawRoot__O()); var tmp4 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(t.F_t1, t.F_t0), 1.0e9)).Ref(); var tmp5 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(t.F_t2, t.F_t1), 1.0e9)).Ref(); var tmp6 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t.F_t2), 1.0e9)).Ref(); var tmp7 any; var t_ any = t.F_text
													t.F_text = nil; tmp7 = t_
//line :337:1
		tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O_O_O_O_O__O(Lit_58, tmp4, tmp5, tmp6, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp7)).Ref())) }
//line :336:1
	return nil }(); var root_2828 any = A_arbace_cpp_run_A_const_92.GetRawRoot__O(); var linked_2829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2828, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2830 lang.IFn; if linked_2829 == nil { ifn_2830 = lang.IFn_Cast(root_2828) } else { ifn_2830 = nil }; if linked_2829 == nil { ifn_2830.Invoke__O() } else { linked_2829.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2828) }; if tmp8 != nil { panic(tmp8) }; return tmp1 }




func A_arbace_cpp_run_build_linked_forms_A_New() *A_arbace_cpp_run_build_linked_forms_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_cpp_run_build_linked_forms_A) Ctor() {}
//line :341:1
func (t *A_arbace_cpp_run_build_linked_forms_A) Invoke_O_O_O_O__O(self, h__0, libs__1, units__2 any) any { var pdefs__4 any; var root_2842 any = A_arbace_cpp_run_A_const_105.GetRawRoot__O(); var linked_2843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2842, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2844 lang.IFn; if




	linked_2843 == nil { ifn_2844 = lang.IFn_Cast(root_2842) } else { ifn_2844 = nil }; var arg_2845 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_100.GetRawRoot__O()); var tmp2 *lang.Compiler_AOTFn; var fnbody__2860 any = A_arbace_cpp_run_build_linked_forms_fn__97000482_A_New(); var tmp3 *jrt.Class; var fncls__2859 *jrt.Class = A_arbace_cpp_run_build_linked_forms_fn__97000482_A_fn_class; if fncls__2859 == nil { var fncls__2859d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_cpp_run_build_linked_forms_fn__97000482_A_fn_class = fncls__2859d; tmp3 = fncls__2859d } else { tmp3 = fncls__2859 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2860, tmp3, nil); arg_2845 = tmp1.Invoke_O_O__O(tmp2.Ref(), units__2); if linked_2843 == nil { pdefs__4 = ifn_2844.Invoke_O__O(arg_2845) } else { pdefs__4 = linked_2843.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2842, arg_2845) }; var prefs__5 any; var root_2861 any = /*line :341:1*/A_arbace_cpp_run_A_const_105.GetRawRoot__O(); var linked_2862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2861, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2863 lang.IFn; if





	linked_2862 == nil { ifn_2863 = lang.IFn_Cast(root_2861) } else { ifn_2863 = nil }; var arg_2864 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_100.GetRawRoot__O()); var tmp5 *lang.Compiler_AOTFn; var fnbody__2889 any = A_arbace_cpp_run_build_linked_forms_fn__97000484_A_New(); var tmp6 *jrt.Class; var fncls__2888 *jrt.Class = A_arbace_cpp_run_build_linked_forms_fn__97000484_A_fn_class; if fncls__2888 == nil { var fncls__2888d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, nil); A_arbace_cpp_run_build_linked_forms_fn__97000484_A_fn_class = fncls__2888d; tmp6 = fncls__2888d } else { tmp6 = fncls__2888 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2889, tmp6, nil); arg_2864 = tmp4.Invoke_O_O__O(tmp5.Ref(), units__2); if linked_2862 == nil { prefs__5 = ifn_2863.Invoke_O__O(arg_2864) } else { prefs__5 = linked_2862.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2861, arg_2864) }; var prefs__6 any; var root_2890 any = /*line :341:1*/A_arbace_cpp_run_A_const_17.GetRawRoot__O(); var linked_2891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2890, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2892 lang.IFn; if






	linked_2891 == nil { ifn_2892 = lang.IFn_Cast(root_2890) } else { ifn_2892 = nil }; var arg_2893 any = prefs__5; var arg_2894 any; var root_2895 any = A_arbace_cpp_run_A_const_168.GetRawRoot__O(); var linked_2896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2895, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2897 lang.IFn; if linked_2896 == nil { ifn_2897 = lang.IFn_Cast(root_2895) } else { ifn_2897 = nil }; var arg_2898 any; var fnbody__2911 any = A_arbace_cpp_run_build_linked_forms_fn__97000486_A_New(); var tmp7 *jrt.Class; var fncls__2910 *jrt.Class = A_arbace_cpp_run_build_linked_forms_fn__97000486_A_fn_class; if fncls__2910 == nil { var fncls__2910d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_cpp_run_build_linked_forms_fn__97000486_A_fn_class = fncls__2910d; tmp7 = fncls__2910d } else { tmp7 = fncls__2910 }; arg_2898 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2911, tmp7, nil); var arg_2899 any = prefs__5; if linked_2896 == nil { arg_2894 = ifn_2897.Invoke_O_O__O(arg_2898, arg_2899) } else { arg_2894 = linked_2896.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2895, arg_2898, arg_2899) }; if linked_2891 == nil { prefs__6 = ifn_2892.Invoke_O_O__O(arg_2893, arg_2894) } else { prefs__6 = linked_2891.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2890, arg_2893, arg_2894) }; var linked__7 any; var root_2912 any = /*line :341:1*/A_arbace_cpp_run_A_const_169.GetRawRoot__O(); var linked_2913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2912, A_arbace_cpp_run_closure_A_fn_class); var ifn_2914 lang.IFn; if







	linked_2913 == nil { ifn_2914 = lang.IFn_Cast(root_2912) } else { ifn_2914 = nil }; var arg_2915 any = libs__1; var arg_2916 any = pdefs__4; var arg_2917 any = prefs__6; if linked_2913 == nil { linked__7 = ifn_2914.Invoke_O_O_O__O(arg_2915, arg_2916, arg_2917) } else { linked__7 = linked_2913.(*A_arbace_cpp_run_closure_A).Invoke_O_O_O_O__O(root_2912, arg_2915, arg_2916, arg_2917) }; var ___8 any; _ = ___8; if
	jrt.System_Getenv_String__String(Lit_33) != nil { var root_3101 any = A_arbace_cpp_run_A_const_93.GetRawRoot__O(); var linked_3102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3101, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3103 lang.IFn; if linked_3102 == nil { ifn_3103 = lang.IFn_Cast(root_3101) } else { ifn_3103 = nil }; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_94.GetRawRoot__O()); var tmp9 any = A_arbace_cpp_run_A_const_95; var arg_3104 any = tmp8.Invoke_O_O__O(tmp9, A_arbace_cpp_run_A_const_96.Get__O()); if linked_3102 == nil { ifn_3103.Invoke_O__O(arg_3104) } else { linked_3102.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3101, arg_3104) }; var tmp10 *lang.Compiler_AOTFn; var fnbody__2933 any = A_arbace_cpp_run_build_linked_forms_fn__97000488_A_New_O(linked__7); var tmp11 *jrt.Class; var fncls__2932 *jrt.Class = A_arbace_cpp_run_build_linked_forms_fn__97000488_A_fn_class; if fncls__2932 == nil { var fncls__2932d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__2933); A_arbace_cpp_run_build_linked_forms_fn__97000488_A_fn_class = fncls__2932d; tmp11 = fncls__2932d } else { tmp11 = fncls__2932 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2933, tmp11, nil); ___8 = Up_Compiler_AOTFn_IFn(tmp10).Invoke__O() } else { ___8 = nil }; var t0__9 int64 = /*line :341:1*/jrt.System_NanoTime__J(); var us__10 any; var root_2934 any = A_arbace_cpp_run_A_const_39.GetRawRoot__O(); var linked_2935 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2934, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2936 lang.IFn; if










	linked_2935 == nil { ifn_2936 = lang.IFn_Cast(root_2934) } else { ifn_2936 = nil }; var arg_2937 any; var fnbody__2951 any = A_arbace_cpp_run_build_linked_forms_fn__97000491_A_New_O(h__0); var tmp12 *jrt.Class; var fncls__2950 *jrt.Class = A_arbace_cpp_run_build_linked_forms_fn__97000491_A_fn_class; if fncls__2950 == nil { var fncls__2950d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__2951); A_arbace_cpp_run_build_linked_forms_fn__97000491_A_fn_class = fncls__2950d; tmp12 = fncls__2950d } else { tmp12 = fncls__2950 }; arg_2937 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2951, tmp12, nil); var arg_2938 any = linked__7; if linked_2935 == nil { us__10 = ifn_2936.Invoke_O_O__O(arg_2937, arg_2938) } else { us__10 = linked_2935.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2934, arg_2937, arg_2938) }; var t1__11 int64 = /*line :341:1*/jrt.System_NanoTime__J(); var cs__12 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_100.GetRawRoot__O()); var tmp14 *lang.Compiler_AOTFn; var fnbody__2958 any = A_arbace_cpp_run_build_linked_forms_fn__97000496_A_New(); var tmp15 *jrt.Class; var fncls__2957 *jrt.Class = A_arbace_cpp_run_build_linked_forms_fn__97000496_A_fn_class; if












	fncls__2957 == nil { var fncls__2957d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, nil); A_arbace_cpp_run_build_linked_forms_fn__97000496_A_fn_class = fncls__2957d; tmp15 = fncls__2957d } else { tmp15 = fncls__2957 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2958, tmp15, nil); var tmp16 any = tmp14.Ref(); var tmp17 any; var root_2959 any = A_arbace_cpp_run_A_const_30.GetRawRoot__O(); var linked_2960 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2959, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2961 lang.IFn; if linked_2960 == nil { ifn_2961 = lang.IFn_Cast(root_2959) } else { ifn_2961 = nil }; var arg_2962 any = units__2; var arg_2963 any = us__10; if linked_2960 == nil { tmp17 = ifn_2961.Invoke_O_O__O(arg_2962, arg_2963) } else { tmp17 = linked_2960.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2959, arg_2962, arg_2963) }; cs__12 = tmp13.Invoke_O_O__O(tmp16, tmp17); var cpp_QMARK___13 any; var root_2964 any = /*line :341:1*/A_arbace_cpp_run_A_const_39.GetRawRoot__O(); var linked_2965 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2964, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2966 lang.IFn; if














	linked_2965 == nil { ifn_2966 = lang.IFn_Cast(root_2964) } else { ifn_2966 = nil }; var arg_2967 any; var fnbody__2974 any = A_arbace_cpp_run_build_linked_forms_fn__97000499_A_New(); var tmp18 *jrt.Class; var fncls__2973 *jrt.Class = A_arbace_cpp_run_build_linked_forms_fn__97000499_A_fn_class; if fncls__2973 == nil { var fncls__2973d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, nil); A_arbace_cpp_run_build_linked_forms_fn__97000499_A_fn_class = fncls__2973d; tmp18 = fncls__2973d } else { tmp18 = fncls__2973 }; arg_2967 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2974, tmp18, nil); var arg_2968 any = linked__7; if linked_2965 == nil { cpp_QMARK___13 = ifn_2966.Invoke_O_O__O(arg_2967, arg_2968) } else { cpp_QMARK___13 = linked_2965.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2964, arg_2967, arg_2968) }; var musl_us__14 any; var root_2975 any = /*line :341:1*/A_arbace_cpp_run_A_const_162.GetRawRoot__O(); var linked_2976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2975, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_2977 lang.IFn; if















	linked_2976 == nil { ifn_2977 = lang.IFn_Cast(root_2975) } else { ifn_2977 = nil }; var arg_2978 any; var fnbody__2981 any = A_arbace_cpp_run_build_linked_forms_fn__97000504_A_New_O(cpp_QMARK___13); var tmp19 *jrt.Class; var fncls__2980 *jrt.Class = A_arbace_cpp_run_build_linked_forms_fn__97000504_A_fn_class; if fncls__2980 == nil { var fncls__2980d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, fnbody__2981); A_arbace_cpp_run_build_linked_forms_fn__97000504_A_fn_class = fncls__2980d; tmp19 = fncls__2980d } else { tmp19 = fncls__2980 }; arg_2978 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2981, tmp19, nil); var arg_2979 any = us__10; if linked_2976 == nil { musl_us__14 = ifn_2977.Invoke_O_O__O(arg_2978, arg_2979) } else { musl_us__14 = linked_2976.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_2975, arg_2978, arg_2979) }; var roots__15 any; var tmp20 lang.IFn = /*line :341:1*/lang.IFn_Cast(A_arbace_cpp_run_A_const_30.GetRawRoot__O()); var tmp21 any; var root_2988 any = A_arbace_cpp_run_A_const_63.GetRawRoot__O(); var linked_2989 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2988, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2990 lang.IFn; if
















	linked_2989 == nil { ifn_2990 = lang.IFn_Cast(root_2988) } else { ifn_2990 = nil }; var arg_2991 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var arg_2992 any = cs__12; if linked_2989 == nil { tmp21 = ifn_2990.Invoke_O_O__O(arg_2991, arg_2992) } else { tmp21 = linked_2989.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2988, arg_2991, arg_2992) }; var tmp22 any = tmp21; var tmp23 any = A_arbace_cpp_run_A_const_181; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_100.GetRawRoot__O()); var tmp25 *lang.Compiler_AOTFn; var fnbody__3017 any = A_arbace_cpp_run_build_linked_forms_fn__97000506_A_New(); var tmp26 *jrt.Class; var fncls__3016 *jrt.Class = A_arbace_cpp_run_build_linked_forms_fn__97000506_A_fn_class; if
	fncls__3016 == nil { var fncls__3016d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); A_arbace_cpp_run_build_linked_forms_fn__97000506_A_fn_class = fncls__3016d; tmp26 = fncls__3016d } else { tmp26 = fncls__3016 }; tmp25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3017, tmp26, nil); var tmp27 any = /*line :358:1*/tmp25.Ref(); var tmp28 any; var root_3018 any = A_arbace_cpp_run_A_const_30.GetRawRoot__O(); var linked_3019 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3018, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3020 lang.IFn; if
	linked_3019 == nil { ifn_3020 = lang.IFn_Cast(root_3018) } else { ifn_3020 = nil }; var arg_3021 any = units__2; var arg_3022 any = musl_us__14; if linked_3019 == nil { tmp28 = ifn_3020.Invoke_O_O__O(arg_3021, arg_3022) } else { tmp28 = linked_3019.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3018, arg_3021, arg_3022) }; roots__15 = /*line :358:1*/tmp20.Invoke_O_O_O__O(tmp22, tmp23, tmp24.Invoke_O_O__O(tmp27, tmp28)); var pruned__16 any; if

	jrt.System_Getenv_String__String(Lit_40) != nil { var root_3023 any = A_arbace_cpp_run_A_const_162.GetRawRoot__O(); var linked_3024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3023, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_3025 lang.IFn; if linked_3024 == nil { ifn_3025 = lang.IFn_Cast(root_3023) } else { ifn_3025 = nil }; var arg_3026 any; var fnbody__3029 any = A_arbace_cpp_run_build_linked_forms_fn__97000508_A_New_O(cpp_QMARK___13); var tmp29 *jrt.Class; var fncls__3028 *jrt.Class = A_arbace_cpp_run_build_linked_forms_fn__97000508_A_fn_class; if fncls__3028 == nil { var fncls__3028d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__3029); A_arbace_cpp_run_build_linked_forms_fn__97000508_A_fn_class = fncls__3028d; tmp29 = fncls__3028d } else { tmp29 = fncls__3028 }; arg_3026 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3029, tmp29, nil); var arg_3027 any = us__10; if linked_3024 == nil { pruned__16 = ifn_3025.Invoke_O_O__O(arg_3026, arg_3027) } else { pruned__16 = linked_3024.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_3023, arg_3026, arg_3027) } } else {
		var root_3030 any = A_arbace_cpp_run_A_const_182.GetRawRoot__O(); var linked_3031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3030, A_arbace_cpp_run_prune_A_fn_class); var ifn_3032 lang.IFn; if linked_3031 == nil { ifn_3032 = lang.IFn_Cast(root_3030) } else { ifn_3032 = nil }; var arg_3033 any; var root_3035 any = A_arbace_cpp_run_A_const_62.GetRawRoot__O(); var linked_3036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3035, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3037 lang.IFn; if linked_3036 == nil { ifn_3037 = lang.IFn_Cast(root_3035) } else { ifn_3037 = nil }; var arg_3038 any; var root_3039 any = A_arbace_cpp_run_A_const_162.GetRawRoot__O(); var linked_3040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3039, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_3041 lang.IFn; if linked_3040 == nil { ifn_3041 = lang.IFn_Cast(root_3039) } else { ifn_3041 = nil }; var arg_3042 any; var fnbody__3045 any = A_arbace_cpp_run_build_linked_forms_fn__97000510_A_New_O(cpp_QMARK___13); var tmp30 *jrt.Class; var fncls__3044 *jrt.Class = A_arbace_cpp_run_build_linked_forms_fn__97000510_A_fn_class; if fncls__3044 == nil { var fncls__3044d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__3045); A_arbace_cpp_run_build_linked_forms_fn__97000510_A_fn_class = fncls__3044d; tmp30 = fncls__3044d } else { tmp30 = fncls__3044 }; arg_3042 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3045, tmp30, nil); var arg_3043 any = us__10; if linked_3040 == nil { arg_3038 = ifn_3041.Invoke_O_O__O(arg_3042, arg_3043) } else { arg_3038 = linked_3040.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_3039, arg_3042, arg_3043) }; if linked_3036 == nil { arg_3033 = ifn_3037.Invoke_O__O(arg_3038) } else { arg_3033 = linked_3036.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3035, arg_3038) }; var arg_3034 any = roots__15; if linked_3031 == nil { pruned__16 = ifn_3032.Invoke_O_O__O(arg_3033, arg_3034) } else { pruned__16 = linked_3031.(*A_arbace_cpp_run_prune_A).Invoke_O_O_O__O(root_3030, arg_3033, arg_3034) } }; var us__17 any; var pq__17 any; var tmp31 any; var root_3046 any = /*line :341:1*/A_arbace_cpp_run_A_const_62.GetRawRoot__O(); var linked_3047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3046, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3048 lang.IFn; if




















	linked_3047 == nil { ifn_3048 = lang.IFn_Cast(root_3046) } else { ifn_3048 = nil }; var arg_3049 any = pruned__16; if linked_3047 == nil { tmp31 = ifn_3048.Invoke_O__O(arg_3049) } else { tmp31 = linked_3047.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3046, arg_3049) }; pq__17 = /*line :341:1*/jrt.ArrayDeque_New_Collection(jrt.Collection_Cast(tmp31)); var root_3050 any =





















	A_arbace_cpp_run_A_const_39.GetRawRoot__O(); var linked_3051 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3050, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_3052 lang.IFn; if linked_3051 == nil { ifn_3052 = lang.IFn_Cast(root_3050) } else { ifn_3052 = nil }; var arg_3053 any; var fnbody__3057 any = A_arbace_cpp_run_build_linked_forms_fn__97000512_A_New_O_O(pq__17, cpp_QMARK___13); var tmp32 *jrt.Class; var fncls__3056 *jrt.Class = A_arbace_cpp_run_build_linked_forms_fn__97000512_A_fn_class; if fncls__3056 == nil { var fncls__3056d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__3057); A_arbace_cpp_run_build_linked_forms_fn__97000512_A_fn_class = fncls__3056d; tmp32 = fncls__3056d } else { tmp32 = fncls__3056 }; arg_3053 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3057, tmp32, nil); var arg_3054 any; var root_3058 any = A_arbace_cpp_run_A_const_97.GetRawRoot__O(); var linked_3059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3058, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_3060 lang.IFn; if linked_3059 == nil { ifn_3060 = lang.IFn_Cast(root_3058) } else { ifn_3060 = nil }; var arg_3061 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(us__10)).Ref(); if linked_3059 == nil { arg_3054 = ifn_3060.Invoke_O__O(arg_3061) } else { arg_3054 = linked_3059.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_3058, arg_3061) }; var arg_3055 any = us__10; if linked_3051 == nil { us__17 = ifn_3052.Invoke_O_O_O__O(arg_3053, arg_3054, arg_3055) } else { us__17 = linked_3051.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O_O__O(root_3050, arg_3053, arg_3054, arg_3055) }; var init__18 any; var tmp33 any; var root_3062 any = /*line :341:1*/A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_3063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3062, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3064 lang.IFn; if






















	linked_3063 == nil { ifn_3064 = lang.IFn_Cast(root_3062) } else { ifn_3064 = nil }; var arg_3065 any = cs__12; if linked_3063 == nil { tmp33 = ifn_3064.Invoke_O__O(arg_3065) } else { tmp33 = linked_3063.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3062, arg_3065) }; if jrt.J2g_Truth(tmp33) { var root_3066 any = A_arbace_cpp_run_A_const_171.GetRawRoot__O(); var linked_3067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3066, A_arbace_cpp_run_init_unit_A_fn_class); var ifn_3068 lang.IFn; if linked_3067 == nil { ifn_3068 = lang.IFn_Cast(root_3066) } else { ifn_3068 = nil }; var arg_3069 any = h__0; var arg_3070 any; var root_3071 any = A_arbace_cpp_run_A_const_63.GetRawRoot__O(); var linked_3072 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3071, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3073 lang.IFn; if linked_3072 == nil { ifn_3073 = lang.IFn_Cast(root_3071) } else { ifn_3073 = nil }; var arg_3074 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var arg_3075 any; var root_3076 any = A_arbace_cpp_run_A_const_109.GetRawRoot__O(); var linked_3077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3076, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_3078 lang.IFn; if linked_3077 == nil { ifn_3078 = lang.IFn_Cast(root_3076) } else { ifn_3078 = nil }; var arg_3079 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var arg_3080 any = cs__12; if linked_3077 == nil { arg_3075 = ifn_3078.Invoke_O_O__O(arg_3079, arg_3080) } else { arg_3075 = linked_3077.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_3076, arg_3079, arg_3080) }; if linked_3072 == nil { arg_3070 = ifn_3073.Invoke_O_O__O(arg_3074, arg_3075) } else { arg_3070 = linked_3072.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3071, arg_3074, arg_3075) }; if linked_3067 == nil { init__18 = ifn_3068.Invoke_O_O__O(arg_3069, arg_3070) } else { init__18 = linked_3067.(*A_arbace_cpp_run_init_unit_A).Invoke_O_O_O__O(root_3066, arg_3069, arg_3070) } } else { init__18 = nil }; var t2__19 int64 = /*line :341:1*/jrt.System_NanoTime__J(); var r__20 any; var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_183.GetRawRoot__O()); var tmp35 any; var G__97000514__20_ any; var root_3087 any = A_arbace_cpp_run_A_const_62.GetRawRoot__O(); var linked_3088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3087, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3089 lang.IFn; if
























	linked_3088 == nil { ifn_3089 = lang.IFn_Cast(root_3087) } else { ifn_3089 = nil }; var arg_3090 any = units__2; if linked_3088 == nil { G__97000514__20_ = ifn_3089.Invoke_O__O(arg_3090) } else { G__97000514__20_ = linked_3088.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3087, arg_3090) }; var G__97000514__21_ any; if jrt.J2g_Truth(init__18) { var root_3091 any = A_arbace_cpp_run_A_const_15.GetRawRoot__O(); var linked_3092 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3091, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_3093 lang.IFn; if linked_3092 == nil { ifn_3093 = lang.IFn_Cast(root_3091) } else { ifn_3093 = nil }; var arg_3094 any = G__97000514__20_; var arg_3095 any = init__18; if linked_3092 == nil { G__97000514__21_ = ifn_3093.Invoke_O_O__O(arg_3094, arg_3095) } else { G__97000514__21_ = linked_3092.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_3091, arg_3094, arg_3095) } } else { G__97000514__21_ = G__97000514__20_ }; if jrt.J2g_Truth(jrt.Boolean_TRUE.Ref()) { var root_3096 any = A_arbace_cpp_run_A_const_17.GetRawRoot__O(); var linked_3097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3096, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_3098 lang.IFn; if linked_3097 == nil { ifn_3098 = lang.IFn_Cast(root_3096) } else { ifn_3098 = nil }; var arg_3099 any = G__97000514__21_; var arg_3100 any = us__17; if linked_3097 == nil { tmp35 = ifn_3098.Invoke_O_O__O(arg_3099, arg_3100) } else { tmp35 = linked_3097.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_3096, arg_3099, arg_3100) } } else { tmp35 = G__97000514__21_ }; r__20 = tmp34.Invoke_O_O_O__O(tmp35, A_arbace_cpp_run_A_const_175, jrt.Boolean_TRUE.Ref()); if
	jrt.System_Getenv_String__String(Lit_33) != nil {
		var root_3158 any = A_arbace_cpp_run_A_const_93.GetRawRoot__O(); var linked_3159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3158, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3160 lang.IFn; if linked_3159 == nil { ifn_3160 = lang.IFn_Cast(root_3158) } else { ifn_3160 = nil }; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_94.GetRawRoot__O()); var tmp37 any = A_arbace_cpp_run_A_const_95; var arg_3161 any = tmp36.Invoke_O_O__O(tmp37, A_arbace_cpp_run_A_const_96.Get__O()); if linked_3159 == nil { ifn_3160.Invoke_O__O(arg_3161) } else { linked_3159.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3158, arg_3161) }; var tmp38 *lang.Compiler_AOTFn; var fnbody__3157 any = A_arbace_cpp_run_build_linked_forms_fn__97000515_A_New_O_O_J_O_O_J_J(h__0, pruned__16, t2__19, cpp_QMARK___13, linked__7, t1__11, t0__9); var tmp39 *jrt.Class; var fncls__3156 *jrt.Class = A_arbace_cpp_run_build_linked_forms_fn__97000515_A_fn_class; if fncls__3156 == nil { var fncls__3156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__3157); A_arbace_cpp_run_build_linked_forms_fn__97000515_A_fn_class = fncls__3156d; tmp39 = fncls__3156d } else { tmp39 = fncls__3156 }; tmp38 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3157, tmp39, nil); Up_Compiler_AOTFn_IFn(tmp38).Invoke__O() }; return r__20 }
//line :346:1
func A_arbace_cpp_run_build_linked_forms_fn__97000482_A_New() *A_arbace_cpp_run_build_linked_forms_fn__97000482_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_fn__97000482_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000482_A) Ctor() {}
//line :346:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000482_A) Invoke_O_O__O(self, p1__97000476_SHARP___1 any) any { var root_2851 any = A_arbace_cpp_run_A_const_64.GetRawRoot__O(); var linked_2852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2851, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2853 lang.IFn; if linked_2852 == nil { ifn_2853 = lang.IFn_Cast(root_2851) } else { ifn_2853 = nil }; var arg_2854 any; var root_2855 any = A_arbace_cpp_run_A_const_103.GetRawRoot__O(); var linked_2856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2855, aot_arbace_c_musl.A_arbace_c_musl_unit_defs_A_fn_class); var ifn_2857 lang.IFn; if linked_2856 == nil { ifn_2857 = lang.IFn_Cast(root_2855) } else { ifn_2857 = nil }; var tmp1 *lang.Keyword = A_arbace_cpp_run_A_const_70; var arg_2858 any = tmp1.Invoke_O__O(A_arbace_cpp_run_A_const_156.Invoke_O__O(p1__97000476_SHARP___1)); if linked_2856 == nil { arg_2854 = ifn_2857.Invoke_O__O(arg_2858) } else { arg_2854 = linked_2856.(*aot_arbace_c_musl.A_arbace_c_musl_unit_defs_A).Invoke_O_O__O(root_2855, arg_2858) }; if linked_2852 == nil { return ifn_2853.Invoke_O__O(arg_2854) } else { return linked_2852.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2851, arg_2854) } }
func A_arbace_cpp_run_build_linked_forms_fn__97000484_A_New() *A_arbace_cpp_run_build_linked_forms_fn__97000484_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_fn__97000484_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000484_A) Ctor() {}
//line :347:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000484_A) Invoke_O_O__O(self, p1__97000477_SHARP___1 any) any { var root_2870 any = A_arbace_cpp_run_A_const_106.GetRawRoot__O(); var linked_2871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2870, aot_arbace_c_musl.A_arbace_c_musl_refs_A_fn_class); var ifn_2872 lang.IFn; if linked_2871 == nil { ifn_2872 = lang.IFn_Cast(root_2870) } else { ifn_2872 = nil }; var arg_2873 any; var root_2874 any = A_arbace_cpp_run_A_const_30.GetRawRoot__O(); var linked_2875 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2874, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2876 lang.IFn; if linked_2875 == nil { ifn_2876 = lang.IFn_Cast(root_2874) } else { ifn_2876 = nil }; var tmp1 *lang.Keyword = A_arbace_cpp_run_A_const_70; var arg_2877 any = tmp1.Invoke_O__O(A_arbace_cpp_run_A_const_156.Invoke_O__O(p1__97000477_SHARP___1)); var arg_2878 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_100.GetRawRoot__O()); var tmp3 any = A_arbace_cpp_run_A_const_70; var tmp4 any; var root_2884 any = A_arbace_cpp_run_A_const_101.GetRawRoot__O(); var linked_2885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2884, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_2886 lang.IFn; if linked_2885 == nil { ifn_2886 = lang.IFn_Cast(root_2884) } else { ifn_2886 = nil }; var tmp5 *lang.Keyword = A_arbace_cpp_run_A_const_65; var arg_2887 any = tmp5.Invoke_O__O(A_arbace_cpp_run_A_const_156.Invoke_O__O(p1__97000477_SHARP___1)); if linked_2885 == nil { tmp4 = ifn_2886.Invoke_O__O(arg_2887) } else { tmp4 = linked_2885.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_2884, arg_2887) }; arg_2878 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_2875 == nil { arg_2873 = ifn_2876.Invoke_O_O__O(arg_2877, arg_2878) } else { arg_2873 = linked_2875.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2874, arg_2877, arg_2878) }; if linked_2871 == nil { return ifn_2872.Invoke_O__O(arg_2873) } else { return linked_2871.(*aot_arbace_c_musl.A_arbace_c_musl_refs_A).Invoke_O_O__O(root_2870, arg_2873) } }
func A_arbace_cpp_run_build_linked_forms_fn__97000486_A_New() *A_arbace_cpp_run_build_linked_forms_fn__97000486_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_fn__97000486_A{}; t.Ctor(); return t }
//line :348:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000486_A) Ctor() {}
//line :348:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000486_A) Invoke_O_O__O(self, p1__97000478_SHARP___1 any) any { var tmp1 any; var root_2900 any = A_arbace_cpp_run_A_const_66.GetRawRoot__O(); var linked_2901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2900, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2902 lang.IFn; if linked_2901 == nil { ifn_2902 = lang.IFn_Cast(root_2900) } else { ifn_2902 = nil }; var arg_2903 any = p1__97000478_SHARP___1; var arg_2904 any = Lit_45; if linked_2901 == nil { tmp1 = ifn_2902.Invoke_O_O__O(arg_2903, arg_2904) } else { tmp1 = linked_2901.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2900, arg_2903, arg_2904) }; if jrt.J2g_Truth(tmp1) { var root_2905 any = A_arbace_cpp_run_A_const_71.GetRawRoot__O(); var linked_2906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2905, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2907 lang.IFn; if linked_2906 == nil { ifn_2907 = lang.IFn_Cast(root_2905) } else { ifn_2907 = nil }; var arg_2908 any = p1__97000478_SHARP___1; var arg_2909 any = A_arbace_cpp_run_A_const_149; if linked_2906 == nil { return ifn_2907.Invoke_O_O__O(arg_2908, arg_2909) } else { return linked_2906.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2905, arg_2908, arg_2909) } } else { return nil } }

func A_arbace_cpp_run_build_linked_forms_fn__97000488_A_New_O(p0 any) *A_arbace_cpp_run_build_linked_forms_fn__97000488_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_fn__97000488_A{}; t.Ctor_O(p0); return t }
//line :350:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000488_A) Ctor_O(c__linked any) { t.F_linked = c__linked }
//line :350:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000488_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_91.GetRawRoot__O()); var tmp3 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(t.F_linked)).Ref(); var tmp4 any; var root_2924 any = A_arbace_cpp_run_A_const_39.GetRawRoot__O(); var linked_2925 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2924, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2926 lang.IFn; if linked_2925 == nil { ifn_2926 = lang.IFn_Cast(root_2924) } else { ifn_2926 = nil }; var arg_2927 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var arg_2928 any; var t_ any = t.F_linked; t.F_linked = nil; arg_2928 = t_; if linked_2925 == nil { tmp4 = ifn_2926.Invoke_O_O__O(arg_2927, arg_2928) } else { tmp4 = linked_2925.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2924, arg_2927, arg_2928) }; tmp1 = tmp2.Invoke_O_O_O__O(Lit_46, tmp3, tmp4) }; return nil }(); var root_2929 any = A_arbace_cpp_run_A_const_92.GetRawRoot__O(); var linked_2930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2929, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2931 lang.IFn; if linked_2930 == nil { ifn_2931 = lang.IFn_Cast(root_2929) } else { ifn_2931 = nil }; if linked_2930 == nil { ifn_2931.Invoke__O() } else { linked_2930.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2929) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }

func A_arbace_cpp_run_build_linked_forms_fn__97000491_A_New_O(p0 any) *A_arbace_cpp_run_build_linked_forms_fn__97000491_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_fn__97000491_A{}; t.Ctor_O(p0); return t }
//line :352:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000491_A) Ctor_O(c__h any) { t.F_h = c__h }
//line :352:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000491_A) Invoke_O_O__O(self, p__97000490__1 any) any { var vec__97000492__2 any = p__97000490__1; var lib__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000492__2, lang.RT_IntCast_J__I_NoInit(0), nil); var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000492__2, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(A_arbace_cpp_run_A_const_173.Invoke_O__O(lib__3)) { var root_2939 any = A_arbace_cpp_run_A_const_179.GetRawRoot__O(); var linked_2940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2939, aot_arbace_c_musl.A_arbace_c_musl_checked_unit_A_fn_class); var ifn_2941 lang.IFn; if linked_2940 == nil { ifn_2941 = lang.IFn_Cast(root_2939) } else { ifn_2941 = nil }; var arg_2942 any = lib__3; var arg_2943 any = s__4; if linked_2940 == nil { return ifn_2941.Invoke_O_O__O(arg_2942, arg_2943) } else { return linked_2940.(*aot_arbace_c_musl.A_arbace_c_musl_checked_unit_A).Invoke_O_O_O__O(root_2939, arg_2942, arg_2943) } } else { var root_2944 any = A_arbace_cpp_run_A_const_180.GetRawRoot__O(); var linked_2945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2944, A_arbace_cpp_run_checked_lib_unit_A_fn_class); var ifn_2946 lang.IFn; if linked_2945 == nil { ifn_2946 = lang.IFn_Cast(root_2944) } else { ifn_2946 = nil }; var arg_2947 any = t.F_h; var arg_2948 any = lib__3; var arg_2949 any = s__4; if linked_2945 == nil { return ifn_2946.Invoke_O_O_O__O(arg_2947, arg_2948, arg_2949) } else { return linked_2945.(*A_arbace_cpp_run_checked_lib_unit_A).Invoke_O_O_O_O__O(root_2944, arg_2947, arg_2948, arg_2949) } } }

func A_arbace_cpp_run_build_linked_forms_fn__97000496_A_New() *A_arbace_cpp_run_build_linked_forms_fn__97000496_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_fn__97000496_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000496_A) Ctor() {}
//line :354:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000496_A) Invoke_O_O__O(self, p1__97000479_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_cpp_run_A_const_139; return tmp1.Invoke_O__O(A_arbace_cpp_run_A_const_156.Invoke_O__O(p1__97000479_SHARP___1)) }

func A_arbace_cpp_run_build_linked_forms_fn__97000499_A_New() *A_arbace_cpp_run_build_linked_forms_fn__97000499_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_fn__97000499_A{}; t.Ctor(); return t }
//line :356:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000499_A) Ctor() {}
//line :356:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000499_A) Invoke_O_O__O(self, p__97000498__1 any) any { var vec__97000500__2 any = p__97000498__1; var lib__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000500__2, lang.RT_IntCast_J__I_NoInit(0), nil); var root_2969 any = A_arbace_cpp_run_A_const_110.GetRawRoot__O(); var linked_2970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2969, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2971 lang.IFn; if linked_2970 == nil { ifn_2971 = lang.IFn_Cast(root_2969) } else { ifn_2971 = nil }; var arg_2972 any = A_arbace_cpp_run_A_const_173.Invoke_O__O(lib__3); if linked_2970 == nil { return ifn_2971.Invoke_O__O(arg_2972) } else { return linked_2970.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2969, arg_2972) } }
func A_arbace_cpp_run_build_linked_forms_fn__97000504_A_New_O(p0 any) *A_arbace_cpp_run_build_linked_forms_fn__97000504_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_fn__97000504_A{}; t.Ctor_O(p0); return t }
//line :357:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000504_A) Ctor_O(c__cpp_QMARK_ any) { t.F_cpp_QMARK_ = c__cpp_QMARK_ }
//line :357:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000504_A) Invoke_O_O_O__O(self, i__1, u__2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_cpp_QMARK_).Invoke_O__O(i__1)) { return nil } else { return u__2 } }

func A_arbace_cpp_run_build_linked_forms_fn__97000506_A_New() *A_arbace_cpp_run_build_linked_forms_fn__97000506_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_fn__97000506_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000506_A) Ctor() {}
//line :359:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000506_A) Invoke_O_O__O(self, p1__97000480_SHARP___1 any) any { var root_2998 any = A_arbace_cpp_run_A_const_106.GetRawRoot__O(); var linked_2999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2998, aot_arbace_c_musl.A_arbace_c_musl_refs_A_fn_class); var ifn_3000 lang.IFn; if linked_2999 == nil { ifn_3000 = lang.IFn_Cast(root_2998) } else { ifn_3000 = nil }; var arg_3001 any; var root_3002 any = A_arbace_cpp_run_A_const_30.GetRawRoot__O(); var linked_3003 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3002, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3004 lang.IFn; if linked_3003 == nil { ifn_3004 = lang.IFn_Cast(root_3002) } else { ifn_3004 = nil }; var tmp1 *lang.Keyword = A_arbace_cpp_run_A_const_70; var arg_3005 any = tmp1.Invoke_O__O(A_arbace_cpp_run_A_const_156.Invoke_O__O(p1__97000480_SHARP___1)); var arg_3006 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_100.GetRawRoot__O()); var tmp3 any = A_arbace_cpp_run_A_const_70; var tmp4 any; var root_3012 any = A_arbace_cpp_run_A_const_101.GetRawRoot__O(); var linked_3013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3012, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_3014 lang.IFn; if linked_3013 == nil { ifn_3014 = lang.IFn_Cast(root_3012) } else { ifn_3014 = nil }; var tmp5 *lang.Keyword = A_arbace_cpp_run_A_const_65; var arg_3015 any = tmp5.Invoke_O__O(A_arbace_cpp_run_A_const_156.Invoke_O__O(p1__97000480_SHARP___1)); if linked_3013 == nil { tmp4 = ifn_3014.Invoke_O__O(arg_3015) } else { tmp4 = linked_3013.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_3012, arg_3015) }; arg_3006 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_3003 == nil { arg_3001 = ifn_3004.Invoke_O_O__O(arg_3005, arg_3006) } else { arg_3001 = linked_3003.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3002, arg_3005, arg_3006) }; if linked_2999 == nil { return ifn_3000.Invoke_O__O(arg_3001) } else { return linked_2999.(*aot_arbace_c_musl.A_arbace_c_musl_refs_A).Invoke_O_O__O(root_2998, arg_3001) } }
func A_arbace_cpp_run_build_linked_forms_fn__97000508_A_New_O(p0 any) *A_arbace_cpp_run_build_linked_forms_fn__97000508_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_fn__97000508_A{}; t.Ctor_O(p0); return t }
//line :360:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000508_A) Ctor_O(c__cpp_QMARK_ any) { t.F_cpp_QMARK_ = c__cpp_QMARK_ }
//line :360:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000508_A) Invoke_O_O_O__O(self, i__1, u__2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_cpp_QMARK_).Invoke_O__O(i__1)) { return u__2 } else { return nil } }
func A_arbace_cpp_run_build_linked_forms_fn__97000510_A_New_O(p0 any) *A_arbace_cpp_run_build_linked_forms_fn__97000510_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_fn__97000510_A{}; t.Ctor_O(p0); return t }
//line :361:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000510_A) Ctor_O(c__cpp_QMARK_ any) { t.F_cpp_QMARK_ = c__cpp_QMARK_ }
//line :361:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000510_A) Invoke_O_O_O__O(self, i__1, u__2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_cpp_QMARK_).Invoke_O__O(i__1)) { return u__2 } else { return nil } }

func A_arbace_cpp_run_build_linked_forms_fn__97000512_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_build_linked_forms_fn__97000512_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_fn__97000512_A{}; t.Ctor_O_O(p0, p1); return t }
//line :363:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000512_A) Ctor_O_O(c__pq, c__cpp_QMARK_ any) { t.F_pq = c__pq; t.F_cpp_QMARK_ = c__cpp_QMARK_ }
//line :363:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000512_A) Invoke_O_O_O__O(self, i__1, u__2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_cpp_QMARK_).Invoke_O__O(i__1)) { return jrt.ArrayDeque_Cast(t.F_pq).Poll__O() } else { return u__2 } }




func A_arbace_cpp_run_build_linked_forms_fn__97000515_A_New_O_O_J_O_O_J_J(p0, p1 any, p2 int64, p3, p4 any, p5, p6 int64) *A_arbace_cpp_run_build_linked_forms_fn__97000515_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_fn__97000515_A{}; t.Ctor_O_O_J_O_O_J_J(p0, p1, p2, p3, p4, p5, p6); return t }
//line :368:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000515_A) Ctor_O_O_J_O_O_J_J(c__h, c__pruned any, c__t2 int64, c__cpp_QMARK_, c__linked any, c__t1, c__t0 int64) { t.F_h = c__h; t.F_pruned = c__pruned; t.F_t2 = c__t2; t.F_cpp_QMARK_ = c__cpp_QMARK_; t.F_linked = c__linked; t.F_t1 = c__t1; t.F_t0 = c__t0 }
//line :368:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000515_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_91.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_86.GetRawRoot__O()); var tmp4 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(t.F_t1, t.F_t0), 1.0e9)).Ref(); var tmp5 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(t.F_t2, t.F_t1), 1.0e9)).Ref(); var tmp6 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t.F_t2), 1.0e9)).Ref(); var tmp7 any; var root_3123 any = A_arbace_cpp_run_A_const_184.GetRawRoot__O(); var linked_3124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3123, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3125 lang.IFn
												if linked_3124 == nil { ifn_3125 = lang.IFn_Cast(root_3123) } else { ifn_3125 = nil }; var arg_3126 any = A_arbace_cpp_run_A_const_185.GetRawRoot__O(); var arg_3127 any; var root_3128 any = A_arbace_cpp_run_A_const_63.GetRawRoot__O(); var linked_3129 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3128, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3130 lang.IFn; if linked_3129 == nil { ifn_3130 = lang.IFn_Cast(root_3128) } else { ifn_3130 = nil }; var arg_3131 any; var fnbody__3134 any = A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000516_A_New(); var tmp8 *jrt.Class; var fncls__3133 *jrt.Class = A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000516_A_fn_class; if fncls__3133 == nil { var fncls__3133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000516_A_fn_class = fncls__3133d; tmp8 = fncls__3133d } else { tmp8 = fncls__3133 }; arg_3131 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3134, tmp8, nil); var arg_3132 any; var t_ any = t.F_pruned; t.F_pruned = nil; arg_3132 = t_; if linked_3129 == nil { arg_3127 = ifn_3130.Invoke_O_O__O(arg_3131, arg_3132) } else { arg_3127 = linked_3129.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3128, arg_3131, arg_3132) }; if linked_3124 == nil { tmp7 = ifn_3125.Invoke_O_O__O(arg_3126, arg_3127) } else { tmp7 = linked_3124.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_3123, arg_3126, arg_3127) }
//line :369:1
		var tmp9 any = tmp7; var tmp10 any; var root_3135 any = A_arbace_cpp_run_A_const_184.GetRawRoot__O(); var linked_3136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3135, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3137 lang.IFn

		if linked_3136 == nil { ifn_3137 = lang.IFn_Cast(root_3135) } else { ifn_3137 = nil }; var arg_3138 any = A_arbace_cpp_run_A_const_185.GetRawRoot__O(); var arg_3139 any; var root_3140 any = A_arbace_cpp_run_A_const_162.GetRawRoot__O(); var linked_3141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3140, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_3142 lang.IFn; if linked_3141 == nil { ifn_3142 = lang.IFn_Cast(root_3140) } else { ifn_3142 = nil }; var arg_3143 any; var fnbody__3152 any = A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000519_A_New_O_O(t.F_h, t.F_cpp_QMARK_); var tmp11 *jrt.Class; var fncls__3151 *jrt.Class = A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000519_A_fn_class; if fncls__3151 == nil { var fncls__3151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__3152); A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000519_A_fn_class = fncls__3151d; tmp11 = fncls__3151d } else { tmp11 = fncls__3151 }; arg_3143 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3152, tmp11, nil); var arg_3144 any; var t__2 any = t.F_linked; t.F_linked = nil; arg_3144 = t__2; if linked_3141 == nil { arg_3139 = ifn_3142.Invoke_O_O__O(arg_3143, arg_3144) } else { arg_3139 = linked_3141.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_3140, arg_3143, arg_3144) }; if linked_3136 == nil { tmp10 = ifn_3137.Invoke_O_O__O(arg_3138, arg_3139) } else { tmp10 = linked_3136.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_3135, arg_3138, arg_3139) }
//line :369:1
		tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O_O_O_O_O_O__O(Lit_47, tmp4, tmp5, tmp6, tmp9, tmp10)) }
//line :368:1
	return nil }(); var root_3153 any = A_arbace_cpp_run_A_const_92.GetRawRoot__O(); var linked_3154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3153, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3155 lang.IFn; if linked_3154 == nil { ifn_3155 = lang.IFn_Cast(root_3153) } else { ifn_3155 = nil }; if linked_3154 == nil { ifn_3155.Invoke__O() } else { linked_3154.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3153) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }

func A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000516_A_New() *A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000516_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000516_A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000516_A) Ctor() {}
//line :370:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000516_A) Invoke_O_O__O(self, p1__97000481_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_cpp_run_A_const_70; return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp1.Invoke_O__O(A_arbace_cpp_run_A_const_156.Invoke_O__O(p1__97000481_SHARP___1)))).Ref() }
func A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000519_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000519_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000519_A{}; t.Ctor_O_O(p0, p1); return t }
//line :371:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000519_A) Ctor_O_O(c__h, c__cpp_QMARK_ any) { t.F_h = c__h; t.F_cpp_QMARK_ = c__cpp_QMARK_ }
//line :371:1
func (t *A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000519_A) Invoke_O_O_O__O(self, i__1, p__97000518__2 any) any { var vec__97000520__3 any = p__97000518__2; var lib__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000520__3, lang.RT_IntCast_J__I_NoInit(0), nil); var s__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000520__3, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(lang.IFn_Cast(t.F_cpp_QMARK_).Invoke_O__O(i__1)) { var tmp1 *lang.Keyword = A_arbace_cpp_run_A_const_70; var tmp2 *lang.Keyword = A_arbace_cpp_run_A_const_156; var tmp3 any; var root_3145 any = A_arbace_cpp_run_A_const_180.GetRawRoot__O(); var linked_3146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3145, A_arbace_cpp_run_checked_lib_unit_A_fn_class); var ifn_3147 lang.IFn; if linked_3146 == nil { ifn_3147 = lang.IFn_Cast(root_3145) } else { ifn_3147 = nil }; var arg_3148 any = t.F_h; var arg_3149 any = lib__4; var arg_3150 any = s__5; if linked_3146 == nil { tmp3 = ifn_3147.Invoke_O_O_O__O(arg_3148, arg_3149, arg_3150) } else { tmp3 = linked_3146.(*A_arbace_cpp_run_checked_lib_unit_A).Invoke_O_O_O_O__O(root_3145, arg_3148, arg_3149, arg_3150) }; return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3)))).Ref() } else { return nil } }


func A_arbace_cpp_run_build_linked_A_New() *A_arbace_cpp_run_build_linked_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_linked_A{}; t.Ctor(); return t }
//line :374:1
func (t *A_arbace_cpp_run_build_linked_A) Ctor() {}
//line :374:1
func (t *A_arbace_cpp_run_build_linked_A) Invoke_O_O_O_O__O(self, h__0, libs__1, units__2 any) any {



	if lang.Util_Equiv_O_O__Z_NoInit(Lit_28, jrt.System_Getenv_String__String(Lit_29).Ref()) {
		var root_3167 any = A_arbace_cpp_run_A_const_186.GetRawRoot__O(); var linked_3168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3167, A_arbace_cpp_run_build_linked_forms_A_fn_class); var ifn_3169 lang.IFn; if linked_3168 == nil { ifn_3169 = lang.IFn_Cast(root_3167) } else { ifn_3169 = nil }; var arg_3170 any = h__0; var arg_3171 any = libs__1; var arg_3172 any = units__2; if linked_3168 == nil { return ifn_3169.Invoke_O_O_O__O(arg_3170, arg_3171, arg_3172) } else { return linked_3168.(*A_arbace_cpp_run_build_linked_forms_A).Invoke_O_O_O_O__O(root_3167, arg_3170, arg_3171, arg_3172) } } else {
			var root_3173 any = A_arbace_cpp_run_A_const_187.GetRawRoot__O(); var linked_3174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3173, aot_arbace_c_build.A_arbace_c_build_read_program_A_fn_class); var ifn_3175 lang.IFn; if linked_3174 == nil { ifn_3175 = lang.IFn_Cast(root_3173) } else { ifn_3175 = nil }; var arg_3176 any; var root_3177 any = A_arbace_cpp_run_A_const_188.GetRawRoot__O(); var linked_3178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3177, A_arbace_cpp_run_build_linked_prebuilt_A_fn_class); var ifn_3179 lang.IFn; if linked_3178 == nil { ifn_3179 = lang.IFn_Cast(root_3177) } else { ifn_3179 = nil }; var arg_3180 any = h__0; var arg_3181 any = libs__1; var arg_3182 any = units__2; if linked_3178 == nil { arg_3176 = ifn_3179.Invoke_O_O_O__O(arg_3180, arg_3181, arg_3182) } else { arg_3176 = linked_3178.(*A_arbace_cpp_run_build_linked_prebuilt_A).Invoke_O_O_O_O__O(root_3177, arg_3180, arg_3181, arg_3182) }; if linked_3174 == nil { return ifn_3175.Invoke_O__O(arg_3176) } else { return linked_3174.(*aot_arbace_c_build.A_arbace_c_build_read_program_A).Invoke_O_O__O(root_3173, arg_3176)
			}
		}
}

func A_arbace_cpp_run_secs_A_New() *A_arbace_cpp_run_secs_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_secs_A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_cpp_run_secs_A) Ctor() {}
//line :385:1
func (t *A_arbace_cpp_run_secs_A) Invoke_O_O__O(self, t0__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_86.GetRawRoot__O()); var tmp2 jrt.Number_I; var na_3188 int64 = jrt.System_NanoTime__J(); var na_3189 any = t0__0; if jrt.Long_InstanceOf(na_3189) { var n0_3190 int64 = na_3188; var n1_3191 int64 = jrt.NN(jrt.Long_Cast(na_3189)).LongValue__J(); var nr_3192 int64 = n0_3190 - n1_3191; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_3191 == -9223372036854775808); if tmp4 { tmp4 = (n0_3190^n1_3191)&(n0_3190^nr_3192) >= 0 }; tmp3 = tmp4; if tmp3 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_3192)) } else { tmp2 = lang.Numbers_Minus_J_O__Number_NoInit(na_3188, na_3189) } } else { tmp2 = lang.Numbers_Minus_J_O__Number_NoInit(na_3188, na_3189) }; return tmp1.Invoke_O_O__O(Lit_194, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(tmp2, 1.0e9)).Ref()) }

func A_arbace_cpp_run_uses_atomic_generic_QMARK__A_New() *A_arbace_cpp_run_uses_atomic_generic_QMARK__A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_uses_atomic_generic_QMARK__A{}; t.Ctor(); return t }
//line :387:1
func (t *A_arbace_cpp_run_uses_atomic_generic_QMARK__A) Ctor() {}
//line :387:1
func (t *A_arbace_cpp_run_uses_atomic_generic_QMARK__A) Invoke_O_O__O(self, forms__0 any) any { var body_walk__2 *A_arbace_cpp_run_uses_atomic_generic_QMARK__walk__97000528_A = A_arbace_cpp_run_uses_atomic_generic_QMARK__walk__97000528_A_New(); var walk__2 any; var fnbody__3215 any = any(body_walk__2); var tmp1 *jrt.Class; var fncls__3214 *jrt.Class = A_arbace_cpp_run_uses_atomic_generic_QMARK__walk__97000528_A_fn_class; if fncls__3214 == nil { var fncls__3214d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_214, false, nil); A_arbace_cpp_run_uses_atomic_generic_QMARK__walk__97000528_A_fn_class = fncls__3214d; tmp1 = fncls__3214d } else { tmp1 = fncls__3214 }; walk__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3215, tmp1, nil); var tmp2 any; var root_3216 any =





	A_arbace_cpp_run_A_const_118.GetRawRoot__O(); var linked_3217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3216, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3218 lang.IFn; if linked_3217 == nil { ifn_3218 = lang.IFn_Cast(root_3216) } else { ifn_3218 = nil }; var arg_3219 any = walk__2; var arg_3220 any = forms__0; if linked_3217 == nil { tmp2 = ifn_3218.Invoke_O_O__O(arg_3219, arg_3220) } else { tmp2 = linked_3217.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3216, arg_3219, arg_3220) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp2)).Ref() }
//line :391:1
func A_arbace_cpp_run_uses_atomic_generic_QMARK__walk__97000528_A_New() *A_arbace_cpp_run_uses_atomic_generic_QMARK__walk__97000528_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_uses_atomic_generic_QMARK__walk__97000528_A{}; t.Ctor(); return t }
//line :391:1
func (t *A_arbace_cpp_run_uses_atomic_generic_QMARK__walk__97000528_A) Ctor() {}
//line :391:1
func (t *A_arbace_cpp_run_uses_atomic_generic_QMARK__walk__97000528_A) Invoke_O_O__O(self, x__1 any) any { var or__1927000174__auto____2 any; var and__1927000168__auto____2 any; var root_3193 any = A_arbace_cpp_run_A_const_119.GetRawRoot__O(); var linked_3194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3193, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3195 lang.IFn; if linked_3194 == nil { ifn_3195 = lang.IFn_Cast(root_3193) } else { ifn_3195 = nil }; var arg_3196 any = x__1; if linked_3194 == nil { and__1927000168__auto____2 = ifn_3195.Invoke_O__O(arg_3196) } else { and__1927000168__auto____2 = linked_3194.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3193, arg_3196) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_189); var tmp2 any; var root_3210 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_3211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3210, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3212 lang.IFn; if linked_3211 == nil { ifn_3212 = lang.IFn_Cast(root_3210) } else { ifn_3212 = nil }; var arg_3213 any = x__1; if linked_3211 == nil { tmp2 = ifn_3212.Invoke_O__O(arg_3213) } else { tmp2 = linked_3211.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3210, arg_3213) }; or__1927000174__auto____2 = tmp1.Invoke_O__O(tmp2) } else { or__1927000174__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_3197 any = A_arbace_cpp_run_A_const_119.GetRawRoot__O(); var linked_3198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3197, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_3199 lang.IFn
														if linked_3198 == nil { ifn_3199 = lang.IFn_Cast(root_3197) } else { ifn_3199 = nil }; var arg_3200 any = x__1; if linked_3198 == nil { or__1927000174__auto____3 = ifn_3199.Invoke_O__O(arg_3200) } else { or__1927000174__auto____3 = linked_3198.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_3197, arg_3200) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else { var root_3201 any = A_arbace_cpp_run_A_const_123.GetRawRoot__O(); var linked_3202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3201, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_3203 lang.IFn; if linked_3202 == nil { ifn_3203 = lang.IFn_Cast(root_3201) } else { ifn_3203 = nil }; var arg_3204 any = x__1; if linked_3202 == nil { and__1927000168__auto____3 = ifn_3203.Invoke_O__O(arg_3204) } else { and__1927000168__auto____3 = linked_3202.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_3201, arg_3204) } }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_3205 any = A_arbace_cpp_run_A_const_118.GetRawRoot__O(); var linked_3206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3205, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3207 lang.IFn; if linked_3206 == nil { ifn_3207 = lang.IFn_Cast(root_3205) } else { ifn_3207 = nil }; var arg_3208 any = self; var arg_3209 any = x__1; if linked_3206 == nil { return ifn_3207.Invoke_O_O__O(arg_3208, arg_3209) } else { return linked_3206.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3205, arg_3208, arg_3209) } } else { return and__1927000168__auto____3 } } }


func A_arbace_cpp_run_va_arg_fns_A_New() *A_arbace_cpp_run_va_arg_fns_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_va_arg_fns_A{}; t.Ctor(); return t }
//line :395:1
func (t *A_arbace_cpp_run_va_arg_fns_A) Ctor() {}
//line :395:1
func (t *A_arbace_cpp_run_va_arg_fns_A) Invoke_O_O__O(self, ll__0 any) any { var out__2 any = jrt.LinkedHashSet_New(); var ls__3 any; var root_3225 any = A_arbace_cpp_run_A_const_45.GetRawRoot__O(); var linked_3226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3225, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_3227 lang.IFn; if





	linked_3226 == nil { ifn_3227 = lang.IFn_Cast(root_3225) } else { ifn_3227 = nil }; var arg_3228 any = lang.IFn_Cast(A_arbace_cpp_run_A_const_46.GetRawRoot__O()).Invoke_O__O(ll__0); if linked_3226 == nil { ls__3 = ifn_3227.Invoke_O__O(arg_3228) } else { ls__3 = linked_3226.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_3225, arg_3228) }; var cur__4 any; L1:
//line :395:1
	for { var temp__1927000414__auto____5 any; var root_3233 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_3234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3233, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3235 lang.IFn






		if linked_3234 == nil { ifn_3235 = lang.IFn_Cast(root_3233) } else { ifn_3235 = nil }; var arg_3236 any = ls__3; if linked_3234 == nil { temp__1927000414__auto____5 = ifn_3235.Invoke_O__O(arg_3236) } else { temp__1927000414__auto____5 = linked_3234.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3233, arg_3236) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var l__6 any = temp__1927000414__auto____5; var cur__7 any; var tmp1 any; var root_3237 any = A_arbace_cpp_run_A_const_66.GetRawRoot__O(); var linked_3238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3237, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_3239 lang.IFn
			if linked_3238 == nil { ifn_3239 = lang.IFn_Cast(root_3237) } else { ifn_3239 = nil }; var arg_3240 any = l__6; var arg_3241 any = Lit_215; if linked_3238 == nil { tmp1 = ifn_3239.Invoke_O_O__O(arg_3240, arg_3241) } else { tmp1 = linked_3238.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_3237, arg_3240, arg_3241) }; if jrt.J2g_Truth(tmp1) {
				var root_3242 any = A_arbace_cpp_run_A_const_75.GetRawRoot__O(); var linked_3243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3242, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3244 lang.IFn; if linked_3243 == nil { ifn_3244 = lang.IFn_Cast(root_3242) } else { ifn_3244 = nil }; var arg_3245 any; var root_3246 any = A_arbace_cpp_run_A_const_190.GetRawRoot__O(); var linked_3247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3246, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_3248 lang.IFn; if linked_3247 == nil { ifn_3248 = lang.IFn_Cast(root_3246) } else { ifn_3248 = nil }; var arg_3249 any = A_arbace_cpp_run_A_const_191; var arg_3250 any = l__6; if linked_3247 == nil { arg_3245 = ifn_3248.Invoke_O_O__O(arg_3249, arg_3250) } else { arg_3245 = linked_3247.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_3246, arg_3249, arg_3250) }; if linked_3243 == nil { cur__7 = ifn_3244.Invoke_O__O(arg_3245) } else { cur__7 = linked_3243.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3242, arg_3245) } } else {
//line :403:1
					cur__7 = cur__4
				}

			var tmp2 any; var and__1927000168__auto____8 any = cur__7; if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_3251 any = A_arbace_cpp_run_A_const_192.GetRawRoot__O(); var linked_3252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3251, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_3253 lang.IFn; if linked_3252 == nil { ifn_3253 = lang.IFn_Cast(root_3251) } else { ifn_3253 = nil }; var arg_3254 any = l__6; var arg_3255 any = Lit_216; if linked_3252 == nil { and__1927000168__auto____9 = ifn_3253.Invoke_O_O__O(arg_3254, arg_3255) } else { and__1927000168__auto____9 = linked_3252.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_3251, arg_3254, arg_3255) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_3256 any = A_arbace_cpp_run_A_const_192.GetRawRoot__O(); var linked_3257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3256, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_3258 lang.IFn; if linked_3257 == nil { ifn_3258 = lang.IFn_Cast(root_3256) } else { ifn_3258 = nil }; var arg_3259 any = l__6; var arg_3260 any = Lit_217; if linked_3257 == nil { tmp2 = ifn_3258.Invoke_O_O__O(arg_3259, arg_3260) } else { tmp2 = linked_3257.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_3256, arg_3259, arg_3260) } } else { tmp2 = and__1927000168__auto____9 } } else { tmp2 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp2) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.HashSet_Cast(out__2).Add_O__Z(cur__7)) }
			var tmp3 any; var root_3261 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_3262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3261, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3263 lang.IFn; if linked_3262 == nil { ifn_3263 = lang.IFn_Cast(root_3261) } else { ifn_3263 = nil }; var arg_3264 any = ls__3; if linked_3262 == nil { tmp3 = ifn_3263.Invoke_O__O(arg_3264) } else { tmp3 = linked_3262.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3261, arg_3264) }; ls__3, cur__4 = tmp3, cur__7; continue L1 }
//line :395:1
		break L1 }; var root_3221 any =












	A_arbace_cpp_run_A_const_62.GetRawRoot__O(); var linked_3222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3221, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3223 lang.IFn; if linked_3222 == nil { ifn_3223 = lang.IFn_Cast(root_3221) } else { ifn_3223 = nil }; var arg_3224 any = out__2; if linked_3222 == nil { return ifn_3223.Invoke_O__O(arg_3224) } else { return linked_3222.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3221, arg_3224) } }

func A_arbace_cpp_run_read_program_A_New() *A_arbace_cpp_run_read_program_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_read_program_A{}; t.Ctor(); return t }
//line :410:1
func (t *A_arbace_cpp_run_read_program_A) Ctor() {}
//line :410:1
func (t *A_arbace_cpp_run_read_program_A) Invoke_O_O_O__O(self, h__0, f__1 any) any { var fc__3 any; var root_3265 any = A_arbace_cpp_run_A_const_47.GetRawRoot__O(); var linked_3266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3265, aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A_fn_class); var ifn_3267 lang.IFn; if



	linked_3266 == nil { ifn_3267 = lang.IFn_Cast(root_3265) } else { ifn_3267 = nil }; var arg_3268 any = A_arbace_cpp_run_A_const_48.GetRawRoot__O(); var arg_3269 any = Lit_77; if linked_3266 == nil { fc__3 = ifn_3267.Invoke_O_O__O(arg_3268, arg_3269) } else { fc__3 = linked_3266.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A).Invoke_O_O_O__O(root_3265, arg_3268, arg_3269) }; var rd__4 any; var root_3270 any = /*line :410:1*/A_arbace_cpp_run_A_const_49.GetRawRoot__O(); var linked_3271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3270, aot_arbace_repr_c.A_arbace_repr_c_read_c_A_fn_class); var ifn_3272 lang.IFn; if




	linked_3271 == nil { ifn_3272 = lang.IFn_Cast(root_3270) } else { ifn_3272 = nil }; var arg_3273 any; var root_3277 any = A_arbace_cpp_run_A_const_50.GetRawRoot__O(); var linked_3278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3277, aot_arbace_repr_c_host.A_arbace_repr_c_host_config_A_fn_class); var ifn_3279 lang.IFn; if linked_3278 == nil { ifn_3279 = lang.IFn_Cast(root_3277) } else { ifn_3279 = nil }; var arg_3280 any = h__0; var arg_3281 any = fc__3; var arg_3282 any = jrt.File_Cast(f__1).GetParent__String().Ref(); if linked_3278 == nil { arg_3273 = ifn_3279.Invoke_O_O_O__O(arg_3280, arg_3281, arg_3282) } else { arg_3273 = linked_3278.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_config_A).Invoke_O_O_O_O__O(root_3277, arg_3280, arg_3281, arg_3282) }; var arg_3274 any = fc__3; var arg_3275 any = jrt.File_Cast(f__1).GetName__String().Ref(); var arg_3276 any = jrt.Boolean_FALSE.Ref(); if linked_3271 == nil { rd__4 = ifn_3272.Invoke_O_O_O_O__O(arg_3273, arg_3274, arg_3275, arg_3276) } else { rd__4 = linked_3271.(*aot_arbace_repr_c.A_arbace_repr_c_read_c_A).Invoke_O_O_O_O_O__O(root_3270, arg_3273, arg_3274, arg_3275, arg_3276) }; if
	jrt.J2g_Truth(A_arbace_cpp_run_A_const_51.Invoke_O__O(rd__4)) { var tmp1 any = A_arbace_cpp_run_A_const_193; var tmp2 any = A_arbace_cpp_run_A_const_194; var tmp3 any = A_arbace_cpp_run_A_const_57; var tmp4 any; var root_3283 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_3284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3283, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_3285 lang.IFn
		if linked_3284 == nil { ifn_3285 = lang.IFn_Cast(root_3283) } else { ifn_3285 = nil }; var arg_3286 any = Lit_80; var arg_3287 any; var root_3288 any = A_arbace_cpp_run_A_const_53.GetRawRoot__O(); var linked_3289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3288, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_3290 lang.IFn; if linked_3289 == nil { ifn_3290 = lang.IFn_Cast(root_3288) } else { ifn_3290 = nil }; var arg_3291 any = A_arbace_cpp_run_A_const_195; var arg_3292 any = A_arbace_cpp_run_A_const_51.Invoke_O__O(rd__4); if linked_3289 == nil { arg_3287 = ifn_3290.Invoke_O_O__O(arg_3291, arg_3292) } else { arg_3287 = linked_3289.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_3288, arg_3291, arg_3292) }; if linked_3284 == nil { tmp4 = ifn_3285.Invoke_O_O__O(arg_3286, arg_3287) } else { tmp4 = linked_3284.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_3283, arg_3286, arg_3287) }
//line :416:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4)) } else { if jrt.J2g_Truth(A_arbace_cpp_run_A_const_55.Invoke_O__O(rd__4)) { var tmp5 any = A_arbace_cpp_run_A_const_193; var tmp6 any = A_arbace_cpp_run_A_const_196; var tmp7 any = A_arbace_cpp_run_A_const_57; var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil); var tmp9 any; var root_3293 any = A_arbace_cpp_run_A_const_56.GetRawRoot__O(); var linked_3294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3293, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_3295 lang.IFn

			if linked_3294 == nil { ifn_3295 = lang.IFn_Cast(root_3293) } else { ifn_3295 = nil }; var arg_3296 any = A_arbace_cpp_run_A_const_55.Invoke_O__O(rd__4); if linked_3294 == nil { tmp9 = ifn_3295.Invoke_O__O(arg_3296) } else { tmp9 = linked_3294.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_3293, arg_3296) }
//line :416:1
			return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, A_arbace_cpp_run_A_const_57.Invoke_O__O(rd__4))).Ref())) } else { if A_arbace_cpp_run_A_const_58 != nil { var u__5 any; var root_3297 any = A_arbace_cpp_run_A_const_142.GetRawRoot__O(); var linked_3298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3297, aot_arbace_c_run.A_arbace_c_run_check_read_A_fn_class); var ifn_3299 lang.IFn


				if linked_3298 == nil { ifn_3299 = lang.IFn_Cast(root_3297) } else { ifn_3299 = nil }; var arg_3300 any = h__0; var arg_3301 any = fc__3; var arg_3302 any; var root_3303 any = A_arbace_cpp_run_A_const_141.GetRawRoot__O(); var linked_3304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3303, A_arbace_cpp_run_with_ctors_A_fn_class); var ifn_3305 lang.IFn; if linked_3304 == nil { ifn_3305 = lang.IFn_Cast(root_3303) } else { ifn_3305 = nil }; var arg_3306 any = rd__4; var arg_3307 any = Lit_211; if linked_3304 == nil { arg_3302 = ifn_3305.Invoke_O_O__O(arg_3306, arg_3307) } else { arg_3302 = linked_3304.(*A_arbace_cpp_run_with_ctors_A).Invoke_O_O_O__O(root_3303, arg_3306, arg_3307) }; if linked_3298 == nil { u__5 = ifn_3299.Invoke_O_O_O__O(arg_3300, arg_3301, arg_3302) } else { u__5 = linked_3298.(*aot_arbace_c_run.A_arbace_c_run_check_read_A).Invoke_O_O_O_O__O(root_3297, arg_3300, arg_3301, arg_3302) }
				var tmp10 any; var root_3308 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_3309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3308, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3310 lang.IFn; if linked_3309 == nil { ifn_3310 = lang.IFn_Cast(root_3308) } else { ifn_3310 = nil }; var arg_3311 any = A_arbace_cpp_run_A_const_144.Invoke_O__O(u__5); if linked_3309 == nil { tmp10 = ifn_3310.Invoke_O__O(arg_3311) } else { tmp10 = linked_3309.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3308, arg_3311) }; if jrt.J2g_Truth(tmp10) {
					var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_138.GetRawRoot__O()); var tmp12 any = A_arbace_cpp_run_A_const_193; var tmp13 any = A_arbace_cpp_run_A_const_197; var tmp14 any = A_arbace_cpp_run_A_const_57; var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp16 any; var root_3320 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_3321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3320, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_3322 lang.IFn; if linked_3321 == nil { ifn_3322 = lang.IFn_Cast(root_3320) } else { ifn_3322 = nil }; var arg_3323 any = Lit_80; var arg_3324 any; var root_3325 any = A_arbace_cpp_run_A_const_53.GetRawRoot__O(); var linked_3326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3325, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_3327 lang.IFn; if linked_3326 == nil { ifn_3327 = lang.IFn_Cast(root_3325) } else { ifn_3327 = nil }; var arg_3328 any = A_arbace_cpp_run_A_const_195; var arg_3329 any = A_arbace_cpp_run_A_const_144.Invoke_O__O(u__5); if linked_3326 == nil { arg_3324 = ifn_3327.Invoke_O_O__O(arg_3328, arg_3329) } else { arg_3324 = linked_3326.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_3325, arg_3328, arg_3329) }; if linked_3321 == nil { tmp16 = ifn_3322.Invoke_O_O__O(arg_3323, arg_3324) } else { tmp16 = linked_3321.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_3320, arg_3323, arg_3324) }; var tmp17 any = tmp16; var tmp18 *jrt.String; var tmp19 any; var root_3330 any = A_arbace_cpp_run_A_const_198.GetRawRoot__O(); var linked_3331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3330, A_arbace_cpp_run_uses_atomic_generic_QMARK__A_fn_class); var ifn_3332 lang.IFn
					if linked_3331 == nil { ifn_3332 = lang.IFn_Cast(root_3330) } else { ifn_3332 = nil }; var arg_3333 any = A_arbace_cpp_run_A_const_70.Invoke_O__O(rd__4); if linked_3331 == nil { tmp19 = ifn_3332.Invoke_O__O(arg_3333) } else { tmp19 = linked_3331.(*A_arbace_cpp_run_uses_atomic_generic_QMARK__A).Invoke_O_O__O(root_3330, arg_3333) }; if jrt.J2g_Truth(tmp19) { tmp18 = Lit_212 } else { tmp18 = nil }
//line :421:1
					var tmp20 any = tmp18.Ref(); var tmp21 *jrt.String; var tmp22 any; var root_3334 any = A_arbace_cpp_run_A_const_146.GetRawRoot__O(); var linked_3335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3334, aot_arbace_c_run.A_arbace_c_run_uses_long_double_QMARK__A_fn_class); var ifn_3336 lang.IFn

					if linked_3335 == nil { ifn_3336 = lang.IFn_Cast(root_3334) } else { ifn_3336 = nil }; var arg_3337 any = A_arbace_cpp_run_A_const_70.Invoke_O__O(rd__4); if linked_3335 == nil { tmp22 = ifn_3336.Invoke_O__O(arg_3337) } else { tmp22 = linked_3335.(*aot_arbace_c_run.A_arbace_c_run_uses_long_double_QMARK__A).Invoke_O_O__O(root_3334, arg_3337) }; if jrt.J2g_Truth(tmp22) { tmp21 = Lit_81 } else { tmp21 = nil }
//line :421:1
					return tmp11.Invoke_O_O_O_O_O__O(u__5, tmp12, tmp13, tmp14, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, tmp17, tmp20, tmp21.Ref())).Ref()) } else {


						var root_3338 any = A_arbace_cpp_run_A_const_138.GetRawRoot__O(); var linked_3339 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3338, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3340 lang.IFn; if linked_3339 == nil { ifn_3340 = lang.IFn_Cast(root_3338) } else { ifn_3340 = nil }; var arg_3341 any = u__5; var arg_3342 any = A_arbace_cpp_run_A_const_193; var arg_3343 any = A_arbace_cpp_run_A_const_199; if linked_3339 == nil { return ifn_3340.Invoke_O_O_O__O(arg_3341, arg_3342, arg_3343) } else { return linked_3339.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3338, arg_3341, arg_3342, arg_3343) } } } else {
//line :416:1
							return nil } } } }









func A_arbace_cpp_run_lower_ll_A_New() *A_arbace_cpp_run_lower_ll_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_lower_ll_A{}; t.Ctor(); return t }
//line :426:1
func (t *A_arbace_cpp_run_lower_ll_A) Ctor() {}
//line :426:1
func (t *A_arbace_cpp_run_lower_ll_A) Invoke_O_O__O(self, ll__0 any) any { var c__2 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_60), jrt.RefArrayOf(jrt.Object_class, jrt.File_New_String(jrt.String_Cast(ll__0)).GetParent__String().Ref(), nil)).Ref(); var r__3 any; var root_3344 any = A_arbace_cpp_run_A_const_200.GetRawRoot__O(); var linked_3345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3344, aot_arbace_cpp_lower.A_arbace_cpp_lower_lower_file_A_fn_class); var ifn_3346 lang.IFn; if



	linked_3345 == nil { ifn_3346 = lang.IFn_Cast(root_3344) } else { ifn_3346 = nil }; var arg_3347 any = ll__0; var arg_3348 any = Lit_161; if linked_3345 == nil { r__3 = ifn_3346.Invoke_O_O__O(arg_3347, arg_3348) } else { r__3 = linked_3345.(*aot_arbace_cpp_lower.A_arbace_cpp_lower_lower_file_A).Invoke_O_O_O__O(root_3344, arg_3347, arg_3348) }; if
	jrt.J2g_Truth(A_arbace_cpp_run_A_const_55.Invoke_O__O(r__3)) { var tmp1 any; var root_3349 any = A_arbace_cpp_run_A_const_56.GetRawRoot__O(); var linked_3350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3349, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_3351 lang.IFn
		if linked_3350 == nil { ifn_3351 = lang.IFn_Cast(root_3349) } else { ifn_3351 = nil }; var arg_3352 any = A_arbace_cpp_run_A_const_55.Invoke_O__O(r__3); if linked_3350 == nil { tmp1 = ifn_3351.Invoke_O__O(arg_3352) } else { tmp1 = linked_3350.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_3349, arg_3352) }
//line :431:1
		return lang.Tuple_Create_O_O_O__IPersistentVector(Lit_162, tmp1, A_arbace_cpp_run_A_const_57.Invoke_O__O(r__3)) } else {

			var root_3353 any = A_arbace_cpp_run_A_const_201.GetRawRoot__O(); var linked_3354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3353, aot_arbace_repr_llvm.A_arbace_repr_llvm_spit_latin1_A_fn_class); var ifn_3355 lang.IFn; if linked_3354 == nil { ifn_3355 = lang.IFn_Cast(root_3353) } else { ifn_3355 = nil }; var arg_3356 any = c__2; var arg_3357 any = A_arbace_cpp_run_A_const_202.Invoke_O__O(r__3); if linked_3354 == nil { ifn_3355.Invoke_O_O__O(arg_3356, arg_3357) } else { linked_3354.(*aot_arbace_repr_llvm.A_arbace_repr_llvm_spit_latin1_A).Invoke_O_O_O__O(root_3353, arg_3356, arg_3357) }
//line :431:1
			return nil } }



func A_arbace_cpp_run_build_one_A_New() *A_arbace_cpp_run_build_one_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_one_A{}; t.Ctor(); return t }
//line :435:1
func (t *A_arbace_cpp_run_build_one_A) Ctor() {}
//line :435:1
func (t *A_arbace_cpp_run_build_one_A) Invoke_O_O_O_O__O(self, h__0, libs_of__1, path__2 any) any { var ll__4 any = path__2; var t0__5 int64 = jrt.System_NanoTime__J(); var refused__6 any; var tmp1 any; var root_3358 any = A_arbace_cpp_run_A_const_203.GetRawRoot__O(); var linked_3359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3358, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_3360 lang.IFn; if





	linked_3359 == nil { ifn_3360 = lang.IFn_Cast(root_3358) } else { ifn_3360 = nil }; var arg_3361 any = path__2; var arg_3362 any = Lit_59; if linked_3359 == nil { tmp1 = ifn_3360.Invoke_O_O__O(arg_3361, arg_3362) } else { tmp1 = linked_3359.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_3358, arg_3361, arg_3362) }; if jrt.J2g_Truth(tmp1) { var root_3363 any = A_arbace_cpp_run_A_const_204.GetRawRoot__O(); var linked_3364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3363, A_arbace_cpp_run_lower_ll_A_fn_class); var ifn_3365 lang.IFn; if linked_3364 == nil { ifn_3365 = lang.IFn_Cast(root_3363) } else { ifn_3365 = nil }; var arg_3366 any = path__2; if linked_3364 == nil { refused__6 = ifn_3365.Invoke_O__O(arg_3366) } else { refused__6 = linked_3364.(*A_arbace_cpp_run_lower_ll_A).Invoke_O_O__O(root_3363, arg_3366) } } else { refused__6 = nil }; var ls__7 any; var root_3367 any = /*line :435:1*/A_arbace_cpp_run_A_const_205.GetRawRoot__O(); var linked_3368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3367, A_arbace_cpp_run_secs_A_fn_class); var ifn_3369 lang.IFn; if






	linked_3368 == nil { ifn_3369 = lang.IFn_Cast(root_3367) } else { ifn_3369 = nil }; var arg_3370 any = jrt.Long_ValueOf_J__Long_NoInit(t0__5).Ref(); if linked_3368 == nil { ls__7 = ifn_3369.Invoke_O__O(arg_3370) } else { ls__7 = linked_3368.(*A_arbace_cpp_run_secs_A).Invoke_O_O__O(root_3367, arg_3370) }; var t0__8 int64 = /*line :435:1*/jrt.System_NanoTime__J(); var path__9 any; var tmp2 any; var root_3371 any = A_arbace_cpp_run_A_const_203.GetRawRoot__O(); var linked_3372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3371, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_3373 lang.IFn; if








	linked_3372 == nil { ifn_3373 = lang.IFn_Cast(root_3371) } else { ifn_3373 = nil }; var arg_3374 any = path__2; var arg_3375 any = Lit_59; if linked_3372 == nil { tmp2 = ifn_3373.Invoke_O_O__O(arg_3374, arg_3375) } else { tmp2 = linked_3372.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_3371, arg_3374, arg_3375) }; if jrt.J2g_Truth(tmp2) { path__9 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_60), jrt.RefArrayOf(jrt.Object_class, jrt.File_New_String(jrt.String_Cast(path__2)).GetParent__String().Ref(), nil)).Ref() } else { path__9 = path__2 }; var f__10 any = /*line :435:1*/jrt.File_New_String(jrt.String_Cast(path__9)); var u__11 any; if










	jrt.J2g_Truth(refused__6) { u__11 = nil } else { var root_3376 any = A_arbace_cpp_run_A_const_206.GetRawRoot__O(); var linked_3377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3376, A_arbace_cpp_run_read_program_A_fn_class); var ifn_3378 lang.IFn; if linked_3377 == nil { ifn_3378 = lang.IFn_Cast(root_3376) } else { ifn_3378 = nil }; var arg_3379 any = h__0; var arg_3380 any = f__10; if linked_3377 == nil { u__11 = ifn_3378.Invoke_O_O__O(arg_3379, arg_3380) } else { u__11 = linked_3377.(*A_arbace_cpp_run_read_program_A).Invoke_O_O_O__O(root_3376, arg_3379, arg_3380) } }; var secs__12 any; var fnbody__3386 any = /*line :435:1*/A_arbace_cpp_run_build_one_secs__97000534_A_New_O(ls__7); var tmp3 *jrt.Class; var fncls__3385 *jrt.Class = A_arbace_cpp_run_build_one_secs__97000534_A_fn_class; if











	fncls__3385 == nil { var fncls__3385d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__3386); A_arbace_cpp_run_build_one_secs__97000534_A_fn_class = fncls__3385d; tmp3 = fncls__3385d } else { tmp3 = fncls__3385 }; secs__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3386, tmp3, nil); if
	jrt.J2g_Truth(refused__6) {
		return lang.IFn_Cast(A_arbace_cpp_run_A_const_15.GetRawRoot__O()).Invoke_O_O_O_O__O(refused__6, Lit_62, ls__7, nil) } else {
//line :448:1
			var tmp4 any; var root_3394 any = A_arbace_cpp_run_A_const_107.GetRawRoot__O(); var linked_3395 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3394, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_3396 lang.IFn

			if linked_3395 == nil { ifn_3396 = lang.IFn_Cast(root_3394) } else { ifn_3396 = nil }; var arg_3397 any = A_arbace_cpp_run_A_const_199; var arg_3398 any = A_arbace_cpp_run_A_const_193.Invoke_O__O(u__11); if linked_3395 == nil { tmp4 = ifn_3396.Invoke_O_O__O(arg_3397, arg_3398) } else { tmp4 = linked_3395.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_3394, arg_3397, arg_3398) }
//line :448:1
			if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_3443 any = A_arbace_cpp_run_A_const_56.GetRawRoot__O(); var linked_3444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3443, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_3445 lang.IFn

				if linked_3444 == nil { ifn_3445 = lang.IFn_Cast(root_3443) } else { ifn_3445 = nil }; var arg_3446 any = A_arbace_cpp_run_A_const_193.Invoke_O__O(u__11); if linked_3444 == nil { tmp5 = ifn_3445.Invoke_O__O(arg_3446) } else { tmp5 = linked_3444.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_3443, arg_3446) }
//line :448:1
				return lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp5, Lit_62, A_arbace_cpp_run_A_const_57.Invoke_O__O(u__11), Lit_62, lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(t0__8).Ref()), nil) } else { if A_arbace_cpp_run_A_const_58 != nil { var va__13 any; var tmp6 any; var root_3399 any = A_arbace_cpp_run_A_const_203.GetRawRoot__O(); var linked_3400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3399, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_3401 lang.IFn



					if linked_3400 == nil { ifn_3401 = lang.IFn_Cast(root_3399) } else { ifn_3401 = nil }; var arg_3402 any = ll__4; var arg_3403 any = Lit_59; if linked_3400 == nil { tmp6 = ifn_3401.Invoke_O_O__O(arg_3402, arg_3403) } else { tmp6 = linked_3400.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_3399, arg_3402, arg_3403) }; if jrt.J2g_Truth(tmp6) { var root_3404 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_3405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3404, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3406 lang.IFn; if linked_3405 == nil { ifn_3406 = lang.IFn_Cast(root_3404) } else { ifn_3406 = nil }; var arg_3407 any; var root_3408 any = A_arbace_cpp_run_A_const_207.GetRawRoot__O(); var linked_3409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3408, A_arbace_cpp_run_va_arg_fns_A_fn_class); var ifn_3410 lang.IFn; if linked_3409 == nil { ifn_3410 = lang.IFn_Cast(root_3408) } else { ifn_3410 = nil }; var arg_3411 any = ll__4; if linked_3409 == nil { arg_3407 = ifn_3410.Invoke_O__O(arg_3411) } else { arg_3407 = linked_3409.(*A_arbace_cpp_run_va_arg_fns_A).Invoke_O_O__O(root_3408, arg_3411) }; if linked_3405 == nil { va__13 = ifn_3406.Invoke_O__O(arg_3407) } else { va__13 = linked_3405.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3404, arg_3407) } } else { va__13 = nil }
//line :448:1
					var ld__14 any; var root_3412 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_3413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3412, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_3414 lang.IFn





					if linked_3413 == nil { ifn_3414 = lang.IFn_Cast(root_3412) } else { ifn_3414 = nil }; var arg_3415 any = Lit_20; var arg_3416 any; var root_3417 any = A_arbace_cpp_run_A_const_43.GetRawRoot__O(); var linked_3418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3417, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3419 lang.IFn; if linked_3418 == nil { ifn_3419 = lang.IFn_Cast(root_3417) } else { ifn_3419 = nil }; var arg_3420 any = A_arbace_cpp_run_A_const_208.GetRawRoot__O(); var arg_3421 any; var tmp7 *jrt.String; var tmp8 any; var root_3422 any = A_arbace_cpp_run_A_const_146.GetRawRoot__O(); var linked_3423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3422, aot_arbace_c_run.A_arbace_c_run_uses_long_double_QMARK__A_fn_class); var ifn_3424 lang.IFn; if linked_3423 == nil { ifn_3424 = lang.IFn_Cast(root_3422) } else { ifn_3424 = nil }; var tmp9 *lang.Keyword = A_arbace_cpp_run_A_const_70; var arg_3425 any = tmp9.Invoke_O__O(A_arbace_cpp_run_A_const_156.Invoke_O__O(u__11)); if linked_3423 == nil { tmp8 = ifn_3424.Invoke_O__O(arg_3425) } else { tmp8 = linked_3423.(*aot_arbace_c_run.A_arbace_c_run_uses_long_double_QMARK__A).Invoke_O_O__O(root_3422, arg_3425) }; if jrt.J2g_Truth(tmp8) { tmp7 = Lit_63 } else { tmp7 = nil }; var tmp10 any = tmp7.Ref(); var tmp11 *jrt.String
					if jrt.J2g_Truth(va__13) { var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_64, nil); var tmp13 any; var root_3426 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_3427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3426, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_3428 lang.IFn; if linked_3427 == nil { ifn_3428 = lang.IFn_Cast(root_3426) } else { ifn_3428 = nil }; var arg_3429 any = Lit_65; var arg_3430 any = va__13; if linked_3427 == nil { tmp13 = ifn_3428.Invoke_O_O__O(arg_3429, arg_3430) } else { tmp13 = linked_3427.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_3426, arg_3429, arg_3430) }; tmp11 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, tmp13)) } else { tmp11 = nil }
//line :454:1
					arg_3421 = lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11.Ref()); if linked_3418 == nil { arg_3416 = ifn_3419.Invoke_O_O__O(arg_3420, arg_3421) } else { arg_3416 = linked_3418.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3417, arg_3420, arg_3421) }; if linked_3413 == nil { ld__14 = ifn_3414.Invoke_O_O__O(arg_3415, arg_3416) } else { ld__14 = linked_3413.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_3412, arg_3415, arg_3416) }
//line :448:1
					var r__15 any; var tmp14 *lang.Compiler_AOTFn; var fnbody__3442 any = A_arbace_cpp_run_build_one_fn__97000536_A_New_O_O_O(libs_of__1, h__0, u__11); var tmp15 *jrt.Class
					var fncls__3441 /*line :448:1*/*jrt.Class = A_arbace_cpp_run_build_one_fn__97000536_A_fn_class







					if fncls__3441 == nil { var fncls__3441d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, fnbody__3442); A_arbace_cpp_run_build_one_fn__97000536_A_fn_class = fncls__3441d; tmp15 = fncls__3441d } else { tmp15 = fncls__3441 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3442, tmp15, nil); r__15 = Up_Compiler_AOTFn_IFn(tmp14).Invoke__O()




					if jrt.J2g_Truth(A_arbace_cpp_run_A_const_209.Invoke_O__O(r__15)) { return lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(Lit_67, Lit_62, Lit_62, ld__14, lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(t0__8).Ref()), A_arbace_cpp_run_A_const_209.Invoke_O__O(r__15)) } else { var tmp16 any; var root_3447 any = A_arbace_cpp_run_A_const_56.GetRawRoot__O(); var linked_3448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3447, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_3449 lang.IFn

						if linked_3448 == nil { ifn_3449 = lang.IFn_Cast(root_3447) } else { ifn_3449 = nil }; var arg_3450 any = A_arbace_cpp_run_A_const_55.Invoke_O__O(r__15); if linked_3448 == nil { tmp16 = ifn_3449.Invoke_O__O(arg_3450) } else { tmp16 = linked_3448.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_3447, arg_3450) }
//line :461:1
						return lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(Lit_68, tmp16, A_arbace_cpp_run_A_const_57.Invoke_O__O(r__15), ld__14, lang.IFn_Cast(secs__12).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(t0__8).Ref()), nil) } } else {
//line :448:1
							return nil } } } }
//line :447:1
func A_arbace_cpp_run_build_one_secs__97000534_A_New_O(p0 any) *A_arbace_cpp_run_build_one_secs__97000534_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_one_secs__97000534_A{}; t.Ctor_O(p0); return t }
//line :447:1
func (t *A_arbace_cpp_run_build_one_secs__97000534_A) Ctor_O(c__ls any) { t.F_ls = c__ls }
//line :447:1
func (t *A_arbace_cpp_run_build_one_secs__97000534_A) Invoke_O_O__O(self, t__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_69, nil); var tmp2 any = t.F_ls; var tmp3 any; var root_3381 any = A_arbace_cpp_run_A_const_205.GetRawRoot__O(); var linked_3382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3381, A_arbace_cpp_run_secs_A_fn_class); var ifn_3383 lang.IFn; if linked_3382 == nil { ifn_3383 = lang.IFn_Cast(root_3381) } else { ifn_3383 = nil }; var arg_3384 any = t__1; if linked_3382 == nil { tmp3 = ifn_3383.Invoke_O__O(arg_3384) } else { tmp3 = linked_3382.(*A_arbace_cpp_run_secs_A).Invoke_O_O__O(root_3381, arg_3384) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, tmp3)).Ref() }








func A_arbace_cpp_run_build_one_fn__97000536_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_run_build_one_fn__97000536_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_build_one_fn__97000536_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :456:1
func (t *A_arbace_cpp_run_build_one_fn__97000536_A) Ctor_O_O_O(c__libs_of, c__h, c__u any) { t.F_libs_of = c__libs_of; t.F_h = c__h; t.F_u = c__u }
//line :456:1
func (t *A_arbace_cpp_run_build_one_fn__97000536_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any = A_arbace_cpp_run_A_const_209; var tmp3 any; var root_3431 any = A_arbace_cpp_run_A_const_210.GetRawRoot__O(); var linked_3432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3431, A_arbace_cpp_run_build_linked_A_fn_class); var ifn_3433 lang.IFn; if linked_3432 == nil { ifn_3433 = lang.IFn_Cast(root_3431) } else { ifn_3433 = nil }; var arg_3434 any; var t_ any = t.F_h; t.F_h = nil; arg_3434 = t_; var arg_3435 any; var tmp4 any; var t__2 any = t.F_libs_of; t.F_libs_of = nil; tmp4 = t__2; arg_3435 = lang.IFn_Cast(tmp4).Invoke__O(); var arg_3436 any; var tmp5 any; var t__3 any = t.F_u; t.F_u = nil; tmp5 = t__3; arg_3436 = lang.Tuple_Create_O__IPersistentVector(tmp5); if linked_3432 == nil { tmp3 = ifn_3433.Invoke_O_O_O__O(arg_3434, arg_3435, arg_3436) } else { tmp3 = linked_3432.(*A_arbace_cpp_run_build_linked_A).Invoke_O_O_O_O__O(root_3431, arg_3434, arg_3435, arg_3436) }; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)) }; return nil }(); if tmp6 != nil { if lang.ExceptionInfo_InstanceOf(tmp6) { var e__3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp6); var temp__1927000408__auto____4 any; var tmp7 *lang.Keyword = A_arbace_cpp_run_A_const_211; var tmp8 any; var root_3437 any = A_arbace_cpp_run_A_const_212.GetRawRoot__O(); var linked_3438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3437, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_3439 lang.IFn

	if linked_3438 == nil { ifn_3439 = lang.IFn_Cast(root_3437) } else { ifn_3439 = nil }; var arg_3440 any = e__3; if linked_3438 == nil { tmp8 = ifn_3439.Invoke_O__O(arg_3440) } else { tmp8 = linked_3438.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_3437, arg_3440) }; temp__1927000408__auto____4 = tmp7.Invoke_O__O(tmp8); if jrt.J2g_Truth(temp__1927000408__auto____4) { var c__5 any = temp__1927000408__auto____4; var tmp9 any = A_arbace_cpp_run_A_const_55; var tmp10 any = A_arbace_cpp_run_A_const_57; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, c__5, tmp10, e__3.GetMessage__String().Ref())) } else { panic(jrt.Thrown(e__3)) } } else {
//line :456:1
		panic(tmp6) } }; return tmp1 }








func A_arbace_cpp_run_work_list_A_New() *A_arbace_cpp_run_work_list_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_work_list_A{}; t.Ctor(); return t }
//line :465:1
func (t *A_arbace_cpp_run_work_list_A) Ctor() {}
//line :465:1
func (t *A_arbace_cpp_run_work_list_A) Invoke_O_O_O_O_O__O(self, list__0, threads__1, out__2, f__3 any) any { var lines__5 any; var root_3451 any = A_arbace_cpp_run_A_const_62.GetRawRoot__O(); var linked_3452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3451, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3453 lang.IFn; if


	linked_3452 == nil { ifn_3453 = lang.IFn_Cast(root_3451) } else { ifn_3453 = nil }; var arg_3454 any; var root_3455 any = A_arbace_cpp_run_A_const_43.GetRawRoot__O(); var linked_3456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3455, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3457 lang.IFn; if linked_3456 == nil { ifn_3457 = lang.IFn_Cast(root_3455) } else { ifn_3457 = nil }; var arg_3458 any = A_arbace_cpp_run_A_const_44.GetRawRoot__O(); var arg_3459 any; var root_3460 any = A_arbace_cpp_run_A_const_45.GetRawRoot__O(); var linked_3461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3460, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_3462 lang.IFn; if linked_3461 == nil { ifn_3462 = lang.IFn_Cast(root_3460) } else { ifn_3462 = nil }; var arg_3463 any = lang.IFn_Cast(A_arbace_cpp_run_A_const_46.GetRawRoot__O()).Invoke_O__O(list__0); if linked_3461 == nil { arg_3459 = ifn_3462.Invoke_O__O(arg_3463) } else { arg_3459 = linked_3461.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_3460, arg_3463) }; if linked_3456 == nil { arg_3454 = ifn_3457.Invoke_O_O__O(arg_3458, arg_3459) } else { arg_3454 = linked_3456.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3455, arg_3458, arg_3459) }; if linked_3452 == nil { lines__5 = ifn_3453.Invoke_O__O(arg_3454) } else { lines__5 = linked_3452.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3451, arg_3454) }; var q__6 any = /*line :465:1*/jrt.ConcurrentLinkedQueue_New_Collection(jrt.Collection_Cast(lines__5)); var res__7 any = jrt.ConcurrentHashMap_New(); var workers__8 any; var root_3468 any = A_arbace_cpp_run_A_const_82.GetRawRoot__O(); var linked_3469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3468, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_3470 lang.IFn; if





	linked_3469 == nil { ifn_3470 = lang.IFn_Cast(root_3468) } else { ifn_3470 = nil }; var arg_3471 any; var iter__1927001039__auto____8 any; var fnbody__3615 any = A_arbace_cpp_run_work_list_iter__97000539__97000543_A_New_O_O_O(f__3, q__6, res__7); var tmp1 *jrt.Class; var fncls__3614 *jrt.Class = A_arbace_cpp_run_work_list_iter__97000539__97000543_A_fn_class; if fncls__3614 == nil { var fncls__3614d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_218, false, fnbody__3615); A_arbace_cpp_run_work_list_iter__97000539__97000543_A_fn_class = fncls__3614d; tmp1 = fncls__3614d } else { tmp1 = fncls__3614 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3615, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp3 any; var root_3616 any = A_arbace_cpp_run_A_const_97.GetRawRoot__O(); var linked_3617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3616, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_3618 lang.IFn; if linked_3617 == nil { ifn_3618 = lang.IFn_Cast(root_3616) } else { ifn_3618 = nil }; var arg_3619 any = threads__1; if linked_3617 == nil { tmp3 = ifn_3618.Invoke_O__O(arg_3619) } else { tmp3 = linked_3617.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_3616, arg_3619) }; arg_3471 = tmp2.Invoke_O__O(tmp3); if linked_3469 == nil { workers__8 = ifn_3470.Invoke_O__O(arg_3471) } else { workers__8 = linked_3469.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_3468, arg_3471) }; var seq_97000557__9 any; var root_3638 any = /*line :465:1*/A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_3639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3638, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3640 lang.IFn; if













	linked_3639 == nil { ifn_3640 = lang.IFn_Cast(root_3638) } else { ifn_3640 = nil }; var arg_3641 any = workers__8; if linked_3639 == nil { seq_97000557__9 = ifn_3640.Invoke_O__O(arg_3641) } else { seq_97000557__9 = linked_3639.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3638, arg_3641) }; var chunk_97000558__10 any; var count_97000559__11 int64 = 0; var i_97000560__12 int64 = 0; L1:
//line :465:1
	for {













		if lang.Numbers_Lt_J_J__Z_NoInit(i_97000560__12, count_97000559__11) { var w__13 any = lang.Indexed_Cast(chunk_97000558__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000560__12)); var root_3658 any = A_arbace_cpp_run_A_const_13.GetRawRoot__O(); var linked_3659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3658, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3660 lang.IFn; if linked_3659 == nil { ifn_3660 = lang.IFn_Cast(root_3658) } else { ifn_3660 = nil }; var arg_3661 any = w__13; if linked_3659 == nil { ifn_3660.Invoke_O__O(arg_3661) } else { linked_3659.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3658, arg_3661) }; seq_97000557__9, chunk_97000558__10, count_97000559__11, i_97000560__12 = seq_97000557__9, chunk_97000558__10, count_97000559__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000560__12); continue L1 } else { var temp__1927000414__auto____13 any; var root_3642 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_3643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3642, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3644 lang.IFn; if linked_3643 == nil { ifn_3644 = lang.IFn_Cast(root_3642) } else { ifn_3644 = nil }; var arg_3645 any = seq_97000557__9; if linked_3643 == nil { temp__1927000414__auto____13 = ifn_3644.Invoke_O__O(arg_3645) } else { temp__1927000414__auto____13 = linked_3643.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3642, arg_3645) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_97000557__14 any = temp__1927000414__auto____13; var tmp4 any; var root_3646 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_3647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3646, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3648 lang.IFn; if linked_3647 == nil { ifn_3648 = lang.IFn_Cast(root_3646) } else { ifn_3648 = nil }; var arg_3649 any = seq_97000557__14; if linked_3647 == nil { tmp4 = ifn_3648.Invoke_O__O(arg_3649) } else { tmp4 = linked_3647.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3646, arg_3649) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____15 any; var root_3650 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_3651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3650, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3652 lang.IFn; if linked_3651 == nil { ifn_3652 = lang.IFn_Cast(root_3650) } else { ifn_3652 = nil }; var arg_3653 any = seq_97000557__14; if linked_3651 == nil { c__1927000678__auto____15 = ifn_3652.Invoke_O__O(arg_3653) } else { c__1927000678__auto____15 = linked_3651.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3650, arg_3653) }; var tmp5 any; var root_3662 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_3663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3662, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3664 lang.IFn; if linked_3663 == nil { ifn_3664 = lang.IFn_Cast(root_3662) } else { ifn_3664 = nil }; var arg_3665 any = seq_97000557__14; if linked_3663 == nil { tmp5 = ifn_3664.Invoke_O__O(arg_3665) } else { tmp5 = linked_3663.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3662, arg_3665) }; seq_97000557__9, chunk_97000558__10, count_97000559__11, i_97000560__12 = tmp5, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var w__15 any; var root_3654 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_3655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3654, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3656 lang.IFn; if linked_3655 == nil { ifn_3656 = lang.IFn_Cast(root_3654) } else { ifn_3656 = nil }; var arg_3657 any = seq_97000557__14; if linked_3655 == nil { w__15 = ifn_3656.Invoke_O__O(arg_3657) } else { w__15 = linked_3655.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3654, arg_3657) }; var root_3666 any = A_arbace_cpp_run_A_const_13.GetRawRoot__O(); var linked_3667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3666, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3668 lang.IFn; if linked_3667 == nil { ifn_3668 = lang.IFn_Cast(root_3666) } else { ifn_3668 = nil }; var arg_3669 any = w__15; if linked_3667 == nil { ifn_3668.Invoke_O__O(arg_3669) } else { linked_3667.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3666, arg_3669) }; var tmp6 any; var root_3670 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_3671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3670, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3672 lang.IFn; if linked_3671 == nil { ifn_3672 = lang.IFn_Cast(root_3670) } else { ifn_3672 = nil }; var arg_3673 any = seq_97000557__14; if linked_3671 == nil { tmp6 = ifn_3672.Invoke_O__O(arg_3673) } else { tmp6 = linked_3671.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3670, arg_3673) }; seq_97000557__9, chunk_97000558__10, count_97000559__11, i_97000560__12 = tmp6, nil, 0, 0; continue L1 } } }
//line :465:1
		break L1 }; var tmp7 lang.IFn =














	lang.IFn_Cast(A_arbace_cpp_run_A_const_35.GetRawRoot__O()); var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_74); var tmp9 any; var root_3625 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_3626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3625, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_3627 lang.IFn; if linked_3626 == nil { ifn_3627 = lang.IFn_Cast(root_3625) } else { ifn_3627 = nil }; var arg_3628 any = Lit_74; var arg_3629 any; var root_3630 any = A_arbace_cpp_run_A_const_215.GetRawRoot__O(); var linked_3631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3630, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_3632 lang.IFn; if linked_3631 == nil { ifn_3632 = lang.IFn_Cast(root_3630) } else { ifn_3632 = nil }; var arg_3633 any; var root_3634 any = A_arbace_cpp_run_A_const_101.GetRawRoot__O(); var linked_3635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3634, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_3636 lang.IFn; if linked_3635 == nil { ifn_3636 = lang.IFn_Cast(root_3634) } else { ifn_3636 = nil }; var arg_3637 any = res__7; if linked_3635 == nil { arg_3633 = ifn_3636.Invoke_O__O(arg_3637) } else { arg_3633 = linked_3635.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_3634, arg_3637) }; if linked_3631 == nil { arg_3629 = ifn_3632.Invoke_O__O(arg_3633) } else { arg_3629 = linked_3631.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_3630, arg_3633) }; if linked_3626 == nil { tmp9 = ifn_3627.Invoke_O_O__O(arg_3628, arg_3629) } else { tmp9 = linked_3626.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_3625, arg_3628, arg_3629) }; return tmp7.Invoke_O_O__O(out__2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, tmp9, nil)).Ref()) }
//line :471:1
func A_arbace_cpp_run_work_list_iter__97000539__97000543_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_run_work_list_iter__97000539__97000543_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_work_list_iter__97000539__97000543_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :471:1
func (t *A_arbace_cpp_run_work_list_iter__97000539__97000543_A) Ctor_O_O_O(c__f, c__q, c__res any) { t.F_f = c__f; t.F_q = c__q; t.F_res = c__res }
//line :471:1
func (t *A_arbace_cpp_run_work_list_iter__97000539__97000543_A) Invoke_O_O__O(self, s__97000540__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3613 any = A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_A_New_O_O_O_O_O(self, t.F_f, t.F_q, s__97000540__1, t.F_res); var tmp2 *jrt.Class; var fncls__3612 *jrt.Class = A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_A_fn_class; if fncls__3612 == nil { var fncls__3612d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_219, false, fnbody__3613); A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_A_fn_class = fncls__3612d; tmp2 = fncls__3612d } else { tmp2 = fncls__3612 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3613, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :471:1
func A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :471:1
func (t *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_A) Ctor_O_O_O_O_O(c__iter__97000539, c__f, c__q, c__s__97000540, c__res any) { t.F_iter__97000539 = c__iter__97000539; t.F_f = c__f; t.F_q = c__q; t.F_s__97000540 = c__s__97000540; t.F_res = c__res }
//line :471:1
func (t *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_A) Invoke_O__O(self any) any { { var s__97000540__1 any; var t_ any = t.F_s__97000540; t.F_s__97000540 = nil; s__97000540__1 = t_; for { var temp__1927000414__auto____2 any; var root_3472 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_3473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3472, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3474 lang.IFn; if linked_3473 == nil { ifn_3474 = lang.IFn_Cast(root_3472) } else { ifn_3474 = nil }; var arg_3475 any = s__97000540__1; if linked_3473 == nil { temp__1927000414__auto____2 = ifn_3474.Invoke_O__O(arg_3475) } else { temp__1927000414__auto____2 = linked_3473.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3472, arg_3475) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__97000540__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3476 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_3477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3476, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3478 lang.IFn; if linked_3477 == nil { ifn_3478 = lang.IFn_Cast(root_3476) } else { ifn_3478 = nil }; var arg_3479 any = s__97000540__3; if linked_3477 == nil { tmp1 = ifn_3478.Invoke_O__O(arg_3479) } else { tmp1 = linked_3477.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3476, arg_3479) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3480 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_3481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3480, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3482 lang.IFn; if linked_3481 == nil { ifn_3482 = lang.IFn_Cast(root_3480) } else { ifn_3482 = nil }; var arg_3483 any = s__97000540__3; if linked_3481 == nil { c__1927001037__auto____4 = ifn_3482.Invoke_O__O(arg_3483) } else { c__1927001037__auto____4 = linked_3481.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3480, arg_3483) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__97000542__6 any; var root_3484 any = A_arbace_cpp_run_A_const_23.GetRawRoot__O(); var linked_3485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3484, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3486 lang.IFn; if linked_3485 == nil { ifn_3486 = lang.IFn_Cast(root_3484) } else { ifn_3486 = nil }; var arg_3487 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3485 == nil { b__97000542__6 = ifn_3486.Invoke_O__O(arg_3487) } else { b__97000542__6 = linked_3485.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3484, arg_3487) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3535 any = A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_A_New_O_O_O_I_O_O(t.F_f, t.F_q, t.F_res, size__1927001038__auto____5, b__97000542__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3534 *jrt.Class = A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_A_fn_class; if fncls__3534 == nil { var fncls__3534d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_220, false, fnbody__3535); A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_A_fn_class = fncls__3534d; tmp3 = fncls__3534d } else { tmp3 = fncls__3534 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3535, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3536 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_3537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3536, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3538 lang.IFn; if linked_3537 == nil { ifn_3538 = lang.IFn_Cast(root_3536) } else { ifn_3538 = nil }; var arg_3539 any; var root_3541 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_3542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3541, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3543 lang.IFn; if linked_3542 == nil { ifn_3543 = lang.IFn_Cast(root_3541) } else { ifn_3543 = nil }; var arg_3544 any = b__97000542__6; if linked_3542 == nil { arg_3539 = ifn_3543.Invoke_O__O(arg_3544) } else { arg_3539 = linked_3542.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3541, arg_3544) }; var arg_3540 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__97000539); var tmp5 any; var root_3545 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_3546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3545, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3547 lang.IFn; if linked_3546 == nil { ifn_3547 = lang.IFn_Cast(root_3545) } else { ifn_3547 = nil }; var arg_3548 any = s__97000540__3; if linked_3546 == nil { tmp5 = ifn_3547.Invoke_O__O(arg_3548) } else { tmp5 = linked_3546.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3545, arg_3548) }; arg_3540 = tmp4.Invoke_O__O(tmp5); if linked_3537 == nil { return ifn_3538.Invoke_O_O__O(arg_3539, arg_3540) } else { return linked_3537.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3536, arg_3539, arg_3540) } } else { var root_3549 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_3550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3549, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3551 lang.IFn; if linked_3550 == nil { ifn_3551 = lang.IFn_Cast(root_3549) } else { ifn_3551 = nil }; var arg_3552 any; var root_3554 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_3555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3554, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3556 lang.IFn; if linked_3555 == nil { ifn_3556 = lang.IFn_Cast(root_3554) } else { ifn_3556 = nil }; var arg_3557 any = b__97000542__6; if linked_3555 == nil { arg_3552 = ifn_3556.Invoke_O__O(arg_3557) } else { arg_3552 = linked_3555.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3554, arg_3557) }; var arg_3553 any; if linked_3550 == nil { return ifn_3551.Invoke_O_O__O(arg_3552, arg_3553) } else { return linked_3550.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3549, arg_3552, arg_3553) } } } else { var ___4 any; var root_3558 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_3559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3558, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3560 lang.IFn; _ = ___4; if linked_3559 == nil { ifn_3560 = lang.IFn_Cast(root_3558) } else { ifn_3560 = nil }; var arg_3561 any = s__97000540__3; if linked_3559 == nil { ___4 = ifn_3560.Invoke_O__O(arg_3561) } else { ___4 = linked_3559.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3558, arg_3561) }; var root_3562 any = A_arbace_cpp_run_A_const_28.GetRawRoot__O(); var linked_3563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3562, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3564 lang.IFn; if linked_3563 == nil { ifn_3564 = lang.IFn_Cast(root_3562) } else { ifn_3564 = nil }; var arg_3565 any; var root_3567 any = A_arbace_cpp_run_A_const_83.GetRawRoot__O(); var linked_3568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3567, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_3569 lang.IFn
													if linked_3568 == nil { ifn_3569 = lang.IFn_Cast(root_3567) } else { ifn_3569 = nil }; var arg_3570 any; var fnbody__3607 any = A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_A_New_O_O_O(t.F_f, t.F_q, t.F_res); var tmp6 *jrt.Class; var fncls__3606 *jrt.Class = A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_A_fn_class; if fncls__3606 == nil { var fncls__3606d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_221, false, fnbody__3607); A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_A_fn_class = fncls__3606d; tmp6 = fncls__3606d } else { tmp6 = fncls__3606 }; arg_3570 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3607, tmp6, nil); if linked_3568 == nil { arg_3565 = ifn_3569.Invoke_O__O(arg_3570) } else { arg_3565 = linked_3568.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_3567, arg_3570) }
//line :471:1
	var arg_3566 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__97000539); var tmp8 any; var root_3608 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_3609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3608, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3610 lang.IFn; if linked_3609 == nil { ifn_3610 = lang.IFn_Cast(root_3608) } else { ifn_3610 = nil }; var arg_3611 any = s__97000540__3; if linked_3609 == nil { tmp8 = ifn_3610.Invoke_O__O(arg_3611) } else { tmp8 = linked_3609.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3608, arg_3611) }; arg_3566 = tmp7.Invoke_O__O(tmp8); if linked_3563 == nil { return ifn_3564.Invoke_O_O__O(arg_3565, arg_3566) } else { return linked_3563.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3562, arg_3565, arg_3566) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :471:1
func A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :471:1
func (t *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_A) Ctor_O_O_O_I_O_O(c__f, c__q, c__res any, c__size__1927001038__auto__ int32, c__b__97000542, c__c__1927001037__auto__ any) { t.F_f = c__f; t.F_q = c__q; t.F_res = c__res; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__97000542 = c__b__97000542; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :471:1
func (t *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_A) Invoke_O__O(self any) any { { var i__97000541__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__97000541__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ___2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__97000541__1)); var root_3488 any = A_arbace_cpp_run_A_const_24.GetRawRoot__O(); var linked_3489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3488, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3490 lang.IFn; _ = ___2; if linked_3489 == nil { ifn_3490 = lang.IFn_Cast(root_3488) } else { ifn_3490 = nil }; var arg_3491 any = t.F_b__97000542; var arg_3492 any; var root_3493 any = A_arbace_cpp_run_A_const_83.GetRawRoot__O(); var linked_3494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3493, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_3495 lang.IFn
															if linked_3494 == nil { ifn_3495 = lang.IFn_Cast(root_3493) } else { ifn_3495 = nil }; var arg_3496 any; var fnbody__3533 any = A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_A_New_O_O_O(t.F_f, t.F_q, t.F_res); var tmp2 *jrt.Class; var fncls__3532 *jrt.Class = A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_A_fn_class; if fncls__3532 == nil { var fncls__3532d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_222, false, fnbody__3533); A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_A_fn_class = fncls__3532d; tmp2 = fncls__3532d } else { tmp2 = fncls__3532 }; arg_3496 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3533, tmp2, nil); if linked_3494 == nil { arg_3492 = ifn_3495.Invoke_O__O(arg_3496) } else { arg_3492 = linked_3494.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_3493, arg_3496) }
//line :471:1
	if linked_3489 == nil { ifn_3490.Invoke_O_O__O(arg_3491, arg_3492) } else { linked_3489.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3488, arg_3491, arg_3492) }; i__97000541__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__97000541__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :472:1
func (t *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_A) Ctor_O_O_O(c__f, c__q, c__res any) { t.F_f = c__f; t.F_q = c__q; t.F_res = c__res }
//line :472:1
func (t *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_A) Invoke_O__O(self any) any { for { L2: for { var temp__1927000414__auto____1 any = jrt.NN(jrt.ConcurrentLinkedQueue_Cast(t.F_q)).Poll__O()

	if jrt.J2g_Truth(temp__1927000414__auto____1) { var l__2 any = temp__1927000414__auto____1; var fs__3 any; var root_3497 any = A_arbace_cpp_run_A_const_40.GetRawRoot__O(); var linked_3498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3497, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_3499 lang.IFn
		if linked_3498 == nil { ifn_3499 = lang.IFn_Cast(root_3497) } else { ifn_3499 = nil }; var arg_3500 any = l__2; var arg_3501 any = A_arbace_cpp_run_A_const_213; var arg_3502 any = A_arbace_cpp_run_A_const_42; if linked_3498 == nil { fs__3 = ifn_3499.Invoke_O_O_O__O(arg_3500, arg_3501, arg_3502) } else { fs__3 = linked_3498.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_3497, arg_3500, arg_3501, arg_3502) }
//line :474:1
		var r__4 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__3508 any = A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_fn__97000547_A_New_O_O(t.F_f, fs__3); var tmp2 *jrt.Class
		var fncls__3507 /*line :474:1*/*jrt.Class = A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_fn__97000547_A_fn_class

		if fncls__3507 == nil { var fncls__3507d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_223, false, fnbody__3508); A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_fn__97000547_A_fn_class = fncls__3507d; tmp2 = fncls__3507d } else { tmp2 = fncls__3507 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3508, tmp2, nil); r__4 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
		var tmp3 jrt.ConcurrentHashMap_I = jrt.ConcurrentHashMap_Cast(t.F_res); var tmp4 any; var root_3509 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_3510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3509, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3511 lang.IFn; if linked_3510 == nil { ifn_3511 = lang.IFn_Cast(root_3509) } else { ifn_3511 = nil }; var arg_3512 any = fs__3; if linked_3510 == nil { tmp4 = ifn_3511.Invoke_O__O(arg_3512) } else { tmp4 = linked_3510.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3509, arg_3512) }; var tmp5 any = tmp4; var tmp6 any; var root_3513 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_3514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3513, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_3515 lang.IFn; if linked_3514 == nil { ifn_3515 = lang.IFn_Cast(root_3513) } else { ifn_3515 = nil }; var arg_3516 any = Lit_25; var arg_3517 any; var root_3518 any = A_arbace_cpp_run_A_const_28.GetRawRoot__O(); var linked_3519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3518, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3520 lang.IFn; if linked_3519 == nil { ifn_3520 = lang.IFn_Cast(root_3518) } else { ifn_3520 = nil }; var arg_3521 any; var root_3523 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_3524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3523, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3525 lang.IFn; if linked_3524 == nil { ifn_3525 = lang.IFn_Cast(root_3523) } else { ifn_3525 = nil }; var arg_3526 any = fs__3; if linked_3524 == nil { arg_3521 = ifn_3525.Invoke_O__O(arg_3526) } else { arg_3521 = linked_3524.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3523, arg_3526) }; var arg_3522 any; var root_3527 any = A_arbace_cpp_run_A_const_63.GetRawRoot__O(); var linked_3528 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3527, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3529 lang.IFn; if linked_3528 == nil { ifn_3529 = lang.IFn_Cast(root_3527) } else { ifn_3529 = nil }; var arg_3530 any = A_arbace_cpp_run_A_const_85.GetRawRoot__O(); var arg_3531 any = r__4; if linked_3528 == nil { arg_3522 = ifn_3529.Invoke_O_O__O(arg_3530, arg_3531) } else { arg_3522 = linked_3528.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3527, arg_3530, arg_3531) }; if linked_3519 == nil { arg_3517 = ifn_3520.Invoke_O_O__O(arg_3521, arg_3522) } else { arg_3517 = linked_3519.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3518, arg_3521, arg_3522) }; if linked_3514 == nil { tmp6 = ifn_3515.Invoke_O_O__O(arg_3516, arg_3517) } else { tmp6 = linked_3514.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_3513, arg_3516, arg_3517) }; tmp3.Put_O_O__O(tmp5, tmp6)
		continue L2 } else {
//line :474:1
			return nil } } }; /*line :472:1*/panic("j2g: unreachable") }
//line :472:1
func A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :472:1
func (t *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_A) Ctor_O_O_O(c__f, c__q, c__res any) { t.F_f = c__f; t.F_q = c__q; t.F_res = c__res }
//line :472:1
func (t *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_A) Invoke_O__O(self any) any { for { L2: for { var temp__1927000414__auto____1 any = jrt.NN(jrt.ConcurrentLinkedQueue_Cast(t.F_q)).Poll__O()

	if jrt.J2g_Truth(temp__1927000414__auto____1) { var l__2 any = temp__1927000414__auto____1; var fs__3 any; var root_3571 any = A_arbace_cpp_run_A_const_40.GetRawRoot__O(); var linked_3572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3571, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_3573 lang.IFn
		if linked_3572 == nil { ifn_3573 = lang.IFn_Cast(root_3571) } else { ifn_3573 = nil }; var arg_3574 any = l__2; var arg_3575 any = A_arbace_cpp_run_A_const_213; var arg_3576 any = A_arbace_cpp_run_A_const_42; if linked_3572 == nil { fs__3 = ifn_3573.Invoke_O_O_O__O(arg_3574, arg_3575, arg_3576) } else { fs__3 = linked_3572.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_3571, arg_3574, arg_3575, arg_3576) }
//line :474:1
		var r__4 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__3582 any = A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_fn__97000552_A_New_O_O(t.F_f, fs__3); var tmp2 *jrt.Class
		var fncls__3581 /*line :474:1*/*jrt.Class = A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_fn__97000552_A_fn_class

		if fncls__3581 == nil { var fncls__3581d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_225, false, fnbody__3582); A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_fn__97000552_A_fn_class = fncls__3581d; tmp2 = fncls__3581d } else { tmp2 = fncls__3581 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3582, tmp2, nil); r__4 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
		var tmp3 jrt.ConcurrentHashMap_I = jrt.ConcurrentHashMap_Cast(t.F_res); var tmp4 any; var root_3583 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_3584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3583, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3585 lang.IFn; if linked_3584 == nil { ifn_3585 = lang.IFn_Cast(root_3583) } else { ifn_3585 = nil }; var arg_3586 any = fs__3; if linked_3584 == nil { tmp4 = ifn_3585.Invoke_O__O(arg_3586) } else { tmp4 = linked_3584.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3583, arg_3586) }; var tmp5 any = tmp4; var tmp6 any; var root_3587 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_3588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3587, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_3589 lang.IFn; if linked_3588 == nil { ifn_3589 = lang.IFn_Cast(root_3587) } else { ifn_3589 = nil }; var arg_3590 any = Lit_25; var arg_3591 any; var root_3592 any = A_arbace_cpp_run_A_const_28.GetRawRoot__O(); var linked_3593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3592, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3594 lang.IFn; if linked_3593 == nil { ifn_3594 = lang.IFn_Cast(root_3592) } else { ifn_3594 = nil }; var arg_3595 any; var root_3597 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_3598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3597, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3599 lang.IFn; if linked_3598 == nil { ifn_3599 = lang.IFn_Cast(root_3597) } else { ifn_3599 = nil }; var arg_3600 any = fs__3; if linked_3598 == nil { arg_3595 = ifn_3599.Invoke_O__O(arg_3600) } else { arg_3595 = linked_3598.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3597, arg_3600) }; var arg_3596 any; var root_3601 any = A_arbace_cpp_run_A_const_63.GetRawRoot__O(); var linked_3602 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3601, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3603 lang.IFn; if linked_3602 == nil { ifn_3603 = lang.IFn_Cast(root_3601) } else { ifn_3603 = nil }; var arg_3604 any = A_arbace_cpp_run_A_const_85.GetRawRoot__O(); var arg_3605 any = r__4; if linked_3602 == nil { arg_3596 = ifn_3603.Invoke_O_O__O(arg_3604, arg_3605) } else { arg_3596 = linked_3602.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3601, arg_3604, arg_3605) }; if linked_3593 == nil { arg_3591 = ifn_3594.Invoke_O_O__O(arg_3595, arg_3596) } else { arg_3591 = linked_3593.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3592, arg_3595, arg_3596) }; if linked_3588 == nil { tmp6 = ifn_3589.Invoke_O_O__O(arg_3590, arg_3591) } else { tmp6 = linked_3588.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_3587, arg_3590, arg_3591) }; tmp3.Put_O_O__O(tmp5, tmp6)
		continue L2 } else {
//line :474:1
			return nil } } }; /*line :472:1*/panic("j2g: unreachable") }



func A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_fn__97000547_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_fn__97000547_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_fn__97000547_A{}; t.Ctor_O_O(p0, p1); return t }
//line :476:1
func (t *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_fn__97000547_A) Ctor_O_O(c__f, c__fs any) { t.F_f = c__f; t.F_fs = c__fs }
//line :476:1
func (t *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_fn__97000547_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_f; t.F_f = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_fs; t.F_fs = nil; tmp4 = t__2; tmp1 = tmp3.Invoke_O__O(tmp4) }; return nil }(); if tmp5 != nil { if true { var e__3 jrt.Throwable_I = tmp5; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil); var tmp7 any; var root_3503 any = A_arbace_cpp_run_A_const_214.GetRawRoot__O(); var linked_3504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3503, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_3505 lang.IFn; if linked_3504 == nil { ifn_3505 = lang.IFn_Cast(root_3503) } else { ifn_3505 = nil }; var arg_3506 any = e__3; if linked_3504 == nil { tmp7 = ifn_3505.Invoke_O__O(arg_3506) } else { tmp7 = linked_3504.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_3503, arg_3506) }; tmp1 = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(Lit_224, Lit_62, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp7)).GetName__String().Ref(), nil, e__3.GetMessage__String().Ref())).Ref(), Lit_62, Lit_62) } }; return tmp1 }
//line :476:1
func A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_fn__97000552_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_fn__97000552_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_fn__97000552_A{}; t.Ctor_O_O(p0, p1); return t }
//line :476:1
func (t *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_fn__97000552_A) Ctor_O_O(c__f, c__fs any) { t.F_f = c__f; t.F_fs = c__fs }
//line :476:1
func (t *A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_fn__97000552_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_f; t.F_f = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_fs; t.F_fs = nil; tmp4 = t__2; tmp1 = tmp3.Invoke_O__O(tmp4) }; return nil }(); if tmp5 != nil { if true { var e__3 jrt.Throwable_I = tmp5; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil); var tmp7 any; var root_3577 any = A_arbace_cpp_run_A_const_214.GetRawRoot__O(); var linked_3578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3577, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_3579 lang.IFn; if linked_3578 == nil { ifn_3579 = lang.IFn_Cast(root_3577) } else { ifn_3579 = nil }; var arg_3580 any = e__3; if linked_3578 == nil { tmp7 = ifn_3579.Invoke_O__O(arg_3580) } else { tmp7 = linked_3578.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_3577, arg_3580) }; tmp1 = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(Lit_224, Lit_62, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp7)).GetName__String().Ref(), nil, e__3.GetMessage__String().Ref())).Ref(), Lit_62, Lit_62) } }; return tmp1 }





func A_arbace_cpp_run_libs_fn_A_New() *A_arbace_cpp_run_libs_fn_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_libs_fn_A{}; t.Ctor(); return t }
//line :482:1
func (t *A_arbace_cpp_run_libs_fn_A) Ctor() {}
//line :482:1
func (t *A_arbace_cpp_run_libs_fn_A) Invoke_O_O_O__O(self, h__0, rtlib__1 any) any { var rt__3 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__3684 any = A_arbace_cpp_run_libs_fn_fn__97000562_A_New_O_O(rtlib__1, h__0); var tmp2 *jrt.Class; var fncls__3683 *jrt.Class = A_arbace_cpp_run_libs_fn_fn__97000562_A_fn_class; if


	fncls__3683 == nil { var fncls__3683d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_147, false, fnbody__3684); A_arbace_cpp_run_libs_fn_fn__97000562_A_fn_class = fncls__3683d; tmp2 = fncls__3683d } else { tmp2 = fncls__3683 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3684, tmp2, nil); rt__3 = /*line :482:1*/lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)); var over__4 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__3695 any = A_arbace_cpp_run_libs_fn_fn__97000564_A_New_O_O(rtlib__1, h__0); var tmp4 *jrt.Class; var fncls__3694 *jrt.Class = A_arbace_cpp_run_libs_fn_fn__97000564_A_fn_class; if




	fncls__3694 == nil { var fncls__3694d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_148, false, fnbody__3695); A_arbace_cpp_run_libs_fn_fn__97000564_A_fn_class = fncls__3694d; tmp4 = fncls__3694d } else { tmp4 = fncls__3694 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3695, tmp4, nil); over__4 = /*line :482:1*/lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp3)); var ms__5 any; var tmp5 *lang.Compiler_AOTFn; var fnbody__3702 any = A_arbace_cpp_run_libs_fn_fn__97000566_A_New_O(h__0); var tmp6 *jrt.Class; var fncls__3701 *jrt.Class = A_arbace_cpp_run_libs_fn_fn__97000566_A_fn_class; if





	fncls__3701 == nil { var fncls__3701d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_149, false, fnbody__3702); A_arbace_cpp_run_libs_fn_fn__97000566_A_fn_class = fncls__3701d; tmp6 = fncls__3701d } else { tmp6 = fncls__3701 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3702, tmp6, nil); ms__5 = /*line :482:1*/lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp5)); var extra__6 any = jrt.ConcurrentHashMap_New(); var fnbody__3743 any = A_arbace_cpp_run_libs_fn_fn__97000568_A_New_O_O_O_O_O(ms__5, h__0, extra__6, over__4, rt__3); var tmp7 *jrt.Class; var fncls__3742 *jrt.Class = A_arbace_cpp_run_libs_fn_fn__97000568_A_fn_class; if







	fncls__3742 == nil { var fncls__3742d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_150, false, fnbody__3743); A_arbace_cpp_run_libs_fn_fn__97000568_A_fn_class = fncls__3742d; tmp7 = fncls__3742d } else { tmp7 = fncls__3742 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3743, tmp7, nil) }
//line :485:1
func A_arbace_cpp_run_libs_fn_fn__97000562_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_libs_fn_fn__97000562_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_libs_fn_fn__97000562_A{}; t.Ctor_O_O(p0, p1); return t }
//line :485:1
func (t *A_arbace_cpp_run_libs_fn_fn__97000562_A) Ctor_O_O(c__rtlib, c__h any) { t.F_rtlib = c__rtlib; t.F_h = c__h }
//line :485:1
func (t *A_arbace_cpp_run_libs_fn_fn__97000562_A) Invoke_O__O(self any) any { var root_3674 any = A_arbace_cpp_run_A_const_216.GetRawRoot__O(); var linked_3675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3674, A_arbace_cpp_run_prebuilt_lib_A_fn_class); var ifn_3676 lang.IFn; if linked_3675 == nil { ifn_3676 = lang.IFn_Cast(root_3674) } else { ifn_3676 = nil }; var arg_3677 any; var t_ any = t.F_h; t.F_h = nil; arg_3677 = t_; var arg_3678 any; var root_3679 any = A_arbace_cpp_run_A_const_217.GetRawRoot__O(); var linked_3680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3679, A_arbace_cpp_run_library_A_fn_class); var ifn_3681 lang.IFn; if linked_3680 == nil { ifn_3681 = lang.IFn_Cast(root_3679) } else { ifn_3681 = nil }; var arg_3682 any; var t__2 any = t.F_rtlib; t.F_rtlib = nil; arg_3682 = t__2; if linked_3680 == nil { arg_3678 = ifn_3681.Invoke_O__O(arg_3682) } else { arg_3678 = linked_3680.(*A_arbace_cpp_run_library_A).Invoke_O_O__O(root_3679, arg_3682) }; if linked_3675 == nil { return ifn_3676.Invoke_O_O__O(arg_3677, arg_3678) } else { return linked_3675.(*A_arbace_cpp_run_prebuilt_lib_A).Invoke_O_O_O__O(root_3674, arg_3677, arg_3678) } }

func A_arbace_cpp_run_libs_fn_fn__97000564_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_libs_fn_fn__97000564_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_libs_fn_fn__97000564_A{}; t.Ctor_O_O(p0, p1); return t }
//line :487:1
func (t *A_arbace_cpp_run_libs_fn_fn__97000564_A) Ctor_O_O(c__rtlib, c__h any) { t.F_rtlib = c__rtlib; t.F_h = c__h }
//line :487:1
func (t *A_arbace_cpp_run_libs_fn_fn__97000564_A) Invoke_O__O(self any) any { if jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_151), jrt.RefArrayOf(jrt.Object_class, t.F_rtlib, nil))).Exists__Z() { var root_3685 any = A_arbace_cpp_run_A_const_216.GetRawRoot__O(); var linked_3686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3685, A_arbace_cpp_run_prebuilt_lib_A_fn_class); var ifn_3687 lang.IFn; if linked_3686 == nil { ifn_3687 = lang.IFn_Cast(root_3685) } else { ifn_3687 = nil }; var arg_3688 any; var t_ any = t.F_h; t.F_h = nil; arg_3688 = t_; var arg_3689 any; var root_3690 any = A_arbace_cpp_run_A_const_217.GetRawRoot__O(); var linked_3691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3690, A_arbace_cpp_run_library_A_fn_class); var ifn_3692 lang.IFn; if linked_3691 == nil { ifn_3692 = lang.IFn_Cast(root_3690) } else { ifn_3692 = nil }; var arg_3693 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_152); var tmp2 any; var t__2 any = t.F_rtlib; t.F_rtlib = nil; tmp2 = t__2; arg_3693 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref(); if linked_3691 == nil { arg_3689 = ifn_3692.Invoke_O__O(arg_3693) } else { arg_3689 = linked_3691.(*A_arbace_cpp_run_library_A).Invoke_O_O__O(root_3690, arg_3693) }; if linked_3686 == nil { return ifn_3687.Invoke_O_O__O(arg_3688, arg_3689) } else { return linked_3686.(*A_arbace_cpp_run_prebuilt_lib_A).Invoke_O_O_O__O(root_3685, arg_3688, arg_3689) } } else { return nil } }
func A_arbace_cpp_run_libs_fn_fn__97000566_A_New_O(p0 any) *A_arbace_cpp_run_libs_fn_fn__97000566_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_libs_fn_fn__97000566_A{}; t.Ctor_O(p0); return t }
//line :488:1
func (t *A_arbace_cpp_run_libs_fn_fn__97000566_A) Ctor_O(c__h any) { t.F_h = c__h }
//line :488:1
func (t *A_arbace_cpp_run_libs_fn_fn__97000566_A) Invoke_O__O(self any) any { var root_3696 any = A_arbace_cpp_run_A_const_218.GetRawRoot__O(); var linked_3697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3696, aot_arbace_c_runtime.A_arbace_c_runtime_library_A_fn_class); var ifn_3698 lang.IFn; if linked_3697 == nil { ifn_3698 = lang.IFn_Cast(root_3696) } else { ifn_3698 = nil }; var arg_3699 any; var t_ any = t.F_h; t.F_h = nil; arg_3699 = t_; var arg_3700 any = jrt.System_GetProperty_String__String(Lit_153).Ref(); if linked_3697 == nil { return ifn_3698.Invoke_O_O__O(arg_3699, arg_3700) } else { return linked_3697.(*aot_arbace_c_runtime.A_arbace_c_runtime_library_A).Invoke_O_O_O__O(root_3696, arg_3699, arg_3700) } }

func A_arbace_cpp_run_libs_fn_fn__97000568_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_cpp_run_libs_fn_fn__97000568_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_libs_fn_fn__97000568_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :490:1
func (t *A_arbace_cpp_run_libs_fn_fn__97000568_A) Ctor_O_O_O_O_O(c__ms, c__h, c__extra, c__over, c__rt any) { t.F_ms = c__ms; t.F_h = c__h; t.F_extra = c__extra; t.F_over = c__over; t.F_rt = c__rt }
//line :490:1
func (t *A_arbace_cpp_run_libs_fn_fn__97000568_A) Invoke_O_O__O(self, xdir__1 any) any {
	var root_3703 any = A_arbace_cpp_run_A_const_62.GetRawRoot__O(); var linked_3704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3703, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3705 lang.IFn; if linked_3704 == nil { ifn_3705 = lang.IFn_Cast(root_3703) } else { ifn_3705 = nil }; var arg_3706 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_30.GetRawRoot__O()); var tmp2 lang.IPersistentVector; var tmp3 any; var root_3713 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_3714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3713, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3715 lang.IFn; if linked_3714 == nil { ifn_3715 = lang.IFn_Cast(root_3713) } else { ifn_3715 = nil }; var arg_3716 any = xdir__1; if linked_3714 == nil { tmp3 = ifn_3715.Invoke_O__O(arg_3716) } else { tmp3 = linked_3714.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3713, arg_3716) }; if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____2 any = jrt.ConcurrentHashMap_Cast(t.F_extra).Get_O__O(xdir__1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { var l__3 any; var root_3717 any = A_arbace_cpp_run_A_const_216.GetRawRoot__O(); var linked_3718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3717, A_arbace_cpp_run_prebuilt_lib_A_fn_class); var ifn_3719 lang.IFn; if linked_3718 == nil { ifn_3719 = lang.IFn_Cast(root_3717) } else { ifn_3719 = nil }; var arg_3720 any = t.F_h; var arg_3721 any; var root_3722 any = A_arbace_cpp_run_A_const_217.GetRawRoot__O(); var linked_3723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3722, A_arbace_cpp_run_library_A_fn_class); var ifn_3724 lang.IFn; if linked_3723 == nil { ifn_3724 = lang.IFn_Cast(root_3722) } else { ifn_3724 = nil }; var arg_3725 any = xdir__1; if linked_3723 == nil { arg_3721 = ifn_3724.Invoke_O__O(arg_3725) } else { arg_3721 = linked_3723.(*A_arbace_cpp_run_library_A).Invoke_O_O__O(root_3722, arg_3725) }; if linked_3718 == nil { l__3 = ifn_3719.Invoke_O_O__O(arg_3720, arg_3721) } else { l__3 = linked_3718.(*A_arbace_cpp_run_prebuilt_lib_A).Invoke_O_O_O__O(root_3717, arg_3720, arg_3721) }; jrt.ConcurrentHashMap_Cast(t.F_extra).PutIfAbsent_O_O__O(xdir__1, l__3); tmp4 = jrt.ConcurrentHashMap_Cast(t.F_extra).Get_O__O(xdir__1) }; tmp2 = lang.Tuple_Create_O__IPersistentVector(tmp4) } else { tmp2 = nil }; var tmp5 any = tmp2; var tmp6 lang.IPersistentVector; var tmp7 any; var root_3726 any = A_arbace_cpp_run_A_const_13.GetRawRoot__O(); var linked_3727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3726, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3728 lang.IFn
	if linked_3727 == nil { ifn_3728 = lang.IFn_Cast(root_3726) } else { ifn_3728 = nil }; var arg_3729 any = t.F_over; if linked_3727 == nil { tmp7 = ifn_3728.Invoke_O__O(arg_3729) } else { tmp7 = linked_3727.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3726, arg_3729) }; if jrt.J2g_Truth(tmp7) { var tmp8 any; var root_3730 any = A_arbace_cpp_run_A_const_13.GetRawRoot__O(); var linked_3731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3730, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3732 lang.IFn; if linked_3731 == nil { ifn_3732 = lang.IFn_Cast(root_3730) } else { ifn_3732 = nil }; var arg_3733 any = t.F_over; if linked_3731 == nil { tmp8 = ifn_3732.Invoke_O__O(arg_3733) } else { tmp8 = linked_3731.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3730, arg_3733) }; tmp6 = lang.Tuple_Create_O__IPersistentVector(tmp8) } else { tmp6 = nil }
//line :491:1
	var tmp9 any = tmp6; var tmp10 any; var root_3734 any = A_arbace_cpp_run_A_const_13.GetRawRoot__O(); var linked_3735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3734, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3736 lang.IFn; if linked_3735 == nil { ifn_3736 = lang.IFn_Cast(root_3734) } else { ifn_3736 = nil }; var arg_3737 any = t.F_rt; if linked_3735 == nil { tmp10 = ifn_3736.Invoke_O__O(arg_3737) } else { tmp10 = linked_3735.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3734, arg_3737) }; var tmp11 any = tmp10; var tmp12 any; var root_3738 any = A_arbace_cpp_run_A_const_13.GetRawRoot__O(); var linked_3739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3738, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3740 lang.IFn; if linked_3739 == nil { ifn_3740 = lang.IFn_Cast(root_3738) } else { ifn_3740 = nil }; var arg_3741 any = t.F_ms; if linked_3739 == nil { tmp12 = ifn_3740.Invoke_O__O(arg_3741) } else { tmp12 = linked_3739.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3738, arg_3741) }; arg_3706 = tmp1.Invoke_O_O_O__O(tmp5, tmp9, lang.Tuple_Create_O_O__IPersistentVector(tmp11, tmp12)); if linked_3704 == nil { return ifn_3705.Invoke_O__O(arg_3706) } else { return linked_3704.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3703, arg_3706)
	}
}

func A_arbace_cpp_run_nodes_list_A_New() *A_arbace_cpp_run_nodes_list_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_nodes_list_A{}; t.Ctor(); return t }
//line :495:1
func (t *A_arbace_cpp_run_nodes_list_A) Ctor() {}
//line :495:1
func (t *A_arbace_cpp_run_nodes_list_A) Invoke_O_O_O_O_O_O__O(self, h__0, work__1, list__2, rtlib__3, threads__4 any) any { var lf__6 any; var root_3744 any = A_arbace_cpp_run_A_const_219.GetRawRoot__O(); var linked_3745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3744, A_arbace_cpp_run_libs_fn_A_fn_class); var ifn_3746 lang.IFn; if



	linked_3745 == nil { ifn_3746 = lang.IFn_Cast(root_3744) } else { ifn_3746 = nil }; var arg_3747 any = h__0; var arg_3748 any = rtlib__3; if linked_3745 == nil { lf__6 = ifn_3746.Invoke_O_O__O(arg_3747, arg_3748) } else { lf__6 = linked_3745.(*A_arbace_cpp_run_libs_fn_A).Invoke_O_O_O__O(root_3744, arg_3747, arg_3748) }; var root_3749 any =
	A_arbace_cpp_run_A_const_220.GetRawRoot__O(); var linked_3750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3749, A_arbace_cpp_run_work_list_A_fn_class); var ifn_3751 lang.IFn; if linked_3750 == nil { ifn_3751 = lang.IFn_Cast(root_3749) } else { ifn_3751 = nil }; var arg_3752 any = list__2; var arg_3753 any = threads__4; var arg_3754 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_84), jrt.RefArrayOf(jrt.Object_class, work__1, nil)).Ref(); var arg_3755 any; var fnbody__3774 any = A_arbace_cpp_run_nodes_list_fn__97000572_A_New_O_O_O(h__0, work__1, lf__6); var tmp1 *jrt.Class; var fncls__3773 *jrt.Class = A_arbace_cpp_run_nodes_list_fn__97000572_A_fn_class; if
	fncls__3773 == nil { var fncls__3773d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_163, false, fnbody__3774); A_arbace_cpp_run_nodes_list_fn__97000572_A_fn_class = fncls__3773d; tmp1 = fncls__3773d } else { tmp1 = fncls__3773 }; arg_3755 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3774, tmp1, nil); if /*line :500:1*/ linked_3750 == nil { return ifn_3751.Invoke_O_O_O_O__O(arg_3752, arg_3753, arg_3754, arg_3755) } else { return linked_3750.(*A_arbace_cpp_run_work_list_A).Invoke_O_O_O_O_O__O(root_3749, arg_3752, arg_3753, arg_3754, arg_3755) } }
func A_arbace_cpp_run_nodes_list_fn__97000572_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_run_nodes_list_fn__97000572_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_nodes_list_fn__97000572_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :501:1
func (t *A_arbace_cpp_run_nodes_list_fn__97000572_A) Ctor_O_O_O(c__h, c__work, c__lf any) { t.F_h = c__h; t.F_work = c__work; t.F_lf = c__lf }
//line :501:1
func (t *A_arbace_cpp_run_nodes_list_fn__97000572_A) Invoke_O_O__O(self, p__97000571__1 any) any { var vec__97000573__2 any = p__97000571__1; var id__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000573__2, lang.RT_IntCast_J__I_NoInit(0), nil); var path__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000573__2, lang.RT_IntCast_J__I_NoInit(1), nil); var xdir__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000573__2, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__97000576__6 any; if
													lang.Util_Equiv_O_O__Z_NoInit(path__4, Lit_86) { vec__97000576__6 = A_arbace_cpp_run_A_const_221 } else { var root_3756 any = A_arbace_cpp_run_A_const_222.GetRawRoot__O(); var linked_3757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3756, A_arbace_cpp_run_build_one_A_fn_class); var ifn_3758 lang.IFn; if linked_3757 == nil { ifn_3758 = lang.IFn_Cast(root_3756) } else { ifn_3758 = nil }; var arg_3759 any = t.F_h; var arg_3760 any; var fnbody__3763 any = A_arbace_cpp_run_nodes_list_fn__97000572_fn__97000579_A_New_O_O(xdir__5, t.F_lf); var tmp1 *jrt.Class; var fncls__3762 *jrt.Class = A_arbace_cpp_run_nodes_list_fn__97000572_fn__97000579_A_fn_class; if fncls__3762 == nil { var fncls__3762d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_164, false, fnbody__3763); A_arbace_cpp_run_nodes_list_fn__97000572_fn__97000579_A_fn_class = fncls__3762d; tmp1 = fncls__3762d } else { tmp1 = fncls__3762 }; arg_3760 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3763, tmp1, nil); var arg_3761 any = path__4; if linked_3757 == nil { vec__97000576__6 = ifn_3758.Invoke_O_O_O__O(arg_3759, arg_3760, arg_3761) } else { vec__97000576__6 = linked_3757.(*A_arbace_cpp_run_build_one_A).Invoke_O_O_O_O__O(root_3756, arg_3759, arg_3760, arg_3761) } }; var st__7 any = /*line :501:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__97000576__6, lang.RT_IntCast_J__I_NoInit(0), nil); var cls__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000576__6, lang.RT_IntCast_J__I_NoInit(1), nil); var msg__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000576__6, lang.RT_IntCast_J__I_NoInit(2), nil); var ld__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000576__6, lang.RT_IntCast_J__I_NoInit(3), nil); var s__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000576__6, lang.RT_IntCast_J__I_NoInit(4), nil); var cmds__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000576__6, lang.RT_IntCast_J__I_NoInit(5), nil); if

	jrt.J2g_Truth(cmds__12) { var root_3764 any = A_arbace_cpp_run_A_const_60.GetRawRoot__O(); var linked_3765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3764, A_arbace_cpp_run_spit_mk_A_fn_class); var ifn_3766 lang.IFn; if linked_3765 == nil { ifn_3766 = lang.IFn_Cast(root_3764) } else { ifn_3766 = nil }; var arg_3767 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_143, nil, Lit_165), jrt.RefArrayOf(jrt.Object_class, t.F_work, nil, id__3, nil)).Ref(); var arg_3768 any; var root_3769 any = A_arbace_cpp_run_A_const_223.GetRawRoot__O(); var linked_3770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3769, aot_arbace_c_build.A_arbace_c_build_program_text_A_fn_class); var ifn_3771 lang.IFn; if linked_3770 == nil { ifn_3771 = lang.IFn_Cast(root_3769) } else { ifn_3771 = nil }; var arg_3772 any = cmds__12; if linked_3770 == nil { arg_3768 = ifn_3771.Invoke_O__O(arg_3772) } else { arg_3768 = linked_3770.(*aot_arbace_c_build.A_arbace_c_build_program_text_A).Invoke_O_O__O(root_3769, arg_3772) }; if linked_3765 == nil { ifn_3766.Invoke_O_O__O(arg_3767, arg_3768) } else { linked_3765.(*A_arbace_cpp_run_spit_mk_A).Invoke_O_O_O__O(root_3764, arg_3767, arg_3768) } }; return /*line :501:1*/ lang.Tuple_Create_O_O_O_O_O__IPersistentVector(st__7, cls__8, msg__9, ld__10, s__11) }
func A_arbace_cpp_run_nodes_list_fn__97000572_fn__97000579_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_nodes_list_fn__97000572_fn__97000579_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_nodes_list_fn__97000572_fn__97000579_A{}; t.Ctor_O_O(p0, p1); return t }
//line :502:1
func (t *A_arbace_cpp_run_nodes_list_fn__97000572_fn__97000579_A) Ctor_O_O(c__xdir, c__lf any) { t.F_xdir = c__xdir; t.F_lf = c__lf }
//line :502:1
func (t *A_arbace_cpp_run_nodes_list_fn__97000572_fn__97000579_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_lf); var tmp2 any; var or__1927000174__auto____1 any = t.F_xdir; if jrt.J2g_Truth(or__1927000174__auto____1) { tmp2 = or__1927000174__auto____1 } else { tmp2 = Lit_62 }; return tmp1.Invoke_O__O(tmp2) }



func A_arbace_cpp_run_compile_list_A_New() *A_arbace_cpp_run_compile_list_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_compile_list_A{}; t.Ctor(); return t }
//line :506:1
func (t *A_arbace_cpp_run_compile_list_A) Ctor() {}
//line :506:1
func (t *A_arbace_cpp_run_compile_list_A) Invoke_O_O_O_O_O_O__O(self, h__0, out__1, list__2, rtlib__3, threads__4 any) any {




	lang.IFn_Cast(A_arbace_cpp_run_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_cpp_run_A_const_229)
//line :506:1
	var lf__6 any; var root_3775 any = A_arbace_cpp_run_A_const_219.GetRawRoot__O(); var linked_3776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3775, A_arbace_cpp_run_libs_fn_A_fn_class); var ifn_3777 lang.IFn





	if linked_3776 == nil { ifn_3777 = lang.IFn_Cast(root_3775) } else { ifn_3777 = nil }; var arg_3778 any = h__0; var arg_3779 any = rtlib__3; if linked_3776 == nil { lf__6 = ifn_3777.Invoke_O_O__O(arg_3778, arg_3779) } else { lf__6 = linked_3776.(*A_arbace_cpp_run_libs_fn_A).Invoke_O_O_O__O(root_3775, arg_3778, arg_3779) }
//line :506:1
	var translate__7 any; var root_3780 any = A_arbace_cpp_run_A_const_224.GetRawRoot__O(); var linked_3781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3780, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_3782 lang.IFn






	if linked_3781 == nil { ifn_3782 = lang.IFn_Cast(root_3780) } else { ifn_3782 = nil }; var arg_3783 any = A_arbace_cpp_run_A_const_225; if linked_3781 == nil { translate__7 = ifn_3782.Invoke_O__O(arg_3783) } else { translate__7 = linked_3781.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_3780, arg_3783) }
//line :506:1
	var go_text__8 any; var root_3784 any = A_arbace_cpp_run_A_const_224.GetRawRoot__O(); var linked_3785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3784, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_3786 lang.IFn







	if linked_3785 == nil { ifn_3786 = lang.IFn_Cast(root_3784) } else { ifn_3786 = nil }; var arg_3787 any = A_arbace_cpp_run_A_const_226; if linked_3785 == nil { go_text__8 = ifn_3786.Invoke_O__O(arg_3787) } else { go_text__8 = linked_3785.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_3784, arg_3787) }
	var root_3788 any = A_arbace_cpp_run_A_const_220.GetRawRoot__O(); var linked_3789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3788, A_arbace_cpp_run_work_list_A_fn_class); var ifn_3790 lang.IFn; if linked_3789 == nil { ifn_3790 = lang.IFn_Cast(root_3788) } else { ifn_3790 = nil }; var arg_3791 any = list__2; var arg_3792 any = threads__4; var arg_3793 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_84), jrt.RefArrayOf(jrt.Object_class, out__1, nil)).Ref(); var arg_3794 any; var fnbody__3834 any = A_arbace_cpp_run_compile_list_fn__97000584_A_New_O_O_O_O_O(h__0, translate__7, out__1, lf__6, go_text__8); var tmp1 *jrt.Class; var fncls__3833 *jrt.Class = A_arbace_cpp_run_compile_list_fn__97000584_A_fn_class
	if fncls__3833 == nil { var fncls__3833d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, fnbody__3834); A_arbace_cpp_run_compile_list_fn__97000584_A_fn_class = fncls__3833d; tmp1 = fncls__3833d } else { tmp1 = fncls__3833 }; arg_3794 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3834, tmp1, nil)
//line :515:1
	if linked_3789 == nil { return ifn_3790.Invoke_O_O_O_O__O(arg_3791, arg_3792, arg_3793, arg_3794) } else { return linked_3789.(*A_arbace_cpp_run_work_list_A).Invoke_O_O_O_O_O__O(root_3788, arg_3791, arg_3792, arg_3793, arg_3794) } }
func A_arbace_cpp_run_compile_list_fn__97000584_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_cpp_run_compile_list_fn__97000584_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_compile_list_fn__97000584_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :516:1
func (t *A_arbace_cpp_run_compile_list_fn__97000584_A) Ctor_O_O_O_O_O(c__h, c__translate, c__out, c__lf, c__go_text any) { t.F_h = c__h; t.F_translate = c__translate; t.F_out = c__out; t.F_lf = c__lf; t.F_go_text = c__go_text }
//line :516:1
func (t *A_arbace_cpp_run_compile_list_fn__97000584_A) Invoke_O_O__O(self, p__97000583__1 any) any { var vec__97000585__2 any = p__97000583__1; var id__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000585__2, lang.RT_IntCast_J__I_NoInit(0), nil); var path__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000585__2, lang.RT_IntCast_J__I_NoInit(1), nil); var xdir__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000585__2, lang.RT_IntCast_J__I_NoInit(2), nil); var pkg__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000585__2, lang.RT_IntCast_J__I_NoInit(3), nil); var vec__97000588__7 any; _ = id__3; if
													lang.Util_Equiv_O_O__Z_NoInit(path__4, Lit_86) { vec__97000588__7 = A_arbace_cpp_run_A_const_227 } else { var root_3795 any = A_arbace_cpp_run_A_const_222.GetRawRoot__O(); var linked_3796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3795, A_arbace_cpp_run_build_one_A_fn_class); var ifn_3797 lang.IFn; if linked_3796 == nil { ifn_3797 = lang.IFn_Cast(root_3795) } else { ifn_3797 = nil }; var arg_3798 any = t.F_h; var arg_3799 any; var fnbody__3802 any = A_arbace_cpp_run_compile_list_fn__97000584_fn__97000591_A_New_O_O(xdir__5, t.F_lf); var tmp1 *jrt.Class; var fncls__3801 *jrt.Class = A_arbace_cpp_run_compile_list_fn__97000584_fn__97000591_A_fn_class; if fncls__3801 == nil { var fncls__3801d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__3802); A_arbace_cpp_run_compile_list_fn__97000584_fn__97000591_A_fn_class = fncls__3801d; tmp1 = fncls__3801d } else { tmp1 = fncls__3801 }; arg_3799 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3802, tmp1, nil); var arg_3800 any = path__4; if linked_3796 == nil { vec__97000588__7 = ifn_3797.Invoke_O_O_O__O(arg_3798, arg_3799, arg_3800) } else { vec__97000588__7 = linked_3796.(*A_arbace_cpp_run_build_one_A).Invoke_O_O_O_O__O(root_3795, arg_3798, arg_3799, arg_3800) } }; var st__8 any = /*line :516:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__97000588__7, lang.RT_IntCast_J__I_NoInit(0), nil); var cls__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000588__7, lang.RT_IntCast_J__I_NoInit(1), nil); var msg__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000588__7, lang.RT_IntCast_J__I_NoInit(2), nil); var ld__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000588__7, lang.RT_IntCast_J__I_NoInit(3), nil); var s__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000588__7, lang.RT_IntCast_J__I_NoInit(4), nil); var cmds__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000588__7, lang.RT_IntCast_J__I_NoInit(5), nil); var tmp2 any; var root_3803 any = A_arbace_cpp_run_A_const_110.GetRawRoot__O(); var linked_3804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3803, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3805 lang.IFn; if

	linked_3804 == nil { ifn_3805 = lang.IFn_Cast(root_3803) } else { ifn_3805 = nil }; var arg_3806 any = cmds__13; if linked_3804 == nil { tmp2 = ifn_3805.Invoke_O__O(arg_3806) } else { tmp2 = linked_3804.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3803, arg_3806) }; if jrt.J2g_Truth(tmp2) { return lang.Tuple_Create_O_O_O_O_O__IPersistentVector(st__8, cls__9, msg__10, ld__11, s__12) } else { var t0__14 int64 = jrt.System_NanoTime__J(); var tmp3 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 lang.IFn = lang.IFn_Cast(t.F_translate); var vec__97000593__17 any = tmp4.Invoke_O_O_O__O(cmds__13, pkg__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_88, nil), jrt.RefArrayOf(jrt.Object_class, nil, pkg__6)).Ref()); var forms__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000593__17, lang.RT_IntCast_J__I_NoInit(0), nil); var d__19 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, t.F_out, nil, pkg__6)).Ref()




		if jrt.System_Getenv_String__String(Lit_90) != nil { var root_3807 any = A_arbace_cpp_run_A_const_60.GetRawRoot__O(); var linked_3808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3807, A_arbace_cpp_run_spit_mk_A_fn_class); var ifn_3809 lang.IFn; if linked_3808 == nil { ifn_3809 = lang.IFn_Cast(root_3807) } else { ifn_3809 = nil }; var arg_3810 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_91), jrt.RefArrayOf(jrt.Object_class, d__19, nil)).Ref(); var arg_3811 any; var root_3812 any = A_arbace_cpp_run_A_const_223.GetRawRoot__O(); var linked_3813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3812, aot_arbace_c_build.A_arbace_c_build_program_text_A_fn_class); var ifn_3814 lang.IFn; if linked_3813 == nil { ifn_3814 = lang.IFn_Cast(root_3812) } else { ifn_3814 = nil }; var arg_3815 any = cmds__13; if linked_3813 == nil { arg_3811 = ifn_3814.Invoke_O__O(arg_3815) } else { arg_3811 = linked_3813.(*aot_arbace_c_build.A_arbace_c_build_program_text_A).Invoke_O_O__O(root_3812, arg_3815) }; if linked_3808 == nil { ifn_3809.Invoke_O_O__O(arg_3810, arg_3811) } else { linked_3808.(*A_arbace_cpp_run_spit_mk_A).Invoke_O_O_O__O(root_3807, arg_3810, arg_3811) } }
		var root_3816 any = A_arbace_cpp_run_A_const_60.GetRawRoot__O(); var linked_3817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3816, A_arbace_cpp_run_spit_mk_A_fn_class); var ifn_3818 lang.IFn; if linked_3817 == nil { ifn_3818 = lang.IFn_Cast(root_3816) } else { ifn_3818 = nil }; var arg_3819 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_92), jrt.RefArrayOf(jrt.Object_class, d__19, nil)).Ref(); var arg_3820 any = lang.IFn_Cast(t.F_go_text).Invoke_O__O(forms__18); if linked_3817 == nil { ifn_3818.Invoke_O_O__O(arg_3819, arg_3820) } else { linked_3817.(*A_arbace_cpp_run_spit_mk_A).Invoke_O_O_O__O(root_3816, arg_3819, arg_3820) }
//line :518:1
		var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_69, nil); var tmp6 any; var root_3821 any = A_arbace_cpp_run_A_const_205.GetRawRoot__O(); var linked_3822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3821, A_arbace_cpp_run_secs_A_fn_class); var ifn_3823 lang.IFn






		if linked_3822 == nil { ifn_3823 = lang.IFn_Cast(root_3821) } else { ifn_3823 = nil }; var arg_3824 any = jrt.Long_ValueOf_J__Long_NoInit(t0__14).Ref(); if linked_3822 == nil { tmp6 = ifn_3823.Invoke_O__O(arg_3824) } else { tmp6 = linked_3822.(*A_arbace_cpp_run_secs_A).Invoke_O_O__O(root_3821, arg_3824) }
//line :518:1
		tmp3 = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(Lit_67, Lit_62, Lit_62, ld__11, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, s__12, nil, tmp6)).Ref()) }; return nil }(); if tmp7 != nil { if lang.ExceptionInfo_InstanceOf(tmp7) { var e__17 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp7); var temp__1927000408__auto____18 any; var tmp8 *lang.Keyword = A_arbace_cpp_run_A_const_228; var tmp9 any; var root_3825 any = A_arbace_cpp_run_A_const_212.GetRawRoot__O(); var linked_3826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3825, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_3827 lang.IFn








			if linked_3826 == nil { ifn_3827 = lang.IFn_Cast(root_3825) } else { ifn_3827 = nil }; var arg_3828 any = e__17; if linked_3826 == nil { tmp9 = ifn_3827.Invoke_O__O(arg_3828) } else { tmp9 = linked_3826.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_3825, arg_3828) }; temp__1927000408__auto____18 = tmp8.Invoke_O__O(tmp9); if jrt.J2g_Truth(temp__1927000408__auto____18) { var c__19 any = temp__1927000408__auto____18; var tmp10 any; var root_3829 any = A_arbace_cpp_run_A_const_56.GetRawRoot__O(); var linked_3830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3829, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_3831 lang.IFn
				if linked_3830 == nil { ifn_3831 = lang.IFn_Cast(root_3829) } else { ifn_3831 = nil }; var arg_3832 any = c__19; if linked_3830 == nil { tmp10 = ifn_3831.Invoke_O__O(arg_3832) } else { tmp10 = linked_3830.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_3829, arg_3832) }
//line :527:1
				tmp3 = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(Lit_68, tmp10, e__17.GetMessage__String().Ref(), ld__11, s__12) } else { panic(jrt.Thrown(e__17)) } } else {
//line :518:1
					panic(tmp7) } }; return tmp3 } }
//line :517:1
func A_arbace_cpp_run_compile_list_fn__97000584_fn__97000591_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_compile_list_fn__97000584_fn__97000591_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_compile_list_fn__97000584_fn__97000591_A{}; t.Ctor_O_O(p0, p1); return t }
//line :517:1
func (t *A_arbace_cpp_run_compile_list_fn__97000584_fn__97000591_A) Ctor_O_O(c__xdir, c__lf any) { t.F_xdir = c__xdir; t.F_lf = c__lf }
//line :517:1
func (t *A_arbace_cpp_run_compile_list_fn__97000584_fn__97000591_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_lf); var tmp2 any; var or__1927000174__auto____1 any = t.F_xdir; if jrt.J2g_Truth(or__1927000174__auto____1) { tmp2 = or__1927000174__auto____1 } else { tmp2 = Lit_62 }; return tmp1.Invoke_O__O(tmp2) }













func A_arbace_cpp_run_check_c_A_New() *A_arbace_cpp_run_check_c_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_check_c_A{}; t.Ctor(); return t }
//line :531:1
func (t *A_arbace_cpp_run_check_c_A) Ctor() {}
//line :531:1
func (t *A_arbace_cpp_run_check_c_A) Invoke_O_O_O_O__O(self, h__0, list__1, threads__2 any) any {




	var root_3839 any = A_arbace_cpp_run_A_const_220.GetRawRoot__O(); var linked_3840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3839, A_arbace_cpp_run_work_list_A_fn_class); var ifn_3841 lang.IFn; if linked_3840 == nil { ifn_3841 = lang.IFn_Cast(root_3839) } else { ifn_3841 = nil }; var arg_3842 any = list__1; var arg_3843 any = threads__2; var arg_3844 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_70), jrt.RefArrayOf(jrt.Object_class, list__1, nil)).Ref(); var arg_3845 any; var fnbody__3872 any = A_arbace_cpp_run_check_c_fn__97000599_A_New_O(h__0); var tmp1 *jrt.Class; var fncls__3871 *jrt.Class = A_arbace_cpp_run_check_c_fn__97000599_A_fn_class
	if fncls__3871 == nil { var fncls__3871d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, fnbody__3872); A_arbace_cpp_run_check_c_fn__97000599_A_fn_class = fncls__3871d; tmp1 = fncls__3871d } else { tmp1 = fncls__3871 }; arg_3845 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3872, tmp1, nil)
//line :536:1
	if linked_3840 == nil { return ifn_3841.Invoke_O_O_O_O__O(arg_3842, arg_3843, arg_3844, arg_3845) } else { return linked_3840.(*A_arbace_cpp_run_work_list_A).Invoke_O_O_O_O_O__O(root_3839, arg_3842, arg_3843, arg_3844, arg_3845) } }
func A_arbace_cpp_run_check_c_fn__97000599_A_New_O(p0 any) *A_arbace_cpp_run_check_c_fn__97000599_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_check_c_fn__97000599_A{}; t.Ctor_O(p0); return t }
//line :537:1
func (t *A_arbace_cpp_run_check_c_fn__97000599_A) Ctor_O(c__h any) { t.F_h = c__h }
//line :537:1
func (t *A_arbace_cpp_run_check_c_fn__97000599_A) Invoke_O_O__O(self, p__97000598__1 any) any { var vec__97000600__2 any = p__97000598__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000600__2, lang.RT_IntCast_J__I_NoInit(0), nil); var dir__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000600__2, lang.RT_IntCast_J__I_NoInit(1), nil); var r__5 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__3856 any = A_arbace_cpp_run_check_c_fn__97000599_fn__97000603_A_New_O_O(t.F_h, dir__4); var tmp2 *jrt.Class; var fncls__3855 *jrt.Class = A_arbace_cpp_run_check_c_fn__97000599_fn__97000603_A_fn_class; _ = ___3; if
												fncls__3855 == nil { var fncls__3855d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, fnbody__3856); A_arbace_cpp_run_check_c_fn__97000599_fn__97000603_A_fn_class = fncls__3855d; tmp2 = fncls__3855d } else { tmp2 = fncls__3855 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3856, tmp2, nil); r__5 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O(); var st__6 any; var root_3857 any = /*line :537:1*/A_arbace_cpp_run_A_const_56.GetRawRoot__O(); var linked_3858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3857, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_3859 lang.IFn; if


	linked_3858 == nil { ifn_3859 = lang.IFn_Cast(root_3857) } else { ifn_3859 = nil }; var arg_3860 any = A_arbace_cpp_run_A_const_193.Invoke_O__O(r__5); if linked_3858 == nil { st__6 = ifn_3859.Invoke_O__O(arg_3860) } else { st__6 = linked_3858.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_3857, arg_3860) };
	lang.IFn_Cast(A_arbace_cpp_run_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_73), jrt.RefArrayOf(jrt.Object_class, dir__4, nil)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_74), jrt.RefArrayOf(jrt.Object_class, st__6, nil)).Ref());
	lang.IFn_Cast(A_arbace_cpp_run_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_75), jrt.RefArrayOf(jrt.Object_class, dir__4, nil)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_74), jrt.RefArrayOf(jrt.Object_class, A_arbace_cpp_run_A_const_57.Invoke_O_O__O(r__5, Lit_62), nil)).Ref()); return /*line :537:1*/ lang.Tuple_Create_O_O__IPersistentVector(st__6, A_arbace_cpp_run_A_const_57.Invoke_O_O__O(r__5, Lit_62)) }
func A_arbace_cpp_run_check_c_fn__97000599_fn__97000603_A_New_O_O(p0, p1 any) *A_arbace_cpp_run_check_c_fn__97000599_fn__97000603_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_check_c_fn__97000599_fn__97000603_A{}; t.Ctor_O_O(p0, p1); return t }
//line :538:1
func (t *A_arbace_cpp_run_check_c_fn__97000599_fn__97000603_A) Ctor_O_O(c__h, c__dir any) { t.F_h = c__h; t.F_dir = c__dir }
//line :538:1
func (t *A_arbace_cpp_run_check_c_fn__97000599_fn__97000603_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3846 any = A_arbace_cpp_run_A_const_206.GetRawRoot__O(); var linked_3847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3846, A_arbace_cpp_run_read_program_A_fn_class); var ifn_3848 lang.IFn; if linked_3847 == nil { ifn_3848 = lang.IFn_Cast(root_3846) } else { ifn_3848 = nil }; var arg_3849 any; var t_ any = t.F_h; t.F_h = nil; arg_3849 = t_; var arg_3850 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_60); var tmp3 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp3 = t__2; arg_3850 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil))); if linked_3847 == nil { tmp1 = ifn_3848.Invoke_O_O__O(arg_3849, arg_3850) } else { tmp1 = linked_3847.(*A_arbace_cpp_run_read_program_A).Invoke_O_O_O__O(root_3846, arg_3849, arg_3850) } }; return nil }(); if tmp4 != nil { if true { var e__3 jrt.Throwable_I = tmp4; var tmp5 any = A_arbace_cpp_run_A_const_193; var tmp6 any = A_arbace_cpp_run_A_const_230; var tmp7 any = A_arbace_cpp_run_A_const_57; var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil); var tmp9 any; var root_3851 any = A_arbace_cpp_run_A_const_214.GetRawRoot__O(); var linked_3852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3851, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_3853 lang.IFn
												if linked_3852 == nil { ifn_3853 = lang.IFn_Cast(root_3851) } else { ifn_3853 = nil }; var arg_3854 any = e__3; if linked_3852 == nil { tmp9 = ifn_3853.Invoke_O__O(arg_3854) } else { tmp9 = linked_3852.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_3851, arg_3854) }
//line :538:1
	tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp9)).GetName__String().Ref(), nil, e__3.GetMessage__String().Ref())).Ref())) } }; return tmp1 }






func A_arbace_cpp_run__main_A_New() *A_arbace_cpp_run__main_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run__main_A{}; t.Ctor(); return t }
//line :545:1
func (t *A_arbace_cpp_run__main_A) Ctor() {}
//line :545:1
func (t *A_arbace_cpp_run__main_A) DoInvoke_O_O_O__O(self, verb__0, args__1 any) any { var h__3 any; var root_3873 any = A_arbace_cpp_run_A_const_231.GetRawRoot__O(); var linked_3874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3873, aot_arbace_repr_c_host.A_arbace_repr_c_host_load_host_A_fn_class); var ifn_3875 lang.IFn; if



	linked_3874 == nil { ifn_3875 = lang.IFn_Cast(root_3873) } else { ifn_3875 = nil }; var arg_3876 any = Lit_1; if linked_3874 == nil { h__3 = ifn_3875.Invoke_O__O(arg_3876) } else { h__3 = linked_3874.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_load_host_A).Invoke_O_O__O(root_3873, arg_3876) }; var th__4 any; var fnbody__3878 any = /*line :545:1*/A_arbace_cpp_run__main_th__97000609_A_New(); var tmp1 *jrt.Class; var fncls__3877 *jrt.Class = A_arbace_cpp_run__main_th__97000609_A_fn_class; if



	fncls__3877 == nil { var fncls__3877d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_cpp_run__main_th__97000609_A_fn_class = fncls__3877d; tmp1 = fncls__3877d } else { tmp1 = fncls__3877 }; th__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3878, tmp1, nil); var G__97000611__5_ any = verb__0; L1:

	switch { default: switch lang.Util_Hash_O__I_NoInit(G__97000611__5_) >> 8 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__97000611__5_, Lit_3) { var vec__97000612__6 any = args__1; var list__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000612__6, lang.RT_IntCast_J__I_NoInit(0), nil); var t__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000612__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3880 any = A_arbace_cpp_run_A_const_232.GetRawRoot__O(); var linked_3881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3880, A_arbace_cpp_run_check_c_A_fn_class); var ifn_3882 lang.IFn








		if linked_3881 == nil { ifn_3882 = lang.IFn_Cast(root_3880) } else { ifn_3882 = nil }; var arg_3883 any = h__3; var arg_3884 any = list__7; var arg_3885 any = lang.IFn_Cast(th__4).Invoke_O__O(t__8); if linked_3881 == nil { ifn_3882.Invoke_O_O_O__O(arg_3883, arg_3884, arg_3885) } else { linked_3881.(*A_arbace_cpp_run_check_c_A).Invoke_O_O_O_O__O(root_3880, arg_3883, arg_3884, arg_3885) }
//line :551:1
		break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__97000611__5_, Lit_4) { var vec__97000615__6 any = args__1; var dir__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000615__6, lang.RT_IntCast_J__I_NoInit(0), nil); var list__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000615__6, lang.RT_IntCast_J__I_NoInit(1), nil); var t__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000615__6, lang.RT_IntCast_J__I_NoInit(2), nil); var rows__10 any; var root_3886 any = A_arbace_cpp_run_A_const_39.GetRawRoot__O(); var linked_3887 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3886, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_3888 lang.IFn



			if linked_3887 == nil { ifn_3888 = lang.IFn_Cast(root_3886) } else { ifn_3888 = nil }; var arg_3889 any; var fnbody__3897 any = A_arbace_cpp_run__main_fn__97000618_A_New(); var tmp2 *jrt.Class; var fncls__3896 *jrt.Class = A_arbace_cpp_run__main_fn__97000618_A_fn_class; if fncls__3896 == nil { var fncls__3896d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); A_arbace_cpp_run__main_fn__97000618_A_fn_class = fncls__3896d; tmp2 = fncls__3896d } else { tmp2 = fncls__3896 }; arg_3889 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3897, tmp2, nil); var arg_3890 any; var root_3898 any = A_arbace_cpp_run_A_const_43.GetRawRoot__O(); var linked_3899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3898, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3900 lang.IFn; if linked_3899 == nil { ifn_3900 = lang.IFn_Cast(root_3898) } else { ifn_3900 = nil }; var arg_3901 any = A_arbace_cpp_run_A_const_44.GetRawRoot__O(); var arg_3902 any; var root_3903 any = A_arbace_cpp_run_A_const_45.GetRawRoot__O(); var linked_3904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3903, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_3905 lang.IFn; if linked_3904 == nil { ifn_3905 = lang.IFn_Cast(root_3903) } else { ifn_3905 = nil }; var arg_3906 any = lang.IFn_Cast(A_arbace_cpp_run_A_const_46.GetRawRoot__O()).Invoke_O__O(list__8); if linked_3904 == nil { arg_3902 = ifn_3905.Invoke_O__O(arg_3906) } else { arg_3902 = linked_3904.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_3903, arg_3906) }; if linked_3899 == nil { arg_3890 = ifn_3900.Invoke_O_O__O(arg_3901, arg_3902) } else { arg_3890 = linked_3899.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3898, arg_3901, arg_3902) }; if linked_3887 == nil { rows__10 = ifn_3888.Invoke_O_O__O(arg_3889, arg_3890) } else { rows__10 = linked_3887.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_3886, arg_3889, arg_3890) }
//line :551:1
			var bad__11 any; var root_3911 any = A_arbace_cpp_run_A_const_82.GetRawRoot__O(); var linked_3912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3911, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_3913 lang.IFn




			if linked_3912 == nil { ifn_3913 = lang.IFn_Cast(root_3911) } else { ifn_3913 = nil }; var arg_3914 any; var root_3915 any = A_arbace_cpp_run_A_const_168.GetRawRoot__O(); var linked_3916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3915, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3917 lang.IFn; if linked_3916 == nil { ifn_3917 = lang.IFn_Cast(root_3915) } else { ifn_3917 = nil }; var arg_3918 any; var fnbody__3930 any = A_arbace_cpp_run__main_fn__97000621_A_New(); var tmp3 *jrt.Class; var fncls__3929 *jrt.Class = A_arbace_cpp_run__main_fn__97000621_A_fn_class; if fncls__3929 == nil { var fncls__3929d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, nil); A_arbace_cpp_run__main_fn__97000621_A_fn_class = fncls__3929d; tmp3 = fncls__3929d } else { tmp3 = fncls__3929 }; arg_3918 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3930, tmp3, nil); var arg_3919 any = rows__10; if linked_3916 == nil { arg_3914 = ifn_3917.Invoke_O_O__O(arg_3918, arg_3919) } else { arg_3914 = linked_3916.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3915, arg_3918, arg_3919) }; if linked_3912 == nil { bad__11 = ifn_3913.Invoke_O__O(arg_3914) } else { bad__11 = linked_3912.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_3911, arg_3914) }
//line :551:1
			var seq_97000626__12 any; var root_3971 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_3972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3971, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3973 lang.IFn





			if linked_3972 == nil { ifn_3973 = lang.IFn_Cast(root_3971) } else { ifn_3973 = nil }; var arg_3974 any = bad__11; if linked_3972 == nil { seq_97000626__12 = ifn_3973.Invoke_O__O(arg_3974) } else { seq_97000626__12 = linked_3972.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3971, arg_3974) }
//line :551:1
			var chunk_97000627__13 any; var count_97000628__14 int64 = 0; var i_97000629__15 int64 = 0; L2: for {





				if lang.Numbers_Lt_J_J__Z_NoInit(i_97000629__15, count_97000628__14) { var b__16 any = lang.Indexed_Cast(chunk_97000627__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_97000629__15)); lang.IFn_Cast(A_arbace_cpp_run_A_const_91.GetRawRoot__O()).Invoke_O_O__O(Lit_7, b__16); seq_97000626__12, chunk_97000627__13, count_97000628__14, i_97000629__15 = seq_97000626__12, chunk_97000627__13, count_97000628__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_97000629__15); continue L2 } else { var temp__1927000414__auto____16 any; var root_3975 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_3976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3975, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3977 lang.IFn; if linked_3976 == nil { ifn_3977 = lang.IFn_Cast(root_3975) } else { ifn_3977 = nil }; var arg_3978 any = seq_97000626__12; if linked_3976 == nil { temp__1927000414__auto____16 = ifn_3977.Invoke_O__O(arg_3978) } else { temp__1927000414__auto____16 = linked_3976.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3975, arg_3978) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_97000626__17 any = temp__1927000414__auto____16; var tmp4 any; var root_3979 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_3980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3979, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3981 lang.IFn; if linked_3980 == nil { ifn_3981 = lang.IFn_Cast(root_3979) } else { ifn_3981 = nil }; var arg_3982 any = seq_97000626__17; if linked_3980 == nil { tmp4 = ifn_3981.Invoke_O__O(arg_3982) } else { tmp4 = linked_3980.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3979, arg_3982) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____18 any; var root_3983 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_3984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3983, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3985 lang.IFn; if linked_3984 == nil { ifn_3985 = lang.IFn_Cast(root_3983) } else { ifn_3985 = nil }; var arg_3986 any = seq_97000626__17; if linked_3984 == nil { c__1927000678__auto____18 = ifn_3985.Invoke_O__O(arg_3986) } else { c__1927000678__auto____18 = linked_3984.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3983, arg_3986) }; var tmp5 any; var root_4067 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_4068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4067, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4069 lang.IFn; if linked_4068 == nil { ifn_4069 = lang.IFn_Cast(root_4067) } else { ifn_4069 = nil }; var arg_4070 any = seq_97000626__17; if linked_4068 == nil { tmp5 = ifn_4069.Invoke_O__O(arg_4070) } else { tmp5 = linked_4068.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4067, arg_4070) }; seq_97000626__12, chunk_97000627__13, count_97000628__14, i_97000629__15 = tmp5, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var b__18 any; var root_3987 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_3988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3987, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3989 lang.IFn; if linked_3988 == nil { ifn_3989 = lang.IFn_Cast(root_3987) } else { ifn_3989 = nil }; var arg_3990 any = seq_97000626__17; if linked_3988 == nil { b__18 = ifn_3989.Invoke_O__O(arg_3990) } else { b__18 = linked_3988.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3987, arg_3990) }; lang.IFn_Cast(A_arbace_cpp_run_A_const_91.GetRawRoot__O()).Invoke_O_O__O(Lit_7, b__18); var tmp6 any; var root_4076 any = A_arbace_cpp_run_A_const_67.GetRawRoot__O(); var linked_4077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4076, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4078 lang.IFn; if linked_4077 == nil { ifn_4078 = lang.IFn_Cast(root_4076) } else { ifn_4078 = nil }; var arg_4079 any = seq_97000626__17; if linked_4077 == nil { tmp6 = ifn_4078.Invoke_O__O(arg_4079) } else { tmp6 = linked_4077.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4076, arg_4079) }; seq_97000626__12, chunk_97000627__13, count_97000628__14, i_97000629__15 = tmp6, nil, 0, 0; continue L2 } } }
//line :551:1
				break L2
			}





			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_35.GetRawRoot__O()); var tmp8 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_8), jrt.RefArrayOf(jrt.Object_class, dir__7, nil)).Ref(); var tmp9 any; var root_3996 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_3997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3996, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_3998 lang.IFn; if linked_3997 == nil { ifn_3998 = lang.IFn_Cast(root_3996) } else { ifn_3998 = nil }; var arg_3999 any; var iter__1927001039__auto____12 any; var fnbody__4061 any = A_arbace_cpp_run__main_iter__97000630__97000634_A_New(); var tmp10 *jrt.Class; var fncls__4060 *jrt.Class = A_arbace_cpp_run__main_iter__97000630__97000634_A_fn_class; if fncls__4060 == nil { var fncls__4060d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); A_arbace_cpp_run__main_iter__97000630__97000634_A_fn_class = fncls__4060d; tmp10 = fncls__4060d } else { tmp10 = fncls__4060 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4061, tmp10, nil); arg_3999 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(rows__10); if linked_3997 == nil { tmp9 = ifn_3998.Invoke_O__O(arg_3999) } else { tmp9 = linked_3997.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_3996, arg_3999) }; tmp7.Invoke_O_O__O(tmp8, tmp9)
			var tmp11 int64; var tmp12 any; var and__1927000168__auto____12 any; var root_3931 any = A_arbace_cpp_run_A_const_108.GetRawRoot__O(); var linked_3932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3931, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3933 lang.IFn; if linked_3932 == nil { ifn_3933 = lang.IFn_Cast(root_3931) } else { ifn_3933 = nil }; var arg_3934 any = bad__11; if linked_3932 == nil { and__1927000168__auto____12 = ifn_3933.Invoke_O__O(arg_3934) } else { and__1927000168__auto____12 = linked_3932.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3931, arg_3934) }; if jrt.J2g_Truth(and__1927000168__auto____12) { var root_3935 any = A_arbace_cpp_run_A_const_234.GetRawRoot__O(); var linked_3936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3935, A_arbace_cpp_run_read_lib_A_fn_class); var ifn_3937 lang.IFn; if linked_3936 == nil { ifn_3937 = lang.IFn_Cast(root_3935) } else { ifn_3937 = nil }; var arg_3938 any = h__3; var arg_3939 any = dir__7; var arg_3940 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_8), jrt.RefArrayOf(jrt.Object_class, dir__7, nil)).Ref(); var arg_3941 any = lang.IFn_Cast(th__4).Invoke_O__O(t__9); if linked_3936 == nil { tmp12 = ifn_3937.Invoke_O_O_O_O__O(arg_3938, arg_3939, arg_3940, arg_3941) } else { tmp12 = linked_3936.(*A_arbace_cpp_run_read_lib_A).Invoke_O_O_O_O_O__O(root_3935, arg_3938, arg_3939, arg_3940, arg_3941) } } else { tmp12 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp12) { tmp11 = 0 } else { tmp11 = 1 }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(tmp11))
//line :551:1
			break L1 }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__97000611__5_, Lit_10) { var vec__97000646__6 any = args__1; var rt__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000646__6, lang.RT_IntCast_J__I_NoInit(0), nil); var xdir__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000646__6, lang.RT_IntCast_J__I_NoInit(1), nil); var out__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000646__6, lang.RT_IntCast_J__I_NoInit(2), nil); var path__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000646__6, lang.RT_IntCast_J__I_NoInit(3), nil); var vec__97000649__11 any; var root_3942 any = A_arbace_cpp_run_A_const_222.GetRawRoot__O(); var linked_3943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3942, A_arbace_cpp_run_build_one_A_fn_class); var ifn_3944 lang.IFn












				if linked_3943 == nil { ifn_3944 = lang.IFn_Cast(root_3942) } else { ifn_3944 = nil }; var arg_3945 any = h__3; var arg_3946 any; var fnbody__3954 any = A_arbace_cpp_run__main_fn__97000652_A_New_O_O_O(h__3, xdir__8, rt__7); var tmp13 *jrt.Class; var fncls__3953 *jrt.Class = A_arbace_cpp_run__main_fn__97000652_A_fn_class; if fncls__3953 == nil { var fncls__3953d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__3954); A_arbace_cpp_run__main_fn__97000652_A_fn_class = fncls__3953d; tmp13 = fncls__3953d } else { tmp13 = fncls__3953 }; arg_3946 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3954, tmp13, nil); var arg_3947 any = path__10; if linked_3943 == nil { vec__97000649__11 = ifn_3944.Invoke_O_O_O__O(arg_3945, arg_3946, arg_3947) } else { vec__97000649__11 = linked_3943.(*A_arbace_cpp_run_build_one_A).Invoke_O_O_O_O__O(root_3942, arg_3945, arg_3946, arg_3947) }
//line :551:1
				var st__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000649__11, lang.RT_IntCast_J__I_NoInit(0), nil); var cls__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000649__11, lang.RT_IntCast_J__I_NoInit(1), nil); var msg__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000649__11, lang.RT_IntCast_J__I_NoInit(2), nil); var ___15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000649__11, lang.RT_IntCast_J__I_NoInit(3), nil); var s__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000649__11, lang.RT_IntCast_J__I_NoInit(4), nil); var cmds__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000649__11, lang.RT_IntCast_J__I_NoInit(5), nil); _ = ___15













				if jrt.J2g_Truth(cmds__17) {
					var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_35.GetRawRoot__O()); var tmp15 any; var root_4085 any = A_arbace_cpp_run_A_const_223.GetRawRoot__O(); var linked_4086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4085, aot_arbace_c_build.A_arbace_c_build_program_text_A_fn_class); var ifn_4087 lang.IFn; if linked_4086 == nil { ifn_4087 = lang.IFn_Cast(root_4085) } else { ifn_4087 = nil }; var arg_4088 any = cmds__17; if linked_4086 == nil { tmp15 = ifn_4087.Invoke_O__O(arg_4088) } else { tmp15 = linked_4086.(*aot_arbace_c_build.A_arbace_c_build_program_text_A).Invoke_O_O__O(root_4085, arg_4088) }; tmp14.Invoke_O_O__O(out__9, tmp15); lang.IFn_Cast(A_arbace_cpp_run_A_const_91.GetRawRoot__O()).Invoke_O_O_O__O(Lit_12, s__16, Lit_13) } else {
						var root_4102 any = A_arbace_cpp_run_A_const_93.GetRawRoot__O(); var linked_4103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4102, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4104 lang.IFn; if linked_4103 == nil { ifn_4104 = lang.IFn_Cast(root_4102) } else { ifn_4104 = nil }; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_94.GetRawRoot__O()); var tmp17 any = A_arbace_cpp_run_A_const_95; var arg_4105 any = tmp16.Invoke_O_O__O(tmp17, A_arbace_cpp_run_A_const_96.Get__O()); if linked_4103 == nil { ifn_4104.Invoke_O__O(arg_4105) } else { linked_4103.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4102, arg_4105) }; var tmp18 *lang.Compiler_AOTFn; var fnbody__4101 any = A_arbace_cpp_run__main_fn__97000654_A_New_O_O_O(msg__14, st__12, cls__13); var tmp19 *jrt.Class; var fncls__4100 *jrt.Class = A_arbace_cpp_run__main_fn__97000654_A_fn_class; if fncls__4100 == nil { var fncls__4100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__4101); A_arbace_cpp_run__main_fn__97000654_A_fn_class = fncls__4100d; tmp19 = fncls__4100d } else { tmp19 = fncls__4100 }; tmp18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4101, tmp19, nil); Up_Compiler_AOTFn_IFn(tmp18).Invoke__O(); jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(1)) }
//line :551:1
				break L1 }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__97000611__5_, Lit_15) { var vec__97000656__6 any = args__1; var dir__7_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000656__6, lang.RT_IntCast_J__I_NoInit(0), nil); var list__8_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000656__6, lang.RT_IntCast_J__I_NoInit(1), nil); var t__9_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000656__6, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp20 int64; var tmp21 any; var root_3961 any = A_arbace_cpp_run_A_const_234.GetRawRoot__O(); var linked_3962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3961, A_arbace_cpp_run_read_lib_A_fn_class); var ifn_3963 lang.IFn
					if linked_3962 == nil { ifn_3963 = lang.IFn_Cast(root_3961) } else { ifn_3963 = nil }; var arg_3964 any = h__3; var arg_3965 any = dir__7_2; var arg_3966 any = list__8_2; var arg_3967 any = lang.IFn_Cast(th__4).Invoke_O__O(t__9_2); if linked_3962 == nil { tmp21 = ifn_3963.Invoke_O_O_O_O__O(arg_3964, arg_3965, arg_3966, arg_3967) } else { tmp21 = linked_3962.(*A_arbace_cpp_run_read_lib_A).Invoke_O_O_O_O_O__O(root_3961, arg_3964, arg_3965, arg_3966, arg_3967) }; if jrt.J2g_Truth(tmp21) { tmp20 = 0 } else { tmp20 = 1 }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(tmp20))
//line :551:1
					break L1 }; case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__97000611__5_, Lit_16) { var vec__97000659__6 any = args__1; var work__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000659__6, lang.RT_IntCast_J__I_NoInit(0), nil); var list__8_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000659__6, lang.RT_IntCast_J__I_NoInit(1), nil); var rt__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000659__6, lang.RT_IntCast_J__I_NoInit(2), nil); var t__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000659__6, lang.RT_IntCast_J__I_NoInit(3), nil); var root_4111 any = A_arbace_cpp_run_A_const_236.GetRawRoot__O(); var linked_4112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4111, A_arbace_cpp_run_nodes_list_A_fn_class); var ifn_4113 lang.IFn









						if linked_4112 == nil { ifn_4113 = lang.IFn_Cast(root_4111) } else { ifn_4113 = nil }; var arg_4114 any = h__3; var arg_4115 any = work__7; var arg_4116 any = list__8_3; var arg_4117 any = rt__9; var arg_4118 any = lang.IFn_Cast(th__4).Invoke_O__O(t__10); if linked_4112 == nil { ifn_4113.Invoke_O_O_O_O_O__O(arg_4114, arg_4115, arg_4116, arg_4117, arg_4118) } else { linked_4112.(*A_arbace_cpp_run_nodes_list_A).Invoke_O_O_O_O_O_O__O(root_4111, arg_4114, arg_4115, arg_4116, arg_4117, arg_4118) }
//line :551:1
						break L1 }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__97000611__5_, Lit_17) { var vec__97000662__6 any = args__1; var out__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000662__6, lang.RT_IntCast_J__I_NoInit(0), nil); var list__8_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000662__6, lang.RT_IntCast_J__I_NoInit(1), nil); var rt__9_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000662__6, lang.RT_IntCast_J__I_NoInit(2), nil); var t__10_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000662__6, lang.RT_IntCast_J__I_NoInit(3), nil); var root_4119 any = A_arbace_cpp_run_A_const_237.GetRawRoot__O(); var linked_4120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4119, A_arbace_cpp_run_compile_list_A_fn_class); var ifn_4121 lang.IFn










							if linked_4120 == nil { ifn_4121 = lang.IFn_Cast(root_4119) } else { ifn_4121 = nil }; var arg_4122 any = h__3; var arg_4123 any = out__7; var arg_4124 any = list__8_4; var arg_4125 any = rt__9_2; var arg_4126 any = lang.IFn_Cast(th__4).Invoke_O__O(t__10_2); if linked_4120 == nil { ifn_4121.Invoke_O_O_O_O_O__O(arg_4122, arg_4123, arg_4124, arg_4125, arg_4126) } else { linked_4120.(*A_arbace_cpp_run_compile_list_A).Invoke_O_O_O_O_O_O__O(root_4119, arg_4122, arg_4123, arg_4124, arg_4125, arg_4126) }
//line :551:1
							break L1 }; default:
	}















		lang.IFn_Cast(A_arbace_cpp_run_A_const_91.GetRawRoot__O()).Invoke_O__O(Lit_18); jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2))}; var root_3968 any =
	A_arbace_cpp_run_A_const_235.GetRawRoot__O(); var linked_3969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3968, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_3970 lang.IFn; if linked_3969 == nil { ifn_3970 = lang.IFn_Cast(root_3968) } else { ifn_3970 = nil }; if linked_3969 == nil { ifn_3970.Invoke__O() } else { linked_3969.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_3968) };
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(0)); return nil }
//line :549:1
func A_arbace_cpp_run__main_th__97000609_A_New() *A_arbace_cpp_run__main_th__97000609_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run__main_th__97000609_A{}; t.Ctor(); return t }
//line :549:1
func (t *A_arbace_cpp_run__main_th__97000609_A) Ctor() {}
//line :549:1
func (t *A_arbace_cpp_run__main_th__97000609_A) Invoke_O_O__O(self, p1__97000607_SHARP___1 any) any {
	var tmp1 any; var or__1927000174__auto____2 any = p1__97000607_SHARP___1; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = Lit_27 }; return jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp1))).Ref()
}



func A_arbace_cpp_run__main_fn__97000618_A_New() *A_arbace_cpp_run__main_fn__97000618_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run__main_fn__97000618_A{}; t.Ctor(); return t }
//line :555:1
func (t *A_arbace_cpp_run__main_fn__97000618_A) Ctor() {}
//line :555:1
func (t *A_arbace_cpp_run__main_fn__97000618_A) Invoke_O_O__O(self, p1__97000608_SHARP___1 any) any { var root_3891 any = A_arbace_cpp_run_A_const_40.GetRawRoot__O(); var linked_3892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3891, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_3893 lang.IFn; if linked_3892 == nil { ifn_3893 = lang.IFn_Cast(root_3891) } else { ifn_3893 = nil }; var arg_3894 any = p1__97000608_SHARP___1; var arg_3895 any = A_arbace_cpp_run_A_const_233; if linked_3892 == nil { return ifn_3893.Invoke_O_O__O(arg_3894, arg_3895) } else { return linked_3892.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_3891, arg_3894, arg_3895) } }
func A_arbace_cpp_run__main_fn__97000621_A_New() *A_arbace_cpp_run__main_fn__97000621_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run__main_fn__97000621_A{}; t.Ctor(); return t }
//line :556:1
func (t *A_arbace_cpp_run__main_fn__97000621_A) Ctor() {}
//line :556:1
func (t *A_arbace_cpp_run__main_fn__97000621_A) Invoke_O_O__O(self, p__97000620__1 any) any { var vec__97000622__2 any = p__97000620__1; var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000622__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ll__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000622__2, lang.RT_IntCast_J__I_NoInit(1), nil); var temp__1927000414__auto____5 any; var root_3920 any = A_arbace_cpp_run_A_const_204.GetRawRoot__O(); var linked_3921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3920, A_arbace_cpp_run_lower_ll_A_fn_class); var ifn_3922 lang.IFn; if linked_3921 == nil { ifn_3922 = lang.IFn_Cast(root_3920) } else { ifn_3922 = nil }; var arg_3923 any = ll__4; if linked_3921 == nil { temp__1927000414__auto____5 = ifn_3922.Invoke_O__O(arg_3923) } else { temp__1927000414__auto____5 = linked_3921.(*A_arbace_cpp_run_lower_ll_A).Invoke_O_O__O(root_3920, arg_3923) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var r__6 any = temp__1927000414__auto____5; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_19, nil); var tmp2 any; var root_3924 any = A_arbace_cpp_run_A_const_52.GetRawRoot__O(); var linked_3925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3924, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_3926 lang.IFn; if linked_3925 == nil { ifn_3926 = lang.IFn_Cast(root_3924) } else { ifn_3926 = nil }; var arg_3927 any = Lit_20; var arg_3928 any = r__6; if linked_3925 == nil { tmp2 = ifn_3926.Invoke_O_O__O(arg_3927, arg_3928) } else { tmp2 = linked_3925.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_3924, arg_3927, arg_3928) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, n__3, nil, tmp2)).Ref() } else { return nil } }

func A_arbace_cpp_run__main_iter__97000630__97000634_A_New() *A_arbace_cpp_run__main_iter__97000630__97000634_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run__main_iter__97000630__97000634_A{}; t.Ctor(); return t }
//line :558:1
func (t *A_arbace_cpp_run__main_iter__97000630__97000634_A) Ctor() {}
//line :558:1
func (t *A_arbace_cpp_run__main_iter__97000630__97000634_A) Invoke_O_O__O(self, s__97000631__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__4059 any = A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_A_New_O_O(s__97000631__1, self); var tmp2 *jrt.Class; var fncls__4058 *jrt.Class = A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_A_fn_class; if fncls__4058 == nil { var fncls__4058d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__4059); A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_A_fn_class = fncls__4058d; tmp2 = fncls__4058d } else { tmp2 = fncls__4058 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4059, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :558:1
func A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_A_New_O_O(p0, p1 any) *A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_A{}; t.Ctor_O_O(p0, p1); return t }
//line :558:1
func (t *A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_A) Ctor_O_O(c__s__97000631, c__iter__97000630 any) { t.F_s__97000631 = c__s__97000631; t.F_iter__97000630 = c__iter__97000630 }
//line :558:1
func (t *A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_A) Invoke_O__O(self any) any { { var s__97000631__1 any; var t_ any = t.F_s__97000631; t.F_s__97000631 = nil; s__97000631__1 = t_; for { var temp__1927000414__auto____2 any; var root_4000 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_4001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4000, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4002 lang.IFn; if linked_4001 == nil { ifn_4002 = lang.IFn_Cast(root_4000) } else { ifn_4002 = nil }; var arg_4003 any = s__97000631__1; if linked_4001 == nil { temp__1927000414__auto____2 = ifn_4002.Invoke_O__O(arg_4003) } else { temp__1927000414__auto____2 = linked_4001.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4000, arg_4003) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__97000631__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4004 any = A_arbace_cpp_run_A_const_21.GetRawRoot__O(); var linked_4005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4004, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4006 lang.IFn; if linked_4005 == nil { ifn_4006 = lang.IFn_Cast(root_4004) } else { ifn_4006 = nil }; var arg_4007 any = s__97000631__3; if linked_4005 == nil { tmp1 = ifn_4006.Invoke_O__O(arg_4007) } else { tmp1 = linked_4005.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4004, arg_4007) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4008 any = A_arbace_cpp_run_A_const_22.GetRawRoot__O(); var linked_4009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4008, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4010 lang.IFn; if linked_4009 == nil { ifn_4010 = lang.IFn_Cast(root_4008) } else { ifn_4010 = nil }; var arg_4011 any = s__97000631__3; if linked_4009 == nil { c__1927001037__auto____4 = ifn_4010.Invoke_O__O(arg_4011) } else { c__1927001037__auto____4 = linked_4009.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4008, arg_4011) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__97000633__6 any; var root_4012 any = A_arbace_cpp_run_A_const_23.GetRawRoot__O(); var linked_4013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4012, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4014 lang.IFn; if linked_4013 == nil { ifn_4014 = lang.IFn_Cast(root_4012) } else { ifn_4014 = nil }; var arg_4015 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4013 == nil { b__97000633__6 = ifn_4014.Invoke_O__O(arg_4015) } else { b__97000633__6 = linked_4013.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4012, arg_4015) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__4022 any = A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_fn__97000636_A_New_O_I_O(b__97000633__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4021 *jrt.Class = A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_fn__97000636_A_fn_class; if fncls__4021 == nil { var fncls__4021d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__4022); A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_fn__97000636_A_fn_class = fncls__4021d; tmp3 = fncls__4021d } else { tmp3 = fncls__4021 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4022, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_4023 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_4024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4023, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4025 lang.IFn; if linked_4024 == nil { ifn_4025 = lang.IFn_Cast(root_4023) } else { ifn_4025 = nil }; var arg_4026 any; var root_4028 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_4029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4028, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4030 lang.IFn; if linked_4029 == nil { ifn_4030 = lang.IFn_Cast(root_4028) } else { ifn_4030 = nil }; var arg_4031 any = b__97000633__6; if linked_4029 == nil { arg_4026 = ifn_4030.Invoke_O__O(arg_4031) } else { arg_4026 = linked_4029.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4028, arg_4031) }; var arg_4027 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__97000630); var tmp5 any; var root_4032 any = A_arbace_cpp_run_A_const_27.GetRawRoot__O(); var linked_4033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4032, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4034 lang.IFn; if linked_4033 == nil { ifn_4034 = lang.IFn_Cast(root_4032) } else { ifn_4034 = nil }; var arg_4035 any = s__97000631__3; if linked_4033 == nil { tmp5 = ifn_4034.Invoke_O__O(arg_4035) } else { tmp5 = linked_4033.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4032, arg_4035) }; arg_4027 = tmp4.Invoke_O__O(tmp5); if linked_4024 == nil { return ifn_4025.Invoke_O_O__O(arg_4026, arg_4027) } else { return linked_4024.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4023, arg_4026, arg_4027) } } else { var root_4036 any = A_arbace_cpp_run_A_const_25.GetRawRoot__O(); var linked_4037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4036, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4038 lang.IFn; if linked_4037 == nil { ifn_4038 = lang.IFn_Cast(root_4036) } else { ifn_4038 = nil }; var arg_4039 any; var root_4041 any = A_arbace_cpp_run_A_const_26.GetRawRoot__O(); var linked_4042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4041, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4043 lang.IFn; if linked_4042 == nil { ifn_4043 = lang.IFn_Cast(root_4041) } else { ifn_4043 = nil }; var arg_4044 any = b__97000633__6; if linked_4042 == nil { arg_4039 = ifn_4043.Invoke_O__O(arg_4044) } else { arg_4039 = linked_4042.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4041, arg_4044) }; var arg_4040 any; if linked_4037 == nil { return ifn_4038.Invoke_O_O__O(arg_4039, arg_4040) } else { return linked_4037.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4036, arg_4039, arg_4040) } } } else { var vec__97000641__4 any; var root_4045 any = A_arbace_cpp_run_A_const_20.GetRawRoot__O(); var linked_4046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4045, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4047 lang.IFn; if linked_4046 == nil { ifn_4047 = lang.IFn_Cast(root_4045) } else { ifn_4047 = nil }; var arg_4048 any = s__97000631__3; if linked_4046 == nil { vec__97000641__4 = ifn_4047.Invoke_O__O(arg_4048) } else { vec__97000641__4 = linked_4046.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4045, arg_4048) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000641__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ll__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000641__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4049 any = A_arbace_cpp_run_A_const_28.GetRawRoot__O(); var linked_4050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4049, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4051 lang.IFn; if linked_4050 == nil { ifn_4051 = lang.IFn_Cast(root_4049) } else { ifn_4051 = nil }; var arg_4052 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_25, nil, Lit_26), jrt.RefArrayOf(jrt.Object_class, n__5, nil, jrt.File_New_String(jrt.String_Cast(ll__6)).GetParent__String().Ref(), nil)).Ref(); var arg_4053 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__97000630); var tmp7 any; var root_4054 any = A_arbace_cpp_run_A_const_29.GetRawRoot__O(); var linked_4055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4054, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4056 lang.IFn; if linked_4055 == nil { ifn_4056 = lang.IFn_Cast(root_4054) } else { ifn_4056 = nil }; var arg_4057 any = s__97000631__3; if linked_4055 == nil { tmp7 = ifn_4056.Invoke_O__O(arg_4057) } else { tmp7 = linked_4055.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4054, arg_4057) }; arg_4053 = tmp6.Invoke_O__O(tmp7); if linked_4050 == nil { return ifn_4051.Invoke_O_O__O(arg_4052, arg_4053) } else { return linked_4050.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4049, arg_4052, arg_4053) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :558:1
func A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_fn__97000636_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_fn__97000636_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_fn__97000636_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :558:1
func (t *A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_fn__97000636_A) Ctor_O_I_O(c__b__97000633 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__97000633 = c__b__97000633; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :558:1
func (t *A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_fn__97000636_A) Invoke_O__O(self any) any { { var i__97000632__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__97000632__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__97000637__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__97000632__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000637__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ll__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__97000637__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_4016 any = A_arbace_cpp_run_A_const_24.GetRawRoot__O(); var linked_4017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4016, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4018 lang.IFn; if linked_4017 == nil { ifn_4018 = lang.IFn_Cast(root_4016) } else { ifn_4018 = nil }; var arg_4019 any = t.F_b__97000633; var arg_4020 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_25, nil, Lit_26), jrt.RefArrayOf(jrt.Object_class, n__3, nil, jrt.File_New_String(jrt.String_Cast(ll__4)).GetParent__String().Ref(), nil)).Ref(); if linked_4017 == nil { ifn_4018.Invoke_O_O__O(arg_4019, arg_4020) } else { linked_4017.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4016, arg_4019, arg_4020) }; i__97000632__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__97000632__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_cpp_run__main_fn__97000652_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_run__main_fn__97000652_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run__main_fn__97000652_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :564:1
func (t *A_arbace_cpp_run__main_fn__97000652_A) Ctor_O_O_O(c__h, c__xdir, c__rt any) { t.F_h = c__h; t.F_xdir = c__xdir; t.F_rt = c__rt }
//line :564:1
func (t *A_arbace_cpp_run__main_fn__97000652_A) Invoke_O__O(self any) any { var tmp1 any; var root_3948 any = A_arbace_cpp_run_A_const_219.GetRawRoot__O(); var linked_3949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3948, A_arbace_cpp_run_libs_fn_A_fn_class); var ifn_3950 lang.IFn; if linked_3949 == nil { ifn_3950 = lang.IFn_Cast(root_3948) } else { ifn_3950 = nil }; var arg_3951 any = t.F_h; var arg_3952 any = t.F_rt; if linked_3949 == nil { tmp1 = ifn_3950.Invoke_O_O__O(arg_3951, arg_3952) } else { tmp1 = linked_3949.(*A_arbace_cpp_run_libs_fn_A).Invoke_O_O_O__O(root_3948, arg_3951, arg_3952) }; return lang.IFn_Cast(tmp1).Invoke_O__O(t.F_xdir) }


func A_arbace_cpp_run__main_fn__97000654_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_run__main_fn__97000654_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run__main_fn__97000654_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :567:1
func (t *A_arbace_cpp_run__main_fn__97000654_A) Ctor_O_O_O(c__msg, c__st, c__cls any) { t.F_msg = c__msg; t.F_st = c__st; t.F_cls = c__cls }
//line :567:1
func (t *A_arbace_cpp_run__main_fn__97000654_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_cpp_run_A_const_91.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_19, nil); var tmp4 any; var t_ any = t.F_st; t.F_st = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 *jrt.String; var tmp7 any; var root_4093 any = A_arbace_cpp_run_A_const_19.GetRawRoot__O(); var linked_4094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4093, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4095 lang.IFn; if linked_4094 == nil { ifn_4095 = lang.IFn_Cast(root_4093) } else { ifn_4095 = nil }; var arg_4096 any = t.F_cls; if linked_4094 == nil { tmp7 = ifn_4095.Invoke_O__O(arg_4096) } else { tmp7 = linked_4094.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4093, arg_4096) }; if jrt.J2g_Truth(tmp7) { var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_22); var tmp9 any; var t__2 any = t.F_cls; t.F_cls = nil; tmp9 = t__2; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil)) } else { tmp6 = nil }; var tmp10 any = tmp6.Ref(); var tmp11 any; var t__3 any = t.F_msg; t.F_msg = nil; tmp11 = t__3; tmp1 = tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp5, tmp10, nil, tmp11)).Ref()) }; return nil }(); var root_4097 any = A_arbace_cpp_run_A_const_92.GetRawRoot__O(); var linked_4098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4097, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4099 lang.IFn; if linked_4098 == nil { ifn_4099 = lang.IFn_Cast(root_4097) } else { ifn_4099 = nil }; if linked_4098 == nil { ifn_4099.Invoke__O() } else { linked_4098.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4097) }; if tmp12 != nil { panic(tmp12) }; return tmp1 }
































































































































































































































































































































































type A_arbace_cpp_run_A struct{ jrt.Object }

var A_arbace_cpp_run_A_const_pool *jrt.RefArray

var A_arbace_cpp_run_A_const_0 *lang.Var

var A_arbace_cpp_run_A_const_1 any

var A_arbace_cpp_run_A_const_2 *lang.Var

var A_arbace_cpp_run_A_const_3 any

var A_arbace_cpp_run_A_const_4 any

var A_arbace_cpp_run_A_const_5 any

var A_arbace_cpp_run_A_const_6 any

var A_arbace_cpp_run_A_const_7 any

var A_arbace_cpp_run_A_const_8 any

var A_arbace_cpp_run_A_const_9 any

var A_arbace_cpp_run_A_const_10 any

var A_arbace_cpp_run_A_const_11 any

var A_arbace_cpp_run_A_const_12 *lang.Var

var A_arbace_cpp_run_A_const_13 *lang.Var

var A_arbace_cpp_run_A_const_14 *lang.Var

var A_arbace_cpp_run_A_const_15 *lang.Var

var A_arbace_cpp_run_A_const_16 any

var A_arbace_cpp_run_A_const_17 *lang.Var

var A_arbace_cpp_run_A_const_18 any

var A_arbace_cpp_run_A_const_19 *lang.Var

var A_arbace_cpp_run_A_const_20 *lang.Var

var A_arbace_cpp_run_A_const_21 *lang.Var

var A_arbace_cpp_run_A_const_22 *lang.Var

var A_arbace_cpp_run_A_const_23 *lang.Var

var A_arbace_cpp_run_A_const_24 *lang.Var

var A_arbace_cpp_run_A_const_25 *lang.Var

var A_arbace_cpp_run_A_const_26 *lang.Var

var A_arbace_cpp_run_A_const_27 *lang.Var

var A_arbace_cpp_run_A_const_28 *lang.Var

var A_arbace_cpp_run_A_const_29 *lang.Var

var A_arbace_cpp_run_A_const_30 *lang.Var

var A_arbace_cpp_run_A_const_31 any

var A_arbace_cpp_run_A_const_32 *lang.Var

var A_arbace_cpp_run_A_const_33 *lang.Keyword

var A_arbace_cpp_run_A_const_34 *lang.Var

var A_arbace_cpp_run_A_const_35 *lang.Var

var A_arbace_cpp_run_A_const_36 *lang.Var

var A_arbace_cpp_run_A_const_37 *lang.Var

var A_arbace_cpp_run_A_const_38 any

var A_arbace_cpp_run_A_const_39 *lang.Var

var A_arbace_cpp_run_A_const_40 *lang.Var

var A_arbace_cpp_run_A_const_41 any

var A_arbace_cpp_run_A_const_42 any

var A_arbace_cpp_run_A_const_43 *lang.Var

var A_arbace_cpp_run_A_const_44 *lang.Var

var A_arbace_cpp_run_A_const_45 *lang.Var

var A_arbace_cpp_run_A_const_46 *lang.Var

var A_arbace_cpp_run_A_const_47 *lang.Var

var A_arbace_cpp_run_A_const_48 *lang.Var

var A_arbace_cpp_run_A_const_49 *lang.Var

var A_arbace_cpp_run_A_const_50 *lang.Var

var A_arbace_cpp_run_A_const_51 *lang.Keyword

var A_arbace_cpp_run_A_const_52 *lang.Var

var A_arbace_cpp_run_A_const_53 *lang.Var

var A_arbace_cpp_run_A_const_54 any

var A_arbace_cpp_run_A_const_55 *lang.Keyword

var A_arbace_cpp_run_A_const_56 *lang.Var

var A_arbace_cpp_run_A_const_57 *lang.Keyword

var A_arbace_cpp_run_A_const_58 *lang.Keyword

var A_arbace_cpp_run_A_const_59 *lang.Var

var A_arbace_cpp_run_A_const_60 *lang.Var

var A_arbace_cpp_run_A_const_61 *lang.Var

var A_arbace_cpp_run_A_const_62 *lang.Var

var A_arbace_cpp_run_A_const_63 *lang.Var

var A_arbace_cpp_run_A_const_64 *lang.Var

var A_arbace_cpp_run_A_const_65 *lang.Keyword

var A_arbace_cpp_run_A_const_66 *lang.Var

var A_arbace_cpp_run_A_const_67 *lang.Var

var A_arbace_cpp_run_A_const_68 *lang.Var

var A_arbace_cpp_run_A_const_69 *lang.Var

var A_arbace_cpp_run_A_const_70 *lang.Keyword

var A_arbace_cpp_run_A_const_71 *lang.Var

var A_arbace_cpp_run_A_const_72 any

var A_arbace_cpp_run_A_const_73 *lang.Var

var A_arbace_cpp_run_A_const_74 *lang.Keyword

var A_arbace_cpp_run_A_const_75 *lang.Var

var A_arbace_cpp_run_A_const_76 any

var A_arbace_cpp_run_A_const_77 *lang.Var

var A_arbace_cpp_run_A_const_78 *lang.Var

var A_arbace_cpp_run_A_const_79 *lang.Var

var A_arbace_cpp_run_A_const_80 *lang.Var

var A_arbace_cpp_run_A_const_81 any

var A_arbace_cpp_run_A_const_82 *lang.Var

var A_arbace_cpp_run_A_const_83 *lang.Var

var A_arbace_cpp_run_A_const_84 *lang.Var

var A_arbace_cpp_run_A_const_85 *lang.Var

var A_arbace_cpp_run_A_const_86 *lang.Var

var A_arbace_cpp_run_A_const_87 *lang.Var

var A_arbace_cpp_run_A_const_88 *lang.Var

var A_arbace_cpp_run_A_const_89 *lang.Var

var A_arbace_cpp_run_A_const_90 any

var A_arbace_cpp_run_A_const_91 *lang.Var

var A_arbace_cpp_run_A_const_92 *lang.Var

var A_arbace_cpp_run_A_const_93 *lang.Var

var A_arbace_cpp_run_A_const_94 *lang.Var

var A_arbace_cpp_run_A_const_95 *lang.Var

var A_arbace_cpp_run_A_const_96 *lang.Var

var A_arbace_cpp_run_A_const_97 *lang.Var

var A_arbace_cpp_run_A_const_98 *lang.Var

var A_arbace_cpp_run_A_const_99 *lang.Var

var A_arbace_cpp_run_A_const_100 *lang.Var

var A_arbace_cpp_run_A_const_101 *lang.Var

var A_arbace_cpp_run_A_const_102 *lang.Keyword

var A_arbace_cpp_run_A_const_103 *lang.Var

var A_arbace_cpp_run_A_const_104 *lang.Keyword

var A_arbace_cpp_run_A_const_105 *lang.Var

var A_arbace_cpp_run_A_const_106 *lang.Var

var A_arbace_cpp_run_A_const_107 *lang.Var

var A_arbace_cpp_run_A_const_108 *lang.Var

var A_arbace_cpp_run_A_const_109 *lang.Var

var A_arbace_cpp_run_A_const_110 *lang.Var

var A_arbace_cpp_run_A_const_111 *lang.Var

var A_arbace_cpp_run_A_const_112 *lang.Keyword

var A_arbace_cpp_run_A_const_113 *lang.Keyword

var A_arbace_cpp_run_A_const_114 *lang.Keyword

var A_arbace_cpp_run_A_const_115 *lang.Keyword

var A_arbace_cpp_run_A_const_116 *lang.Var

var A_arbace_cpp_run_A_const_117 *lang.Keyword

var A_arbace_cpp_run_A_const_118 *lang.Var

var A_arbace_cpp_run_A_const_119 *lang.Var

var A_arbace_cpp_run_A_const_120 any

var A_arbace_cpp_run_A_const_121 any

var A_arbace_cpp_run_A_const_122 any

var A_arbace_cpp_run_A_const_123 *lang.Var

var A_arbace_cpp_run_A_const_124 any

var A_arbace_cpp_run_A_const_125 *lang.Keyword

var A_arbace_cpp_run_A_const_126 any

var A_arbace_cpp_run_A_const_127 any

var A_arbace_cpp_run_A_const_128 *lang.Var

var A_arbace_cpp_run_A_const_129 *lang.Var

var A_arbace_cpp_run_A_const_130 *lang.Var

var A_arbace_cpp_run_A_const_131 *lang.Var

var A_arbace_cpp_run_A_const_132 *lang.Var

var A_arbace_cpp_run_A_const_133 *lang.Var

var A_arbace_cpp_run_A_const_134 *lang.Keyword

var A_arbace_cpp_run_A_const_135 any

var A_arbace_cpp_run_A_const_136 *lang.Var

var A_arbace_cpp_run_A_const_137 *lang.Var

var A_arbace_cpp_run_A_const_138 *lang.Var

var A_arbace_cpp_run_A_const_139 *lang.Keyword

var A_arbace_cpp_run_A_const_140 *lang.Var

var A_arbace_cpp_run_A_const_141 *lang.Var

var A_arbace_cpp_run_A_const_142 *lang.Var

var A_arbace_cpp_run_A_const_143 *lang.Keyword

var A_arbace_cpp_run_A_const_144 *lang.Keyword

var A_arbace_cpp_run_A_const_145 *lang.Var

var A_arbace_cpp_run_A_const_146 *lang.Var

var A_arbace_cpp_run_A_const_147 any

var A_arbace_cpp_run_A_const_148 *lang.Var

var A_arbace_cpp_run_A_const_149 any

var A_arbace_cpp_run_A_const_150 *lang.Var

var A_arbace_cpp_run_A_const_151 any

var A_arbace_cpp_run_A_const_152 any

var A_arbace_cpp_run_A_const_153 *lang.Keyword

var A_arbace_cpp_run_A_const_154 any

var A_arbace_cpp_run_A_const_155 *lang.Var

var A_arbace_cpp_run_A_const_156 *lang.Keyword

var A_arbace_cpp_run_A_const_157 *lang.Var

var A_arbace_cpp_run_A_const_158 *lang.Var

var A_arbace_cpp_run_A_const_159 *lang.Var

var A_arbace_cpp_run_A_const_160 *lang.Var

var A_arbace_cpp_run_A_const_161 any

var A_arbace_cpp_run_A_const_162 *lang.Var

var A_arbace_cpp_run_A_const_163 any

var A_arbace_cpp_run_A_const_164 any

var A_arbace_cpp_run_A_const_165 *lang.Var

var A_arbace_cpp_run_A_const_166 *lang.Var

var A_arbace_cpp_run_A_const_167 any

var A_arbace_cpp_run_A_const_168 *lang.Var

var A_arbace_cpp_run_A_const_169 *lang.Var

var A_arbace_cpp_run_A_const_170 *lang.Var

var A_arbace_cpp_run_A_const_171 *lang.Var

var A_arbace_cpp_run_A_const_172 *lang.Var

var A_arbace_cpp_run_A_const_173 *lang.Keyword

var A_arbace_cpp_run_A_const_174 *lang.Var

var A_arbace_cpp_run_A_const_175 *lang.Keyword

var A_arbace_cpp_run_A_const_176 *lang.Keyword

var A_arbace_cpp_run_A_const_177 *lang.Keyword

var A_arbace_cpp_run_A_const_178 any

var A_arbace_cpp_run_A_const_179 *lang.Var

var A_arbace_cpp_run_A_const_180 *lang.Var

var A_arbace_cpp_run_A_const_181 any

var A_arbace_cpp_run_A_const_182 *lang.Var

var A_arbace_cpp_run_A_const_183 *lang.Var

var A_arbace_cpp_run_A_const_184 *lang.Var

var A_arbace_cpp_run_A_const_185 *lang.Var

var A_arbace_cpp_run_A_const_186 *lang.Var

var A_arbace_cpp_run_A_const_187 *lang.Var

var A_arbace_cpp_run_A_const_188 *lang.Var

var A_arbace_cpp_run_A_const_189 any

var A_arbace_cpp_run_A_const_190 *lang.Var

var A_arbace_cpp_run_A_const_191 any

var A_arbace_cpp_run_A_const_192 *lang.Var

var A_arbace_cpp_run_A_const_193 *lang.Keyword

var A_arbace_cpp_run_A_const_194 *lang.Keyword

var A_arbace_cpp_run_A_const_195 any

var A_arbace_cpp_run_A_const_196 *lang.Keyword

var A_arbace_cpp_run_A_const_197 *lang.Keyword

var A_arbace_cpp_run_A_const_198 *lang.Var

var A_arbace_cpp_run_A_const_199 *lang.Keyword

var A_arbace_cpp_run_A_const_200 *lang.Var

var A_arbace_cpp_run_A_const_201 *lang.Var

var A_arbace_cpp_run_A_const_202 *lang.Keyword

var A_arbace_cpp_run_A_const_203 *lang.Var

var A_arbace_cpp_run_A_const_204 *lang.Var

var A_arbace_cpp_run_A_const_205 *lang.Var

var A_arbace_cpp_run_A_const_206 *lang.Var

var A_arbace_cpp_run_A_const_207 *lang.Var

var A_arbace_cpp_run_A_const_208 *lang.Var

var A_arbace_cpp_run_A_const_209 *lang.Keyword

var A_arbace_cpp_run_A_const_210 *lang.Var

var A_arbace_cpp_run_A_const_211 *lang.Keyword

var A_arbace_cpp_run_A_const_212 *lang.Var

var A_arbace_cpp_run_A_const_213 any

var A_arbace_cpp_run_A_const_214 *lang.Var

var A_arbace_cpp_run_A_const_215 *lang.Var

var A_arbace_cpp_run_A_const_216 *lang.Var

var A_arbace_cpp_run_A_const_217 *lang.Var

var A_arbace_cpp_run_A_const_218 *lang.Var

var A_arbace_cpp_run_A_const_219 *lang.Var

var A_arbace_cpp_run_A_const_220 *lang.Var

var A_arbace_cpp_run_A_const_221 any

var A_arbace_cpp_run_A_const_222 *lang.Var

var A_arbace_cpp_run_A_const_223 *lang.Var

var A_arbace_cpp_run_A_const_224 *lang.Var

var A_arbace_cpp_run_A_const_225 any

var A_arbace_cpp_run_A_const_226 any

var A_arbace_cpp_run_A_const_227 any

var A_arbace_cpp_run_A_const_228 *lang.Keyword

var A_arbace_cpp_run_A_const_229 any

var A_arbace_cpp_run_A_const_230 *lang.Keyword

var A_arbace_cpp_run_A_const_231 *lang.Var

var A_arbace_cpp_run_A_const_232 *lang.Var

var A_arbace_cpp_run_A_const_233 any

var A_arbace_cpp_run_A_const_234 *lang.Var

var A_arbace_cpp_run_A_const_235 *lang.Var

var A_arbace_cpp_run_A_const_236 *lang.Var

var A_arbace_cpp_run_A_const_237 *lang.Var

var A_arbace_cpp_run_A_init jrt.ClassInit

func A_arbace_cpp_run_A_Init() { if !A_arbace_cpp_run_A_init.Done() { A_arbace_cpp_run_A_init.Run(A_arbace_cpp_run_A_clinit) } }

func A_arbace_cpp_run_A_clinit() { A_arbace_cpp_run_A_clinit_p0(); A_arbace_cpp_run_A_clinit_p1(); A_arbace_cpp_run_A_clinit_p2(); A_arbace_cpp_run_A_clinit_p3(); A_arbace_cpp_run_A_clinit_p4(); A_arbace_cpp_run_A_clinit_p5(); A_arbace_cpp_run_A_clinit_p6(); A_arbace_cpp_run_A_clinit_p7(); A_arbace_cpp_run_A_clinit_p8(); A_arbace_cpp_run_A_clinit_p9(); A_arbace_cpp_run_A_clinit_p10(); A_arbace_cpp_run_A_clinit_p11(); A_arbace_cpp_run_A_clinit_p12(); A_arbace_cpp_run_A_clinit_p13(); A_arbace_cpp_run_A_clinit_p14(); A_arbace_cpp_run_A_clinit_p15(); A_arbace_cpp_run_A_clinit_p16(); A_arbace_cpp_run_A_clinit_p17(); A_arbace_cpp_run_A_clinit_p18(); A_arbace_cpp_run_A_clinit_p19() }

func A_arbace_cpp_run_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_run_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 308); A_arbace_cpp_run_A_const_0 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[70]); A_arbace_cpp_run_A_const_1 = A_arbace_cpp_run_A_const_pool.A[71]; A_arbace_cpp_run_A_const_2 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[72]); A_arbace_cpp_run_A_const_3 = A_arbace_cpp_run_A_const_pool.A[73]; A_arbace_cpp_run_A_const_4 = A_arbace_cpp_run_A_const_pool.A[74]; A_arbace_cpp_run_A_const_5 = A_arbace_cpp_run_A_const_pool.A[75]; A_arbace_cpp_run_A_const_6 = A_arbace_cpp_run_A_const_pool.A[76]; A_arbace_cpp_run_A_const_7 = A_arbace_cpp_run_A_const_pool.A[77]; A_arbace_cpp_run_A_const_8 = A_arbace_cpp_run_A_const_pool.A[78]; A_arbace_cpp_run_A_const_9 = A_arbace_cpp_run_A_const_pool.A[79]; A_arbace_cpp_run_A_const_10 = A_arbace_cpp_run_A_const_pool.A[80]; A_arbace_cpp_run_A_const_11 = A_arbace_cpp_run_A_const_pool.A[81]; A_arbace_cpp_run_A_const_12 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[82]) }

func A_arbace_cpp_run_A_clinit_p1() { A_arbace_cpp_run_A_const_13 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[83]); A_arbace_cpp_run_A_const_14 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[84]); A_arbace_cpp_run_A_const_15 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[85]); A_arbace_cpp_run_A_const_16 = A_arbace_cpp_run_A_const_pool.A[86]; A_arbace_cpp_run_A_const_17 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[87]); A_arbace_cpp_run_A_const_18 = A_arbace_cpp_run_A_const_pool.A[88]; A_arbace_cpp_run_A_const_19 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[89]); A_arbace_cpp_run_A_const_20 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[90]); A_arbace_cpp_run_A_const_21 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[91]); A_arbace_cpp_run_A_const_22 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[92]); A_arbace_cpp_run_A_const_23 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[93]); A_arbace_cpp_run_A_const_24 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[94]) }

func A_arbace_cpp_run_A_clinit_p2() { A_arbace_cpp_run_A_const_25 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[95]); A_arbace_cpp_run_A_const_26 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[96]); A_arbace_cpp_run_A_const_27 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[97]); A_arbace_cpp_run_A_const_28 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[98]); A_arbace_cpp_run_A_const_29 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[99]); A_arbace_cpp_run_A_const_30 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[100]); A_arbace_cpp_run_A_const_31 = A_arbace_cpp_run_A_const_pool.A[101]; A_arbace_cpp_run_A_const_32 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[102]); A_arbace_cpp_run_A_const_33 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[103]); A_arbace_cpp_run_A_const_34 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[104]); A_arbace_cpp_run_A_const_35 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[105]); A_arbace_cpp_run_A_const_36 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[106]) }

func A_arbace_cpp_run_A_clinit_p3() { A_arbace_cpp_run_A_const_37 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[107]); A_arbace_cpp_run_A_const_38 = A_arbace_cpp_run_A_const_pool.A[108]; A_arbace_cpp_run_A_const_39 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[109]); A_arbace_cpp_run_A_const_40 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[110]); A_arbace_cpp_run_A_const_41 = A_arbace_cpp_run_A_const_pool.A[111]; A_arbace_cpp_run_A_const_42 = A_arbace_cpp_run_A_const_pool.A[112]; A_arbace_cpp_run_A_const_43 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[113]); A_arbace_cpp_run_A_const_44 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[114]); A_arbace_cpp_run_A_const_45 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[115]); A_arbace_cpp_run_A_const_46 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[116]); A_arbace_cpp_run_A_const_47 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[117]); A_arbace_cpp_run_A_const_48 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[118]) }

func A_arbace_cpp_run_A_clinit_p4() { A_arbace_cpp_run_A_const_49 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[119]); A_arbace_cpp_run_A_const_50 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[120]); A_arbace_cpp_run_A_const_51 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[121]); A_arbace_cpp_run_A_const_52 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[122]); A_arbace_cpp_run_A_const_53 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[123]); A_arbace_cpp_run_A_const_54 = A_arbace_cpp_run_A_const_pool.A[124]; A_arbace_cpp_run_A_const_55 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[125]); A_arbace_cpp_run_A_const_56 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[126]); A_arbace_cpp_run_A_const_57 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[127]); A_arbace_cpp_run_A_const_58 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[128]); A_arbace_cpp_run_A_const_59 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[129]); A_arbace_cpp_run_A_const_60 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[130]) }

func A_arbace_cpp_run_A_clinit_p5() { A_arbace_cpp_run_A_const_61 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[131]); A_arbace_cpp_run_A_const_62 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[132]); A_arbace_cpp_run_A_const_63 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[133]); A_arbace_cpp_run_A_const_64 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[134]); A_arbace_cpp_run_A_const_65 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[135]); A_arbace_cpp_run_A_const_66 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[136]); A_arbace_cpp_run_A_const_67 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[137]); A_arbace_cpp_run_A_const_68 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[138]); A_arbace_cpp_run_A_const_69 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[139]); A_arbace_cpp_run_A_const_70 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[140]); A_arbace_cpp_run_A_const_71 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[141]); A_arbace_cpp_run_A_const_72 = A_arbace_cpp_run_A_const_pool.A[142] }

func A_arbace_cpp_run_A_clinit_p6() { A_arbace_cpp_run_A_const_73 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[143]); A_arbace_cpp_run_A_const_74 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[144]); A_arbace_cpp_run_A_const_75 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[145]); A_arbace_cpp_run_A_const_76 = A_arbace_cpp_run_A_const_pool.A[146]; A_arbace_cpp_run_A_const_77 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[147]); A_arbace_cpp_run_A_const_78 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[148]); A_arbace_cpp_run_A_const_79 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[149]); A_arbace_cpp_run_A_const_80 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[150]); A_arbace_cpp_run_A_const_81 = A_arbace_cpp_run_A_const_pool.A[151]; A_arbace_cpp_run_A_const_82 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[152]); A_arbace_cpp_run_A_const_83 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[153]); A_arbace_cpp_run_A_const_84 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[154]) }

func A_arbace_cpp_run_A_clinit_p7() { A_arbace_cpp_run_A_const_85 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[155]); A_arbace_cpp_run_A_const_86 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[156]); A_arbace_cpp_run_A_const_87 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[157]); A_arbace_cpp_run_A_const_88 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[158]); A_arbace_cpp_run_A_const_89 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[159]); A_arbace_cpp_run_A_const_90 = A_arbace_cpp_run_A_const_pool.A[160]; A_arbace_cpp_run_A_const_91 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[161]); A_arbace_cpp_run_A_const_92 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[162]); A_arbace_cpp_run_A_const_93 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[163]); A_arbace_cpp_run_A_const_94 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[164]); A_arbace_cpp_run_A_const_95 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[165]); A_arbace_cpp_run_A_const_96 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[166]) }

func A_arbace_cpp_run_A_clinit_p8() { A_arbace_cpp_run_A_const_97 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[167]); A_arbace_cpp_run_A_const_98 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[168]); A_arbace_cpp_run_A_const_99 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[169]); A_arbace_cpp_run_A_const_100 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[170]); A_arbace_cpp_run_A_const_101 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[171]); A_arbace_cpp_run_A_const_102 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[172]); A_arbace_cpp_run_A_const_103 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[173]); A_arbace_cpp_run_A_const_104 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[174]); A_arbace_cpp_run_A_const_105 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[175]); A_arbace_cpp_run_A_const_106 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[176]); A_arbace_cpp_run_A_const_107 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[177]); A_arbace_cpp_run_A_const_108 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[178]) }

func A_arbace_cpp_run_A_clinit_p9() { A_arbace_cpp_run_A_const_109 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[179]); A_arbace_cpp_run_A_const_110 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[180]); A_arbace_cpp_run_A_const_111 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[181]); A_arbace_cpp_run_A_const_112 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[182]); A_arbace_cpp_run_A_const_113 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[183]); A_arbace_cpp_run_A_const_114 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[184]); A_arbace_cpp_run_A_const_115 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[185]); A_arbace_cpp_run_A_const_116 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[186]); A_arbace_cpp_run_A_const_117 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[187]); A_arbace_cpp_run_A_const_118 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[188]); A_arbace_cpp_run_A_const_119 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[189]); A_arbace_cpp_run_A_const_120 = A_arbace_cpp_run_A_const_pool.A[190] }

func A_arbace_cpp_run_A_clinit_p10() { A_arbace_cpp_run_A_const_121 = A_arbace_cpp_run_A_const_pool.A[191]; A_arbace_cpp_run_A_const_122 = A_arbace_cpp_run_A_const_pool.A[192]; A_arbace_cpp_run_A_const_123 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[193]); A_arbace_cpp_run_A_const_124 = A_arbace_cpp_run_A_const_pool.A[194]; A_arbace_cpp_run_A_const_125 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[195]); A_arbace_cpp_run_A_const_126 = A_arbace_cpp_run_A_const_pool.A[196]; A_arbace_cpp_run_A_const_127 = A_arbace_cpp_run_A_const_pool.A[197]; A_arbace_cpp_run_A_const_128 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[198]); A_arbace_cpp_run_A_const_129 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[199]); A_arbace_cpp_run_A_const_130 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[200]); A_arbace_cpp_run_A_const_131 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[201]); A_arbace_cpp_run_A_const_132 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[202]); A_arbace_cpp_run_A_const_133 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[203]) }

func A_arbace_cpp_run_A_clinit_p11() { A_arbace_cpp_run_A_const_134 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[204]); A_arbace_cpp_run_A_const_135 = A_arbace_cpp_run_A_const_pool.A[205]; A_arbace_cpp_run_A_const_136 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[206]); A_arbace_cpp_run_A_const_137 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[207]); A_arbace_cpp_run_A_const_138 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[208]); A_arbace_cpp_run_A_const_139 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[209]); A_arbace_cpp_run_A_const_140 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[210]); A_arbace_cpp_run_A_const_141 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[211]); A_arbace_cpp_run_A_const_142 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[212]); A_arbace_cpp_run_A_const_143 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[213]); A_arbace_cpp_run_A_const_144 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[214]); A_arbace_cpp_run_A_const_145 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[215]) }

func A_arbace_cpp_run_A_clinit_p12() { A_arbace_cpp_run_A_const_146 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[216]); A_arbace_cpp_run_A_const_147 = A_arbace_cpp_run_A_const_pool.A[217]; A_arbace_cpp_run_A_const_148 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[218]); A_arbace_cpp_run_A_const_149 = A_arbace_cpp_run_A_const_pool.A[219]; A_arbace_cpp_run_A_const_150 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[220]); A_arbace_cpp_run_A_const_151 = A_arbace_cpp_run_A_const_pool.A[221]; A_arbace_cpp_run_A_const_152 = A_arbace_cpp_run_A_const_pool.A[222]; A_arbace_cpp_run_A_const_153 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[223]); A_arbace_cpp_run_A_const_154 = A_arbace_cpp_run_A_const_pool.A[224]; A_arbace_cpp_run_A_const_155 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[225]); A_arbace_cpp_run_A_const_156 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[226]); A_arbace_cpp_run_A_const_157 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[227]); A_arbace_cpp_run_A_const_158 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[228]) }

func A_arbace_cpp_run_A_clinit_p13() { A_arbace_cpp_run_A_const_159 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[229]); A_arbace_cpp_run_A_const_160 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[230]); A_arbace_cpp_run_A_const_161 = A_arbace_cpp_run_A_const_pool.A[231]; A_arbace_cpp_run_A_const_162 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[232]); A_arbace_cpp_run_A_const_163 = A_arbace_cpp_run_A_const_pool.A[233]; A_arbace_cpp_run_A_const_164 = A_arbace_cpp_run_A_const_pool.A[234]; A_arbace_cpp_run_A_const_165 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[235]); A_arbace_cpp_run_A_const_166 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[236]); A_arbace_cpp_run_A_const_167 = A_arbace_cpp_run_A_const_pool.A[237]; A_arbace_cpp_run_A_const_168 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[238]); A_arbace_cpp_run_A_const_169 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[239]); A_arbace_cpp_run_A_const_170 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[240]); A_arbace_cpp_run_A_const_171 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[241]) }

func A_arbace_cpp_run_A_clinit_p14() { A_arbace_cpp_run_A_const_172 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[242]); A_arbace_cpp_run_A_const_173 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[243]); A_arbace_cpp_run_A_const_174 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[244]); A_arbace_cpp_run_A_const_175 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[245]); A_arbace_cpp_run_A_const_176 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[246]); A_arbace_cpp_run_A_const_177 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[247]); A_arbace_cpp_run_A_const_178 = A_arbace_cpp_run_A_const_pool.A[248]; A_arbace_cpp_run_A_const_179 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[249]); A_arbace_cpp_run_A_const_180 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[250]); A_arbace_cpp_run_A_const_181 = A_arbace_cpp_run_A_const_pool.A[251]; A_arbace_cpp_run_A_const_182 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[252]); A_arbace_cpp_run_A_const_183 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[253]) }

func A_arbace_cpp_run_A_clinit_p15() { A_arbace_cpp_run_A_const_184 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[254]); A_arbace_cpp_run_A_const_185 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[255]); A_arbace_cpp_run_A_const_186 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[256]); A_arbace_cpp_run_A_const_187 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[257]); A_arbace_cpp_run_A_const_188 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[258]); A_arbace_cpp_run_A_const_189 = A_arbace_cpp_run_A_const_pool.A[259]; A_arbace_cpp_run_A_const_190 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[260]); A_arbace_cpp_run_A_const_191 = A_arbace_cpp_run_A_const_pool.A[261]; A_arbace_cpp_run_A_const_192 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[262]); A_arbace_cpp_run_A_const_193 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[263]); A_arbace_cpp_run_A_const_194 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[264]); A_arbace_cpp_run_A_const_195 = A_arbace_cpp_run_A_const_pool.A[265] }

func A_arbace_cpp_run_A_clinit_p16() { A_arbace_cpp_run_A_const_196 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[266]); A_arbace_cpp_run_A_const_197 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[267]); A_arbace_cpp_run_A_const_198 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[268]); A_arbace_cpp_run_A_const_199 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[269]); A_arbace_cpp_run_A_const_200 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[270]); A_arbace_cpp_run_A_const_201 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[271]); A_arbace_cpp_run_A_const_202 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[272]); A_arbace_cpp_run_A_const_203 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[273]); A_arbace_cpp_run_A_const_204 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[274]); A_arbace_cpp_run_A_const_205 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[275]); A_arbace_cpp_run_A_const_206 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[276]); A_arbace_cpp_run_A_const_207 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[277]) }

func A_arbace_cpp_run_A_clinit_p17() { A_arbace_cpp_run_A_const_208 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[278]); A_arbace_cpp_run_A_const_209 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[279]); A_arbace_cpp_run_A_const_210 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[280]); A_arbace_cpp_run_A_const_211 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[281]); A_arbace_cpp_run_A_const_212 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[282]); A_arbace_cpp_run_A_const_213 = A_arbace_cpp_run_A_const_pool.A[283]; A_arbace_cpp_run_A_const_214 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[284]); A_arbace_cpp_run_A_const_215 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[285]); A_arbace_cpp_run_A_const_216 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[286]); A_arbace_cpp_run_A_const_217 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[287]); A_arbace_cpp_run_A_const_218 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[288]); A_arbace_cpp_run_A_const_219 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[289]) }

func A_arbace_cpp_run_A_clinit_p18() { A_arbace_cpp_run_A_const_220 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[290]); A_arbace_cpp_run_A_const_221 = A_arbace_cpp_run_A_const_pool.A[291]; A_arbace_cpp_run_A_const_222 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[292]); A_arbace_cpp_run_A_const_223 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[293]); A_arbace_cpp_run_A_const_224 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[294]); A_arbace_cpp_run_A_const_225 = A_arbace_cpp_run_A_const_pool.A[295]; A_arbace_cpp_run_A_const_226 = A_arbace_cpp_run_A_const_pool.A[296]; A_arbace_cpp_run_A_const_227 = A_arbace_cpp_run_A_const_pool.A[297]; A_arbace_cpp_run_A_const_228 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[298]); A_arbace_cpp_run_A_const_229 = A_arbace_cpp_run_A_const_pool.A[299]; A_arbace_cpp_run_A_const_230 = lang.Keyword_Cast(A_arbace_cpp_run_A_const_pool.A[300]); A_arbace_cpp_run_A_const_231 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[301]); A_arbace_cpp_run_A_const_232 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[302]) }

func A_arbace_cpp_run_A_clinit_p19() { A_arbace_cpp_run_A_const_233 = A_arbace_cpp_run_A_const_pool.A[303]; A_arbace_cpp_run_A_const_234 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[304]); A_arbace_cpp_run_A_const_235 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[305]); A_arbace_cpp_run_A_const_236 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[306]); A_arbace_cpp_run_A_const_237 = lang.Var_Cast(A_arbace_cpp_run_A_const_pool.A[307]) }

func A_arbace_cpp_run_A_New() *A_arbace_cpp_run_A { A_arbace_cpp_run_A_Init(); t := &A_arbace_cpp_run_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_run_A) Ctor() {}

func (t *A_arbace_cpp_run_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_run_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_run_A_class }

func (t *A_arbace_cpp_run_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_run_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_run_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_run_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_run_A); return ok }

func A_arbace_cpp_run_A_Cast(x any) *A_arbace_cpp_run_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_run_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_run_A_class)) }; return v }



type A_arbace_cpp_run__main_A struct{ j2g_header uint64 }

var A_arbace_cpp_run__main_A_fn_class *jrt.Class



type A_arbace_cpp_run__main_fn__97000618_A struct{ j2g_header uint64 }

var A_arbace_cpp_run__main_fn__97000618_A_fn_class *jrt.Class



type A_arbace_cpp_run__main_fn__97000621_A struct{ j2g_header uint64 }

var A_arbace_cpp_run__main_fn__97000621_A_fn_class *jrt.Class



type A_arbace_cpp_run__main_fn__97000652_A struct{ j2g_header uint64; F_h, F_xdir, F_rt any }

var A_arbace_cpp_run__main_fn__97000652_A_fn_class *jrt.Class



type A_arbace_cpp_run__main_fn__97000654_A struct{ j2g_header uint64; F_msg, F_st, F_cls any }

var A_arbace_cpp_run__main_fn__97000654_A_fn_class *jrt.Class



type A_arbace_cpp_run__main_iter__97000630__97000634_A struct{ j2g_header uint64 }

var A_arbace_cpp_run__main_iter__97000630__97000634_A_fn_class *jrt.Class



type A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_A struct{ j2g_header uint64; F_s__97000631, F_iter__97000630 any }

var A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_A_fn_class *jrt.Class



type A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_fn__97000636_A struct{ j2g_header uint64; F_b__97000633 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_run__main_iter__97000630__97000634_fn__97000635_fn__97000636_A_fn_class *jrt.Class



type A_arbace_cpp_run__main_th__97000609_A struct{ j2g_header uint64 }

var A_arbace_cpp_run__main_th__97000609_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_linked_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_linked_forms_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_fn__97000482_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_linked_forms_fn__97000482_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_fn__97000484_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_linked_forms_fn__97000484_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_fn__97000486_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_linked_forms_fn__97000486_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_fn__97000488_A struct{ j2g_header uint64; F_linked any }

var A_arbace_cpp_run_build_linked_forms_fn__97000488_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_fn__97000491_A struct{ j2g_header uint64; F_h any }

var A_arbace_cpp_run_build_linked_forms_fn__97000491_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_fn__97000496_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_linked_forms_fn__97000496_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_fn__97000499_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_linked_forms_fn__97000499_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_fn__97000504_A struct{ j2g_header uint64; F_cpp_QMARK_ any }

var A_arbace_cpp_run_build_linked_forms_fn__97000504_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_fn__97000506_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_linked_forms_fn__97000506_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_fn__97000508_A struct{ j2g_header uint64; F_cpp_QMARK_ any }

var A_arbace_cpp_run_build_linked_forms_fn__97000508_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_fn__97000510_A struct{ j2g_header uint64; F_cpp_QMARK_ any }

var A_arbace_cpp_run_build_linked_forms_fn__97000510_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_fn__97000512_A struct{ j2g_header uint64; F_pq, F_cpp_QMARK_ any }

var A_arbace_cpp_run_build_linked_forms_fn__97000512_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_fn__97000515_A struct{ j2g_header uint64; F_h, F_pruned any; F_t2 int64; F_cpp_QMARK_, F_linked any; F_t1, F_t0 int64 }

var A_arbace_cpp_run_build_linked_forms_fn__97000515_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000516_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000516_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000519_A struct{ j2g_header uint64; F_h, F_cpp_QMARK_ any }

var A_arbace_cpp_run_build_linked_forms_fn__97000515_fn__97000519_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_prebuilt_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_linked_prebuilt_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_prebuilt_fn__97000450_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_linked_prebuilt_fn__97000450_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_prebuilt_fn__97000452_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_linked_prebuilt_fn__97000452_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_prebuilt_fn__97000454_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_linked_prebuilt_fn__97000454_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_prebuilt_fn__97000456_A struct{ j2g_header uint64; F_linked any }

var A_arbace_cpp_run_build_linked_prebuilt_fn__97000456_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_prebuilt_fn__97000459_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_linked_prebuilt_fn__97000459_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_prebuilt_fn__97000464_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_linked_prebuilt_fn__97000464_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_prebuilt_fn__97000468_A struct{ j2g_header uint64; F_n int32 }

var A_arbace_cpp_run_build_linked_prebuilt_fn__97000468_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_linked_prebuilt_fn__97000473_A struct{ j2g_header uint64; F_t2, F_t1, F_t0 int64; F_text any }

var A_arbace_cpp_run_build_linked_prebuilt_fn__97000473_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_one_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_build_one_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_one_fn__97000536_A struct{ j2g_header uint64; F_libs_of, F_h, F_u any }

var A_arbace_cpp_run_build_one_fn__97000536_A_fn_class *jrt.Class



type A_arbace_cpp_run_build_one_secs__97000534_A struct{ j2g_header uint64; F_ls any }

var A_arbace_cpp_run_build_one_secs__97000534_A_fn_class *jrt.Class



type A_arbace_cpp_run_check_c_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_check_c_A_fn_class *jrt.Class



type A_arbace_cpp_run_check_c_fn__97000599_A struct{ j2g_header uint64; F_h any }

var A_arbace_cpp_run_check_c_fn__97000599_A_fn_class *jrt.Class



type A_arbace_cpp_run_check_c_fn__97000599_fn__97000603_A struct{ j2g_header uint64; F_h, F_dir any }

var A_arbace_cpp_run_check_c_fn__97000599_fn__97000603_A_fn_class *jrt.Class



type A_arbace_cpp_run_check_lib_unit_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_check_lib_unit_A_fn_class *jrt.Class



type A_arbace_cpp_run_checked_lib_unit_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_checked_lib_unit_A_fn_class *jrt.Class



type A_arbace_cpp_run_checked_lib_unit_fn__97000265_A struct{ j2g_header uint64; F_lib, F_h, F_nm any }

var A_arbace_cpp_run_checked_lib_unit_fn__97000265_A_fn_class *jrt.Class



type A_arbace_cpp_run_clean_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_clean_A_fn_class *jrt.Class



type A_arbace_cpp_run_closure_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_closure_A_fn_class *jrt.Class



type A_arbace_cpp_run_closure_fn__97000273_A struct{ j2g_header uint64; F_n any }

var A_arbace_cpp_run_closure_fn__97000273_A_fn_class *jrt.Class



type A_arbace_cpp_run_compile_list_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_compile_list_A_fn_class *jrt.Class



type A_arbace_cpp_run_compile_list_fn__97000584_A struct{ j2g_header uint64; F_h, F_translate, F_out, F_lf, F_go_text any }

var A_arbace_cpp_run_compile_list_fn__97000584_A_fn_class *jrt.Class



type A_arbace_cpp_run_compile_list_fn__97000584_fn__97000591_A struct{ j2g_header uint64; F_xdir, F_lf any }

var A_arbace_cpp_run_compile_list_fn__97000584_fn__97000591_A_fn_class *jrt.Class



type A_arbace_cpp_run_ctor_attr_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_ctor_attr_A_fn_class *jrt.Class



type A_arbace_cpp_run_ctor_attr_fn__97000246_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_ctor_attr_fn__97000246_A_fn_class *jrt.Class



type A_arbace_cpp_run_ctor_attr_fn__97000246_fn__97000247_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_ctor_attr_fn__97000246_fn__97000247_A_fn_class *jrt.Class



type A_arbace_cpp_run_ctors_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_ctors_A_fn_class *jrt.Class



type A_arbace_cpp_run_ctors_fn__97000252_A struct{ j2g_header uint64; F_tag, F_acc any }

var A_arbace_cpp_run_ctors_fn__97000252_A_fn_class *jrt.Class



type A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_A_fn_class *jrt.Class



type A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_A_fn_class *jrt.Class



type A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_fn__97000255_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_ctors_fn__97000252_fn__97000253_fn__97000254_fn__97000255_A_fn_class *jrt.Class



type A_arbace_cpp_run_def_name_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_def_name_A_fn_class *jrt.Class



type A_arbace_cpp_run_eval97000004_A struct{ jrt.Object }

func A_arbace_cpp_run_eval97000004_A_New() *A_arbace_cpp_run_eval97000004_A { t := &A_arbace_cpp_run_eval97000004_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_run_eval97000004_A) Ctor() {}

func (t *A_arbace_cpp_run_eval97000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_run_eval97000004_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_run_eval97000004_A_class }

func (t *A_arbace_cpp_run_eval97000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_run_eval97000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_run_eval97000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_run_eval97000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_run_eval97000004_A); return ok }

func A_arbace_cpp_run_eval97000004_A_Cast(x any) *A_arbace_cpp_run_eval97000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_run_eval97000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_run_eval97000004_A_class)) }; return v }



type A_arbace_cpp_run_eval97000004_loading__1927001464__auto____97000005_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_eval97000004_loading__1927001464__auto____97000005_A_fn_class *jrt.Class



type A_arbace_cpp_run_eval97000008_A struct{ jrt.Object }

func A_arbace_cpp_run_eval97000008_A_New() *A_arbace_cpp_run_eval97000008_A { t := &A_arbace_cpp_run_eval97000008_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_run_eval97000008_A) Ctor() {}

func (t *A_arbace_cpp_run_eval97000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_run_eval97000008_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_run_eval97000008_A_class }

func (t *A_arbace_cpp_run_eval97000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_run_eval97000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_run_eval97000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_run_eval97000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_run_eval97000008_A); return ok }

func A_arbace_cpp_run_eval97000008_A_Cast(x any) *A_arbace_cpp_run_eval97000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_run_eval97000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_run_eval97000008_A_class)) }; return v }



type A_arbace_cpp_run_eval97000008_fn__97000009_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_eval97000008_fn__97000009_A_fn_class *jrt.Class



type A_arbace_cpp_run_fn__97000014_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_fn__97000014_A_fn_class *jrt.Class



type A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_A struct{ j2g_header uint64; F_rmw any }

var A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_A_fn_class *jrt.Class



type A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_A struct{ j2g_header uint64; F_s__97000018, F_rmw, F_iter__97000017 any }

var A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_A_fn_class *jrt.Class



type A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_A struct{ j2g_header uint64; F_rmw, F_op any }

var A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_A_fn_class *jrt.Class



type A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_A struct{ j2g_header uint64; F_s__97000020, F_rmw, F_op, F_iter__97000019 any }

var A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_A_fn_class *jrt.Class



type A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_fn__97000030_A struct{ j2g_header uint64; F_b__97000022, F_rmw, F_op any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_run_fn__97000014_iter__97000017__97000023_fn__97000024_iter__97000019__97000028_fn__97000029_fn__97000030_A_fn_class *jrt.Class



type A_arbace_cpp_run_fn__97000014_rmw__97000015_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_fn__97000014_rmw__97000015_A_fn_class *jrt.Class



type A_arbace_cpp_run_fn__97000047_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_fn__97000047_A_fn_class *jrt.Class



type A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_A_fn_class *jrt.Class



type A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_A struct{ j2g_header uint64; F_s__97000044, F_iter__97000043 any }

var A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_A_fn_class *jrt.Class



type A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_fn__97000050_A struct{ j2g_header uint64; F_b__97000046 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_run_fn__97000047_iter__97000043__97000048_fn__97000049_fn__97000050_A_fn_class *jrt.Class



type A_arbace_cpp_run_init_unit_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_init_unit_A_fn_class *jrt.Class



type A_arbace_cpp_run_init_unit_iter__97000412__97000416_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_init_unit_iter__97000412__97000416_A_fn_class *jrt.Class



type A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_A struct{ j2g_header uint64; F_s__97000413, F_iter__97000412 any }

var A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_A_fn_class *jrt.Class



type A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_fn__97000418_A struct{ j2g_header uint64; F_b__97000415 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_run_init_unit_iter__97000412__97000416_fn__97000417_fn__97000418_A_fn_class *jrt.Class



type A_arbace_cpp_run_init_unit_iter__97000422__97000426_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_init_unit_iter__97000422__97000426_A_fn_class *jrt.Class



type A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_A struct{ j2g_header uint64; F_s__97000423, F_iter__97000422 any }

var A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_A_fn_class *jrt.Class



type A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_fn__97000428_A struct{ j2g_header uint64; F_b__97000425 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_run_init_unit_iter__97000422__97000426_fn__97000427_fn__97000428_A_fn_class *jrt.Class



type A_arbace_cpp_run_lib_key_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_lib_key_A_fn_class *jrt.Class



type A_arbace_cpp_run_library_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_library_A_fn_class *jrt.Class



type A_arbace_cpp_run_libs_fn_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_libs_fn_A_fn_class *jrt.Class



type A_arbace_cpp_run_libs_fn_fn__97000562_A struct{ j2g_header uint64; F_rtlib, F_h any }

var A_arbace_cpp_run_libs_fn_fn__97000562_A_fn_class *jrt.Class



type A_arbace_cpp_run_libs_fn_fn__97000564_A struct{ j2g_header uint64; F_rtlib, F_h any }

var A_arbace_cpp_run_libs_fn_fn__97000564_A_fn_class *jrt.Class



type A_arbace_cpp_run_libs_fn_fn__97000566_A struct{ j2g_header uint64; F_h any }

var A_arbace_cpp_run_libs_fn_fn__97000566_A_fn_class *jrt.Class



type A_arbace_cpp_run_libs_fn_fn__97000568_A struct{ j2g_header uint64; F_ms, F_h, F_extra, F_over, F_rt any }

var A_arbace_cpp_run_libs_fn_fn__97000568_A_fn_class *jrt.Class



type A_arbace_cpp_run_load_unit_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_load_unit_A_fn_class *jrt.Class



type A_arbace_cpp_run_load_unit_iter__97000081__97000085_A struct{ j2g_header uint64; F_dir any }

var A_arbace_cpp_run_load_unit_iter__97000081__97000085_A_fn_class *jrt.Class



type A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_A struct{ j2g_header uint64; F_s__97000082, F_dir, F_iter__97000081 any }

var A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_A_fn_class *jrt.Class



type A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_fn__97000087_A struct{ j2g_header uint64; F_dir, F_b__97000084 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_run_load_unit_iter__97000081__97000085_fn__97000086_fn__97000087_A_fn_class *jrt.Class



type A_arbace_cpp_run_lower_ll_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_lower_ll_A_fn_class *jrt.Class



type A_arbace_cpp_run_nodes_list_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_nodes_list_A_fn_class *jrt.Class



type A_arbace_cpp_run_nodes_list_fn__97000572_A struct{ j2g_header uint64; F_h, F_work, F_lf any }

var A_arbace_cpp_run_nodes_list_fn__97000572_A_fn_class *jrt.Class



type A_arbace_cpp_run_nodes_list_fn__97000572_fn__97000579_A struct{ j2g_header uint64; F_xdir, F_lf any }

var A_arbace_cpp_run_nodes_list_fn__97000572_fn__97000579_A_fn_class *jrt.Class



type A_arbace_cpp_run_prebuilt_lib_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_prebuilt_lib_A_fn_class *jrt.Class



type A_arbace_cpp_run_prebuilt_lib_fn__97000443_A struct{ j2g_header uint64; F_lib, F_h any }

var A_arbace_cpp_run_prebuilt_lib_fn__97000443_A_fn_class *jrt.Class



type A_arbace_cpp_run_prune_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_prune_A_fn_class *jrt.Class



type A_arbace_cpp_run_prune_fn__97000296_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_prune_fn__97000296_A_fn_class *jrt.Class



type A_arbace_cpp_run_prune_fn__97000298_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_prune_fn__97000298_A_fn_class *jrt.Class



type A_arbace_cpp_run_prune_fn__97000352_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_prune_fn__97000352_A_fn_class *jrt.Class



type A_arbace_cpp_run_prune_fn__97000407_A struct{ j2g_header uint64; F_forms, F_keep any }

var A_arbace_cpp_run_prune_fn__97000407_A_fn_class *jrt.Class



type A_arbace_cpp_run_prune_fn__97000407_fn__97000408_A struct{ j2g_header uint64; F_u, F_keep any }

var A_arbace_cpp_run_prune_fn__97000407_fn__97000408_A_fn_class *jrt.Class



type A_arbace_cpp_run_prune_mark_BANG___97000354_A struct{ j2g_header uint64; F_q, F_keep any }

var A_arbace_cpp_run_prune_mark_BANG___97000354_A_fn_class *jrt.Class



type A_arbace_cpp_run_prune_ref_BANG___97000356_A struct{ j2g_header uint64; F_local, F_mark_BANG_, F_global any }

var A_arbace_cpp_run_prune_ref_BANG___97000356_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_read_lib_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_fn__97000100_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_read_lib_fn__97000100_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_fn__97000103_A struct{ j2g_header uint64; F_done any }

var A_arbace_cpp_run_read_lib_fn__97000103_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_fn__97000156_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_read_lib_fn__97000156_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000108__97000112_A struct{ j2g_header uint64; F_k, F_h, F_q, F_dir, F_res, F_todo any }

var A_arbace_cpp_run_read_lib_iter__97000108__97000112_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_A struct{ j2g_header uint64; F_k, F_h, F_q, F_dir, F_res, F_s__97000109, F_todo, F_iter__97000108 any }

var A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_A struct{ j2g_header uint64; F_k, F_h, F_q, F_dir, F_res, F_b__97000111 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_todo any }

var A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_A struct{ j2g_header uint64; F_k, F_h, F_q, F_dir, F_res, F_todo any }

var A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000119_A struct{ j2g_header uint64; F_h, F_n, F_dir, F_p any }

var A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000119_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000121_A struct{ j2g_header uint64; F_i, F_todo any }

var A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000114_fn__97000115_fn__97000121_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_A struct{ j2g_header uint64; F_k, F_h, F_q, F_dir, F_res, F_todo any }

var A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000129_A struct{ j2g_header uint64; F_h, F_n, F_dir, F_p any }

var A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000129_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000131_A struct{ j2g_header uint64; F_i, F_todo any }

var A_arbace_cpp_run_read_lib_iter__97000108__97000112_fn__97000113_fn__97000125_fn__97000131_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000140__97000144_A struct{ j2g_header uint64; F_res any }

var A_arbace_cpp_run_read_lib_iter__97000140__97000144_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_A struct{ j2g_header uint64; F_s__97000141, F_iter__97000140, F_res any }

var A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_fn__97000146_A struct{ j2g_header uint64; F_res, F_b__97000143 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_run_read_lib_iter__97000140__97000144_fn__97000145_fn__97000146_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000158__97000162_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_read_lib_iter__97000158__97000162_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_A struct{ j2g_header uint64; F_s__97000159, F_iter__97000158 any }

var A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_fn__97000164_A struct{ j2g_header uint64; F_b__97000161 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_run_read_lib_iter__97000158__97000162_fn__97000163_fn__97000164_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000174__97000178_A struct{ j2g_header uint64; F_dir any }

var A_arbace_cpp_run_read_lib_iter__97000174__97000178_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_A struct{ j2g_header uint64; F_dir, F_s__97000175, F_iter__97000174 any }

var A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_fn__97000180_A struct{ j2g_header uint64; F_dir, F_b__97000177 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_run_read_lib_iter__97000174__97000178_fn__97000179_fn__97000180_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000184__97000188_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_read_lib_iter__97000184__97000188_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_A struct{ j2g_header uint64; F_s__97000185, F_iter__97000184 any }

var A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_fn__97000190_A struct{ j2g_header uint64; F_b__97000187 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_run_read_lib_iter__97000184__97000188_fn__97000189_fn__97000190_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_one_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_read_one_A_fn_class *jrt.Class



type A_arbace_cpp_run_read_program_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_read_program_A_fn_class *jrt.Class



type A_arbace_cpp_run_secs_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_secs_A_fn_class *jrt.Class



type A_arbace_cpp_run_spit_mk_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_spit_mk_A_fn_class *jrt.Class



type A_arbace_cpp_run_sym_name_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_sym_name_A_fn_class *jrt.Class



type A_arbace_cpp_run_tsv_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_tsv_A_fn_class *jrt.Class



type A_arbace_cpp_run_tsv_fn__97000064_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_tsv_fn__97000064_A_fn_class *jrt.Class



type A_arbace_cpp_run_uses_atomic_generic_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_run_uses_atomic_generic_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_run_uses_atomic_generic_QMARK__walk__97000528_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_uses_atomic_generic_QMARK__walk__97000528_A_fn_class *jrt.Class



type A_arbace_cpp_run_va_arg_fns_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_va_arg_fns_A_fn_class *jrt.Class



type A_arbace_cpp_run_with_ctors_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_with_ctors_A_fn_class *jrt.Class



type A_arbace_cpp_run_work_list_A struct{ j2g_header uint64 }

var A_arbace_cpp_run_work_list_A_fn_class *jrt.Class



type A_arbace_cpp_run_work_list_iter__97000539__97000543_A struct{ j2g_header uint64; F_f, F_q, F_res any }

var A_arbace_cpp_run_work_list_iter__97000539__97000543_A_fn_class *jrt.Class



type A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_A struct{ j2g_header uint64; F_iter__97000539, F_f, F_q, F_s__97000540, F_res any }

var A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_A_fn_class *jrt.Class



type A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_A struct{ j2g_header uint64; F_f, F_q, F_res any; F_size__1927001038__auto__ int32; F_b__97000542, F_c__1927001037__auto__ any }

var A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_A_fn_class *jrt.Class



type A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_A struct{ j2g_header uint64; F_f, F_q, F_res any }

var A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_A_fn_class *jrt.Class



type A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_fn__97000547_A struct{ j2g_header uint64; F_f, F_fs any }

var A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000545_fn__97000546_fn__97000547_A_fn_class *jrt.Class



type A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_A struct{ j2g_header uint64; F_f, F_q, F_res any }

var A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_A_fn_class *jrt.Class



type A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_fn__97000552_A struct{ j2g_header uint64; F_f, F_fs any }

var A_arbace_cpp_run_work_list_iter__97000539__97000543_fn__97000544_fn__97000551_fn__97000552_A_fn_class *jrt.Class
