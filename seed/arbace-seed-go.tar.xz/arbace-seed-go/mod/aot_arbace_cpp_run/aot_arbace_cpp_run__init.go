//line aot_arbace_cpp_run__init.ae:1
package aot_arbace_cpp_run

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_cpp_run__init_A_Unit0__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_cpp_run__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_cpp_run__init_A_const_1) }
//line :1:1
func A_arbace_cpp_run__init_A_Unit1__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_cpp_run__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_2)) }
//line :1:1
func A_arbace_cpp_run__init_A_Unit2__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_cpp_run_eval97000004_loading__1927001464__auto____97000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_cpp_run_eval97000004_loading__1927001464__auto____97000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_227, false, nil); A_arbace_cpp_run_eval97000004_loading__1927001464__auto____97000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_cpp_run__init_A_Unit3__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_cpp_run__init_A_const_1)).Equals_O__Z(A_arbace_cpp_run__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_cpp_run_eval97000008_fn__97000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_cpp_run_eval97000008_fn__97000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_228, false, nil); A_arbace_cpp_run_eval97000008_fn__97000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_cpp_run__init_A_Load__O() any { A_arbace_cpp_run__init_A_Init(); jrt.StartCheck(); A_arbace_cpp_run__init_A_Unit0__O(); A_arbace_cpp_run__init_A_Unit1__O(); A_arbace_cpp_run__init_A_Unit2__O(); A_arbace_cpp_run__init_A_Unit3__O(); A_arbace_cpp_run__init_A_Unit4__O(); A_arbace_cpp_run__init_A_Unit5__O(); A_arbace_cpp_run__init_A_Unit6__O(); A_arbace_cpp_run__init_A_Unit7__O(); A_arbace_cpp_run__init_A_Unit8__O(); A_arbace_cpp_run__init_A_Unit9__O(); A_arbace_cpp_run__init_A_Unit10__O(); A_arbace_cpp_run__init_A_Unit11__O(); A_arbace_cpp_run__init_A_Unit12__O(); A_arbace_cpp_run__init_A_Unit13__O(); A_arbace_cpp_run__init_A_Unit14__O(); A_arbace_cpp_run__init_A_Unit15__O(); A_arbace_cpp_run__init_A_Unit16__O(); A_arbace_cpp_run__init_A_Unit17__O(); A_arbace_cpp_run__init_A_Unit18__O(); A_arbace_cpp_run__init_A_Unit19__O(); A_arbace_cpp_run__init_A_Unit20__O(); A_arbace_cpp_run__init_A_Unit21__O(); A_arbace_cpp_run__init_A_Unit22__O(); A_arbace_cpp_run__init_A_Unit23__O(); A_arbace_cpp_run__init_A_Unit24__O(); A_arbace_cpp_run__init_A_Unit25__O(); A_arbace_cpp_run__init_A_Unit26__O(); A_arbace_cpp_run__init_A_Unit27__O(); A_arbace_cpp_run__init_A_Unit28__O(); A_arbace_cpp_run__init_A_Unit29__O(); A_arbace_cpp_run__init_A_Unit30__O(); A_arbace_cpp_run__init_A_Unit31__O(); A_arbace_cpp_run__init_A_Unit32__O(); A_arbace_cpp_run__init_A_Unit33__O(); A_arbace_cpp_run__init_A_Unit34__O(); A_arbace_cpp_run__init_A_Unit35__O(); A_arbace_cpp_run__init_A_Unit36__O(); A_arbace_cpp_run__init_A_Unit37__O(); A_arbace_cpp_run__init_A_Unit38__O(); A_arbace_cpp_run__init_A_Unit39__O(); A_arbace_cpp_run__init_A_Unit40__O(); A_arbace_cpp_run__init_A_Unit41__O(); return nil }





















func A_arbace_cpp_run__init_A_Unit4__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); return A_arbace_cpp_run__init_A_const_4.Set_O__O(jrt.Boolean_TRUE.Ref()) }


func A_arbace_cpp_run__init_A_Unit5__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_5; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_cpp_run_fn__97000014_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_cpp_run_fn__97000014_A_fn_class; if






	fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_229, false, nil); A_arbace_cpp_run_fn__97000014_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); /*line :30:1*/tmp1.BindRoot_O__V(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_5; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_6)); return A_arbace_cpp_run__init_A_const_5 }




























func A_arbace_cpp_run__init_A_Unit6__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(59, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_7; var tmp2 any; var root_7 any = A_arbace_cpp_run__init_A_const_8.GetRawRoot__O(); var linked_8 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_7, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_9 lang.IFn; if



	linked_8 == nil { ifn_9 = lang.IFn_Cast(root_7) } else { ifn_9 = nil }; var arg_10 any = A_arbace_cpp_run__init_A_const_9; var arg_11 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__13 any = A_arbace_cpp_run_fn__97000047_A_New(); var tmp4 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_cpp_run_fn__97000047_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_230, false, nil); A_arbace_cpp_run_fn__97000047_A_fn_class = fncls__12d; tmp4 = fncls__12d } else { tmp4 = fncls__12 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__13, tmp4, nil); arg_11 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O(); if linked_8 == nil { tmp2 = ifn_9.Invoke_O_O__O(arg_10, arg_11) } else { tmp2 = linked_8.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_7, arg_10, arg_11) }; /*line :59:1*/tmp1.BindRoot_O__V(tmp2); var tmp5 *lang.Var = A_arbace_cpp_run__init_A_const_7; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_10)); return A_arbace_cpp_run__init_A_const_7 }





func A_arbace_cpp_run__init_A_Unit7__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__15 any = A_arbace_cpp_run_spit_mk_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_cpp_run_spit_mk_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_231, false, nil); A_arbace_cpp_run_spit_mk_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__15, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_12)); return A_arbace_cpp_run__init_A_const_11 }



func A_arbace_cpp_run__init_A_Unit8__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__17 any = A_arbace_cpp_run_clean_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_cpp_run_clean_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_232, false, nil); A_arbace_cpp_run_clean_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__17, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_14)); return A_arbace_cpp_run__init_A_const_13 }

func A_arbace_cpp_run__init_A_Unit9__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(71, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__19 any = A_arbace_cpp_run_tsv_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_cpp_run_tsv_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_233, false, nil); A_arbace_cpp_run_tsv_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__19, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_16)); return A_arbace_cpp_run__init_A_const_15 }






func A_arbace_cpp_run__init_A_Unit10__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(78, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__21 any = A_arbace_cpp_run_read_one_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_cpp_run_read_one_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_234, false, nil); A_arbace_cpp_run_read_one_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__21, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_18)); return A_arbace_cpp_run__init_A_const_17 }















func A_arbace_cpp_run__init_A_Unit11__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(94, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__23 any = A_arbace_cpp_run_load_unit_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_cpp_run_load_unit_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_235, false, nil); A_arbace_cpp_run_load_unit_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__23, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_20)); return A_arbace_cpp_run__init_A_const_19 }









func A_arbace_cpp_run__init_A_Unit12__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(104, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__25 any = A_arbace_cpp_run_read_lib_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_cpp_run_read_lib_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_236, false, nil); A_arbace_cpp_run_read_lib_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__25, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_22)); return A_arbace_cpp_run__init_A_const_21 }




































func A_arbace_cpp_run__init_A_Unit13__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__27 any = A_arbace_cpp_run_library_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_cpp_run_library_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_237, false, nil); A_arbace_cpp_run_library_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__27, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_24)); return A_arbace_cpp_run__init_A_const_23 }















func A_arbace_cpp_run__init_A_Unit14__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(157, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__29 any = A_arbace_cpp_run_ctor_attr_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_cpp_run_ctor_attr_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_238, false, nil); A_arbace_cpp_run_ctor_attr_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__29, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_26)); return A_arbace_cpp_run__init_A_const_25 }








func A_arbace_cpp_run__init_A_Unit15__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__31 any = A_arbace_cpp_run_ctors_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_cpp_run_ctors_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_239, false, nil); A_arbace_cpp_run_ctors_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__31, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_28)); return A_arbace_cpp_run__init_A_const_27 }

















func A_arbace_cpp_run__init_A_Unit16__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(184, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__33 any = A_arbace_cpp_run_with_ctors_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_cpp_run_with_ctors_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_240, false, nil); A_arbace_cpp_run_with_ctors_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__33, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_30)); return A_arbace_cpp_run__init_A_const_29 }




func A_arbace_cpp_run__init_A_Unit17__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(189, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_31; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_32)); return A_arbace_cpp_run__init_A_const_31 }

func A_arbace_cpp_run__init_A_Unit18__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(191, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__35 any = A_arbace_cpp_run_checked_lib_unit_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_cpp_run_checked_lib_unit_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_241, false, nil); A_arbace_cpp_run_checked_lib_unit_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__35, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_34)); return A_arbace_cpp_run__init_A_const_33 }







func A_arbace_cpp_run__init_A_Unit19__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(199, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__37 any = A_arbace_cpp_run_check_lib_unit_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_cpp_run_check_lib_unit_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_242, false, nil); A_arbace_cpp_run_check_lib_unit_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__37, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_35)); return A_arbace_cpp_run__init_A_const_31 }










func A_arbace_cpp_run__init_A_Unit20__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(210, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__39 any = A_arbace_cpp_run_closure_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_cpp_run_closure_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_243, false, nil); A_arbace_cpp_run_closure_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__39, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_37)); return A_arbace_cpp_run__init_A_const_36 }





















func A_arbace_cpp_run__init_A_Unit21__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__41 any = A_arbace_cpp_run_sym_name_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_cpp_run_sym_name_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_244, false, nil); A_arbace_cpp_run_sym_name_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__41, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_39)); return A_arbace_cpp_run__init_A_const_38 }

func A_arbace_cpp_run__init_A_Unit22__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(234, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__43 any = A_arbace_cpp_run_def_name_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_cpp_run_def_name_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_245, false, nil); A_arbace_cpp_run_def_name_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__43, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_41)); return A_arbace_cpp_run__init_A_const_40 }








func A_arbace_cpp_run__init_A_Unit23__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(243, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__45 any = A_arbace_cpp_run_prune_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_cpp_run_prune_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_246, false, nil); A_arbace_cpp_run_prune_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__45, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_43)); return A_arbace_cpp_run__init_A_const_42 }
































func A_arbace_cpp_run__init_A_Unit24__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(276, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__47 any = A_arbace_cpp_run_init_unit_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_cpp_run_init_unit_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_247, false, nil); A_arbace_cpp_run_init_unit_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__47, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_45)); return A_arbace_cpp_run__init_A_const_44 }















func A_arbace_cpp_run__init_A_Unit25__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(292, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__49 any = A_arbace_cpp_run_lib_key_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_cpp_run_lib_key_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_248, false, nil); A_arbace_cpp_run_lib_key_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__49, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_47)); return A_arbace_cpp_run__init_A_const_46 }











func A_arbace_cpp_run__init_A_Unit26__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(304, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__51 any = A_arbace_cpp_run_prebuilt_lib_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_cpp_run_prebuilt_lib_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_249, false, nil); A_arbace_cpp_run_prebuilt_lib_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__51, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_49)); return A_arbace_cpp_run__init_A_const_48 }







func A_arbace_cpp_run__init_A_Unit27__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(312, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__53 any = A_arbace_cpp_run_build_linked_prebuilt_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_cpp_run_build_linked_prebuilt_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_250, false, nil); A_arbace_cpp_run_build_linked_prebuilt_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__53, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_51)); return A_arbace_cpp_run__init_A_const_50 }




























func A_arbace_cpp_run__init_A_Unit28__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(341, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__55 any = A_arbace_cpp_run_build_linked_forms_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_cpp_run_build_linked_forms_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_251, false, nil); A_arbace_cpp_run_build_linked_forms_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__55, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_53)); return A_arbace_cpp_run__init_A_const_52 }
































func A_arbace_cpp_run__init_A_Unit29__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(374, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__57 any = A_arbace_cpp_run_build_linked_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_cpp_run_build_linked_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_252, false, nil); A_arbace_cpp_run_build_linked_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__57, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_55)); return A_arbace_cpp_run__init_A_const_54 }










func A_arbace_cpp_run__init_A_Unit30__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(385, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__59 any = A_arbace_cpp_run_secs_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_cpp_run_secs_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_253, false, nil); A_arbace_cpp_run_secs_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__59, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_57)); return A_arbace_cpp_run__init_A_const_56 }

func A_arbace_cpp_run__init_A_Unit31__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(387, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__61 any = A_arbace_cpp_run_uses_atomic_generic_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_cpp_run_uses_atomic_generic_QMARK__A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_254, false, nil); A_arbace_cpp_run_uses_atomic_generic_QMARK__A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__61, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_59)); return A_arbace_cpp_run__init_A_const_58 }







func A_arbace_cpp_run__init_A_Unit32__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(395, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__63 any = A_arbace_cpp_run_va_arg_fns_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_cpp_run_va_arg_fns_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_255, false, nil); A_arbace_cpp_run_va_arg_fns_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__63, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_61)); return A_arbace_cpp_run__init_A_const_60 }














func A_arbace_cpp_run__init_A_Unit33__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(410, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__65 any = A_arbace_cpp_run_read_program_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_cpp_run_read_program_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_256, false, nil); A_arbace_cpp_run_read_program_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__65, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_63)); return A_arbace_cpp_run__init_A_const_62 }















func A_arbace_cpp_run__init_A_Unit34__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(426, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__67 any = A_arbace_cpp_run_lower_ll_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_cpp_run_lower_ll_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_257, false, nil); A_arbace_cpp_run_lower_ll_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__67, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_65)); return A_arbace_cpp_run__init_A_const_64 }








func A_arbace_cpp_run__init_A_Unit35__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(435, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__69 any = A_arbace_cpp_run_build_one_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_cpp_run_build_one_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_258, false, nil); A_arbace_cpp_run_build_one_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__69, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_67)); return A_arbace_cpp_run__init_A_const_66 }





























func A_arbace_cpp_run__init_A_Unit36__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(465, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__71 any = A_arbace_cpp_run_work_list_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_cpp_run_work_list_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_259, false, nil); A_arbace_cpp_run_work_list_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__71, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_69)); return A_arbace_cpp_run__init_A_const_68 }
















func A_arbace_cpp_run__init_A_Unit37__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(482, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__73 any = A_arbace_cpp_run_libs_fn_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_cpp_run_libs_fn_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_260, false, nil); A_arbace_cpp_run_libs_fn_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__73, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_71)); return A_arbace_cpp_run__init_A_const_70 }












func A_arbace_cpp_run__init_A_Unit38__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(495, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__75 any = A_arbace_cpp_run_nodes_list_A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_cpp_run_nodes_list_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_261, false, nil); A_arbace_cpp_run_nodes_list_A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__75, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_73)); return A_arbace_cpp_run__init_A_const_72 }










func A_arbace_cpp_run__init_A_Unit39__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(506, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__77 any = A_arbace_cpp_run_compile_list_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_cpp_run_compile_list_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_262, false, nil); A_arbace_cpp_run_compile_list_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__77, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_75)); return A_arbace_cpp_run__init_A_const_74 }
























func A_arbace_cpp_run__init_A_Unit40__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(531, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__79 any = A_arbace_cpp_run_check_c_A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_cpp_run_check_c_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_263, false, nil); A_arbace_cpp_run_check_c_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__79, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_77)); return A_arbace_cpp_run__init_A_const_76 }













func A_arbace_cpp_run__init_A_Unit41__O() any { A_arbace_cpp_run__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(545, 1); var tmp1 *lang.Var = A_arbace_cpp_run__init_A_const_78; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__81 any = A_arbace_cpp_run__main_A_New(); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_cpp_run__main_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_264, true, nil); A_arbace_cpp_run__main_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__81, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_run__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_run__init_A_const_79)); return A_arbace_cpp_run__init_A_const_78 }



type A_arbace_cpp_run__init_A struct{ jrt.Object }

var A_arbace_cpp_run__init_A_const_pool *jrt.RefArray

var A_arbace_cpp_run__init_A_const_0 *lang.Var

var A_arbace_cpp_run__init_A_const_1 any

var A_arbace_cpp_run__init_A_const_2 any

var A_arbace_cpp_run__init_A_const_3 any

var A_arbace_cpp_run__init_A_const_4 *lang.Var

var A_arbace_cpp_run__init_A_const_5 *lang.Var

var A_arbace_cpp_run__init_A_const_6 any

var A_arbace_cpp_run__init_A_const_7 *lang.Var

var A_arbace_cpp_run__init_A_const_8 *lang.Var

var A_arbace_cpp_run__init_A_const_9 any

var A_arbace_cpp_run__init_A_const_10 any

var A_arbace_cpp_run__init_A_const_11 *lang.Var

var A_arbace_cpp_run__init_A_const_12 any

var A_arbace_cpp_run__init_A_const_13 *lang.Var

var A_arbace_cpp_run__init_A_const_14 any

var A_arbace_cpp_run__init_A_const_15 *lang.Var

var A_arbace_cpp_run__init_A_const_16 any

var A_arbace_cpp_run__init_A_const_17 *lang.Var

var A_arbace_cpp_run__init_A_const_18 any

var A_arbace_cpp_run__init_A_const_19 *lang.Var

var A_arbace_cpp_run__init_A_const_20 any

var A_arbace_cpp_run__init_A_const_21 *lang.Var

var A_arbace_cpp_run__init_A_const_22 any

var A_arbace_cpp_run__init_A_const_23 *lang.Var

var A_arbace_cpp_run__init_A_const_24 any

var A_arbace_cpp_run__init_A_const_25 *lang.Var

var A_arbace_cpp_run__init_A_const_26 any

var A_arbace_cpp_run__init_A_const_27 *lang.Var

var A_arbace_cpp_run__init_A_const_28 any

var A_arbace_cpp_run__init_A_const_29 *lang.Var

var A_arbace_cpp_run__init_A_const_30 any

var A_arbace_cpp_run__init_A_const_31 *lang.Var

var A_arbace_cpp_run__init_A_const_32 any

var A_arbace_cpp_run__init_A_const_33 *lang.Var

var A_arbace_cpp_run__init_A_const_34 any

var A_arbace_cpp_run__init_A_const_35 any

var A_arbace_cpp_run__init_A_const_36 *lang.Var

var A_arbace_cpp_run__init_A_const_37 any

var A_arbace_cpp_run__init_A_const_38 *lang.Var

var A_arbace_cpp_run__init_A_const_39 any

var A_arbace_cpp_run__init_A_const_40 *lang.Var

var A_arbace_cpp_run__init_A_const_41 any

var A_arbace_cpp_run__init_A_const_42 *lang.Var

var A_arbace_cpp_run__init_A_const_43 any

var A_arbace_cpp_run__init_A_const_44 *lang.Var

var A_arbace_cpp_run__init_A_const_45 any

var A_arbace_cpp_run__init_A_const_46 *lang.Var

var A_arbace_cpp_run__init_A_const_47 any

var A_arbace_cpp_run__init_A_const_48 *lang.Var

var A_arbace_cpp_run__init_A_const_49 any

var A_arbace_cpp_run__init_A_const_50 *lang.Var

var A_arbace_cpp_run__init_A_const_51 any

var A_arbace_cpp_run__init_A_const_52 *lang.Var

var A_arbace_cpp_run__init_A_const_53 any

var A_arbace_cpp_run__init_A_const_54 *lang.Var

var A_arbace_cpp_run__init_A_const_55 any

var A_arbace_cpp_run__init_A_const_56 *lang.Var

var A_arbace_cpp_run__init_A_const_57 any

var A_arbace_cpp_run__init_A_const_58 *lang.Var

var A_arbace_cpp_run__init_A_const_59 any

var A_arbace_cpp_run__init_A_const_60 *lang.Var

var A_arbace_cpp_run__init_A_const_61 any

var A_arbace_cpp_run__init_A_const_62 *lang.Var

var A_arbace_cpp_run__init_A_const_63 any

var A_arbace_cpp_run__init_A_const_64 *lang.Var

var A_arbace_cpp_run__init_A_const_65 any

var A_arbace_cpp_run__init_A_const_66 *lang.Var

var A_arbace_cpp_run__init_A_const_67 any

var A_arbace_cpp_run__init_A_const_68 *lang.Var

var A_arbace_cpp_run__init_A_const_69 any

var A_arbace_cpp_run__init_A_const_70 *lang.Var

var A_arbace_cpp_run__init_A_const_71 any

var A_arbace_cpp_run__init_A_const_72 *lang.Var

var A_arbace_cpp_run__init_A_const_73 any

var A_arbace_cpp_run__init_A_const_74 *lang.Var

var A_arbace_cpp_run__init_A_const_75 any

var A_arbace_cpp_run__init_A_const_76 *lang.Var

var A_arbace_cpp_run__init_A_const_77 any

var A_arbace_cpp_run__init_A_const_78 *lang.Var

var A_arbace_cpp_run__init_A_const_79 any

var A_arbace_cpp_run__init_A_init jrt.ClassInit

func A_arbace_cpp_run__init_A_Init() { if !A_arbace_cpp_run__init_A_init.Done() { A_arbace_cpp_run__init_A_init.Run(A_arbace_cpp_run__init_A_clinit) } }

func A_arbace_cpp_run__init_A_clinit() { A_arbace_cpp_run__init_A_clinit_p0(); A_arbace_cpp_run__init_A_clinit_p1(); A_arbace_cpp_run__init_A_clinit_p2(); A_arbace_cpp_run__init_A_clinit_p3(); A_arbace_cpp_run__init_A_clinit_p4(); A_arbace_cpp_run__init_A_clinit_p5(); A_arbace_cpp_run__init_A_clinit_p6() }

func A_arbace_cpp_run__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_run__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_226, 113); A_arbace_cpp_run__init_A_const_0 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[33]); A_arbace_cpp_run__init_A_const_1 = A_arbace_cpp_run__init_A_const_pool.A[34]; A_arbace_cpp_run__init_A_const_2 = A_arbace_cpp_run__init_A_const_pool.A[35]; A_arbace_cpp_run__init_A_const_3 = A_arbace_cpp_run__init_A_const_pool.A[36]; A_arbace_cpp_run__init_A_const_4 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[37]); A_arbace_cpp_run__init_A_const_5 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[38]); A_arbace_cpp_run__init_A_const_6 = A_arbace_cpp_run__init_A_const_pool.A[39]; A_arbace_cpp_run__init_A_const_7 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[40]); A_arbace_cpp_run__init_A_const_8 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[41]); A_arbace_cpp_run__init_A_const_9 = A_arbace_cpp_run__init_A_const_pool.A[42]; A_arbace_cpp_run__init_A_const_10 = A_arbace_cpp_run__init_A_const_pool.A[43]; A_arbace_cpp_run__init_A_const_11 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[44]); A_arbace_cpp_run__init_A_const_12 = A_arbace_cpp_run__init_A_const_pool.A[45] }

func A_arbace_cpp_run__init_A_clinit_p1() { A_arbace_cpp_run__init_A_const_13 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[46]); A_arbace_cpp_run__init_A_const_14 = A_arbace_cpp_run__init_A_const_pool.A[47]; A_arbace_cpp_run__init_A_const_15 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[48]); A_arbace_cpp_run__init_A_const_16 = A_arbace_cpp_run__init_A_const_pool.A[49]; A_arbace_cpp_run__init_A_const_17 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[50]); A_arbace_cpp_run__init_A_const_18 = A_arbace_cpp_run__init_A_const_pool.A[51]; A_arbace_cpp_run__init_A_const_19 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[52]); A_arbace_cpp_run__init_A_const_20 = A_arbace_cpp_run__init_A_const_pool.A[53]; A_arbace_cpp_run__init_A_const_21 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[54]); A_arbace_cpp_run__init_A_const_22 = A_arbace_cpp_run__init_A_const_pool.A[55]; A_arbace_cpp_run__init_A_const_23 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[56]); A_arbace_cpp_run__init_A_const_24 = A_arbace_cpp_run__init_A_const_pool.A[57]; A_arbace_cpp_run__init_A_const_25 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[58]) }

func A_arbace_cpp_run__init_A_clinit_p2() { A_arbace_cpp_run__init_A_const_26 = A_arbace_cpp_run__init_A_const_pool.A[59]; A_arbace_cpp_run__init_A_const_27 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[60]); A_arbace_cpp_run__init_A_const_28 = A_arbace_cpp_run__init_A_const_pool.A[61]; A_arbace_cpp_run__init_A_const_29 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[62]); A_arbace_cpp_run__init_A_const_30 = A_arbace_cpp_run__init_A_const_pool.A[63]; A_arbace_cpp_run__init_A_const_31 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[64]); A_arbace_cpp_run__init_A_const_32 = A_arbace_cpp_run__init_A_const_pool.A[65]; A_arbace_cpp_run__init_A_const_33 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[66]); A_arbace_cpp_run__init_A_const_34 = A_arbace_cpp_run__init_A_const_pool.A[67]; A_arbace_cpp_run__init_A_const_35 = A_arbace_cpp_run__init_A_const_pool.A[68]; A_arbace_cpp_run__init_A_const_36 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[69]); A_arbace_cpp_run__init_A_const_37 = A_arbace_cpp_run__init_A_const_pool.A[70]; A_arbace_cpp_run__init_A_const_38 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[71]); A_arbace_cpp_run__init_A_const_39 = A_arbace_cpp_run__init_A_const_pool.A[72] }

func A_arbace_cpp_run__init_A_clinit_p3() { A_arbace_cpp_run__init_A_const_40 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[73]); A_arbace_cpp_run__init_A_const_41 = A_arbace_cpp_run__init_A_const_pool.A[74]; A_arbace_cpp_run__init_A_const_42 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[75]); A_arbace_cpp_run__init_A_const_43 = A_arbace_cpp_run__init_A_const_pool.A[76]; A_arbace_cpp_run__init_A_const_44 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[77]); A_arbace_cpp_run__init_A_const_45 = A_arbace_cpp_run__init_A_const_pool.A[78]; A_arbace_cpp_run__init_A_const_46 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[79]); A_arbace_cpp_run__init_A_const_47 = A_arbace_cpp_run__init_A_const_pool.A[80]; A_arbace_cpp_run__init_A_const_48 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[81]); A_arbace_cpp_run__init_A_const_49 = A_arbace_cpp_run__init_A_const_pool.A[82]; A_arbace_cpp_run__init_A_const_50 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[83]); A_arbace_cpp_run__init_A_const_51 = A_arbace_cpp_run__init_A_const_pool.A[84]; A_arbace_cpp_run__init_A_const_52 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[85]) }

func A_arbace_cpp_run__init_A_clinit_p4() { A_arbace_cpp_run__init_A_const_53 = A_arbace_cpp_run__init_A_const_pool.A[86]; A_arbace_cpp_run__init_A_const_54 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[87]); A_arbace_cpp_run__init_A_const_55 = A_arbace_cpp_run__init_A_const_pool.A[88]; A_arbace_cpp_run__init_A_const_56 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[89]); A_arbace_cpp_run__init_A_const_57 = A_arbace_cpp_run__init_A_const_pool.A[90]; A_arbace_cpp_run__init_A_const_58 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[91]); A_arbace_cpp_run__init_A_const_59 = A_arbace_cpp_run__init_A_const_pool.A[92]; A_arbace_cpp_run__init_A_const_60 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[93]); A_arbace_cpp_run__init_A_const_61 = A_arbace_cpp_run__init_A_const_pool.A[94]; A_arbace_cpp_run__init_A_const_62 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[95]); A_arbace_cpp_run__init_A_const_63 = A_arbace_cpp_run__init_A_const_pool.A[96]; A_arbace_cpp_run__init_A_const_64 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[97]); A_arbace_cpp_run__init_A_const_65 = A_arbace_cpp_run__init_A_const_pool.A[98] }

func A_arbace_cpp_run__init_A_clinit_p5() { A_arbace_cpp_run__init_A_const_66 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[99]); A_arbace_cpp_run__init_A_const_67 = A_arbace_cpp_run__init_A_const_pool.A[100]; A_arbace_cpp_run__init_A_const_68 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[101]); A_arbace_cpp_run__init_A_const_69 = A_arbace_cpp_run__init_A_const_pool.A[102]; A_arbace_cpp_run__init_A_const_70 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[103]); A_arbace_cpp_run__init_A_const_71 = A_arbace_cpp_run__init_A_const_pool.A[104]; A_arbace_cpp_run__init_A_const_72 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[105]); A_arbace_cpp_run__init_A_const_73 = A_arbace_cpp_run__init_A_const_pool.A[106]; A_arbace_cpp_run__init_A_const_74 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[107]); A_arbace_cpp_run__init_A_const_75 = A_arbace_cpp_run__init_A_const_pool.A[108]; A_arbace_cpp_run__init_A_const_76 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[109]); A_arbace_cpp_run__init_A_const_77 = A_arbace_cpp_run__init_A_const_pool.A[110]; A_arbace_cpp_run__init_A_const_78 = lang.Var_Cast(A_arbace_cpp_run__init_A_const_pool.A[111]) }

func A_arbace_cpp_run__init_A_clinit_p6() { A_arbace_cpp_run__init_A_const_79 = A_arbace_cpp_run__init_A_const_pool.A[112] }

func A_arbace_cpp_run__init_A_New() *A_arbace_cpp_run__init_A { A_arbace_cpp_run__init_A_Init(); t := &A_arbace_cpp_run__init_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_run__init_A) Ctor() {}

func (t *A_arbace_cpp_run__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_run__init_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_run__init_A_class }

func (t *A_arbace_cpp_run__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_run__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_run__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_run__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_run__init_A); return ok }

func A_arbace_cpp_run__init_A_Cast(x any) *A_arbace_cpp_run__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_run__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_run__init_A_class)) }; return v }
