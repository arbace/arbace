//line j2g_strings.ae:1
package aot_arbace_cpp_run

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.repr.ckn2,asyn2,rcyn18,arbace.repr.c.hostyn4,hostyn14,arbace.c.buildyn5,buildyn13,arbace.c.muslyn4,muslyn12,arbace.c.runyn4,crunyn16,arbace.c.runtimeyn3,rtmyn16,arbace.cpp.loweryn5,loweryn16,arbace.repr.llvmyn4,llvmyn13,arbace.stringyn3,strkn3,dockn2,cikn5,errorkn7,refusedkn7,messagekn4,elsekn5,unitskn5,formskn6,headerkn4,defskn4,refskn3,dirkn5,indexkn7,by-namekn7,checkedkn4,weakyn13,__attribute__yn11,constructorks1,c10,decl-attrsys1,c4,defnkn6,statickn5,ctorskn3,srckn6,errorsks2,ci7,refusedkn13,runtime-checkys1,c2,idys1,c3,varkn6,externkn2,rdkn4,initkn4,rootkn10,libc-startkn5,prunekn5,rootsyn14,__atomic_storeyn17,__atomic_exchangeyn13,__atomic_loadkn6,statuskn10,read-errorkn12,read-refusedkn11,check-errorkn2,okkn1,ckn4,cmdsys13,arbace.c.cf2g9,translateys13,arbace.c.cf2g7,go-textks4,cf2g7,refusedyn13,arbace.c.cf2gkn11,check-crashv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,V3,R14,R2,R15,V3,R16,R2,R17,V3,R18,R2,R19,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn14,arbace.cpp.runm2,R20,s1256,cppi's programs on ci (doc/cpp/CPP-SURVEY.md, \"As built: CX8 (write-ahead)\"; doc/cpp/LLVM.md §11): a C++ program's\n  lowered C (arbace.cpp.lower's, printed by repr/c) read by repr/c and checked by ci's checker as any C program is\n  (arbace.c.run/read-unit), then linked as a static link pulls archive members (arbace.c.musl's rule: a unit when it defines a\n  symbol the program still needs, a strong definition before a weak one) from the libraries in order: the program's own\n  (the testsuite's util/ lowered), the lowered runtime (bin/cppi runtime-build's units: libsupc++, libstdc++-v3/src,\n  libstdc++exp, and the pending-flag layer arbace/cpp/rt/eh.c.ae) and musl's forms (arbace.c.musl), and built into a node\n  program (arbace.c.build) that ci's back end runs (tools/cirun on the light path); for AOT the node program translated by\n  cf2g (arbace.c.cf2g/translate) into a Go package.\n\n  A library here is a directory of read units (read-lib): DIR/forms/NAME.ae (repr/c's .ae of the unit, its header units\n  under DIR/forms/c/h/), DIR/index.edn {NAME {:defs {name {:weak :alias}} :refs #{names}}}, DIR/read.tsv each unit's read\n  (ok, or the error). Evaluated from the checkout on the tools' host (arbace.c.* is stage 0's, at the checkout's sources).v11,arbace.core4,intoV11,V2,s20,__atomic_load_n(p,o)s6,(*(p))V2,s23,__atomic_store_n(p,v,o)s20,((void)(*(p) = (v)))V2,s26,__atomic_exchange_n(p,v,o)s88,({ __typeof__(p) cx$ap = (p); __typeof__(*cx$ap) cx$ao = *cx$ap; *cx$ap = (v); cx$ao; })V2,s40,__atomic_compare_exchange_n(p,e,d,w,s,f)s145,({ __typeof__(p) cx$ap = (p); __typeof__(e) cx$ae = (e); _Bool cx$ok = *cx$ap == *cx$ae; if (cx$ok) *cx$ap = (d); else *cx$ae = *cx$ap; cx$ok; })V2,s38,__atomic_compare_exchange(p,e,d,w,s,f)s173,({ _Bool cx$ok = __builtin_memcmp((p), (e), sizeof(*(p))) == 0; if (cx$ok) __builtin_memcpy((p), (d), sizeof(*(p))); else __builtin_memcpy((e), (p), sizeof(*(p))); cx$ok; })V2,s24,__atomic_thread_fence(o)s9,((void)0)V2,s24,__atomic_signal_fence(o)s9,((void)0)V2,s26,__atomic_is_lock_free(n,p)s1,1V2,s30,__atomic_always_lock_free(n,p)s1,1V2,s26,__atomic_test_and_set(p,o)s91,({ unsigned char *cx$ab = (unsigned char *)(p); _Bool cx$ok = *cx$ab; *cx$ab = 1; cx$ok; })V2,s19,__atomic_clear(p,o)s35,((void)(*(unsigned char *)(p) = 0))v11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core6,concatV6,V2,s3,adds11,cx$ao + (v)V2,s3,subs11,cx$ao - (v)V2,s3,ands11,cx$ao & (v)V2,s2,ors11,cx$ao | (v)V2,s3,xors11,cx$ao ^ (v)V2,s4,nands14,~(cx$ao & (v))v14,arbace.cpp.run10,ci-atomicsR21,v16,arbace.cpp.lower15,va-field-macrosv11,arbace.core4,spitv13,arbace.string7,replacev11,arbace.core3,strp8,[\\t\\n\\r]v11,arbace.core4,mapvv13,arbace.string5,splitp2,\\tl-1,v11,arbace.core6,removev13,arbace.string6,blank?v13,arbace.string11,split-linesv11,arbace.core5,slurpv18,arbace.repr.c.host11,file-configv14,arbace.cpp.run4,optsv13,arbace.repr.c6,read-cv18,arbace.repr.c.host6,configR22,v13,arbace.string4,joinv11,arbace.core4,takel2,R23,v11,arbace.core4,nameR24,R25,v13,arbace.repr.c10,unit-textsv14,arbace.cpp.run7,spit-mkv11,arbace.core6,pr-strv11,arbace.core3,vecv11,arbace.core3,mapv11,arbace.core4,keysR26,v13,arbace.string12,starts-with?v11,arbace.core4,nextv13,arbace.repr.c14,read-unit-textv11,arbace.core11,read-stringR27,v11,arbace.core4,subsl4,v11,arbace.core6,symbolR28,v11,arbace.core6,secondp2,\\tv11,arbace.core4,juxtv11,arbace.core8,identityv14,arbace.cpp.run3,tsvv11,arbace.core4,atoml0,v11,arbace.core5,doallv11,arbace.core11,future-callv14,arbace.cpp.run8,read-onev14,arbace.cpp.run5,cleanv11,arbace.core6,formatv11,arbace.core5,swap!v11,arbace.core3,incv11,arbace.core3,modl20,v11,arbace.core7,printlnv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core5,rangev11,arbace.core10,sorted-mapv14,arbace.cpp.run9,load-unitv11,arbace.core6,mapcatv11,arbace.core4,valsR29,v13,arbace.c.musl9,unit-defsR30,v11,arbace.core3,setv13,arbace.c.musl4,refsv11,arbace.core4,not=v11,arbace.core6,empty?v11,arbace.core7,sort-byv11,arbace.core3,notv11,arbace.core7,string?R31,R32,R33,R34,v11,arbace.core8,to-arrayR35,v11,arbace.core4,somev11,arbace.core4,seq?R36,R37,l65536,v11,arbace.core7,vector?R37,R38,p13,[^A-Za-z0-9_]R39,v14,arbace.cpp.run9,ctor-attrv11,arbace.core5,applyv11,arbace.core4,listv11,arbace.core9,with-metav11,arbace.core6,updatev11,arbace.core6,dissocR40,S1,R37,v11,arbace.core4,dropv14,arbace.cpp.run5,ctorsv11,arbace.core5,assocR41,v14,arbace.cpp.run14,check-lib-unitv14,arbace.cpp.run10,with-ctorsv12,arbace.c.run10,check-readR42,R43,v11,arbace.core7,ex-infov12,arbace.c.run17,uses-long-double?m2,R44,R45,v13,arbace.c.musl5,rootsl10,v11,arbace.core7,symbol?R46,R47,R48,R39,v14,arbace.cpp.run8,sym-nameR49,v11,arbace.core11,map-indexedv11,arbace.core6,vectorv14,arbace.cpp.run8,def-namev11,arbace.core8,assoc-inV2,R49,R27,v11,arbace.core12,keep-indexedm2,R44,R50,V3,s9,index.edns3,keys8,read.tsvv16,arbace.c.runtime8,prebuiltv14,arbace.cpp.run7,lib-keyl12,v11,arbace.core4,keepv14,arbace.cpp.run7,closurev16,arbace.c.runtime12,lib-fragmentv14,arbace.cpp.run9,init-unitv14,arbace.c.build13,unit-fragmentR51,v14,arbace.c.build9,link-textR52,R53,R54,V2,s4,mains5,_initv13,arbace.c.musl12,checked-unitv14,arbace.cpp.run16,checked-lib-unitV2,s4,mains5,_initv14,arbace.cpp.run5,prunev14,arbace.c.build13,build-programv11,arbace.core6,reducev11,arbace.core1,+v14,arbace.cpp.run18,build-linked-formsv14,arbace.c.build12,read-programv14,arbace.cpp.run21,build-linked-prebuiltS3,R55,R56,R57,v11,arbace.core7,re-findp18,@\\\"?([^\\\"(]+)\\\"?\\(v13,arbace.string9,includes?R58,R59,l3,R60,R61,v14,arbace.cpp.run20,uses-atomic-generic?R62,v16,arbace.cpp.lower10,lower-filev16,arbace.repr.llvm11,spit-latin1R63,v13,arbace.string10,ends-with?v14,arbace.cpp.run8,lower-llv14,arbace.cpp.run4,secsv14,arbace.cpp.run12,read-programv14,arbace.cpp.run10,va-arg-fnsv11,arbace.core4,nil?R64,v14,arbace.cpp.run12,build-linkedR44,v11,arbace.core7,ex-datap2,\\tv11,arbace.core5,classv11,arbace.core4,sortv14,arbace.cpp.run12,prebuilt-libv14,arbace.cpp.run7,libraryv16,arbace.c.runtime7,libraryv14,arbace.cpp.run7,libs-fnv14,arbace.cpp.run9,work-listV6,s10,ir-missings0,s0,s0,s0,nv14,arbace.cpp.run9,build-onev14,arbace.c.build12,program-textv11,arbace.core7,resolveR65,R66,V6,s10,ir-missings0,s0,s0,s0,nR67,R68,R69,v18,arbace.repr.c.host9,load-hostv14,arbace.cpp.run7,check-cp2,\\tv14,arbace.cpp.run8,read-libv11,arbace.core15,shutdown-agentsv14,arbace.cpp.run10,nodes-listv14,arbace.cpp.run12,compile-list")

var Lit_1 *jrt.String = jrt.Intern("test/c/host")

var Lit_2 *jrt.String = jrt.Intern("arbace.cpp.run$_main$th__97000609")

var Lit_3 *jrt.String = jrt.Intern("check-c")

var Lit_4 *jrt.String = jrt.Intern("lower-lib")

var Lit_5 *jrt.String = jrt.Intern("arbace.cpp.run$_main$fn__97000618")

var Lit_6 *jrt.String = jrt.Intern("arbace.cpp.run$_main$fn__97000621")

var Lit_7 *jrt.String = jrt.Intern("cppi: not lowered:")

var Lit_8 *jrt.String = jrt.Intern("/read.list")

var Lit_9 *jrt.String = jrt.Intern("arbace.cpp.run$_main$iter__97000630__97000634")

var Lit_10 *jrt.String = jrt.Intern("nodes")

var Lit_11 *jrt.String = jrt.Intern("arbace.cpp.run$_main$fn__97000652")

var Lit_12 *jrt.String = jrt.Intern("cppi: built in")

var Lit_13 *jrt.String = jrt.Intern("s")

var Lit_14 *jrt.String = jrt.Intern("arbace.cpp.run$_main$fn__97000654")

var Lit_15 *jrt.String = jrt.Intern("read-lib")

var Lit_16 *jrt.String = jrt.Intern("nodes-list")

var Lit_17 *jrt.String = jrt.Intern("compile-list")

var Lit_18 *jrt.String = jrt.Intern("arbace.cpp.run: read-lib, nodes-list, compile-list, nodes")

var Lit_19 *jrt.String = jrt.Intern(": ")

var Lit_20 *jrt.String = jrt.Intern(" ")

var Lit_21 *jrt.String = jrt.Intern(" (")

var Lit_22 *jrt.String = jrt.Intern(")")

var Lit_23 *jrt.String = jrt.Intern("arbace.cpp.run$_main$iter__97000630__97000634$fn__97000635")

var Lit_24 *jrt.String = jrt.Intern("arbace.cpp.run$_main$iter__97000630__97000634$fn__97000635$fn__97000636")

var Lit_25 *jrt.String = jrt.Intern("\t")

var Lit_26 *jrt.String = jrt.Intern("/lowered.c\n")

var Lit_27 *jrt.String = jrt.Intern("3")

var Lit_28 *jrt.String = jrt.Intern("0")

var Lit_29 *jrt.String = jrt.Intern("CI_PREBUILT")

var Lit_30 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms$fn__97000482")

var Lit_31 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms$fn__97000484")

var Lit_32 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms$fn__97000486")

var Lit_33 *jrt.String = jrt.Intern("CPPI_TRACE")

var Lit_34 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms$fn__97000488")

var Lit_35 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms$fn__97000491")

var Lit_36 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms$fn__97000496")

var Lit_37 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms$fn__97000499")

var Lit_38 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms$fn__97000504")

var Lit_39 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms$fn__97000506")

var Lit_40 *jrt.String = jrt.Intern("CPPI_NO_PRUNE")

var Lit_41 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms$fn__97000508")

var Lit_42 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms$fn__97000510")

var Lit_43 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms$fn__97000512")

var Lit_44 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms$fn__97000515")

var Lit_45 *jrt.String = jrt.Intern("__builtin_")

var Lit_46 *jrt.String = jrt.Intern("cppi: linked")

var Lit_47 *jrt.String = jrt.Intern("cppi: units checked %.1f s, pruned %.1f s, built %.1f s; forms %d of %d")

var Lit_48 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms$fn__97000515$fn__97000516")

var Lit_49 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms$fn__97000515$fn__97000519")

var Lit_50 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_prebuilt$fn__97000450")

var Lit_51 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_prebuilt$fn__97000452")

var Lit_52 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_prebuilt$fn__97000454")

var Lit_53 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_prebuilt$fn__97000456")

var Lit_54 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_prebuilt$fn__97000459")

var Lit_55 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_prebuilt$fn__97000464")

var Lit_56 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_prebuilt$fn__97000468")

var Lit_57 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_prebuilt$fn__97000473")

var Lit_58 *jrt.String = jrt.Intern("cppi: library fragments %.1f s, the program's %.1f s, linked %.1f s; %d bytes")

var Lit_59 *jrt.String = jrt.Intern(".ll")

var Lit_60 *jrt.String = jrt.Intern("/lowered.c")

var Lit_61 *jrt.String = jrt.Intern("arbace.cpp.run$build_one$secs__97000534")

var Lit_62 *jrt.String = jrt.Intern("")

var Lit_63 *jrt.String = jrt.Intern("long-double")

var Lit_64 *jrt.String = jrt.Intern("va-arg=")

var Lit_65 *jrt.String = jrt.Intern(",")

var Lit_66 *jrt.String = jrt.Intern("arbace.cpp.run$build_one$fn__97000536")

var Lit_67 *jrt.String = jrt.Intern("ok")

var Lit_68 *jrt.String = jrt.Intern("refused")

var Lit_69 *jrt.String = jrt.Intern("+")

var Lit_70 *jrt.String = jrt.Intern(".out")

var Lit_71 *jrt.String = jrt.Intern("arbace.cpp.run$check_c$fn__97000599")

var Lit_72 *jrt.String = jrt.Intern("arbace.cpp.run$check_c$fn__97000599$fn__97000603")

var Lit_73 *jrt.String = jrt.Intern("/ci-check.status")

var Lit_74 *jrt.String = jrt.Intern("\n")

var Lit_75 *jrt.String = jrt.Intern("/ci-check.log")

var Lit_76 *jrt.String = jrt.Intern("_")

var Lit_77 *jrt.String = jrt.Intern("gnu23")

var Lit_78 *jrt.String = jrt.Intern("the library unit ")

var Lit_79 *jrt.String = jrt.Intern(" does not check: ")

var Lit_80 *jrt.String = jrt.Intern("; ")

var Lit_81 *jrt.String = jrt.Intern(" uses-long-double")

var Lit_82 *jrt.String = jrt.Intern("arbace.cpp.run$checked_lib_unit$fn__97000265")

var Lit_83 *jrt.String = jrt.Intern("arbace.cpp.run$closure$fn__97000273")

var Lit_84 *jrt.String = jrt.Intern("/nodes.tsv")

var Lit_85 *jrt.String = jrt.Intern("arbace.cpp.run$compile_list$fn__97000584")

var Lit_86 *jrt.String = jrt.Intern("-")

var Lit_87 *jrt.String = jrt.Intern("arbace.cpp.run$compile_list$fn__97000584$fn__97000591")

var Lit_88 *jrt.String = jrt.Intern("arbace/progs/")

var Lit_89 *jrt.String = jrt.Intern("/progs/")

var Lit_90 *jrt.String = jrt.Intern("CI_AOT_NODES")

var Lit_91 *jrt.String = jrt.Intern("/prog.nodes")

var Lit_92 *jrt.String = jrt.Intern("/prog.go")

var Lit_93 *jrt.String = jrt.Intern("arbace.cpp.run$ctor_attr$fn__97000246")

var Lit_94 *jrt.String = jrt.Intern("arbace.cpp.run$ctor_attr$fn__97000246$fn__97000247")

var Lit_95 *jrt.String = jrt.Intern("arbace.cpp.run$ctors$fn__97000252")

var Lit_96 *jrt.String = jrt.Intern("cx$init$")

var Lit_97 *jrt.String = jrt.Intern("$")

var Lit_98 *jrt.String = jrt.Intern("arbace.cpp.run$ctors$fn__97000252$fn__97000253")

var Lit_99 *jrt.String = jrt.Intern("arbace.cpp.run$ctors$fn__97000252$fn__97000253$fn__97000254")

var Lit_100 *jrt.String = jrt.Intern("arbace.cpp.run$ctors$fn__97000252$fn__97000253$fn__97000254$fn__97000255")

var Lit_101 *jrt.String = jrt.Intern("java.io.File")

var Lit_102 *jrt.String = jrt.Intern("java.util.ArrayDeque")

var Lit_103 *jrt.String = jrt.Intern("java.util.HashMap")

var Lit_104 *jrt.String = jrt.Intern("java.util.HashSet")

var Lit_105 *jrt.String = jrt.Intern("java.util.concurrent.ConcurrentHashMap")

var Lit_106 *jrt.String = jrt.Intern("java.util.concurrent.ConcurrentLinkedQueue")

var Lit_107 *jrt.String = jrt.Intern("arbace.cpp.run$fn__97000014$rmw__97000015")

var Lit_108 *jrt.String = jrt.Intern("arbace.cpp.run$fn__97000014$iter__97000017__97000023")

var Lit_109 *jrt.String = jrt.Intern("arbace.cpp.run$fn__97000014$iter__97000017__97000023$fn__97000024")

var Lit_110 *jrt.String = jrt.Intern("arbace.cpp.run$fn__97000014$iter__97000017__97000023$fn__97000024$iter__97000019__97000028")

var Lit_111 *jrt.String = jrt.Intern("fetch_")

var Lit_112 *jrt.String = jrt.Intern("_fetch")

var Lit_113 *jrt.String = jrt.Intern("arbace.cpp.run$fn__97000014$iter__97000017__97000023$fn__97000024$iter__97000019__97000028$fn__97000029")

var Lit_114 *jrt.String = jrt.Intern("arbace.cpp.run$fn__97000014$iter__97000017__97000023$fn__97000024$iter__97000019__97000028$fn__97000029$fn__97000030")

var Lit_115 *jrt.String = jrt.Intern("__atomic_")

var Lit_116 *jrt.String = jrt.Intern("(p,v,o)")

var Lit_117 *jrt.String = jrt.Intern("({ __typeof__(p) cx$ap = (p); __typeof__(*cx$ap) cx$ao = *cx$ap; __typeof__(*cx$ap) cx$an = ")

var Lit_118 *jrt.String = jrt.Intern("; *cx$ap = cx$an; ")

var Lit_119 *jrt.String = jrt.Intern("; })")

var Lit_120 *jrt.String = jrt.Intern("cx$an")

var Lit_121 *jrt.String = jrt.Intern("cx$ao")

var Lit_122 *jrt.String = jrt.Intern("arbace.cpp.run$fn__97000047$iter__97000043__97000048")

var Lit_123 *jrt.String = jrt.Intern("arbace.cpp.run$fn__97000047$iter__97000043__97000048$fn__97000049")

var Lit_124 *jrt.String = jrt.Intern("arbace.cpp.run$fn__97000047$iter__97000043__97000048$fn__97000049$fn__97000050")

var Lit_125 *jrt.String = jrt.Intern("-D")

var Lit_126 *jrt.String = jrt.Intern("=")

var Lit_127 *jrt.String = jrt.Intern("cppi-init")

var Lit_128 *jrt.String = jrt.Intern(".c")

var Lit_129 *jrt.String = jrt.Intern("void _init(void) {\n")

var Lit_130 *jrt.String = jrt.Intern("}\n")

var Lit_131 *jrt.String = jrt.Intern("arbace.cpp.run$init_unit$iter__97000412__97000416")

var Lit_132 *jrt.String = jrt.Intern("arbace.cpp.run$init_unit$iter__97000422__97000426")

var Lit_133 *jrt.String = jrt.Intern("the constructors' unit does not check: ")

var Lit_134 *jrt.String = jrt.Intern("arbace.cpp.run$init_unit$iter__97000412__97000416$fn__97000417")

var Lit_135 *jrt.String = jrt.Intern("arbace.cpp.run$init_unit$iter__97000412__97000416$fn__97000417$fn__97000418")

var Lit_136 *jrt.String = jrt.Intern("void ")

var Lit_137 *jrt.String = jrt.Intern("(void);\n")

var Lit_138 *jrt.String = jrt.Intern("arbace.cpp.run$init_unit$iter__97000422__97000426$fn__97000427")

var Lit_139 *jrt.String = jrt.Intern("arbace.cpp.run$init_unit$iter__97000422__97000426$fn__97000427$fn__97000428")

var Lit_140 *jrt.String = jrt.Intern("  ")

var Lit_141 *jrt.String = jrt.Intern("();\n")

var Lit_142 *jrt.String = jrt.Intern("SHA-256")

var Lit_143 *jrt.String = jrt.Intern("/")

var Lit_144 *jrt.String = jrt.Intern("UTF-8")

var Lit_145 *jrt.String = jrt.Intern("%02x")

var Lit_146 *jrt.String = jrt.Intern("/index.edn")

var Lit_147 *jrt.String = jrt.Intern("arbace.cpp.run$libs_fn$fn__97000562")

var Lit_148 *jrt.String = jrt.Intern("arbace.cpp.run$libs_fn$fn__97000564")

var Lit_149 *jrt.String = jrt.Intern("arbace.cpp.run$libs_fn$fn__97000566")

var Lit_150 *jrt.String = jrt.Intern("arbace.cpp.run$libs_fn$fn__97000568")

var Lit_151 *jrt.String = jrt.Intern("/over/index.edn")

var Lit_152 *jrt.String = jrt.Intern("/over")

var Lit_153 *jrt.String = jrt.Intern("user.dir")

var Lit_154 *jrt.String = jrt.Intern("/forms/")

var Lit_155 *jrt.String = jrt.Intern(".ae")

var Lit_156 *jrt.String = jrt.Intern(".units")

var Lit_157 *jrt.String = jrt.Intern("arbace.cpp.run$load_unit$iter__97000081__97000085")

var Lit_158 *jrt.String = jrt.Intern("arbace.cpp.run$load_unit$iter__97000081__97000085$fn__97000086")

var Lit_159 *jrt.String = jrt.Intern("arbace.cpp.run$load_unit$iter__97000081__97000085$fn__97000086$fn__97000087")

var Lit_160 *jrt.String = jrt.Intern("/forms/c/h/")

var Lit_161 *jrt.String = jrt.Intern("lowered.c")

var Lit_162 *jrt.String = jrt.Intern("lower-refused")

var Lit_163 *jrt.String = jrt.Intern("arbace.cpp.run$nodes_list$fn__97000572")

var Lit_164 *jrt.String = jrt.Intern("arbace.cpp.run$nodes_list$fn__97000572$fn__97000579")

var Lit_165 *jrt.String = jrt.Intern(".nodes")

var Lit_166 *jrt.String = jrt.Intern("cpp-")

var Lit_167 *jrt.String = jrt.Intern("arbace.cpp.run$prebuilt_lib$fn__97000443")

var Lit_168 *jrt.String = jrt.Intern("arbace.cpp.run$prune$fn__97000296")

var Lit_169 *jrt.String = jrt.Intern("arbace.cpp.run$prune$fn__97000298")

var Lit_170 *jrt.String = jrt.Intern("arbace.cpp.run$prune$fn__97000352")

var Lit_171 *jrt.String = jrt.Intern("arbace.cpp.run$prune$mark_BANG___97000354")

var Lit_172 *jrt.String = jrt.Intern("arbace.cpp.run$prune$ref_BANG___97000356")

var Lit_173 *jrt.String = jrt.Intern("arbace.cpp.run$prune$fn__97000407")

var Lit_174 *jrt.String = jrt.Intern("arbace.cpp.run$prune$fn__97000407$fn__97000408")

var Lit_175 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$fn__97000100")

var Lit_176 *jrt.String = jrt.Intern("/read.tsv")

var Lit_177 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$fn__97000103")

var Lit_178 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000108__97000112")

var Lit_179 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000140__97000144")

var Lit_180 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$fn__97000156")

var Lit_181 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000158__97000162")

var Lit_182 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000174__97000178")

var Lit_183 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000184__97000188")

var Lit_184 *jrt.String = jrt.Intern("cppi: not read:")

var Lit_185 *jrt.String = jrt.Intern("cppi: read")

var Lit_186 *jrt.String = jrt.Intern("units of")

var Lit_187 *jrt.String = jrt.Intern("into")

var Lit_188 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000108__97000112$fn__97000113")

var Lit_189 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000108__97000112$fn__97000113$fn__97000114")

var Lit_190 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000108__97000112$fn__97000113$fn__97000125")

var Lit_191 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000108__97000112$fn__97000113$fn__97000114$fn__97000115")

var Lit_192 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000108__97000112$fn__97000113$fn__97000114$fn__97000115$fn__97000119")

var Lit_193 *jrt.String = jrt.Intern("error")

var Lit_194 *jrt.String = jrt.Intern("%.1f")

var Lit_195 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000108__97000112$fn__97000113$fn__97000114$fn__97000115$fn__97000121")

var Lit_196 *jrt.String = jrt.Intern("error: ")

var Lit_197 *jrt.String = jrt.Intern("of")

var Lit_198 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000108__97000112$fn__97000113$fn__97000125$fn__97000129")

var Lit_199 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000108__97000112$fn__97000113$fn__97000125$fn__97000131")

var Lit_200 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000140__97000144$fn__97000145")

var Lit_201 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000140__97000144$fn__97000145$fn__97000146")

var Lit_202 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000158__97000162$fn__97000163")

var Lit_203 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000158__97000162$fn__97000163$fn__97000164")

var Lit_204 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000174__97000178$fn__97000179")

var Lit_205 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000174__97000178$fn__97000179$fn__97000180")

var Lit_206 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000184__97000188$fn__97000189")

var Lit_207 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib$iter__97000184__97000188$fn__97000189$fn__97000190")

var Lit_208 *jrt.String = jrt.Intern("read-error: ")

var Lit_209 *jrt.String = jrt.Intern("read-refused: ")

var Lit_210 *jrt.String = jrt.Intern("c/h/")

var Lit_211 *jrt.String = jrt.Intern("p")

var Lit_212 *jrt.String = jrt.Intern(" uses-atomic-generic")

var Lit_213 *jrt.String = jrt.Intern("arbace.cpp.run$tsv$fn__97000064")

var Lit_214 *jrt.String = jrt.Intern("arbace.cpp.run$uses_atomic_generic_QMARK_$walk__97000528")

var Lit_215 *jrt.String = jrt.Intern("define ")

var Lit_216 *jrt.String = jrt.Intern("getelementptr")

var Lit_217 *jrt.String = jrt.Intern("%struct.__va_list_tag,")

var Lit_218 *jrt.String = jrt.Intern("arbace.cpp.run$work_list$iter__97000539__97000543")

var Lit_219 *jrt.String = jrt.Intern("arbace.cpp.run$work_list$iter__97000539__97000543$fn__97000544")

var Lit_220 *jrt.String = jrt.Intern("arbace.cpp.run$work_list$iter__97000539__97000543$fn__97000544$fn__97000545")

var Lit_221 *jrt.String = jrt.Intern("arbace.cpp.run$work_list$iter__97000539__97000543$fn__97000544$fn__97000551")

var Lit_222 *jrt.String = jrt.Intern("arbace.cpp.run$work_list$iter__97000539__97000543$fn__97000544$fn__97000545$fn__97000546")

var Lit_223 *jrt.String = jrt.Intern("arbace.cpp.run$work_list$iter__97000539__97000543$fn__97000544$fn__97000545$fn__97000546$fn__97000547")

var Lit_224 *jrt.String = jrt.Intern("build-error")

var Lit_225 *jrt.String = jrt.Intern("arbace.cpp.run$work_list$iter__97000539__97000543$fn__97000544$fn__97000551$fn__97000552")

var Lit_226 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn7,privatekn8,arglistskn3,tagyn6,Stringyn1,syn1,hyn7,threadsyn1,myn5,formsyn2,rdyn3,tagkn8,declaredyn3,libyn4,libsyn9,prog-defsyn9,prog-refsyn1,xyn1,fyn5,unitsyn5,rootsyn5,namesyn16,java.lang.Stringyn2,t0yn4,Fileyn7,libs-ofyn4,verbyn1,&yn4,argsv11,arbace.core5,in-nsMyn14,arbace.cpp.runm2,R0,s1256,cppi's programs on ci (doc/cpp/CPP-SURVEY.md, \"As built: CX8 (write-ahead)\"; doc/cpp/LLVM.md §11): a C++ program's\n  lowered C (arbace.cpp.lower's, printed by repr/c) read by repr/c and checked by ci's checker as any C program is\n  (arbace.c.run/read-unit), then linked as a static link pulls archive members (arbace.c.musl's rule: a unit when it defines a\n  symbol the program still needs, a strong definition before a weak one) from the libraries in order: the program's own\n  (the testsuite's util/ lowered), the lowered runtime (bin/cppi runtime-build's units: libsupc++, libstdc++-v3/src,\n  libstdc++exp, and the pending-flag layer arbace/cpp/rt/eh.c.ae) and musl's forms (arbace.c.musl), and built into a node\n  program (arbace.c.build) that ci's back end runs (tools/cirun on the light path); for AOT the node program translated by\n  cf2g (arbace.c.cf2g/translate) into a Go package.\n\n  A library here is a directory of read units (read-lib): DIR/forms/NAME.ae (repr/c's .ae of the unit, its header units\n  under DIR/forms/c/h/), DIR/index.edn {NAME {:defs {name {:weak :alias}} :refs #{names}}}, DIR/read.tsv each unit's read\n  (ok, or the error). Evaluated from the checkout on the tools' host (arbace.c.* is stage 0's, at the checkout's sources).m2,R0,s1256,cppi's programs on ci (doc/cpp/CPP-SURVEY.md, \"As built: CX8 (write-ahead)\"; doc/cpp/LLVM.md §11): a C++ program's\n  lowered C (arbace.cpp.lower's, printed by repr/c) read by repr/c and checked by ci's checker as any C program is\n  (arbace.c.run/read-unit), then linked as a static link pulls archive members (arbace.c.musl's rule: a unit when it defines a\n  symbol the program still needs, a strong definition before a weak one) from the libraries in order: the program's own\n  (the testsuite's util/ lowered), the lowered runtime (bin/cppi runtime-build's units: libsupc++, libstdc++-v3/src,\n  libstdc++exp, and the pending-flag layer arbace/cpp/rt/eh.c.ae) and musl's forms (arbace.c.musl), and built into a node\n  program (arbace.c.build) that ci's back end runs (tools/cirun on the light path); for AOT the node program translated by\n  cf2g (arbace.c.cf2g/translate) into a Go package.\n\n  A library here is a directory of read units (read-lib): DIR/forms/NAME.ae (repr/c's .ae of the unit, its header units\n  under DIR/forms/c/h/), DIR/index.edn {NAME {:defs {name {:weak :alias}} :refs #{names}}}, DIR/read.tsv each unit's read\n  (ok, or the error). Evaluated from the checkout on the tools' host (arbace.c.* is stage 0's, at the checkout's sources).R1,v11,arbace.core20,*warn-on-reflection*v14,arbace.cpp.run10,ci-atomicsm8,R2,i30,R3,i1,R4,s17,arbace/cpp/run.aeR0,s756,gcc's __atomic builtins, which the lowering writes for the IR's atomics (CP121 (c), LLVM.md §7) and ci's back end does not\n  have (C's class missing-builtin), as macros of plain operations for ci's one thread (CP1: ci runs no threads, doc/c/SPEC.md\n  §6.5): each evaluates its operands once, the memory orders not at all. gcc's judge of the lowered C (lower-check) keeps the\n  builtins; only ci's read defines these (LLVM.md §11). Not the generic __atomic_load, __atomic_store and __atomic_exchange, which\n  repr/c's <builtin> source declares without parameters (stdatomic.h's), so a macro of three would break the declaration: since\n  cppi-deferred the lowering writes them only for an x86_fp80 (a float's or double's atomics are the _n ones on its bits).v14,arbace.cpp.run4,optsv11,arbace.core4,intoV1,s10,-std=gnu23m8,R2,i59,R3,i1,R4,s17,arbace/cpp/run.aeR0,s298,The lowered C's options: the lowering prints C at gnu23 (LLVM.md §7); ci-atomics' macros and ci's x86-64 va_list fields\n  (arbace.cpp.lower/va-field-macros, cppi-deferred). (CX8's ci-math macros went with\n  queue 178: ci's checker declares the math builtins it lacked, check.ae's math-builtin-fns.)v14,arbace.cpp.run7,spit-mkm10,R5,TR6,L1,V2,Myn4,pathm2,R7,R8,Myn1,sm2,R7,R8,R2,i65,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run5,cleanm10,R5,TR6,L1,V1,R9,R2,i69,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run3,tsvm10,R5,TR6,L1,V1,Myn1,fm2,R7,R8,R2,i71,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run8,read-onem10,R6,L1,V4,R10,Myn3,dirm2,R7,R8,Myn2,nmm2,R7,R8,Myn4,pathm2,R7,R8,R0,s90,The lowered C file `path` read by repr/c into DIR/forms/NAME.ae: nil, or the error's text.R2,i78,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run9,load-unitm10,R6,L1,V2,Myn3,dirm2,R7,R8,Myn2,nmm2,R7,R8,R0,s69,A library unit's read: {:forms :units} as arbace.repr.c/read-c gives.R2,i94,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run8,read-libm10,R6,L1,V4,R10,Myn3,dirm2,R7,R8,Myn4,listm2,R7,R8,R11,R0,s221,read-lib DIR LIST THREADS: each line of LIST (NAME PATH: a unit's lowered C) read into DIR (the units already read kept\n  when DIR/read.tsv says so), DIR/index.edn written; the errors printed. Exit 0 when every unit read.R2,i104,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run7,librarym10,R6,L1,V1,Myn3,dirm2,R7,R8,R0,s104,A library of read units: {:dir :index :by-name {name [[unit weak] ...]} :checked (atom {unit checked})}.R2,i141,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run9,ctor-attrm12,R5,TR6,L1,V1,R12,R0,s107,A c/defn name's constructor attribute: nil, or its priority (65536 when it has none, after every priority).R2,i157,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run5,ctorsm10,R6,L1,V2,R13,Myn3,tagm2,R7,R8,R0,s116,A read's top-level forms with its constructors renamed (TAG distinguishes the units): [forms [[priority name] ...]].R2,i166,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run10,with-ctorsm12,R5,TR6,L1,V2,R14,R15,R0,s70,A read with its constructors renamed (ctors), the list kept as :ctors.R2,i184,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run14,check-lib-unitm8,R16,TR2,i189,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run16,checked-lib-unitm12,R5,TR6,L1,V3,R10,R17,Myn2,nmm2,R7,R8,R0,s166,A library unit read from its directory and checked as a program's unit is (kept in the library; a unit is checked once, the\n  other threads that need it wait for it).R2,i191,R3,i1,R4,s17,arbace/cpp/run.aem10,R5,TR6,L1,V3,R10,R17,Myn2,nmm2,R7,R8,R2,i199,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run7,closurem10,R6,L1,V3,R18,R19,R20,R0,s288,The library units a program needs, in the libraries' order (each a library map, musl's last): for a name the program or\n  a linked unit references and nothing linked defines, the first library defining it gives its unit (a strong definition\n  before a weak one). Returns [[lib unit] ...].R2,i210,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run8,sym-namem10,R5,TR6,L1,V1,R21,R2,i232,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run8,def-namem12,R5,TR6,L1,V1,R22,R0,s118,A top-level form's defined name and whether it is static: [name static?] for a c/defn or a non-extern c/var, else nil.R2,i234,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run5,prunem10,R6,L1,V2,R23,R24,R0,s593,The library units' forms cut to the definitions the program reaches (a linker's --gc-sections for ci, CX8): every form that\n  defines nothing is kept (types, declarations, assertions, groups), and its references are roots, as are `roots` (the names\n  the program's own units and musl's reference, the constructors); a name referenced in a unit is its own definition there\n  when it has one (static or not), else every external definition of the name in the units. units: checked units; returns\n  them with :rd's :forms cut (the forms are the checked ones, so the checker's results still hold).R2,i243,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run9,init-unitm12,R5,TR6,L1,V2,R10,R25,R0,s78,The checked unit defining _init, which calls the constructors named, in order.R2,i276,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run7,lib-keym12,R5,TR6,L1,MV1,Myn3,dirm2,R7,R8,m2,R7,R26,R0,s87,A library directory's key for ci's prebuilt runtime: its index's and key file's digest.R2,i292,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run12,prebuilt-libm10,R6,L1,V2,R10,R17,R0,s120,A library of read units made prebuilt (arbace.c.runtime/prebuilt): its units' fragments made once and cached by its key.R2,i304,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run21,build-linked-prebuiltm10,R6,L1,V3,R10,R18,R23,R0,s368,build-linked's node program text with ci's prebuilt runtime (doc/C23-SURVEY.md, \"As built: ci's prebuilt runtime\"): the\n  program's units and the constructors' unit built into fragments, the libraries' fragments made once (cached), the C++\n  libraries' candidates cut at the link to what the program reaches (arbace.c.build/link-text's :prune, as prune cut the forms).R2,i312,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run18,build-linked-formsm12,R5,TR6,L1,V3,R10,R18,R23,R0,s269,The node program's commands of the program's checked units linked with the libraries, the old build (CI_PREBUILT=0): every\n  linked unit checked and kept, the C++ units' forms pruned (prune), all built together (musl's library last, a map of\n  arbace.c.musl/library's).R2,i341,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run12,build-linkedm10,R6,L1,V3,R10,R18,R23,R0,s204,The node program's commands of the program's checked units linked with the libraries: ci's prebuilt runtime\n  (build-linked-prebuilt, cpp-s13, CS273 (a)), CI_PREBUILT=0 the old build (build-linked-forms).R2,i374,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run4,secsm10,R5,TR6,L1,V1,R27,R2,i385,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run20,uses-atomic-generic?m10,R6,L1,V1,R13,R0,s250,Whether the forms call gcc's generic __atomic_load, __atomic_store or __atomic_exchange, which the lowering writes for an\n  atomic of a floating type and repr/c's <builtin> source declares without parameters (the class atomic-generic, review 191 F3).R2,i387,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run10,va-arg-fnsm10,R6,L1,V1,Myn2,llm2,R7,R8,R0,s364,The functions of the IR at `ll` that read a va_list as clang writes va_arg for x86-64 at -O0, inline, by getelementptr into\n  %struct.__va_list_tag (gp_offset, reg_save_area): ci's va_list is its own, so on ci they read garbage (the class va-arg, review\n  191 F2; the user's decision: a gap class now, ci's x86-64 va_list later). Their names as the IR spells them.R2,i395,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run12,read-programm10,R6,L1,V2,R10,Myn1,fm2,R7,R28,R0,s181,A program's lowered C read and checked (arbace.c.run/read-unit's, its constructors renamed): a unit with :status :ok, or\n  {:status :read-error|:read-refused|:check-error :message}.R2,i410,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run8,lower-llm10,R6,L1,V1,Myn2,llm2,R7,R8,R0,s119,The IR at `ll` lowered (arbace.cpp.lower/lower-file) into lowered.c beside it: nil, or [\"lower-refused\" class message].R2,i426,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run9,build-onem12,R5,TR6,L1,V3,R10,R29,Myn4,pathm2,R7,R8,R0,s202,One program: its IR lowered (a path ending in .ll; else the path is lowered C already), the lowered C read and checked,\n  linked, built: [status class message flags seconds cmds], seconds \"LOWER+BUILD\".R2,i435,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run9,work-listm12,R5,TR6,L1,V4,Myn4,listm2,R7,R8,R11,Myn3,outm2,R7,R8,R22,R0,s113,Runs f on each line of LIST in `threads` threads; f returns the row's fields after the id; WORK/OUT.tsv the rows.R2,i465,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run7,libs-fnm12,R5,TR6,L1,V2,R10,Myn5,rtlibm2,R7,R8,R0,s120,A function of a program's extra library directory (or \"\") giving its libraries: [extra? runtime musl], each loaded once.R2,i482,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run10,nodes-listm10,R6,L1,V5,R10,Myn4,workm2,R7,R8,Myn4,listm2,R7,R8,Myn5,rtlibm2,R7,R8,R11,R0,s222,nodes-list WORK LIST RTLIB THREADS: each line of LIST (ID LOWERED.C EXTRA-LIB) built into WORK/ID.nodes; WORK/nodes.tsv\n  lists ID STATUS CLASS MESSAGE FLAGS SECONDS (arbace.c.run's nodes-list's, with the build's seconds).R2,i495,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run12,compile-listm10,R6,L1,V5,R10,Myn3,outm2,R7,R8,Myn4,listm2,R7,R8,Myn5,rtlibm2,R7,R8,R11,R0,s330,compile-list OUT LIST RTLIB THREADS: each line of LIST (ID LOWERED.C EXTRA-LIB PKG) built and translated by cf2g into\n  OUT/progs/PKG/prog.go (package PKG, path arbace/progs/PKG); OUT/nodes.tsv as nodes-list's (cf2g's refusal: refused, its\n  class). CI_AOT_NODES: the node program kept beside, prog.nodes, for the interpreted run.R2,i506,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run7,check-cm10,R6,L1,V3,R10,Myn4,listm2,R7,R8,R11,R0,s388,check-c LIST THREADS (ORS27: the lowering's C level from the records, where gcc compiling the lowered C was): each line of LIST\n  (NAME DIR) has DIR/lowered.c read by repr/c and checked by ci's checker as a program is (read-program); DIR/ci-check.status the\n  outcome (ok, read-error, read-refused, check-error, check-crash), DIR/ci-check.log its message. LIST.out the rows (work-list's).R2,i531,R3,i1,R4,s17,arbace/cpp/run.aev14,arbace.cpp.run5,-mainm10,R6,L1,V3,R30,R31,R32,R0,s209,bin/cppi's ci steps: read-lib DIR LIST THREADS, lower-lib DIR LIST THREADS, check-c LIST THREADS, nodes-list WORK LIST RTLIB THREADS, compile-list OUT LIST RTLIB THREADS,\n  nodes RTLIB EXTRA-LIB OUT LOWERED.C.R2,i545,R3,i1,R4,s17,arbace/cpp/run.ae")

var Lit_227 *jrt.String = jrt.Intern("arbace.cpp.run$eval97000004$loading__1927001464__auto____97000005")

var Lit_228 *jrt.String = jrt.Intern("arbace.cpp.run$eval97000008$fn__97000009")

var Lit_229 *jrt.String = jrt.Intern("arbace.cpp.run$fn__97000014")

var Lit_230 *jrt.String = jrt.Intern("arbace.cpp.run$fn__97000047")

var Lit_231 *jrt.String = jrt.Intern("arbace.cpp.run$spit_mk")

var Lit_232 *jrt.String = jrt.Intern("arbace.cpp.run$clean")

var Lit_233 *jrt.String = jrt.Intern("arbace.cpp.run$tsv")

var Lit_234 *jrt.String = jrt.Intern("arbace.cpp.run$read_one")

var Lit_235 *jrt.String = jrt.Intern("arbace.cpp.run$load_unit")

var Lit_236 *jrt.String = jrt.Intern("arbace.cpp.run$read_lib")

var Lit_237 *jrt.String = jrt.Intern("arbace.cpp.run$library")

var Lit_238 *jrt.String = jrt.Intern("arbace.cpp.run$ctor_attr")

var Lit_239 *jrt.String = jrt.Intern("arbace.cpp.run$ctors")

var Lit_240 *jrt.String = jrt.Intern("arbace.cpp.run$with_ctors")

var Lit_241 *jrt.String = jrt.Intern("arbace.cpp.run$checked_lib_unit")

var Lit_242 *jrt.String = jrt.Intern("arbace.cpp.run$check_lib_unit")

var Lit_243 *jrt.String = jrt.Intern("arbace.cpp.run$closure")

var Lit_244 *jrt.String = jrt.Intern("arbace.cpp.run$sym_name")

var Lit_245 *jrt.String = jrt.Intern("arbace.cpp.run$def_name")

var Lit_246 *jrt.String = jrt.Intern("arbace.cpp.run$prune")

var Lit_247 *jrt.String = jrt.Intern("arbace.cpp.run$init_unit")

var Lit_248 *jrt.String = jrt.Intern("arbace.cpp.run$lib_key")

var Lit_249 *jrt.String = jrt.Intern("arbace.cpp.run$prebuilt_lib")

var Lit_250 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_prebuilt")

var Lit_251 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked_forms")

var Lit_252 *jrt.String = jrt.Intern("arbace.cpp.run$build_linked")

var Lit_253 *jrt.String = jrt.Intern("arbace.cpp.run$secs")

var Lit_254 *jrt.String = jrt.Intern("arbace.cpp.run$uses_atomic_generic_QMARK_")

var Lit_255 *jrt.String = jrt.Intern("arbace.cpp.run$va_arg_fns")

var Lit_256 *jrt.String = jrt.Intern("arbace.cpp.run$read_program")

var Lit_257 *jrt.String = jrt.Intern("arbace.cpp.run$lower_ll")

var Lit_258 *jrt.String = jrt.Intern("arbace.cpp.run$build_one")

var Lit_259 *jrt.String = jrt.Intern("arbace.cpp.run$work_list")

var Lit_260 *jrt.String = jrt.Intern("arbace.cpp.run$libs_fn")

var Lit_261 *jrt.String = jrt.Intern("arbace.cpp.run$nodes_list")

var Lit_262 *jrt.String = jrt.Intern("arbace.cpp.run$compile_list")

var Lit_263 *jrt.String = jrt.Intern("arbace.cpp.run$check_c")

var Lit_264 *jrt.String = jrt.Intern("arbace.cpp.run$_main")
