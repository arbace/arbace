//line a2g_strings.ae:1
package aot_arbace_a2g_dyn

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_7 *jrt.String = jrt.Intern("t")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_9 *jrt.String = jrt.Intern("a")

var Lit_10 *jrt.String = jrt.Intern("arbace.a2g.model")

var Lit_11 *jrt.String = jrt.Intern("m")

var Lit_12 *jrt.String = jrt.Intern("arbace.a2g.code")

var Lit_13 *jrt.String = jrt.Intern("c")

var Lit_14 *jrt.String = jrt.Intern("arbace.a2g.names")

var Lit_15 *jrt.String = jrt.Intern("nm")

var Lit_16 *jrt.String = jrt.Intern("arbace.a2g.jrt")

var Lit_17 *jrt.String = jrt.Intern("jrt")

var Lit_18 *jrt.String = jrt.Intern("arbace.classes.opcodes")

var Lit_19 *jrt.String = jrt.Intern("Opcodes")

var Lit_20 *jrt.String = jrt.Intern("commute")

var Lit_21 *jrt.String = jrt.Intern("deref")

var Lit_22 *jrt.String = jrt.Intern("conj")

var Lit_23 *jrt.String = jrt.Intern("arbace.a2g.dyn")

var Lit_24 *jrt.String = jrt.Intern("doc")

var Lit_25 *jrt.String = jrt.Intern("A2G-SPEC §5.12: Dyn, the Go type of the objects of classes made at run time (deftype,\n  defrecord, reify), in arbace/lang's a2g_dyn.go. Go cannot make types at run time, so one\n  struct serves every such class: it has a Go method for every method of every interface of\n  the closed world a run-time class may implement (the public interfaces translated, with their\n  superinterfaces) and every marker, so that a Go assertion to any of them succeeds; each\n  method calls the fn its class set for the method (by a slot number a2g assigns to the method's\n  name and descriptor), else the interface's default method, else throws AbstractMethodError.\n  The nominal check (does the object's class implement the interface) is in a2g's instanceof\n  and checkcast (decls/instance-forms, jrt.Dynamic).\n\n  The evaluator reaches it through the natives of Compiler$Dyn (arbace/lang/Compiler.ae):\n  defineClass, setMethod, newInstance, getField, setField.")

var Lit_26 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_27 *jrt.String = jrt.Intern("with-meta")

var Lit_28 *jrt.String = jrt.Intern("tag")

var Lit_29 *jrt.String = jrt.Intern("seq")

var Lit_30 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_31 *jrt.String = jrt.Intern("chunk-first")

var Lit_32 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_33 *jrt.String = jrt.Intern("chunk-append")

var Lit_34 *jrt.String = jrt.Intern("chunk-cons")

var Lit_35 *jrt.String = jrt.Intern("first")

var Lit_36 *jrt.String = jrt.Intern("cons")

var Lit_37 *jrt.String = jrt.Intern("chunk")

var Lit_38 *jrt.String = jrt.Intern("chunk-rest")

var Lit_39 *jrt.String = jrt.Intern("rest")

var Lit_40 *jrt.String = jrt.Intern("rt-casts")

var Lit_41 *jrt.String = jrt.Intern("translated?")

var Lit_42 *jrt.String = jrt.Intern("api-class")

var Lit_43 *jrt.String = jrt.Intern("not")

var Lit_44 *jrt.String = jrt.Intern("flags")

var Lit_45 *jrt.String = jrt.Intern("info")

var Lit_46 *jrt.String = jrt.Intern("filter")

var Lit_47 *jrt.String = jrt.Intern("sort")

var Lit_48 *jrt.String = jrt.Intern("interface?")

var Lit_49 *jrt.String = jrt.Intern("public?")

var Lit_50 *jrt.String = jrt.Intern("compiled-pkg?")

var Lit_51 *jrt.String = jrt.Intern("pkg")

var Lit_52 *jrt.String = jrt.Intern("starts-with?")

var Lit_53 *jrt.String = jrt.Intern("reflected?")

var Lit_54 *jrt.String = jrt.Intern("concat")

var Lit_55 *jrt.String = jrt.Intern("hand-written?")

var Lit_56 *jrt.String = jrt.Intern("contains?")

var Lit_57 *jrt.String = jrt.Intern("funcs")

var Lit_58 *jrt.String = jrt.Intern("*w*")

var Lit_59 *jrt.String = jrt.Intern("go-name")

var Lit_60 *jrt.String = jrt.Intern("keys")

var Lit_61 *jrt.String = jrt.Intern("jrt-classes")

var Lit_62 *jrt.String = jrt.Intern("distinct")

var Lit_63 *jrt.String = jrt.Intern("not=")

var Lit_64 *jrt.String = jrt.Intern("in-world?")

var Lit_65 *jrt.String = jrt.Intern("all-supertypes")

var Lit_66 *jrt.String = jrt.Intern("vec")

var Lit_67 *jrt.String = jrt.Intern("object-keys")

var Lit_68 *jrt.String = jrt.Intern("vmethods")

var Lit_69 *jrt.String = jrt.Intern("object-slots")

var Lit_70 *jrt.String = jrt.Intern("impl-of")

var Lit_71 *jrt.String = jrt.Intern("default")

var Lit_72 *jrt.String = jrt.Intern("kind")

var Lit_73 *jrt.String = jrt.Intern("owner")

var Lit_74 *jrt.String = jrt.Intern("class-sym")

var Lit_75 *jrt.String = jrt.Intern("lang")

var Lit_76 *jrt.String = jrt.Intern("method-base")

var Lit_77 *jrt.String = jrt.Intern("second")

var Lit_78 *jrt.String = jrt.Intern("sort-by")

var Lit_79 *jrt.String = jrt.Intern("prim?")

var Lit_80 *jrt.String = jrt.Intern("list")

var Lit_81 *jrt.String = jrt.Intern("pointer-desc?")

var Lit_82 *jrt.String = jrt.Intern("else")

var Lit_83 *jrt.String = jrt.Intern("Box")

var Lit_84 *jrt.String = jrt.Intern("dynRef")

var Lit_85 *jrt.String = jrt.Intern("Z")

var Lit_86 *jrt.String = jrt.Intern("C")

var Lit_87 *jrt.String = jrt.Intern("array?")

var Lit_88 *jrt.String = jrt.Intern("assert")

var Lit_89 *jrt.String = jrt.Intern("go-type")

var Lit_90 *jrt.String = jrt.Intern("dynUnbox")

var Lit_91 *jrt.String = jrt.Intern("Prim_boolean")

var Lit_92 *jrt.String = jrt.Intern("Prim_char")

var Lit_93 *jrt.String = jrt.Intern("iterate")

var Lit_94 *jrt.String = jrt.Intern("elem-type")

var Lit_95 *jrt.String = jrt.Intern(".ArrayClass")

var Lit_96 *jrt.String = jrt.Intern("symbol")

var Lit_97 *jrt.String = jrt.Intern("prim-desc->name")

var Lit_98 *jrt.String = jrt.Intern("desc->internal")

var Lit_99 *jrt.String = jrt.Intern("inst")

var Lit_100 *jrt.String = jrt.Intern("A2g_CastArray")

var Lit_101 *jrt.String = jrt.Intern("apply")

var Lit_102 *jrt.String = jrt.Intern("f")

var Lit_103 *jrt.String = jrt.Intern("method-desc")

var Lit_104 *jrt.String = jrt.Intern("repeat")

var Lit_105 *jrt.String = jrt.Intern(".ApplyTo_ISeq__O")

var Lit_106 *jrt.String = jrt.Intern("RT_Seq_O__ISeq")

var Lit_107 *jrt.String = jrt.Intern("RefArrayOf")

var Lit_108 *jrt.String = jrt.Intern("Object_class")

var Lit_109 *jrt.String = jrt.Intern("call-impl")

var Lit_110 *jrt.String = jrt.Intern("java-type-name")

var Lit_111 *jrt.String = jrt.Intern("replace")

var Lit_112 *jrt.String = jrt.Intern("parse-method-desc")

var Lit_113 *jrt.String = jrt.Intern("some")

var Lit_114 *jrt.String = jrt.Intern("name")

var Lit_115 *jrt.String = jrt.Intern("desc")

var Lit_116 *jrt.String = jrt.Intern("methods")

var Lit_117 *jrt.String = jrt.Intern("decl")

var Lit_118 *jrt.String = jrt.Intern("join")

var Lit_119 *jrt.String = jrt.Intern("map")

var Lit_120 *jrt.String = jrt.Intern(".-Self")

var Lit_121 *jrt.String = jrt.Intern("line")

var Lit_122 *jrt.String = jrt.Intern("column")

var Lit_123 *jrt.String = jrt.Intern("when")

var Lit_124 *jrt.String = jrt.Intern(".DynImplements")

var Lit_125 *jrt.String = jrt.Intern("do")

var Lit_126 *jrt.String = jrt.Intern("return")

var Lit_127 *jrt.String = jrt.Intern("defaults-for")

var Lit_128 *jrt.String = jrt.Intern("panic")

var Lit_129 *jrt.String = jrt.Intern("dynAbstract")

var Lit_130 *jrt.String = jrt.Intern("abstract-text")

var Lit_131 *jrt.String = jrt.Intern("iface-fallback")

var Lit_132 *jrt.String = jrt.Intern("range")

var Lit_133 *jrt.String = jrt.Intern("box-arg")

var Lit_134 *jrt.String = jrt.Intern("go")

var Lit_135 *jrt.String = jrt.Intern("method")

var Lit_136 *jrt.String = jrt.Intern("let")

var Lit_137 *jrt.String = jrt.Intern("aget")

var Lit_138 *jrt.String = jrt.Intern(".-Slots")

var Lit_139 *jrt.String = jrt.Intern(".-D")

var Lit_140 *jrt.String = jrt.Intern("!=")

var Lit_141 *jrt.String = jrt.Intern("r")

var Lit_142 *jrt.String = jrt.Intern("dynSuper")

var Lit_143 *jrt.String = jrt.Intern("convert-result")

var Lit_144 *jrt.String = jrt.Intern("method-form")

var Lit_145 *jrt.String = jrt.Intern("*")

var Lit_146 *jrt.String = jrt.Intern("dynCore")

var Lit_147 *jrt.String = jrt.Intern("final?")

var Lit_148 *jrt.String = jrt.Intern("leaf?")

var Lit_149 *jrt.String = jrt.Intern("sub-supers")

var Lit_150 *jrt.String = jrt.Intern("static?")

var Lit_151 *jrt.String = jrt.Intern("private?")

var Lit_152 *jrt.String = jrt.Intern("superclass-chain")

var Lit_153 *jrt.String = jrt.Intern("jrt-impl")

var Lit_154 *jrt.String = jrt.Intern("class")

var Lit_155 *jrt.String = jrt.Intern(".HashCode__I")

var Lit_156 *jrt.String = jrt.Intern(".Self_Object")

var Lit_157 *jrt.String = jrt.Intern("Object_toString")

var Lit_158 *jrt.String = jrt.Intern(".Equals_O__Z")

var Lit_159 *jrt.String = jrt.Intern("promoted")

var Lit_160 *jrt.String = jrt.Intern("sub-name")

var Lit_161 *jrt.String = jrt.Intern("As")

var Lit_162 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_163 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_164 *jrt.String = jrt.Intern("hash-map")

var Lit_165 *jrt.String = jrt.Intern("*f*")

var Lit_166 *jrt.String = jrt.Intern("func")

var Lit_167 *jrt.String = jrt.Intern("slice")

var Lit_168 *jrt.String = jrt.Intern("CtorInfo")

var Lit_169 *jrt.String = jrt.Intern("dc")

var Lit_170 *jrt.String = jrt.Intern("DynClass")

var Lit_171 *jrt.String = jrt.Intern("lit")

var Lit_172 *jrt.String = jrt.Intern("mdesc-in-world?")

var Lit_173 *jrt.String = jrt.Intern("ctor-real-desc")

var Lit_174 *jrt.String = jrt.Intern("struct-methods")

var Lit_175 *jrt.String = jrt.Intern("ctor-base")

var Lit_176 *jrt.String = jrt.Intern("Params")

var Lit_177 *jrt.String = jrt.Intern("Modifiers")

var Lit_178 *jrt.String = jrt.Intern("AccPublic")

var Lit_179 *jrt.String = jrt.Intern("New")

var Lit_180 *jrt.String = jrt.Intern("list*")

var Lit_181 *jrt.String = jrt.Intern("Class")

var Lit_182 *jrt.String = jrt.Intern("class-val")

var Lit_183 *jrt.String = jrt.Intern("fn")

var Lit_184 *jrt.String = jrt.Intern("any")

var Lit_185 *jrt.String = jrt.Intern("args")

var Lit_186 *jrt.String = jrt.Intern("trivial-init?")

var Lit_187 *jrt.String = jrt.Intern("set!")

var Lit_188 *jrt.String = jrt.Intern(".MarkDynamic")

var Lit_189 *jrt.String = jrt.Intern("addr")

var Lit_190 *jrt.String = jrt.Intern("D")

var Lit_191 *jrt.String = jrt.Intern("F")

var Lit_192 *jrt.String = jrt.Intern("make")

var Lit_193 *jrt.String = jrt.Intern("map-indexed")

var Lit_194 *jrt.String = jrt.Intern("methods-of")

var Lit_195 *jrt.String = jrt.Intern("into")

var Lit_196 *jrt.String = jrt.Intern("set")

var Lit_197 *jrt.String = jrt.Intern("go-method-names")

var Lit_198 *jrt.String = jrt.Intern("remove")

var Lit_199 *jrt.String = jrt.Intern("object-fallback")

var Lit_200 *jrt.String = jrt.Intern("keep-indexed")

var Lit_201 *jrt.String = jrt.Intern("a2g")

var Lit_202 *jrt.String = jrt.Intern("comment")

var Lit_203 *jrt.String = jrt.Intern("type")

var Lit_204 *jrt.String = jrt.Intern("struct")

var Lit_205 *jrt.String = jrt.Intern("var")

var Lit_206 *jrt.String = jrt.Intern("string")

var Lit_207 *jrt.String = jrt.Intern("int32")

var Lit_208 *jrt.String = jrt.Intern("Ref")

var Lit_209 *jrt.String = jrt.Intern("==")

var Lit_210 *jrt.String = jrt.Intern("GetClass__Class")

var Lit_211 *jrt.String = jrt.Intern(".-Cls")

var Lit_212 *jrt.String = jrt.Intern("Clone__O")

var Lit_213 *jrt.String = jrt.Intern("CloneNotSupported")

var Lit_214 *jrt.String = jrt.Intern("CloneShallow")

var Lit_215 *jrt.String = jrt.Intern("class-fallback")

var Lit_216 *jrt.String = jrt.Intern("ctor-infos")

var Lit_217 *jrt.String = jrt.Intern(".Info")

var Lit_218 *jrt.String = jrt.Intern("k")

var Lit_219 *jrt.String = jrt.Intern("i")

var Lit_220 *jrt.String = jrt.Intern("fi")

var Lit_221 *jrt.String = jrt.Intern("FieldInfo")

var Lit_222 *jrt.String = jrt.Intern("Name")

var Lit_223 *jrt.String = jrt.Intern(".String")

var Lit_224 *jrt.String = jrt.Intern("NN")

var Lit_225 *jrt.String = jrt.Intern("Type")

var Lit_226 *jrt.String = jrt.Intern("ft")

var Lit_227 *jrt.String = jrt.Intern("Get")

var Lit_228 *jrt.String = jrt.Intern("o")

var Lit_229 *jrt.String = jrt.Intern(".-A")

var Lit_230 *jrt.String = jrt.Intern(".-F_closed")

var Lit_231 *jrt.String = jrt.Intern("Compiler_EvalFn")

var Lit_232 *jrt.String = jrt.Intern(".IsPrimitive__Z")

var Lit_233 *jrt.String = jrt.Intern(".-Set")

var Lit_234 *jrt.String = jrt.Intern("v")

var Lit_235 *jrt.String = jrt.Intern(".Store")

var Lit_236 *jrt.String = jrt.Intern(".-Fields")

var Lit_237 *jrt.String = jrt.Intern("append")

var Lit_238 *jrt.String = jrt.Intern("native-name")

var Lit_239 *jrt.String = jrt.Intern("String")

var Lit_240 *jrt.String = jrt.Intern("interfaces")

var Lit_241 *jrt.String = jrt.Intern("slot-keys")

var Lit_242 *jrt.String = jrt.Intern("dynCore is what an object of a class made at run time has besides its superclass's\nstruct: its class's dispatch table D, its fields F, and Self, the object (a Dyn or a DynSub_C)\naround it, which its methods (every interface's, by slot) pass to the slots' fns and the\ninterfaces' default methods.\n")

var Lit_243 *jrt.String = jrt.Intern("Self")

var Lit_244 *jrt.String = jrt.Intern("Dyn")

var Lit_245 *jrt.String = jrt.Intern("Dyn is an object of a class made at run time (deftype, defrecord, reify): Object's\nstruct and a dynCore.\n")

var Lit_246 *jrt.String = jrt.Intern("Object")

var Lit_247 *jrt.String = jrt.Intern("DynClass is a class made at run time: its Class, the fns of its methods by slot (nil:\nthe interface's default, else AbstractMethodError), the interfaces it implements (with their\nsuperinterfaces), and its methods by name and descriptor (all of them, for reflection and the\ninterfaces made at run time).\n")

var Lit_248 *jrt.String = jrt.Intern("Cls")

var Lit_249 *jrt.String = jrt.Intern("Slots")

var Lit_250 *jrt.String = jrt.Intern("IFn")

var Lit_251 *jrt.String = jrt.Intern("Ifaces")

var Lit_252 *jrt.String = jrt.Intern("bool")

var Lit_253 *jrt.String = jrt.Intern("ByKey")

var Lit_254 *jrt.String = jrt.Intern("SlotMap")

var Lit_255 *jrt.String = jrt.Intern("Proxy")

var Lit_256 *jrt.String = jrt.Intern("Own")

var Lit_257 *jrt.String = jrt.Intern("CF")

var Lit_258 *jrt.String = jrt.Intern("dynObject")

var Lit_259 *jrt.String = jrt.Intern("dynObject is an object of a class made at run time: a Dyn, or a DynSub_C (a proxy of class C).\n")

var Lit_260 *jrt.String = jrt.Intern("interface")

var Lit_261 *jrt.String = jrt.Intern("DynClassOf")

var Lit_262 *jrt.String = jrt.Intern("DynFields")

var Lit_263 *jrt.String = jrt.Intern("DynImplements")

var Lit_264 *jrt.String = jrt.Intern("dynSuper is what a proxy's method fn answers when the proxy has no fn for the method: the\nsuperclass's implementation runs (Compiler$Dyn.superMarker).\n")

var Lit_265 *jrt.String = jrt.Intern("Object_New")

var Lit_266 *jrt.String = jrt.Intern("dynMu")

var Lit_267 *jrt.String = jrt.Intern("sync")

var Lit_268 *jrt.String = jrt.Intern("Mutex")

var Lit_269 *jrt.String = jrt.Intern("dynClasses")

var Lit_270 *jrt.String = jrt.Intern("type-params")

var Lit_271 *jrt.String = jrt.Intern("T")

var Lit_272 *jrt.String = jrt.Intern("p")

var Lit_273 *jrt.String = jrt.Intern("x")

var Lit_274 *jrt.String = jrt.Intern("values")

var Lit_275 *jrt.String = jrt.Intern("ok")

var Lit_276 *jrt.String = jrt.Intern("Unbox")

var Lit_277 *jrt.String = jrt.Intern("Thrown")

var Lit_278 *jrt.String = jrt.Intern("NPE")

var Lit_279 *jrt.String = jrt.Intern("ClassCast")

var Lit_280 *jrt.String = jrt.Intern("AbstractMethodError_New_String")

var Lit_281 *jrt.String = jrt.Intern("Str")

var Lit_282 *jrt.String = jrt.Intern("+")

var Lit_283 *jrt.String = jrt.Intern("Receiver class ")

var Lit_284 *jrt.String = jrt.Intern(".-Name")

var Lit_285 *jrt.String = jrt.Intern(".DynClassOf")

var Lit_286 *jrt.String = jrt.Intern(" does not define or inherit an implementation of the resolved method ")

var Lit_287 *jrt.String = jrt.Intern("newDyn")

var Lit_288 *jrt.String = jrt.Intern("newDyn is a new object of a class made at run time, with the header's dynamic flag.\n")

var Lit_289 *jrt.String = jrt.Intern("d")

var Lit_290 *jrt.String = jrt.Intern(".-Ifaces")

var Lit_291 *jrt.String = jrt.Intern(".-F")

var Lit_292 *jrt.String = jrt.Intern("ToString__String")

var Lit_293 *jrt.String = jrt.Intern(".Invoke_O__O")

var Lit_294 *jrt.String = jrt.Intern("String_Cast")

var Lit_295 *jrt.String = jrt.Intern("HashCode__I")

var Lit_296 *jrt.String = jrt.Intern("RT_IntCast_O__I")

var Lit_297 *jrt.String = jrt.Intern(".-Object")

var Lit_298 *jrt.String = jrt.Intern("Equals_O__Z")

var Lit_299 *jrt.String = jrt.Intern(".Invoke_O_O__O")

var Lit_300 *jrt.String = jrt.Intern("par-mapv")

var Lit_301 *jrt.String = jrt.Intern("dynAddInterface")

var Lit_302 *jrt.String = jrt.Intern("aset")

var Lit_303 *jrt.String = jrt.Intern("_")

var Lit_304 *jrt.String = jrt.Intern("s")

var Lit_305 *jrt.String = jrt.Intern(".-Interfaces")

var Lit_306 *jrt.String = jrt.Intern("dynClassOf")

var Lit_307 *jrt.String = jrt.Intern(".Lock")

var Lit_308 *jrt.String = jrt.Intern(".Unlock")

var Lit_309 *jrt.String = jrt.Intern("IllegalArgumentException_New_String")

var Lit_310 *jrt.String = jrt.Intern("not a class made at run time: ")

var Lit_311 *jrt.String = jrt.Intern("fn-field-native")

var Lit_312 *jrt.String = jrt.Intern("dynTypeName")

var Lit_313 *jrt.String = jrt.Intern("dynTypeName: Class.getTypeName (int, java.lang.Object, byte[]).")

var Lit_314 *jrt.String = jrt.Intern(".IsArray__Z")

var Lit_315 *jrt.String = jrt.Intern(".GetComponentType__Class")

var Lit_316 *jrt.String = jrt.Intern("[]")

var Lit_317 *jrt.String = jrt.Intern(".GetName__String")

var Lit_318 *jrt.String = jrt.Intern("dynAbstractText")

var Lit_319 *jrt.String = jrt.Intern("dynAbstractText: HotSpot's text of an unimplemented method of an interface made at run time.")

var Lit_320 *jrt.String = jrt.Intern("ps")

var Lit_321 *jrt.String = jrt.Intern("ret")

var Lit_322 *jrt.String = jrt.Intern("'abstract ")

var Lit_323 *jrt.String = jrt.Intern(" ")

var Lit_324 *jrt.String = jrt.Intern("(")

var Lit_325 *jrt.String = jrt.Intern(">")

var Lit_326 *jrt.String = jrt.Intern(", ")

var Lit_327 *jrt.String = jrt.Intern(")' of interface ")

var Lit_328 *jrt.String = jrt.Intern(".")

var Lit_329 *jrt.String = jrt.Intern("dynClassList")

var Lit_330 *jrt.String = jrt.Intern("dynClassList: the classes of a Class[] (nil for null).")

var Lit_331 *jrt.String = jrt.Intern("RefArray")

var Lit_332 *jrt.String = jrt.Intern("dyn-call-fast")

var Lit_333 *jrt.String = jrt.Intern("dynCall")

var Lit_334 *jrt.String = jrt.Intern("dynCall calls a method's fn with the object (none for a static method) and the\narguments, boxed.\n")

var Lit_335 *jrt.String = jrt.Intern("impl")

var Lit_336 *jrt.String = jrt.Intern("this")

var Lit_337 *jrt.String = jrt.Intern("and")

var Lit_338 *jrt.String = jrt.Intern("<=")

var Lit_339 *jrt.String = jrt.Intern("len")

var Lit_340 *jrt.String = jrt.Intern("dynCallFast")

var Lit_341 *jrt.String = jrt.Intern("spread")

var Lit_342 *jrt.String = jrt.Intern("dynOf")

var Lit_343 *jrt.String = jrt.Intern("not an object of a class made at run time")

var Lit_344 *jrt.String = jrt.Intern("mapcat")

var Lit_345 *jrt.String = jrt.Intern("dynSlots")

var Lit_346 *jrt.String = jrt.Intern("dynConvert")

var Lit_347 *jrt.String = jrt.Intern("switch")

var Lit_348 *jrt.String = jrt.Intern(".Descriptor")

var Lit_349 *jrt.String = jrt.Intern("case")

var Lit_350 *jrt.String = jrt.Intern("V")

var Lit_351 *jrt.String = jrt.Intern("jobs")

var Lit_352 *jrt.String = jrt.Intern("fieldNames")

var Lit_353 *jrt.String = jrt.Intern(".DynFields")

var Lit_354 *jrt.String = jrt.Intern("Set")

var Lit_355 *jrt.String = jrt.Intern("DefineDynamic")

var Lit_356 *jrt.String = jrt.Intern(".-IsInstance")

var Lit_357 *jrt.String = jrt.Intern("ClassInfo")

var Lit_358 *jrt.String = jrt.Intern("bit-or")

var Lit_359 *jrt.String = jrt.Intern("AccFinal")

var Lit_360 *jrt.String = jrt.Intern("Kind")

var Lit_361 *jrt.String = jrt.Intern("KindClass")

var Lit_362 *jrt.String = jrt.Intern("Super")

var Lit_363 *jrt.String = jrt.Intern("Go")

var Lit_364 *jrt.String = jrt.Intern("arbace/lang.Dyn")

var Lit_365 *jrt.String = jrt.Intern("key")

var Lit_366 *jrt.String = jrt.Intern("params")

var Lit_367 *jrt.String = jrt.Intern(")")

var Lit_368 *jrt.String = jrt.Intern(".-SlotMap")

var Lit_369 *jrt.String = jrt.Intern(".-Proxy")

var Lit_370 *jrt.String = jrt.Intern(".-ByKey")

var Lit_371 *jrt.String = jrt.Intern(".-Methods")

var Lit_372 *jrt.String = jrt.Intern("MethodInfo")

var Lit_373 *jrt.String = jrt.Intern("Return")

var Lit_374 *jrt.String = jrt.Intern("Invoke")

var Lit_375 *jrt.String = jrt.Intern("UnsupportedOperationException_New_String")

var Lit_376 *jrt.String = jrt.Intern("AccStatic")

var Lit_377 *jrt.String = jrt.Intern("tl")

var Lit_378 *jrt.String = jrt.Intern("tail")

var Lit_379 *jrt.String = jrt.Intern(".-Ctors")

var Lit_380 *jrt.String = jrt.Intern("AccInterface")

var Lit_381 *jrt.String = jrt.Intern("AccAbstract")

var Lit_382 *jrt.String = jrt.Intern("KindInterface")

var Lit_383 *jrt.String = jrt.Intern("Interfaces")

var Lit_384 *jrt.String = jrt.Intern("extends")

var Lit_385 *jrt.String = jrt.Intern("arbace/lang.Dyn (interface)")

var Lit_386 *jrt.String = jrt.Intern("super")

var Lit_387 *jrt.String = jrt.Intern("arbace/lang.Compiler_EvalFn (fn)")

var Lit_388 *jrt.String = jrt.Intern(".-Modifiers")

var Lit_389 *jrt.String = jrt.Intern("AccPrivate")

var Lit_390 *jrt.String = jrt.Intern("fieldValues")

var Lit_391 *jrt.String = jrt.Intern("nme")

var Lit_392 *jrt.String = jrt.Intern(".-Own")

var Lit_393 *jrt.String = jrt.Intern("IFn_Cast")

var Lit_394 *jrt.String = jrt.Intern("factory")

var Lit_395 *jrt.String = jrt.Intern("dynSubFor")

var Lit_396 *jrt.String = jrt.Intern("results")

var Lit_397 *jrt.String = jrt.Intern("proxy-classes")

var Lit_398 *jrt.String = jrt.Intern("slots")

var Lit_399 *jrt.String = jrt.Intern("ctors")

var Lit_400 *jrt.String = jrt.Intern("own")

var Lit_401 *jrt.String = jrt.Intern("proxy of ")

var Lit_402 *jrt.String = jrt.Intern(" is not in the Go build")

var Lit_403 *jrt.String = jrt.Intern("arbace/lang.DynSub (proxy)")

var Lit_404 *jrt.String = jrt.Intern("while")

var Lit_405 *jrt.String = jrt.Intern(".-Super")

var Lit_406 *jrt.String = jrt.Intern("String_class")

var Lit_407 *jrt.String = jrt.Intern("__arbaceFnMap")

var Lit_408 *jrt.String = jrt.Intern("sub-forms")

var Lit_409 *jrt.String = jrt.Intern("arbace.a2g.dyn$abstract_text")

var Lit_410 *jrt.String = jrt.Intern(" of interface ")

var Lit_411 *jrt.String = jrt.Intern("/")

var Lit_412 *jrt.String = jrt.Intern("arbace.a2g.dyn$abstract_text$declares_QMARK___256000113")

var Lit_413 *jrt.String = jrt.Intern("arbace.a2g.dyn$abstract_text$declares_QMARK___256000113$fn__256000114")

var Lit_414 *jrt.String = jrt.Intern("arbace.a2g.dyn$abstract_text$fn__256000117")

var Lit_415 *jrt.String = jrt.Intern("arbace.a2g.dyn$abstract_text$fn__256000117$fn__256000119")

var Lit_416 *jrt.String = jrt.Intern("arbace.a2g.dyn$box_arg")

var Lit_417 *jrt.String = jrt.Intern("arbace.a2g.dyn$call_impl")

var Lit_418 *jrt.String = jrt.Intern("invoke")

var Lit_419 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_420 *jrt.String = jrt.Intern("arbace.a2g.dyn$class_fallback")

var Lit_421 *jrt.String = jrt.Intern(".Impl_")

var Lit_422 *jrt.String = jrt.Intern(".-")

var Lit_423 *jrt.String = jrt.Intern("arbace.a2g.dyn$class_fallback$ret__256000206")

var Lit_424 *jrt.String = jrt.Intern("arbace.a2g.dyn$convert_result")

var Lit_425 *jrt.String = jrt.Intern("arbace/lang/RT")

var Lit_426 *jrt.String = jrt.Intern("(Ljava/lang/Object;)")

var Lit_427 *jrt.String = jrt.Intern("_Cast")

var Lit_428 *jrt.String = jrt.Intern("arbace.a2g.dyn$convert_result$fn__256000097")

var Lit_429 *jrt.String = jrt.Intern("jrt/Prim_")

var Lit_430 *jrt.String = jrt.Intern("_class")

var Lit_431 *jrt.String = jrt.Intern("arbace.a2g.dyn$convert_result$fn__256000097$fn__256000098")

var Lit_432 *jrt.String = jrt.Intern("arbace.a2g.dyn$ctor_infos")

var Lit_433 *jrt.String = jrt.Intern("dynCtors_")

var Lit_434 *jrt.String = jrt.Intern("arbace.a2g.dyn$ctor_infos$arg_conv__256000213")

var Lit_435 *jrt.String = jrt.Intern("arbace.a2g.dyn$ctor_infos$iter__256000215__256000219")

var Lit_436 *jrt.String = jrt.Intern("arbace.a2g.dyn$ctor_infos$iter__256000215__256000219$fn__256000220")

var Lit_437 *jrt.String = jrt.Intern("<init>")

var Lit_438 *jrt.String = jrt.Intern("_Init")

var Lit_439 *jrt.String = jrt.Intern("arbace.a2g.dyn$ctor_infos$iter__256000215__256000219$fn__256000220$fn__256000221")

var Lit_440 *jrt.String = jrt.Intern("arbace.a2g.dyn$ctor_infos$iter__256000215__256000219$fn__256000220$fn__256000221$fn__256000228")

var Lit_441 *jrt.String = jrt.Intern("arbace.a2g.dyn$ctor_infos$iter__256000215__256000219$fn__256000220$fn__256000237")

var Lit_442 *jrt.String = jrt.Intern("arbace.a2g.dyn$defaults_for")

var Lit_443 *jrt.String = jrt.Intern("arbace.a2g.dyn$defaults_for$fn__256000089")

var Lit_444 *jrt.String = jrt.Intern("arbace.a2g.dyn$defaults_for$iter__256000078__256000082")

var Lit_445 *jrt.String = jrt.Intern("arbace.a2g.dyn$defaults_for$iter__256000078__256000082$fn__256000083")

var Lit_446 *jrt.String = jrt.Intern("arbace.a2g.dyn$defaults_for$iter__256000078__256000082$fn__256000083$fn__256000084")

var Lit_447 *jrt.String = jrt.Intern("arbace.a2g.dyn$enabled_QMARK_")

var Lit_448 *jrt.String = jrt.Intern("arbace.a2g.dyn$eval256000004$loading__1927001464__auto____256000005")

var Lit_449 *jrt.String = jrt.Intern("arbace.a2g.dyn$eval256000008$fn__256000009")

var Lit_450 *jrt.String = jrt.Intern("arbace.a2g.dyn$fn_field_native")

var Lit_451 *jrt.String = jrt.Intern("defineFnField")

var Lit_452 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;ILjava/lang/Class;)V")

var Lit_453 *jrt.String = jrt.Intern("arbace.a2g.dyn$forms")

var Lit_454 *jrt.String = jrt.Intern("---- Dyn (A2G-SPEC §5.12): ")

var Lit_455 *jrt.String = jrt.Intern(" interfaces, ")

var Lit_456 *jrt.String = jrt.Intern(" methods")

var Lit_457 *jrt.String = jrt.Intern("dynConvert is a method's result r as the Go value of its return class (reflection's\nInvoke): Clojure's conversion to a primitive, as compiled deftype methods convert.\n")

var Lit_458 *jrt.String = jrt.Intern("defineClass")

var Lit_459 *jrt.String = jrt.Intern("(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/String;)Ljava/lang/Class;")

var Lit_460 *jrt.String = jrt.Intern("setMethod")

var Lit_461 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;Ljava/lang/Class;Larbace/lang/IFn;)V")

var Lit_462 *jrt.String = jrt.Intern("setStaticMethod")

var Lit_463 *jrt.String = jrt.Intern("defineCtor")

var Lit_464 *jrt.String = jrt.Intern("(Ljava/lang/Class;[Ljava/lang/Class;[Ljava/lang/Object;)V")

var Lit_465 *jrt.String = jrt.Intern("defineInterface")

var Lit_466 *jrt.String = jrt.Intern("(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/Class;")

var Lit_467 *jrt.String = jrt.Intern("addInterfaceMethod")

var Lit_468 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;Ljava/lang/Class;)V")

var Lit_469 *jrt.String = jrt.Intern("defineFnClass")

var Lit_470 *jrt.String = jrt.Intern("(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Class;")

var Lit_471 *jrt.String = jrt.Intern("hideField")

var Lit_472 *jrt.String = jrt.Intern("(Ljava/lang/Class;I)V")

var Lit_473 *jrt.String = jrt.Intern("newInstance")

var Lit_474 *jrt.String = jrt.Intern("(Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;")

var Lit_475 *jrt.String = jrt.Intern("getField")

var Lit_476 *jrt.String = jrt.Intern("(Ljava/lang/Object;I)Ljava/lang/Object;")

var Lit_477 *jrt.String = jrt.Intern("setField")

var Lit_478 *jrt.String = jrt.Intern("(Ljava/lang/Object;ILjava/lang/Object;)V")

var Lit_479 *jrt.String = jrt.Intern("fillProxySlots")

var Lit_480 *jrt.String = jrt.Intern("(Ljava/lang/Class;Larbace/lang/IFn;)V")

var Lit_481 *jrt.String = jrt.Intern("the methods of a proxy's superclass that reflection does not list (protected ones of jrt's\nclasses) and that have no fn yet: the fn factory makes of their name.\n")

var Lit_482 *jrt.String = jrt.Intern("superMarker")

var Lit_483 *jrt.String = jrt.Intern("()Ljava/lang/Object;")

var Lit_484 *jrt.String = jrt.Intern("dynSubFor: the slot table and constructors of the proxies of class c (nil: c has no DynSub type).\n")

var Lit_485 *jrt.String = jrt.Intern("defineProxyClass")

var Lit_486 *jrt.String = jrt.Intern("(Ljava/lang/String;Ljava/lang/Class;[Ljava/lang/Class;)Ljava/lang/Class;")

var Lit_487 *jrt.String = jrt.Intern("arbace.a2g.dyn$forms$fn__256000355")

var Lit_488 *jrt.String = jrt.Intern("arbace.a2g.dyn$forms$fn__256000386")

var Lit_489 *jrt.String = jrt.Intern("arbace.a2g.dyn$forms$fn__256000398")

var Lit_490 *jrt.String = jrt.Intern("arbace.a2g.dyn$forms$iter__256000360__256000364")

var Lit_491 *jrt.String = jrt.Intern("arbace.a2g.dyn$forms$iter__256000360__256000364$fn__256000365")

var Lit_492 *jrt.String = jrt.Intern("arbace.a2g.dyn$forms$iter__256000360__256000364$fn__256000365$fn__256000366")

var Lit_493 *jrt.String = jrt.Intern("arbace.a2g.dyn$forms$iter__256000376__256000380")

var Lit_494 *jrt.String = jrt.Intern("arbace.a2g.dyn$forms$iter__256000376__256000380$fn__256000381")

var Lit_495 *jrt.String = jrt.Intern("Is_")

var Lit_496 *jrt.String = jrt.Intern("arbace.a2g.dyn$forms$iter__256000376__256000380$fn__256000381$fn__256000382")

var Lit_497 *jrt.String = jrt.Intern("arbace.a2g.dyn$forms$iter__256000388__256000392")

var Lit_498 *jrt.String = jrt.Intern("arbace.a2g.dyn$forms$iter__256000388__256000392$fn__256000393")

var Lit_499 *jrt.String = jrt.Intern("dynSlots_")

var Lit_500 *jrt.String = jrt.Intern("dynOwn_")

var Lit_501 *jrt.String = jrt.Intern("arbace.a2g.dyn$forms$iter__256000388__256000392$fn__256000393$fn__256000394")

var Lit_502 *jrt.String = jrt.Intern("arbace.a2g.dyn$go_method_names")

var Lit_503 *jrt.String = jrt.Intern("arbace.a2g.dyn$go_method_names$iter__256000242__256000248")

var Lit_504 *jrt.String = jrt.Intern("arbace.a2g.dyn$go_method_names$iter__256000242__256000248$fn__256000249")

var Lit_505 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_506 *jrt.String = jrt.Intern("arbace.a2g.dyn$go_method_names$iter__256000242__256000248$fn__256000249$iter__256000244__256000250")

var Lit_507 *jrt.String = jrt.Intern("arbace.a2g.dyn$go_method_names$iter__256000242__256000248$fn__256000249$iter__256000244__256000250$fn__256000251")

var Lit_508 *jrt.String = jrt.Intern("arbace.a2g.dyn$go_method_names$iter__256000242__256000248$fn__256000249$iter__256000244__256000250$fn__256000251$fn__256000252")

var Lit_509 *jrt.String = jrt.Intern("arbace.a2g.dyn$go_method_names$iter__256000242__256000248$fn__256000249$iter__256000256__256000260")

var Lit_510 *jrt.String = jrt.Intern("arbace.a2g.dyn$go_method_names$iter__256000242__256000248$fn__256000249$iter__256000256__256000260$fn__256000261")

var Lit_511 *jrt.String = jrt.Intern("<clinit>")

var Lit_512 *jrt.String = jrt.Intern("arbace.a2g.dyn$go_method_names$iter__256000242__256000248$fn__256000249$iter__256000256__256000260$fn__256000261$fn__256000262")

var Lit_513 *jrt.String = jrt.Intern("arbace.a2g.dyn$go_method_names$iter__256000268__256000272")

var Lit_514 *jrt.String = jrt.Intern("arbace.a2g.dyn$go_method_names$iter__256000268__256000272$fn__256000273")

var Lit_515 *jrt.String = jrt.Intern("arbace.a2g.dyn$go_method_names$iter__256000268__256000272$fn__256000273$fn__256000274")

var Lit_516 *jrt.String = jrt.Intern("arbace.a2g.dyn$iface_fallback")

var Lit_517 *jrt.String = jrt.Intern("arbace.a2g.dyn$iface_fallback$iter__256000130__256000134")

var Lit_518 *jrt.String = jrt.Intern("arbace.a2g.dyn$iface_fallback$iter__256000130__256000134$fn__256000135")

var Lit_519 *jrt.String = jrt.Intern("arbace.a2g.dyn$iface_fallback$iter__256000130__256000134$fn__256000135$fn__256000136")

var Lit_520 *jrt.String = jrt.Intern("arbace.a2g.dyn$interfaces")

var Lit_521 *jrt.String = jrt.Intern("arbace.a2g.dyn$interfaces$fn__256000034")

var Lit_522 *jrt.String = jrt.Intern("arbace/lang/Compiler$AOT")

var Lit_523 *jrt.String = jrt.Intern("arbace.a2g.dyn$interfaces$fn__256000036")

var Lit_524 *jrt.String = jrt.Intern("arbace.a2g.dyn$interfaces$iter__256000038__256000044")

var Lit_525 *jrt.String = jrt.Intern("arbace.a2g.dyn$interfaces$iter__256000038__256000044$fn__256000045")

var Lit_526 *jrt.String = jrt.Intern("arbace.a2g.dyn$interfaces$iter__256000038__256000044$fn__256000045$iter__256000040__256000046")

var Lit_527 *jrt.String = jrt.Intern("arbace.a2g.dyn$interfaces$iter__256000038__256000044$fn__256000045$iter__256000040__256000046$fn__256000047")

var Lit_528 *jrt.String = jrt.Intern("arbace.a2g.dyn$interfaces$iter__256000038__256000044$fn__256000045$iter__256000040__256000046$fn__256000047$fn__256000048")

var Lit_529 *jrt.String = jrt.Intern("arbace.a2g.dyn$java_type_name")

var Lit_530 *jrt.String = jrt.Intern("arbace.a2g.dyn$method_form")

var Lit_531 *jrt.String = jrt.Intern("arbace.a2g.dyn$method_form$fn__256000150")

var Lit_532 *jrt.String = jrt.Intern("arbace.a2g.dyn$method_form$fn__256000168")

var Lit_533 *jrt.String = jrt.Intern("arbace.a2g.dyn$method_form$iter__256000158__256000162")

var Lit_534 *jrt.String = jrt.Intern("arbace.a2g.dyn$method_form$iter__256000158__256000162$fn__256000163")

var Lit_535 *jrt.String = jrt.Intern("arbace.a2g.dyn$method_form$iter__256000158__256000162$fn__256000163$fn__256000164")

var Lit_536 *jrt.String = jrt.Intern("arbace.a2g.dyn$native_name")

var Lit_537 *jrt.String = jrt.Intern("_native")

var Lit_538 *jrt.String = jrt.Intern("arbace.a2g.dyn$object_fallback")

var Lit_539 *jrt.String = jrt.Intern("hashCode")

var Lit_540 *jrt.String = jrt.Intern("toString")

var Lit_541 *jrt.String = jrt.Intern("equals")

var Lit_542 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_543 *jrt.String = jrt.Intern("arbace.a2g.dyn$proxy_classes")

var Lit_544 *jrt.String = jrt.Intern("arbace.a2g.dyn$proxy_classes$fn__256000173")

var Lit_545 *jrt.String = jrt.Intern("arbace.a2g.dyn$proxy_roots")

var Lit_546 *jrt.String = jrt.Intern("arbace.a2g.dyn$proxy_roots$iter__256000177__256000185")

var Lit_547 *jrt.String = jrt.Intern("arbace.a2g.dyn$proxy_roots$iter__256000177__256000185$fn__256000186")

var Lit_548 *jrt.String = jrt.Intern("arbace.a2g.dyn$proxy_roots$iter__256000177__256000185$fn__256000186$iter__256000179__256000187")

var Lit_549 *jrt.String = jrt.Intern("arbace.a2g.dyn$proxy_roots$iter__256000177__256000185$fn__256000186$iter__256000179__256000187$fn__256000188")

var Lit_550 *jrt.String = jrt.Intern("arbace.a2g.dyn$proxy_roots$iter__256000177__256000185$fn__256000186$iter__256000179__256000187$fn__256000188$iter__256000181__256000189")

var Lit_551 *jrt.String = jrt.Intern("arbace.a2g.dyn$proxy_roots$iter__256000177__256000185$fn__256000186$iter__256000179__256000187$fn__256000188$iter__256000181__256000189$fn__256000190")

var Lit_552 *jrt.String = jrt.Intern("arbace.a2g.dyn$proxy_roots$iter__256000177__256000185$fn__256000186$iter__256000179__256000187$fn__256000188$iter__256000181__256000189$fn__256000190$fn__256000191")

var Lit_553 *jrt.String = jrt.Intern("arbace.a2g.dyn$public_QMARK_")

var Lit_554 *jrt.String = jrt.Intern("arbace.a2g.dyn$roots")

var Lit_555 *jrt.String = jrt.Intern("arbace.a2g.dyn$roots$iter__256000013__256000017")

var Lit_556 *jrt.String = jrt.Intern("arbace.a2g.dyn$roots$iter__256000013__256000017$fn__256000018")

var Lit_557 *jrt.String = jrt.Intern("arbace.a2g.dyn$roots$iter__256000013__256000017$fn__256000018$fn__256000019")

var Lit_558 *jrt.String = jrt.Intern("arbace.a2g.dyn$slot_keys")

var Lit_559 *jrt.String = jrt.Intern("arbace.a2g.dyn$slot_keys$iter__256000055__256000061")

var Lit_560 *jrt.String = jrt.Intern("arbace.a2g.dyn$slot_keys$iter__256000055__256000061$fn__256000062")

var Lit_561 *jrt.String = jrt.Intern("arbace.a2g.dyn$slot_keys$iter__256000055__256000061$fn__256000062$iter__256000057__256000063")

var Lit_562 *jrt.String = jrt.Intern("arbace.a2g.dyn$slot_keys$iter__256000055__256000061$fn__256000062$iter__256000057__256000063$fn__256000064")

var Lit_563 *jrt.String = jrt.Intern("arbace.a2g.dyn$slot_keys$iter__256000055__256000061$fn__256000062$iter__256000057__256000063$fn__256000064$fn__256000065")

var Lit_564 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms")

var Lit_565 *jrt.String = jrt.Intern(" is an object of a proxy class extending ")

var Lit_566 *jrt.String = jrt.Intern(": its struct, and a dynCore (the class's dispatch table D, its fields F, Self this object).\n")

var Lit_567 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$fn__256000296")

var Lit_568 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$fn__256000342")

var Lit_569 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$fn__256000342$fn__256000346")

var Lit_570 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$fn__256000342$fn__256000348")

var Lit_571 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$iter__256000279__256000283")

var Lit_572 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$iter__256000279__256000283$fn__256000284")

var Lit_573 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$iter__256000279__256000283$fn__256000284$fn__256000285")

var Lit_574 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$iter__256000301__256000305")

var Lit_575 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$iter__256000301__256000305$fn__256000306")

var Lit_576 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$iter__256000301__256000305$fn__256000306$fn__256000307")

var Lit_577 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$iter__256000317__256000321")

var Lit_578 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$iter__256000317__256000321$fn__256000322")

var Lit_579 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$iter__256000317__256000321$fn__256000322$fn__256000323")

var Lit_580 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$iter__256000317__256000321$fn__256000322$fn__256000323$fn__256000324")

var Lit_581 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$iter__256000317__256000321$fn__256000322$fn__256000327")

var Lit_582 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$iter__256000331__256000335")

var Lit_583 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$iter__256000331__256000335$fn__256000336")

var Lit_584 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_forms$iter__256000331__256000335$fn__256000336$fn__256000337")

var Lit_585 *jrt.String = jrt.Intern("arbace.a2g.dyn$sub_name")

var Lit_586 *jrt.String = jrt.Intern("DynSub_")

var Lit_587 *jrt.String = jrt.Intern("arbace.a2g.dyn$tag")

var Lit_588 *jrt.String = jrt.Intern("in-ns")

var Lit_589 *jrt.String = jrt.Intern("file")

var Lit_590 *jrt.String = jrt.Intern("arbace/a2g/dyn.ae")

var Lit_591 *jrt.String = jrt.Intern("private")

var Lit_592 *jrt.String = jrt.Intern("arglists")

var Lit_593 *jrt.String = jrt.Intern("sym")

var Lit_594 *jrt.String = jrt.Intern("()Ljava/lang/String;")

var Lit_595 *jrt.String = jrt.Intern("()I")

var Lit_596 *jrt.String = jrt.Intern("(Ljava/lang/Object;)Z")

var Lit_597 *jrt.String = jrt.Intern("The Object methods a run-time class may override, at fixed slots.")

var Lit_598 *jrt.String = jrt.Intern("Clojure's conversion of a method's result to its primitive return type (as compiled deftype\n  methods convert: HostExpr.emitUnboxArg).")

var Lit_599 *jrt.String = jrt.Intern("roots")

var Lit_600 *jrt.String = jrt.Intern("What Dyn's code calls besides the world's interfaces: reachability roots.")

var Lit_601 *jrt.String = jrt.Intern("enabled?")

var Lit_602 *jrt.String = jrt.Intern("Is the evaluator's Dyn API in this world (translated)?")

var Lit_603 *jrt.String = jrt.Intern("n")

var Lit_604 *jrt.String = jrt.Intern("The interfaces Dyn implements: every public interface translated (not an annotation) or\n  hand-written in jrt with a cast function (Future: core's future-call reifies it; jrt's instance\n  checks of them make the nominal check, jrt.dynNominal), with every interface they extend that the world has.")

var Lit_605 *jrt.String = jrt.Intern("ifaces")

var Lit_606 *jrt.String = jrt.Intern("The methods of the interfaces, [name desc], sorted; Object's overridable ones first.")

var Lit_607 *jrt.String = jrt.Intern("The interfaces among ifaces with a default method for k, most specific first: [j fn-sym].")

var Lit_608 *jrt.String = jrt.Intern("A parameter of Go type for desc d as a Java object.")

var Lit_609 *jrt.String = jrt.Intern("The Java object r as the Go value of return type d.")

var Lit_610 *jrt.String = jrt.Intern("The call of slot fn f with the object this (t, or the object around a dynCore) and the boxed\n  arguments.")

var Lit_611 *jrt.String = jrt.Intern("The Java name of descriptor d (int, java.lang.Object, byte[]).")

var Lit_612 *jrt.String = jrt.Intern("HotSpot's text of an unimplemented interface method, after the receiver class: the resolved\n  method's signature and its interface (the first of ifaces declaring it).")

var Lit_613 *jrt.String = jrt.Intern("pn")

var Lit_614 *jrt.String = jrt.Intern("core?")

var Lit_615 *jrt.String = jrt.Intern("What a method of the interfaces does when its slot is unset (or its fn answers SUPER): the\n  interface's default method, else AbstractMethodError. On a dynCore (core?) the default method\n  takes the object around it (Self) as the interface.")

var Lit_616 *jrt.String = jrt.Intern("recv")

var Lit_617 *jrt.String = jrt.Intern("fallback")

var Lit_618 *jrt.String = jrt.Intern("The Go method of slot i (method k) on receiver type recv (Dyn or a DynSub_C): the slot's fn\n  when it is set and does not answer SUPER (a proxy's method without a mapping), else the\n  statements of fallback.")

var Lit_619 *jrt.String = jrt.Intern("mname")

var Lit_620 *jrt.String = jrt.Intern("proxy-supers")

var Lit_621 *jrt.String = jrt.Intern("The classes besides Object that a proxy may extend in the Go build (model/proxy-supers): each\n  gets a Go type DynSub_C, which embeds C's struct (so it is a C_I) and has Dyn's methods (every\n  interface of the world) and C's virtual methods, each calling its slot's fn and, when unset or\n  answering SUPER, C's implementation. A class must be translated or hand-written and non-final;\n  a translated one is not a leaf for being listed (its values are C_I, §5.3).")

var Lit_622 *jrt.String = jrt.Intern("class-supers")

var Lit_623 *jrt.String = jrt.Intern("The classes besides proxy-supers that the classes of class forms made at the REPL may extend\n  (doc/go/CLASSFORMS-REPL.md): each gets its DynSub_C as the proxies' superclasses do (so they\n  are proxy superclasses too).")

var Lit_624 *jrt.String = jrt.Intern("The classes that get a DynSub_C: proxy-supers and class-supers.")

var Lit_625 *jrt.String = jrt.Intern("The classes of sub-supers a proxy (or a class of class forms) may extend in this world\n  (translated).")

var Lit_626 *jrt.String = jrt.Intern("proxy-roots")

var Lit_627 *jrt.String = jrt.Intern("Reachability roots of the proxies' superclasses: their constructors and virtual methods (a\n  DynSub_C calls C's constructor bodies and implementations).")

var Lit_628 *jrt.String = jrt.Intern("The fallback of Object's method k (toString, hashCode, equals) in DynSub_C: C's\n  implementation, else the header's.")

var Lit_629 *jrt.String = jrt.Intern("The fallback of C's virtual method k in DynSub_C: C's implementation (the super call), else\n  AbstractMethodError.")

var Lit_630 *jrt.String = jrt.Intern("The constructors of DynSub_C (C's non-private ones), as a Go function of the DynClass.")

var Lit_631 *jrt.String = jrt.Intern("The Go method names of class n's struct (its own and its ancestors' methods, translated or\n  jrt's, its interfaces' markers): those a DynSub_C must define itself, as the ones promoted\n  from its embedded dynCore would be ambiguous.")

var Lit_632 *jrt.String = jrt.Intern("dyn-keys")

var Lit_633 *jrt.String = jrt.Intern("The Go type DynSub_C of the proxies of class n, its methods and its slot table. It embeds C's\n  struct and a dynCore, whose methods (the interfaces' methods and markers, Dyn's) it takes by\n  Go's promotion; it defines itself Object's and C's virtual methods, and those of the core whose\n  names C's struct has too (they would be ambiguous). Its slots are Dyn's (the core's methods\n  index them), then C's own methods the interfaces lack.")

var Lit_634 *jrt.String = jrt.Intern("dynCallFast calls a method's fn of up to 3 arguments with the object and the arguments,\nboxed, through its invoke of that arity.\n")

var Lit_635 *jrt.String = jrt.Intern(".Invoke_O_O_O__O")

var Lit_636 *jrt.String = jrt.Intern(".Invoke_O_O_O_O__O")

var Lit_637 *jrt.String = jrt.Intern("dynCall's call of a method of up to 3 arguments: the fn's invoke of that arity, without a seq\n  (the evaluator's methods, EvalMethod.invoke: doc/go/SPEED-NOTES.md, \"The evaluator\"). (A def\n  of its own: forms is at the JVM's limit of a method's size.)")

var Lit_638 *jrt.String = jrt.Intern("Compiler$Dyn.defineFnField: a fn class's field, the fn's i-th closed-over value, as the\n  compiled fn's field (EVAL-NOTES.md, \"Locals clearing\"); settable when not primitive. (Apart\n  from forms, whose constants would not fit in one class.)")

var Lit_639 *jrt.String = jrt.Intern("forms")

var Lit_640 *jrt.String = jrt.Intern("The forms of a2g_dyn.go (package arbace/lang) for the translated classes T.")

var Lit_641 *jrt.String = jrt.Intern("arbace/lang/Compiler$Dyn")
