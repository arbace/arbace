//line a2g_classes.ae:1
package aot_arbace_a2g_dyn

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_a2g_dyn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_A_New()}; return nil }

var A_arbace_a2g_dyn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_dyn_A_new}

var A_arbace_a2g_dyn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_A"})

func init() { i := A_arbace_a2g_dyn_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_A_InstanceOf; i.Init = A_arbace_a2g_dyn_A_Init; i.Table = A_arbace_a2g_dyn_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_A_class, reflect.TypeFor[A_arbace_a2g_dyn_A]()) }

func A_arbace_a2g_dyn_abstract_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_abstract_text_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_abstract_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_abstract_text_A_New()}; return nil }

func A_arbace_a2g_dyn_abstract_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_abstract_text_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_abstract_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_abstract_text_A_invoke, New: A_arbace_a2g_dyn_abstract_text_A_new, Get: A_arbace_a2g_dyn_abstract_text_A_get}

var A_arbace_a2g_dyn_abstract_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$abstract_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "abstract_text", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_abstract_text_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_abstract_text_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_abstract_text_A_InstanceOf; i.Init = A_arbace_a2g_dyn_abstract_text_A_Init; i.Table = A_arbace_a2g_dyn_abstract_text_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_abstract_text_A_class, reflect.TypeFor[A_arbace_a2g_dyn_abstract_text_A]()) }

func A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_invoke, New: A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_new, Get: A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_get}

var A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$abstract_text$declares_QMARK___256000113", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_abstract_text_A_class, Simple: "declares_QMARK___256000113", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_InstanceOf; i.Init = A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_Init; i.Table = A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_class, reflect.TypeFor[A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A]()) }

func A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A_invoke, New: A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A_new, Get: A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A_get}

var A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$abstract_text$declares_QMARK___256000113$fn__256000114", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_A_class, Simple: "fn__256000114", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A_InstanceOf; i.Init = A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A_Init; i.Table = A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A_class, reflect.TypeFor[A_arbace_a2g_dyn_abstract_text_declares_QMARK___256000113_fn__256000114_A]()) }

func A_arbace_a2g_dyn_abstract_text_fn__256000117_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_abstract_text_fn__256000117_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_abstract_text_fn__256000117_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_abstract_text_fn__256000117_A_New_O(args[0])}; return nil }

func A_arbace_a2g_dyn_abstract_text_fn__256000117_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_abstract_text_fn__256000117_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_abstract_text_fn__256000117_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_abstract_text_fn__256000117_A_invoke, New: A_arbace_a2g_dyn_abstract_text_fn__256000117_A_new, Get: A_arbace_a2g_dyn_abstract_text_fn__256000117_A_get}

var A_arbace_a2g_dyn_abstract_text_fn__256000117_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$abstract_text$fn__256000117", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_abstract_text_A_class, Simple: "fn__256000117", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_abstract_text_fn__256000117_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_abstract_text_fn__256000117_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_abstract_text_fn__256000117_A_InstanceOf; i.Init = A_arbace_a2g_dyn_abstract_text_fn__256000117_A_Init; i.Table = A_arbace_a2g_dyn_abstract_text_fn__256000117_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_abstract_text_fn__256000117_A_class, reflect.TypeFor[A_arbace_a2g_dyn_abstract_text_fn__256000117_A]()) }

func A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A_New_O(args[0])}; return nil }

func A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A_invoke, New: A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A_new, Get: A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A_get}

var A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$abstract_text$fn__256000117$fn__256000119", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_abstract_text_fn__256000117_A_class, Simple: "fn__256000119", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A_InstanceOf; i.Init = A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A_Init; i.Table = A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A_class, reflect.TypeFor[A_arbace_a2g_dyn_abstract_text_fn__256000117_fn__256000119_A]()) }

func A_arbace_a2g_dyn_box_arg_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_box_arg_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_box_arg_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_box_arg_A_New()}; return nil }

func A_arbace_a2g_dyn_box_arg_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_box_arg_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_box_arg_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_box_arg_A_invoke, New: A_arbace_a2g_dyn_box_arg_A_new, Get: A_arbace_a2g_dyn_box_arg_A_get}

var A_arbace_a2g_dyn_box_arg_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$box_arg", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "box_arg", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_box_arg_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_box_arg_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_box_arg_A_InstanceOf; i.Init = A_arbace_a2g_dyn_box_arg_A_Init; i.Table = A_arbace_a2g_dyn_box_arg_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_box_arg_A_class, reflect.TypeFor[A_arbace_a2g_dyn_box_arg_A]()) }

func A_arbace_a2g_dyn_call_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_call_impl_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_a2g_dyn_call_impl_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_call_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_call_impl_A_New()}; return nil }

func A_arbace_a2g_dyn_call_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_call_impl_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_call_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_call_impl_A_invoke, New: A_arbace_a2g_dyn_call_impl_A_new, Get: A_arbace_a2g_dyn_call_impl_A_get}

var A_arbace_a2g_dyn_call_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$call_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "call_impl", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_call_impl_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_call_impl_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_call_impl_A_InstanceOf; i.Init = A_arbace_a2g_dyn_call_impl_A_Init; i.Table = A_arbace_a2g_dyn_call_impl_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_call_impl_A_class, reflect.TypeFor[A_arbace_a2g_dyn_call_impl_A]()) }

func A_arbace_a2g_dyn_class_fallback_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_class_fallback_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_dyn_class_fallback_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_class_fallback_A_New()}; return nil }

func A_arbace_a2g_dyn_class_fallback_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_class_fallback_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_class_fallback_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_class_fallback_A_invoke, New: A_arbace_a2g_dyn_class_fallback_A_new, Get: A_arbace_a2g_dyn_class_fallback_A_get}

var A_arbace_a2g_dyn_class_fallback_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$class_fallback", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "class_fallback", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_class_fallback_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_class_fallback_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_class_fallback_A_InstanceOf; i.Init = A_arbace_a2g_dyn_class_fallback_A_Init; i.Table = A_arbace_a2g_dyn_class_fallback_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_class_fallback_A_class, reflect.TypeFor[A_arbace_a2g_dyn_class_fallback_A]()) }

func A_arbace_a2g_dyn_class_fallback_ret__256000206_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_class_fallback_ret__256000206_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_class_fallback_ret__256000206_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_class_fallback_ret__256000206_A_New_O(args[0])}; return nil }

func A_arbace_a2g_dyn_class_fallback_ret__256000206_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_class_fallback_ret__256000206_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_class_fallback_ret__256000206_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_class_fallback_ret__256000206_A_invoke, New: A_arbace_a2g_dyn_class_fallback_ret__256000206_A_new, Get: A_arbace_a2g_dyn_class_fallback_ret__256000206_A_get}

var A_arbace_a2g_dyn_class_fallback_ret__256000206_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$class_fallback$ret__256000206", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_class_fallback_A_class, Simple: "ret__256000206", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_class_fallback_ret__256000206_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_class_fallback_ret__256000206_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_class_fallback_ret__256000206_A_InstanceOf; i.Init = A_arbace_a2g_dyn_class_fallback_ret__256000206_A_Init; i.Table = A_arbace_a2g_dyn_class_fallback_ret__256000206_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_class_fallback_ret__256000206_A_class, reflect.TypeFor[A_arbace_a2g_dyn_class_fallback_ret__256000206_A]()) }

func A_arbace_a2g_dyn_convert_result_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_convert_result_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_convert_result_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_convert_result_A_New()}; return nil }

func A_arbace_a2g_dyn_convert_result_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_convert_result_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_convert_result_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_convert_result_A_invoke, New: A_arbace_a2g_dyn_convert_result_A_new, Get: A_arbace_a2g_dyn_convert_result_A_get}

var A_arbace_a2g_dyn_convert_result_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$convert_result", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "convert_result", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_convert_result_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_convert_result_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_convert_result_A_InstanceOf; i.Init = A_arbace_a2g_dyn_convert_result_A_Init; i.Table = A_arbace_a2g_dyn_convert_result_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_convert_result_A_class, reflect.TypeFor[A_arbace_a2g_dyn_convert_result_A]()) }

func A_arbace_a2g_dyn_convert_result_fn__256000097_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_convert_result_fn__256000097_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_convert_result_fn__256000097_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_convert_result_fn__256000097_A_New_O(args[0])}; return nil }

func A_arbace_a2g_dyn_convert_result_fn__256000097_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_convert_result_fn__256000097_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_convert_result_fn__256000097_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_convert_result_fn__256000097_A_invoke, New: A_arbace_a2g_dyn_convert_result_fn__256000097_A_new, Get: A_arbace_a2g_dyn_convert_result_fn__256000097_A_get}

var A_arbace_a2g_dyn_convert_result_fn__256000097_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$convert_result$fn__256000097", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_convert_result_A_class, Simple: "fn__256000097", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_convert_result_fn__256000097_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_convert_result_fn__256000097_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_convert_result_fn__256000097_A_InstanceOf; i.Init = A_arbace_a2g_dyn_convert_result_fn__256000097_A_Init; i.Table = A_arbace_a2g_dyn_convert_result_fn__256000097_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_convert_result_fn__256000097_A_class, reflect.TypeFor[A_arbace_a2g_dyn_convert_result_fn__256000097_A]()) }

func A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A_New()}; return nil }

func A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A_invoke, New: A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A_new, Get: A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A_get}

var A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$convert_result$fn__256000097$fn__256000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_convert_result_fn__256000097_A_class, Simple: "fn__256000098", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A_InstanceOf; i.Init = A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A_Init; i.Table = A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A_class, reflect.TypeFor[A_arbace_a2g_dyn_convert_result_fn__256000097_fn__256000098_A]()) }

func A_arbace_a2g_dyn_ctor_infos_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_ctor_infos_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_ctor_infos_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_ctor_infos_A_New()}; return nil }

func A_arbace_a2g_dyn_ctor_infos_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_ctor_infos_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_ctor_infos_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_ctor_infos_A_invoke, New: A_arbace_a2g_dyn_ctor_infos_A_new, Get: A_arbace_a2g_dyn_ctor_infos_A_get}

var A_arbace_a2g_dyn_ctor_infos_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$ctor_infos", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "ctor_infos", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_ctor_infos_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_ctor_infos_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_ctor_infos_A_InstanceOf; i.Init = A_arbace_a2g_dyn_ctor_infos_A_Init; i.Table = A_arbace_a2g_dyn_ctor_infos_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_ctor_infos_A_class, reflect.TypeFor[A_arbace_a2g_dyn_ctor_infos_A]()) }

func A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A_New()}; return nil }

func A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A_invoke, New: A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A_new, Get: A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A_get}

var A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$ctor_infos$arg_conv__256000213", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_ctor_infos_A_class, Simple: "arg_conv__256000213", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A_InstanceOf; i.Init = A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A_Init; i.Table = A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A_class, reflect.TypeFor[A_arbace_a2g_dyn_ctor_infos_arg_conv__256000213_A]()) }

func A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_invoke, New: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_new, Get: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_get}

var A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$ctor_infos$iter__256000215__256000219", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_ctor_infos_A_class, Simple: "iter__256000215__256000219", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_InstanceOf; i.Init = A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_Init; i.Table = A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_class, reflect.TypeFor[A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A]()) }

func A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_invoke, New: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_new, Get: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_get}

var A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$ctor_infos$iter__256000215__256000219$fn__256000220", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_A_class, Simple: "fn__256000220", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_InstanceOf; i.Init = A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_Init; i.Table = A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_class, reflect.TypeFor[A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A]()) }

func A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_New_O_O_O_O_I_O(args[0], args[1], args[2], args[3], args[4].(int32), args[5])}; return nil }

func A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_invoke, New: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_new, Get: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_get}

var A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$ctor_infos$iter__256000215__256000219$fn__256000220$fn__256000221", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_class, Simple: "fn__256000221", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_InstanceOf; i.Init = A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_Init; i.Table = A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_class, reflect.TypeFor[A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A]()) }

func A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A_New_O(args[0])}; return nil }

func A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A_invoke, New: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A_new, Get: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A_get}

var A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$ctor_infos$iter__256000215__256000219$fn__256000220$fn__256000221$fn__256000228", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_A_class, Simple: "fn__256000228", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A_InstanceOf; i.Init = A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A_Init; i.Table = A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A_class, reflect.TypeFor[A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000221_fn__256000228_A]()) }

func A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A_New_O(args[0])}; return nil }

func A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A_invoke, New: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A_new, Get: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A_get}

var A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$ctor_infos$iter__256000215__256000219$fn__256000220$fn__256000237", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_A_class, Simple: "fn__256000237", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A_InstanceOf; i.Init = A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A_Init; i.Table = A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A_class, reflect.TypeFor[A_arbace_a2g_dyn_ctor_infos_iter__256000215__256000219_fn__256000220_fn__256000237_A]()) }

func A_arbace_a2g_dyn_defaults_for_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_defaults_for_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_defaults_for_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_defaults_for_A_New()}; return nil }

func A_arbace_a2g_dyn_defaults_for_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_defaults_for_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_defaults_for_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_defaults_for_A_invoke, New: A_arbace_a2g_dyn_defaults_for_A_new, Get: A_arbace_a2g_dyn_defaults_for_A_get}

var A_arbace_a2g_dyn_defaults_for_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$defaults_for", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "defaults_for", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_defaults_for_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_defaults_for_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_defaults_for_A_InstanceOf; i.Init = A_arbace_a2g_dyn_defaults_for_A_Init; i.Table = A_arbace_a2g_dyn_defaults_for_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_defaults_for_A_class, reflect.TypeFor[A_arbace_a2g_dyn_defaults_for_A]()) }

func A_arbace_a2g_dyn_defaults_for_fn__256000089_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_defaults_for_fn__256000089_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_defaults_for_fn__256000089_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_defaults_for_fn__256000089_A_New()}; return nil }

func A_arbace_a2g_dyn_defaults_for_fn__256000089_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_defaults_for_fn__256000089_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_defaults_for_fn__256000089_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_defaults_for_fn__256000089_A_invoke, New: A_arbace_a2g_dyn_defaults_for_fn__256000089_A_new, Get: A_arbace_a2g_dyn_defaults_for_fn__256000089_A_get}

var A_arbace_a2g_dyn_defaults_for_fn__256000089_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$defaults_for$fn__256000089", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_defaults_for_A_class, Simple: "fn__256000089", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_defaults_for_fn__256000089_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_defaults_for_fn__256000089_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_defaults_for_fn__256000089_A_InstanceOf; i.Init = A_arbace_a2g_dyn_defaults_for_fn__256000089_A_Init; i.Table = A_arbace_a2g_dyn_defaults_for_fn__256000089_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_defaults_for_fn__256000089_A_class, reflect.TypeFor[A_arbace_a2g_dyn_defaults_for_fn__256000089_A]()) }

func A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_New_O(args[0])}; return nil }

func A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_invoke, New: A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_new, Get: A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_get}

var A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$defaults_for$iter__256000078__256000082", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_defaults_for_A_class, Simple: "iter__256000078__256000082", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_InstanceOf; i.Init = A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_Init; i.Table = A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_class, reflect.TypeFor[A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A]()) }

func A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_invoke, New: A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_new, Get: A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_get}

var A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$defaults_for$iter__256000078__256000082$fn__256000083", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_A_class, Simple: "fn__256000083", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_InstanceOf; i.Init = A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_Init; i.Table = A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_class, reflect.TypeFor[A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A]()) }

func A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A_invoke, New: A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A_new, Get: A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A_get}

var A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$defaults_for$iter__256000078__256000082$fn__256000083$fn__256000084", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_A_class, Simple: "fn__256000084", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A_InstanceOf; i.Init = A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A_Init; i.Table = A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A_class, reflect.TypeFor[A_arbace_a2g_dyn_defaults_for_iter__256000078__256000082_fn__256000083_fn__256000084_A]()) }

func A_arbace_a2g_dyn_enabled_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_enabled_QMARK__A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_enabled_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_enabled_QMARK__A_New()}; return nil }

func A_arbace_a2g_dyn_enabled_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_enabled_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_dyn_enabled_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_enabled_QMARK__A_invoke, New: A_arbace_a2g_dyn_enabled_QMARK__A_new, Get: A_arbace_a2g_dyn_enabled_QMARK__A_get}

var A_arbace_a2g_dyn_enabled_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$enabled_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "enabled_QMARK_", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_enabled_QMARK__A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_enabled_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_enabled_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_dyn_enabled_QMARK__A_Init; i.Table = A_arbace_a2g_dyn_enabled_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_enabled_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_dyn_enabled_QMARK__A]()) }

func A_arbace_a2g_dyn_eval256000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_eval256000004_A_New()}; return nil }

var A_arbace_a2g_dyn_eval256000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_dyn_eval256000004_A_new}

var A_arbace_a2g_dyn_eval256000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$eval256000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_dyn_A_class, Simple: "eval256000004", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_eval256000004_A"})

func init() { i := A_arbace_a2g_dyn_eval256000004_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_eval256000004_A_InstanceOf; i.Table = A_arbace_a2g_dyn_eval256000004_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_eval256000004_A_class, reflect.TypeFor[A_arbace_a2g_dyn_eval256000004_A]()) }

func A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_New()}; return nil }

func A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_invoke, New: A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_new, Get: A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_get}

var A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$eval256000004$loading__1927001464__auto____256000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_eval256000004_A_class, Simple: "loading__1927001464__auto____256000005", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_InstanceOf; i.Init = A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_Init; i.Table = A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_class, reflect.TypeFor[A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A]()) }

func A_arbace_a2g_dyn_eval256000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_eval256000008_A_New()}; return nil }

var A_arbace_a2g_dyn_eval256000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_dyn_eval256000008_A_new}

var A_arbace_a2g_dyn_eval256000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$eval256000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_dyn_A_class, Simple: "eval256000008", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_eval256000008_A"})

func init() { i := A_arbace_a2g_dyn_eval256000008_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_eval256000008_A_InstanceOf; i.Table = A_arbace_a2g_dyn_eval256000008_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_eval256000008_A_class, reflect.TypeFor[A_arbace_a2g_dyn_eval256000008_A]()) }

func A_arbace_a2g_dyn_eval256000008_fn__256000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_eval256000008_fn__256000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_eval256000008_fn__256000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_eval256000008_fn__256000009_A_New()}; return nil }

func A_arbace_a2g_dyn_eval256000008_fn__256000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_eval256000008_fn__256000009_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_eval256000008_fn__256000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_eval256000008_fn__256000009_A_invoke, New: A_arbace_a2g_dyn_eval256000008_fn__256000009_A_new, Get: A_arbace_a2g_dyn_eval256000008_fn__256000009_A_get}

var A_arbace_a2g_dyn_eval256000008_fn__256000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$eval256000008$fn__256000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_eval256000008_A_class, Simple: "fn__256000009", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_eval256000008_fn__256000009_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_eval256000008_fn__256000009_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_eval256000008_fn__256000009_A_InstanceOf; i.Init = A_arbace_a2g_dyn_eval256000008_fn__256000009_A_Init; i.Table = A_arbace_a2g_dyn_eval256000008_fn__256000009_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_eval256000008_fn__256000009_A_class, reflect.TypeFor[A_arbace_a2g_dyn_eval256000008_fn__256000009_A]()) }

func A_arbace_a2g_dyn_fn_field_native_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_fn_field_native_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_fn_field_native_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_fn_field_native_A_New()}; return nil }

func A_arbace_a2g_dyn_fn_field_native_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_fn_field_native_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_fn_field_native_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_fn_field_native_A_invoke, New: A_arbace_a2g_dyn_fn_field_native_A_new, Get: A_arbace_a2g_dyn_fn_field_native_A_get}

var A_arbace_a2g_dyn_fn_field_native_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$fn_field_native", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "fn_field_native", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_fn_field_native_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_fn_field_native_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_fn_field_native_A_InstanceOf; i.Init = A_arbace_a2g_dyn_fn_field_native_A_Init; i.Table = A_arbace_a2g_dyn_fn_field_native_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_fn_field_native_A_class, reflect.TypeFor[A_arbace_a2g_dyn_fn_field_native_A]()) }

func A_arbace_a2g_dyn_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_forms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_forms_A_New()}; return nil }

func A_arbace_a2g_dyn_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_forms_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_forms_A_invoke, New: A_arbace_a2g_dyn_forms_A_new, Get: A_arbace_a2g_dyn_forms_A_get}

var A_arbace_a2g_dyn_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "forms", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_forms_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_forms_A_InstanceOf; i.Init = A_arbace_a2g_dyn_forms_A_Init; i.Table = A_arbace_a2g_dyn_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_forms_A_class, reflect.TypeFor[A_arbace_a2g_dyn_forms_A]()) }

func A_arbace_a2g_dyn_forms_fn__256000355_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_forms_fn__256000355_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_forms_fn__256000355_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_forms_fn__256000355_A_New()}; return nil }

func A_arbace_a2g_dyn_forms_fn__256000355_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_forms_fn__256000355_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_forms_fn__256000355_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_forms_fn__256000355_A_invoke, New: A_arbace_a2g_dyn_forms_fn__256000355_A_new, Get: A_arbace_a2g_dyn_forms_fn__256000355_A_get}

var A_arbace_a2g_dyn_forms_fn__256000355_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$forms$fn__256000355", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_forms_A_class, Simple: "fn__256000355", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_forms_fn__256000355_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_forms_fn__256000355_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_forms_fn__256000355_A_InstanceOf; i.Init = A_arbace_a2g_dyn_forms_fn__256000355_A_Init; i.Table = A_arbace_a2g_dyn_forms_fn__256000355_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_forms_fn__256000355_A_class, reflect.TypeFor[A_arbace_a2g_dyn_forms_fn__256000355_A]()) }

func A_arbace_a2g_dyn_forms_fn__256000386_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_forms_fn__256000386_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_forms_fn__256000386_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_forms_fn__256000386_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_forms_fn__256000386_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_forms_fn__256000386_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_forms_fn__256000386_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_forms_fn__256000386_A_invoke, New: A_arbace_a2g_dyn_forms_fn__256000386_A_new, Get: A_arbace_a2g_dyn_forms_fn__256000386_A_get}

var A_arbace_a2g_dyn_forms_fn__256000386_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$forms$fn__256000386", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_forms_A_class, Simple: "fn__256000386", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_forms_fn__256000386_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_forms_fn__256000386_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_forms_fn__256000386_A_InstanceOf; i.Init = A_arbace_a2g_dyn_forms_fn__256000386_A_Init; i.Table = A_arbace_a2g_dyn_forms_fn__256000386_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_forms_fn__256000386_A_class, reflect.TypeFor[A_arbace_a2g_dyn_forms_fn__256000386_A]()) }

func A_arbace_a2g_dyn_forms_fn__256000398_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_forms_fn__256000398_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_forms_fn__256000398_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_forms_fn__256000398_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_forms_fn__256000398_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_forms_fn__256000398_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_forms_fn__256000398_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_forms_fn__256000398_A_invoke, New: A_arbace_a2g_dyn_forms_fn__256000398_A_new, Get: A_arbace_a2g_dyn_forms_fn__256000398_A_get}

var A_arbace_a2g_dyn_forms_fn__256000398_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$forms$fn__256000398", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_forms_A_class, Simple: "fn__256000398", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_forms_fn__256000398_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_forms_fn__256000398_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_forms_fn__256000398_A_InstanceOf; i.Init = A_arbace_a2g_dyn_forms_fn__256000398_A_Init; i.Table = A_arbace_a2g_dyn_forms_fn__256000398_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_forms_fn__256000398_A_class, reflect.TypeFor[A_arbace_a2g_dyn_forms_fn__256000398_A]()) }

func A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_forms_iter__256000360__256000364_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_New()}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_invoke, New: A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_new, Get: A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_get}

var A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$forms$iter__256000360__256000364", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_forms_A_class, Simple: "iter__256000360__256000364", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_forms_iter__256000360__256000364_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_InstanceOf; i.Init = A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_Init; i.Table = A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_class, reflect.TypeFor[A_arbace_a2g_dyn_forms_iter__256000360__256000364_A]()) }

func A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_invoke, New: A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_new, Get: A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_get}

var A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$forms$iter__256000360__256000364$fn__256000365", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_forms_iter__256000360__256000364_A_class, Simple: "fn__256000365", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_InstanceOf; i.Init = A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_Init; i.Table = A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_class, reflect.TypeFor[A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A]()) }

func A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A_invoke, New: A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A_new, Get: A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A_get}

var A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$forms$iter__256000360__256000364$fn__256000365$fn__256000366", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_A_class, Simple: "fn__256000366", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A_InstanceOf; i.Init = A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A_Init; i.Table = A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A_class, reflect.TypeFor[A_arbace_a2g_dyn_forms_iter__256000360__256000364_fn__256000365_fn__256000366_A]()) }

func A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_forms_iter__256000376__256000380_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_New()}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_invoke, New: A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_new, Get: A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_get}

var A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$forms$iter__256000376__256000380", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_forms_A_class, Simple: "iter__256000376__256000380", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_forms_iter__256000376__256000380_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_InstanceOf; i.Init = A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_Init; i.Table = A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_class, reflect.TypeFor[A_arbace_a2g_dyn_forms_iter__256000376__256000380_A]()) }

func A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_invoke, New: A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_new, Get: A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_get}

var A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$forms$iter__256000376__256000380$fn__256000381", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_forms_iter__256000376__256000380_A_class, Simple: "fn__256000381", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_InstanceOf; i.Init = A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_Init; i.Table = A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_class, reflect.TypeFor[A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A]()) }

func A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A_invoke, New: A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A_new, Get: A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A_get}

var A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$forms$iter__256000376__256000380$fn__256000381$fn__256000382", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_A_class, Simple: "fn__256000382", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A_InstanceOf; i.Init = A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A_Init; i.Table = A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A_class, reflect.TypeFor[A_arbace_a2g_dyn_forms_iter__256000376__256000380_fn__256000381_fn__256000382_A]()) }

func A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_forms_iter__256000388__256000392_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_New()}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_invoke, New: A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_new, Get: A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_get}

var A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$forms$iter__256000388__256000392", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_forms_A_class, Simple: "iter__256000388__256000392", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_forms_iter__256000388__256000392_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_InstanceOf; i.Init = A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_Init; i.Table = A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_class, reflect.TypeFor[A_arbace_a2g_dyn_forms_iter__256000388__256000392_A]()) }

func A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_invoke, New: A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_new, Get: A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_get}

var A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$forms$iter__256000388__256000392$fn__256000393", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_forms_iter__256000388__256000392_A_class, Simple: "fn__256000393", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_InstanceOf; i.Init = A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_Init; i.Table = A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_class, reflect.TypeFor[A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A]()) }

func A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A_invoke, New: A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A_new, Get: A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A_get}

var A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$forms$iter__256000388__256000392$fn__256000393$fn__256000394", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_A_class, Simple: "fn__256000394", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A_InstanceOf; i.Init = A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A_Init; i.Table = A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A_class, reflect.TypeFor[A_arbace_a2g_dyn_forms_iter__256000388__256000392_fn__256000393_fn__256000394_A]()) }

func A_arbace_a2g_dyn_go_method_names_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_go_method_names_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_go_method_names_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_go_method_names_A_New()}; return nil }

func A_arbace_a2g_dyn_go_method_names_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_go_method_names_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_go_method_names_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_go_method_names_A_invoke, New: A_arbace_a2g_dyn_go_method_names_A_new, Get: A_arbace_a2g_dyn_go_method_names_A_get}

var A_arbace_a2g_dyn_go_method_names_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$go_method_names", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "go_method_names", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_go_method_names_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_go_method_names_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_go_method_names_A_InstanceOf; i.Init = A_arbace_a2g_dyn_go_method_names_A_Init; i.Table = A_arbace_a2g_dyn_go_method_names_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_go_method_names_A_class, reflect.TypeFor[A_arbace_a2g_dyn_go_method_names_A]()) }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_New()}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_invoke, New: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_new, Get: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_get}

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$go_method_names$iter__256000242__256000248", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_go_method_names_A_class, Simple: "iter__256000242__256000248", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_InstanceOf; i.Init = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_Init; i.Table = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_class, reflect.TypeFor[A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A]()) }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_invoke, New: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_new, Get: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_get}

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$go_method_names$iter__256000242__256000248$fn__256000249", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_A_class, Simple: "fn__256000249", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_InstanceOf; i.Init = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_Init; i.Table = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_class, reflect.TypeFor[A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A]()) }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_New()}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_invoke, New: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_new, Get: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_get}

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$go_method_names$iter__256000242__256000248$fn__256000249$iter__256000244__256000250", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_class, Simple: "iter__256000244__256000250", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_InstanceOf; i.Init = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_Init; i.Table = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_class, reflect.TypeFor[A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A]()) }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_invoke, New: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_new, Get: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_get}

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$go_method_names$iter__256000242__256000248$fn__256000249$iter__256000244__256000250$fn__256000251", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_A_class, Simple: "fn__256000251", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_InstanceOf; i.Init = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_Init; i.Table = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_class, reflect.TypeFor[A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A]()) }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A_invoke, New: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A_new, Get: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A_get}

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$go_method_names$iter__256000242__256000248$fn__256000249$iter__256000244__256000250$fn__256000251$fn__256000252", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_A_class, Simple: "fn__256000252", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A_InstanceOf; i.Init = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A_Init; i.Table = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A_class, reflect.TypeFor[A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000244__256000250_fn__256000251_fn__256000252_A]()) }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_New()}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_invoke, New: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_new, Get: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_get}

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$go_method_names$iter__256000242__256000248$fn__256000249$iter__256000256__256000260", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_A_class, Simple: "iter__256000256__256000260", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_InstanceOf; i.Init = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_Init; i.Table = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_class, reflect.TypeFor[A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A]()) }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_invoke, New: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_new, Get: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_get}

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$go_method_names$iter__256000242__256000248$fn__256000249$iter__256000256__256000260$fn__256000261", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_A_class, Simple: "fn__256000261", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_InstanceOf; i.Init = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_Init; i.Table = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_class, reflect.TypeFor[A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A]()) }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A_invoke, New: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A_new, Get: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A_get}

var A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$go_method_names$iter__256000242__256000248$fn__256000249$iter__256000256__256000260$fn__256000261$fn__256000262", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_A_class, Simple: "fn__256000262", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A_InstanceOf; i.Init = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A_Init; i.Table = A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A_class, reflect.TypeFor[A_arbace_a2g_dyn_go_method_names_iter__256000242__256000248_fn__256000249_iter__256000256__256000260_fn__256000261_fn__256000262_A]()) }

func A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_New_O(args[0])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_invoke, New: A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_new, Get: A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_get}

var A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$go_method_names$iter__256000268__256000272", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_go_method_names_A_class, Simple: "iter__256000268__256000272", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_InstanceOf; i.Init = A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_Init; i.Table = A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_class, reflect.TypeFor[A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A]()) }

func A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_invoke, New: A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_new, Get: A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_get}

var A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$go_method_names$iter__256000268__256000272$fn__256000273", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_A_class, Simple: "fn__256000273", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_InstanceOf; i.Init = A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_Init; i.Table = A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_class, reflect.TypeFor[A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A]()) }

func A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A_invoke, New: A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A_new, Get: A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A_get}

var A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$go_method_names$iter__256000268__256000272$fn__256000273$fn__256000274", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_A_class, Simple: "fn__256000274", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A_InstanceOf; i.Init = A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A_Init; i.Table = A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A_class, reflect.TypeFor[A_arbace_a2g_dyn_go_method_names_iter__256000268__256000272_fn__256000273_fn__256000274_A]()) }

func A_arbace_a2g_dyn_iface_fallback_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4]); case 1: return this.(*A_arbace_a2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_dyn_iface_fallback_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_iface_fallback_A_New()}; return nil }

func A_arbace_a2g_dyn_iface_fallback_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_iface_fallback_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_iface_fallback_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_iface_fallback_A_invoke, New: A_arbace_a2g_dyn_iface_fallback_A_new, Get: A_arbace_a2g_dyn_iface_fallback_A_get}

var A_arbace_a2g_dyn_iface_fallback_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$iface_fallback", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class, lang.Compiler_AOTF4_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "iface_fallback", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_iface_fallback_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_iface_fallback_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_iface_fallback_A_InstanceOf; i.Init = A_arbace_a2g_dyn_iface_fallback_A_Init; i.Table = A_arbace_a2g_dyn_iface_fallback_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_iface_fallback_A_class, reflect.TypeFor[A_arbace_a2g_dyn_iface_fallback_A]()) }

func A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_invoke, New: A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_new, Get: A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_get}

var A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$iface_fallback$iter__256000130__256000134", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_iface_fallback_A_class, Simple: "iter__256000130__256000134", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_InstanceOf; i.Init = A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_Init; i.Table = A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_class, reflect.TypeFor[A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A]()) }

func A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_invoke, New: A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_new, Get: A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_get}

var A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$iface_fallback$iter__256000130__256000134$fn__256000135", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_A_class, Simple: "fn__256000135", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_InstanceOf; i.Init = A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_Init; i.Table = A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_class, reflect.TypeFor[A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A]()) }

func A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A_New_O_O_O_I_O_O(args[0], args[1], args[2], args[3].(int32), args[4], args[5])}; return nil }

func A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A_invoke, New: A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A_new, Get: A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A_get}

var A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$iface_fallback$iter__256000130__256000134$fn__256000135$fn__256000136", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_A_class, Simple: "fn__256000136", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A_InstanceOf; i.Init = A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A_Init; i.Table = A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A_class, reflect.TypeFor[A_arbace_a2g_dyn_iface_fallback_iter__256000130__256000134_fn__256000135_fn__256000136_A]()) }

func A_arbace_a2g_dyn_interfaces_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_interfaces_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_interfaces_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_interfaces_A_New()}; return nil }

func A_arbace_a2g_dyn_interfaces_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_interfaces_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_interfaces_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_interfaces_A_invoke, New: A_arbace_a2g_dyn_interfaces_A_new, Get: A_arbace_a2g_dyn_interfaces_A_get}

var A_arbace_a2g_dyn_interfaces_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$interfaces", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "interfaces", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_interfaces_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_interfaces_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_interfaces_A_InstanceOf; i.Init = A_arbace_a2g_dyn_interfaces_A_Init; i.Table = A_arbace_a2g_dyn_interfaces_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_interfaces_A_class, reflect.TypeFor[A_arbace_a2g_dyn_interfaces_A]()) }

func A_arbace_a2g_dyn_interfaces_fn__256000034_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_interfaces_fn__256000034_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_interfaces_fn__256000034_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_interfaces_fn__256000034_A_New()}; return nil }

func A_arbace_a2g_dyn_interfaces_fn__256000034_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_interfaces_fn__256000034_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_interfaces_fn__256000034_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_interfaces_fn__256000034_A_invoke, New: A_arbace_a2g_dyn_interfaces_fn__256000034_A_new, Get: A_arbace_a2g_dyn_interfaces_fn__256000034_A_get}

var A_arbace_a2g_dyn_interfaces_fn__256000034_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$interfaces$fn__256000034", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_interfaces_A_class, Simple: "fn__256000034", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_interfaces_fn__256000034_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_interfaces_fn__256000034_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_interfaces_fn__256000034_A_InstanceOf; i.Init = A_arbace_a2g_dyn_interfaces_fn__256000034_A_Init; i.Table = A_arbace_a2g_dyn_interfaces_fn__256000034_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_interfaces_fn__256000034_A_class, reflect.TypeFor[A_arbace_a2g_dyn_interfaces_fn__256000034_A]()) }

func A_arbace_a2g_dyn_interfaces_fn__256000036_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_interfaces_fn__256000036_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_interfaces_fn__256000036_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_interfaces_fn__256000036_A_New()}; return nil }

func A_arbace_a2g_dyn_interfaces_fn__256000036_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_interfaces_fn__256000036_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_interfaces_fn__256000036_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_interfaces_fn__256000036_A_invoke, New: A_arbace_a2g_dyn_interfaces_fn__256000036_A_new, Get: A_arbace_a2g_dyn_interfaces_fn__256000036_A_get}

var A_arbace_a2g_dyn_interfaces_fn__256000036_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$interfaces$fn__256000036", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_interfaces_A_class, Simple: "fn__256000036", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_interfaces_fn__256000036_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_interfaces_fn__256000036_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_interfaces_fn__256000036_A_InstanceOf; i.Init = A_arbace_a2g_dyn_interfaces_fn__256000036_A_Init; i.Table = A_arbace_a2g_dyn_interfaces_fn__256000036_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_interfaces_fn__256000036_A_class, reflect.TypeFor[A_arbace_a2g_dyn_interfaces_fn__256000036_A]()) }

func A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_New()}; return nil }

func A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_invoke, New: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_new, Get: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_get}

var A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$interfaces$iter__256000038__256000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_interfaces_A_class, Simple: "iter__256000038__256000044", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_InstanceOf; i.Init = A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_Init; i.Table = A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_class, reflect.TypeFor[A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A]()) }

func A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_invoke, New: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_new, Get: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_get}

var A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$interfaces$iter__256000038__256000044$fn__256000045", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_A_class, Simple: "fn__256000045", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_InstanceOf; i.Init = A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_Init; i.Table = A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_class, reflect.TypeFor[A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A]()) }

func A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_New_O(args[0])}; return nil }

func A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_invoke, New: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_new, Get: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_get}

var A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$interfaces$iter__256000038__256000044$fn__256000045$iter__256000040__256000046", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_A_class, Simple: "iter__256000040__256000046", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_InstanceOf; i.Init = A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_Init; i.Table = A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_class, reflect.TypeFor[A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A]()) }

func A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_invoke, New: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_new, Get: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_get}

var A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$interfaces$iter__256000038__256000044$fn__256000045$iter__256000040__256000046$fn__256000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_A_class, Simple: "fn__256000047", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_InstanceOf; i.Init = A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_Init; i.Table = A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_class, reflect.TypeFor[A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A]()) }

func A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A_invoke, New: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A_new, Get: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A_get}

var A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$interfaces$iter__256000038__256000044$fn__256000045$iter__256000040__256000046$fn__256000047$fn__256000048", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_A_class, Simple: "fn__256000048", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A_InstanceOf; i.Init = A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A_Init; i.Table = A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A_class, reflect.TypeFor[A_arbace_a2g_dyn_interfaces_iter__256000038__256000044_fn__256000045_iter__256000040__256000046_fn__256000047_fn__256000048_A]()) }

func A_arbace_a2g_dyn_java_type_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_java_type_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_java_type_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_java_type_name_A_New()}; return nil }

func A_arbace_a2g_dyn_java_type_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_java_type_name_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_java_type_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_java_type_name_A_invoke, New: A_arbace_a2g_dyn_java_type_name_A_new, Get: A_arbace_a2g_dyn_java_type_name_A_get}

var A_arbace_a2g_dyn_java_type_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$java_type_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "java_type_name", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_java_type_name_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_java_type_name_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_java_type_name_A_InstanceOf; i.Init = A_arbace_a2g_dyn_java_type_name_A_Init; i.Table = A_arbace_a2g_dyn_java_type_name_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_java_type_name_A_class, reflect.TypeFor[A_arbace_a2g_dyn_java_type_name_A]()) }

func A_arbace_a2g_dyn_method_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_method_form_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3]); case 1: return this.(*A_arbace_a2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4]); case 2: return this.(*A_arbace_a2g_dyn_method_form_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_dyn_method_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_method_form_A_New()}; return nil }

func A_arbace_a2g_dyn_method_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_method_form_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_method_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_method_form_A_invoke, New: A_arbace_a2g_dyn_method_form_A_new, Get: A_arbace_a2g_dyn_method_form_A_get}

var A_arbace_a2g_dyn_method_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$method_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class, lang.Compiler_AOTF4_class, lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "method_form", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_method_form_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_method_form_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_method_form_A_InstanceOf; i.Init = A_arbace_a2g_dyn_method_form_A_Init; i.Table = A_arbace_a2g_dyn_method_form_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_method_form_A_class, reflect.TypeFor[A_arbace_a2g_dyn_method_form_A]()) }

func A_arbace_a2g_dyn_method_form_fn__256000150_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_method_form_fn__256000150_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_method_form_fn__256000150_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_method_form_fn__256000150_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_method_form_fn__256000150_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_method_form_fn__256000150_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_method_form_fn__256000150_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_method_form_fn__256000150_A_invoke, New: A_arbace_a2g_dyn_method_form_fn__256000150_A_new, Get: A_arbace_a2g_dyn_method_form_fn__256000150_A_get}

var A_arbace_a2g_dyn_method_form_fn__256000150_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$method_form$fn__256000150", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_method_form_A_class, Simple: "fn__256000150", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_method_form_fn__256000150_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_method_form_fn__256000150_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_method_form_fn__256000150_A_InstanceOf; i.Init = A_arbace_a2g_dyn_method_form_fn__256000150_A_Init; i.Table = A_arbace_a2g_dyn_method_form_fn__256000150_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_method_form_fn__256000150_A_class, reflect.TypeFor[A_arbace_a2g_dyn_method_form_fn__256000150_A]()) }

func A_arbace_a2g_dyn_method_form_fn__256000168_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_method_form_fn__256000168_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_method_form_fn__256000168_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_method_form_fn__256000168_A_New()}; return nil }

func A_arbace_a2g_dyn_method_form_fn__256000168_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_method_form_fn__256000168_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_method_form_fn__256000168_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_method_form_fn__256000168_A_invoke, New: A_arbace_a2g_dyn_method_form_fn__256000168_A_new, Get: A_arbace_a2g_dyn_method_form_fn__256000168_A_get}

var A_arbace_a2g_dyn_method_form_fn__256000168_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$method_form$fn__256000168", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_method_form_A_class, Simple: "fn__256000168", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_method_form_fn__256000168_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_method_form_fn__256000168_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_method_form_fn__256000168_A_InstanceOf; i.Init = A_arbace_a2g_dyn_method_form_fn__256000168_A_Init; i.Table = A_arbace_a2g_dyn_method_form_fn__256000168_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_method_form_fn__256000168_A_class, reflect.TypeFor[A_arbace_a2g_dyn_method_form_fn__256000168_A]()) }

func A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_New()}; return nil }

func A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_invoke, New: A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_new, Get: A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_get}

var A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$method_form$iter__256000158__256000162", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_method_form_A_class, Simple: "iter__256000158__256000162", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_InstanceOf; i.Init = A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_Init; i.Table = A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_class, reflect.TypeFor[A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A]()) }

func A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_invoke, New: A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_new, Get: A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_get}

var A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$method_form$iter__256000158__256000162$fn__256000163", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_method_form_iter__256000158__256000162_A_class, Simple: "fn__256000163", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_InstanceOf; i.Init = A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_Init; i.Table = A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_class, reflect.TypeFor[A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A]()) }

func A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A_invoke, New: A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A_new, Get: A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A_get}

var A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$method_form$iter__256000158__256000162$fn__256000163$fn__256000164", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_A_class, Simple: "fn__256000164", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A_InstanceOf; i.Init = A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A_Init; i.Table = A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A_class, reflect.TypeFor[A_arbace_a2g_dyn_method_form_iter__256000158__256000162_fn__256000163_fn__256000164_A]()) }

func A_arbace_a2g_dyn_native_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_native_name_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_native_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_native_name_A_New()}; return nil }

func A_arbace_a2g_dyn_native_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_native_name_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_native_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_native_name_A_invoke, New: A_arbace_a2g_dyn_native_name_A_new, Get: A_arbace_a2g_dyn_native_name_A_get}

var A_arbace_a2g_dyn_native_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$native_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "native_name", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_native_name_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_native_name_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_native_name_A_InstanceOf; i.Init = A_arbace_a2g_dyn_native_name_A_Init; i.Table = A_arbace_a2g_dyn_native_name_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_native_name_A_class, reflect.TypeFor[A_arbace_a2g_dyn_native_name_A]()) }

func A_arbace_a2g_dyn_object_fallback_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_object_fallback_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_dyn_object_fallback_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_object_fallback_A_New()}; return nil }

func A_arbace_a2g_dyn_object_fallback_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_object_fallback_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_object_fallback_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_object_fallback_A_invoke, New: A_arbace_a2g_dyn_object_fallback_A_new, Get: A_arbace_a2g_dyn_object_fallback_A_get}

var A_arbace_a2g_dyn_object_fallback_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$object_fallback", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "object_fallback", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_object_fallback_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_object_fallback_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_object_fallback_A_InstanceOf; i.Init = A_arbace_a2g_dyn_object_fallback_A_Init; i.Table = A_arbace_a2g_dyn_object_fallback_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_object_fallback_A_class, reflect.TypeFor[A_arbace_a2g_dyn_object_fallback_A]()) }

func A_arbace_a2g_dyn_proxy_classes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_proxy_classes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_proxy_classes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_proxy_classes_A_New()}; return nil }

func A_arbace_a2g_dyn_proxy_classes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_proxy_classes_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_proxy_classes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_proxy_classes_A_invoke, New: A_arbace_a2g_dyn_proxy_classes_A_new, Get: A_arbace_a2g_dyn_proxy_classes_A_get}

var A_arbace_a2g_dyn_proxy_classes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$proxy_classes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "proxy_classes", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_proxy_classes_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_proxy_classes_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_proxy_classes_A_InstanceOf; i.Init = A_arbace_a2g_dyn_proxy_classes_A_Init; i.Table = A_arbace_a2g_dyn_proxy_classes_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_proxy_classes_A_class, reflect.TypeFor[A_arbace_a2g_dyn_proxy_classes_A]()) }

func A_arbace_a2g_dyn_proxy_classes_fn__256000173_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_proxy_classes_fn__256000173_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_proxy_classes_fn__256000173_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_proxy_classes_fn__256000173_A_New_O(args[0])}; return nil }

func A_arbace_a2g_dyn_proxy_classes_fn__256000173_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_proxy_classes_fn__256000173_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_proxy_classes_fn__256000173_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_proxy_classes_fn__256000173_A_invoke, New: A_arbace_a2g_dyn_proxy_classes_fn__256000173_A_new, Get: A_arbace_a2g_dyn_proxy_classes_fn__256000173_A_get}

var A_arbace_a2g_dyn_proxy_classes_fn__256000173_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$proxy_classes$fn__256000173", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_proxy_classes_A_class, Simple: "fn__256000173", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_proxy_classes_fn__256000173_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_proxy_classes_fn__256000173_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_proxy_classes_fn__256000173_A_InstanceOf; i.Init = A_arbace_a2g_dyn_proxy_classes_fn__256000173_A_Init; i.Table = A_arbace_a2g_dyn_proxy_classes_fn__256000173_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_proxy_classes_fn__256000173_A_class, reflect.TypeFor[A_arbace_a2g_dyn_proxy_classes_fn__256000173_A]()) }

func A_arbace_a2g_dyn_proxy_roots_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_proxy_roots_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_proxy_roots_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_proxy_roots_A_New()}; return nil }

func A_arbace_a2g_dyn_proxy_roots_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_proxy_roots_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_proxy_roots_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_proxy_roots_A_invoke, New: A_arbace_a2g_dyn_proxy_roots_A_new, Get: A_arbace_a2g_dyn_proxy_roots_A_get}

var A_arbace_a2g_dyn_proxy_roots_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$proxy_roots", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "proxy_roots", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_proxy_roots_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_proxy_roots_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_proxy_roots_A_InstanceOf; i.Init = A_arbace_a2g_dyn_proxy_roots_A_Init; i.Table = A_arbace_a2g_dyn_proxy_roots_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_proxy_roots_A_class, reflect.TypeFor[A_arbace_a2g_dyn_proxy_roots_A]()) }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_New()}; return nil }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_invoke, New: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_new, Get: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_get}

var A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$proxy_roots$iter__256000177__256000185", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_proxy_roots_A_class, Simple: "iter__256000177__256000185", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_InstanceOf; i.Init = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_Init; i.Table = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_class, reflect.TypeFor[A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A]()) }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_invoke, New: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_new, Get: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_get}

var A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$proxy_roots$iter__256000177__256000185$fn__256000186", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_A_class, Simple: "fn__256000186", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_InstanceOf; i.Init = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_Init; i.Table = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_class, reflect.TypeFor[A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A]()) }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_New_O(args[0])}; return nil }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_invoke, New: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_new, Get: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_get}

var A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$proxy_roots$iter__256000177__256000185$fn__256000186$iter__256000179__256000187", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_A_class, Simple: "iter__256000179__256000187", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_InstanceOf; i.Init = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_Init; i.Table = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_class, reflect.TypeFor[A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A]()) }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_invoke, New: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_new, Get: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_get}

var A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$proxy_roots$iter__256000177__256000185$fn__256000186$iter__256000179__256000187$fn__256000188", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_A_class, Simple: "fn__256000188", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_InstanceOf; i.Init = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_Init; i.Table = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_class, reflect.TypeFor[A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A]()) }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_invoke, New: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_new, Get: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_get}

var A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$proxy_roots$iter__256000177__256000185$fn__256000186$iter__256000179__256000187$fn__256000188$iter__256000181__256000189", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_A_class, Simple: "iter__256000181__256000189", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_InstanceOf; i.Init = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_Init; i.Table = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_class, reflect.TypeFor[A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A]()) }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_invoke, New: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_new, Get: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_get}

var A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$proxy_roots$iter__256000177__256000185$fn__256000186$iter__256000179__256000187$fn__256000188$iter__256000181__256000189$fn__256000190", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_A_class, Simple: "fn__256000190", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_InstanceOf; i.Init = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_Init; i.Table = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_class, reflect.TypeFor[A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A]()) }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A_New_O_O_I_O_O(args[0], args[1], args[2].(int32), args[3], args[4])}; return nil }

func A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A_invoke, New: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A_new, Get: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A_get}

var A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$proxy_roots$iter__256000177__256000185$fn__256000186$iter__256000179__256000187$fn__256000188$iter__256000181__256000189$fn__256000190$fn__256000191", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_A_class, Simple: "fn__256000191", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A_InstanceOf; i.Init = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A_Init; i.Table = A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A_class, reflect.TypeFor[A_arbace_a2g_dyn_proxy_roots_iter__256000177__256000185_fn__256000186_iter__256000179__256000187_fn__256000188_iter__256000181__256000189_fn__256000190_fn__256000191_A]()) }

func A_arbace_a2g_dyn_public_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_public_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_public_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_public_QMARK__A_New()}; return nil }

func A_arbace_a2g_dyn_public_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_public_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_dyn_public_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_public_QMARK__A_invoke, New: A_arbace_a2g_dyn_public_QMARK__A_new, Get: A_arbace_a2g_dyn_public_QMARK__A_get}

var A_arbace_a2g_dyn_public_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$public_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "public_QMARK_", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_public_QMARK__A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_public_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_public_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_dyn_public_QMARK__A_Init; i.Table = A_arbace_a2g_dyn_public_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_public_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_dyn_public_QMARK__A]()) }

func A_arbace_a2g_dyn_roots_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_roots_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_roots_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_roots_A_New()}; return nil }

func A_arbace_a2g_dyn_roots_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_roots_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_roots_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_roots_A_invoke, New: A_arbace_a2g_dyn_roots_A_new, Get: A_arbace_a2g_dyn_roots_A_get}

var A_arbace_a2g_dyn_roots_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$roots", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "roots", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_roots_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_roots_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_roots_A_InstanceOf; i.Init = A_arbace_a2g_dyn_roots_A_Init; i.Table = A_arbace_a2g_dyn_roots_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_roots_A_class, reflect.TypeFor[A_arbace_a2g_dyn_roots_A]()) }

func A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_roots_iter__256000013__256000017_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_New()}; return nil }

func A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_invoke, New: A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_new, Get: A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_get}

var A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$roots$iter__256000013__256000017", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_roots_A_class, Simple: "iter__256000013__256000017", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_roots_iter__256000013__256000017_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_InstanceOf; i.Init = A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_Init; i.Table = A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_class, reflect.TypeFor[A_arbace_a2g_dyn_roots_iter__256000013__256000017_A]()) }

func A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_invoke, New: A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_new, Get: A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_get}

var A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$roots$iter__256000013__256000017$fn__256000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_roots_iter__256000013__256000017_A_class, Simple: "fn__256000018", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_InstanceOf; i.Init = A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_Init; i.Table = A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_class, reflect.TypeFor[A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A]()) }

func A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A_invoke, New: A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A_new, Get: A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A_get}

var A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$roots$iter__256000013__256000017$fn__256000018$fn__256000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_A_class, Simple: "fn__256000019", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A_InstanceOf; i.Init = A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A_Init; i.Table = A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A_class, reflect.TypeFor[A_arbace_a2g_dyn_roots_iter__256000013__256000017_fn__256000018_fn__256000019_A]()) }

func A_arbace_a2g_dyn_slot_keys_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_slot_keys_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_slot_keys_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_slot_keys_A_New()}; return nil }

func A_arbace_a2g_dyn_slot_keys_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_slot_keys_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_slot_keys_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_slot_keys_A_invoke, New: A_arbace_a2g_dyn_slot_keys_A_new, Get: A_arbace_a2g_dyn_slot_keys_A_get}

var A_arbace_a2g_dyn_slot_keys_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$slot_keys", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "slot_keys", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_slot_keys_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_slot_keys_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_slot_keys_A_InstanceOf; i.Init = A_arbace_a2g_dyn_slot_keys_A_Init; i.Table = A_arbace_a2g_dyn_slot_keys_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_slot_keys_A_class, reflect.TypeFor[A_arbace_a2g_dyn_slot_keys_A]()) }

func A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_New()}; return nil }

func A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_invoke, New: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_new, Get: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_get}

var A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$slot_keys$iter__256000055__256000061", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_slot_keys_A_class, Simple: "iter__256000055__256000061", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_InstanceOf; i.Init = A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_Init; i.Table = A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_class, reflect.TypeFor[A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A]()) }

func A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_invoke, New: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_new, Get: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_get}

var A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$slot_keys$iter__256000055__256000061$fn__256000062", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_A_class, Simple: "fn__256000062", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_InstanceOf; i.Init = A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_Init; i.Table = A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_class, reflect.TypeFor[A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A]()) }

func A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_New()}; return nil }

func A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_invoke, New: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_new, Get: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_get}

var A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$slot_keys$iter__256000055__256000061$fn__256000062$iter__256000057__256000063", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_A_class, Simple: "iter__256000057__256000063", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_InstanceOf; i.Init = A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_Init; i.Table = A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_class, reflect.TypeFor[A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A]()) }

func A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_invoke, New: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_new, Get: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_get}

var A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$slot_keys$iter__256000055__256000061$fn__256000062$iter__256000057__256000063$fn__256000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_A_class, Simple: "fn__256000064", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_InstanceOf; i.Init = A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_Init; i.Table = A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_class, reflect.TypeFor[A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A]()) }

func A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A_invoke, New: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A_new, Get: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A_get}

var A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$slot_keys$iter__256000055__256000061$fn__256000062$iter__256000057__256000063$fn__256000064$fn__256000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_A_class, Simple: "fn__256000065", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A_InstanceOf; i.Init = A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A_Init; i.Table = A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A_class, reflect.TypeFor[A_arbace_a2g_dyn_slot_keys_iter__256000055__256000061_fn__256000062_iter__256000057__256000063_fn__256000064_fn__256000065_A]()) }

func A_arbace_a2g_dyn_sub_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_dyn_sub_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_A_New()}; return nil }

func A_arbace_a2g_dyn_sub_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_A_invoke, New: A_arbace_a2g_dyn_sub_forms_A_new, Get: A_arbace_a2g_dyn_sub_forms_A_get}

var A_arbace_a2g_dyn_sub_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "sub_forms", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_A]()) }

func A_arbace_a2g_dyn_sub_forms_fn__256000296_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_fn__256000296_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_sub_forms_fn__256000296_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_fn__256000296_A_New()}; return nil }

func A_arbace_a2g_dyn_sub_forms_fn__256000296_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_fn__256000296_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_fn__256000296_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_fn__256000296_A_invoke, New: A_arbace_a2g_dyn_sub_forms_fn__256000296_A_new, Get: A_arbace_a2g_dyn_sub_forms_fn__256000296_A_get}

var A_arbace_a2g_dyn_sub_forms_fn__256000296_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$fn__256000296", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_sub_forms_A_class, Simple: "fn__256000296", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_fn__256000296_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_fn__256000296_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_fn__256000296_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_fn__256000296_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_fn__256000296_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_fn__256000296_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_fn__256000296_A]()) }

func A_arbace_a2g_dyn_sub_forms_fn__256000342_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_fn__256000342_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_sub_forms_fn__256000342_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_fn__256000342_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_dyn_sub_forms_fn__256000342_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_fn__256000342_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_fn__256000342_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_fn__256000342_A_invoke, New: A_arbace_a2g_dyn_sub_forms_fn__256000342_A_new, Get: A_arbace_a2g_dyn_sub_forms_fn__256000342_A_get}

var A_arbace_a2g_dyn_sub_forms_fn__256000342_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$fn__256000342", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_sub_forms_A_class, Simple: "fn__256000342", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_fn__256000342_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_fn__256000342_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_fn__256000342_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_fn__256000342_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_fn__256000342_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_fn__256000342_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_fn__256000342_A]()) }

func A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A_invoke, New: A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A_new, Get: A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A_get}

var A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$fn__256000342$fn__256000346", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_sub_forms_fn__256000342_A_class, Simple: "fn__256000346", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000346_A]()) }

func A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A_invoke, New: A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A_new, Get: A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A_get}

var A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$fn__256000342$fn__256000348", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_sub_forms_fn__256000342_A_class, Simple: "fn__256000348", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_fn__256000342_fn__256000348_A]()) }

func A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_New()}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_invoke, New: A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_new, Get: A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_get}

var A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$iter__256000279__256000283", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_sub_forms_A_class, Simple: "iter__256000279__256000283", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A]()) }

func A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_invoke, New: A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_new, Get: A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_get}

var A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$iter__256000279__256000283$fn__256000284", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_A_class, Simple: "fn__256000284", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A]()) }

func A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A_invoke, New: A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A_new, Get: A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A_get}

var A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$iter__256000279__256000283$fn__256000284$fn__256000285", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_A_class, Simple: "fn__256000285", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_iter__256000279__256000283_fn__256000284_fn__256000285_A]()) }

func A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_New()}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_invoke, New: A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_new, Get: A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_get}

var A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$iter__256000301__256000305", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_sub_forms_A_class, Simple: "iter__256000301__256000305", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A]()) }

func A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_invoke, New: A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_new, Get: A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_get}

var A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$iter__256000301__256000305$fn__256000306", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_A_class, Simple: "fn__256000306", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A]()) }

func A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A_invoke, New: A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A_new, Get: A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A_get}

var A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$iter__256000301__256000305$fn__256000306$fn__256000307", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_A_class, Simple: "fn__256000307", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_iter__256000301__256000305_fn__256000306_fn__256000307_A]()) }

func A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_invoke, New: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_new, Get: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_get}

var A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$iter__256000317__256000321", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_sub_forms_A_class, Simple: "iter__256000317__256000321", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A]()) }

func A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_invoke, New: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_new, Get: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_get}

var A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$iter__256000317__256000321$fn__256000322", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_A_class, Simple: "fn__256000322", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A]()) }

func A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_invoke, New: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_new, Get: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_get}

var A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$iter__256000317__256000321$fn__256000322$fn__256000323", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_class, Simple: "fn__256000323", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A]()) }

func A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A_invoke, New: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A_new, Get: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A_get}

var A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$iter__256000317__256000321$fn__256000322$fn__256000323$fn__256000324", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_A_class, Simple: "fn__256000324", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000323_fn__256000324_A]()) }

func A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A_invoke, New: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A_new, Get: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A_get}

var A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$iter__256000317__256000321$fn__256000322$fn__256000327", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_A_class, Simple: "fn__256000327", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_iter__256000317__256000321_fn__256000322_fn__256000327_A]()) }

func A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_invoke, New: A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_new, Get: A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_get}

var A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$iter__256000331__256000335", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_sub_forms_A_class, Simple: "iter__256000331__256000335", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A]()) }

func A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_invoke, New: A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_new, Get: A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_get}

var A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$iter__256000331__256000335$fn__256000336", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_A_class, Simple: "fn__256000336", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A]()) }

func A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A_invoke, New: A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A_new, Get: A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A_get}

var A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_forms$iter__256000331__256000335$fn__256000336$fn__256000337", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_A_class, Simple: "fn__256000337", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A_Init; i.Table = A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_forms_iter__256000331__256000335_fn__256000336_fn__256000337_A]()) }

func A_arbace_a2g_dyn_sub_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_sub_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_dyn_sub_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_sub_name_A_New()}; return nil }

func A_arbace_a2g_dyn_sub_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_sub_name_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_sub_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_sub_name_A_invoke, New: A_arbace_a2g_dyn_sub_name_A_new, Get: A_arbace_a2g_dyn_sub_name_A_get}

var A_arbace_a2g_dyn_sub_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$sub_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "sub_name", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_sub_name_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_sub_name_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_sub_name_A_InstanceOf; i.Init = A_arbace_a2g_dyn_sub_name_A_Init; i.Table = A_arbace_a2g_dyn_sub_name_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_sub_name_A_class, reflect.TypeFor[A_arbace_a2g_dyn_sub_name_A]()) }

func A_arbace_a2g_dyn_tag_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_dyn_tag_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_dyn_tag_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn_tag_A_New()}; return nil }

func A_arbace_a2g_dyn_tag_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_dyn_tag_A_fn_class)}; return nil }

var A_arbace_a2g_dyn_tag_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_dyn_tag_A_invoke, New: A_arbace_a2g_dyn_tag_A_new, Get: A_arbace_a2g_dyn_tag_A_get}

var A_arbace_a2g_dyn_tag_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn$tag", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_dyn_A_class, Simple: "tag", Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn_tag_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn_tag_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn_tag_A_InstanceOf; i.Init = A_arbace_a2g_dyn_tag_A_Init; i.Table = A_arbace_a2g_dyn_tag_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn_tag_A_class, reflect.TypeFor[A_arbace_a2g_dyn_tag_A]()) }

func A_arbace_a2g_dyn__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_dyn__init_A_Load__O(); case 1: return A_arbace_a2g_dyn__init_A_Unit0__O(); case 2: return A_arbace_a2g_dyn__init_A_Unit1__O(); case 3: return A_arbace_a2g_dyn__init_A_Unit10__O(); case 4: return A_arbace_a2g_dyn__init_A_Unit11__O(); case 5: return A_arbace_a2g_dyn__init_A_Unit12__O(); case 6: return A_arbace_a2g_dyn__init_A_Unit13__O(); case 7: return A_arbace_a2g_dyn__init_A_Unit14__O(); case 8: return A_arbace_a2g_dyn__init_A_Unit15__O(); case 9: return A_arbace_a2g_dyn__init_A_Unit16__O(); case 10: return A_arbace_a2g_dyn__init_A_Unit17__O(); case 11: return A_arbace_a2g_dyn__init_A_Unit18__O(); case 12: return A_arbace_a2g_dyn__init_A_Unit19__O(); case 13: return A_arbace_a2g_dyn__init_A_Unit2__O(); case 14: return A_arbace_a2g_dyn__init_A_Unit20__O(); case 15: return A_arbace_a2g_dyn__init_A_Unit21__O(); case 16: return A_arbace_a2g_dyn__init_A_Unit22__O(); case 17: return A_arbace_a2g_dyn__init_A_Unit23__O(); case 18: return A_arbace_a2g_dyn__init_A_Unit24__O(); case 19: return A_arbace_a2g_dyn__init_A_Unit25__O(); case 20: return A_arbace_a2g_dyn__init_A_Unit26__O(); case 21: return A_arbace_a2g_dyn__init_A_Unit27__O(); case 22: return A_arbace_a2g_dyn__init_A_Unit28__O(); case 23: return A_arbace_a2g_dyn__init_A_Unit29__O(); case 24: return A_arbace_a2g_dyn__init_A_Unit3__O(); case 25: return A_arbace_a2g_dyn__init_A_Unit30__O(); case 26: return A_arbace_a2g_dyn__init_A_Unit31__O(); case 27: return A_arbace_a2g_dyn__init_A_Unit32__O(); case 28: return A_arbace_a2g_dyn__init_A_Unit33__O(); case 29: return A_arbace_a2g_dyn__init_A_Unit34__O(); case 30: return A_arbace_a2g_dyn__init_A_Unit35__O(); case 31: return A_arbace_a2g_dyn__init_A_Unit4__O(); case 32: return A_arbace_a2g_dyn__init_A_Unit5__O(); case 33: return A_arbace_a2g_dyn__init_A_Unit6__O(); case 34: return A_arbace_a2g_dyn__init_A_Unit7__O(); case 35: return A_arbace_a2g_dyn__init_A_Unit8__O(); case 36: return A_arbace_a2g_dyn__init_A_Unit9__O()}; return nil }

func A_arbace_a2g_dyn__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_dyn__init_A_New()}; return nil }

var A_arbace_a2g_dyn__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_dyn__init_A_invoke, New: A_arbace_a2g_dyn__init_A_new}

var A_arbace_a2g_dyn__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.dyn__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_dyn.A_arbace_a2g_dyn__init_A", Source: "dyn.ae"})

func init() { i := A_arbace_a2g_dyn__init_A_class.Info(); i.IsInstance = A_arbace_a2g_dyn__init_A_InstanceOf; i.Init = A_arbace_a2g_dyn__init_A_Init; i.Table = A_arbace_a2g_dyn__init_A_members; jrt.RegisterGoType(A_arbace_a2g_dyn__init_A_class, reflect.TypeFor[A_arbace_a2g_dyn__init_A]()) }
