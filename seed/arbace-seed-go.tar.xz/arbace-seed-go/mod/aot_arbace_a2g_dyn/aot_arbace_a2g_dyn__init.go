//line aot_arbace_a2g_dyn__init.ae:1
package aot_arbace_a2g_dyn

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_dyn__init_A_Unit0__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_a2g_dyn__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_dyn__init_A_const_1) }
//line :1:1
func A_arbace_a2g_dyn__init_A_Unit1__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_a2g_dyn__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_2)) }
//line :1:1
func A_arbace_a2g_dyn__init_A_Unit2__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_Init(); tmp2 = A_arbace_a2g_dyn_eval256000004_loading__1927001464__auto____256000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_a2g_dyn__init_A_Unit3__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_a2g_dyn__init_A_const_1)).Equals_O__Z(A_arbace_a2g_dyn__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_a2g_dyn_eval256000008_fn__256000009_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_dyn_eval256000008_fn__256000009_A_Init(); tmp2 = A_arbace_a2g_dyn_eval256000008_fn__256000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_a2g_dyn__init_A_Load__O() any { A_arbace_a2g_dyn__init_A_Init(); A_arbace_a2g_dyn__init_A_Unit0__O(); A_arbace_a2g_dyn__init_A_Unit1__O(); A_arbace_a2g_dyn__init_A_Unit2__O(); A_arbace_a2g_dyn__init_A_Unit3__O(); A_arbace_a2g_dyn__init_A_Unit4__O(); A_arbace_a2g_dyn__init_A_Unit5__O(); A_arbace_a2g_dyn__init_A_Unit6__O(); A_arbace_a2g_dyn__init_A_Unit7__O(); A_arbace_a2g_dyn__init_A_Unit8__O(); A_arbace_a2g_dyn__init_A_Unit9__O(); A_arbace_a2g_dyn__init_A_Unit10__O(); A_arbace_a2g_dyn__init_A_Unit11__O(); A_arbace_a2g_dyn__init_A_Unit12__O(); A_arbace_a2g_dyn__init_A_Unit13__O(); A_arbace_a2g_dyn__init_A_Unit14__O(); A_arbace_a2g_dyn__init_A_Unit15__O(); A_arbace_a2g_dyn__init_A_Unit16__O(); A_arbace_a2g_dyn__init_A_Unit17__O(); A_arbace_a2g_dyn__init_A_Unit18__O(); A_arbace_a2g_dyn__init_A_Unit19__O(); A_arbace_a2g_dyn__init_A_Unit20__O(); A_arbace_a2g_dyn__init_A_Unit21__O(); A_arbace_a2g_dyn__init_A_Unit22__O(); A_arbace_a2g_dyn__init_A_Unit23__O(); A_arbace_a2g_dyn__init_A_Unit24__O(); A_arbace_a2g_dyn__init_A_Unit25__O(); A_arbace_a2g_dyn__init_A_Unit26__O(); A_arbace_a2g_dyn__init_A_Unit27__O(); A_arbace_a2g_dyn__init_A_Unit28__O(); A_arbace_a2g_dyn__init_A_Unit29__O(); A_arbace_a2g_dyn__init_A_Unit30__O(); A_arbace_a2g_dyn__init_A_Unit31__O(); A_arbace_a2g_dyn__init_A_Unit32__O(); A_arbace_a2g_dyn__init_A_Unit33__O(); A_arbace_a2g_dyn__init_A_Unit34__O(); A_arbace_a2g_dyn__init_A_Unit35__O(); return nil }

















func A_arbace_a2g_dyn__init_A_Unit4__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); jrt.NN(A_arbace_a2g_dyn__init_A_const_4).BindRoot_O__V(Lit_641); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_5)); return A_arbace_a2g_dyn__init_A_const_4.Ref() }

func A_arbace_a2g_dyn__init_A_Unit5__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_6; var tmp2 any = A_arbace_a2g_dyn_tag_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_tag_A_Init(); tmp3 = A_arbace_a2g_dyn_tag_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_7)); return A_arbace_a2g_dyn__init_A_const_6.Ref() }

func A_arbace_a2g_dyn__init_A_Unit6__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(27, 1); jrt.NN(A_arbace_a2g_dyn__init_A_const_8).BindRoot_O__V(A_arbace_a2g_dyn__init_A_const_9); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_8; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_10)); return A_arbace_a2g_dyn__init_A_const_8.Ref() }



func A_arbace_a2g_dyn__init_A_Unit7__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(31, 1); jrt.NN(A_arbace_a2g_dyn__init_A_const_11).BindRoot_O__V(A_arbace_a2g_dyn__init_A_const_12); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_11; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_13)); return A_arbace_a2g_dyn__init_A_const_11.Ref() }




func A_arbace_a2g_dyn__init_A_Unit8__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(36, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_14; var tmp2 any = A_arbace_a2g_dyn_roots_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_roots_A_Init(); tmp3 = A_arbace_a2g_dyn_roots_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_15)); return A_arbace_a2g_dyn__init_A_const_14.Ref() }





func A_arbace_a2g_dyn__init_A_Unit9__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_16; var tmp2 any = A_arbace_a2g_dyn_enabled_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_enabled_QMARK__A_Init(); tmp3 = A_arbace_a2g_dyn_enabled_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_17)); return A_arbace_a2g_dyn__init_A_const_16.Ref() }




func A_arbace_a2g_dyn__init_A_Unit10__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(47, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_18; var tmp2 any = A_arbace_a2g_dyn_public_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_public_QMARK__A_Init(); tmp3 = A_arbace_a2g_dyn_public_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_19)); return A_arbace_a2g_dyn__init_A_const_18.Ref() }

func A_arbace_a2g_dyn__init_A_Unit11__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(49, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_20; var tmp2 any = A_arbace_a2g_dyn_interfaces_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_interfaces_A_Init(); tmp3 = A_arbace_a2g_dyn_interfaces_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_21)); return A_arbace_a2g_dyn__init_A_const_20.Ref() }




















func A_arbace_a2g_dyn__init_A_Unit12__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_22; var tmp2 any = A_arbace_a2g_dyn_slot_keys_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_slot_keys_A_Init(); tmp3 = A_arbace_a2g_dyn_slot_keys_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_23)); return A_arbace_a2g_dyn__init_A_const_22.Ref() }





func A_arbace_a2g_dyn__init_A_Unit13__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(76, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_24; var tmp2 any = A_arbace_a2g_dyn_defaults_for_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_defaults_for_A_Init(); tmp3 = A_arbace_a2g_dyn_defaults_for_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_25)); return A_arbace_a2g_dyn__init_A_const_24.Ref() }








func A_arbace_a2g_dyn__init_A_Unit14__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_26; var tmp2 any = A_arbace_a2g_dyn_box_arg_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_box_arg_A_Init(); tmp3 = A_arbace_a2g_dyn_box_arg_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_27)); return A_arbace_a2g_dyn__init_A_const_26.Ref() }






func A_arbace_a2g_dyn__init_A_Unit15__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(92, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_28; var tmp2 any = A_arbace_a2g_dyn_convert_result_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_convert_result_A_Init(); tmp3 = A_arbace_a2g_dyn_convert_result_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_29)); return A_arbace_a2g_dyn__init_A_const_28.Ref() }















func A_arbace_a2g_dyn__init_A_Unit16__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(108, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_30; var tmp2 any = A_arbace_a2g_dyn_call_impl_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_call_impl_A_Init(); tmp3 = A_arbace_a2g_dyn_call_impl_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_31)); return A_arbace_a2g_dyn__init_A_const_30.Ref() }










func A_arbace_a2g_dyn__init_A_Unit17__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(119, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_32; var tmp2 any = A_arbace_a2g_dyn_java_type_name_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_java_type_name_A_Init(); tmp3 = A_arbace_a2g_dyn_java_type_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_33)); return A_arbace_a2g_dyn__init_A_const_32.Ref() }







func A_arbace_a2g_dyn__init_A_Unit18__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(127, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_34; var tmp2 any = A_arbace_a2g_dyn_abstract_text_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_abstract_text_A_Init(); tmp3 = A_arbace_a2g_dyn_abstract_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_35)); return A_arbace_a2g_dyn__init_A_const_34.Ref() }










func A_arbace_a2g_dyn__init_A_Unit19__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(138, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_36; var tmp2 any = A_arbace_a2g_dyn_iface_fallback_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_iface_fallback_A_Init(); tmp3 = A_arbace_a2g_dyn_iface_fallback_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_37)); return A_arbace_a2g_dyn__init_A_const_36.Ref() }












func A_arbace_a2g_dyn__init_A_Unit20__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(151, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_38; var tmp2 any = A_arbace_a2g_dyn_method_form_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_method_form_A_Init(); tmp3 = A_arbace_a2g_dyn_method_form_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_39)); return A_arbace_a2g_dyn__init_A_const_38.Ref() }




















func A_arbace_a2g_dyn__init_A_Unit21__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(172, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_40; var tmp2 any = A_arbace_a2g_dyn_native_name_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_native_name_A_Init(); tmp3 = A_arbace_a2g_dyn_native_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_40; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_41)); return A_arbace_a2g_dyn__init_A_const_40.Ref() }





func A_arbace_a2g_dyn__init_A_Unit22__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(178, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_42; jrt.NN(tmp1).BindRoot_O__V(jrt.NN(A_arbace_a2g_dyn__init_A_const_43).GetRawRoot__O()); var tmp2 *lang.Var = A_arbace_a2g_dyn__init_A_const_42; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_44)); return A_arbace_a2g_dyn__init_A_const_42.Ref() }







func A_arbace_a2g_dyn__init_A_Unit23__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(186, 1); jrt.NN(A_arbace_a2g_dyn__init_A_const_45).BindRoot_O__V(A_arbace_a2g_dyn__init_A_const_46); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_45; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_47)); return A_arbace_a2g_dyn__init_A_const_45.Ref() }







func A_arbace_a2g_dyn__init_A_Unit24__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(194, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_48; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_a2g_dyn__init_A_const_49).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(jrt.NN(A_arbace_a2g_dyn__init_A_const_51).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(jrt.NN(A_arbace_a2g_dyn__init_A_const_52).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_a2g_dyn__init_A_const_42).GetRawRoot__O(), jrt.NN(A_arbace_a2g_dyn__init_A_const_45).GetRawRoot__O())))); var tmp2 *lang.Var = A_arbace_a2g_dyn__init_A_const_48; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_50)); return A_arbace_a2g_dyn__init_A_const_48.Ref() }



func A_arbace_a2g_dyn__init_A_Unit25__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_53; var tmp2 any = A_arbace_a2g_dyn_proxy_classes_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_proxy_classes_A_Init(); tmp3 = A_arbace_a2g_dyn_proxy_classes_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_53; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_54)); return A_arbace_a2g_dyn__init_A_const_53.Ref() }







func A_arbace_a2g_dyn__init_A_Unit26__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(206, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_55; var tmp2 any = A_arbace_a2g_dyn_sub_name_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_sub_name_A_Init(); tmp3 = A_arbace_a2g_dyn_sub_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_55; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_56)); return A_arbace_a2g_dyn__init_A_const_55.Ref() }

func A_arbace_a2g_dyn__init_A_Unit27__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(208, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_57; var tmp2 any = A_arbace_a2g_dyn_proxy_roots_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_proxy_roots_A_Init(); tmp3 = A_arbace_a2g_dyn_proxy_roots_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_57; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_58)); return A_arbace_a2g_dyn__init_A_const_57.Ref() }













func A_arbace_a2g_dyn__init_A_Unit28__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(222, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_59; var tmp2 any = A_arbace_a2g_dyn_object_fallback_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_object_fallback_A_Init(); tmp3 = A_arbace_a2g_dyn_object_fallback_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_59; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_60)); return A_arbace_a2g_dyn__init_A_const_59.Ref() }












func A_arbace_a2g_dyn__init_A_Unit29__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(235, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_61; var tmp2 any = A_arbace_a2g_dyn_class_fallback_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_class_fallback_A_Init(); tmp3 = A_arbace_a2g_dyn_class_fallback_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_61; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_62)); return A_arbace_a2g_dyn__init_A_const_61.Ref() }















func A_arbace_a2g_dyn__init_A_Unit30__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(251, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_63; var tmp2 any = A_arbace_a2g_dyn_ctor_infos_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_ctor_infos_A_Init(); tmp3 = A_arbace_a2g_dyn_ctor_infos_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_63; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_64)); return A_arbace_a2g_dyn__init_A_const_63.Ref() }
































func A_arbace_a2g_dyn__init_A_Unit31__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(284, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_65; var tmp2 any = A_arbace_a2g_dyn_go_method_names_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_go_method_names_A_Init(); tmp3 = A_arbace_a2g_dyn_go_method_names_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_65; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_66)); return A_arbace_a2g_dyn__init_A_const_65.Ref() }

















func A_arbace_a2g_dyn__init_A_Unit32__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(302, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_67; var tmp2 any = A_arbace_a2g_dyn_sub_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_sub_forms_A_Init(); tmp3 = A_arbace_a2g_dyn_sub_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_67; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_68)); return A_arbace_a2g_dyn__init_A_const_67.Ref() }










































func A_arbace_a2g_dyn__init_A_Unit33__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(345, 1); jrt.NN(A_arbace_a2g_dyn__init_A_const_69).BindRoot_O__V(A_arbace_a2g_dyn__init_A_const_70); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_69; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_71)); return A_arbace_a2g_dyn__init_A_const_69.Ref() }













func A_arbace_a2g_dyn__init_A_Unit34__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(359, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_72; var tmp2 any = A_arbace_a2g_dyn_fn_field_native_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_fn_field_native_A_Init(); tmp3 = A_arbace_a2g_dyn_fn_field_native_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_72; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_73)); return A_arbace_a2g_dyn__init_A_const_72.Ref() }














func A_arbace_a2g_dyn__init_A_Unit35__O() any { A_arbace_a2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V(374, 1); var tmp1 *lang.Var = A_arbace_a2g_dyn__init_A_const_74; var tmp2 any = A_arbace_a2g_dyn_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_dyn_forms_A_Init(); tmp3 = A_arbace_a2g_dyn_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_dyn__init_A_const_74; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_dyn__init_A_const_75)); return A_arbace_a2g_dyn__init_A_const_74.Ref() }



type A_arbace_a2g_dyn__init_A struct{ jrt.Object }

var A_arbace_a2g_dyn__init_A_const_0 *lang.Var

var A_arbace_a2g_dyn__init_A_const_1 any

var A_arbace_a2g_dyn__init_A_const_2 any

var A_arbace_a2g_dyn__init_A_const_3 any

var A_arbace_a2g_dyn__init_A_const_4 *lang.Var

var A_arbace_a2g_dyn__init_A_const_5 any

var A_arbace_a2g_dyn__init_A_const_6 *lang.Var

var A_arbace_a2g_dyn__init_A_const_7 any

var A_arbace_a2g_dyn__init_A_const_8 *lang.Var

var A_arbace_a2g_dyn__init_A_const_9 any

var A_arbace_a2g_dyn__init_A_const_10 any

var A_arbace_a2g_dyn__init_A_const_11 *lang.Var

var A_arbace_a2g_dyn__init_A_const_12 any

var A_arbace_a2g_dyn__init_A_const_13 any

var A_arbace_a2g_dyn__init_A_const_14 *lang.Var

var A_arbace_a2g_dyn__init_A_const_15 any

var A_arbace_a2g_dyn__init_A_const_16 *lang.Var

var A_arbace_a2g_dyn__init_A_const_17 any

var A_arbace_a2g_dyn__init_A_const_18 *lang.Var

var A_arbace_a2g_dyn__init_A_const_19 any

var A_arbace_a2g_dyn__init_A_const_20 *lang.Var

var A_arbace_a2g_dyn__init_A_const_21 any

var A_arbace_a2g_dyn__init_A_const_22 *lang.Var

var A_arbace_a2g_dyn__init_A_const_23 any

var A_arbace_a2g_dyn__init_A_const_24 *lang.Var

var A_arbace_a2g_dyn__init_A_const_25 any

var A_arbace_a2g_dyn__init_A_const_26 *lang.Var

var A_arbace_a2g_dyn__init_A_const_27 any

var A_arbace_a2g_dyn__init_A_const_28 *lang.Var

var A_arbace_a2g_dyn__init_A_const_29 any

var A_arbace_a2g_dyn__init_A_const_30 *lang.Var

var A_arbace_a2g_dyn__init_A_const_31 any

var A_arbace_a2g_dyn__init_A_const_32 *lang.Var

var A_arbace_a2g_dyn__init_A_const_33 any

var A_arbace_a2g_dyn__init_A_const_34 *lang.Var

var A_arbace_a2g_dyn__init_A_const_35 any

var A_arbace_a2g_dyn__init_A_const_36 *lang.Var

var A_arbace_a2g_dyn__init_A_const_37 any

var A_arbace_a2g_dyn__init_A_const_38 *lang.Var

var A_arbace_a2g_dyn__init_A_const_39 any

var A_arbace_a2g_dyn__init_A_const_40 *lang.Var

var A_arbace_a2g_dyn__init_A_const_41 any

var A_arbace_a2g_dyn__init_A_const_42 *lang.Var

var A_arbace_a2g_dyn__init_A_const_43 *lang.Var

var A_arbace_a2g_dyn__init_A_const_44 any

var A_arbace_a2g_dyn__init_A_const_45 *lang.Var

var A_arbace_a2g_dyn__init_A_const_46 any

var A_arbace_a2g_dyn__init_A_const_47 any

var A_arbace_a2g_dyn__init_A_const_48 *lang.Var

var A_arbace_a2g_dyn__init_A_const_49 *lang.Var

var A_arbace_a2g_dyn__init_A_const_50 any

var A_arbace_a2g_dyn__init_A_const_51 *lang.Var

var A_arbace_a2g_dyn__init_A_const_52 *lang.Var

var A_arbace_a2g_dyn__init_A_const_53 *lang.Var

var A_arbace_a2g_dyn__init_A_const_54 any

var A_arbace_a2g_dyn__init_A_const_55 *lang.Var

var A_arbace_a2g_dyn__init_A_const_56 any

var A_arbace_a2g_dyn__init_A_const_57 *lang.Var

var A_arbace_a2g_dyn__init_A_const_58 any

var A_arbace_a2g_dyn__init_A_const_59 *lang.Var

var A_arbace_a2g_dyn__init_A_const_60 any

var A_arbace_a2g_dyn__init_A_const_61 *lang.Var

var A_arbace_a2g_dyn__init_A_const_62 any

var A_arbace_a2g_dyn__init_A_const_63 *lang.Var

var A_arbace_a2g_dyn__init_A_const_64 any

var A_arbace_a2g_dyn__init_A_const_65 *lang.Var

var A_arbace_a2g_dyn__init_A_const_66 any

var A_arbace_a2g_dyn__init_A_const_67 *lang.Var

var A_arbace_a2g_dyn__init_A_const_68 any

var A_arbace_a2g_dyn__init_A_const_69 *lang.Var

var A_arbace_a2g_dyn__init_A_const_70 any

var A_arbace_a2g_dyn__init_A_const_71 any

var A_arbace_a2g_dyn__init_A_const_72 *lang.Var

var A_arbace_a2g_dyn__init_A_const_73 any

var A_arbace_a2g_dyn__init_A_const_74 *lang.Var

var A_arbace_a2g_dyn__init_A_const_75 any

var A_arbace_a2g_dyn__init_A_init jrt.ClassInit

func A_arbace_a2g_dyn__init_A_Init() { if !A_arbace_a2g_dyn__init_A_init.Done() { A_arbace_a2g_dyn__init_A_init.Run(A_arbace_a2g_dyn__init_A_clinit) } }

func A_arbace_a2g_dyn__init_A_clinit() { A_arbace_a2g_dyn__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_588); A_arbace_a2g_dyn__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_23)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_25))); A_arbace_a2g_dyn__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_25)); A_arbace_a2g_dyn__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_dyn__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_23, Lit_42); A_arbace_a2g_dyn__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(23).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_23, Lit_28); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_a2g_dyn__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_593).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_203).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(25).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_23, Lit_69); A_arbace_a2g_dyn__init_A_const_9 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(Lit_540, Lit_594), lang.Tuple_Create_O_O__IPersistentVector(Lit_539, Lit_595), lang.Tuple_Create_O_O__IPersistentVector(Lit_541, Lit_596)); A_arbace_a2g_dyn__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(27).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_597)); A_arbace_a2g_dyn__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_23, Lit_40); A_arbace_a2g_dyn__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.ConstRefArray("[0,12,s1:Is7:intCasts1:Js8:longCasts1:Ds10:doubleCasts1:Fs9:floatCasts1:Ss9:shortCasts1:Bs8:byteCast", []*jrt.Class{jrt.Object_class})); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_a2g_dyn__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(31).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_598)); A_arbace_a2g_dyn__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_23, Lit_599); A_arbace_a2g_dyn__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_600, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(36).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_23, Lit_601); A_arbace_a2g_dyn__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_602, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_23, Lit_49); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_a2g_dyn__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_603).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(47).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_23, Lit_240); A_arbace_a2g_dyn__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_271).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_604, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(49).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_23, Lit_241); A_arbace_a2g_dyn__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_605).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_606, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(70).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_23, Lit_127); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_a2g_dyn__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_605).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_218).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_607, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(76).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_23, Lit_133); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_a2g_dyn__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_272).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_608, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(85).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_23, Lit_143); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_a2g_dyn__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_141).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_609, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(92).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_23, Lit_109); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_a2g_dyn__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_336).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_610, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(108).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_23, Lit_110); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_a2g_dyn__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_289).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_611, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(119).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_23, Lit_130); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_a2g_dyn__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_605).Ref(), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_114).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_218).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_612, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(127).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_23, Lit_131); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_a2g_dyn__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_605).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_218).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_613).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_141).Ref()), lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_605).Ref(), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_114).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_218).Ref()), lang.Symbol_Intern_String_String__Symbol(nil, Lit_613).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_141).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_614).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_615, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(138).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_23, Lit_144); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_a2g_dyn__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_605).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_219).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_218).Ref()), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_616).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_219).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_218).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_617).Ref()), lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_616).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_219).Ref(), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_114).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_218).Ref()), lang.Symbol_Intern_String_String__Symbol(nil, Lit_617).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_336).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_618, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(151).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_23, Lit_238); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_a2g_dyn__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_619).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(172).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_23, Lit_620); A_arbace_a2g_dyn__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_10, Lit_620); A_arbace_a2g_dyn__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(178).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_621)); A_arbace_a2g_dyn__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_23, Lit_622); A_arbace_a2g_dyn__init_A_const_46 = lang.RT_Vector_O1__IPersistentVector(jrt.ConstRefArray("[0,9,s19:java/lang/Throwables19:java/lang/Exceptions26:java/lang/RuntimeExceptions15:java/lang/Errors34:java/lang/IllegalArgumentExceptions31:java/lang/IllegalStateExceptions14:java/lang/Enums16:java/lang/Records15:arbace/lang/AFn", []*jrt.Class{jrt.Object_class})); A_arbace_a2g_dyn__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(186).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_623)); A_arbace_a2g_dyn__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_23, Lit_149); A_arbace_a2g_dyn__init_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_66); A_arbace_a2g_dyn__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(194).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_624)); A_arbace_a2g_dyn__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_62); A_arbace_a2g_dyn__init_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_a2g_dyn__init_A_const_53 = lang.RT_Var_String_String__Var(Lit_23, Lit_397); A_arbace_a2g_dyn__init_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_271).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_625, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(198).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_55 = lang.RT_Var_String_String__Var(Lit_23, Lit_160); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_a2g_dyn__init_A_const_56 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_603).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(206).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_57 = lang.RT_Var_String_String__Var(Lit_23, Lit_626); A_arbace_a2g_dyn__init_A_const_58 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_627, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(208).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_59 = lang.RT_Var_String_String__Var(Lit_23, Lit_199); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_a2g_dyn__init_A_const_60 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_603).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_218).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_613).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_628, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(222).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_61 = lang.RT_Var_String_String__Var(Lit_23, Lit_215); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_a2g_dyn__init_A_const_62 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_603).Ref(), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_114).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_218).Ref()), lang.Symbol_Intern_String_String__Symbol(nil, Lit_613).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_141).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_629, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(235).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_63 = lang.RT_Var_String_String__Var(Lit_23, Lit_216); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_a2g_dyn__init_A_const_64 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_603).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_630, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(251).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_65 = lang.RT_Var_String_String__Var(Lit_23, Lit_197); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_a2g_dyn__init_A_const_66 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_603).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_631, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(284).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_67 = lang.RT_Var_String_String__Var(Lit_23, Lit_408); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp53.Ref(); A_arbace_a2g_dyn__init_A_const_68 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_603).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_605).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_632).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_633, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(302).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_69 = lang.RT_Var_String_String__Var(Lit_23, Lit_332); A_arbace_a2g_dyn__init_A_const_70 = lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_134, Lit_166).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_340).Ref(), Lit_634, lang.IObj_Cast(lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_335)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_250).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_336)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_184).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_167).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_184).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(352).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(39).Ref())))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_184).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_347).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_339).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(353).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(14).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_349).Ref(), lang.Tuple_Create_O__IPersistentVector(jrt.Long_ValueOf_J__Long(0).Ref()), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_293).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_335).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_336).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(354).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(26).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(354).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(18).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(354).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(8).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_349).Ref(), lang.Tuple_Create_O__IPersistentVector(jrt.Long_ValueOf_J__Long(1).Ref()), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_299).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_335).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_336).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_17, Lit_83).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_137).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref(), jrt.Long_ValueOf_J__Long(0).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(355).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(61).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(355).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(52).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(355).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(26).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(355).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(18).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(355).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(8).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_349).Ref(), lang.Tuple_Create_O__IPersistentVector(jrt.Long_ValueOf_J__Long(2).Ref()), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_635).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_335).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_336).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_17, Lit_83).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_137).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref(), jrt.Long_ValueOf_J__Long(0).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(356).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(63).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(356).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(54).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_17, Lit_83).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_137).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref(), jrt.Long_ValueOf_J__Long(1).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(356).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(87).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(356).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(78).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(356).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(26).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(356).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(18).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(356).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(8).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(353).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(6).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_636).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_335).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_336).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_17, Lit_83).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_137).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref(), jrt.Long_ValueOf_J__Long(0).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(357).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(45).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(357).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(36).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_17, Lit_83).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_137).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref(), jrt.Long_ValueOf_J__Long(1).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(357).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(69).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(357).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(60).Ref()))), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_17, Lit_83).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_137).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref(), jrt.Long_ValueOf_J__Long(2).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(357).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(93).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(357).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(84).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(357).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(6).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(349).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(4).Ref()))); var tmp55 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_TRUE; var tmp57 any = tmp56.Ref(); A_arbace_a2g_dyn__init_A_const_71 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp55, tmp57, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(345).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_637)); A_arbace_a2g_dyn__init_A_const_72 = lang.RT_Var_String_String__Var(Lit_23, Lit_311); var tmp58 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_591).Ref(); var tmp59 *jrt.Boolean; jrt.Boolean_Init(); tmp59 = jrt.Boolean_TRUE; var tmp60 any = tmp59.Ref(); A_arbace_a2g_dyn__init_A_const_73 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp58, tmp60, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_638, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(359).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)); A_arbace_a2g_dyn__init_A_const_74 = lang.RT_Var_String_String__Var(Lit_23, Lit_639); A_arbace_a2g_dyn__init_A_const_75 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_592).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_271).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_640, lang.RT_Keyword_String_String__Keyword(nil, Lit_121).Ref(), jrt.Integer_ValueOf_I__Integer(374).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_122).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_589).Ref(), Lit_590)) }

func A_arbace_a2g_dyn__init_A_New() *A_arbace_a2g_dyn__init_A { A_arbace_a2g_dyn__init_A_Init(); t := &A_arbace_a2g_dyn__init_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_dyn__init_A) Ctor() {}

func (t *A_arbace_a2g_dyn__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_dyn__init_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_dyn__init_A_class }

func (t *A_arbace_a2g_dyn__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_dyn__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_dyn__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_dyn__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_dyn__init_A); return ok }

func A_arbace_a2g_dyn__init_A_Cast(x any) *A_arbace_a2g_dyn__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_dyn__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_dyn__init_A_class)) }; return v }
