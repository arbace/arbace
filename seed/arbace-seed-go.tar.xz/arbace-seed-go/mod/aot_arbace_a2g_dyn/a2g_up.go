//line a2g_up.ae:1
package aot_arbace_a2g_dyn

import "arbace/lang"


func Up_Namespace_AReference(p *lang.Namespace) lang.AReference_I { if p == nil { return nil }; return p }
