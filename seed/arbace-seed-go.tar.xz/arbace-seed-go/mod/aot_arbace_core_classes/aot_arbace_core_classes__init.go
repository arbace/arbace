//line aot_arbace_core_classes__init.ae:1
package aot_arbace_core_classes

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_classes__init_A_Load__O() any { A_arbace_core_classes__init_A_Init(); A_arbace_core_classes__init_A_Unit0__O(); A_arbace_core_classes__init_A_Unit1__O(); A_arbace_core_classes__init_A_Unit2__O(); A_arbace_core_classes__init_A_Unit3__O(); A_arbace_core_classes__init_A_Unit4__O(); A_arbace_core_classes__init_A_Unit5__O(); A_arbace_core_classes__init_A_Unit6__O(); A_arbace_core_classes__init_A_Unit7__O(); A_arbace_core_classes__init_A_Unit8__O(); A_arbace_core_classes__init_A_Unit9__O(); A_arbace_core_classes__init_A_Unit10__O(); A_arbace_core_classes__init_A_Unit11__O(); A_arbace_core_classes__init_A_Unit12__O(); A_arbace_core_classes__init_A_Unit13__O(); A_arbace_core_classes__init_A_Unit14__O(); A_arbace_core_classes__init_A_Unit15__O(); A_arbace_core_classes__init_A_Unit16__O(); A_arbace_core_classes__init_A_Unit17__O(); A_arbace_core_classes__init_A_Unit18__O(); A_arbace_core_classes__init_A_Unit19__O(); A_arbace_core_classes__init_A_Unit20__O(); A_arbace_core_classes__init_A_Unit21__O(); A_arbace_core_classes__init_A_Unit22__O(); A_arbace_core_classes__init_A_Unit23__O(); A_arbace_core_classes__init_A_Unit24__O(); A_arbace_core_classes__init_A_Unit25__O(); A_arbace_core_classes__init_A_Unit26__O(); A_arbace_core_classes__init_A_Unit27__O(); A_arbace_core_classes__init_A_Unit28__O(); A_arbace_core_classes__init_A_Unit29__O(); A_arbace_core_classes__init_A_Unit30__O(); A_arbace_core_classes__init_A_Unit31__O(); A_arbace_core_classes__init_A_Unit32__O(); A_arbace_core_classes__init_A_Unit33__O(); A_arbace_core_classes__init_A_Unit34__O(); A_arbace_core_classes__init_A_Unit35__O(); A_arbace_core_classes__init_A_Unit36__O(); A_arbace_core_classes__init_A_Unit37__O(); A_arbace_core_classes__init_A_Unit38__O(); A_arbace_core_classes__init_A_Unit39__O(); A_arbace_core_classes__init_A_Unit40__O(); A_arbace_core_classes__init_A_Unit41__O(); A_arbace_core_classes__init_A_Unit42__O(); A_arbace_core_classes__init_A_Unit43__O(); A_arbace_core_classes__init_A_Unit44__O(); A_arbace_core_classes__init_A_Unit45__O(); A_arbace_core_classes__init_A_Unit46__O(); A_arbace_core_classes__init_A_Unit47__O(); A_arbace_core_classes__init_A_Unit48__O(); A_arbace_core_classes__init_A_Unit49__O(); A_arbace_core_classes__init_A_Unit50__O(); A_arbace_core_classes__init_A_Unit51__O(); A_arbace_core_classes__init_A_Unit52__O(); A_arbace_core_classes__init_A_Unit53__O(); A_arbace_core_classes__init_A_Unit54__O(); A_arbace_core_classes__init_A_Unit55__O(); A_arbace_core_classes__init_A_Unit56__O(); A_arbace_core_classes__init_A_Unit57__O(); A_arbace_core_classes__init_A_Unit58__O(); A_arbace_core_classes__init_A_Unit59__O(); A_arbace_core_classes__init_A_Unit60__O(); A_arbace_core_classes__init_A_Unit61__O(); A_arbace_core_classes__init_A_Unit62__O(); A_arbace_core_classes__init_A_Unit63__O(); A_arbace_core_classes__init_A_Unit64__O(); A_arbace_core_classes__init_A_Unit65__O(); A_arbace_core_classes__init_A_Unit66__O(); A_arbace_core_classes__init_A_Unit67__O(); A_arbace_core_classes__init_A_Unit68__O(); A_arbace_core_classes__init_A_Unit69__O(); A_arbace_core_classes__init_A_Unit70__O(); A_arbace_core_classes__init_A_Unit71__O(); A_arbace_core_classes__init_A_Unit72__O(); A_arbace_core_classes__init_A_Unit73__O(); A_arbace_core_classes__init_A_Unit74__O(); A_arbace_core_classes__init_A_Unit75__O(); return nil }



func A_arbace_core_classes__init_A_Unit0__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_classes__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_core_classes__init_A_const_1) }




func A_arbace_core_classes__init_A_Unit1__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_2; var tmp2 any = aot_arbace_core.A_arbace_core_defclass_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_defclass_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_defclass_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_2; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_3)); return A_arbace_core_classes__init_A_const_2.Ref() }
//line :14:1
func A_arbace_core_classes__init_A_Unit2__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); jrt.NN(A_arbace_core_classes__init_A_const_2).SetMacro__V(); return nil }
//line :14:1
func A_arbace_core_classes__init_A_Unit3__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); return A_arbace_core_classes__init_A_const_2.Ref() }







func A_arbace_core_classes__init_A_Unit4__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_4; var tmp2 any = aot_arbace_core.A_arbace_core_defclasses_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_defclasses_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_defclasses_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_5)); return A_arbace_core_classes__init_A_const_4.Ref() }
//line :22:1
func A_arbace_core_classes__init_A_Unit5__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); jrt.NN(A_arbace_core_classes__init_A_const_4).SetMacro__V(); return nil }
//line :22:1
func A_arbace_core_classes__init_A_Unit6__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); return A_arbace_core_classes__init_A_const_4.Ref() }









func A_arbace_core_classes__init_A_Unit7__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_6; var tmp2 any = aot_arbace_core.A_arbace_core_anon_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_anon_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_anon_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_7)); return A_arbace_core_classes__init_A_const_6.Ref() }
//line :32:1
func A_arbace_core_classes__init_A_Unit8__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); jrt.NN(A_arbace_core_classes__init_A_const_6).SetMacro__V(); return nil }
//line :32:1
func A_arbace_core_classes__init_A_Unit9__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); return A_arbace_core_classes__init_A_const_6.Ref() }






func A_arbace_core_classes__init_A_Unit10__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_8; var tmp2 any = aot_arbace_core.A_arbace_core_letclass_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_letclass_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_letclass_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_9)); return A_arbace_core_classes__init_A_const_8.Ref() }
//line :39:1
func A_arbace_core_classes__init_A_Unit11__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); jrt.NN(A_arbace_core_classes__init_A_const_8).SetMacro__V(); return nil }
//line :39:1
func A_arbace_core_classes__init_A_Unit12__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); return A_arbace_core_classes__init_A_const_8.Ref() }





func A_arbace_core_classes__init_A_Unit13__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(45, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_10; var tmp2 any = aot_arbace_core.A_arbace_core_defmodule_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_defmodule_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_defmodule_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_11)); return A_arbace_core_classes__init_A_const_10.Ref() }
//line :45:1
func A_arbace_core_classes__init_A_Unit14__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(45, 1); jrt.NN(A_arbace_core_classes__init_A_const_10).SetMacro__V(); return nil }
//line :45:1
func A_arbace_core_classes__init_A_Unit15__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(45, 1); return A_arbace_core_classes__init_A_const_10.Ref() }







func A_arbace_core_classes__init_A_Unit16__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_12; var tmp2 any = aot_arbace_core.A_arbace_core_defpackage_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_defpackage_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_defpackage_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_13)); return A_arbace_core_classes__init_A_const_12.Ref() }
//line :53:1
func A_arbace_core_classes__init_A_Unit17__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); jrt.NN(A_arbace_core_classes__init_A_const_12).SetMacro__V(); return nil }
//line :53:1
func A_arbace_core_classes__init_A_Unit18__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); return A_arbace_core_classes__init_A_const_12.Ref() }










func A_arbace_core_classes__init_A_Unit19__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(64, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_14; var tmp2 any = aot_arbace_core.A_arbace_core_label_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_label_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_label_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_15)); return A_arbace_core_classes__init_A_const_14.Ref() }
//line :64:1
func A_arbace_core_classes__init_A_Unit20__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(64, 1); jrt.NN(A_arbace_core_classes__init_A_const_14).SetMacro__V(); return nil }
//line :64:1
func A_arbace_core_classes__init_A_Unit21__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(64, 1); return A_arbace_core_classes__init_A_const_14.Ref() }

func A_arbace_core_classes__init_A_Unit22__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_16; var tmp2 any = aot_arbace_core.A_arbace_core_break_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_break_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_break_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_17)); return A_arbace_core_classes__init_A_const_16.Ref() }
//line :66:1
func A_arbace_core_classes__init_A_Unit23__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); jrt.NN(A_arbace_core_classes__init_A_const_16).SetMacro__V(); return nil }
//line :66:1
func A_arbace_core_classes__init_A_Unit24__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); return A_arbace_core_classes__init_A_const_16.Ref() }

func A_arbace_core_classes__init_A_Unit25__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(68, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_18; var tmp2 any = aot_arbace_core.A_arbace_core_continue_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_continue_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_continue_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_19)); return A_arbace_core_classes__init_A_const_18.Ref() }
//line :68:1
func A_arbace_core_classes__init_A_Unit26__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(68, 1); jrt.NN(A_arbace_core_classes__init_A_const_18).SetMacro__V(); return nil }
//line :68:1
func A_arbace_core_classes__init_A_Unit27__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(68, 1); return A_arbace_core_classes__init_A_const_18.Ref() }

func A_arbace_core_classes__init_A_Unit28__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_20; var tmp2 any = aot_arbace_core.A_arbace_core_return_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_return_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_return_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_21)); return A_arbace_core_classes__init_A_const_20.Ref() }
//line :70:1
func A_arbace_core_classes__init_A_Unit29__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); jrt.NN(A_arbace_core_classes__init_A_const_20).SetMacro__V(); return nil }
//line :70:1
func A_arbace_core_classes__init_A_Unit30__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); return A_arbace_core_classes__init_A_const_20.Ref() }

func A_arbace_core_classes__init_A_Unit31__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_22; var tmp2 any = aot_arbace_core.A_arbace_core_switch_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_switch_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_switch_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_23)); return A_arbace_core_classes__init_A_const_22.Ref() }
//line :72:1
func A_arbace_core_classes__init_A_Unit32__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); jrt.NN(A_arbace_core_classes__init_A_const_22).SetMacro__V(); return nil }
//line :72:1
func A_arbace_core_classes__init_A_Unit33__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); return A_arbace_core_classes__init_A_const_22.Ref() }

func A_arbace_core_classes__init_A_Unit34__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_24; var tmp2 any = aot_arbace_core.A_arbace_core_lambda_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_lambda_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_lambda_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_25)); return A_arbace_core_classes__init_A_const_24.Ref() }
//line :74:1
func A_arbace_core_classes__init_A_Unit35__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); jrt.NN(A_arbace_core_classes__init_A_const_24).SetMacro__V(); return nil }
//line :74:1
func A_arbace_core_classes__init_A_Unit36__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); return A_arbace_core_classes__init_A_const_24.Ref() }

func A_arbace_core_classes__init_A_Unit37__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(76, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_26; var tmp2 any = aot_arbace_core.A_arbace_core_method_ref_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_method_ref_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_method_ref_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_27)); return A_arbace_core_classes__init_A_const_26.Ref() }
//line :76:1
func A_arbace_core_classes__init_A_Unit38__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(76, 1); jrt.NN(A_arbace_core_classes__init_A_const_26).SetMacro__V(); return nil }
//line :76:1
func A_arbace_core_classes__init_A_Unit39__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(76, 1); return A_arbace_core_classes__init_A_const_26.Ref() }

func A_arbace_core_classes__init_A_Unit40__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(78, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_28; var tmp2 any = aot_arbace_core.A_arbace_core_java_str_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_java_str_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_java_str_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_29)); return A_arbace_core_classes__init_A_const_28.Ref() }
//line :78:1
func A_arbace_core_classes__init_A_Unit41__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(78, 1); jrt.NN(A_arbace_core_classes__init_A_const_28).SetMacro__V(); return nil }
//line :78:1
func A_arbace_core_classes__init_A_Unit42__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(78, 1); return A_arbace_core_classes__init_A_const_28.Ref() }

func A_arbace_core_classes__init_A_Unit43__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_30; var tmp2 any = aot_arbace_core.A_arbace_core_java_assert_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_java_assert_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_java_assert_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_31)); return A_arbace_core_classes__init_A_const_30.Ref() }
//line :80:1
func A_arbace_core_classes__init_A_Unit44__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); jrt.NN(A_arbace_core_classes__init_A_const_30).SetMacro__V(); return nil }
//line :80:1
func A_arbace_core_classes__init_A_Unit45__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); return A_arbace_core_classes__init_A_const_30.Ref() }

func A_arbace_core_classes__init_A_Unit46__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_32; var tmp2 any = aot_arbace_core.A_arbace_core_for_each_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_for_each_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_for_each_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_33)); return A_arbace_core_classes__init_A_const_32.Ref() }
//line :82:1
func A_arbace_core_classes__init_A_Unit47__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); jrt.NN(A_arbace_core_classes__init_A_const_32).SetMacro__V(); return nil }
//line :82:1
func A_arbace_core_classes__init_A_Unit48__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); return A_arbace_core_classes__init_A_const_32.Ref() }


func A_arbace_core_classes__init_A_Unit49__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_34; var tmp2 any = aot_arbace_core.A_arbace_core_with_resources_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_with_resources_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_with_resources_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_35)); return A_arbace_core_classes__init_A_const_34.Ref() }
//line :85:1
func A_arbace_core_classes__init_A_Unit50__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); jrt.NN(A_arbace_core_classes__init_A_const_34).SetMacro__V(); return nil }
//line :85:1
func A_arbace_core_classes__init_A_Unit51__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); return A_arbace_core_classes__init_A_const_34.Ref() }





func A_arbace_core_classes__init_A_Unit52__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(91, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_36; var tmp2 any = aot_arbace_core.A_arbace_core_if_instance_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_if_instance_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_if_instance_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_37)); return A_arbace_core_classes__init_A_const_36.Ref() }
//line :91:1
func A_arbace_core_classes__init_A_Unit53__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(91, 1); jrt.NN(A_arbace_core_classes__init_A_const_36).SetMacro__V(); return nil }
//line :91:1
func A_arbace_core_classes__init_A_Unit54__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(91, 1); return A_arbace_core_classes__init_A_const_36.Ref() }





func A_arbace_core_classes__init_A_Unit55__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_38; var tmp2 any = aot_arbace_core.A_arbace_core_when_instance_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_when_instance_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_when_instance_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_39)); return A_arbace_core_classes__init_A_const_38.Ref() }
//line :97:1
func A_arbace_core_classes__init_A_Unit56__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); jrt.NN(A_arbace_core_classes__init_A_const_38).SetMacro__V(); return nil }
//line :97:1
func A_arbace_core_classes__init_A_Unit57__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); return A_arbace_core_classes__init_A_const_38.Ref() }










func A_arbace_core_classes__init_A_Unit58__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(108, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_40; var tmp2 any = aot_arbace_core.A_arbace_core_defop_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_defop_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_defop_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_40; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_41)); return A_arbace_core_classes__init_A_const_40.Ref() }
//line :108:1
func A_arbace_core_classes__init_A_Unit59__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(108, 1); jrt.NN(A_arbace_core_classes__init_A_const_40).SetMacro__V(); return nil }
//line :108:1
func A_arbace_core_classes__init_A_Unit60__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(108, 1); return A_arbace_core_classes__init_A_const_40.Ref() }








func A_arbace_core_classes__init_A_Unit61__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(117, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_42; var tmp2 any = aot_arbace_core.A_arbace_core_bit_and_int_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_bit_and_int_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_bit_and_int_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_42; var tmp5 any = A_arbace_core_classes__init_A_const_43.Ref(); var tmp6 any = A_arbace_core_classes__init_A_const_44; var tmp7 any = A_arbace_core_classes__init_A_const_45.Ref(); var tmp8 any = A_arbace_core_classes__init_A_const_46.Ref(); var tmp9 any = A_arbace_core_classes__init_A_const_47.Ref(); var tmp10 any = A_arbace_core_classes__init_A_const_48; var tmp11 any = A_arbace_core_classes__init_A_const_49.Ref(); var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000106_A_New(); var tmp13 *jrt.Class; aot_arbace_core.A_arbace_core_fn__1056000106_A_Init(); tmp13 = aot_arbace_core.A_arbace_core_fn__1056000106_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_84, tmp8, Lit_9, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50.Ref(), A_arbace_core_classes__init_A_const_51, A_arbace_core_classes__init_A_const_52.Ref(), A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54.Ref(), Lit_13))); return A_arbace_core_classes__init_A_const_42.Ref() }
func A_arbace_core_classes__init_A_Unit62__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(118, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_55; var tmp2 any = aot_arbace_core.A_arbace_core_bit_or_int_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_bit_or_int_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_bit_or_int_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_55; var tmp5 any = A_arbace_core_classes__init_A_const_43.Ref(); var tmp6 any = A_arbace_core_classes__init_A_const_56; var tmp7 any = A_arbace_core_classes__init_A_const_45.Ref(); var tmp8 any = A_arbace_core_classes__init_A_const_46.Ref(); var tmp9 any = A_arbace_core_classes__init_A_const_47.Ref(); var tmp10 any = A_arbace_core_classes__init_A_const_57; var tmp11 any = A_arbace_core_classes__init_A_const_49.Ref(); var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000109_A_New(); var tmp13 *jrt.Class; aot_arbace_core.A_arbace_core_fn__1056000109_A_Init(); tmp13 = aot_arbace_core.A_arbace_core_fn__1056000109_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_85, tmp8, Lit_9, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50.Ref(), A_arbace_core_classes__init_A_const_58, A_arbace_core_classes__init_A_const_52.Ref(), A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54.Ref(), Lit_13))); return A_arbace_core_classes__init_A_const_55.Ref() }
func A_arbace_core_classes__init_A_Unit63__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(119, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_59; var tmp2 any = aot_arbace_core.A_arbace_core_bit_xor_int_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_bit_xor_int_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_bit_xor_int_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_59; var tmp5 any = A_arbace_core_classes__init_A_const_43.Ref(); var tmp6 any = A_arbace_core_classes__init_A_const_60; var tmp7 any = A_arbace_core_classes__init_A_const_45.Ref(); var tmp8 any = A_arbace_core_classes__init_A_const_46.Ref(); var tmp9 any = A_arbace_core_classes__init_A_const_47.Ref(); var tmp10 any = A_arbace_core_classes__init_A_const_61; var tmp11 any = A_arbace_core_classes__init_A_const_49.Ref(); var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000112_A_New(); var tmp13 *jrt.Class; aot_arbace_core.A_arbace_core_fn__1056000112_A_Init(); tmp13 = aot_arbace_core.A_arbace_core_fn__1056000112_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_86, tmp8, Lit_9, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50.Ref(), A_arbace_core_classes__init_A_const_62, A_arbace_core_classes__init_A_const_52.Ref(), A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54.Ref(), Lit_13))); return A_arbace_core_classes__init_A_const_59.Ref() }
func A_arbace_core_classes__init_A_Unit64__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(120, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_63; var tmp2 any = aot_arbace_core.A_arbace_core_bit_not_int_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_bit_not_int_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_bit_not_int_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_63; var tmp5 any = A_arbace_core_classes__init_A_const_43.Ref(); var tmp6 any = A_arbace_core_classes__init_A_const_64; var tmp7 any = A_arbace_core_classes__init_A_const_45.Ref(); var tmp8 any = A_arbace_core_classes__init_A_const_46.Ref(); var tmp9 any = A_arbace_core_classes__init_A_const_47.Ref(); var tmp10 any = A_arbace_core_classes__init_A_const_65; var tmp11 any = A_arbace_core_classes__init_A_const_49.Ref(); var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000115_A_New(); var tmp13 *jrt.Class; aot_arbace_core.A_arbace_core_fn__1056000115_A_Init(); tmp13 = aot_arbace_core.A_arbace_core_fn__1056000115_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_87, tmp8, Lit_9, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50.Ref(), A_arbace_core_classes__init_A_const_66, A_arbace_core_classes__init_A_const_52.Ref(), A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54.Ref(), Lit_13))); return A_arbace_core_classes__init_A_const_63.Ref() }
func A_arbace_core_classes__init_A_Unit65__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(121, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_67; var tmp2 any = aot_arbace_core.A_arbace_core_bit_shift_left_int_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_bit_shift_left_int_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_bit_shift_left_int_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_67; var tmp5 any = A_arbace_core_classes__init_A_const_43.Ref(); var tmp6 any = A_arbace_core_classes__init_A_const_68; var tmp7 any = A_arbace_core_classes__init_A_const_45.Ref(); var tmp8 any = A_arbace_core_classes__init_A_const_46.Ref(); var tmp9 any = A_arbace_core_classes__init_A_const_47.Ref(); var tmp10 any = A_arbace_core_classes__init_A_const_69; var tmp11 any = A_arbace_core_classes__init_A_const_49.Ref(); var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000118_A_New(); var tmp13 *jrt.Class; aot_arbace_core.A_arbace_core_fn__1056000118_A_Init(); tmp13 = aot_arbace_core.A_arbace_core_fn__1056000118_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_88, tmp8, Lit_9, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50.Ref(), A_arbace_core_classes__init_A_const_70, A_arbace_core_classes__init_A_const_52.Ref(), A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54.Ref(), Lit_13))); return A_arbace_core_classes__init_A_const_67.Ref() }
func A_arbace_core_classes__init_A_Unit66__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(122, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_71; var tmp2 any = aot_arbace_core.A_arbace_core_bit_shift_right_int_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_bit_shift_right_int_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_bit_shift_right_int_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_71; var tmp5 any = A_arbace_core_classes__init_A_const_43.Ref(); var tmp6 any = A_arbace_core_classes__init_A_const_72; var tmp7 any = A_arbace_core_classes__init_A_const_45.Ref(); var tmp8 any = A_arbace_core_classes__init_A_const_46.Ref(); var tmp9 any = A_arbace_core_classes__init_A_const_47.Ref(); var tmp10 any = A_arbace_core_classes__init_A_const_73; var tmp11 any = A_arbace_core_classes__init_A_const_49.Ref(); var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000121_A_New(); var tmp13 *jrt.Class; aot_arbace_core.A_arbace_core_fn__1056000121_A_Init(); tmp13 = aot_arbace_core.A_arbace_core_fn__1056000121_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_89, tmp8, Lit_9, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50.Ref(), A_arbace_core_classes__init_A_const_74, A_arbace_core_classes__init_A_const_52.Ref(), A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54.Ref(), Lit_13))); return A_arbace_core_classes__init_A_const_71.Ref() }
func A_arbace_core_classes__init_A_Unit67__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(123, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_75; var tmp2 any = aot_arbace_core.A_arbace_core_unsigned_bit_shift_right_int_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_unsigned_bit_shift_right_int_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_unsigned_bit_shift_right_int_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_75; var tmp5 any = A_arbace_core_classes__init_A_const_43.Ref(); var tmp6 any = A_arbace_core_classes__init_A_const_76; var tmp7 any = A_arbace_core_classes__init_A_const_45.Ref(); var tmp8 any = A_arbace_core_classes__init_A_const_46.Ref(); var tmp9 any = A_arbace_core_classes__init_A_const_47.Ref(); var tmp10 any = A_arbace_core_classes__init_A_const_77; var tmp11 any = A_arbace_core_classes__init_A_const_49.Ref(); var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000124_A_New(); var tmp13 *jrt.Class; aot_arbace_core.A_arbace_core_fn__1056000124_A_Init(); tmp13 = aot_arbace_core.A_arbace_core_fn__1056000124_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_90, tmp8, Lit_9, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50.Ref(), A_arbace_core_classes__init_A_const_78, A_arbace_core_classes__init_A_const_52.Ref(), A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54.Ref(), Lit_13))); return A_arbace_core_classes__init_A_const_75.Ref() }


func A_arbace_core_classes__init_A_Unit68__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(126, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_79; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_divide_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_unchecked_divide_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_unchecked_divide_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_79; var tmp5 any = A_arbace_core_classes__init_A_const_43.Ref(); var tmp6 any = A_arbace_core_classes__init_A_const_80; var tmp7 any = A_arbace_core_classes__init_A_const_45.Ref(); var tmp8 any = A_arbace_core_classes__init_A_const_46.Ref(); var tmp9 any = A_arbace_core_classes__init_A_const_47.Ref(); var tmp10 any = A_arbace_core_classes__init_A_const_81; var tmp11 any = A_arbace_core_classes__init_A_const_49.Ref(); var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000127_A_New(); var tmp13 *jrt.Class; aot_arbace_core.A_arbace_core_fn__1056000127_A_Init(); tmp13 = aot_arbace_core.A_arbace_core_fn__1056000127_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_91, tmp8, Lit_9, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50.Ref(), A_arbace_core_classes__init_A_const_82, A_arbace_core_classes__init_A_const_52.Ref(), A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54.Ref(), Lit_13))); return A_arbace_core_classes__init_A_const_79.Ref() }


func A_arbace_core_classes__init_A_Unit69__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(129, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_83; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_remainder_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_unchecked_remainder_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_unchecked_remainder_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_83; var tmp5 any = A_arbace_core_classes__init_A_const_43.Ref(); var tmp6 any = A_arbace_core_classes__init_A_const_84; var tmp7 any = A_arbace_core_classes__init_A_const_45.Ref(); var tmp8 any = A_arbace_core_classes__init_A_const_46.Ref(); var tmp9 any = A_arbace_core_classes__init_A_const_47.Ref(); var tmp10 any = A_arbace_core_classes__init_A_const_85; var tmp11 any = A_arbace_core_classes__init_A_const_49.Ref(); var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000130_A_New(); var tmp13 *jrt.Class; aot_arbace_core.A_arbace_core_fn__1056000130_A_Init(); tmp13 = aot_arbace_core.A_arbace_core_fn__1056000130_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_92, tmp8, Lit_9, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50.Ref(), A_arbace_core_classes__init_A_const_86, A_arbace_core_classes__init_A_const_52.Ref(), A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54.Ref(), Lit_13))); return A_arbace_core_classes__init_A_const_83.Ref() }


func A_arbace_core_classes__init_A_Unit70__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(132, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_87; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_add_float_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_unchecked_add_float_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_unchecked_add_float_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_87; var tmp5 any = A_arbace_core_classes__init_A_const_43.Ref(); var tmp6 any = A_arbace_core_classes__init_A_const_88; var tmp7 any = A_arbace_core_classes__init_A_const_45.Ref(); var tmp8 any = A_arbace_core_classes__init_A_const_46.Ref(); var tmp9 any = A_arbace_core_classes__init_A_const_47.Ref(); var tmp10 any = A_arbace_core_classes__init_A_const_89; var tmp11 any = A_arbace_core_classes__init_A_const_49.Ref(); var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000133_A_New(); var tmp13 *jrt.Class; aot_arbace_core.A_arbace_core_fn__1056000133_A_Init(); tmp13 = aot_arbace_core.A_arbace_core_fn__1056000133_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_93, tmp8, Lit_9, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50.Ref(), A_arbace_core_classes__init_A_const_90, A_arbace_core_classes__init_A_const_52.Ref(), A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54.Ref(), Lit_13))); return A_arbace_core_classes__init_A_const_87.Ref() }
func A_arbace_core_classes__init_A_Unit71__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(133, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_91; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_subtract_float_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_unchecked_subtract_float_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_unchecked_subtract_float_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_91; var tmp5 any = A_arbace_core_classes__init_A_const_43.Ref(); var tmp6 any = A_arbace_core_classes__init_A_const_92; var tmp7 any = A_arbace_core_classes__init_A_const_45.Ref(); var tmp8 any = A_arbace_core_classes__init_A_const_46.Ref(); var tmp9 any = A_arbace_core_classes__init_A_const_47.Ref(); var tmp10 any = A_arbace_core_classes__init_A_const_93; var tmp11 any = A_arbace_core_classes__init_A_const_49.Ref(); var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000136_A_New(); var tmp13 *jrt.Class; aot_arbace_core.A_arbace_core_fn__1056000136_A_Init(); tmp13 = aot_arbace_core.A_arbace_core_fn__1056000136_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_94, tmp8, Lit_9, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50.Ref(), A_arbace_core_classes__init_A_const_94, A_arbace_core_classes__init_A_const_52.Ref(), A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54.Ref(), Lit_13))); return A_arbace_core_classes__init_A_const_91.Ref() }
func A_arbace_core_classes__init_A_Unit72__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(134, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_95; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_multiply_float_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_unchecked_multiply_float_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_unchecked_multiply_float_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_95; var tmp5 any = A_arbace_core_classes__init_A_const_43.Ref(); var tmp6 any = A_arbace_core_classes__init_A_const_96; var tmp7 any = A_arbace_core_classes__init_A_const_45.Ref(); var tmp8 any = A_arbace_core_classes__init_A_const_46.Ref(); var tmp9 any = A_arbace_core_classes__init_A_const_47.Ref(); var tmp10 any = A_arbace_core_classes__init_A_const_97; var tmp11 any = A_arbace_core_classes__init_A_const_49.Ref(); var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000139_A_New(); var tmp13 *jrt.Class; aot_arbace_core.A_arbace_core_fn__1056000139_A_Init(); tmp13 = aot_arbace_core.A_arbace_core_fn__1056000139_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_95, tmp8, Lit_9, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50.Ref(), A_arbace_core_classes__init_A_const_98, A_arbace_core_classes__init_A_const_52.Ref(), A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54.Ref(), Lit_13))); return A_arbace_core_classes__init_A_const_95.Ref() }
func A_arbace_core_classes__init_A_Unit73__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(135, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_99; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_divide_float_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_unchecked_divide_float_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_unchecked_divide_float_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_99; var tmp5 any = A_arbace_core_classes__init_A_const_43.Ref(); var tmp6 any = A_arbace_core_classes__init_A_const_100; var tmp7 any = A_arbace_core_classes__init_A_const_45.Ref(); var tmp8 any = A_arbace_core_classes__init_A_const_46.Ref(); var tmp9 any = A_arbace_core_classes__init_A_const_47.Ref(); var tmp10 any = A_arbace_core_classes__init_A_const_101; var tmp11 any = A_arbace_core_classes__init_A_const_49.Ref(); var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000142_A_New(); var tmp13 *jrt.Class; aot_arbace_core.A_arbace_core_fn__1056000142_A_Init(); tmp13 = aot_arbace_core.A_arbace_core_fn__1056000142_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_96, tmp8, Lit_9, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50.Ref(), A_arbace_core_classes__init_A_const_102, A_arbace_core_classes__init_A_const_52.Ref(), A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54.Ref(), Lit_13))); return A_arbace_core_classes__init_A_const_99.Ref() }
func A_arbace_core_classes__init_A_Unit74__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(136, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_103; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_remainder_float_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_unchecked_remainder_float_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_unchecked_remainder_float_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_103; var tmp5 any = A_arbace_core_classes__init_A_const_43.Ref(); var tmp6 any = A_arbace_core_classes__init_A_const_104; var tmp7 any = A_arbace_core_classes__init_A_const_45.Ref(); var tmp8 any = A_arbace_core_classes__init_A_const_46.Ref(); var tmp9 any = A_arbace_core_classes__init_A_const_47.Ref(); var tmp10 any = A_arbace_core_classes__init_A_const_105; var tmp11 any = A_arbace_core_classes__init_A_const_49.Ref(); var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000145_A_New(); var tmp13 *jrt.Class; aot_arbace_core.A_arbace_core_fn__1056000145_A_Init(); tmp13 = aot_arbace_core.A_arbace_core_fn__1056000145_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_97, tmp8, Lit_9, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50.Ref(), A_arbace_core_classes__init_A_const_106, A_arbace_core_classes__init_A_const_52.Ref(), A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54.Ref(), Lit_13))); return A_arbace_core_classes__init_A_const_103.Ref() }
func A_arbace_core_classes__init_A_Unit75__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(137, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_107; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_negate_float_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_unchecked_negate_float_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_unchecked_negate_float_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_107; var tmp5 any = A_arbace_core_classes__init_A_const_43.Ref(); var tmp6 any = A_arbace_core_classes__init_A_const_108; var tmp7 any = A_arbace_core_classes__init_A_const_45.Ref(); var tmp8 any = A_arbace_core_classes__init_A_const_46.Ref(); var tmp9 any = A_arbace_core_classes__init_A_const_47.Ref(); var tmp10 any = A_arbace_core_classes__init_A_const_109; var tmp11 any = A_arbace_core_classes__init_A_const_49.Ref(); var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000148_A_New(); var tmp13 *jrt.Class; aot_arbace_core.A_arbace_core_fn__1056000148_A_Init(); tmp13 = aot_arbace_core.A_arbace_core_fn__1056000148_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_98, tmp8, Lit_9, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50.Ref(), A_arbace_core_classes__init_A_const_110, A_arbace_core_classes__init_A_const_52.Ref(), A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54.Ref(), Lit_13))); return A_arbace_core_classes__init_A_const_107.Ref() }










































type A_arbace_core_classes__init_A struct{ jrt.Object }

var A_arbace_core_classes__init_A_const_0 *lang.Var

var A_arbace_core_classes__init_A_const_1 any

var A_arbace_core_classes__init_A_const_2 *lang.Var

var A_arbace_core_classes__init_A_const_3 any

var A_arbace_core_classes__init_A_const_4 *lang.Var

var A_arbace_core_classes__init_A_const_5 any

var A_arbace_core_classes__init_A_const_6 *lang.Var

var A_arbace_core_classes__init_A_const_7 any

var A_arbace_core_classes__init_A_const_8 *lang.Var

var A_arbace_core_classes__init_A_const_9 any

var A_arbace_core_classes__init_A_const_10 *lang.Var

var A_arbace_core_classes__init_A_const_11 any

var A_arbace_core_classes__init_A_const_12 *lang.Var

var A_arbace_core_classes__init_A_const_13 any

var A_arbace_core_classes__init_A_const_14 *lang.Var

var A_arbace_core_classes__init_A_const_15 any

var A_arbace_core_classes__init_A_const_16 *lang.Var

var A_arbace_core_classes__init_A_const_17 any

var A_arbace_core_classes__init_A_const_18 *lang.Var

var A_arbace_core_classes__init_A_const_19 any

var A_arbace_core_classes__init_A_const_20 *lang.Var

var A_arbace_core_classes__init_A_const_21 any

var A_arbace_core_classes__init_A_const_22 *lang.Var

var A_arbace_core_classes__init_A_const_23 any

var A_arbace_core_classes__init_A_const_24 *lang.Var

var A_arbace_core_classes__init_A_const_25 any

var A_arbace_core_classes__init_A_const_26 *lang.Var

var A_arbace_core_classes__init_A_const_27 any

var A_arbace_core_classes__init_A_const_28 *lang.Var

var A_arbace_core_classes__init_A_const_29 any

var A_arbace_core_classes__init_A_const_30 *lang.Var

var A_arbace_core_classes__init_A_const_31 any

var A_arbace_core_classes__init_A_const_32 *lang.Var

var A_arbace_core_classes__init_A_const_33 any

var A_arbace_core_classes__init_A_const_34 *lang.Var

var A_arbace_core_classes__init_A_const_35 any

var A_arbace_core_classes__init_A_const_36 *lang.Var

var A_arbace_core_classes__init_A_const_37 any

var A_arbace_core_classes__init_A_const_38 *lang.Var

var A_arbace_core_classes__init_A_const_39 any

var A_arbace_core_classes__init_A_const_40 *lang.Var

var A_arbace_core_classes__init_A_const_41 any

var A_arbace_core_classes__init_A_const_42 *lang.Var

var A_arbace_core_classes__init_A_const_43 *lang.Keyword

var A_arbace_core_classes__init_A_const_44 any

var A_arbace_core_classes__init_A_const_45 *lang.Keyword

var A_arbace_core_classes__init_A_const_46 *lang.Keyword

var A_arbace_core_classes__init_A_const_47 *lang.Keyword

var A_arbace_core_classes__init_A_const_48 any

var A_arbace_core_classes__init_A_const_49 *lang.Keyword

var A_arbace_core_classes__init_A_const_50 *lang.Keyword

var A_arbace_core_classes__init_A_const_51 any

var A_arbace_core_classes__init_A_const_52 *lang.Keyword

var A_arbace_core_classes__init_A_const_53 any

var A_arbace_core_classes__init_A_const_54 *lang.Keyword

var A_arbace_core_classes__init_A_const_55 *lang.Var

var A_arbace_core_classes__init_A_const_56 any

var A_arbace_core_classes__init_A_const_57 any

var A_arbace_core_classes__init_A_const_58 any

var A_arbace_core_classes__init_A_const_59 *lang.Var

var A_arbace_core_classes__init_A_const_60 any

var A_arbace_core_classes__init_A_const_61 any

var A_arbace_core_classes__init_A_const_62 any

var A_arbace_core_classes__init_A_const_63 *lang.Var

var A_arbace_core_classes__init_A_const_64 any

var A_arbace_core_classes__init_A_const_65 any

var A_arbace_core_classes__init_A_const_66 any

var A_arbace_core_classes__init_A_const_67 *lang.Var

var A_arbace_core_classes__init_A_const_68 any

var A_arbace_core_classes__init_A_const_69 any

var A_arbace_core_classes__init_A_const_70 any

var A_arbace_core_classes__init_A_const_71 *lang.Var

var A_arbace_core_classes__init_A_const_72 any

var A_arbace_core_classes__init_A_const_73 any

var A_arbace_core_classes__init_A_const_74 any

var A_arbace_core_classes__init_A_const_75 *lang.Var

var A_arbace_core_classes__init_A_const_76 any

var A_arbace_core_classes__init_A_const_77 any

var A_arbace_core_classes__init_A_const_78 any

var A_arbace_core_classes__init_A_const_79 *lang.Var

var A_arbace_core_classes__init_A_const_80 any

var A_arbace_core_classes__init_A_const_81 any

var A_arbace_core_classes__init_A_const_82 any

var A_arbace_core_classes__init_A_const_83 *lang.Var

var A_arbace_core_classes__init_A_const_84 any

var A_arbace_core_classes__init_A_const_85 any

var A_arbace_core_classes__init_A_const_86 any

var A_arbace_core_classes__init_A_const_87 *lang.Var

var A_arbace_core_classes__init_A_const_88 any

var A_arbace_core_classes__init_A_const_89 any

var A_arbace_core_classes__init_A_const_90 any

var A_arbace_core_classes__init_A_const_91 *lang.Var

var A_arbace_core_classes__init_A_const_92 any

var A_arbace_core_classes__init_A_const_93 any

var A_arbace_core_classes__init_A_const_94 any

var A_arbace_core_classes__init_A_const_95 *lang.Var

var A_arbace_core_classes__init_A_const_96 any

var A_arbace_core_classes__init_A_const_97 any

var A_arbace_core_classes__init_A_const_98 any

var A_arbace_core_classes__init_A_const_99 *lang.Var

var A_arbace_core_classes__init_A_const_100 any

var A_arbace_core_classes__init_A_const_101 any

var A_arbace_core_classes__init_A_const_102 any

var A_arbace_core_classes__init_A_const_103 *lang.Var

var A_arbace_core_classes__init_A_const_104 any

var A_arbace_core_classes__init_A_const_105 any

var A_arbace_core_classes__init_A_const_106 any

var A_arbace_core_classes__init_A_const_107 *lang.Var

var A_arbace_core_classes__init_A_const_108 any

var A_arbace_core_classes__init_A_const_109 any

var A_arbace_core_classes__init_A_const_110 any

var A_arbace_core_classes__init_A_init jrt.ClassInit

func A_arbace_core_classes__init_A_Init() { if !A_arbace_core_classes__init_A_init.Done() { A_arbace_core_classes__init_A_init.Run(A_arbace_core_classes__init_A_clinit) } }

func A_arbace_core_classes__init_A_clinit() { A_arbace_core_classes__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_core_classes__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_core_classes__init_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_core_classes__init_A_const_3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(14).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_core_classes__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_15).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_16, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(22).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_core_classes__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_18, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(32).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_core_classes__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_21).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_22, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(39).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_core_classes__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_24, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(45).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_core_classes__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_26).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_27, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_core_classes__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_21).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_30, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(64).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_core_classes__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_33, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(66).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_core_classes__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_35, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(68).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_core_classes__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_37, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(70).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_core_classes__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_39, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(72).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_core_classes__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_41, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(74).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_core_classes__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_43, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(76).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_core_classes__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_45, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(78).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_core_classes__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_47, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(80).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_core_classes__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_49).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_21).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_50, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(82).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_core_classes__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_52).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_21).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_53, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(85).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_core_classes__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_55, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(91).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_core_classes__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_49).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_21).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_57, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(97).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_59).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_core_classes__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_60).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_63, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(108).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_classes__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_core_classes__init_A_const_43 = lang.RT_Keyword_String_String__Keyword(nil, Lit_3); A_arbace_core_classes__init_A_const_44 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref())))); A_arbace_core_classes__init_A_const_45 = lang.RT_Keyword_String_String__Keyword(nil, Lit_6); A_arbace_core_classes__init_A_const_46 = lang.RT_Keyword_String_String__Keyword(nil, Lit_8); A_arbace_core_classes__init_A_const_47 = lang.RT_Keyword_String_String__Keyword(nil, Lit_67); A_arbace_core_classes__init_A_const_48 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(2).Ref())).Ref(); A_arbace_core_classes__init_A_const_49 = lang.RT_Keyword_String_String__Keyword(nil, Lit_68); A_arbace_core_classes__init_A_const_50 = lang.RT_Keyword_String_String__Keyword(nil, Lit_10); A_arbace_core_classes__init_A_const_51 = jrt.Integer_ValueOf_I__Integer(117).Ref(); A_arbace_core_classes__init_A_const_52 = lang.RT_Keyword_String_String__Keyword(nil, Lit_11); A_arbace_core_classes__init_A_const_53 = jrt.Integer_ValueOf_I__Integer(1).Ref(); A_arbace_core_classes__init_A_const_54 = lang.RT_Keyword_String_String__Keyword(nil, Lit_12); A_arbace_core_classes__init_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_69); A_arbace_core_classes__init_A_const_56 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref())))); A_arbace_core_classes__init_A_const_57 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(2).Ref())).Ref(); A_arbace_core_classes__init_A_const_58 = jrt.Integer_ValueOf_I__Integer(118).Ref(); A_arbace_core_classes__init_A_const_59 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_core_classes__init_A_const_60 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref())))); A_arbace_core_classes__init_A_const_61 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(2).Ref())).Ref(); A_arbace_core_classes__init_A_const_62 = jrt.Integer_ValueOf_I__Integer(119).Ref(); A_arbace_core_classes__init_A_const_63 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); A_arbace_core_classes__init_A_const_64 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref())))); A_arbace_core_classes__init_A_const_65 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(1).Ref())).Ref(); A_arbace_core_classes__init_A_const_66 = jrt.Integer_ValueOf_I__Integer(120).Ref(); A_arbace_core_classes__init_A_const_67 = lang.RT_Var_String_String__Var(Lit_0, Lit_72); A_arbace_core_classes__init_A_const_68 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref())))); A_arbace_core_classes__init_A_const_69 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(2).Ref())).Ref(); A_arbace_core_classes__init_A_const_70 = jrt.Integer_ValueOf_I__Integer(121).Ref(); A_arbace_core_classes__init_A_const_71 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); A_arbace_core_classes__init_A_const_72 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref())))); A_arbace_core_classes__init_A_const_73 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(2).Ref())).Ref(); A_arbace_core_classes__init_A_const_74 = jrt.Integer_ValueOf_I__Integer(122).Ref(); A_arbace_core_classes__init_A_const_75 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); A_arbace_core_classes__init_A_const_76 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref())))); A_arbace_core_classes__init_A_const_77 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(2).Ref())).Ref(); A_arbace_core_classes__init_A_const_78 = jrt.Integer_ValueOf_I__Integer(123).Ref(); A_arbace_core_classes__init_A_const_79 = lang.RT_Var_String_String__Var(Lit_0, Lit_76); A_arbace_core_classes__init_A_const_80 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref())))); A_arbace_core_classes__init_A_const_81 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(2).Ref())).Ref(); A_arbace_core_classes__init_A_const_82 = jrt.Integer_ValueOf_I__Integer(126).Ref(); A_arbace_core_classes__init_A_const_83 = lang.RT_Var_String_String__Var(Lit_0, Lit_77); A_arbace_core_classes__init_A_const_84 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref())))); A_arbace_core_classes__init_A_const_85 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(2).Ref())).Ref(); A_arbace_core_classes__init_A_const_86 = jrt.Integer_ValueOf_I__Integer(129).Ref(); A_arbace_core_classes__init_A_const_87 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_core_classes__init_A_const_88 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref())))); A_arbace_core_classes__init_A_const_89 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(2).Ref())).Ref(); A_arbace_core_classes__init_A_const_90 = jrt.Integer_ValueOf_I__Integer(132).Ref(); A_arbace_core_classes__init_A_const_91 = lang.RT_Var_String_String__Var(Lit_0, Lit_79); A_arbace_core_classes__init_A_const_92 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref())))); A_arbace_core_classes__init_A_const_93 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(2).Ref())).Ref(); A_arbace_core_classes__init_A_const_94 = jrt.Integer_ValueOf_I__Integer(133).Ref(); A_arbace_core_classes__init_A_const_95 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_core_classes__init_A_const_96 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref())))); A_arbace_core_classes__init_A_const_97 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(2).Ref())).Ref(); A_arbace_core_classes__init_A_const_98 = jrt.Integer_ValueOf_I__Integer(134).Ref(); A_arbace_core_classes__init_A_const_99 = lang.RT_Var_String_String__Var(Lit_0, Lit_81); A_arbace_core_classes__init_A_const_100 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref())))); A_arbace_core_classes__init_A_const_101 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(2).Ref())).Ref(); A_arbace_core_classes__init_A_const_102 = jrt.Integer_ValueOf_I__Integer(135).Ref(); A_arbace_core_classes__init_A_const_103 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_core_classes__init_A_const_104 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref())))); A_arbace_core_classes__init_A_const_105 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(2).Ref())).Ref(); A_arbace_core_classes__init_A_const_106 = jrt.Integer_ValueOf_I__Integer(136).Ref(); A_arbace_core_classes__init_A_const_107 = lang.RT_Var_String_String__Var(Lit_0, Lit_83); A_arbace_core_classes__init_A_const_108 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref())))); A_arbace_core_classes__init_A_const_109 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Integer_ValueOf_I__Integer(1).Ref())).Ref(); A_arbace_core_classes__init_A_const_110 = jrt.Integer_ValueOf_I__Integer(137).Ref() }

func A_arbace_core_classes__init_A_New() *A_arbace_core_classes__init_A { A_arbace_core_classes__init_A_Init(); t := &A_arbace_core_classes__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_classes__init_A) Ctor() {}

func (t *A_arbace_core_classes__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_classes__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_classes__init_A_class }

func (t *A_arbace_core_classes__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_classes__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_classes__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_classes__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_classes__init_A); return ok }

func A_arbace_core_classes__init_A_Cast(x any) *A_arbace_core_classes__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_classes__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_classes__init_A_class)) }; return v }
