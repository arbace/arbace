//line aot_arbace_core_classes__init.ae:1
package aot_arbace_core_classes

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_classes__init_A_Load__O() any { A_arbace_core_classes__init_A_Init(); A_arbace_core_classes__init_A_Unit0__O(); A_arbace_core_classes__init_A_Unit1__O(); A_arbace_core_classes__init_A_Unit2__O(); A_arbace_core_classes__init_A_Unit3__O(); A_arbace_core_classes__init_A_Unit4__O(); A_arbace_core_classes__init_A_Unit5__O(); A_arbace_core_classes__init_A_Unit6__O(); A_arbace_core_classes__init_A_Unit7__O(); A_arbace_core_classes__init_A_Unit8__O(); A_arbace_core_classes__init_A_Unit9__O(); A_arbace_core_classes__init_A_Unit10__O(); A_arbace_core_classes__init_A_Unit11__O(); A_arbace_core_classes__init_A_Unit12__O(); A_arbace_core_classes__init_A_Unit13__O(); A_arbace_core_classes__init_A_Unit14__O(); A_arbace_core_classes__init_A_Unit15__O(); A_arbace_core_classes__init_A_Unit16__O(); A_arbace_core_classes__init_A_Unit17__O(); A_arbace_core_classes__init_A_Unit18__O(); A_arbace_core_classes__init_A_Unit19__O(); A_arbace_core_classes__init_A_Unit20__O(); A_arbace_core_classes__init_A_Unit21__O(); A_arbace_core_classes__init_A_Unit22__O(); A_arbace_core_classes__init_A_Unit23__O(); A_arbace_core_classes__init_A_Unit24__O(); A_arbace_core_classes__init_A_Unit25__O(); A_arbace_core_classes__init_A_Unit26__O(); A_arbace_core_classes__init_A_Unit27__O(); A_arbace_core_classes__init_A_Unit28__O(); A_arbace_core_classes__init_A_Unit29__O(); A_arbace_core_classes__init_A_Unit30__O(); A_arbace_core_classes__init_A_Unit31__O(); A_arbace_core_classes__init_A_Unit32__O(); A_arbace_core_classes__init_A_Unit33__O(); A_arbace_core_classes__init_A_Unit34__O(); A_arbace_core_classes__init_A_Unit35__O(); A_arbace_core_classes__init_A_Unit36__O(); A_arbace_core_classes__init_A_Unit37__O(); A_arbace_core_classes__init_A_Unit38__O(); A_arbace_core_classes__init_A_Unit39__O(); A_arbace_core_classes__init_A_Unit40__O(); A_arbace_core_classes__init_A_Unit41__O(); A_arbace_core_classes__init_A_Unit42__O(); A_arbace_core_classes__init_A_Unit43__O(); A_arbace_core_classes__init_A_Unit44__O(); A_arbace_core_classes__init_A_Unit45__O(); A_arbace_core_classes__init_A_Unit46__O(); A_arbace_core_classes__init_A_Unit47__O(); A_arbace_core_classes__init_A_Unit48__O(); A_arbace_core_classes__init_A_Unit49__O(); A_arbace_core_classes__init_A_Unit50__O(); A_arbace_core_classes__init_A_Unit51__O(); A_arbace_core_classes__init_A_Unit52__O(); A_arbace_core_classes__init_A_Unit53__O(); A_arbace_core_classes__init_A_Unit54__O(); A_arbace_core_classes__init_A_Unit55__O(); A_arbace_core_classes__init_A_Unit56__O(); A_arbace_core_classes__init_A_Unit57__O(); A_arbace_core_classes__init_A_Unit58__O(); A_arbace_core_classes__init_A_Unit59__O(); A_arbace_core_classes__init_A_Unit60__O(); A_arbace_core_classes__init_A_Unit61__O(); A_arbace_core_classes__init_A_Unit62__O(); A_arbace_core_classes__init_A_Unit63__O(); A_arbace_core_classes__init_A_Unit64__O(); A_arbace_core_classes__init_A_Unit65__O(); A_arbace_core_classes__init_A_Unit66__O(); A_arbace_core_classes__init_A_Unit67__O(); A_arbace_core_classes__init_A_Unit68__O(); A_arbace_core_classes__init_A_Unit69__O(); A_arbace_core_classes__init_A_Unit70__O(); A_arbace_core_classes__init_A_Unit71__O(); A_arbace_core_classes__init_A_Unit72__O(); A_arbace_core_classes__init_A_Unit73__O(); A_arbace_core_classes__init_A_Unit74__O(); A_arbace_core_classes__init_A_Unit75__O(); return nil }



func A_arbace_core_classes__init_A_Unit0__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(A_arbace_core_classes__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_classes__init_A_const_1) }




func A_arbace_core_classes__init_A_Unit1__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_2; var tmp2 any = aot_arbace_core.A_arbace_core_defclass_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_core.A_arbace_core_defclass_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, true); aot_arbace_core.A_arbace_core_defclass_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_3)); return A_arbace_core_classes__init_A_const_2 }
//line :14:1
func A_arbace_core_classes__init_A_Unit2__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); A_arbace_core_classes__init_A_const_2.SetMacro__V(); return nil }
//line :14:1
func A_arbace_core_classes__init_A_Unit3__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); return A_arbace_core_classes__init_A_const_2 }







func A_arbace_core_classes__init_A_Unit4__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_4; var tmp2 any = aot_arbace_core.A_arbace_core_defclasses_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_core.A_arbace_core_defclasses_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, true); aot_arbace_core.A_arbace_core_defclasses_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_5)); return A_arbace_core_classes__init_A_const_4 }
//line :22:1
func A_arbace_core_classes__init_A_Unit5__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); A_arbace_core_classes__init_A_const_4.SetMacro__V(); return nil }
//line :22:1
func A_arbace_core_classes__init_A_Unit6__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); return A_arbace_core_classes__init_A_const_4 }









func A_arbace_core_classes__init_A_Unit7__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_6; var tmp2 any = aot_arbace_core.A_arbace_core_anon_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_core.A_arbace_core_anon_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, true); aot_arbace_core.A_arbace_core_anon_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_7)); return A_arbace_core_classes__init_A_const_6 }
//line :32:1
func A_arbace_core_classes__init_A_Unit8__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); A_arbace_core_classes__init_A_const_6.SetMacro__V(); return nil }
//line :32:1
func A_arbace_core_classes__init_A_Unit9__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); return A_arbace_core_classes__init_A_const_6 }






func A_arbace_core_classes__init_A_Unit10__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_8; var tmp2 any = aot_arbace_core.A_arbace_core_letclass_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_core.A_arbace_core_letclass_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, true); aot_arbace_core.A_arbace_core_letclass_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_9)); return A_arbace_core_classes__init_A_const_8 }
//line :39:1
func A_arbace_core_classes__init_A_Unit11__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); A_arbace_core_classes__init_A_const_8.SetMacro__V(); return nil }
//line :39:1
func A_arbace_core_classes__init_A_Unit12__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); return A_arbace_core_classes__init_A_const_8 }





func A_arbace_core_classes__init_A_Unit13__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(45, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_10; var tmp2 any = aot_arbace_core.A_arbace_core_defmodule_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_core.A_arbace_core_defmodule_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, true); aot_arbace_core.A_arbace_core_defmodule_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_11)); return A_arbace_core_classes__init_A_const_10 }
//line :45:1
func A_arbace_core_classes__init_A_Unit14__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(45, 1); A_arbace_core_classes__init_A_const_10.SetMacro__V(); return nil }
//line :45:1
func A_arbace_core_classes__init_A_Unit15__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(45, 1); return A_arbace_core_classes__init_A_const_10 }







func A_arbace_core_classes__init_A_Unit16__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_12; var tmp2 any = aot_arbace_core.A_arbace_core_defpackage_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = aot_arbace_core.A_arbace_core_defpackage_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); aot_arbace_core.A_arbace_core_defpackage_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_13)); return A_arbace_core_classes__init_A_const_12 }
//line :53:1
func A_arbace_core_classes__init_A_Unit17__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); A_arbace_core_classes__init_A_const_12.SetMacro__V(); return nil }
//line :53:1
func A_arbace_core_classes__init_A_Unit18__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); return A_arbace_core_classes__init_A_const_12 }










func A_arbace_core_classes__init_A_Unit19__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(64, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_14; var tmp2 any = aot_arbace_core.A_arbace_core_label_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_core.A_arbace_core_label_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, true); aot_arbace_core.A_arbace_core_label_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_15)); return A_arbace_core_classes__init_A_const_14 }
//line :64:1
func A_arbace_core_classes__init_A_Unit20__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(64, 1); A_arbace_core_classes__init_A_const_14.SetMacro__V(); return nil }
//line :64:1
func A_arbace_core_classes__init_A_Unit21__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(64, 1); return A_arbace_core_classes__init_A_const_14 }

func A_arbace_core_classes__init_A_Unit22__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_16; var tmp2 any = aot_arbace_core.A_arbace_core_break_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = aot_arbace_core.A_arbace_core_break_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, true); aot_arbace_core.A_arbace_core_break_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_17)); return A_arbace_core_classes__init_A_const_16 }
//line :66:1
func A_arbace_core_classes__init_A_Unit23__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); A_arbace_core_classes__init_A_const_16.SetMacro__V(); return nil }
//line :66:1
func A_arbace_core_classes__init_A_Unit24__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); return A_arbace_core_classes__init_A_const_16 }

func A_arbace_core_classes__init_A_Unit25__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(68, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_18; var tmp2 any = aot_arbace_core.A_arbace_core_continue_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_core.A_arbace_core_continue_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, true); aot_arbace_core.A_arbace_core_continue_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_19)); return A_arbace_core_classes__init_A_const_18 }
//line :68:1
func A_arbace_core_classes__init_A_Unit26__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(68, 1); A_arbace_core_classes__init_A_const_18.SetMacro__V(); return nil }
//line :68:1
func A_arbace_core_classes__init_A_Unit27__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(68, 1); return A_arbace_core_classes__init_A_const_18 }

func A_arbace_core_classes__init_A_Unit28__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_20; var tmp2 any = aot_arbace_core.A_arbace_core_return_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = aot_arbace_core.A_arbace_core_return_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, true); aot_arbace_core.A_arbace_core_return_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_21)); return A_arbace_core_classes__init_A_const_20 }
//line :70:1
func A_arbace_core_classes__init_A_Unit29__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); A_arbace_core_classes__init_A_const_20.SetMacro__V(); return nil }
//line :70:1
func A_arbace_core_classes__init_A_Unit30__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); return A_arbace_core_classes__init_A_const_20 }

func A_arbace_core_classes__init_A_Unit31__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_22; var tmp2 any = aot_arbace_core.A_arbace_core_switch_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_core.A_arbace_core_switch_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, true); aot_arbace_core.A_arbace_core_switch_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_23)); return A_arbace_core_classes__init_A_const_22 }
//line :72:1
func A_arbace_core_classes__init_A_Unit32__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); A_arbace_core_classes__init_A_const_22.SetMacro__V(); return nil }
//line :72:1
func A_arbace_core_classes__init_A_Unit33__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); return A_arbace_core_classes__init_A_const_22 }

func A_arbace_core_classes__init_A_Unit34__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_24; var tmp2 any = aot_arbace_core.A_arbace_core_lambda_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = aot_arbace_core.A_arbace_core_lambda_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, true); aot_arbace_core.A_arbace_core_lambda_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_25)); return A_arbace_core_classes__init_A_const_24 }
//line :74:1
func A_arbace_core_classes__init_A_Unit35__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); A_arbace_core_classes__init_A_const_24.SetMacro__V(); return nil }
//line :74:1
func A_arbace_core_classes__init_A_Unit36__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); return A_arbace_core_classes__init_A_const_24 }

func A_arbace_core_classes__init_A_Unit37__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(76, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_26; var tmp2 any = aot_arbace_core.A_arbace_core_method_ref_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_core.A_arbace_core_method_ref_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_13, true); aot_arbace_core.A_arbace_core_method_ref_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_27)); return A_arbace_core_classes__init_A_const_26 }
//line :76:1
func A_arbace_core_classes__init_A_Unit38__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(76, 1); A_arbace_core_classes__init_A_const_26.SetMacro__V(); return nil }
//line :76:1
func A_arbace_core_classes__init_A_Unit39__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(76, 1); return A_arbace_core_classes__init_A_const_26 }

func A_arbace_core_classes__init_A_Unit40__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(78, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_28; var tmp2 any = aot_arbace_core.A_arbace_core_java_str_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = aot_arbace_core.A_arbace_core_java_str_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, true); aot_arbace_core.A_arbace_core_java_str_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_29)); return A_arbace_core_classes__init_A_const_28 }
//line :78:1
func A_arbace_core_classes__init_A_Unit41__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(78, 1); A_arbace_core_classes__init_A_const_28.SetMacro__V(); return nil }
//line :78:1
func A_arbace_core_classes__init_A_Unit42__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(78, 1); return A_arbace_core_classes__init_A_const_28 }

func A_arbace_core_classes__init_A_Unit43__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_30; var tmp2 any = aot_arbace_core.A_arbace_core_java_assert_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = aot_arbace_core.A_arbace_core_java_assert_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, true); aot_arbace_core.A_arbace_core_java_assert_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_31)); return A_arbace_core_classes__init_A_const_30 }
//line :80:1
func A_arbace_core_classes__init_A_Unit44__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); A_arbace_core_classes__init_A_const_30.SetMacro__V(); return nil }
//line :80:1
func A_arbace_core_classes__init_A_Unit45__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); return A_arbace_core_classes__init_A_const_30 }

func A_arbace_core_classes__init_A_Unit46__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_32; var tmp2 any = aot_arbace_core.A_arbace_core_for_each_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = aot_arbace_core.A_arbace_core_for_each_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, true); aot_arbace_core.A_arbace_core_for_each_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_33)); return A_arbace_core_classes__init_A_const_32 }
//line :82:1
func A_arbace_core_classes__init_A_Unit47__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); A_arbace_core_classes__init_A_const_32.SetMacro__V(); return nil }
//line :82:1
func A_arbace_core_classes__init_A_Unit48__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); return A_arbace_core_classes__init_A_const_32 }


func A_arbace_core_classes__init_A_Unit49__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_34; var tmp2 any = aot_arbace_core.A_arbace_core_with_resources_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = aot_arbace_core.A_arbace_core_with_resources_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, true); aot_arbace_core.A_arbace_core_with_resources_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_35)); return A_arbace_core_classes__init_A_const_34 }
//line :85:1
func A_arbace_core_classes__init_A_Unit50__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); A_arbace_core_classes__init_A_const_34.SetMacro__V(); return nil }
//line :85:1
func A_arbace_core_classes__init_A_Unit51__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); return A_arbace_core_classes__init_A_const_34 }





func A_arbace_core_classes__init_A_Unit52__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(91, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_36; var tmp2 any = aot_arbace_core.A_arbace_core_if_instance_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = aot_arbace_core.A_arbace_core_if_instance_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, true); aot_arbace_core.A_arbace_core_if_instance_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_37)); return A_arbace_core_classes__init_A_const_36 }
//line :91:1
func A_arbace_core_classes__init_A_Unit53__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(91, 1); A_arbace_core_classes__init_A_const_36.SetMacro__V(); return nil }
//line :91:1
func A_arbace_core_classes__init_A_Unit54__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(91, 1); return A_arbace_core_classes__init_A_const_36 }





func A_arbace_core_classes__init_A_Unit55__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_38; var tmp2 any = aot_arbace_core.A_arbace_core_when_instance_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = aot_arbace_core.A_arbace_core_when_instance_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, true); aot_arbace_core.A_arbace_core_when_instance_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_39)); return A_arbace_core_classes__init_A_const_38 }
//line :97:1
func A_arbace_core_classes__init_A_Unit56__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); A_arbace_core_classes__init_A_const_38.SetMacro__V(); return nil }
//line :97:1
func A_arbace_core_classes__init_A_Unit57__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); return A_arbace_core_classes__init_A_const_38 }










func A_arbace_core_classes__init_A_Unit58__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(108, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_40; var tmp2 any = aot_arbace_core.A_arbace_core_defop_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = aot_arbace_core.A_arbace_core_defop_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); aot_arbace_core.A_arbace_core_defop_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_classes__init_A_const_41)); return A_arbace_core_classes__init_A_const_40 }
//line :108:1
func A_arbace_core_classes__init_A_Unit59__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(108, 1); A_arbace_core_classes__init_A_const_40.SetMacro__V(); return nil }
//line :108:1
func A_arbace_core_classes__init_A_Unit60__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(108, 1); return A_arbace_core_classes__init_A_const_40 }








func A_arbace_core_classes__init_A_Unit61__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(117, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_42; var tmp2 any = aot_arbace_core.A_arbace_core_bit_and_int_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = aot_arbace_core.A_arbace_core_bit_and_int_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); aot_arbace_core.A_arbace_core_bit_and_int_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_42; var tmp5 any = A_arbace_core_classes__init_A_const_43; var tmp6 any = A_arbace_core_classes__init_A_const_44; var tmp7 any = A_arbace_core_classes__init_A_const_45; var tmp8 any = A_arbace_core_classes__init_A_const_46; var tmp9 any = A_arbace_core_classes__init_A_const_47; var tmp10 any = A_arbace_core_classes__init_A_const_48; var tmp11 any = A_arbace_core_classes__init_A_const_49; var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000106_A_New(); var tmp13 *jrt.Class; var fncls__22 *jrt.Class = aot_arbace_core.A_arbace_core_fn__1056000106_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); aot_arbace_core.A_arbace_core_fn__1056000106_A_fn_class = fncls__22d; tmp13 = fncls__22d } else { tmp13 = fncls__22 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_22, tmp8, Lit_23, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50, A_arbace_core_classes__init_A_const_51, A_arbace_core_classes__init_A_const_52, A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54, Lit_25))); return A_arbace_core_classes__init_A_const_42 }
func A_arbace_core_classes__init_A_Unit62__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(118, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_55; var tmp2 any = aot_arbace_core.A_arbace_core_bit_or_int_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = aot_arbace_core.A_arbace_core_bit_or_int_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); aot_arbace_core.A_arbace_core_bit_or_int_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_55; var tmp5 any = A_arbace_core_classes__init_A_const_43; var tmp6 any = A_arbace_core_classes__init_A_const_56; var tmp7 any = A_arbace_core_classes__init_A_const_45; var tmp8 any = A_arbace_core_classes__init_A_const_46; var tmp9 any = A_arbace_core_classes__init_A_const_47; var tmp10 any = A_arbace_core_classes__init_A_const_57; var tmp11 any = A_arbace_core_classes__init_A_const_49; var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000109_A_New(); var tmp13 *jrt.Class; var fncls__24 *jrt.Class = aot_arbace_core.A_arbace_core_fn__1056000109_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); aot_arbace_core.A_arbace_core_fn__1056000109_A_fn_class = fncls__24d; tmp13 = fncls__24d } else { tmp13 = fncls__24 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_27, tmp8, Lit_23, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50, A_arbace_core_classes__init_A_const_58, A_arbace_core_classes__init_A_const_52, A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54, Lit_25))); return A_arbace_core_classes__init_A_const_55 }
func A_arbace_core_classes__init_A_Unit63__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(119, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_59; var tmp2 any = aot_arbace_core.A_arbace_core_bit_xor_int_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = aot_arbace_core.A_arbace_core_bit_xor_int_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); aot_arbace_core.A_arbace_core_bit_xor_int_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_59; var tmp5 any = A_arbace_core_classes__init_A_const_43; var tmp6 any = A_arbace_core_classes__init_A_const_60; var tmp7 any = A_arbace_core_classes__init_A_const_45; var tmp8 any = A_arbace_core_classes__init_A_const_46; var tmp9 any = A_arbace_core_classes__init_A_const_47; var tmp10 any = A_arbace_core_classes__init_A_const_61; var tmp11 any = A_arbace_core_classes__init_A_const_49; var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000112_A_New(); var tmp13 *jrt.Class; var fncls__26 *jrt.Class = aot_arbace_core.A_arbace_core_fn__1056000112_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); aot_arbace_core.A_arbace_core_fn__1056000112_A_fn_class = fncls__26d; tmp13 = fncls__26d } else { tmp13 = fncls__26 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_30, tmp8, Lit_23, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50, A_arbace_core_classes__init_A_const_62, A_arbace_core_classes__init_A_const_52, A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54, Lit_25))); return A_arbace_core_classes__init_A_const_59 }
func A_arbace_core_classes__init_A_Unit64__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(120, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_63; var tmp2 any = aot_arbace_core.A_arbace_core_bit_not_int_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = aot_arbace_core.A_arbace_core_bit_not_int_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); aot_arbace_core.A_arbace_core_bit_not_int_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_63; var tmp5 any = A_arbace_core_classes__init_A_const_43; var tmp6 any = A_arbace_core_classes__init_A_const_64; var tmp7 any = A_arbace_core_classes__init_A_const_45; var tmp8 any = A_arbace_core_classes__init_A_const_46; var tmp9 any = A_arbace_core_classes__init_A_const_47; var tmp10 any = A_arbace_core_classes__init_A_const_65; var tmp11 any = A_arbace_core_classes__init_A_const_49; var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000115_A_New(); var tmp13 *jrt.Class; var fncls__28 *jrt.Class = aot_arbace_core.A_arbace_core_fn__1056000115_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); aot_arbace_core.A_arbace_core_fn__1056000115_A_fn_class = fncls__28d; tmp13 = fncls__28d } else { tmp13 = fncls__28 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_33, tmp8, Lit_23, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50, A_arbace_core_classes__init_A_const_66, A_arbace_core_classes__init_A_const_52, A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54, Lit_25))); return A_arbace_core_classes__init_A_const_63 }
func A_arbace_core_classes__init_A_Unit65__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(121, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_67; var tmp2 any = aot_arbace_core.A_arbace_core_bit_shift_left_int_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = aot_arbace_core.A_arbace_core_bit_shift_left_int_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); aot_arbace_core.A_arbace_core_bit_shift_left_int_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_67; var tmp5 any = A_arbace_core_classes__init_A_const_43; var tmp6 any = A_arbace_core_classes__init_A_const_68; var tmp7 any = A_arbace_core_classes__init_A_const_45; var tmp8 any = A_arbace_core_classes__init_A_const_46; var tmp9 any = A_arbace_core_classes__init_A_const_47; var tmp10 any = A_arbace_core_classes__init_A_const_69; var tmp11 any = A_arbace_core_classes__init_A_const_49; var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000118_A_New(); var tmp13 *jrt.Class; var fncls__30 *jrt.Class = aot_arbace_core.A_arbace_core_fn__1056000118_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); aot_arbace_core.A_arbace_core_fn__1056000118_A_fn_class = fncls__30d; tmp13 = fncls__30d } else { tmp13 = fncls__30 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_36, tmp8, Lit_23, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50, A_arbace_core_classes__init_A_const_70, A_arbace_core_classes__init_A_const_52, A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54, Lit_25))); return A_arbace_core_classes__init_A_const_67 }
func A_arbace_core_classes__init_A_Unit66__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(122, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_71; var tmp2 any = aot_arbace_core.A_arbace_core_bit_shift_right_int_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = aot_arbace_core.A_arbace_core_bit_shift_right_int_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); aot_arbace_core.A_arbace_core_bit_shift_right_int_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_71; var tmp5 any = A_arbace_core_classes__init_A_const_43; var tmp6 any = A_arbace_core_classes__init_A_const_72; var tmp7 any = A_arbace_core_classes__init_A_const_45; var tmp8 any = A_arbace_core_classes__init_A_const_46; var tmp9 any = A_arbace_core_classes__init_A_const_47; var tmp10 any = A_arbace_core_classes__init_A_const_73; var tmp11 any = A_arbace_core_classes__init_A_const_49; var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000121_A_New(); var tmp13 *jrt.Class; var fncls__32 *jrt.Class = aot_arbace_core.A_arbace_core_fn__1056000121_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); aot_arbace_core.A_arbace_core_fn__1056000121_A_fn_class = fncls__32d; tmp13 = fncls__32d } else { tmp13 = fncls__32 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_39, tmp8, Lit_23, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50, A_arbace_core_classes__init_A_const_74, A_arbace_core_classes__init_A_const_52, A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54, Lit_25))); return A_arbace_core_classes__init_A_const_71 }
func A_arbace_core_classes__init_A_Unit67__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(123, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_75; var tmp2 any = aot_arbace_core.A_arbace_core_unsigned_bit_shift_right_int_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = aot_arbace_core.A_arbace_core_unsigned_bit_shift_right_int_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); aot_arbace_core.A_arbace_core_unsigned_bit_shift_right_int_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_75; var tmp5 any = A_arbace_core_classes__init_A_const_43; var tmp6 any = A_arbace_core_classes__init_A_const_76; var tmp7 any = A_arbace_core_classes__init_A_const_45; var tmp8 any = A_arbace_core_classes__init_A_const_46; var tmp9 any = A_arbace_core_classes__init_A_const_47; var tmp10 any = A_arbace_core_classes__init_A_const_77; var tmp11 any = A_arbace_core_classes__init_A_const_49; var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000124_A_New(); var tmp13 *jrt.Class; var fncls__34 *jrt.Class = aot_arbace_core.A_arbace_core_fn__1056000124_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); aot_arbace_core.A_arbace_core_fn__1056000124_A_fn_class = fncls__34d; tmp13 = fncls__34d } else { tmp13 = fncls__34 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_42, tmp8, Lit_23, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50, A_arbace_core_classes__init_A_const_78, A_arbace_core_classes__init_A_const_52, A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54, Lit_25))); return A_arbace_core_classes__init_A_const_75 }


func A_arbace_core_classes__init_A_Unit68__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(126, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_79; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_divide_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = aot_arbace_core.A_arbace_core_unchecked_divide_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); aot_arbace_core.A_arbace_core_unchecked_divide_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_79; var tmp5 any = A_arbace_core_classes__init_A_const_43; var tmp6 any = A_arbace_core_classes__init_A_const_80; var tmp7 any = A_arbace_core_classes__init_A_const_45; var tmp8 any = A_arbace_core_classes__init_A_const_46; var tmp9 any = A_arbace_core_classes__init_A_const_47; var tmp10 any = A_arbace_core_classes__init_A_const_81; var tmp11 any = A_arbace_core_classes__init_A_const_49; var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000127_A_New(); var tmp13 *jrt.Class; var fncls__36 *jrt.Class = aot_arbace_core.A_arbace_core_fn__1056000127_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); aot_arbace_core.A_arbace_core_fn__1056000127_A_fn_class = fncls__36d; tmp13 = fncls__36d } else { tmp13 = fncls__36 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_45, tmp8, Lit_23, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50, A_arbace_core_classes__init_A_const_82, A_arbace_core_classes__init_A_const_52, A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54, Lit_25))); return A_arbace_core_classes__init_A_const_79 }


func A_arbace_core_classes__init_A_Unit69__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(129, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_83; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_remainder_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = aot_arbace_core.A_arbace_core_unchecked_remainder_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); aot_arbace_core.A_arbace_core_unchecked_remainder_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_83; var tmp5 any = A_arbace_core_classes__init_A_const_43; var tmp6 any = A_arbace_core_classes__init_A_const_84; var tmp7 any = A_arbace_core_classes__init_A_const_45; var tmp8 any = A_arbace_core_classes__init_A_const_46; var tmp9 any = A_arbace_core_classes__init_A_const_47; var tmp10 any = A_arbace_core_classes__init_A_const_85; var tmp11 any = A_arbace_core_classes__init_A_const_49; var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000130_A_New(); var tmp13 *jrt.Class; var fncls__38 *jrt.Class = aot_arbace_core.A_arbace_core_fn__1056000130_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); aot_arbace_core.A_arbace_core_fn__1056000130_A_fn_class = fncls__38d; tmp13 = fncls__38d } else { tmp13 = fncls__38 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_48, tmp8, Lit_23, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50, A_arbace_core_classes__init_A_const_86, A_arbace_core_classes__init_A_const_52, A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54, Lit_25))); return A_arbace_core_classes__init_A_const_83 }


func A_arbace_core_classes__init_A_Unit70__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(132, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_87; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_add_float_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = aot_arbace_core.A_arbace_core_unchecked_add_float_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); aot_arbace_core.A_arbace_core_unchecked_add_float_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_87; var tmp5 any = A_arbace_core_classes__init_A_const_43; var tmp6 any = A_arbace_core_classes__init_A_const_88; var tmp7 any = A_arbace_core_classes__init_A_const_45; var tmp8 any = A_arbace_core_classes__init_A_const_46; var tmp9 any = A_arbace_core_classes__init_A_const_47; var tmp10 any = A_arbace_core_classes__init_A_const_89; var tmp11 any = A_arbace_core_classes__init_A_const_49; var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000133_A_New(); var tmp13 *jrt.Class; var fncls__40 *jrt.Class = aot_arbace_core.A_arbace_core_fn__1056000133_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); aot_arbace_core.A_arbace_core_fn__1056000133_A_fn_class = fncls__40d; tmp13 = fncls__40d } else { tmp13 = fncls__40 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_51, tmp8, Lit_23, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50, A_arbace_core_classes__init_A_const_90, A_arbace_core_classes__init_A_const_52, A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54, Lit_25))); return A_arbace_core_classes__init_A_const_87 }
func A_arbace_core_classes__init_A_Unit71__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(133, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_91; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_subtract_float_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = aot_arbace_core.A_arbace_core_unchecked_subtract_float_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); aot_arbace_core.A_arbace_core_unchecked_subtract_float_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_91; var tmp5 any = A_arbace_core_classes__init_A_const_43; var tmp6 any = A_arbace_core_classes__init_A_const_92; var tmp7 any = A_arbace_core_classes__init_A_const_45; var tmp8 any = A_arbace_core_classes__init_A_const_46; var tmp9 any = A_arbace_core_classes__init_A_const_47; var tmp10 any = A_arbace_core_classes__init_A_const_93; var tmp11 any = A_arbace_core_classes__init_A_const_49; var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000136_A_New(); var tmp13 *jrt.Class; var fncls__42 *jrt.Class = aot_arbace_core.A_arbace_core_fn__1056000136_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); aot_arbace_core.A_arbace_core_fn__1056000136_A_fn_class = fncls__42d; tmp13 = fncls__42d } else { tmp13 = fncls__42 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_54, tmp8, Lit_23, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50, A_arbace_core_classes__init_A_const_94, A_arbace_core_classes__init_A_const_52, A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54, Lit_25))); return A_arbace_core_classes__init_A_const_91 }
func A_arbace_core_classes__init_A_Unit72__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(134, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_95; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_multiply_float_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = aot_arbace_core.A_arbace_core_unchecked_multiply_float_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); aot_arbace_core.A_arbace_core_unchecked_multiply_float_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_95; var tmp5 any = A_arbace_core_classes__init_A_const_43; var tmp6 any = A_arbace_core_classes__init_A_const_96; var tmp7 any = A_arbace_core_classes__init_A_const_45; var tmp8 any = A_arbace_core_classes__init_A_const_46; var tmp9 any = A_arbace_core_classes__init_A_const_47; var tmp10 any = A_arbace_core_classes__init_A_const_97; var tmp11 any = A_arbace_core_classes__init_A_const_49; var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000139_A_New(); var tmp13 *jrt.Class; var fncls__44 *jrt.Class = aot_arbace_core.A_arbace_core_fn__1056000139_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); aot_arbace_core.A_arbace_core_fn__1056000139_A_fn_class = fncls__44d; tmp13 = fncls__44d } else { tmp13 = fncls__44 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_57, tmp8, Lit_23, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50, A_arbace_core_classes__init_A_const_98, A_arbace_core_classes__init_A_const_52, A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54, Lit_25))); return A_arbace_core_classes__init_A_const_95 }
func A_arbace_core_classes__init_A_Unit73__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(135, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_99; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_divide_float_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = aot_arbace_core.A_arbace_core_unchecked_divide_float_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); aot_arbace_core.A_arbace_core_unchecked_divide_float_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_99; var tmp5 any = A_arbace_core_classes__init_A_const_43; var tmp6 any = A_arbace_core_classes__init_A_const_100; var tmp7 any = A_arbace_core_classes__init_A_const_45; var tmp8 any = A_arbace_core_classes__init_A_const_46; var tmp9 any = A_arbace_core_classes__init_A_const_47; var tmp10 any = A_arbace_core_classes__init_A_const_101; var tmp11 any = A_arbace_core_classes__init_A_const_49; var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000142_A_New(); var tmp13 *jrt.Class; var fncls__46 *jrt.Class = aot_arbace_core.A_arbace_core_fn__1056000142_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); aot_arbace_core.A_arbace_core_fn__1056000142_A_fn_class = fncls__46d; tmp13 = fncls__46d } else { tmp13 = fncls__46 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_60, tmp8, Lit_23, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50, A_arbace_core_classes__init_A_const_102, A_arbace_core_classes__init_A_const_52, A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54, Lit_25))); return A_arbace_core_classes__init_A_const_99 }
func A_arbace_core_classes__init_A_Unit74__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(136, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_103; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_remainder_float_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = aot_arbace_core.A_arbace_core_unchecked_remainder_float_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); aot_arbace_core.A_arbace_core_unchecked_remainder_float_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_103; var tmp5 any = A_arbace_core_classes__init_A_const_43; var tmp6 any = A_arbace_core_classes__init_A_const_104; var tmp7 any = A_arbace_core_classes__init_A_const_45; var tmp8 any = A_arbace_core_classes__init_A_const_46; var tmp9 any = A_arbace_core_classes__init_A_const_47; var tmp10 any = A_arbace_core_classes__init_A_const_105; var tmp11 any = A_arbace_core_classes__init_A_const_49; var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000145_A_New(); var tmp13 *jrt.Class; var fncls__48 *jrt.Class = aot_arbace_core.A_arbace_core_fn__1056000145_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_64, false); aot_arbace_core.A_arbace_core_fn__1056000145_A_fn_class = fncls__48d; tmp13 = fncls__48d } else { tmp13 = fncls__48 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_63, tmp8, Lit_23, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50, A_arbace_core_classes__init_A_const_106, A_arbace_core_classes__init_A_const_52, A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54, Lit_25))); return A_arbace_core_classes__init_A_const_103 }
func A_arbace_core_classes__init_A_Unit75__O() any { A_arbace_core_classes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(137, 1); var tmp1 *lang.Var = A_arbace_core_classes__init_A_const_107; var tmp2 any = aot_arbace_core.A_arbace_core_unchecked_negate_float_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = aot_arbace_core.A_arbace_core_unchecked_negate_float_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); aot_arbace_core.A_arbace_core_unchecked_negate_float_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_classes__init_A_const_107; var tmp5 any = A_arbace_core_classes__init_A_const_43; var tmp6 any = A_arbace_core_classes__init_A_const_108; var tmp7 any = A_arbace_core_classes__init_A_const_45; var tmp8 any = A_arbace_core_classes__init_A_const_46; var tmp9 any = A_arbace_core_classes__init_A_const_47; var tmp10 any = A_arbace_core_classes__init_A_const_109; var tmp11 any = A_arbace_core_classes__init_A_const_49; var tmp12 any = aot_arbace_core.A_arbace_core_fn__1056000148_A_New(); var tmp13 *jrt.Class; var fncls__50 *jrt.Class = aot_arbace_core.A_arbace_core_fn__1056000148_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_67, false); aot_arbace_core.A_arbace_core_fn__1056000148_A_fn_class = fncls__50d; tmp13 = fncls__50d } else { tmp13 = fncls__50 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_66, tmp8, Lit_23, tmp9, tmp10, tmp11, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_core_classes__init_A_const_50, A_arbace_core_classes__init_A_const_110, A_arbace_core_classes__init_A_const_52, A_arbace_core_classes__init_A_const_53, A_arbace_core_classes__init_A_const_54, Lit_25))); return A_arbace_core_classes__init_A_const_107 }










































type A_arbace_core_classes__init_A struct{ jrt.Object }

var A_arbace_core_classes__init_A_const_pool *jrt.RefArray

var A_arbace_core_classes__init_A_const_0 *lang.Var

var A_arbace_core_classes__init_A_const_1 any

var A_arbace_core_classes__init_A_const_2 *lang.Var

var A_arbace_core_classes__init_A_const_3 any

var A_arbace_core_classes__init_A_const_4 *lang.Var

var A_arbace_core_classes__init_A_const_5 any

var A_arbace_core_classes__init_A_const_6 *lang.Var

var A_arbace_core_classes__init_A_const_7 any

var A_arbace_core_classes__init_A_const_8 *lang.Var

var A_arbace_core_classes__init_A_const_9 any

var A_arbace_core_classes__init_A_const_10 *lang.Var

var A_arbace_core_classes__init_A_const_11 any

var A_arbace_core_classes__init_A_const_12 *lang.Var

var A_arbace_core_classes__init_A_const_13 any

var A_arbace_core_classes__init_A_const_14 *lang.Var

var A_arbace_core_classes__init_A_const_15 any

var A_arbace_core_classes__init_A_const_16 *lang.Var

var A_arbace_core_classes__init_A_const_17 any

var A_arbace_core_classes__init_A_const_18 *lang.Var

var A_arbace_core_classes__init_A_const_19 any

var A_arbace_core_classes__init_A_const_20 *lang.Var

var A_arbace_core_classes__init_A_const_21 any

var A_arbace_core_classes__init_A_const_22 *lang.Var

var A_arbace_core_classes__init_A_const_23 any

var A_arbace_core_classes__init_A_const_24 *lang.Var

var A_arbace_core_classes__init_A_const_25 any

var A_arbace_core_classes__init_A_const_26 *lang.Var

var A_arbace_core_classes__init_A_const_27 any

var A_arbace_core_classes__init_A_const_28 *lang.Var

var A_arbace_core_classes__init_A_const_29 any

var A_arbace_core_classes__init_A_const_30 *lang.Var

var A_arbace_core_classes__init_A_const_31 any

var A_arbace_core_classes__init_A_const_32 *lang.Var

var A_arbace_core_classes__init_A_const_33 any

var A_arbace_core_classes__init_A_const_34 *lang.Var

var A_arbace_core_classes__init_A_const_35 any

var A_arbace_core_classes__init_A_const_36 *lang.Var

var A_arbace_core_classes__init_A_const_37 any

var A_arbace_core_classes__init_A_const_38 *lang.Var

var A_arbace_core_classes__init_A_const_39 any

var A_arbace_core_classes__init_A_const_40 *lang.Var

var A_arbace_core_classes__init_A_const_41 any

var A_arbace_core_classes__init_A_const_42 *lang.Var

var A_arbace_core_classes__init_A_const_43 *lang.Keyword

var A_arbace_core_classes__init_A_const_44 any

var A_arbace_core_classes__init_A_const_45 *lang.Keyword

var A_arbace_core_classes__init_A_const_46 *lang.Keyword

var A_arbace_core_classes__init_A_const_47 *lang.Keyword

var A_arbace_core_classes__init_A_const_48 any

var A_arbace_core_classes__init_A_const_49 *lang.Keyword

var A_arbace_core_classes__init_A_const_50 *lang.Keyword

var A_arbace_core_classes__init_A_const_51 any

var A_arbace_core_classes__init_A_const_52 *lang.Keyword

var A_arbace_core_classes__init_A_const_53 any

var A_arbace_core_classes__init_A_const_54 *lang.Keyword

var A_arbace_core_classes__init_A_const_55 *lang.Var

var A_arbace_core_classes__init_A_const_56 any

var A_arbace_core_classes__init_A_const_57 any

var A_arbace_core_classes__init_A_const_58 any

var A_arbace_core_classes__init_A_const_59 *lang.Var

var A_arbace_core_classes__init_A_const_60 any

var A_arbace_core_classes__init_A_const_61 any

var A_arbace_core_classes__init_A_const_62 any

var A_arbace_core_classes__init_A_const_63 *lang.Var

var A_arbace_core_classes__init_A_const_64 any

var A_arbace_core_classes__init_A_const_65 any

var A_arbace_core_classes__init_A_const_66 any

var A_arbace_core_classes__init_A_const_67 *lang.Var

var A_arbace_core_classes__init_A_const_68 any

var A_arbace_core_classes__init_A_const_69 any

var A_arbace_core_classes__init_A_const_70 any

var A_arbace_core_classes__init_A_const_71 *lang.Var

var A_arbace_core_classes__init_A_const_72 any

var A_arbace_core_classes__init_A_const_73 any

var A_arbace_core_classes__init_A_const_74 any

var A_arbace_core_classes__init_A_const_75 *lang.Var

var A_arbace_core_classes__init_A_const_76 any

var A_arbace_core_classes__init_A_const_77 any

var A_arbace_core_classes__init_A_const_78 any

var A_arbace_core_classes__init_A_const_79 *lang.Var

var A_arbace_core_classes__init_A_const_80 any

var A_arbace_core_classes__init_A_const_81 any

var A_arbace_core_classes__init_A_const_82 any

var A_arbace_core_classes__init_A_const_83 *lang.Var

var A_arbace_core_classes__init_A_const_84 any

var A_arbace_core_classes__init_A_const_85 any

var A_arbace_core_classes__init_A_const_86 any

var A_arbace_core_classes__init_A_const_87 *lang.Var

var A_arbace_core_classes__init_A_const_88 any

var A_arbace_core_classes__init_A_const_89 any

var A_arbace_core_classes__init_A_const_90 any

var A_arbace_core_classes__init_A_const_91 *lang.Var

var A_arbace_core_classes__init_A_const_92 any

var A_arbace_core_classes__init_A_const_93 any

var A_arbace_core_classes__init_A_const_94 any

var A_arbace_core_classes__init_A_const_95 *lang.Var

var A_arbace_core_classes__init_A_const_96 any

var A_arbace_core_classes__init_A_const_97 any

var A_arbace_core_classes__init_A_const_98 any

var A_arbace_core_classes__init_A_const_99 *lang.Var

var A_arbace_core_classes__init_A_const_100 any

var A_arbace_core_classes__init_A_const_101 any

var A_arbace_core_classes__init_A_const_102 any

var A_arbace_core_classes__init_A_const_103 *lang.Var

var A_arbace_core_classes__init_A_const_104 any

var A_arbace_core_classes__init_A_const_105 any

var A_arbace_core_classes__init_A_const_106 any

var A_arbace_core_classes__init_A_const_107 *lang.Var

var A_arbace_core_classes__init_A_const_108 any

var A_arbace_core_classes__init_A_const_109 any

var A_arbace_core_classes__init_A_const_110 any

var A_arbace_core_classes__init_A_init jrt.ClassInit

func A_arbace_core_classes__init_A_Init() { if !A_arbace_core_classes__init_A_init.Done() { A_arbace_core_classes__init_A_init.Run(A_arbace_core_classes__init_A_clinit) } }

func A_arbace_core_classes__init_A_clinit() { A_arbace_core_classes__init_A_clinit_p0(); A_arbace_core_classes__init_A_clinit_p1(); A_arbace_core_classes__init_A_clinit_p2(); A_arbace_core_classes__init_A_clinit_p3(); A_arbace_core_classes__init_A_clinit_p4(); A_arbace_core_classes__init_A_clinit_p5(); A_arbace_core_classes__init_A_clinit_p6(); A_arbace_core_classes__init_A_clinit_p7(); A_arbace_core_classes__init_A_clinit_p8() }

func A_arbace_core_classes__init_A_clinit_p0() { A_arbace_core_classes__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 138); A_arbace_core_classes__init_A_const_0 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[27]); A_arbace_core_classes__init_A_const_1 = A_arbace_core_classes__init_A_const_pool.A[28]; A_arbace_core_classes__init_A_const_2 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[29]); A_arbace_core_classes__init_A_const_3 = A_arbace_core_classes__init_A_const_pool.A[30]; A_arbace_core_classes__init_A_const_4 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[31]); A_arbace_core_classes__init_A_const_5 = A_arbace_core_classes__init_A_const_pool.A[32]; A_arbace_core_classes__init_A_const_6 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[33]); A_arbace_core_classes__init_A_const_7 = A_arbace_core_classes__init_A_const_pool.A[34]; A_arbace_core_classes__init_A_const_8 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[35]); A_arbace_core_classes__init_A_const_9 = A_arbace_core_classes__init_A_const_pool.A[36]; A_arbace_core_classes__init_A_const_10 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[37]); A_arbace_core_classes__init_A_const_11 = A_arbace_core_classes__init_A_const_pool.A[38]; A_arbace_core_classes__init_A_const_12 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[39]) }

func A_arbace_core_classes__init_A_clinit_p1() { A_arbace_core_classes__init_A_const_13 = A_arbace_core_classes__init_A_const_pool.A[40]; A_arbace_core_classes__init_A_const_14 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[41]); A_arbace_core_classes__init_A_const_15 = A_arbace_core_classes__init_A_const_pool.A[42]; A_arbace_core_classes__init_A_const_16 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[43]); A_arbace_core_classes__init_A_const_17 = A_arbace_core_classes__init_A_const_pool.A[44]; A_arbace_core_classes__init_A_const_18 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[45]); A_arbace_core_classes__init_A_const_19 = A_arbace_core_classes__init_A_const_pool.A[46]; A_arbace_core_classes__init_A_const_20 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[47]); A_arbace_core_classes__init_A_const_21 = A_arbace_core_classes__init_A_const_pool.A[48]; A_arbace_core_classes__init_A_const_22 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[49]); A_arbace_core_classes__init_A_const_23 = A_arbace_core_classes__init_A_const_pool.A[50]; A_arbace_core_classes__init_A_const_24 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[51]); A_arbace_core_classes__init_A_const_25 = A_arbace_core_classes__init_A_const_pool.A[52] }

func A_arbace_core_classes__init_A_clinit_p2() { A_arbace_core_classes__init_A_const_26 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[53]); A_arbace_core_classes__init_A_const_27 = A_arbace_core_classes__init_A_const_pool.A[54]; A_arbace_core_classes__init_A_const_28 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[55]); A_arbace_core_classes__init_A_const_29 = A_arbace_core_classes__init_A_const_pool.A[56]; A_arbace_core_classes__init_A_const_30 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[57]); A_arbace_core_classes__init_A_const_31 = A_arbace_core_classes__init_A_const_pool.A[58]; A_arbace_core_classes__init_A_const_32 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[59]); A_arbace_core_classes__init_A_const_33 = A_arbace_core_classes__init_A_const_pool.A[60]; A_arbace_core_classes__init_A_const_34 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[61]); A_arbace_core_classes__init_A_const_35 = A_arbace_core_classes__init_A_const_pool.A[62]; A_arbace_core_classes__init_A_const_36 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[63]); A_arbace_core_classes__init_A_const_37 = A_arbace_core_classes__init_A_const_pool.A[64]; A_arbace_core_classes__init_A_const_38 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[65]) }

func A_arbace_core_classes__init_A_clinit_p3() { A_arbace_core_classes__init_A_const_39 = A_arbace_core_classes__init_A_const_pool.A[66]; A_arbace_core_classes__init_A_const_40 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[67]); A_arbace_core_classes__init_A_const_41 = A_arbace_core_classes__init_A_const_pool.A[68]; A_arbace_core_classes__init_A_const_42 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[69]); A_arbace_core_classes__init_A_const_43 = lang.Keyword_Cast(A_arbace_core_classes__init_A_const_pool.A[70]); A_arbace_core_classes__init_A_const_44 = A_arbace_core_classes__init_A_const_pool.A[71]; A_arbace_core_classes__init_A_const_45 = lang.Keyword_Cast(A_arbace_core_classes__init_A_const_pool.A[72]); A_arbace_core_classes__init_A_const_46 = lang.Keyword_Cast(A_arbace_core_classes__init_A_const_pool.A[73]); A_arbace_core_classes__init_A_const_47 = lang.Keyword_Cast(A_arbace_core_classes__init_A_const_pool.A[74]); A_arbace_core_classes__init_A_const_48 = A_arbace_core_classes__init_A_const_pool.A[75]; A_arbace_core_classes__init_A_const_49 = lang.Keyword_Cast(A_arbace_core_classes__init_A_const_pool.A[76]); A_arbace_core_classes__init_A_const_50 = lang.Keyword_Cast(A_arbace_core_classes__init_A_const_pool.A[77]); A_arbace_core_classes__init_A_const_51 = A_arbace_core_classes__init_A_const_pool.A[78] }

func A_arbace_core_classes__init_A_clinit_p4() { A_arbace_core_classes__init_A_const_52 = lang.Keyword_Cast(A_arbace_core_classes__init_A_const_pool.A[79]); A_arbace_core_classes__init_A_const_53 = A_arbace_core_classes__init_A_const_pool.A[80]; A_arbace_core_classes__init_A_const_54 = lang.Keyword_Cast(A_arbace_core_classes__init_A_const_pool.A[81]); A_arbace_core_classes__init_A_const_55 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[82]); A_arbace_core_classes__init_A_const_56 = A_arbace_core_classes__init_A_const_pool.A[83]; A_arbace_core_classes__init_A_const_57 = A_arbace_core_classes__init_A_const_pool.A[84]; A_arbace_core_classes__init_A_const_58 = A_arbace_core_classes__init_A_const_pool.A[85]; A_arbace_core_classes__init_A_const_59 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[86]); A_arbace_core_classes__init_A_const_60 = A_arbace_core_classes__init_A_const_pool.A[87]; A_arbace_core_classes__init_A_const_61 = A_arbace_core_classes__init_A_const_pool.A[88]; A_arbace_core_classes__init_A_const_62 = A_arbace_core_classes__init_A_const_pool.A[89]; A_arbace_core_classes__init_A_const_63 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[90]); A_arbace_core_classes__init_A_const_64 = A_arbace_core_classes__init_A_const_pool.A[91]; A_arbace_core_classes__init_A_const_65 = A_arbace_core_classes__init_A_const_pool.A[92] }

func A_arbace_core_classes__init_A_clinit_p5() { A_arbace_core_classes__init_A_const_66 = A_arbace_core_classes__init_A_const_pool.A[93]; A_arbace_core_classes__init_A_const_67 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[94]); A_arbace_core_classes__init_A_const_68 = A_arbace_core_classes__init_A_const_pool.A[95]; A_arbace_core_classes__init_A_const_69 = A_arbace_core_classes__init_A_const_pool.A[96]; A_arbace_core_classes__init_A_const_70 = A_arbace_core_classes__init_A_const_pool.A[97]; A_arbace_core_classes__init_A_const_71 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[98]); A_arbace_core_classes__init_A_const_72 = A_arbace_core_classes__init_A_const_pool.A[99]; A_arbace_core_classes__init_A_const_73 = A_arbace_core_classes__init_A_const_pool.A[100]; A_arbace_core_classes__init_A_const_74 = A_arbace_core_classes__init_A_const_pool.A[101]; A_arbace_core_classes__init_A_const_75 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[102]); A_arbace_core_classes__init_A_const_76 = A_arbace_core_classes__init_A_const_pool.A[103]; A_arbace_core_classes__init_A_const_77 = A_arbace_core_classes__init_A_const_pool.A[104]; A_arbace_core_classes__init_A_const_78 = A_arbace_core_classes__init_A_const_pool.A[105]; A_arbace_core_classes__init_A_const_79 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[106]) }

func A_arbace_core_classes__init_A_clinit_p6() { A_arbace_core_classes__init_A_const_80 = A_arbace_core_classes__init_A_const_pool.A[107]; A_arbace_core_classes__init_A_const_81 = A_arbace_core_classes__init_A_const_pool.A[108]; A_arbace_core_classes__init_A_const_82 = A_arbace_core_classes__init_A_const_pool.A[109]; A_arbace_core_classes__init_A_const_83 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[110]); A_arbace_core_classes__init_A_const_84 = A_arbace_core_classes__init_A_const_pool.A[111]; A_arbace_core_classes__init_A_const_85 = A_arbace_core_classes__init_A_const_pool.A[112]; A_arbace_core_classes__init_A_const_86 = A_arbace_core_classes__init_A_const_pool.A[113]; A_arbace_core_classes__init_A_const_87 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[114]); A_arbace_core_classes__init_A_const_88 = A_arbace_core_classes__init_A_const_pool.A[115]; A_arbace_core_classes__init_A_const_89 = A_arbace_core_classes__init_A_const_pool.A[116]; A_arbace_core_classes__init_A_const_90 = A_arbace_core_classes__init_A_const_pool.A[117]; A_arbace_core_classes__init_A_const_91 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[118]); A_arbace_core_classes__init_A_const_92 = A_arbace_core_classes__init_A_const_pool.A[119]; A_arbace_core_classes__init_A_const_93 = A_arbace_core_classes__init_A_const_pool.A[120]; A_arbace_core_classes__init_A_const_94 = A_arbace_core_classes__init_A_const_pool.A[121] }

func A_arbace_core_classes__init_A_clinit_p7() { A_arbace_core_classes__init_A_const_95 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[122]); A_arbace_core_classes__init_A_const_96 = A_arbace_core_classes__init_A_const_pool.A[123]; A_arbace_core_classes__init_A_const_97 = A_arbace_core_classes__init_A_const_pool.A[124]; A_arbace_core_classes__init_A_const_98 = A_arbace_core_classes__init_A_const_pool.A[125]; A_arbace_core_classes__init_A_const_99 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[126]); A_arbace_core_classes__init_A_const_100 = A_arbace_core_classes__init_A_const_pool.A[127]; A_arbace_core_classes__init_A_const_101 = A_arbace_core_classes__init_A_const_pool.A[128]; A_arbace_core_classes__init_A_const_102 = A_arbace_core_classes__init_A_const_pool.A[129]; A_arbace_core_classes__init_A_const_103 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[130]); A_arbace_core_classes__init_A_const_104 = A_arbace_core_classes__init_A_const_pool.A[131]; A_arbace_core_classes__init_A_const_105 = A_arbace_core_classes__init_A_const_pool.A[132]; A_arbace_core_classes__init_A_const_106 = A_arbace_core_classes__init_A_const_pool.A[133]; A_arbace_core_classes__init_A_const_107 = lang.Var_Cast(A_arbace_core_classes__init_A_const_pool.A[134]); A_arbace_core_classes__init_A_const_108 = A_arbace_core_classes__init_A_const_pool.A[135] }

func A_arbace_core_classes__init_A_clinit_p8() { A_arbace_core_classes__init_A_const_109 = A_arbace_core_classes__init_A_const_pool.A[136]; A_arbace_core_classes__init_A_const_110 = A_arbace_core_classes__init_A_const_pool.A[137] }

func A_arbace_core_classes__init_A_New() *A_arbace_core_classes__init_A { A_arbace_core_classes__init_A_Init(); t := &A_arbace_core_classes__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_classes__init_A) Ctor() {}

func (t *A_arbace_core_classes__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_classes__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_classes__init_A_class }

func (t *A_arbace_core_classes__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_classes__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_classes__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_classes__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_classes__init_A); return ok }

func A_arbace_core_classes__init_A_Cast(x any) *A_arbace_core_classes__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_classes__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_classes__init_A_class)) }; return v }
