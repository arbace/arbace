//line a2g_strings.ae:1
package aot_arbace_core_classes

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("in-ns")

var Lit_2 *jrt.String = jrt.Intern("defclass")

var Lit_3 *jrt.String = jrt.Intern("arglists")

var Lit_4 *jrt.String = jrt.Intern("&")

var Lit_5 *jrt.String = jrt.Intern("form")

var Lit_6 *jrt.String = jrt.Intern("doc")

var Lit_7 *jrt.String = jrt.Intern("(defclass name record-components? option* member*) defines a Java class (SPEC §4.1).\n  Imports it and evaluates to the class. Class forms of one top-level do may refer to each\n  other (SPEC §9.2).")

var Lit_8 *jrt.String = jrt.Intern("added")

var Lit_9 *jrt.String = jrt.Intern("arbace")

var Lit_10 *jrt.String = jrt.Intern("line")

var Lit_11 *jrt.String = jrt.Intern("column")

var Lit_12 *jrt.String = jrt.Intern("file")

var Lit_13 *jrt.String = jrt.Intern("arbace/core_classes.ae")

var Lit_14 *jrt.String = jrt.Intern("defclasses")

var Lit_15 *jrt.String = jrt.Intern("forms")

var Lit_16 *jrt.String = jrt.Intern("(defclasses (defclass ...) ...): class forms compiled together, so they may refer to each\n  other (SPEC §9.2). Evaluates to a vector of the classes.")

var Lit_17 *jrt.String = jrt.Intern("anon")

var Lit_18 *jrt.String = jrt.Intern("(anon Super [ctor-args*] member*), (anon Inner [ctor-args*] :outer o member*): an instance of\n  an anonymous class (SPEC §4.8).")

var Lit_19 *jrt.String = jrt.Intern("letclass")

var Lit_20 *jrt.String = jrt.Intern("specs")

var Lit_21 *jrt.String = jrt.Intern("body")

var Lit_22 *jrt.String = jrt.Intern("(letclass [(name ...) ...] body*): local classes (SPEC §4.8).")

var Lit_23 *jrt.String = jrt.Intern("defmodule")

var Lit_24 *jrt.String = jrt.Intern("(defmodule name directive*) wrote module-info.class when compiling files (SPEC §4.14). Arbace\n  writes no class files (the bytecode back end is on the branch arbace-for-java-26): it does\n  nothing.")

var Lit_25 *jrt.String = jrt.Intern("defpackage")

var Lit_26 *jrt.String = jrt.Intern("nm")

var Lit_27 *jrt.String = jrt.Intern("(defpackage name) wrote the package's package-info.class (its annotations) when compiling\n  files (SPEC §4.14). Arbace writes no class files (the bytecode back end is on the branch\n  arbace-for-java-26): it does nothing.")

var Lit_28 *jrt.String = jrt.Intern("label")

var Lit_29 *jrt.String = jrt.Intern("kw")

var Lit_30 *jrt.String = jrt.Intern("(label :L form*): a named statement (SPEC §5.7).")

var Lit_31 *jrt.String = jrt.Intern("break")

var Lit_32 *jrt.String = jrt.Intern("args")

var Lit_33 *jrt.String = jrt.Intern("(break), (break :L), (break :L value) (SPEC §5.7).")

var Lit_34 *jrt.String = jrt.Intern("continue")

var Lit_35 *jrt.String = jrt.Intern("(continue arg*), (continue :L arg*) (SPEC §5.7).")

var Lit_36 *jrt.String = jrt.Intern("return")

var Lit_37 *jrt.String = jrt.Intern("(return), (return value) (SPEC §5.7).")

var Lit_38 *jrt.String = jrt.Intern("switch")

var Lit_39 *jrt.String = jrt.Intern("(switch expr clause* default?) (SPEC §5.8).")

var Lit_40 *jrt.String = jrt.Intern("lambda")

var Lit_41 *jrt.String = jrt.Intern("(lambda FI params body*) (SPEC §5.12).")

var Lit_42 *jrt.String = jrt.Intern("method-ref")

var Lit_43 *jrt.String = jrt.Intern("(method-ref FI sig? receiver? method) (SPEC §5.12).")

var Lit_44 *jrt.String = jrt.Intern("java-str")

var Lit_45 *jrt.String = jrt.Intern("(java-str x*): Java's string concatenation (SPEC §5.10).")

var Lit_46 *jrt.String = jrt.Intern("java-assert")

var Lit_47 *jrt.String = jrt.Intern("(java-assert c message?): Java's assert (SPEC §5.9).")

var Lit_48 *jrt.String = jrt.Intern("for-each")

var Lit_49 *jrt.String = jrt.Intern("binding")

var Lit_50 *jrt.String = jrt.Intern("(for-each [^T x coll] body*): Java's enhanced for (SPEC §5.7).")

var Lit_51 *jrt.String = jrt.Intern("with-resources")

var Lit_52 *jrt.String = jrt.Intern("bindings")

var Lit_53 *jrt.String = jrt.Intern("(with-resources [^R r init ...] body*): try-with-resources (SPEC §5.9).")

var Lit_54 *jrt.String = jrt.Intern("if-instance")

var Lit_55 *jrt.String = jrt.Intern("(if-instance [pattern expr] then else?): Java's instanceof with a pattern (SPEC §5.8).")

var Lit_56 *jrt.String = jrt.Intern("when-instance")

var Lit_57 *jrt.String = jrt.Intern("(when-instance [pattern expr] body*) (SPEC §5.8).")

var Lit_58 *jrt.String = jrt.Intern("defop")

var Lit_59 *jrt.String = jrt.Intern("private")

var Lit_60 *jrt.String = jrt.Intern("name")

var Lit_61 *jrt.String = jrt.Intern("method")

var Lit_62 *jrt.String = jrt.Intern("params")

var Lit_63 *jrt.String = jrt.Intern("Defines operator `name` (SPEC §5.4) calling arbace.lang.Numbers/`method`, inlined.")

var Lit_64 *jrt.String = jrt.Intern("bit-and-int")

var Lit_65 *jrt.String = jrt.Intern("x")

var Lit_66 *jrt.String = jrt.Intern("y")

var Lit_67 *jrt.String = jrt.Intern("inline-arities")

var Lit_68 *jrt.String = jrt.Intern("inline")

var Lit_69 *jrt.String = jrt.Intern("bit-or-int")

var Lit_70 *jrt.String = jrt.Intern("bit-xor-int")

var Lit_71 *jrt.String = jrt.Intern("bit-not-int")

var Lit_72 *jrt.String = jrt.Intern("bit-shift-left-int")

var Lit_73 *jrt.String = jrt.Intern("n")

var Lit_74 *jrt.String = jrt.Intern("bit-shift-right-int")

var Lit_75 *jrt.String = jrt.Intern("unsigned-bit-shift-right-int")

var Lit_76 *jrt.String = jrt.Intern("unchecked-divide")

var Lit_77 *jrt.String = jrt.Intern("unchecked-remainder")

var Lit_78 *jrt.String = jrt.Intern("unchecked-add-float")

var Lit_79 *jrt.String = jrt.Intern("unchecked-subtract-float")

var Lit_80 *jrt.String = jrt.Intern("unchecked-multiply-float")

var Lit_81 *jrt.String = jrt.Intern("unchecked-divide-float")

var Lit_82 *jrt.String = jrt.Intern("unchecked-remainder-float")

var Lit_83 *jrt.String = jrt.Intern("unchecked-negate-float")

var Lit_84 *jrt.String = jrt.Intern("Java's & on int: its operands converted as by `int`.")

var Lit_85 *jrt.String = jrt.Intern("Java's | on int: its operands converted as by `int`.")

var Lit_86 *jrt.String = jrt.Intern("Java's ^ on int: its operands converted as by `int`.")

var Lit_87 *jrt.String = jrt.Intern("Java's ~ on int: its operand converted as by `int`.")

var Lit_88 *jrt.String = jrt.Intern("Java's << on int: x shifted by the low 5 bits of n.")

var Lit_89 *jrt.String = jrt.Intern("Java's >> on int: x shifted by the low 5 bits of n.")

var Lit_90 *jrt.String = jrt.Intern("Java's >>> on int: x shifted by the low 5 bits of n.")

var Lit_91 *jrt.String = jrt.Intern("Java's / on long (ldiv) or, when an operand is a double or float, double (ddiv).")

var Lit_92 *jrt.String = jrt.Intern("Java's % on long (lrem) or, when an operand is a double or float, double (drem).")

var Lit_93 *jrt.String = jrt.Intern("Java's + on float: its operands converted as by `float`.")

var Lit_94 *jrt.String = jrt.Intern("Java's - on float.")

var Lit_95 *jrt.String = jrt.Intern("Java's * on float.")

var Lit_96 *jrt.String = jrt.Intern("Java's / on float.")

var Lit_97 *jrt.String = jrt.Intern("Java's % on float.")

var Lit_98 *jrt.String = jrt.Intern("Java's unary - on float.")
