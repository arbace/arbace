//line a2g_strings.ae:1
package aot_arbace_core_classes

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn8,arglistsyn1,&yn4,formkn3,dockn5,addedkn4,linekn6,columnkn4,fileyn5,formsyn5,specsyn4,bodyyn2,nmyn2,kwyn4,argsyn7,bindingyn8,bindingskn7,privateyn4,nameyn3,docyn6,methodyn6,paramsyn1,xyn1,ykn14,inline-aritieskn6,inlineyn1,nv11,arbace.core5,in-nsR0,v11,arbace.core8,defclassm12,R1,L1,V2,R2,R3,R4,s196,(defclass name record-components? option* member*) defines a Java class (SPEC §4.1).\n  Imports it and evaluates to the class. Class forms of one top-level do may refer to each\n  other (SPEC §9.2).R5,s6,arbaceR6,i14,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core10,defclassesm12,R1,L1,V2,R2,R9,R4,s148,(defclasses (defclass ...) ...): class forms compiled together, so they may refer to each\n  other (SPEC §9.2). Evaluates to a vector of the classes.R5,s6,arbaceR6,i22,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core4,anonm12,R1,L1,V2,R2,R3,R4,s127,(anon Super [ctor-args*] member*), (anon Inner [ctor-args*] :outer o member*): an instance of\n  an anonymous class (SPEC §4.8).R5,s6,arbaceR6,i32,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core8,letclassm12,R1,L1,V3,R10,R2,R11,R4,s61,(letclass [(name ...) ...] body*): local classes (SPEC §4.8).R5,s6,arbaceR6,i39,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core9,defmodulem12,R1,L1,V2,R2,R3,R4,s197,(defmodule name directive*) wrote module-info.class when compiling files (SPEC §4.14). Arbace\n  writes no class files (the bytecode back end is on the branch arbace-for-java-26): it does\n  nothing.R5,s6,arbaceR6,i45,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core10,defpackagem12,R1,L1,V1,R12,R4,s220,(defpackage name) wrote the package's package-info.class (its annotations) when compiling\n  files (SPEC §4.14). Arbace writes no class files (the bytecode back end is on the branch\n  arbace-for-java-26): it does nothing.R5,s6,arbaceR6,i53,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core5,labelm12,R1,L1,V3,R13,R2,R11,R4,s48,(label :L form*): a named statement (SPEC §5.7).R5,s6,arbaceR6,i64,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core5,breakm12,R1,L1,V2,R2,R14,R4,s50,(break), (break :L), (break :L value) (SPEC §5.7).R5,s6,arbaceR6,i66,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core8,continuem12,R1,L1,V2,R2,R14,R4,s48,(continue arg*), (continue :L arg*) (SPEC §5.7).R5,s6,arbaceR6,i68,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core6,returnm12,R1,L1,V2,R2,R14,R4,s37,(return), (return value) (SPEC §5.7).R5,s6,arbaceR6,i70,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core6,switchm12,R1,L1,V2,R2,R14,R4,s43,(switch expr clause* default?) (SPEC §5.8).R5,s6,arbaceR6,i72,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core6,lambdam12,R1,L1,V2,R2,R14,R4,s38,(lambda FI params body*) (SPEC §5.12).R5,s6,arbaceR6,i74,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core10,method-refm12,R1,L1,V2,R2,R14,R4,s51,(method-ref FI sig? receiver? method) (SPEC §5.12).R5,s6,arbaceR6,i76,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core8,java-strm12,R1,L1,V2,R2,R14,R4,s56,(java-str x*): Java's string concatenation (SPEC §5.10).R5,s6,arbaceR6,i78,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core11,java-assertm12,R1,L1,V2,R2,R14,R4,s52,(java-assert c message?): Java's assert (SPEC §5.9).R5,s6,arbaceR6,i80,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core8,for-eachm12,R1,L1,V3,R15,R2,R11,R4,s62,(for-each [^T x coll] body*): Java's enhanced for (SPEC §5.7).R5,s6,arbaceR6,i82,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core14,with-resourcesm12,R1,L1,V3,R16,R2,R11,R4,s71,(with-resources [^R r init ...] body*): try-with-resources (SPEC §5.9).R5,s6,arbaceR6,i85,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core11,if-instancem12,R1,L1,V2,R2,R14,R4,s86,(if-instance [pattern expr] then else?): Java's instanceof with a pattern (SPEC §5.8).R5,s6,arbaceR6,i91,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core13,when-instancem12,R1,L1,V3,R15,R2,R11,R4,s49,(when-instance [pattern expr] body*) (SPEC §5.8).R5,s6,arbaceR6,i97,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core5,defopm12,R17,TR1,L1,V4,R18,R19,R20,R21,R4,s82,Defines operator `name` (SPEC §5.4) calling arbace.lang.Numbers/`method`, inlined.R6,i108,R7,i1,R8,s22,arbace/core_classes.aev11,arbace.core11,bit-and-intR1,L1,V2,R22,R23,R4,R5,R24,S1,i2,R25,R6,i117,R7,i1,R8,v11,arbace.core10,bit-or-intL1,V2,R22,R23,S1,i2,i118,v11,arbace.core11,bit-xor-intL1,V2,R22,R23,S1,i2,i119,v11,arbace.core11,bit-not-intL1,V1,R22,S1,i1,i120,v11,arbace.core18,bit-shift-left-intL1,V2,R22,R26,S1,i2,i121,v11,arbace.core19,bit-shift-right-intL1,V2,R22,R26,S1,i2,i122,v11,arbace.core28,unsigned-bit-shift-right-intL1,V2,R22,R26,S1,i2,i123,v11,arbace.core16,unchecked-divideL1,V2,R22,R23,S1,i2,i126,v11,arbace.core19,unchecked-remainderL1,V2,R22,R23,S1,i2,i129,v11,arbace.core19,unchecked-add-floatL1,V2,R22,R23,S1,i2,i132,v11,arbace.core24,unchecked-subtract-floatL1,V2,R22,R23,S1,i2,i133,v11,arbace.core24,unchecked-multiply-floatL1,V2,R22,R23,S1,i2,i134,v11,arbace.core22,unchecked-divide-floatL1,V2,R22,R23,S1,i2,i135,v11,arbace.core25,unchecked-remainder-floatL1,V2,R22,R23,S1,i2,i136,v11,arbace.core22,unchecked-negate-floatL1,V1,R22,S1,i1,i137,")

var Lit_1 *jrt.String = jrt.Intern("arbace.core$defclass")

var Lit_2 *jrt.String = jrt.Intern("arbace.core$defclasses")

var Lit_3 *jrt.String = jrt.Intern("arbace.core$anon")

var Lit_4 *jrt.String = jrt.Intern("arbace.core$letclass")

var Lit_5 *jrt.String = jrt.Intern("arbace.core$defmodule")

var Lit_6 *jrt.String = jrt.Intern("arbace.core$defpackage")

var Lit_7 *jrt.String = jrt.Intern("arbace.core$label")

var Lit_8 *jrt.String = jrt.Intern("arbace.core$break")

var Lit_9 *jrt.String = jrt.Intern("arbace.core$continue")

var Lit_10 *jrt.String = jrt.Intern("arbace.core$return")

var Lit_11 *jrt.String = jrt.Intern("arbace.core$switch")

var Lit_12 *jrt.String = jrt.Intern("arbace.core$lambda")

var Lit_13 *jrt.String = jrt.Intern("arbace.core$method_ref")

var Lit_14 *jrt.String = jrt.Intern("arbace.core$java_str")

var Lit_15 *jrt.String = jrt.Intern("arbace.core$java_assert")

var Lit_16 *jrt.String = jrt.Intern("arbace.core$for_each")

var Lit_17 *jrt.String = jrt.Intern("arbace.core$with_resources")

var Lit_18 *jrt.String = jrt.Intern("arbace.core$if_instance")

var Lit_19 *jrt.String = jrt.Intern("arbace.core$when_instance")

var Lit_20 *jrt.String = jrt.Intern("arbace.core$defop")

var Lit_21 *jrt.String = jrt.Intern("arbace.core$bit_and_int")

var Lit_22 *jrt.String = jrt.Intern("Java's & on int: its operands converted as by `int`.")

var Lit_23 *jrt.String = jrt.Intern("arbace")

var Lit_24 *jrt.String = jrt.Intern("arbace.core$fn__1056000106")

var Lit_25 *jrt.String = jrt.Intern("arbace/core_classes.ae")

var Lit_26 *jrt.String = jrt.Intern("arbace.core$bit_or_int")

var Lit_27 *jrt.String = jrt.Intern("Java's | on int: its operands converted as by `int`.")

var Lit_28 *jrt.String = jrt.Intern("arbace.core$fn__1056000109")

var Lit_29 *jrt.String = jrt.Intern("arbace.core$bit_xor_int")

var Lit_30 *jrt.String = jrt.Intern("Java's ^ on int: its operands converted as by `int`.")

var Lit_31 *jrt.String = jrt.Intern("arbace.core$fn__1056000112")

var Lit_32 *jrt.String = jrt.Intern("arbace.core$bit_not_int")

var Lit_33 *jrt.String = jrt.Intern("Java's ~ on int: its operand converted as by `int`.")

var Lit_34 *jrt.String = jrt.Intern("arbace.core$fn__1056000115")

var Lit_35 *jrt.String = jrt.Intern("arbace.core$bit_shift_left_int")

var Lit_36 *jrt.String = jrt.Intern("Java's << on int: x shifted by the low 5 bits of n.")

var Lit_37 *jrt.String = jrt.Intern("arbace.core$fn__1056000118")

var Lit_38 *jrt.String = jrt.Intern("arbace.core$bit_shift_right_int")

var Lit_39 *jrt.String = jrt.Intern("Java's >> on int: x shifted by the low 5 bits of n.")

var Lit_40 *jrt.String = jrt.Intern("arbace.core$fn__1056000121")

var Lit_41 *jrt.String = jrt.Intern("arbace.core$unsigned_bit_shift_right_int")

var Lit_42 *jrt.String = jrt.Intern("Java's >>> on int: x shifted by the low 5 bits of n.")

var Lit_43 *jrt.String = jrt.Intern("arbace.core$fn__1056000124")

var Lit_44 *jrt.String = jrt.Intern("arbace.core$unchecked_divide")

var Lit_45 *jrt.String = jrt.Intern("Java's / on long (ldiv) or, when an operand is a double or float, double (ddiv).")

var Lit_46 *jrt.String = jrt.Intern("arbace.core$fn__1056000127")

var Lit_47 *jrt.String = jrt.Intern("arbace.core$unchecked_remainder")

var Lit_48 *jrt.String = jrt.Intern("Java's % on long (lrem) or, when an operand is a double or float, double (drem).")

var Lit_49 *jrt.String = jrt.Intern("arbace.core$fn__1056000130")

var Lit_50 *jrt.String = jrt.Intern("arbace.core$unchecked_add_float")

var Lit_51 *jrt.String = jrt.Intern("Java's + on float: its operands converted as by `float`.")

var Lit_52 *jrt.String = jrt.Intern("arbace.core$fn__1056000133")

var Lit_53 *jrt.String = jrt.Intern("arbace.core$unchecked_subtract_float")

var Lit_54 *jrt.String = jrt.Intern("Java's - on float.")

var Lit_55 *jrt.String = jrt.Intern("arbace.core$fn__1056000136")

var Lit_56 *jrt.String = jrt.Intern("arbace.core$unchecked_multiply_float")

var Lit_57 *jrt.String = jrt.Intern("Java's * on float.")

var Lit_58 *jrt.String = jrt.Intern("arbace.core$fn__1056000139")

var Lit_59 *jrt.String = jrt.Intern("arbace.core$unchecked_divide_float")

var Lit_60 *jrt.String = jrt.Intern("Java's / on float.")

var Lit_61 *jrt.String = jrt.Intern("arbace.core$fn__1056000142")

var Lit_62 *jrt.String = jrt.Intern("arbace.core$unchecked_remainder_float")

var Lit_63 *jrt.String = jrt.Intern("Java's % on float.")

var Lit_64 *jrt.String = jrt.Intern("arbace.core$fn__1056000145")

var Lit_65 *jrt.String = jrt.Intern("arbace.core$unchecked_negate_float")

var Lit_66 *jrt.String = jrt.Intern("Java's unary - on float.")

var Lit_67 *jrt.String = jrt.Intern("arbace.core$fn__1056000148")
