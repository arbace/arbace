module arbace

go 1.27
