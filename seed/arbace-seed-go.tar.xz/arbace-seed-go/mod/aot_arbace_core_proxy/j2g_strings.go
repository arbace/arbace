//line j2g_strings.ae:1
package aot_arbace_core_proxy

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn8,arglistskn3,tagyn24,java.lang.reflect.Methodkn4,linekn6,columnkn4,filekn7,privateyn6,rtypesyn4,collkn3,docyn5,Classyn10,interfacesyn6,Stringyn6,super?yn1,fyn5,basesyn1,&kn5,addedyn1,cyn9,ctor-argsyn6,IProxyyn8,mappingsyn20,class-and-interfacesyn4,argsyn2,fsyn4,callyn4,thisyn4,methv11,arbace.core5,in-nsR0,v11,arbace.core10,method-sigm8,R1,L1,V1,Myn4,methm2,R2,R3,R4,i31,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core13,most-specificm10,R7,TR1,L1,V1,R8,R4,i34,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core12,group-by-sigm12,R7,TR1,L1,V1,R9,R10,s90,Takes a collection of [msig meth] and returns a seq of maps from\n   return-types to meths.R4,i38,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core10,proxy-namem10,R1,L1,V2,Myn5,superm2,R2,R11,R12,R2,C16,java.lang.StringR4,i48,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core13,proxy-methodsm12,R7,TR1,L1,V2,Myn5,superm2,R2,R11,R12,R10,s266,The methods generate-proxy overrides: {:super (the superclass's, which call the\n  superclass's implementation without a mapping), :ifaces (the interfaces' and the abstract\n  ones, which throw), :bridges ([dest bridges] for each signature with several return types)}.R4,i59,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core18,proxy-super-markerm8,R7,TR4,i109,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core15,proxy-method-fnm12,R7,TR1,L1,V2,Myn5,mnamem2,R2,R13,R14,R10,s135,The fn of a proxy's method named mname: the fn map's, else the superclass's implementation\n  (super?) or UnsupportedOperationException.R4,i111,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core16,set-proxy-methodm10,R7,TR1,L1,V3,Myn1,cm2,R2,R11,Myn4,methm2,R2,R3,R15,R4,i123,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core12,define-proxym12,R7,TR1,L1,V3,Myn5,pnamem2,R2,R13,Myn5,superm2,R2,R11,R12,R10,s70,The proxy class of super and interfaces named pname, made at run time.R4,i126,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core24,get-super-and-interfacesm10,R7,TR1,L1,V1,R16,R4,i166,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core15,get-proxy-classm12,R1,L1,V2,R17,R16,R10,s316,Takes an optional single class followed by zero or more\n  interfaces. If not supplied class defaults to Object.  Creates an\n  returns an instance of a proxy class derived from the supplied\n  classes. The resulting value is cached and used for any subsequent\n  requests for the same class set. Returns a Class object.R18,s3,1.0R4,i171,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core15,construct-proxym12,R1,L1,V3,R19,R17,R20,R10,s113,Takes a proxy class and any arguments for its superclass ctor and\n  creates and returns an instance of the proxy.R18,s3,1.0R4,i184,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core10,init-proxym12,R1,L1,V2,Myn5,proxym2,R2,R21,R22,R10,s307,Takes a proxy instance and a map of strings (which must\n  correspond to methods of the proxy superclass/superinterfaces) to\n  fns (which must take arguments matching the corresponding method,\n  plus an additional (explicit) first arg corresponding to this, and\n  sets the proxy's fn map.  Returns the proxy.R18,s3,1.0R4,i191,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core12,update-proxym12,R1,L1,V2,Myn5,proxym2,R2,R21,R22,R10,s554,Takes a proxy instance and a map of strings (which must\n  correspond to methods of the proxy superclass/superinterfaces) to\n  fns (which must take arguments matching the corresponding method,\n  plus an additional (explicit) first arg corresponding to this, and\n  updates (via assoc) the proxy's fn map. nil can be passed instead of\n  a fn, in which case the corresponding method will revert to the\n  default behavior. Note that this function can be used to update the\n  behavior of an existing instance without changing its identity.\n  Returns the proxy.R18,s3,1.0R4,i202,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core14,proxy-mappingsm12,R1,L1,V1,Myn5,proxym2,R2,R21,R10,s54,Takes a proxy instance and returns the proxy's fn map.R18,s3,1.0R4,i217,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core5,proxym12,R1,L1,V4,R23,R24,R17,R25,R10,s1058,class-and-interfaces - a vector of class names\n\n  args - a (possibly empty) vector of arguments to the superclass\n  constructor.\n\n  f => (name [params*] body) or\n  (name ([params*] body) ([params+] body) ...)\n\n  Expands to code which creates a instance of a proxy class that\n  implements the named class/interface(s) by calling the supplied\n  fns. A single class, if provided, must be first. If not provided it\n  defaults to Object.\n\n  The interfaces names must be valid interface types. If a method fn\n  is not provided for a class method, the superclass method will be\n  called. If a method fn is not provided for an interface method, an\n  UnsupportedOperationException will be thrown should it be\n  called. Method fns are closures and can capture the environment in\n  which proxy is called. Each method fn takes an additional implicit\n  first arg, which is bound to 'this. Note that while method fns can\n  be provided to override protected methods, they have no other access\n  to protected members, nor to super, as these capabilities cannot be\n  proxied.R18,s3,1.0R4,i223,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core21,proxy-call-with-superm8,R1,L1,V3,R26,R27,R28,R4,i280,R5,i1,R6,s20,arbace/core_proxy.aev11,arbace.core11,proxy-superm12,R1,L1,V3,R28,R17,R24,R10,s95,Use to call a superclass method in the body of a proxy method.\n  Note, expansion captures 'thisR18,s3,1.0R4,i287,R5,i1,R6,s20,arbace/core_proxy.ae")

var Lit_1 *jrt.String = jrt.Intern("java.lang.reflect.Modifier")

var Lit_2 *jrt.String = jrt.Intern("java.lang.reflect.Constructor")

var Lit_3 *jrt.String = jrt.Intern("java.io.Serializable")

var Lit_4 *jrt.String = jrt.Intern("java.io.NotSerializableException")

var Lit_5 *jrt.String = jrt.Intern("arbace.lang.IProxy")

var Lit_6 *jrt.String = jrt.Intern("arbace.lang.Reflector")

var Lit_7 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_8 *jrt.String = jrt.Intern("arbace.lang.PersistentHashMap")

var Lit_9 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_10 *jrt.String = jrt.Intern("arbace.lang.Compiler$Dyn")

var Lit_11 *jrt.String = jrt.Intern("arbace.core$method_sig")

var Lit_12 *jrt.String = jrt.Intern("arbace.core$most_specific")

var Lit_13 *jrt.String = jrt.Intern("arbace.core$group_by_sig")

var Lit_14 *jrt.String = jrt.Intern("arbace.core$proxy_name")

var Lit_15 *jrt.String = jrt.Intern("arbace.core$proxy_methods")

var Lit_16 *jrt.String = jrt.Intern("arbace.core$proxy_method_fn")

var Lit_17 *jrt.String = jrt.Intern("arbace.core$set_proxy_method")

var Lit_18 *jrt.String = jrt.Intern("arbace.core$define_proxy")

var Lit_19 *jrt.String = jrt.Intern("arbace.core$get_super_and_interfaces")

var Lit_20 *jrt.String = jrt.Intern("arbace.core$get_proxy_class")

var Lit_21 *jrt.String = jrt.Intern("arbace.core$construct_proxy")

var Lit_22 *jrt.String = jrt.Intern("arbace.core$init_proxy")

var Lit_23 *jrt.String = jrt.Intern("arbace.core$update_proxy")

var Lit_24 *jrt.String = jrt.Intern("arbace.core$proxy_mappings")

var Lit_25 *jrt.String = jrt.Intern("arbace.core$proxy")

var Lit_26 *jrt.String = jrt.Intern("arbace.core$proxy_call_with_super")

var Lit_27 *jrt.String = jrt.Intern("arbace.core$proxy_super")
