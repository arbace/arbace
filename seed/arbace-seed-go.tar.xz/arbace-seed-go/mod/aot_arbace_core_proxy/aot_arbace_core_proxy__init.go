//line aot_arbace_core_proxy__init.ae:1
package aot_arbace_core_proxy

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_proxy__init_A_Load__O() any { A_arbace_core_proxy__init_A_Init(); jrt.StartCheck(); A_arbace_core_proxy__init_A_Unit0__O(); A_arbace_core_proxy__init_A_Unit1__O(); A_arbace_core_proxy__init_A_Unit2__O(); A_arbace_core_proxy__init_A_Unit3__O(); A_arbace_core_proxy__init_A_Unit4__O(); A_arbace_core_proxy__init_A_Unit5__O(); A_arbace_core_proxy__init_A_Unit6__O(); A_arbace_core_proxy__init_A_Unit7__O(); A_arbace_core_proxy__init_A_Unit8__O(); A_arbace_core_proxy__init_A_Unit9__O(); A_arbace_core_proxy__init_A_Unit10__O(); A_arbace_core_proxy__init_A_Unit11__O(); A_arbace_core_proxy__init_A_Unit12__O(); A_arbace_core_proxy__init_A_Unit13__O(); A_arbace_core_proxy__init_A_Unit14__O(); A_arbace_core_proxy__init_A_Unit15__O(); A_arbace_core_proxy__init_A_Unit16__O(); A_arbace_core_proxy__init_A_Unit17__O(); A_arbace_core_proxy__init_A_Unit18__O(); A_arbace_core_proxy__init_A_Unit19__O(); A_arbace_core_proxy__init_A_Unit20__O(); A_arbace_core_proxy__init_A_Unit21__O(); A_arbace_core_proxy__init_A_Unit22__O(); A_arbace_core_proxy__init_A_Unit23__O(); A_arbace_core_proxy__init_A_Unit24__O(); A_arbace_core_proxy__init_A_Unit25__O(); A_arbace_core_proxy__init_A_Unit26__O(); A_arbace_core_proxy__init_A_Unit27__O(); A_arbace_core_proxy__init_A_Unit28__O(); A_arbace_core_proxy__init_A_Unit29__O(); A_arbace_core_proxy__init_A_Unit30__O(); A_arbace_core_proxy__init_A_Unit31__O(); A_arbace_core_proxy__init_A_Unit32__O(); return nil }

















func A_arbace_core_proxy__init_A_Unit0__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(23, 1); return lang.IFn_Cast(A_arbace_core_proxy__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_proxy__init_A_const_1) }


func A_arbace_core_proxy__init_A_Unit1__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)).Ref() }
//line :26:1
func A_arbace_core_proxy__init_A_Unit2__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_2)).Ref() }
//line :26:1
func A_arbace_core_proxy__init_A_Unit3__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)).Ref() }
//line :26:1
func A_arbace_core_proxy__init_A_Unit4__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_4)).Ref() }
//line :26:1
func A_arbace_core_proxy__init_A_Unit5__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)).Ref() }
//line :26:1
func A_arbace_core_proxy__init_A_Unit6__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)).Ref() }
//line :26:1
func A_arbace_core_proxy__init_A_Unit7__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)).Ref() }
//line :26:1
func A_arbace_core_proxy__init_A_Unit8__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)).Ref() }
//line :26:1
func A_arbace_core_proxy__init_A_Unit9__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)).Ref() }
//line :26:1
func A_arbace_core_proxy__init_A_Unit10__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10)).Ref() }




func A_arbace_core_proxy__init_A_Unit11__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_2; var tmp2 any = aot_arbace_core.A_arbace_core_method_sig_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_core.A_arbace_core_method_sig_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); aot_arbace_core.A_arbace_core_method_sig_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_3)); return A_arbace_core_proxy__init_A_const_2 }


func A_arbace_core_proxy__init_A_Unit12__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_4; var tmp2 any = aot_arbace_core.A_arbace_core_most_specific_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_core.A_arbace_core_most_specific_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); aot_arbace_core.A_arbace_core_most_specific_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_5)); return A_arbace_core_proxy__init_A_const_4 }



func A_arbace_core_proxy__init_A_Unit13__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_6; var tmp2 any = aot_arbace_core.A_arbace_core_group_by_sig_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_core.A_arbace_core_group_by_sig_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); aot_arbace_core.A_arbace_core_group_by_sig_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_7)); return A_arbace_core_proxy__init_A_const_6 }









func A_arbace_core_proxy__init_A_Unit14__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_8; var tmp2 any = aot_arbace_core.A_arbace_core_proxy_name_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_core.A_arbace_core_proxy_name_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); aot_arbace_core.A_arbace_core_proxy_name_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_9)); return A_arbace_core_proxy__init_A_const_8 }










func A_arbace_core_proxy__init_A_Unit15__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(59, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_10; var tmp2 any = aot_arbace_core.A_arbace_core_proxy_methods_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_core.A_arbace_core_proxy_methods_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); aot_arbace_core.A_arbace_core_proxy_methods_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_11)); return A_arbace_core_proxy__init_A_const_10 }

















































func A_arbace_core_proxy__init_A_Unit16__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_12; tmp1.BindRoot_O__V(lang.Compiler_Dyn_SuperMarker__O()); var tmp2 *lang.Var = A_arbace_core_proxy__init_A_const_12; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_13)); return A_arbace_core_proxy__init_A_const_12 }

func A_arbace_core_proxy__init_A_Unit17__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(111, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_14; var tmp2 any = aot_arbace_core.A_arbace_core_proxy_method_fn_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = aot_arbace_core.A_arbace_core_proxy_method_fn_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); aot_arbace_core.A_arbace_core_proxy_method_fn_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_15)); return A_arbace_core_proxy__init_A_const_14 }











func A_arbace_core_proxy__init_A_Unit18__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_16; var tmp2 any = aot_arbace_core.A_arbace_core_set_proxy_method_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_core.A_arbace_core_set_proxy_method_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); aot_arbace_core.A_arbace_core_set_proxy_method_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_17)); return A_arbace_core_proxy__init_A_const_16 }


func A_arbace_core_proxy__init_A_Unit19__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); if lang.RT_LoadClassForName_String__Class_NoInit(Lit_5) == nil { lang.IFn_Cast(A_arbace_core_proxy__init_A_const_18.GetRawRoot__O()).Invoke_O_O_O__O(Lit_5, nil, lang.RT_Seq_O__ISeq_NoInit(jrt.RefArrayOf(jrt.Object_class))) }; var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_18; var tmp2 any = aot_arbace_core.A_arbace_core_define_proxy_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = aot_arbace_core.A_arbace_core_define_proxy_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); aot_arbace_core.A_arbace_core_define_proxy_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_19)); return A_arbace_core_proxy__init_A_const_18 }







































func A_arbace_core_proxy__init_A_Unit20__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_20; var tmp2 any = aot_arbace_core.A_arbace_core_get_super_and_interfaces_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_core.A_arbace_core_get_super_and_interfaces_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); aot_arbace_core.A_arbace_core_get_super_and_interfaces_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_21)); return A_arbace_core_proxy__init_A_const_20 }




func A_arbace_core_proxy__init_A_Unit21__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(171, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_22; var tmp2 any = aot_arbace_core.A_arbace_core_get_proxy_class_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = aot_arbace_core.A_arbace_core_get_proxy_class_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, true); aot_arbace_core.A_arbace_core_get_proxy_class_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_23)); return A_arbace_core_proxy__init_A_const_22 }












func A_arbace_core_proxy__init_A_Unit22__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(184, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_24; var tmp2 any = aot_arbace_core.A_arbace_core_construct_proxy_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_core.A_arbace_core_construct_proxy_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, true); aot_arbace_core.A_arbace_core_construct_proxy_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_25)); return A_arbace_core_proxy__init_A_const_24 }






func A_arbace_core_proxy__init_A_Unit23__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(191, 1); if lang.RT_LoadClassForName_String__Class_NoInit(Lit_5) == nil { lang.IFn_Cast(A_arbace_core_proxy__init_A_const_18.GetRawRoot__O()).Invoke_O_O_O__O(Lit_5, nil, lang.RT_Seq_O__ISeq_NoInit(jrt.RefArrayOf(jrt.Object_class))) }; var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_26; var tmp2 any = aot_arbace_core.A_arbace_core_init_proxy_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = aot_arbace_core.A_arbace_core_init_proxy_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); aot_arbace_core.A_arbace_core_init_proxy_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_27)); return A_arbace_core_proxy__init_A_const_26 }










func A_arbace_core_proxy__init_A_Unit24__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); if lang.RT_LoadClassForName_String__Class_NoInit(Lit_5) == nil { lang.IFn_Cast(A_arbace_core_proxy__init_A_const_18.GetRawRoot__O()).Invoke_O_O_O__O(Lit_5, nil, lang.RT_Seq_O__ISeq_NoInit(jrt.RefArrayOf(jrt.Object_class))) }; var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_28; var tmp2 any = aot_arbace_core.A_arbace_core_update_proxy_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_core.A_arbace_core_update_proxy_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); aot_arbace_core.A_arbace_core_update_proxy_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_29)); return A_arbace_core_proxy__init_A_const_28 }














func A_arbace_core_proxy__init_A_Unit25__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(217, 1); if lang.RT_LoadClassForName_String__Class_NoInit(Lit_5) == nil { lang.IFn_Cast(A_arbace_core_proxy__init_A_const_18.GetRawRoot__O()).Invoke_O_O_O__O(Lit_5, nil, lang.RT_Seq_O__ISeq_NoInit(jrt.RefArrayOf(jrt.Object_class))) }; var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_30; var tmp2 any = aot_arbace_core.A_arbace_core_proxy_mappings_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = aot_arbace_core.A_arbace_core_proxy_mappings_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); aot_arbace_core.A_arbace_core_proxy_mappings_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_31)); return A_arbace_core_proxy__init_A_const_30 }





func A_arbace_core_proxy__init_A_Unit26__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(223, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_32; var tmp2 any = aot_arbace_core.A_arbace_core_proxy_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = aot_arbace_core.A_arbace_core_proxy_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, true); aot_arbace_core.A_arbace_core_proxy_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_33)); return A_arbace_core_proxy__init_A_const_32 }
//line :223:1
func A_arbace_core_proxy__init_A_Unit27__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(223, 1); A_arbace_core_proxy__init_A_const_32.SetMacro__V(); return nil }
//line :223:1
func A_arbace_core_proxy__init_A_Unit28__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(223, 1); return A_arbace_core_proxy__init_A_const_32 }
























































func A_arbace_core_proxy__init_A_Unit29__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(280, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_34; var tmp2 any = aot_arbace_core.A_arbace_core_proxy_call_with_super_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = aot_arbace_core.A_arbace_core_proxy_call_with_super_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); aot_arbace_core.A_arbace_core_proxy_call_with_super_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_35)); return A_arbace_core_proxy__init_A_const_34 }






func A_arbace_core_proxy__init_A_Unit30__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(287, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_36; var tmp2 any = aot_arbace_core.A_arbace_core_proxy_super_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = aot_arbace_core.A_arbace_core_proxy_super_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, true); aot_arbace_core.A_arbace_core_proxy_super_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_37)); return A_arbace_core_proxy__init_A_const_36 }
//line :287:1
func A_arbace_core_proxy__init_A_Unit31__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(287, 1); A_arbace_core_proxy__init_A_const_36.SetMacro__V(); return nil }
//line :287:1
func A_arbace_core_proxy__init_A_Unit32__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(287, 1); return A_arbace_core_proxy__init_A_const_36 }







type A_arbace_core_proxy__init_A struct{ jrt.Object }

var A_arbace_core_proxy__init_A_const_pool *jrt.RefArray

var A_arbace_core_proxy__init_A_const_0 *lang.Var

var A_arbace_core_proxy__init_A_const_1 any

var A_arbace_core_proxy__init_A_const_2 *lang.Var

var A_arbace_core_proxy__init_A_const_3 any

var A_arbace_core_proxy__init_A_const_4 *lang.Var

var A_arbace_core_proxy__init_A_const_5 any

var A_arbace_core_proxy__init_A_const_6 *lang.Var

var A_arbace_core_proxy__init_A_const_7 any

var A_arbace_core_proxy__init_A_const_8 *lang.Var

var A_arbace_core_proxy__init_A_const_9 any

var A_arbace_core_proxy__init_A_const_10 *lang.Var

var A_arbace_core_proxy__init_A_const_11 any

var A_arbace_core_proxy__init_A_const_12 *lang.Var

var A_arbace_core_proxy__init_A_const_13 any

var A_arbace_core_proxy__init_A_const_14 *lang.Var

var A_arbace_core_proxy__init_A_const_15 any

var A_arbace_core_proxy__init_A_const_16 *lang.Var

var A_arbace_core_proxy__init_A_const_17 any

var A_arbace_core_proxy__init_A_const_18 *lang.Var

var A_arbace_core_proxy__init_A_const_19 any

var A_arbace_core_proxy__init_A_const_20 *lang.Var

var A_arbace_core_proxy__init_A_const_21 any

var A_arbace_core_proxy__init_A_const_22 *lang.Var

var A_arbace_core_proxy__init_A_const_23 any

var A_arbace_core_proxy__init_A_const_24 *lang.Var

var A_arbace_core_proxy__init_A_const_25 any

var A_arbace_core_proxy__init_A_const_26 *lang.Var

var A_arbace_core_proxy__init_A_const_27 any

var A_arbace_core_proxy__init_A_const_28 *lang.Var

var A_arbace_core_proxy__init_A_const_29 any

var A_arbace_core_proxy__init_A_const_30 *lang.Var

var A_arbace_core_proxy__init_A_const_31 any

var A_arbace_core_proxy__init_A_const_32 *lang.Var

var A_arbace_core_proxy__init_A_const_33 any

var A_arbace_core_proxy__init_A_const_34 *lang.Var

var A_arbace_core_proxy__init_A_const_35 any

var A_arbace_core_proxy__init_A_const_36 *lang.Var

var A_arbace_core_proxy__init_A_const_37 any

var A_arbace_core_proxy__init_A_init jrt.ClassInit

func A_arbace_core_proxy__init_A_Init() { if !A_arbace_core_proxy__init_A_init.Done() { A_arbace_core_proxy__init_A_init.Run(A_arbace_core_proxy__init_A_clinit) } }

func A_arbace_core_proxy__init_A_clinit() { A_arbace_core_proxy__init_A_clinit_p0(); A_arbace_core_proxy__init_A_clinit_p1(); A_arbace_core_proxy__init_A_clinit_p2() }

func A_arbace_core_proxy__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_core_proxy__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 67); A_arbace_core_proxy__init_A_const_0 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[29]); A_arbace_core_proxy__init_A_const_1 = A_arbace_core_proxy__init_A_const_pool.A[30]; A_arbace_core_proxy__init_A_const_2 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[31]); A_arbace_core_proxy__init_A_const_3 = A_arbace_core_proxy__init_A_const_pool.A[32]; A_arbace_core_proxy__init_A_const_4 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[33]); A_arbace_core_proxy__init_A_const_5 = A_arbace_core_proxy__init_A_const_pool.A[34]; A_arbace_core_proxy__init_A_const_6 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[35]); A_arbace_core_proxy__init_A_const_7 = A_arbace_core_proxy__init_A_const_pool.A[36]; A_arbace_core_proxy__init_A_const_8 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[37]); A_arbace_core_proxy__init_A_const_9 = A_arbace_core_proxy__init_A_const_pool.A[38]; A_arbace_core_proxy__init_A_const_10 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[39]); A_arbace_core_proxy__init_A_const_11 = A_arbace_core_proxy__init_A_const_pool.A[40] }

func A_arbace_core_proxy__init_A_clinit_p1() { A_arbace_core_proxy__init_A_const_12 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[41]); A_arbace_core_proxy__init_A_const_13 = A_arbace_core_proxy__init_A_const_pool.A[42]; A_arbace_core_proxy__init_A_const_14 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[43]); A_arbace_core_proxy__init_A_const_15 = A_arbace_core_proxy__init_A_const_pool.A[44]; A_arbace_core_proxy__init_A_const_16 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[45]); A_arbace_core_proxy__init_A_const_17 = A_arbace_core_proxy__init_A_const_pool.A[46]; A_arbace_core_proxy__init_A_const_18 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[47]); A_arbace_core_proxy__init_A_const_19 = A_arbace_core_proxy__init_A_const_pool.A[48]; A_arbace_core_proxy__init_A_const_20 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[49]); A_arbace_core_proxy__init_A_const_21 = A_arbace_core_proxy__init_A_const_pool.A[50]; A_arbace_core_proxy__init_A_const_22 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[51]); A_arbace_core_proxy__init_A_const_23 = A_arbace_core_proxy__init_A_const_pool.A[52]; A_arbace_core_proxy__init_A_const_24 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[53]) }

func A_arbace_core_proxy__init_A_clinit_p2() { A_arbace_core_proxy__init_A_const_25 = A_arbace_core_proxy__init_A_const_pool.A[54]; A_arbace_core_proxy__init_A_const_26 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[55]); A_arbace_core_proxy__init_A_const_27 = A_arbace_core_proxy__init_A_const_pool.A[56]; A_arbace_core_proxy__init_A_const_28 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[57]); A_arbace_core_proxy__init_A_const_29 = A_arbace_core_proxy__init_A_const_pool.A[58]; A_arbace_core_proxy__init_A_const_30 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[59]); A_arbace_core_proxy__init_A_const_31 = A_arbace_core_proxy__init_A_const_pool.A[60]; A_arbace_core_proxy__init_A_const_32 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[61]); A_arbace_core_proxy__init_A_const_33 = A_arbace_core_proxy__init_A_const_pool.A[62]; A_arbace_core_proxy__init_A_const_34 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[63]); A_arbace_core_proxy__init_A_const_35 = A_arbace_core_proxy__init_A_const_pool.A[64]; A_arbace_core_proxy__init_A_const_36 = lang.Var_Cast(A_arbace_core_proxy__init_A_const_pool.A[65]); A_arbace_core_proxy__init_A_const_37 = A_arbace_core_proxy__init_A_const_pool.A[66] }

func A_arbace_core_proxy__init_A_New() *A_arbace_core_proxy__init_A { A_arbace_core_proxy__init_A_Init(); t := &A_arbace_core_proxy__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_proxy__init_A) Ctor() {}

func (t *A_arbace_core_proxy__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_proxy__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_proxy__init_A_class }

func (t *A_arbace_core_proxy__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_proxy__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_proxy__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_proxy__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_proxy__init_A); return ok }

func A_arbace_core_proxy__init_A_Cast(x any) *A_arbace_core_proxy__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_proxy__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_proxy__init_A_class)) }; return v }
