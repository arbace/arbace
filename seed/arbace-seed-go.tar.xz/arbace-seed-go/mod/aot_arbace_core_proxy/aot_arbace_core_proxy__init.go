//line aot_arbace_core_proxy__init.ae:1
package aot_arbace_core_proxy

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_proxy__init_A_Load__O() any { A_arbace_core_proxy__init_A_Init(); A_arbace_core_proxy__init_A_Unit0__O(); A_arbace_core_proxy__init_A_Unit1__O(); A_arbace_core_proxy__init_A_Unit2__O(); A_arbace_core_proxy__init_A_Unit3__O(); A_arbace_core_proxy__init_A_Unit4__O(); A_arbace_core_proxy__init_A_Unit5__O(); A_arbace_core_proxy__init_A_Unit6__O(); A_arbace_core_proxy__init_A_Unit7__O(); A_arbace_core_proxy__init_A_Unit8__O(); A_arbace_core_proxy__init_A_Unit9__O(); A_arbace_core_proxy__init_A_Unit10__O(); A_arbace_core_proxy__init_A_Unit11__O(); A_arbace_core_proxy__init_A_Unit12__O(); A_arbace_core_proxy__init_A_Unit13__O(); A_arbace_core_proxy__init_A_Unit14__O(); A_arbace_core_proxy__init_A_Unit15__O(); A_arbace_core_proxy__init_A_Unit16__O(); A_arbace_core_proxy__init_A_Unit17__O(); A_arbace_core_proxy__init_A_Unit18__O(); A_arbace_core_proxy__init_A_Unit19__O(); A_arbace_core_proxy__init_A_Unit20__O(); A_arbace_core_proxy__init_A_Unit21__O(); A_arbace_core_proxy__init_A_Unit22__O(); A_arbace_core_proxy__init_A_Unit23__O(); A_arbace_core_proxy__init_A_Unit24__O(); A_arbace_core_proxy__init_A_Unit25__O(); A_arbace_core_proxy__init_A_Unit26__O(); A_arbace_core_proxy__init_A_Unit27__O(); A_arbace_core_proxy__init_A_Unit28__O(); A_arbace_core_proxy__init_A_Unit29__O(); A_arbace_core_proxy__init_A_Unit30__O(); A_arbace_core_proxy__init_A_Unit31__O(); A_arbace_core_proxy__init_A_Unit32__O(); return nil }

















func A_arbace_core_proxy__init_A_Unit0__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_proxy__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_core_proxy__init_A_const_1) }


func A_arbace_core_proxy__init_A_Unit1__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_65)); return nil }
//line :26:1
func A_arbace_core_proxy__init_A_Unit2__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_66)); return nil }
//line :26:1
func A_arbace_core_proxy__init_A_Unit3__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_67)); return nil }
//line :26:1
func A_arbace_core_proxy__init_A_Unit4__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_68)); return nil }
//line :26:1
func A_arbace_core_proxy__init_A_Unit5__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_69)); return nil }
//line :26:1
func A_arbace_core_proxy__init_A_Unit6__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_70)); return nil }
//line :26:1
func A_arbace_core_proxy__init_A_Unit7__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_71)); return nil }
//line :26:1
func A_arbace_core_proxy__init_A_Unit8__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_72)); return nil }
//line :26:1
func A_arbace_core_proxy__init_A_Unit9__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_73)); return nil }
//line :26:1
func A_arbace_core_proxy__init_A_Unit10__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_74)); return nil }




func A_arbace_core_proxy__init_A_Unit11__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(31, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_2; var tmp2 any = aot_arbace_core.A_arbace_core_method_sig_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_method_sig_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_method_sig_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_2; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_3)); return A_arbace_core_proxy__init_A_const_2.Ref() }


func A_arbace_core_proxy__init_A_Unit12__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_4; var tmp2 any = aot_arbace_core.A_arbace_core_most_specific_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_most_specific_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_most_specific_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_5)); return A_arbace_core_proxy__init_A_const_4.Ref() }



func A_arbace_core_proxy__init_A_Unit13__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_6; var tmp2 any = aot_arbace_core.A_arbace_core_group_by_sig_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_group_by_sig_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_group_by_sig_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_7)); return A_arbace_core_proxy__init_A_const_6.Ref() }









func A_arbace_core_proxy__init_A_Unit14__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_8; var tmp2 any = aot_arbace_core.A_arbace_core_proxy_name_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_proxy_name_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_proxy_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_9)); return A_arbace_core_proxy__init_A_const_8.Ref() }










func A_arbace_core_proxy__init_A_Unit15__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(59, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_10; var tmp2 any = aot_arbace_core.A_arbace_core_proxy_methods_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_proxy_methods_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_proxy_methods_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_11)); return A_arbace_core_proxy__init_A_const_10.Ref() }

















































func A_arbace_core_proxy__init_A_Unit16__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(109, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_12; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_Dyn_SuperMarker__O()); var tmp2 *lang.Var = A_arbace_core_proxy__init_A_const_12; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_13)); return A_arbace_core_proxy__init_A_const_12.Ref() }

func A_arbace_core_proxy__init_A_Unit17__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(111, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_14; var tmp2 any = aot_arbace_core.A_arbace_core_proxy_method_fn_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_proxy_method_fn_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_proxy_method_fn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_15)); return A_arbace_core_proxy__init_A_const_14.Ref() }











func A_arbace_core_proxy__init_A_Unit18__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(123, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_16; var tmp2 any = aot_arbace_core.A_arbace_core_set_proxy_method_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_set_proxy_method_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_set_proxy_method_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_17)); return A_arbace_core_proxy__init_A_const_16.Ref() }


func A_arbace_core_proxy__init_A_Unit19__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(126, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_18; var tmp2 any = aot_arbace_core.A_arbace_core_define_proxy_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_define_proxy_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_define_proxy_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_19)); return A_arbace_core_proxy__init_A_const_18.Ref() }







































func A_arbace_core_proxy__init_A_Unit20__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(166, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_20; var tmp2 any = aot_arbace_core.A_arbace_core_get_super_and_interfaces_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_get_super_and_interfaces_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_get_super_and_interfaces_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_21)); return A_arbace_core_proxy__init_A_const_20.Ref() }




func A_arbace_core_proxy__init_A_Unit21__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(171, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_22; var tmp2 any = aot_arbace_core.A_arbace_core_get_proxy_class_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_get_proxy_class_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_get_proxy_class_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_23)); return A_arbace_core_proxy__init_A_const_22.Ref() }












func A_arbace_core_proxy__init_A_Unit22__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(184, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_24; var tmp2 any = aot_arbace_core.A_arbace_core_construct_proxy_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_construct_proxy_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_construct_proxy_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_25)); return A_arbace_core_proxy__init_A_const_24.Ref() }






func A_arbace_core_proxy__init_A_Unit23__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(191, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_26; var tmp2 any = aot_arbace_core.A_arbace_core_init_proxy_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_init_proxy_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_init_proxy_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_27)); return A_arbace_core_proxy__init_A_const_26.Ref() }










func A_arbace_core_proxy__init_A_Unit24__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_28; var tmp2 any = aot_arbace_core.A_arbace_core_update_proxy_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_update_proxy_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_update_proxy_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_29)); return A_arbace_core_proxy__init_A_const_28.Ref() }














func A_arbace_core_proxy__init_A_Unit25__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(217, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_30; var tmp2 any = aot_arbace_core.A_arbace_core_proxy_mappings_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_proxy_mappings_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_proxy_mappings_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_31)); return A_arbace_core_proxy__init_A_const_30.Ref() }





func A_arbace_core_proxy__init_A_Unit26__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(223, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_32; var tmp2 any = aot_arbace_core.A_arbace_core_proxy_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_proxy_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_proxy_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_33)); return A_arbace_core_proxy__init_A_const_32.Ref() }
//line :223:1
func A_arbace_core_proxy__init_A_Unit27__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(223, 1); jrt.NN(A_arbace_core_proxy__init_A_const_32).SetMacro__V(); return nil }
//line :223:1
func A_arbace_core_proxy__init_A_Unit28__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(223, 1); return A_arbace_core_proxy__init_A_const_32.Ref() }
























































func A_arbace_core_proxy__init_A_Unit29__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(280, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_34; var tmp2 any = aot_arbace_core.A_arbace_core_proxy_call_with_super_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_proxy_call_with_super_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_proxy_call_with_super_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_35)); return A_arbace_core_proxy__init_A_const_34.Ref() }






func A_arbace_core_proxy__init_A_Unit30__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(287, 1); var tmp1 *lang.Var = A_arbace_core_proxy__init_A_const_36; var tmp2 any = aot_arbace_core.A_arbace_core_proxy_super_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_proxy_super_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_proxy_super_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_proxy__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_proxy__init_A_const_37)); return A_arbace_core_proxy__init_A_const_36.Ref() }
//line :287:1
func A_arbace_core_proxy__init_A_Unit31__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(287, 1); jrt.NN(A_arbace_core_proxy__init_A_const_36).SetMacro__V(); return nil }
//line :287:1
func A_arbace_core_proxy__init_A_Unit32__O() any { A_arbace_core_proxy__init_A_Init(); lang.Compiler_AOT_At_I_I__V(287, 1); return A_arbace_core_proxy__init_A_const_36.Ref() }







type A_arbace_core_proxy__init_A struct{ jrt.Object }

var A_arbace_core_proxy__init_A_const_0 *lang.Var

var A_arbace_core_proxy__init_A_const_1 any

var A_arbace_core_proxy__init_A_const_2 *lang.Var

var A_arbace_core_proxy__init_A_const_3 any

var A_arbace_core_proxy__init_A_const_4 *lang.Var

var A_arbace_core_proxy__init_A_const_5 any

var A_arbace_core_proxy__init_A_const_6 *lang.Var

var A_arbace_core_proxy__init_A_const_7 any

var A_arbace_core_proxy__init_A_const_8 *lang.Var

var A_arbace_core_proxy__init_A_const_9 any

var A_arbace_core_proxy__init_A_const_10 *lang.Var

var A_arbace_core_proxy__init_A_const_11 any

var A_arbace_core_proxy__init_A_const_12 *lang.Var

var A_arbace_core_proxy__init_A_const_13 any

var A_arbace_core_proxy__init_A_const_14 *lang.Var

var A_arbace_core_proxy__init_A_const_15 any

var A_arbace_core_proxy__init_A_const_16 *lang.Var

var A_arbace_core_proxy__init_A_const_17 any

var A_arbace_core_proxy__init_A_const_18 *lang.Var

var A_arbace_core_proxy__init_A_const_19 any

var A_arbace_core_proxy__init_A_const_20 *lang.Var

var A_arbace_core_proxy__init_A_const_21 any

var A_arbace_core_proxy__init_A_const_22 *lang.Var

var A_arbace_core_proxy__init_A_const_23 any

var A_arbace_core_proxy__init_A_const_24 *lang.Var

var A_arbace_core_proxy__init_A_const_25 any

var A_arbace_core_proxy__init_A_const_26 *lang.Var

var A_arbace_core_proxy__init_A_const_27 any

var A_arbace_core_proxy__init_A_const_28 *lang.Var

var A_arbace_core_proxy__init_A_const_29 any

var A_arbace_core_proxy__init_A_const_30 *lang.Var

var A_arbace_core_proxy__init_A_const_31 any

var A_arbace_core_proxy__init_A_const_32 *lang.Var

var A_arbace_core_proxy__init_A_const_33 any

var A_arbace_core_proxy__init_A_const_34 *lang.Var

var A_arbace_core_proxy__init_A_const_35 any

var A_arbace_core_proxy__init_A_const_36 *lang.Var

var A_arbace_core_proxy__init_A_const_37 any

var A_arbace_core_proxy__init_A_init jrt.ClassInit

func A_arbace_core_proxy__init_A_Init() { if !A_arbace_core_proxy__init_A_init.Done() { A_arbace_core_proxy__init_A_init.Run(A_arbace_core_proxy__init_A_clinit) } }

func A_arbace_core_proxy__init_A_clinit() { A_arbace_core_proxy__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_core_proxy__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_core_proxy__init_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_core_proxy__init_A_const_3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(31).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_core_proxy__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(34).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_core_proxy__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_15).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_core_proxy__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_21).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.RT_ClassForNameNonLoading_String__Class(Lit_22).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_core_proxy__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_21).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_24, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(59).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_core_proxy__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(109).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_core_proxy__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_28).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_30, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(111).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_core_proxy__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_32)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_33).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(123).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_core_proxy__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_35)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_28).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_21).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_36, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(126).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_core_proxy__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(166).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_core_proxy__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_41, lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), Lit_43, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(171).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_core_proxy__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_45).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_46, lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), Lit_43, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(184).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_core_proxy__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_48)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_49).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_51, lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), Lit_43, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(191).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_core_proxy__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_48)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_49).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_53, lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), Lit_43, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(202).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_core_proxy__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_48)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_49).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_55, lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), Lit_43, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(217).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_core_proxy__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_57).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_58).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_59, lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), Lit_43, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(223).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_core_proxy__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(280).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)); A_arbace_core_proxy__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_63); A_arbace_core_proxy__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_57).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_64, lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), Lit_43, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(287).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), Lit_10)) }

func A_arbace_core_proxy__init_A_New() *A_arbace_core_proxy__init_A { A_arbace_core_proxy__init_A_Init(); t := &A_arbace_core_proxy__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_proxy__init_A) Ctor() {}

func (t *A_arbace_core_proxy__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_proxy__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_proxy__init_A_class }

func (t *A_arbace_core_proxy__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_proxy__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_proxy__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_proxy__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_proxy__init_A); return ok }

func A_arbace_core_proxy__init_A_Cast(x any) *A_arbace_core_proxy__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_proxy__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_proxy__init_A_class)) }; return v }
