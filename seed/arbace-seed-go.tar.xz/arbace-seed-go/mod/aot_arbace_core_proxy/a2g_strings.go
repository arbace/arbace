//line a2g_strings.ae:1
package aot_arbace_core_proxy

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("in-ns")

var Lit_2 *jrt.String = jrt.Intern("method-sig")

var Lit_3 *jrt.String = jrt.Intern("arglists")

var Lit_4 *jrt.String = jrt.Intern("meth")

var Lit_5 *jrt.String = jrt.Intern("tag")

var Lit_6 *jrt.String = jrt.Intern("java.lang.reflect.Method")

var Lit_7 *jrt.String = jrt.Intern("line")

var Lit_8 *jrt.String = jrt.Intern("column")

var Lit_9 *jrt.String = jrt.Intern("file")

var Lit_10 *jrt.String = jrt.Intern("arbace/core_proxy.ae")

var Lit_11 *jrt.String = jrt.Intern("most-specific")

var Lit_12 *jrt.String = jrt.Intern("private")

var Lit_13 *jrt.String = jrt.Intern("rtypes")

var Lit_14 *jrt.String = jrt.Intern("group-by-sig")

var Lit_15 *jrt.String = jrt.Intern("coll")

var Lit_16 *jrt.String = jrt.Intern("doc")

var Lit_17 *jrt.String = jrt.Intern("Takes a collection of [msig meth] and returns a seq of maps from\n   return-types to meths.")

var Lit_18 *jrt.String = jrt.Intern("proxy-name")

var Lit_19 *jrt.String = jrt.Intern("super")

var Lit_20 *jrt.String = jrt.Intern("Class")

var Lit_21 *jrt.String = jrt.Intern("interfaces")

var Lit_22 *jrt.String = jrt.Intern("java.lang.String")

var Lit_23 *jrt.String = jrt.Intern("proxy-methods")

var Lit_24 *jrt.String = jrt.Intern("The methods generate-proxy overrides: {:super (the superclass's, which call the\n  superclass's implementation without a mapping), :ifaces (the interfaces' and the abstract\n  ones, which throw), :bridges ([dest bridges] for each signature with several return types)}.")

var Lit_25 *jrt.String = jrt.Intern("proxy-super-marker")

var Lit_26 *jrt.String = jrt.Intern("proxy-method-fn")

var Lit_27 *jrt.String = jrt.Intern("mname")

var Lit_28 *jrt.String = jrt.Intern("String")

var Lit_29 *jrt.String = jrt.Intern("super?")

var Lit_30 *jrt.String = jrt.Intern("The fn of a proxy's method named mname: the fn map's, else the superclass's implementation\n  (super?) or UnsupportedOperationException.")

var Lit_31 *jrt.String = jrt.Intern("set-proxy-method")

var Lit_32 *jrt.String = jrt.Intern("c")

var Lit_33 *jrt.String = jrt.Intern("f")

var Lit_34 *jrt.String = jrt.Intern("define-proxy")

var Lit_35 *jrt.String = jrt.Intern("pname")

var Lit_36 *jrt.String = jrt.Intern("The proxy class of super and interfaces named pname, made at run time.")

var Lit_37 *jrt.String = jrt.Intern("get-super-and-interfaces")

var Lit_38 *jrt.String = jrt.Intern("bases")

var Lit_39 *jrt.String = jrt.Intern("get-proxy-class")

var Lit_40 *jrt.String = jrt.Intern("&")

var Lit_41 *jrt.String = jrt.Intern("Takes an optional single class followed by zero or more\n  interfaces. If not supplied class defaults to Object.  Creates an\n  returns an instance of a proxy class derived from the supplied\n  classes. The resulting value is cached and used for any subsequent\n  requests for the same class set. Returns a Class object.")

var Lit_42 *jrt.String = jrt.Intern("added")

var Lit_43 *jrt.String = jrt.Intern("1.0")

var Lit_44 *jrt.String = jrt.Intern("construct-proxy")

var Lit_45 *jrt.String = jrt.Intern("ctor-args")

var Lit_46 *jrt.String = jrt.Intern("Takes a proxy class and any arguments for its superclass ctor and\n  creates and returns an instance of the proxy.")

var Lit_47 *jrt.String = jrt.Intern("init-proxy")

var Lit_48 *jrt.String = jrt.Intern("proxy")

var Lit_49 *jrt.String = jrt.Intern("IProxy")

var Lit_50 *jrt.String = jrt.Intern("mappings")

var Lit_51 *jrt.String = jrt.Intern("Takes a proxy instance and a map of strings (which must\n  correspond to methods of the proxy superclass/superinterfaces) to\n  fns (which must take arguments matching the corresponding method,\n  plus an additional (explicit) first arg corresponding to this, and\n  sets the proxy's fn map.  Returns the proxy.")

var Lit_52 *jrt.String = jrt.Intern("update-proxy")

var Lit_53 *jrt.String = jrt.Intern("Takes a proxy instance and a map of strings (which must\n  correspond to methods of the proxy superclass/superinterfaces) to\n  fns (which must take arguments matching the corresponding method,\n  plus an additional (explicit) first arg corresponding to this, and\n  updates (via assoc) the proxy's fn map. nil can be passed instead of\n  a fn, in which case the corresponding method will revert to the\n  default behavior. Note that this function can be used to update the\n  behavior of an existing instance without changing its identity.\n  Returns the proxy.")

var Lit_54 *jrt.String = jrt.Intern("proxy-mappings")

var Lit_55 *jrt.String = jrt.Intern("Takes a proxy instance and returns the proxy's fn map.")

var Lit_56 *jrt.String = jrt.Intern("class-and-interfaces")

var Lit_57 *jrt.String = jrt.Intern("args")

var Lit_58 *jrt.String = jrt.Intern("fs")

var Lit_59 *jrt.String = jrt.Intern("class-and-interfaces - a vector of class names\n\n  args - a (possibly empty) vector of arguments to the superclass\n  constructor.\n\n  f => (name [params*] body) or\n  (name ([params*] body) ([params+] body) ...)\n\n  Expands to code which creates a instance of a proxy class that\n  implements the named class/interface(s) by calling the supplied\n  fns. A single class, if provided, must be first. If not provided it\n  defaults to Object.\n\n  The interfaces names must be valid interface types. If a method fn\n  is not provided for a class method, the superclass method will be\n  called. If a method fn is not provided for an interface method, an\n  UnsupportedOperationException will be thrown should it be\n  called. Method fns are closures and can capture the environment in\n  which proxy is called. Each method fn takes an additional implicit\n  first arg, which is bound to 'this. Note that while method fns can\n  be provided to override protected methods, they have no other access\n  to protected members, nor to super, as these capabilities cannot be\n  proxied.")

var Lit_60 *jrt.String = jrt.Intern("proxy-call-with-super")

var Lit_61 *jrt.String = jrt.Intern("call")

var Lit_62 *jrt.String = jrt.Intern("this")

var Lit_63 *jrt.String = jrt.Intern("proxy-super")

var Lit_64 *jrt.String = jrt.Intern("Use to call a superclass method in the body of a proxy method.\n  Note, expansion captures 'this")

var Lit_65 *jrt.String = jrt.Intern("java.lang.reflect.Modifier")

var Lit_66 *jrt.String = jrt.Intern("java.lang.reflect.Constructor")

var Lit_67 *jrt.String = jrt.Intern("java.io.Serializable")

var Lit_68 *jrt.String = jrt.Intern("java.io.NotSerializableException")

var Lit_69 *jrt.String = jrt.Intern("arbace.lang.IProxy")

var Lit_70 *jrt.String = jrt.Intern("arbace.lang.Reflector")

var Lit_71 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_72 *jrt.String = jrt.Intern("arbace.lang.PersistentHashMap")

var Lit_73 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_74 *jrt.String = jrt.Intern("arbace.lang.Compiler$Dyn")
