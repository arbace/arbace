//line a2g_strings.ae:1
package aot_arbace_a2g_out

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.java.io")

var Lit_7 *jrt.String = jrt.Intern("io")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_9 *jrt.String = jrt.Intern("t")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.env")

var Lit_11 *jrt.String = jrt.Intern("env")

var Lit_12 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_13 *jrt.String = jrt.Intern("a")

var Lit_14 *jrt.String = jrt.Intern("arbace.a2g.model")

var Lit_15 *jrt.String = jrt.Intern("m")

var Lit_16 *jrt.String = jrt.Intern("arbace.a2g.names")

var Lit_17 *jrt.String = jrt.Intern("nm")

var Lit_18 *jrt.String = jrt.Intern("arbace.a2g.jrt")

var Lit_19 *jrt.String = jrt.Intern("jrt")

var Lit_20 *jrt.String = jrt.Intern("arbace.a2g.code")

var Lit_21 *jrt.String = jrt.Intern("c")

var Lit_22 *jrt.String = jrt.Intern("arbace.a2g.decls")

var Lit_23 *jrt.String = jrt.Intern("d")

var Lit_24 *jrt.String = jrt.Intern("arbace.a2g.edge")

var Lit_25 *jrt.String = jrt.Intern("edge")

var Lit_26 *jrt.String = jrt.Intern("arbace.classes.opcodes")

var Lit_27 *jrt.String = jrt.Intern("Opcodes")

var Lit_28 *jrt.String = jrt.Intern("commute")

var Lit_29 *jrt.String = jrt.Intern("deref")

var Lit_30 *jrt.String = jrt.Intern("conj")

var Lit_31 *jrt.String = jrt.Intern("arbace.a2g.out")

var Lit_32 *jrt.String = jrt.Intern("doc")

var Lit_33 *jrt.String = jrt.Intern("a2g's output (A2G-SPEC §4.3): Go forms files, one per class forms file, plus the generated\n  files of each package (a2g_classes: registrations and member tables, §5.11; a2g_strings: the\n  literal pool, §7.5; a2g_frames: the frame table, §7.9.6; a2g_support: a2g's helpers), and\n  the merge with jrt's hand-written forms into one program root for bin/g2a build.")

var Lit_34 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_35 *jrt.String = jrt.Intern("with-meta")

var Lit_36 *jrt.String = jrt.Intern("tag")

var Lit_37 *jrt.String = jrt.Intern("dissoc")

var Lit_38 *jrt.String = jrt.Intern("contains?")

var Lit_39 *jrt.String = jrt.Intern("update")

var Lit_40 *jrt.String = jrt.Intern("line")

var Lit_41 *jrt.String = jrt.Intern("column")

var Lit_42 *jrt.String = jrt.Intern("file")

var Lit_43 *jrt.String = jrt.Intern("end-line")

var Lit_44 *jrt.String = jrt.Intern("end-column")

var Lit_45 *jrt.String = jrt.Intern("clean")

var Lit_46 *jrt.String = jrt.Intern("empty?")

var Lit_47 *jrt.String = jrt.Intern("symbol?")

var Lit_48 *jrt.String = jrt.Intern("seq?")

var Lit_49 *jrt.String = jrt.Intern("vector?")

var Lit_50 *jrt.String = jrt.Intern("map?")

var Lit_51 *jrt.String = jrt.Intern("into")

var Lit_52 *jrt.String = jrt.Intern("else")

var Lit_53 *jrt.String = jrt.Intern("*renames*")

var Lit_54 *jrt.String = jrt.Intern("apply")

var Lit_55 *jrt.String = jrt.Intern("list")

var Lit_56 *jrt.String = jrt.Intern("map")

var Lit_57 *jrt.String = jrt.Intern("mapv")

var Lit_58 *jrt.String = jrt.Intern("*lay*")

var Lit_59 *jrt.String = jrt.Intern("filter")

var Lit_60 *jrt.String = jrt.Intern("seq")

var Lit_61 *jrt.String = jrt.Intern("keys")

var Lit_62 *jrt.String = jrt.Intern("out!")

var Lit_63 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_64 *jrt.String = jrt.Intern("a2g")

var Lit_65 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_66 *jrt.String = jrt.Intern("hash-map")

var Lit_67 *jrt.String = jrt.Intern("assoc")

var Lit_68 *jrt.String = jrt.Intern("meta")

var Lit_69 *jrt.String = jrt.Intern("write-form")

var Lit_70 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_71 *jrt.String = jrt.Intern("chunk-first")

var Lit_72 *jrt.String = jrt.Intern("first")

var Lit_73 *jrt.String = jrt.Intern("map-indexed")

var Lit_74 *jrt.String = jrt.Intern("vector")

var Lit_75 *jrt.String = jrt.Intern("chunk-rest")

var Lit_76 *jrt.String = jrt.Intern("next")

var Lit_77 *jrt.String = jrt.Intern("forced")

var Lit_78 *jrt.String = jrt.Intern("write-meta")

var Lit_79 *jrt.String = jrt.Intern("write-items")

var Lit_80 *jrt.String = jrt.Intern("not=")

var Lit_81 *jrt.String = jrt.Intern("repeat")

var Lit_82 *jrt.String = jrt.Intern("write-list")

var Lit_83 *jrt.String = jrt.Intern("pr-str")

var Lit_84 *jrt.String = jrt.Intern("*print-meta*")

var Lit_85 *jrt.String = jrt.Intern("volatile!")

var Lit_86 *jrt.String = jrt.Intern("run!")

var Lit_87 *jrt.String = jrt.Intern("namespace")

var Lit_88 *jrt.String = jrt.Intern("vals")

var Lit_89 *jrt.String = jrt.Intern("some?")

var Lit_90 *jrt.String = jrt.Intern("lined?")

var Lit_91 *jrt.String = jrt.Intern("some")

var Lit_92 *jrt.String = jrt.Intern("split-min")

var Lit_93 *jrt.String = jrt.Intern("comment")

var Lit_94 *jrt.String = jrt.Intern("partition-all")

var Lit_95 *jrt.String = jrt.Intern("jobs")

var Lit_96 *jrt.String = jrt.Intern("cat")

var Lit_97 *jrt.String = jrt.Intern("par-mapv")

var Lit_98 *jrt.String = jrt.Intern("vec")

var Lit_99 *jrt.String = jrt.Intern("unlined-texts")

var Lit_100 *jrt.String = jrt.Intern("used-qualifiers")

var Lit_101 *jrt.String = jrt.Intern("set")

var Lit_102 *jrt.String = jrt.Intern("import-paths")

var Lit_103 *jrt.String = jrt.Intern("pkg-path")

var Lit_104 *jrt.String = jrt.Intern("keyword")

var Lit_105 *jrt.String = jrt.Intern("compiled-packages")

var Lit_106 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_107 *jrt.String = jrt.Intern("not")

var Lit_108 *jrt.String = jrt.Intern("pkg-name")

var Lit_109 *jrt.String = jrt.Intern("chunk-append")

var Lit_110 *jrt.String = jrt.Intern("symbol")

var Lit_111 *jrt.String = jrt.Intern("chunk-cons")

var Lit_112 *jrt.String = jrt.Intern("cons")

var Lit_113 *jrt.String = jrt.Intern("chunk")

var Lit_114 *jrt.String = jrt.Intern("rest")

var Lit_115 *jrt.String = jrt.Intern("sort")

var Lit_116 *jrt.String = jrt.Intern("pkg-ns")

var Lit_117 *jrt.String = jrt.Intern("go")

var Lit_118 *jrt.String = jrt.Intern("imports")

var Lit_119 *jrt.String = jrt.Intern("concat")

var Lit_120 *jrt.String = jrt.Intern("range")

var Lit_121 *jrt.String = jrt.Intern("sort-by")

var Lit_122 *jrt.String = jrt.Intern("remove")

var Lit_123 *jrt.String = jrt.Intern("second")

var Lit_124 *jrt.String = jrt.Intern("replace")

var Lit_125 *jrt.String = jrt.Intern("subs")

var Lit_126 *jrt.String = jrt.Intern("split")

var Lit_127 *jrt.String = jrt.Intern("_")

var Lit_128 *jrt.String = jrt.Intern("last")

var Lit_129 *jrt.String = jrt.Intern("int")

var Lit_130 *jrt.String = jrt.Intern("var")

var Lit_131 *jrt.String = jrt.Intern("*")

var Lit_132 *jrt.String = jrt.Intern("jrt-sym")

var Lit_133 *jrt.String = jrt.Intern("lit")

var Lit_134 *jrt.String = jrt.Intern("slice")

var Lit_135 *jrt.String = jrt.Intern("uint16")

var Lit_136 *jrt.String = jrt.Intern("comp")

var Lit_137 *jrt.String = jrt.Intern("name")

var Lit_138 *jrt.String = jrt.Intern("val")

var Lit_139 *jrt.String = jrt.Intern("func")

var Lit_140 *jrt.String = jrt.Intern("p")

var Lit_141 *jrt.String = jrt.Intern("desc-code")

var Lit_142 *jrt.String = jrt.Intern("go-type")

var Lit_143 *jrt.String = jrt.Intern("when")

var Lit_144 *jrt.String = jrt.Intern("==")

var Lit_145 *jrt.String = jrt.Intern("return")

var Lit_146 *jrt.String = jrt.Intern("*f*")

var Lit_147 *jrt.String = jrt.Intern("pkg")

var Lit_148 *jrt.String = jrt.Intern("go-name")

var Lit_149 *jrt.String = jrt.Intern("find-sam")

var Lit_150 *jrt.String = jrt.Intern("parse-method-desc")

var Lit_151 *jrt.String = jrt.Intern("desc")

var Lit_152 *jrt.String = jrt.Intern(".-Fn")

var Lit_153 *jrt.String = jrt.Intern("method")

var Lit_154 *jrt.String = jrt.Intern("impl-of")

var Lit_155 *jrt.String = jrt.Intern("method-base")

var Lit_156 *jrt.String = jrt.Intern("vary-meta")

var Lit_157 *jrt.String = jrt.Intern("default")

var Lit_158 *jrt.String = jrt.Intern("kind")

var Lit_159 *jrt.String = jrt.Intern("class-sym")

var Lit_160 *jrt.String = jrt.Intern("owner")

var Lit_161 *jrt.String = jrt.Intern("panic")

var Lit_162 *jrt.String = jrt.Intern("type")

var Lit_163 *jrt.String = jrt.Intern("struct")

var Lit_164 *jrt.String = jrt.Intern("Fn")

var Lit_165 *jrt.String = jrt.Intern("distinct")

var Lit_166 *jrt.String = jrt.Intern("mapcat")

var Lit_167 *jrt.String = jrt.Intern("interface-closure")

var Lit_168 *jrt.String = jrt.Intern("vmethods")

var Lit_169 *jrt.String = jrt.Intern("Ref")

var Lit_170 *jrt.String = jrt.Intern("any")

var Lit_171 *jrt.String = jrt.Intern("GetClass__Class")

var Lit_172 *jrt.String = jrt.Intern("ToString__String")

var Lit_173 *jrt.String = jrt.Intern("Clone__O")

var Lit_174 *jrt.String = jrt.Intern("addr")

var Lit_175 *jrt.String = jrt.Intern("Name")

var Lit_176 *jrt.String = jrt.Intern("Modifiers")

var Lit_177 *jrt.String = jrt.Intern("Kind")

var Lit_178 *jrt.String = jrt.Intern("Super")

var Lit_179 *jrt.String = jrt.Intern("Interfaces")

var Lit_180 *jrt.String = jrt.Intern("Go")

var Lit_181 *jrt.String = jrt.Intern("java-names")

var Lit_182 *jrt.String = jrt.Intern("hand-written?")

var Lit_183 *jrt.String = jrt.Intern("leaf?")

var Lit_184 *jrt.String = jrt.Intern("struct-methods")

var Lit_185 *jrt.String = jrt.Intern("interface?")

var Lit_186 *jrt.String = jrt.Intern("abstract?")

var Lit_187 *jrt.String = jrt.Intern("*w*")

var Lit_188 *jrt.String = jrt.Intern("types")

var Lit_189 *jrt.String = jrt.Intern("jrt-classes")

var Lit_190 *jrt.String = jrt.Intern("fjp-support-class")

var Lit_191 *jrt.String = jrt.Intern("translated?")

var Lit_192 *jrt.String = jrt.Intern("fjp-support-key")

var Lit_193 *jrt.String = jrt.Intern("ForkJoinPool")

var Lit_194 *jrt.String = jrt.Intern("fjp-support-methods")

var Lit_195 *jrt.String = jrt.Intern("trivial-init?")

var Lit_196 *jrt.String = jrt.Intern("jrt-default-forwarders")

var Lit_197 *jrt.String = jrt.Intern("fjp-support-forms")

var Lit_198 *jrt.String = jrt.Intern("DescribeConstable__Optional")

var Lit_199 *jrt.String = jrt.Intern("DescribeConstable__Optional is String.describeConstable: Optional.of(this).\n")

var Lit_200 *jrt.String = jrt.Intern("String")

var Lit_201 *jrt.String = jrt.Intern("Optional")

var Lit_202 *jrt.String = jrt.Intern("Optional_Of_O__Optional")

var Lit_203 *jrt.String = jrt.Intern("Lines__Stream")

var Lit_204 *jrt.String = jrt.Intern("Lines__Stream is String.lines: the lines (split at \\n, \\r, \\r\\n) as a\nsequential stream (over an ArrayList: not jdk26u's lazy spliterator).\n")

var Lit_205 *jrt.String = jrt.Intern("Stream")

var Lit_206 *jrt.String = jrt.Intern("let")

var Lit_207 *jrt.String = jrt.Intern("l")

var Lit_208 *jrt.String = jrt.Intern("ArrayList_New")

var Lit_209 *jrt.String = jrt.Intern("x")

var Lit_210 *jrt.String = jrt.Intern("splitLines")

var Lit_211 *jrt.String = jrt.Intern(".-value")

var Lit_212 *jrt.String = jrt.Intern(".Add_O__Z")

var Lit_213 *jrt.String = jrt.Intern("NewStringUTF16")

var Lit_214 *jrt.String = jrt.Intern(".Stream__Stream")

var Lit_215 *jrt.String = jrt.Intern("a2gSetDateZone")

var Lit_216 *jrt.String = jrt.Intern("a2gSetDateZone sets jrt's DateZone hooks to DefaultZone's methods.\n")

var Lit_217 *jrt.String = jrt.Intern("bool")

var Lit_218 *jrt.String = jrt.Intern("set!")

var Lit_219 *jrt.String = jrt.Intern("DateZoneOffset")

var Lit_220 *jrt.String = jrt.Intern("DefaultZone_Offset_J__I")

var Lit_221 *jrt.String = jrt.Intern("DateZoneOffsetByWall")

var Lit_222 *jrt.String = jrt.Intern("DefaultZone_OffsetByWall_J__I")

var Lit_223 *jrt.String = jrt.Intern("DateZoneName")

var Lit_224 *jrt.String = jrt.Intern("fn")

var Lit_225 *jrt.String = jrt.Intern("ms")

var Lit_226 *jrt.String = jrt.Intern("int64")

var Lit_227 *jrt.String = jrt.Intern("string")

var Lit_228 *jrt.String = jrt.Intern(".String")

var Lit_229 *jrt.String = jrt.Intern("DefaultZone_Name_J__String")

var Lit_230 *jrt.String = jrt.Intern("a2gDateZoneSet")

var Lit_231 *jrt.String = jrt.Intern("string-regex-methods")

var Lit_232 *jrt.String = jrt.Intern("GetResourceAsStream_String__InputStream")

var Lit_233 *jrt.String = jrt.Intern("n")

var Lit_234 *jrt.String = jrt.Intern("NN")

var Lit_235 *jrt.String = jrt.Intern("if")

var Lit_236 *jrt.String = jrt.Intern("strings")

var Lit_237 *jrt.String = jrt.Intern("HasPrefix")

var Lit_238 *jrt.String = jrt.Intern("/")

var Lit_239 *jrt.String = jrt.Intern("subslice")

var Lit_240 *jrt.String = jrt.Intern("e")

var Lit_241 *jrt.String = jrt.Intern("while")

var Lit_242 *jrt.String = jrt.Intern(".IsArray__Z")

var Lit_243 *jrt.String = jrt.Intern(".GetComponentType__Class")

var Lit_244 *jrt.String = jrt.Intern("cn")

var Lit_245 *jrt.String = jrt.Intern(".-Name")

var Lit_246 *jrt.String = jrt.Intern(".Info")

var Lit_247 *jrt.String = jrt.Intern("i")

var Lit_248 *jrt.String = jrt.Intern("LastIndexByte")

var Lit_249 *jrt.String = jrt.Intern(">=")

var Lit_250 *jrt.String = jrt.Intern("+")

var Lit_251 *jrt.String = jrt.Intern("ReplaceAll")

var Lit_252 *jrt.String = jrt.Intern(".")

var Lit_253 *jrt.String = jrt.Intern("values")

var Lit_254 *jrt.String = jrt.Intern("b")

var Lit_255 *jrt.String = jrt.Intern("ok")

var Lit_256 *jrt.String = jrt.Intern("ResourceOrPath")

var Lit_257 *jrt.String = jrt.Intern("NewByteArray")

var Lit_258 *jrt.String = jrt.Intern("conv")

var Lit_259 *jrt.String = jrt.Intern("int32")

var Lit_260 *jrt.String = jrt.Intern("len")

var Lit_261 *jrt.String = jrt.Intern("aset")

var Lit_262 *jrt.String = jrt.Intern(".-A")

var Lit_263 *jrt.String = jrt.Intern("int8")

var Lit_264 *jrt.String = jrt.Intern("ByteArrayInputStream_New_B1")

var Lit_265 *jrt.String = jrt.Intern("Class")

var Lit_266 *jrt.String = jrt.Intern("nil?")

var Lit_267 *jrt.String = jrt.Intern("A2g_RefP")

var Lit_268 *jrt.String = jrt.Intern("A2g_RefP is a pointer as an any, nil-preserving (§5.6).\n")

var Lit_269 *jrt.String = jrt.Intern("type-params")

var Lit_270 *jrt.String = jrt.Intern("T")

var Lit_271 *jrt.String = jrt.Intern("String_Format_String_O1__String")

var Lit_272 *jrt.String = jrt.Intern("String_Format_String_O1__String is String.format: a new Formatter's format (a2g's, over the\ntranslated java.util.Formatter).\n")

var Lit_273 *jrt.String = jrt.Intern("format")

var Lit_274 *jrt.String = jrt.Intern("args")

var Lit_275 *jrt.String = jrt.Intern("RefArray")

var Lit_276 *jrt.String = jrt.Intern(".ToString__String")

var Lit_277 *jrt.String = jrt.Intern(".Format_String_O1__Formatter")

var Lit_278 *jrt.String = jrt.Intern("Formatter_New")

var Lit_279 *jrt.String = jrt.Intern("Formatted_O1__String")

var Lit_280 *jrt.String = jrt.Intern("Formatted_O1__String is String.formatted: String.format(this, args).\n")

var Lit_281 *jrt.String = jrt.Intern("String_Join_CharSequence_Iterable__String")

var Lit_282 *jrt.String = jrt.Intern("String_Join_CharSequence_Iterable__String is String.join(CharSequence, Iterable): each\nelement cast to CharSequence (the for loop's checkcast), then joined as the array overload joins.\n")

var Lit_283 *jrt.String = jrt.Intern("sep")

var Lit_284 *jrt.String = jrt.Intern("CharSequence")

var Lit_285 *jrt.String = jrt.Intern("elements")

var Lit_286 *jrt.String = jrt.Intern("Iterable")

var Lit_287 *jrt.String = jrt.Intern("NPE")

var Lit_288 *jrt.String = jrt.Intern("es")

var Lit_289 *jrt.String = jrt.Intern("it")

var Lit_290 *jrt.String = jrt.Intern(".Iterator__Iterator")

var Lit_291 *jrt.String = jrt.Intern(".HasNext__Z")

var Lit_292 *jrt.String = jrt.Intern("append")

var Lit_293 *jrt.String = jrt.Intern("CharSequence_Cast")

var Lit_294 *jrt.String = jrt.Intern(".Next__O")

var Lit_295 *jrt.String = jrt.Intern("String_Join_CharSequence_CharSequence1__String")

var Lit_296 *jrt.String = jrt.Intern("RefArrayOf")

var Lit_297 *jrt.String = jrt.Intern("CharSequence_class")

var Lit_298 *jrt.String = jrt.Intern("spread")

var Lit_299 *jrt.String = jrt.Intern("String_Format_Locale_String_O1__String")

var Lit_300 *jrt.String = jrt.Intern("String_Format_Locale_String_O1__String is String.format(Locale, ...).\n")

var Lit_301 *jrt.String = jrt.Intern("Locale")

var Lit_302 *jrt.String = jrt.Intern("Formatter_New_Locale")

var Lit_303 *jrt.String = jrt.Intern("A2g_ObjHash")

var Lit_304 *jrt.String = jrt.Intern("A2g_ObjHash is Objects.hashCode.\n")

var Lit_305 *jrt.String = jrt.Intern("HashCode")

var Lit_306 *jrt.String = jrt.Intern("A2g_ObjEquals")

var Lit_307 *jrt.String = jrt.Intern("A2g_ObjEquals is Objects.equals.\n")

var Lit_308 *jrt.String = jrt.Intern("or")

var Lit_309 *jrt.String = jrt.Intern("Equals")

var Lit_310 *jrt.String = jrt.Intern("A2g_DoubleBits")

var Lit_311 *jrt.String = jrt.Intern("A2g_DoubleBits is Double.doubleToLongBits (one NaN).\n")

var Lit_312 *jrt.String = jrt.Intern("float64")

var Lit_313 *jrt.String = jrt.Intern("math")

var Lit_314 *jrt.String = jrt.Intern("IsNaN")

var Lit_315 *jrt.String = jrt.Intern("Float64bits")

var Lit_316 *jrt.String = jrt.Intern("A2g_BoolHash")

var Lit_317 *jrt.String = jrt.Intern("A2g_BoolHash is Boolean.hashCode(boolean).\n")

var Lit_318 *jrt.String = jrt.Intern("A2g_FloatBits")

var Lit_319 *jrt.String = jrt.Intern("A2g_FloatBits is Float.floatToIntBits (one NaN).\n")

var Lit_320 *jrt.String = jrt.Intern("f")

var Lit_321 *jrt.String = jrt.Intern("float32")

var Lit_322 *jrt.String = jrt.Intern("!=")

var Lit_323 *jrt.String = jrt.Intern("Float32bits")

var Lit_324 *jrt.String = jrt.Intern("A2g_AssertionsDisabled")

var Lit_325 *jrt.String = jrt.Intern("A2g_NotTranslated")

var Lit_326 *jrt.String = jrt.Intern("Throwable_I")

var Lit_327 *jrt.String = jrt.Intern("what")

var Lit_328 *jrt.String = jrt.Intern("UnsupportedOperationException_New_String")

var Lit_329 *jrt.String = jrt.Intern("Str")

var Lit_330 *jrt.String = jrt.Intern("A2g_Missing")

var Lit_331 *jrt.String = jrt.Intern("why")

var Lit_332 *jrt.String = jrt.Intern("Thrown")

var Lit_333 *jrt.String = jrt.Intern("A2g_NotNull")

var Lit_334 *jrt.String = jrt.Intern("A2g_Truth")

var Lit_335 *jrt.String = jrt.Intern("Boolean_Init")

var Lit_336 *jrt.String = jrt.Intern("Boolean_FALSE")

var Lit_337 *jrt.String = jrt.Intern("A2g_CastArray")

var Lit_338 *jrt.String = jrt.Intern("cls")

var Lit_339 *jrt.String = jrt.Intern("z")

var Lit_340 *jrt.String = jrt.Intern("zero")

var Lit_341 *jrt.String = jrt.Intern(".IsInstance_O__Z")

var Lit_342 *jrt.String = jrt.Intern("ClassCast")

var Lit_343 *jrt.String = jrt.Intern("assert")

var Lit_344 *jrt.String = jrt.Intern("A2g_Discard")

var Lit_345 *jrt.String = jrt.Intern("funcs")

var Lit_346 *jrt.String = jrt.Intern("scan-file")

var Lit_347 *jrt.String = jrt.Intern("A2g_PrintStackTraceWriter")

var Lit_348 *jrt.String = jrt.Intern(".Print_String__V")

var Lit_349 *jrt.String = jrt.Intern("w")

var Lit_350 *jrt.String = jrt.Intern("StackTraceString")

var Lit_351 *jrt.String = jrt.Intern("A2g_PrintStackTraceStream")

var Lit_352 *jrt.String = jrt.Intern("s")

var Lit_353 *jrt.String = jrt.Intern("A2g_SystemGetenv")

var Lit_354 *jrt.String = jrt.Intern("HashMap_New")

var Lit_355 *jrt.String = jrt.Intern("kv")

var Lit_356 *jrt.String = jrt.Intern(".Environ")

var Lit_357 *jrt.String = jrt.Intern("CurrentHost")

var Lit_358 *jrt.String = jrt.Intern("IndexByte")

var Lit_359 *jrt.String = jrt.Intern(">")

var Lit_360 *jrt.String = jrt.Intern(".Put_O_O__O")

var Lit_361 *jrt.String = jrt.Intern("Collections_UnmodifiableMap_Map__Map")

var Lit_362 *jrt.String = jrt.Intern("A2g_SystemGetProperties")

var Lit_363 *jrt.String = jrt.Intern("Properties_New")

var Lit_364 *jrt.String = jrt.Intern("k")

var Lit_365 *jrt.String = jrt.Intern("PropertyNames")

var Lit_366 *jrt.String = jrt.Intern("v")

var Lit_367 *jrt.String = jrt.Intern("System_GetProperty_String__String")

var Lit_368 *jrt.String = jrt.Intern(".SetProperty_String_String__O")

var Lit_369 *jrt.String = jrt.Intern("System_GetProperties__Properties")

var Lit_370 *jrt.String = jrt.Intern("System_in")

var Lit_371 *jrt.String = jrt.Intern("System_out")

var Lit_372 *jrt.String = jrt.Intern("System_err")

var Lit_373 *jrt.String = jrt.Intern("System_SetIn_InputStream__V")

var Lit_374 *jrt.String = jrt.Intern("in")

var Lit_375 *jrt.String = jrt.Intern("System_SetOut_PrintStream__V")

var Lit_376 *jrt.String = jrt.Intern("out")

var Lit_377 *jrt.String = jrt.Intern("System_SetErr_PrintStream__V")

var Lit_378 *jrt.String = jrt.Intern("err")

var Lit_379 *jrt.String = jrt.Intern("String_CASE_INSENSITIVE_ORDER")

var Lit_380 *jrt.String = jrt.Intern("init")

var Lit_381 *jrt.String = jrt.Intern("CaseInsensitiveComparator_Init")

var Lit_382 *jrt.String = jrt.Intern("CaseInsensitiveComparator_INSTANCE")

var Lit_383 *jrt.String = jrt.Intern("StandardStreams_In__InputStream")

var Lit_384 *jrt.String = jrt.Intern("StandardStreams_Out__PrintStream")

var Lit_385 *jrt.String = jrt.Intern("StandardStreams_Err__PrintStream")

var Lit_386 *jrt.String = jrt.Intern("StderrPrint")

var Lit_387 *jrt.String = jrt.Intern("host")

var Lit_388 *jrt.String = jrt.Intern(".Flush__V")

var Lit_389 *jrt.String = jrt.Intern("A2gCloner")

var Lit_390 *jrt.String = jrt.Intern("interface")

var Lit_391 *jrt.String = jrt.Intern("CloneShallow")

var Lit_392 *jrt.String = jrt.Intern("A2g_ObjectClone")

var Lit_393 *jrt.String = jrt.Intern(".CloneShallow")

var Lit_394 *jrt.String = jrt.Intern("decl")

var Lit_395 *jrt.String = jrt.Intern("inner-flags")

var Lit_396 *jrt.String = jrt.Intern("flags")

var Lit_397 *jrt.String = jrt.Intern("info")

var Lit_398 *jrt.String = jrt.Intern("top")

var Lit_399 *jrt.String = jrt.Intern("nesting")

var Lit_400 *jrt.String = jrt.Intern("class")

var Lit_401 *jrt.String = jrt.Intern("enum")

var Lit_402 *jrt.String = jrt.Intern("annotation")

var Lit_403 *jrt.String = jrt.Intern("record")

var Lit_404 *jrt.String = jrt.Intern("prim?")

var Lit_405 *jrt.String = jrt.Intern("inst")

var Lit_406 *jrt.String = jrt.Intern("pointer-desc?")

var Lit_407 *jrt.String = jrt.Intern("java-name")

var Lit_408 *jrt.String = jrt.Intern("archived-classes")

var Lit_409 *jrt.String = jrt.Intern("frequencies")

var Lit_410 *jrt.String = jrt.Intern("key")

var Lit_411 *jrt.String = jrt.Intern("to-array")

var Lit_412 *jrt.String = jrt.Intern("methods")

var Lit_413 *jrt.String = jrt.Intern("ctors")

var Lit_414 *jrt.String = jrt.Intern("fields")

var Lit_415 *jrt.String = jrt.Intern("cut")

var Lit_416 *jrt.String = jrt.Intern("keep-indexed")

var Lit_417 *jrt.String = jrt.Intern("case")

var Lit_418 *jrt.String = jrt.Intern("list*")

var Lit_419 *jrt.String = jrt.Intern("switch")

var Lit_420 *jrt.String = jrt.Intern("this")

var Lit_421 *jrt.String = jrt.Intern("body")

var Lit_422 *jrt.String = jrt.Intern("o")

var Lit_423 *jrt.String = jrt.Intern("get")

var Lit_424 *jrt.String = jrt.Intern("keep")

var Lit_425 *jrt.String = jrt.Intern("Cut")

var Lit_426 *jrt.String = jrt.Intern("Data")

var Lit_427 *jrt.String = jrt.Intern("join")

var Lit_428 *jrt.String = jrt.Intern("Invoke")

var Lit_429 *jrt.String = jrt.Intern("New")

var Lit_430 *jrt.String = jrt.Intern("Get")

var Lit_431 *jrt.String = jrt.Intern("Set")

var Lit_432 *jrt.String = jrt.Intern("has?")

var Lit_433 *jrt.String = jrt.Intern("class-val")

var Lit_434 *jrt.String = jrt.Intern("static?")

var Lit_435 *jrt.String = jrt.Intern("arg-conv")

var Lit_436 *jrt.String = jrt.Intern("aget")

var Lit_437 *jrt.String = jrt.Intern("dotted-desc")

var Lit_438 *jrt.String = jrt.Intern("result-any")

var Lit_439 *jrt.String = jrt.Intern("*absent-members*")

var Lit_440 *jrt.String = jrt.Intern("prim-desc->name")

var Lit_441 *jrt.String = jrt.Intern("array?")

var Lit_442 *jrt.String = jrt.Intern("desc->internal")

var Lit_443 *jrt.String = jrt.Intern("jvm")

var Lit_444 *jrt.String = jrt.Intern("ctor-real-desc")

var Lit_445 *jrt.String = jrt.Intern("new-name")

var Lit_446 *jrt.String = jrt.Intern("volatile-field?")

var Lit_447 *jrt.String = jrt.Intern("const-value")

var Lit_448 *jrt.String = jrt.Intern("static-field-name")

var Lit_449 *jrt.String = jrt.Intern("field-name")

var Lit_450 *jrt.String = jrt.Intern("volatile-read")

var Lit_451 *jrt.String = jrt.Intern("volatile-write")

var Lit_452 *jrt.String = jrt.Intern("class-methods")

var Lit_453 *jrt.String = jrt.Intern("juxt")

var Lit_454 *jrt.String = jrt.Intern("method-order")

var Lit_455 *jrt.String = jrt.Intern("=")

var Lit_456 *jrt.String = jrt.Intern("count")

var Lit_457 *jrt.String = jrt.Intern("mms")

var Lit_458 *jrt.String = jrt.Intern("class-fields")

var Lit_459 *jrt.String = jrt.Intern("super")

var Lit_460 *jrt.String = jrt.Intern("reflected")

var Lit_461 *jrt.String = jrt.Intern("member-tables")

var Lit_462 *jrt.String = jrt.Intern("outer")

var Lit_463 *jrt.String = jrt.Intern("member")

var Lit_464 *jrt.String = jrt.Intern("simple")

var Lit_465 *jrt.String = jrt.Intern("simple-name-of")

var Lit_466 *jrt.String = jrt.Intern("in-world?")

var Lit_467 *jrt.String = jrt.Intern("interfaces")

var Lit_468 *jrt.String = jrt.Intern("member-table-form")

var Lit_469 *jrt.String = jrt.Intern("aot")

var Lit_470 *jrt.String = jrt.Intern("source")

var Lit_471 *jrt.String = jrt.Intern("modifiers")

var Lit_472 *jrt.String = jrt.Intern("kind-sym")

var Lit_473 *jrt.String = jrt.Intern("Declaring")

var Lit_474 *jrt.String = jrt.Intern("Simple")

var Lit_475 *jrt.String = jrt.Intern("Source")

var Lit_476 *jrt.String = jrt.Intern(".-IsInstance")

var Lit_477 *jrt.String = jrt.Intern(".-Init")

var Lit_478 *jrt.String = jrt.Intern(".-Enum")

var Lit_479 *jrt.String = jrt.Intern(".-Table")

var Lit_480 *jrt.String = jrt.Intern("reflect")

var Lit_481 *jrt.String = jrt.Intern("TypeFor")

var Lit_482 *jrt.String = jrt.Intern("MethodInfo")

var Lit_483 *jrt.String = jrt.Intern("Params")

var Lit_484 *jrt.String = jrt.Intern("Return")

var Lit_485 *jrt.String = jrt.Intern("As")

var Lit_486 *jrt.String = jrt.Intern("String_class")

var Lit_487 *jrt.String = jrt.Intern(".ArrayClass")

var Lit_488 *jrt.String = jrt.Intern("Object_class")

var Lit_489 *jrt.String = jrt.Intern("Locale_class")

var Lit_490 *jrt.String = jrt.Intern(".Formatted_O1__String")

var Lit_491 *jrt.String = jrt.Intern("Stream_class")

var Lit_492 *jrt.String = jrt.Intern(".Lines__Stream")

var Lit_493 *jrt.String = jrt.Intern("Optional_class")

var Lit_494 *jrt.String = jrt.Intern(".DescribeConstable__Optional")

var Lit_495 *jrt.String = jrt.Intern("Iterable_class")

var Lit_496 *jrt.String = jrt.Intern("Prim_boolean")

var Lit_497 *jrt.String = jrt.Intern(".Matches_String__Z")

var Lit_498 *jrt.String = jrt.Intern(".ReplaceAll_String_String__String")

var Lit_499 *jrt.String = jrt.Intern(".ReplaceFirst_String_String__String")

var Lit_500 *jrt.String = jrt.Intern(".Split_String__String1")

var Lit_501 *jrt.String = jrt.Intern("Prim_int")

var Lit_502 *jrt.String = jrt.Intern(".Split_String_I__String1")

var Lit_503 *jrt.String = jrt.Intern(".-Methods")

var Lit_504 *jrt.String = jrt.Intern("System_class")

var Lit_505 *jrt.String = jrt.Intern("getenv")

var Lit_506 *jrt.String = jrt.Intern("Map_class")

var Lit_507 *jrt.String = jrt.Intern("File")

var Lit_508 *jrt.String = jrt.Intern("getProperties")

var Lit_509 *jrt.String = jrt.Intern("Properties_class")

var Lit_510 *jrt.String = jrt.Intern(".-Fields")

var Lit_511 *jrt.String = jrt.Intern("FieldInfo")

var Lit_512 *jrt.String = jrt.Intern("CASE_INSENSITIVE_ORDER")

var Lit_513 *jrt.String = jrt.Intern("Type")

var Lit_514 *jrt.String = jrt.Intern("Comparator_class")

var Lit_515 *jrt.String = jrt.Intern("Throwable_class")

var Lit_516 *jrt.String = jrt.Intern("PrintStream_class")

var Lit_517 *jrt.String = jrt.Intern("Prim_void")

var Lit_518 *jrt.String = jrt.Intern("do")

var Lit_519 *jrt.String = jrt.Intern("PrintStream_Cast")

var Lit_520 *jrt.String = jrt.Intern("PrintWriter_class")

var Lit_521 *jrt.String = jrt.Intern("PrintWriter_Cast")

var Lit_522 *jrt.String = jrt.Intern("Runtime_class")

var Lit_523 *jrt.String = jrt.Intern("Process_class")

var Lit_524 *jrt.String = jrt.Intern("RuntimeExec_Exec_String__Process")

var Lit_525 *jrt.String = jrt.Intern("RuntimeExec_Exec_String_String1__Process")

var Lit_526 *jrt.String = jrt.Intern("File_class")

var Lit_527 *jrt.String = jrt.Intern("RuntimeExec_Exec_String_String1_File__Process")

var Lit_528 *jrt.String = jrt.Intern("RuntimeExec_Exec_String1__Process")

var Lit_529 *jrt.String = jrt.Intern("RuntimeExec_Exec_String1_String1__Process")

var Lit_530 *jrt.String = jrt.Intern("RuntimeExec_Exec_String1_String1_File__Process")

var Lit_531 *jrt.String = jrt.Intern("Thread_class")

var Lit_532 *jrt.String = jrt.Intern("ClassLoader_class")

var Lit_533 *jrt.String = jrt.Intern("ClassLoader_GetSystemClassLoader__ClassLoader")

var Lit_534 *jrt.String = jrt.Intern("URL_class")

var Lit_535 *jrt.String = jrt.Intern("ClassPathResources_GetResource_ClassLoader_String__URL")

var Lit_536 *jrt.String = jrt.Intern("ClassLoader_I")

var Lit_537 *jrt.String = jrt.Intern("Enumeration_class")

var Lit_538 *jrt.String = jrt.Intern("ClassPathResources_GetResources_ClassLoader_String__Enumeration")

var Lit_539 *jrt.String = jrt.Intern("Collections_EmptyEnumeration__Enumeration")

var Lit_540 *jrt.String = jrt.Intern("InputStream_class")

var Lit_541 *jrt.String = jrt.Intern("Date_class")

var Lit_542 *jrt.String = jrt.Intern("Instant_class")

var Lit_543 *jrt.String = jrt.Intern("exc")

var Lit_544 *jrt.String = jrt.Intern("results")

var Lit_545 *jrt.String = jrt.Intern("defer")

var Lit_546 *jrt.String = jrt.Intern("Catch")

var Lit_547 *jrt.String = jrt.Intern("Date_New_J")

var Lit_548 *jrt.String = jrt.Intern(".ToEpochMilli__J")

var Lit_549 *jrt.String = jrt.Intern("Instant")

var Lit_550 *jrt.String = jrt.Intern("ArithmeticException_InstanceOf")

var Lit_551 *jrt.String = jrt.Intern("IllegalArgumentException_New_Throwable")

var Lit_552 *jrt.String = jrt.Intern("Instant_OfEpochMilli_J__Instant")

var Lit_553 *jrt.String = jrt.Intern(".GetTime__J")

var Lit_554 *jrt.String = jrt.Intern("Date_I")

var Lit_555 *jrt.String = jrt.Intern(".Ref")

var Lit_556 *jrt.String = jrt.Intern("InputStream_Cast")

var Lit_557 *jrt.String = jrt.Intern("cut-type-expr")

var Lit_558 *jrt.String = jrt.Intern("lang")

var Lit_559 *jrt.String = jrt.Intern("vars")

var Lit_560 *jrt.String = jrt.Intern("const")

var Lit_561 *jrt.String = jrt.Intern("int16")

var Lit_562 *jrt.String = jrt.Intern("mods")

var Lit_563 *jrt.String = jrt.Intern("params")

var Lit_564 *jrt.String = jrt.Intern("ret")

var Lit_565 *jrt.String = jrt.Intern("java.lang.String")

var Lit_566 *jrt.String = jrt.Intern("every?")

var Lit_567 *jrt.String = jrt.Intern("cut-constant")

var Lit_568 *jrt.String = jrt.Intern("cut-class-members")

var Lit_569 *jrt.String = jrt.Intern("re-find")

var Lit_570 *jrt.String = jrt.Intern("[_$]")

var Lit_571 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms")

var Lit_572 *jrt.String = jrt.Intern("_Fn")

var Lit_573 *jrt.String = jrt.Intern("V")

var Lit_574 *jrt.String = jrt.Intern("---- the lambda adapter of ")

var Lit_575 *jrt.String = jrt.Intern("Object")

var Lit_576 *jrt.String = jrt.Intern("_class")

var Lit_577 *jrt.String = jrt.Intern("Object_toString")

var Lit_578 *jrt.String = jrt.Intern("CloneNotSupported")

var Lit_579 *jrt.String = jrt.Intern("Define")

var Lit_580 *jrt.String = jrt.Intern("ClassInfo")

var Lit_581 *jrt.String = jrt.Intern("$$Lambda")

var Lit_582 *jrt.String = jrt.Intern("KindClass")

var Lit_583 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$fn__1579000175")

var Lit_584 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$fn__1579000187")

var Lit_585 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$fn__1579000189")

var Lit_586 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$fn__1579000191")

var Lit_587 *jrt.String = jrt.Intern(" & ")

var Lit_588 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$fn__1579000194")

var Lit_589 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$fn__1579000206")

var Lit_590 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$fn__1579000262")

var Lit_591 *jrt.String = jrt.Intern("$")

var Lit_592 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$fn__1579000264")

var Lit_593 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000177__1579000181")

var Lit_594 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000177__1579000181$fn__1579000182")

var Lit_595 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000177__1579000181$fn__1579000182$fn__1579000183")

var Lit_596 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000196__1579000200")

var Lit_597 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000196__1579000200$fn__1579000201")

var Lit_598 *jrt.String = jrt.Intern("Is_")

var Lit_599 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000196__1579000200$fn__1579000201$fn__1579000202")

var Lit_600 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000208__1579000212")

var Lit_601 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000208__1579000212$fn__1579000213")

var Lit_602 *jrt.String = jrt.Intern("abstract ")

var Lit_603 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000208__1579000212$fn__1579000213$fn__1579000214")

var Lit_604 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000208__1579000212$fn__1579000213$fn__1579000214$fn__1579000235")

var Lit_605 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000208__1579000212$fn__1579000213$fn__1579000214$iter__1579000224__1579000228")

var Lit_606 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000208__1579000212$fn__1579000213$fn__1579000214$iter__1579000224__1579000228$fn__1579000229")

var Lit_607 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000208__1579000212$fn__1579000213$fn__1579000214$iter__1579000224__1579000228$fn__1579000229$fn__1579000230")

var Lit_608 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000208__1579000212$fn__1579000213$fn__1579000258")

var Lit_609 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000208__1579000212$fn__1579000213$iter__1579000247__1579000251")

var Lit_610 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000208__1579000212$fn__1579000213$iter__1579000247__1579000251$fn__1579000252")

var Lit_611 *jrt.String = jrt.Intern("arbace.a2g.out$adapter_forms$iter__1579000208__1579000212$fn__1579000213$iter__1579000247__1579000251$fn__1579000252$fn__1579000253")

var Lit_612 *jrt.String = jrt.Intern("arbace.a2g.out$arg_conv")

var Lit_613 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_614 *jrt.String = jrt.Intern("arbace.a2g.out$class_registration")

var Lit_615 *jrt.String = jrt.Intern("_members")

var Lit_616 *jrt.String = jrt.Intern("MemberTable")

var Lit_617 *jrt.String = jrt.Intern("L")

var Lit_618 *jrt.String = jrt.Intern(";")

var Lit_619 *jrt.String = jrt.Intern("")

var Lit_620 *jrt.String = jrt.Intern("_InstanceOf")

var Lit_621 *jrt.String = jrt.Intern("_Init")

var Lit_622 *jrt.String = jrt.Intern("__VALUES")

var Lit_623 *jrt.String = jrt.Intern("RegisterGoType")

var Lit_624 *jrt.String = jrt.Intern("arbace.a2g.out$class_registration$fn__1579000588")

var Lit_625 *jrt.String = jrt.Intern("arbace.a2g.out$class_registration$up__1579000583")

var Lit_626 *jrt.String = jrt.Intern("arbace.a2g.out$clean")

var Lit_627 *jrt.String = jrt.Intern("arbace.a2g.out$clean$cm__1579000013")

var Lit_628 *jrt.String = jrt.Intern("arbace.a2g.out$clean$fn__1579000016")

var Lit_629 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members")

var Lit_630 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$desc__1579000616")

var Lit_631 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$fn__1579000614")

var Lit_632 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$fn__1579000628")

var Lit_633 *jrt.String = jrt.Intern(" ")

var Lit_634 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$fn__1579000660")

var Lit_635 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$fn__1579000672")

var Lit_636 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$iter__1579000618__1579000622")

var Lit_637 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$iter__1579000618__1579000622$fn__1579000623")

var Lit_638 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$iter__1579000618__1579000622$fn__1579000623$fn__1579000624")

var Lit_639 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$iter__1579000630__1579000634")

var Lit_640 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$iter__1579000630__1579000634$fn__1579000635")

var Lit_641 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$iter__1579000630__1579000634$fn__1579000635$fn__1579000636")

var Lit_642 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$iter__1579000630__1579000634$fn__1579000635$fn__1579000636$fn__1579000637")

var Lit_643 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$iter__1579000630__1579000634$fn__1579000635$fn__1579000648")

var Lit_644 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$iter__1579000662__1579000666")

var Lit_645 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$iter__1579000662__1579000666$fn__1579000667")

var Lit_646 *jrt.String = jrt.Intern("arbace.a2g.out$cut_class_members$iter__1579000662__1579000666$fn__1579000667$fn__1579000668")

var Lit_647 *jrt.String = jrt.Intern("arbace.a2g.out$cut_constant")

var Lit_648 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_649 *jrt.String = jrt.Intern("B")

var Lit_650 *jrt.String = jrt.Intern("C")

var Lit_651 *jrt.String = jrt.Intern("I")

var Lit_652 *jrt.String = jrt.Intern("J")

var Lit_653 *jrt.String = jrt.Intern("S")

var Lit_654 *jrt.String = jrt.Intern("Z")

var Lit_655 *jrt.String = jrt.Intern("arbace.a2g.out$cut_forms")

var Lit_656 *jrt.String = jrt.Intern("arbace.a2g.out$cut_forms$iter__1579000591__1579000595")

var Lit_657 *jrt.String = jrt.Intern("arbace.a2g.out$cut_forms$iter__1579000591__1579000595$fn__1579000596")

var Lit_658 *jrt.String = jrt.Intern("KindInterface")

var Lit_659 *jrt.String = jrt.Intern(" (cut)")

var Lit_660 *jrt.String = jrt.Intern("arbace.a2g.out$cut_forms$iter__1579000591__1579000595$fn__1579000596$fn__1579000597")

var Lit_661 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms")

var Lit_662 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$dotted__1579000676")

var Lit_663 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$fn__1579000783")

var Lit_664 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684")

var Lit_665 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685")

var Lit_666 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$fn__1579000686")

var Lit_667 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$fn__1579000686$fn__1579000687")

var Lit_668 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$fn__1579000686$iter__1579000691__1579000695")

var Lit_669 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$fn__1579000686$iter__1579000691__1579000695$fn__1579000696")

var Lit_670 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$fn__1579000686$iter__1579000691__1579000695$fn__1579000696$fn__1579000697")

var Lit_671 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$fn__1579000686$iter__1579000705__1579000709")

var Lit_672 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$fn__1579000686$iter__1579000705__1579000709$fn__1579000710")

var Lit_673 *jrt.String = jrt.Intern("G")

var Lit_674 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$fn__1579000686$iter__1579000705__1579000709$fn__1579000710$fn__1579000711")

var Lit_675 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$fn__1579000686$iter__1579000719__1579000723")

var Lit_676 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$fn__1579000686$iter__1579000719__1579000723$fn__1579000724")

var Lit_677 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$fn__1579000686$iter__1579000719__1579000723$fn__1579000724$fn__1579000725")

var Lit_678 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$fn__1579000686$texpr__1579000689")

var Lit_679 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$fn__1579000734")

var Lit_680 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$iter__1579000738__1579000742")

var Lit_681 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$iter__1579000738__1579000742$fn__1579000743")

var Lit_682 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$iter__1579000738__1579000742$fn__1579000743$fn__1579000744")

var Lit_683 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$iter__1579000752__1579000756")

var Lit_684 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$iter__1579000752__1579000756$fn__1579000757")

var Lit_685 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$iter__1579000752__1579000756$fn__1579000757$fn__1579000758")

var Lit_686 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$iter__1579000766__1579000770")

var Lit_687 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$iter__1579000766__1579000770$fn__1579000771")

var Lit_688 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$iter__1579000766__1579000770$fn__1579000771$fn__1579000772")

var Lit_689 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000680__1579000684$fn__1579000685$texpr__1579000736")

var Lit_690 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000791__1579000795")

var Lit_691 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000791__1579000795$fn__1579000796")

var Lit_692 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$iter__1579000791__1579000795$fn__1579000796$fn__1579000797")

var Lit_693 *jrt.String = jrt.Intern("arbace.a2g.out$cut_table_forms$mdesc__1579000678")

var Lit_694 *jrt.String = jrt.Intern("(")

var Lit_695 *jrt.String = jrt.Intern(")")

var Lit_696 *jrt.String = jrt.Intern("arbace.a2g.out$cut_type_expr")

var Lit_697 *jrt.String = jrt.Intern("Prim_")

var Lit_698 *jrt.String = jrt.Intern("jrt/")

var Lit_699 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_700 *jrt.String = jrt.Intern("arbace.a2g.out$dotted_desc")

var Lit_701 *jrt.String = jrt.Intern("arbace.a2g.out$eval1579000004$loading__1927001464__auto____1579000005")

var Lit_702 *jrt.String = jrt.Intern("arbace.a2g.out$eval1579000008$fn__1579000009")

var Lit_703 *jrt.String = jrt.Intern("arbace.a2g.out$file_text")

var Lit_704 *jrt.String = jrt.Intern("arbace.a2g.out$file_text$fn__1579000099")

var Lit_705 *jrt.String = jrt.Intern(";; Generated by a2g (arbace/a2g, doc/go/A2G-SPEC.md); do not edit.\n")

var Lit_706 *jrt.String = jrt.Intern("(in-ns '")

var Lit_707 *jrt.String = jrt.Intern(")\n\n")

var Lit_708 *jrt.String = jrt.Intern("\n")

var Lit_709 *jrt.String = jrt.Intern("\n;; ")

var Lit_710 *jrt.String = jrt.Intern("arbace.a2g.out$file_text$fn__1579000099$line_of__1579000104")

var Lit_711 *jrt.String = jrt.Intern("arbace.a2g.out$file_text$iter__1579000089__1579000093")

var Lit_712 *jrt.String = jrt.Intern("arbace.a2g.out$file_text$iter__1579000089__1579000093$fn__1579000094")

var Lit_713 *jrt.String = jrt.Intern("arbace.a2g.out$file_text$iter__1579000089__1579000093$fn__1579000094$fn__1579000095")

var Lit_714 *jrt.String = jrt.Intern("arbace.a2g.out$file_text$path_of__1579000087")

var Lit_715 *jrt.String = jrt.Intern("arbace.a2g.out$fjp_support_forms")

var Lit_716 *jrt.String = jrt.Intern("java/util/concurrent/ExecutorService")

var Lit_717 *jrt.String = jrt.Intern("java/util/concurrent/ForkJoinPool")

var Lit_718 *jrt.String = jrt.Intern("arbace.a2g.out$fjp_support_forms$iter__1579000338__1579000342")

var Lit_719 *jrt.String = jrt.Intern("arbace.a2g.out$fjp_support_forms$iter__1579000338__1579000342$fn__1579000343")

var Lit_720 *jrt.String = jrt.Intern("arbace.a2g.out$fjp_support_forms$iter__1579000338__1579000342$fn__1579000343$fn__1579000344")

var Lit_721 *jrt.String = jrt.Intern("arbace.a2g.out$fjp_support_forms$iter__1579000338__1579000342$fn__1579000343$fn__1579000344$fn__1579000364")

var Lit_722 *jrt.String = jrt.Intern("arbace.a2g.out$fjp_support_forms$iter__1579000338__1579000342$fn__1579000343$fn__1579000344$iter__1579000354__1579000358")

var Lit_723 *jrt.String = jrt.Intern("arbace.a2g.out$fjp_support_forms$iter__1579000338__1579000342$fn__1579000343$fn__1579000344$iter__1579000354__1579000358$fn__1579000359")

var Lit_724 *jrt.String = jrt.Intern("arbace.a2g.out$fjp_support_forms$iter__1579000338__1579000342$fn__1579000343$fn__1579000344$iter__1579000354__1579000358$fn__1579000359$fn__1579000360")

var Lit_725 *jrt.String = jrt.Intern("arbace.a2g.out$fjp_support_forms$iter__1579000338__1579000342$fn__1579000343$fn__1579000386")

var Lit_726 *jrt.String = jrt.Intern("arbace.a2g.out$fjp_support_forms$iter__1579000338__1579000342$fn__1579000343$iter__1579000376__1579000380")

var Lit_727 *jrt.String = jrt.Intern("arbace.a2g.out$fjp_support_forms$iter__1579000338__1579000342$fn__1579000343$iter__1579000376__1579000380$fn__1579000381")

var Lit_728 *jrt.String = jrt.Intern("arbace.a2g.out$fjp_support_forms$iter__1579000338__1579000342$fn__1579000343$iter__1579000376__1579000380$fn__1579000381$fn__1579000382")

var Lit_729 *jrt.String = jrt.Intern("arbace.a2g.out$fjp_support_key")

var Lit_730 *jrt.String = jrt.Intern("(Ljava/util/concurrent/ForkJoinPool;")

var Lit_731 *jrt.String = jrt.Intern("arbace.a2g.out$form_text")

var Lit_732 *jrt.String = jrt.Intern("arbace.a2g.out$form_text$fn__1579000060")

var Lit_733 *jrt.String = jrt.Intern("arbace.a2g.out$frames_forms")

var Lit_734 *jrt.String = jrt.Intern("RegisterFrames")

var Lit_735 *jrt.String = jrt.Intern("FrameInfo")

var Lit_736 *jrt.String = jrt.Intern("arbace.a2g.out$frames_forms$iter__1579000808__1579000814")

var Lit_737 *jrt.String = jrt.Intern("arbace.a2g.out$frames_forms$iter__1579000808__1579000814$fn__1579000815")

var Lit_738 *jrt.String = jrt.Intern("arbace.a2g.out$frames_forms$iter__1579000808__1579000814$fn__1579000815$iter__1579000810__1579000816")

var Lit_739 *jrt.String = jrt.Intern("arbace.a2g.out$frames_forms$iter__1579000808__1579000814$fn__1579000815$iter__1579000810__1579000816$fn__1579000817")

var Lit_740 *jrt.String = jrt.Intern("<init>")

var Lit_741 *jrt.String = jrt.Intern("(*")

var Lit_742 *jrt.String = jrt.Intern(").")

var Lit_743 *jrt.String = jrt.Intern(").Impl_")

var Lit_744 *jrt.String = jrt.Intern("arbace.a2g.out$frames_forms$iter__1579000808__1579000814$fn__1579000815$iter__1579000810__1579000816$fn__1579000817$fn__1579000818")

var Lit_745 *jrt.String = jrt.Intern("arbace.a2g.out$go_file_name")

var Lit_746 *jrt.String = jrt.Intern(".go")

var Lit_747 *jrt.String = jrt.Intern("_a2g")

var Lit_748 *jrt.String = jrt.Intern("arbace.a2g.out$java_name")

var Lit_749 *jrt.String = jrt.Intern("arbace.a2g.out$jrt_default_forwarders")

var Lit_750 *jrt.String = jrt.Intern("arbace.a2g.out$jrt_default_forwarders$iter__1579000270__1579000276")

var Lit_751 *jrt.String = jrt.Intern("arbace.a2g.out$jrt_default_forwarders$iter__1579000270__1579000276$fn__1579000277")

var Lit_752 *jrt.String = jrt.Intern("arbace.a2g.out$jrt_default_forwarders$iter__1579000270__1579000276$fn__1579000277$iter__1579000272__1579000278")

var Lit_753 *jrt.String = jrt.Intern("arbace.a2g.out$jrt_default_forwarders$iter__1579000270__1579000276$fn__1579000277$iter__1579000272__1579000278$fn__1579000279")

var Lit_754 *jrt.String = jrt.Intern("arbace.a2g.out$jrt_default_forwarders$iter__1579000270__1579000276$fn__1579000277$iter__1579000272__1579000278$fn__1579000279$fn__1579000280")

var Lit_755 *jrt.String = jrt.Intern("arbace.a2g.out$jrt_default_forwarders$iter__1579000270__1579000276$fn__1579000277$iter__1579000272__1579000278$fn__1579000279$fn__1579000280$fn__1579000301")

var Lit_756 *jrt.String = jrt.Intern("arbace.a2g.out$jrt_default_forwarders$iter__1579000270__1579000276$fn__1579000277$iter__1579000272__1579000278$fn__1579000279$fn__1579000280$iter__1579000290__1579000294")

var Lit_757 *jrt.String = jrt.Intern("arbace.a2g.out$jrt_default_forwarders$iter__1579000270__1579000276$fn__1579000277$iter__1579000272__1579000278$fn__1579000279$fn__1579000280$iter__1579000290__1579000294$fn__1579000295")

var Lit_758 *jrt.String = jrt.Intern("arbace.a2g.out$jrt_default_forwarders$iter__1579000270__1579000276$fn__1579000277$iter__1579000272__1579000278$fn__1579000279$fn__1579000280$iter__1579000290__1579000294$fn__1579000295$fn__1579000296")

var Lit_759 *jrt.String = jrt.Intern("arbace.a2g.out$jrt_default_forwarders$iter__1579000270__1579000276$fn__1579000277$iter__1579000272__1579000278$fn__1579000279$fn__1579000324")

var Lit_760 *jrt.String = jrt.Intern("arbace.a2g.out$jrt_default_forwarders$iter__1579000270__1579000276$fn__1579000277$iter__1579000272__1579000278$fn__1579000279$iter__1579000313__1579000317")

var Lit_761 *jrt.String = jrt.Intern("arbace.a2g.out$jrt_default_forwarders$iter__1579000270__1579000276$fn__1579000277$iter__1579000272__1579000278$fn__1579000279$iter__1579000313__1579000317$fn__1579000318")

var Lit_762 *jrt.String = jrt.Intern("arbace.a2g.out$jrt_default_forwarders$iter__1579000270__1579000276$fn__1579000277$iter__1579000272__1579000278$fn__1579000279$iter__1579000313__1579000317$fn__1579000318$fn__1579000319")

var Lit_763 *jrt.String = jrt.Intern("arbace.a2g.out$kind_sym")

var Lit_764 *jrt.String = jrt.Intern("KindEnum")

var Lit_765 *jrt.String = jrt.Intern("KindAnnotation")

var Lit_766 *jrt.String = jrt.Intern("KindRecord")

var Lit_767 *jrt.String = jrt.Intern("arbace.a2g.out$lined_QMARK_")

var Lit_768 *jrt.String = jrt.Intern("arbace.a2g.out$lined_QMARK_$fn__1579000069")

var Lit_769 *jrt.String = jrt.Intern("arbace.a2g.out$lined_QMARK_$lined_meta_QMARK___1579000066")

var Lit_770 *jrt.String = jrt.Intern("arbace.a2g.out$member_table_form")

var Lit_771 *jrt.String = jrt.Intern("invoke")

var Lit_772 *jrt.String = jrt.Intern("new")

var Lit_773 *jrt.String = jrt.Intern("arbace.a2g.out$member_table_form$dispatch__1579000440")

var Lit_774 *jrt.String = jrt.Intern("arbace.a2g.out$member_table_form$dispatch__1579000440$fn__1579000441")

var Lit_775 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables")

var Lit_776 *jrt.String = jrt.Intern("_I")

var Lit_777 *jrt.String = jrt.Intern("Assert failed: ")

var Lit_778 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$cls__1579000449")

var Lit_779 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$fn__1579000511")

var Lit_780 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$fn__1579000514")

var Lit_781 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$fn__1579000520")

var Lit_782 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$fn__1579000520$fn__1579000524")

var Lit_783 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$fn__1579000527")

var Lit_784 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000451__1579000455")

var Lit_785 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000451__1579000455$fn__1579000456")

var Lit_786 *jrt.String = jrt.Intern("M")

var Lit_787 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000451__1579000455$fn__1579000456$fn__1579000457")

var Lit_788 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000451__1579000455$fn__1579000456$fn__1579000457$fn__1579000461")

var Lit_789 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000451__1579000455$fn__1579000456$fn__1579000467")

var Lit_790 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000471__1579000475")

var Lit_791 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000471__1579000475$fn__1579000476")

var Lit_792 *jrt.String = jrt.Intern("<clinit>")

var Lit_793 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000471__1579000475$fn__1579000476$fn__1579000477")

var Lit_794 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000487__1579000491")

var Lit_795 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000487__1579000491$fn__1579000492")

var Lit_796 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000487__1579000491$fn__1579000492$fn__1579000493")

var Lit_797 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000497__1579000501")

var Lit_798 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000497__1579000501$fn__1579000502")

var Lit_799 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000497__1579000501$fn__1579000502$fn__1579000503")

var Lit_800 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000529__1579000533")

var Lit_801 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000529__1579000533$fn__1579000534")

var Lit_802 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000529__1579000533$fn__1579000534$fn__1579000535")

var Lit_803 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000545__1579000549")

var Lit_804 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000545__1579000549$fn__1579000550")

var Lit_805 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000545__1579000549$fn__1579000550$fn__1579000551")

var Lit_806 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000545__1579000549$fn__1579000550$fn__1579000551$fn__1579000558")

var Lit_807 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000545__1579000549$fn__1579000550$fn__1579000567")

var Lit_808 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000571__1579000575")

var Lit_809 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000571__1579000575$fn__1579000576")

var Lit_810 *jrt.String = jrt.Intern(".-")

var Lit_811 *jrt.String = jrt.Intern(".Self_")

var Lit_812 *jrt.String = jrt.Intern("F")

var Lit_813 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$iter__1579000571__1579000575$fn__1579000576$fn__1579000577")

var Lit_814 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$jname__1579000507")

var Lit_815 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$jparams__1579000509")

var Lit_816 *jrt.String = jrt.Intern("arbace.a2g.out$member_tables$public_QMARK___1579000447")

var Lit_817 *jrt.String = jrt.Intern("arbace.a2g.out$method_order")

var Lit_818 *jrt.String = jrt.Intern("arbace.a2g.out$method_order$fn__1579000399")

var Lit_819 *jrt.String = jrt.Intern("arbace.a2g.out$method_order$fn__1579000401")

var Lit_820 *jrt.String = jrt.Intern("arbace.a2g.out$method_order$fn__1579000401$fn__1579000402")

var Lit_821 *jrt.String = jrt.Intern("arbace.a2g.out$method_order$iter__1579000405__1579000409")

var Lit_822 *jrt.String = jrt.Intern("arbace.a2g.out$method_order$iter__1579000405__1579000409$fn__1579000410")

var Lit_823 *jrt.String = jrt.Intern("arbace.a2g.out$method_order$iter__1579000405__1579000409$fn__1579000410$fn__1579000411")

var Lit_824 *jrt.String = jrt.Intern("arbace.a2g.out$method_order$iter__1579000421__1579000425")

var Lit_825 *jrt.String = jrt.Intern("arbace.a2g.out$method_order$iter__1579000421__1579000425$fn__1579000426")

var Lit_826 *jrt.String = jrt.Intern("arbace.a2g.out$method_order$iter__1579000421__1579000425$fn__1579000426$fn__1579000427")

var Lit_827 *jrt.String = jrt.Intern("arbace.a2g.out$method_order$iter__1579000421__1579000425$fn__1579000426$fn__1579000427$fn__1579000428")

var Lit_828 *jrt.String = jrt.Intern("arbace.a2g.out$method_order$iter__1579000421__1579000425$fn__1579000426$fn__1579000431")

var Lit_829 *jrt.String = jrt.Intern("arbace.a2g.out$modifiers")

var Lit_830 *jrt.String = jrt.Intern("arbace.a2g.out$out_BANG_")

var Lit_831 *jrt.String = jrt.Intern("arbace.a2g.out$out_BANG_$fn__1579000023")

var Lit_832 *jrt.String = jrt.Intern("arbace.a2g.out$result_any")

var Lit_833 *jrt.String = jrt.Intern("arbace.a2g.out$strings_forms")

var Lit_834 *jrt.String = jrt.Intern("arbace.a2g.out$strings_forms$fn__1579000138")

var Lit_835 *jrt.String = jrt.Intern("arbace.a2g.out$strings_forms$iter__1579000110__1579000114")

var Lit_836 *jrt.String = jrt.Intern("arbace.a2g.out$strings_forms$iter__1579000110__1579000114$fn__1579000115")

var Lit_837 *jrt.String = jrt.Intern("InternUTF16")

var Lit_838 *jrt.String = jrt.Intern("Intern")

var Lit_839 *jrt.String = jrt.Intern("arbace.a2g.out$strings_forms$iter__1579000110__1579000114$fn__1579000115$fn__1579000116")

var Lit_840 *jrt.String = jrt.Intern("arbace.a2g.out$strings_forms$iter__1579000110__1579000114$fn__1579000115$fn__1579000116$fn__1579000121")

var Lit_841 *jrt.String = jrt.Intern("arbace.a2g.out$strings_forms$iter__1579000110__1579000114$fn__1579000115$fn__1579000131")

var Lit_842 *jrt.String = jrt.Intern("arbace.a2g.out$support_forms")

var Lit_843 *jrt.String = jrt.Intern("java/lang/Boolean")

var Lit_844 *jrt.String = jrt.Intern("java/util/regex/Pattern")

var Lit_845 *jrt.String = jrt.Intern("java/util/Optional")

var Lit_846 *jrt.String = jrt.Intern("java/lang/constant/Constable")

var Lit_847 *jrt.String = jrt.Intern("java/util/stream/Stream")

var Lit_848 *jrt.String = jrt.Intern("java/util/ArrayList")

var Lit_849 *jrt.String = jrt.Intern("java/io/ByteArrayInputStream")

var Lit_850 *jrt.String = jrt.Intern("GetResourceAsStream_String__InputStream is Class.getResourceAsStream: the resource name\nresolved as Class.resolveName resolves it (absolute without its /, else in the package of the\nclass or of its arrays' element class), from the host's resources, as a ByteArrayInputStream; null\nwhen there is none.\n")

var Lit_851 *jrt.String = jrt.Intern("Ljava/io/InputStream;")

var Lit_852 *jrt.String = jrt.Intern("jdk/internal/jrt/DefaultZone")

var Lit_853 *jrt.String = jrt.Intern("a2g: not translated: ")

var Lit_854 *jrt.String = jrt.Intern("a2g: ")

var Lit_855 *jrt.String = jrt.Intern("java/util/Formatter")

var Lit_856 *jrt.String = jrt.Intern("go/arbace/jrt/string.ae")

var Lit_857 *jrt.String = jrt.Intern("java/lang/Iterable")

var Lit_858 *jrt.String = jrt.Intern("java/lang/CharSequence")

var Lit_859 *jrt.String = jrt.Intern("java/io/PrintWriter")

var Lit_860 *jrt.String = jrt.Intern("A2g_PrintStackTraceWriter is Throwable.printStackTrace(PrintWriter): the trace's text printed.\n")

var Lit_861 *jrt.String = jrt.Intern("Ljava/io/PrintWriter;")

var Lit_862 *jrt.String = jrt.Intern("java/io/PrintStream")

var Lit_863 *jrt.String = jrt.Intern("A2g_PrintStackTraceStream is Throwable.printStackTrace(PrintStream).\n")

var Lit_864 *jrt.String = jrt.Intern("Ljava/io/PrintStream;")

var Lit_865 *jrt.String = jrt.Intern("java/util/HashMap")

var Lit_866 *jrt.String = jrt.Intern("java/util/Collections")

var Lit_867 *jrt.String = jrt.Intern("A2g_SystemGetenv is System.getenv(): the host's environment as an unmodifiable map.\n")

var Lit_868 *jrt.String = jrt.Intern("Ljava/util/Map;")

var Lit_869 *jrt.String = jrt.Intern("java/util/Properties")

var Lit_870 *jrt.String = jrt.Intern("A2g_SystemGetProperties is System.getProperties(): a Properties with the system properties\n(a copy: the Go build keeps them in jrt's table, System.setProperty's).\n")

var Lit_871 *jrt.String = jrt.Intern("Ljava/util/Properties;")

var Lit_872 *jrt.String = jrt.Intern("System_GetProperties__Properties is System.getProperties() as translated code calls it\n(m/a2g-static?).\n")

var Lit_873 *jrt.String = jrt.Intern("jdk/internal/jrt/StandardStreams")

var Lit_874 *jrt.String = jrt.Intern("System_SetIn_InputStream__V is System.setIn.\n")

var Lit_875 *jrt.String = jrt.Intern("System_SetOut_PrintStream__V is System.setOut.\n")

var Lit_876 *jrt.String = jrt.Intern("System_SetErr_PrintStream__V is System.setErr.\n")

var Lit_877 *jrt.String = jrt.Intern("jdk/internal/jrt/CaseInsensitiveComparator")

var Lit_878 *jrt.String = jrt.Intern("Ljava/util/Comparator;")

var Lit_879 *jrt.String = jrt.Intern("arbace.a2g.out$support_table_forms")

var Lit_880 *jrt.String = jrt.Intern("formatted")

var Lit_881 *jrt.String = jrt.Intern("lines")

var Lit_882 *jrt.String = jrt.Intern("describeConstable")

var Lit_883 *jrt.String = jrt.Intern("matches")

var Lit_884 *jrt.String = jrt.Intern("replaceAll")

var Lit_885 *jrt.String = jrt.Intern("replaceFirst")

var Lit_886 *jrt.String = jrt.Intern("jdk/internal/jrt/RuntimeExec")

var Lit_887 *jrt.String = jrt.Intern("jdk/internal/jrt/ClassPathResources")

var Lit_888 *jrt.String = jrt.Intern("java/time/Instant")

var Lit_889 *jrt.String = jrt.Intern("printStackTrace")

var Lit_890 *jrt.String = jrt.Intern("exec")

var Lit_891 *jrt.String = jrt.Intern("getContextClassLoader")

var Lit_892 *jrt.String = jrt.Intern("setContextClassLoader")

var Lit_893 *jrt.String = jrt.Intern("getResource")

var Lit_894 *jrt.String = jrt.Intern("getResources")

var Lit_895 *jrt.String = jrt.Intern("getResourceAsStream")

var Lit_896 *jrt.String = jrt.Intern("from")

var Lit_897 *jrt.String = jrt.Intern("toInstant")

var Lit_898 *jrt.String = jrt.Intern("setErr")

var Lit_899 *jrt.String = jrt.Intern("setIn")

var Lit_900 *jrt.String = jrt.Intern("setOut")

var Lit_901 *jrt.String = jrt.Intern("arbace.a2g.out$support_table_forms$sig__1579000602")

var Lit_902 *jrt.String = jrt.Intern("arbace.a2g.out$tag")

var Lit_903 *jrt.String = jrt.Intern("arbace.a2g.out$unlined_texts")

var Lit_904 *jrt.String = jrt.Intern("arbace.a2g.out$unlined_texts$fn__1579000079")

var Lit_905 *jrt.String = jrt.Intern("arbace.a2g.out$unlined_texts$one__1579000075")

var Lit_906 *jrt.String = jrt.Intern("arbace.a2g.out$unlined_texts$one__1579000075$fn__1579000076")

var Lit_907 *jrt.String = jrt.Intern("arbace.a2g.out$ups_forms")

var Lit_908 *jrt.String = jrt.Intern("arbace.a2g.out$ups_forms$iter__1579000141__1579000145")

var Lit_909 *jrt.String = jrt.Intern("arbace.a2g.out$ups_forms$iter__1579000141__1579000145$fn__1579000146")

var Lit_910 *jrt.String = jrt.Intern("Up_")

var Lit_911 *jrt.String = jrt.Intern("arbace.a2g.out$ups_forms$iter__1579000141__1579000145$fn__1579000146$fn__1579000147")

var Lit_912 *jrt.String = jrt.Intern("arbace.a2g.out$used_qualifiers")

var Lit_913 *jrt.String = jrt.Intern("arbace.a2g.out$used_qualifiers$w__1579000063")

var Lit_914 *jrt.String = jrt.Intern("arbace.a2g.out$write_form")

var Lit_915 *jrt.String = jrt.Intern("[")

var Lit_916 *jrt.String = jrt.Intern("]")

var Lit_917 *jrt.String = jrt.Intern("{")

var Lit_918 *jrt.String = jrt.Intern("}")

var Lit_919 *jrt.String = jrt.Intern("arbace.a2g.out$write_form$fn__1579000057")

var Lit_920 *jrt.String = jrt.Intern("arbace.a2g.out$write_items")

var Lit_921 *jrt.String = jrt.Intern("arbace.a2g.out$write_list")

var Lit_922 *jrt.String = jrt.Intern("arbace.a2g.out$write_list$body__1579000038")

var Lit_923 *jrt.String = jrt.Intern("arbace.a2g.out$write_meta")

var Lit_924 *jrt.String = jrt.Intern("^")

var Lit_925 *jrt.String = jrt.Intern("in-ns")

var Lit_926 *jrt.String = jrt.Intern("private")

var Lit_927 *jrt.String = jrt.Intern("arglists")

var Lit_928 *jrt.String = jrt.Intern("sym")

var Lit_929 *jrt.String = jrt.Intern("arbace/a2g/out.ae")

var Lit_930 *jrt.String = jrt.Intern("dynamic")

var Lit_931 *jrt.String = jrt.Intern("nil, or a map of symbols to the symbols clean writes in their place: the literals of the\n  classes translated in parallel, named apart (Lit?i_k), to their names in the package's\n  literal pool (Lit_n; arbace.a2g.main; A2G-SPEC §4.1, \"The run in parallel\").")

var Lit_932 *jrt.String = jrt.Intern("f without the reader's position metadata (quoted forms in a2g's source carry it), its\n  symbols renamed by *renames*.")

var Lit_933 *jrt.String = jrt.Intern("declared")

var Lit_934 *jrt.String = jrt.Intern("nil (no layout), or {:line (volatile! current line) :forced line-or-nil}.")

var Lit_935 *jrt.String = jrt.Intern("sb")

var Lit_936 *jrt.String = jrt.Intern("StringBuilder")

var Lit_937 *jrt.String = jrt.Intern("mt")

var Lit_938 *jrt.String = jrt.Intern("xs")

var Lit_939 *jrt.String = jrt.Intern("form-text")

var Lit_940 *jrt.String = jrt.Intern("forms")

var Lit_941 *jrt.String = jrt.Intern("Does form f hold a list with a class forms line (:a2g/line), its tags included? Then its\n  text depends on the line it starts on (write-list); else not.")

var Lit_942 *jrt.String = jrt.Intern("A file of this many forms or more has the texts of its forms without lines computed in\n  parallel (a2g_classes.go: 8,000 registrations), before it is laid out.")

var Lit_943 *jrt.String = jrt.Intern("For the forms of a long file (split-min), by index, the text of each form that holds no line\n  (lined?), cleaned and written as file-text writes it (its text does not depend on where it\n  starts), or nil for the others; computed in parallel, by chunks. nil for a short file.")

var Lit_944 *jrt.String = jrt.Intern("file-text")

var Lit_945 *jrt.String = jrt.Intern("&")

var Lit_946 *jrt.String = jrt.Intern("header")

var Lit_947 *jrt.String = jrt.Intern("The text of a Go forms file of package pkg named go-name holding forms (a long one's forms\n  without lines written in parallel first, unlined-texts).")

var Lit_948 *jrt.String = jrt.Intern("go-file-name")

var Lit_949 *jrt.String = jrt.Intern("The Go file of a class forms file (§4.3): its name for arbace/lang, the Java source path\n  with _ for / in jrt; _a2g appended when the name would read as a build constraint.")

var Lit_950 *jrt.String = jrt.Intern("strings-forms")

var Lit_951 *jrt.String = jrt.Intern("lits")

var Lit_952 *jrt.String = jrt.Intern("The literal pool (§7.5): Lit_n vars interned at package initialization.")

var Lit_953 *jrt.String = jrt.Intern("ups-forms")

var Lit_954 *jrt.String = jrt.Intern("ups")

var Lit_955 *jrt.String = jrt.Intern("The nil-preserving conversions Up_From_To (§5.6) the package's code needs.")

var Lit_956 *jrt.String = jrt.Intern("adapter-forms")

var Lit_957 *jrt.String = jrt.Intern("The adapter F_Fn of functional interface fi (§7.11): its SAM calls Fn, default methods\n  forward to their functions.")

var Lit_958 *jrt.String = jrt.Intern("Split_String__String1")

var Lit_959 *jrt.String = jrt.Intern("Split_String__String1 is String.split(regex).\n")

var Lit_960 *jrt.String = jrt.Intern("regex")

var Lit_961 *jrt.String = jrt.Intern("Split_String_I__String1")

var Lit_962 *jrt.String = jrt.Intern("Split_String_I__String1 is String.split(regex, limit).\n")

var Lit_963 *jrt.String = jrt.Intern("limit")

var Lit_964 *jrt.String = jrt.Intern(".Split_CharSequence_I__String1")

var Lit_965 *jrt.String = jrt.Intern("Pattern_Compile_String__Pattern")

var Lit_966 *jrt.String = jrt.Intern("ReplaceAll_String_String__String")

var Lit_967 *jrt.String = jrt.Intern("ReplaceAll_String_String__String is String.replaceAll.\n")

var Lit_968 *jrt.String = jrt.Intern("replacement")

var Lit_969 *jrt.String = jrt.Intern(".ReplaceAll_String__String")

var Lit_970 *jrt.String = jrt.Intern(".Matcher_CharSequence__Matcher")

var Lit_971 *jrt.String = jrt.Intern("ReplaceFirst_String_String__String")

var Lit_972 *jrt.String = jrt.Intern("ReplaceFirst_String_String__String is String.replaceFirst.\n")

var Lit_973 *jrt.String = jrt.Intern(".ReplaceFirst_String__String")

var Lit_974 *jrt.String = jrt.Intern("Matches_String__Z")

var Lit_975 *jrt.String = jrt.Intern("Matches_String__Z is String.matches.\n")

var Lit_976 *jrt.String = jrt.Intern("Pattern_Matches_String_CharSequence__Z")

var Lit_977 *jrt.String = jrt.Intern("String's methods over java.util.regex, which a2g writes into jrt's a2g_support when Pattern is\n  translated (jrt's String is hand-written; JRT-NOTES.md, \"waiting for the regex port\"): Go\n  method name, then its definition as jdk26u's String defines it (split's one-character fast\n  path gives what Pattern.split gives).")

var Lit_978 *jrt.String = jrt.Intern("java.lang.String$CaseInsensitiveComparator")

var Lit_979 *jrt.String = jrt.Intern("Classes of jrt's own Java (overlay/jdk) that stand for a JDK class jrt cannot translate (a\n  nested class of a hand-written one): the name Class.getName answers for them.")

var Lit_980 *jrt.String = jrt.Intern("Forwarders on jrt's hand-written leaf classes to the default methods of translated\n  interfaces they implement and do not define themselves (CharSequence's chars and\n  codePoints on String, StringBuilder and StringBuffer once streams are in the world): Go's\n  interface satisfaction needs the methods, which jrt's own build cannot name (§5.4).")

var Lit_981 *jrt.String = jrt.Intern("shutdownNow")

var Lit_982 *jrt.String = jrt.Intern("()Ljava/util/List;")

var Lit_983 *jrt.String = jrt.Intern("invokeAll")

var Lit_984 *jrt.String = jrt.Intern("(Ljava/util/Collection;)Ljava/util/List;")

var Lit_985 *jrt.String = jrt.Intern("(Ljava/util/Collection;JLjava/util/concurrent/TimeUnit;)Ljava/util/List;")

var Lit_986 *jrt.String = jrt.Intern("invokeAny")

var Lit_987 *jrt.String = jrt.Intern("(Ljava/util/Collection;)Ljava/lang/Object;")

var Lit_988 *jrt.String = jrt.Intern("(Ljava/util/Collection;JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;")

var Lit_989 *jrt.String = jrt.Intern("The methods of ExecutorService jrt's hand-written ForkJoinPool cannot define (their types are\n  translated), as [name desc]: a2g gives ForkJoinPool Go methods calling jrt's own\n  jdk.internal.jrt.ForkJoinPools (JRT-NOTES.md, \"Concurrency\", JC7).")

var Lit_990 *jrt.String = jrt.Intern("The static method of ForkJoinPools behind ExecutorService method [name desc]: the pool first.")

var Lit_991 *jrt.String = jrt.Intern("ForkJoinPool's Go methods for fjp-support-methods, once ExecutorService and ForkJoinPools are\n  translated and ForkJoinPool is jrt's.")

var Lit_992 *jrt.String = jrt.Intern("support-forms")

var Lit_993 *jrt.String = jrt.Intern("a2g's helpers in package jrt (a2g_support): what translated code calls besides jrt's API.")

var Lit_994 *jrt.String = jrt.Intern("call")

var Lit_995 *jrt.String = jrt.Intern("Whether member tables list the public methods that do not exist in Go (bin/a2g --program).")

var Lit_996 *jrt.String = jrt.Intern("The order of the JVM's getDeclaredMethods for the overloads of class n among methods mms, when\n  it is stable (edge/archived-classes): {name [[parameter binary names] ...]} for each name of more\n  than one of mms, the parameter lists in the order of their (last) index; else nil.")

var Lit_997 *jrt.String = jrt.Intern("A descriptor with binary names (java.util.Map$Entry), as jrt's member tables hold them.")

var Lit_998 *jrt.String = jrt.Intern("g")

var Lit_999 *jrt.String = jrt.Intern("The MemberTable of class g's tables {:methods :ctors :fields} (amendment SZ3): the members'\n  lines as data, and per kind one dispatch function, a switch over the member's index among\n  its kind's (a member without a :body has none: jrt throws); [the dispatch functions' forms,\n  the table's form], nil when there are no members.")

var Lit_1000 *jrt.String = jrt.Intern("The member tables (§5.11, amendment R12) of translated class n: its public members, as\n  {:methods :ctors :fields} of {:line (data) :body (the dispatch case's statements; none:\n  absent)} (fields: :get, :set).")

var Lit_1001 *jrt.String = jrt.Intern("class-registration")

var Lit_1002 *jrt.String = jrt.Intern("C_class (Define, hierarchy only) and the init function setting its function and table\n  fields (§5.11, amendment J1).")

var Lit_1003 *jrt.String = jrt.Intern("cut-forms")

var Lit_1004 *jrt.String = jrt.Intern("classes")

var Lit_1005 *jrt.String = jrt.Intern("Class objects of classes outside the closed world that code names (class literals):\n  registered by name only, so that Class.forName finds them and nothing is their instance\n  (\"cut\" classes, A2G-SPEC §4.1).")

var Lit_1006 *jrt.String = jrt.Intern("support-table-forms")

var Lit_1007 *jrt.String = jrt.Intern("The member table entries of jrt's statics and methods that a2g writes (A2G-NOTES.md, phase\n  2C: String.format, String's regex methods, System.in, out, err and their setters), so that\n  reflection finds them at the REPL (System/out, String/format). In reflect_tables_a2g.go: its\n  init runs after reflect_tables.go's, which sets the hand-written classes' tables.")

var Lit_1008 *jrt.String = jrt.Intern("cuts")

var Lit_1009 *jrt.String = jrt.Intern("The Class expression of type descriptor d (a cut class's member names it) from pkg, or nil\n  when the Go build has no Class object for it there (a class outside the world that is not\n  cut, or one of arbace/lang named from jrt).")

var Lit_1010 *jrt.String = jrt.Intern("The Go value of a cut class's constant (static final, of a primitive type or String: its\n  value, read by reflection when the edge was recorded), else nil: cut classes' constants are\n  readable (ASM's Opcodes in the class forms compiler's analysis, doc/go/CLASSFORMS-REPL.md).")

var Lit_1011 *jrt.String = jrt.Intern("The public members class n declares on this JVM, as the edge's :cut records them, or nil:\n  {:methods [{:mods :name :params [desc] :ret desc}] :fields [{:mods :name :type desc :const v}]\n  :ctors [{:mods :params [desc]}]}, each in the order of the member tables.")

var Lit_1012 *jrt.String = jrt.Intern("cut-table-forms")

var Lit_1013 *jrt.String = jrt.Intern("The member tables of the cut classes of pkg (A2G-SPEC §4.1, D6; doc/go/EVAL-NOTES.md): their\n  public members as the JVM reports them (the edge's :cut), whose types the Go build can name,\n  each throwing UnsupportedOperationException when called, so that code naming them analyzes\n  (core's annotation support names ASM's Type) and fails only when run. As MemberTables\n  (amendment SZ3) whose functions are nil (jrt throws, MemberTable.Cut) but for a constant's\n  getter.")

var Lit_1014 *jrt.String = jrt.Intern("frames-forms")

var Lit_1015 *jrt.String = jrt.Intern("The frame table (§7.9.6, amendment J4): entries for methods whose Java names the demangler\n  cannot read back (names with _ or $).")

var Lit_1016 *jrt.String = jrt.Intern("jdk/internal/jrt/ForkJoinPools")
