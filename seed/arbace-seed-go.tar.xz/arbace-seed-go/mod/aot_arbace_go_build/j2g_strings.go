//line j2g_strings.ae:1
package aot_arbace_go_build

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn21,arbace.go.check.typesyn1,tyn21,arbace.go.check.constyn1,cyn19,arbace.go.check.envyn1,eyn20,arbace.go.check.codeyn4,codeyn20,arbace.go.check.declyn4,declkn3,docks3,goi11,unsupportedkn4,namekn3,pkgkn4,typekn8,ptr-recvkn3,objkn7,tparamskn4,funckn10,lazy-underkn9,compiled?kn1,Ikn7,float32kn7,float64kn13,untyped-floatkn1,Fkn6,stringkn14,untyped-stringkn1,Skn4,elsekn1,Rkn3,intkn5,int64kn4,uintkn6,uint64kn7,uintptrkn5,arraykn6,structkn5,targskn7,pointerkn3,mapkn5,slicekn4,chankn14,unsafe-pointerkn3,tagkn8,embeddedkn4,pathkn5,int32kn5,int16kn10,complex128kn9,interfacekn5,uint8kn9,complex64kn6,uint32kn6,uint16kn4,boolkn4,int8ks3,goi3,genkn5,typeskn11,table-type?kn5,localkn3,genkn7,invalidkn11,untyped-intkn12,untyped-boolkn15,untyped-complexkn4,recvkn4,bothkn4,sendkn12,untyped-runekn11,untyped-nilkn1,Bkn5,slotskn4,codekn6,labelskn4,gotokn9,captured?kn10,addressed?kn4,locskn4,cellkn1,Ckn4,slotkn1,Tkn8,constantkn4,modekn7,unknownkn3,valkn2,opkn3,nilks15,arbace.go.build4,nodekn1,kkn4,nodekn5,valueks2,go2,opkn1,xkn1,ykn2,tokn8,variablekn11,place-localkn11,place-fieldkn11,place-derefkn11,place-indexkn12,place-globalkn6,derefskn5,indexkn3,ptrkn6,globalkn5,derefkn5,fieldkn3,litkn4,kindkn6,fieldskn5,elemskn3,keykn7,entrieskn9,func-cellkn6,methodkn11,method-exprkn6,resultkn4,callkn1,tkn5,tempsks15,arbace.go.build4,minikn6,binarykn2,fnkn5,unaryks15,arbace.go.build7,selrecvkn2,vskn7,indexeskn9,map-indexkn5,parenkn13,convert-ifacekn4,formkn6,assertkn12,iface-methodkn4,addrkn4,convkn6,paramskn7,resultskn6,countskn6,spreadkn5,callskn5,multikn10,recv-namedkn11,method-cellkn8,rtparamskn11,recv-adjustkn9,panicwrapkn9,recv-typekn9,pkg-scopekn5,aliaskn13,tparams-countkn5,ifacekn3,varkn6,local?kn8,indirectkn3,viakn6,calleekn4,argskn5,tuplekn5,blockkn5,stmtskn4,exprkn6,returnkn6,valueskn8,pkg-namekn3,sigkn4,bodykn12,methods-donekn9,ambiguousks15,arbace.go.build4,nonekn5,eagerkn6,statickn7,closurekn7,builtinkn4,stmtkn6,unsafekn8,deferredkn9,new-valuekn5,blankks15,arbace.go.build8,map-tempkn1,mkn5,vtypekn2,mtks15,arbace.go.build6,p-tempkn1,ckn9,place-mapkn8,comma-okkn2,okkn3,okskn3,lhskn3,rhskn5,placekn3,inckn4,linekn5,constkn4,objskn4,initkn7,targetskn5,labelkn3,letkn8,let-typekn5,declskn4,declkn5,rangekn4,overkn6,placeskn11,fallthroughkn9,has-deferkn5,breakkn8,continuekn10,local-typekn6,switchkn7,clauseskn9,op-assignkn11,type-switchkn2,ifkn4,condkn4,thenkn3,forkn4,postkn6,incdeckn9,directivekn6,assignkn2,gokn5,deferkn10,decl-labelks3,goi5,labelkn4,loopkn3,brkkn4,contkn2,idkn14,per-iteration?ks15,arbace.go.build4,tempkn9,ptr-arraykn7,defaultkn4,fallkn3,lockn2,chkn2,ctkn4,bindkn4,commkn6,selectkn8,tag-typekn4,refskn4,casekn6,sourcekn3,srckn4,filekn9,lit-countkn6,originkn3,allkn5,termskn10,comparablekn5,unionks3,goi6,vargenks3,goi9,implicitskn10,underlyingkn4,treeks15,arbace.go.build8,nil-typekn6,ctx-ofv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.go.buildm2,R14,s1640,goi's builder (doc/go/GOI-SPEC.md §4.1): the checked tree (§3.7) made nodes, typed Go\n  closures of the back end arbace/goi, by its factories through arbace.lang.GoInterp's op\n  native (go/arbace/goi/registry.ae). It numbers each function's slots per kind (parameters and\n  results first, as the signature lays them out), makes the variables that live in Go memory\n  cells (captured, addressed, of a struct or array type, every package variable), gives each\n  jump target its codes, chooses each node's variant by its operands' types, and resolves each\n  call to the callee's cell, a closure, or the table's member. It decides nothing the checker\n  has not: no type, no constant, no resolution.\n\n  GR3 builds the interpreter's core: scalars, strings, slices, arrays, maps, structs, pointers,\n  functions and closures, all control flow with labels and goto, defer, panic and recover,\n  interface values without methods (§5.3 rules 1 and 2), the calls of compiled Go. GR4 adds\n  methods (their receiver laid after the parameters and results), method values and\n  expressions, the method sets of the types that go into interfaces (each entry the method or a\n  thunk: §5.3), interface method calls, type assertions and switches, embedding and promotion,\n  goroutines, channels, select and range over functions and channels. GR6 adds generics (§9.2):\n  each instance of a generic function, method or type built per type-argument list from the\n  generic declaration's checked tree with its type parameters substituted (inst-tree). A form\n  that needs what goi does not run is \"not supported by goi yet\" (§3.4), an ex-info with\n  :goi/unsupported.v11,arbace.core7,ex-infoR15,v15,arbace.go.build12,program-modev11,arbace.core7,ex-datav11,arbace.core5,flushv11,arbace.core19,pop-thread-bindingsv11,arbace.core7,printlnv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*R16,v19,arbace.go.check.env1,oR17,v21,arbace.go.check.types9,exported?R18,R19,R20,R21,R22,R23,v21,arbace.go.check.types4,infov20,arbace.go.check.decl15,instance-under!v15,arbace.go.build5,*ctx*v21,arbace.go.check.types12,*method-obj*v15,arbace.go.build11,method-datav21,arbace.go.check.types14,*subst-method*v20,arbace.go.check.decl12,subst-methodv21,arbace.go.check.types15,*resolve-named*v15,arbace.go.build18,complete-instance!R24,v21,arbace.go.check.types5,underv11,arbace.core8,keyword?v15,arbace.go.build7,int-kwsR25,S3,R26,R27,R28,R29,S2,R30,R31,R32,R33,R34,v21,arbace.go.check.types8,untyped?v21,arbace.go.check.types12,default-typev21,arbace.go.check.types9,unsigned?v11,arbace.core9,contains?S5,R35,R36,R37,R38,R39,v15,arbace.go.build8,basic-ofv11,arbace.core7,vector?S2,R40,R41,v21,arbace.go.check.types10,interface?v11,arbace.core3,notv21,arbace.go.check.types7,tparam?v21,arbace.go.check.types6,named?v11,arbace.core3,seqR42,v15,arbace.go.build10,inst-type?v15,arbace.go.build9,compiled?v15,arbace.go.build18,interpreted-named?R43,R40,R44,R45,R46,v11,arbace.core4,someR41,v15,arbace.go.build10,recursive?v15,arbace.go.build10,shape-typeR47,V2,R45,R47,v11,arbace.core4,mapvv11,arbace.core5,assocR48,R49,v21,arbace.go.check.const10,value-textv15,arbace.go.build2,oav11,arbace.core3,mapv15,arbace.go.build4,descv15,arbace.go.build8,tag-textR50,v15,arbace.go.build15,*iface-pending*v15,arbace.go.build22,set-iface-methods-now!v15,arbace.go.build2,opv15,arbace.go.build10,method-keyR51,l5,R52,l4,R53,l16,R39,l12,v15,arbace.go.build12,unsupported!v21,arbace.go.check.types8,type-strl21,l17,l18,R54,l20,R26,l13,R55,l8,R27,l14,R36,l6,R56,l15,R57,l10,R58,l9,R38,l11,R30,l24,R37,l7,l26,R59,l1,R60,l3,R35,l2,l23,l19,l22,l25,R61,v11,arbace.core5,swap!v15,arbace.go.build9,local-genv11,arbace.core3,incv21,arbace.go.check.types12,update-info!v15,arbace.go.build11,named-desc1v15,arbace.go.build10,desc-typesR62,R63,v15,arbace.go.build8,inst-genR64,v15,arbace.go.build12,local-gen-ofR65,v15,arbace.go.build14,inst-type-nameR66,v15,arbace.go.build12,reflect-kindv15,arbace.go.build12,method-countv15,arbace.go.build18,set-iface-methods!v15,arbace.go.build14,layout-needed?v11,arbace.core10,ex-messagev13,arbace.string9,includes?v15,arbace.go.build12,struct-partsv15,arbace.go.build17,*methods-pending*v15,arbace.go.build18,set-named-methods!v15,arbace.go.build5,desc1R67,R68,R28,R69,v11,arbace.core4,namev15,arbace.go.build10,named-descR70,R71,l0,R72,v11,arbace.core6,empty?R73,R31,R74,v11,arbace.core10,bigintegerv11,arbace.core6,every?v21,arbace.go.check.const11,complex-valv21,arbace.go.check.const9,to-doublev11,arbace.core8,boolean?R75,S2,R53,R56,S2,R26,R27,v15,arbace.go.build13,complex-valuev15,arbace.go.build14,go-string-nodev15,arbace.go.build8,int-bitsv11,arbace.core8,integer?v21,arbace.go.check.const7,int-valR76,v15,arbace.go.build4,*fn*v11,arbace.core6,updateR77,R78,v11,arbace.core9,volatile!R79,v15,arbace.go.build10,next-code!R80,R81,v15,arbace.go.build16,struct-or-array?R82,v15,arbace.go.build9,cell-var?R83,v15,arbace.go.build9,new-slot!R84,R85,v15,arbace.go.build4,kindv15,arbace.go.build7,as-kindR86,v15,arbace.go.build2,exv15,arbace.go.build6,iface?v15,arbace.go.build15,ensure-methods!m18,s1,*s3,Muls1,%s3,Rems6,bit-ors2,Ors1,/s3,Divs1,-s3,Subs7,bit-xors3,Xors7,bit-ands3,Ands11,bit-and-nots6,AndNots1,+s3,AddR87,R88,v11,arbace.core4,not=R89,R90,R91,v15,arbace.go.build7,int-sfxv15,arbace.go.build10,arith-namev15,arbace.go.build8,const-ofv15,arbace.go.build13,local-slot-ofv15,arbace.go.build5,wide?S3,s1,*s1,-s1,+S3,s1,*s1,-s1,+v15,arbace.go.build3,exkS2,s2,>>s2,<<v15,arbace.go.build9,unsigned?v15,arbace.go.build11,float-binopv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core5,firstv21,arbace.go.check.const8,complex?v21,arbace.go.check.const7,re-partv15,arbace.go.build10,count-nodeR92,v15,arbace.go.build9,nil-node?v15,arbace.go.build5,temp!v15,arbace.go.build6,load-pv15,arbace.go.build10,local-nodeR93,R94,R95,R96,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv15,arbace.go.build13,compare-nodesv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core6,reducev15,arbace.go.build8,set-slotv15,arbace.go.build8,cmp-namev15,arbace.go.build13,iface-contentv11,arbace.core5,rangeS2,R46,R43,R97,R98,R99,S2,s2,>>s2,<<v15,arbace.go.build10,shift-nodev15,arbace.go.build9,int-binopR100,v15,arbace.go.build11,bytes-type?v15,arbace.go.build11,runes-type?S2,R53,R56,S2,R53,R56,S2,R46,R22,R101,S5,R102,R103,R104,R105,R106,v15,arbace.go.build12,addressable?v15,arbace.go.build5,placeR107,v15,arbace.go.build11,value-placev11,arbace.core1,+v11,arbace.core11,map-indexedv15,arbace.go.build5,uidx?v11,arbace.core4,takeR108,R106,R109,R110,R105,v15,arbace.go.build11,index-placeR111,v15,arbace.go.build3,locR103,v15,arbace.go.build11,field-placeR112,R104,R102,R113,v15,arbace.go.build9,lit-placeR114,v11,arbace.core6,removeR115,v21,arbace.go.check.types8,pointer?v11,arbace.core4,longv15,arbace.go.build9,elem-nodeR116,v11,arbace.core6,repeatV1,l0,v11,arbace.core6,secondv15,arbace.go.build8,lit-nodev11,arbace.core5,applyv11,arbace.core3,maxR117,R118,v15,arbace.go.build13,instance-cellR119,S5,R40,R43,R45,R41,R44,v15,arbace.go.build6,coercev15,arbace.go.build3,ex*S1,R92,v15,arbace.go.build10,const-nodeR120,v15,arbace.go.build17,method-value-nodeR121,v15,arbace.go.build16,method-expr-nodev15,arbace.go.build8,var-nodeR122,v15,arbace.go.build12,call-resultsR123,R124,R125,R126,R127,v15,arbace.go.build11,binary-nodev15,arbace.go.build9,elem-typeR128,R129,v15,arbace.go.build10,unary-nodev15,arbace.go.build12,build-fn-litR130,v21,arbace.go.check.types12,string-type?R131,v11,arbace.core6,concatR132,v15,arbace.go.build9,uidx-maskv15,arbace.go.build11,global-nodeR133,v15,arbace.go.build9,call-nodeR134,R135,v11,arbace.core6,pr-strR136,v15,arbace.go.build15,func-value-nodeR137,v15,arbace.go.build9,assert-knR138,v15,arbace.go.build23,iface-method-value-nodeR139,R140,v15,arbace.go.build9,conv-nodem8,R25,l0,R29,l0,R32,l0,R34,l0,v11,arbace.core3,vecR141,R142,R143,v15,arbace.go.build11,slot-layoutv15,arbace.go.build14,mem-converted?v15,arbace.go.build8,mem-nodev11,arbace.core4,lastv11,arbace.core4,dropR144,R145,R146,v11,arbace.core3,strv11,arbace.core4,compv15,arbace.go.build9,arg-nodesv15,arbace.go.build10,arg-setterv15,arbace.go.build9,cell-callv15,arbace.go.build8,from-memv15,arbace.go.build18,compiled-call-nodeR147,R148,R149,v15,arbace.go.build15,generic-method?v15,arbace.go.build11,method-cellv15,arbace.go.build12,recv-type-ofv11,arbace.core6,zipmapv20,arbace.go.check.decl5,substv15,arbace.go.build11,path-derefsv11,arbace.core5,true?v11,arbace.core3,popR150,R151,v15,arbace.go.build9,field-selv15,arbace.go.build6,sig-ofv15,arbace.go.build13,method-targetR152,v15,arbace.go.build9,recv-nodeR153,R154,R155,v21,arbace.go.check.types22,identical-ignore-tags?v21,arbace.go.check.types14,missing-methodv11,arbace.core7,sort-byv11,arbace.core3,keyv21,arbace.go.check.types10,deref-typev15,arbace.go.build9,via-ifacev15,arbace.go.build13,compiled-callv15,arbace.go.build18,interp-method-callv15,arbace.go.build15,iface-recv-nodeR156,v15,arbace.go.build11,error-type?v15,arbace.go.build15,compiled-iface?v11,arbace.core4,map?v19,arbace.go.check.env3,objR157,R158,R159,R160,v21,arbace.go.check.types11,method-datav15,arbace.go.build9,local-refR161,R162,v11,arbace.core4,intoV1,R163,R164,R165,R166,R167,R168,v15,arbace.go.build9,local-objv15,arbace.go.build9,selectionR169,v15,arbace.go.build10,build-codeR170,R171,v15,arbace.go.build10,thunk-bodyv21,arbace.go.check.types11,lookup-implv15,arbace.go.build6,isubstv21,arbace.go.check.types10,methods-ofR172,v15,arbace.go.build17,may-have-methods?S2,R120,R138,R173,v13,arbace.string12,starts-with?V2,R174,nR174,R175,v15,arbace.go.build18,build-method-thunkv15,arbace.go.build6,lazilyv15,arbace.go.build8,with-ctxS2,R120,R138,V2,R174,nv11,arbace.core4,keepv15,arbace.go.build17,method-candidatesS2,R120,R138,S2,R120,R138,v21,arbace.go.check.types16,empty-interface?v15,arbace.go.build7,rt-namev15,arbace.go.build11,assert-descv15,arbace.go.build10,iface-namev15,arbace.go.build10,iface-callv15,arbace.go.build11,method-callR176,v15,arbace.go.build11,static-callR177,v15,arbace.go.build10,value-callR178,v15,arbace.go.build7,builtinR179,v15,arbace.go.build12,expr-stmt-ofR180,R181,v15,arbace.go.build12,expr-or-stmtR182,V1,l0,S2,R102,R64,R183,R184,R185,R186,R187,R188,v15,arbace.go.build7,store-pR189,v15,arbace.go.build13,slot-of-placeR190,R191,R192,v15,arbace.go.build9,rhs-nodesV2,nnR193,S2,R102,R64,S2,R103,R112,S2,R43,R45,R194,v15,arbace.go.build9,assign-toR195,v15,arbace.go.build13,prepare-placev15,arbace.go.build8,temps-ofv11,arbace.core6,mapcatR196,S2,s2,>>s2,<<v15,arbace.go.build11,binop-nodesS2,s2,>>s2,<<S2,s2,>>s2,<<V3,R189,l1,l0,v15,arbace.go.build14,op-assign-stmtR197,R198,R199,v15,arbace.go.build6,one-ofv15,arbace.go.build8,new-loc!d0,R200,R201,v15,arbace.go.build9,zero-initv15,arbace.go.build8,init-varR202,v11,arbace.core6,filterv15,arbace.go.build9,stmt-listR203,v15,arbace.go.build12,quiet-basic?v15,arbace.go.build12,quiet-const?S4,s3,nots1,-s7,bit-nots1,+v15,arbace.go.build11,quiet-expr?v11,arbace.core8,not-any?v15,arbace.go.build14,quiet-builtinsS2,s2,ors3,andv15,arbace.go.build15,quiet-cmp-type?S2,s2,>>s2,<<S2,s1,%s1,/S2,R34,R29,R204,R205,v15,arbace.go.build13,quiet-header?R206,R207,R208,S5,R35,R30,R40,R45,R44,R209,v15,arbace.go.build12,quiet-place?v11,arbace.core4,nil?R210,R211,R212,R213,R214,R215,R216,R217,R218,S2,s2,>>s2,<<S2,s1,%s1,/S2,R34,R29,R219,R220,R221,v15,arbace.go.build19,quiet-block-header?R222,R223,R224,R225,R226,R227,v15,arbace.go.build12,hoisted-lineS2,R223,R208,S8,R228,R218,R229,R227,R207,R166,R72,R225,v15,arbace.go.build9,stmt-linev15,arbace.go.build4,stmtv15,arbace.go.build11,label-code!R230,v15,arbace.go.build11,stored-linev11,arbace.core4,pos?v15,arbace.go.build9,body-nodev15,arbace.go.build9,decl-stmtR231,R232,R233,R234,R235,v15,arbace.go.build11,label-entryR236,v15,arbace.go.build11,loop-targetv15,arbace.go.build19,per-iteration-cellsv15,arbace.go.build11,push-targetv15,arbace.go.build9,loop-bodyR237,v15,arbace.go.build9,has-call?v11,arbace.core4,valsv11,arbace.core6,dissocR238,V2,nnV2,R35,R51,v15,arbace.go.build13,range-targetsv15,arbace.go.build16,range-elem-typesv11,arbace.core6,vectorv11,arbace.core7,filtervv11,arbace.core5,some?v15,arbace.go.build11,assign-stmtv15,arbace.go.build10,any-setterv15,arbace.go.build10,idx-setterv15,arbace.go.build9,at-setterv11,arbace.core8,identityV2,nnv11,arbace.core5,doallv21,arbace.go.check.types13,boolean-type?R239,R240,v15,arbace.go.build4,jumpR241,m8,R25,l0,R29,l0,R32,l0,R34,l0,v15,arbace.go.build9,call-stmtv15,arbace.go.build13,deferred-callv11,arbace.core7,vreset!R229,R242,l-1,R243,R244,R245,v15,arbace.go.build11,select-recvR228,v15,arbace.go.build7,go-stmtv15,arbace.go.build11,incdec-stmtv15,arbace.go.build10,defer-stmtv15,arbace.go.build10,range-stmtv15,arbace.go.build9,send-stmtv15,arbace.go.build10,block-nodev15,arbace.go.build11,switch-stmtv15,arbace.go.build16,type-switch-stmtR246,v15,arbace.go.build11,select-stmtv15,arbace.go.build9,innermostS2,R232,R216,v15,arbace.go.build11,return-stmtv15,arbace.go.build8,for-stmtR247,R248,S16,R156,R120,R248,R152,R141,R90,R112,R18,R247,R170,R157,R136,R20,R200,R100,R142,S16,R156,R120,R248,R152,R141,R90,R112,R18,R247,R170,R157,R136,R20,R200,R100,R142,R249,S2,R102,R64,v11,arbace.core4,keysR250,R251,v15,arbace.go.build10,has-defer?R252,v15,arbace.go.build11,free-localsR253,m10,R25,l0,R29,l0,R32,l0,R34,l0,R84,l0,R254,v20,arbace.go.check.decl11,instantiateR255,v21,arbace.go.check.types10,terms-normR163,V1,R163,v21,arbace.go.check.types12,sort-methodsv21,arbace.go.check.types9,make-tsetR256,R257,R258,v15,arbace.go.build9,skip-keysv15,arbace.go.build9,type-keysv19,arbace.go.check.env4,obj?v20,arbace.go.check.code14,representationS1,R138,v11,arbace.core11,persistent!v11,arbace.core9,reduce-kvv11,arbace.core6,assoc!v15,arbace.go.build8,obj-keysv15,arbace.go.build9,objs-keysv11,arbace.core9,transientv15,arbace.go.build10,resolve-onS2,R156,R120,S2,R120,R138,S3,s7,Alignofs6,Sizeofs8,Offsetofv21,arbace.go.check.types6,sizeofv20,arbace.go.check.code14,offsetof-valuev21,arbace.go.check.types7,alignofv21,arbace.go.check.types11,const-type?v20,arbace.go.check.code10,conversionv11,arbace.core5,mergev11,arbace.core11,select-keysV2,R88,R90,v15,arbace.go.build11,local-typesv21,arbace.go.check.types9,new-namedV6,R20,R16,R17,R169,R64,R259,R260,R261,V6,R20,R16,R17,R169,R64,R259,v15,arbace.go.build9,inst-treev21,arbace.go.check.types11,basic-namesS2,s22,command-line-argumentss4,mainv15,arbace.go.build8,sym-namev13,arbace.string4,joinv15,arbace.go.build6,rt-sigR259,v15,arbace.go.build9,inst-gensR262,v15,arbace.go.build14,instance-cell*R263,v15,arbace.go.build9,instancesR264,v15,arbace.go.build13,instance-nameV1,s7,reflectv15,arbace.go.build14,build-instance")

var Lit_1 *jrt.String = jrt.Intern("AnySlot")

var Lit_2 *jrt.String = jrt.Intern("AnyNewCell")

var Lit_3 *jrt.String = jrt.Intern("AnyCell")

var Lit_4 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_5 *jrt.String = jrt.Intern("AnyPlace")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes$fn__367000311")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes$fn__367000313")

var Lit_8 *jrt.String = jrt.Intern("MakeSliceOf")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes$fn__367000315")

var Lit_10 *jrt.String = jrt.Intern("ArgF")

var Lit_11 *jrt.String = jrt.Intern("ArgI")

var Lit_12 *jrt.String = jrt.Intern("ArgR")

var Lit_13 *jrt.String = jrt.Intern("ArgS")

var Lit_14 *jrt.String = jrt.Intern("BI")

var Lit_15 *jrt.String = jrt.Intern("IB")

var Lit_16 *jrt.String = jrt.Intern("goi's builder: a ")

var Lit_17 *jrt.String = jrt.Intern(" node where a ")

var Lit_18 *jrt.String = jrt.Intern(" is wanted")

var Lit_19 *jrt.String = jrt.Intern("AssertF")

var Lit_20 *jrt.String = jrt.Intern("AssertI")

var Lit_21 *jrt.String = jrt.Intern("AssertR")

var Lit_22 *jrt.String = jrt.Intern("AssertS")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.build$assign_stmt$fn__367000692")

var Lit_24 *jrt.String = jrt.Intern("Assign")

var Lit_25 *jrt.String = jrt.Intern("MapSet")

var Lit_26 *jrt.String = jrt.Intern("CellP")

var Lit_27 *jrt.String = jrt.Intern("AtSlot")

var Lit_28 *jrt.String = jrt.Intern("AtNewCell")

var Lit_29 *jrt.String = jrt.Intern("AtCell")

var Lit_30 *jrt.String = jrt.Intern("AtPlace")

var Lit_31 *jrt.String = jrt.Intern("and")

var Lit_32 *jrt.String = jrt.Intern("AndB")

var Lit_33 *jrt.String = jrt.Intern("or")

var Lit_34 *jrt.String = jrt.Intern("OrB")

var Lit_35 *jrt.String = jrt.Intern("K")

var Lit_36 *jrt.String = jrt.Intern("F32")

var Lit_37 *jrt.String = jrt.Intern("F64")

var Lit_38 *jrt.String = jrt.Intern("C64")

var Lit_39 *jrt.String = jrt.Intern("C128")

var Lit_40 *jrt.String = jrt.Intern("ConcatS")

var Lit_41 *jrt.String = jrt.Intern("<<")

var Lit_42 *jrt.String = jrt.Intern("Shl")

var Lit_43 *jrt.String = jrt.Intern("Shr")

var Lit_44 *jrt.String = jrt.Intern("U")

var Lit_45 *jrt.String = jrt.Intern("")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.build$block_node$fn__367000767")

var Lit_47 *jrt.String = jrt.Intern("Seq")

var Lit_48 *jrt.String = jrt.Intern("arbace.go.build$body_node$fn__367000762")

var Lit_49 *jrt.String = jrt.Intern("SeqL")

var Lit_50 *jrt.String = jrt.Intern("ProCell")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367001108__367001112")

var Lit_52 *jrt.String = jrt.Intern("NewCode")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367001108__367001112$fn__367001113")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367001108__367001112$fn__367001113$fn__367001114")

var Lit_55 *jrt.String = jrt.Intern("ProNewCell")

var Lit_56 *jrt.String = jrt.Intern("EpiCell")

var Lit_57 *jrt.String = jrt.Intern("ProZeroR")

var Lit_58 *jrt.String = jrt.Intern(".func")

var Lit_59 *jrt.String = jrt.Intern("FuncCell")

var Lit_60 *jrt.String = jrt.Intern("FuncSource")

var Lit_61 *jrt.String = jrt.Intern("SetCode")

var Lit_62 *jrt.String = jrt.Intern("MakeClosure")

var Lit_63 *jrt.String = jrt.Intern("arbace.go.build$build_fn_lit$fn__367001137")

var Lit_64 *jrt.String = jrt.Intern("a function without a body (assembly)")

var Lit_65 *jrt.String = jrt.Intern("out of scope: §1.1")

var Lit_66 *jrt.String = jrt.Intern("init")

var Lit_67 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001143__367001147")

var Lit_68 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001143__367001147$fn__367001148")

var Lit_69 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001143__367001147$fn__367001148$fn__367001149")

var Lit_70 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001143__367001147$fn__367001148$fn__367001153")

var Lit_71 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001143__367001147$fn__367001148$fn__367001149$fn__367001150")

var Lit_72 *jrt.String = jrt.Intern("_")

var Lit_73 *jrt.String = jrt.Intern("the generic function ")

var Lit_74 *jrt.String = jrt.Intern(".")

var Lit_75 *jrt.String = jrt.Intern(" (its body is not in the forms)")

var Lit_76 *jrt.String = jrt.Intern("GR6")

var Lit_77 *jrt.String = jrt.Intern("r")

var Lit_78 *jrt.String = jrt.Intern("arbace.go.build$build_method_thunk$fn__367000441")

var Lit_79 *jrt.String = jrt.Intern("arbace.go.build$build_method_thunk$fn__367000443")

var Lit_80 *jrt.String = jrt.Intern("p")

var Lit_81 *jrt.String = jrt.Intern("arbace.go.build$builtin$value__367000570")

var Lit_82 *jrt.String = jrt.Intern("Add")

var Lit_83 *jrt.String = jrt.Intern("UnsafeAdd")

var Lit_84 *jrt.String = jrt.Intern("make")

var Lit_85 *jrt.String = jrt.Intern("MakeMap")

var Lit_86 *jrt.String = jrt.Intern("MakeSlice")

var Lit_87 *jrt.String = jrt.Intern("MakeChan")

var Lit_88 *jrt.String = jrt.Intern("panic")

var Lit_89 *jrt.String = jrt.Intern("Panic")

var Lit_90 *jrt.String = jrt.Intern("StmtT")

var Lit_91 *jrt.String = jrt.Intern("recover")

var Lit_92 *jrt.String = jrt.Intern("DeferredRecover")

var Lit_93 *jrt.String = jrt.Intern("Recover")

var Lit_94 *jrt.String = jrt.Intern("StringData")

var Lit_95 *jrt.String = jrt.Intern("UnsafeStringData")

var Lit_96 *jrt.String = jrt.Intern("String")

var Lit_97 *jrt.String = jrt.Intern("UnsafeString")

var Lit_98 *jrt.String = jrt.Intern("Slice")

var Lit_99 *jrt.String = jrt.Intern("UnsafeSlice")

var Lit_100 *jrt.String = jrt.Intern("real")

var Lit_101 *jrt.String = jrt.Intern("RealF")

var Lit_102 *jrt.String = jrt.Intern("imag")

var Lit_103 *jrt.String = jrt.Intern("ImagF")

var Lit_104 *jrt.String = jrt.Intern("complex")

var Lit_105 *jrt.String = jrt.Intern("ComplexR")

var Lit_106 *jrt.String = jrt.Intern("cap")

var Lit_107 *jrt.String = jrt.Intern("CapSlice")

var Lit_108 *jrt.String = jrt.Intern("CapChan")

var Lit_109 *jrt.String = jrt.Intern("ThenI")

var Lit_110 *jrt.String = jrt.Intern("ConstI")

var Lit_111 *jrt.String = jrt.Intern("cap of ")

var Lit_112 *jrt.String = jrt.Intern("GR4")

var Lit_113 *jrt.String = jrt.Intern("delete")

var Lit_114 *jrt.String = jrt.Intern("Delete")

var Lit_115 *jrt.String = jrt.Intern("len")

var Lit_116 *jrt.String = jrt.Intern("LenS")

var Lit_117 *jrt.String = jrt.Intern("LenSlice")

var Lit_118 *jrt.String = jrt.Intern("LenMap")

var Lit_119 *jrt.String = jrt.Intern("LenChan")

var Lit_120 *jrt.String = jrt.Intern("len of ")

var Lit_121 *jrt.String = jrt.Intern("max")

var Lit_122 *jrt.String = jrt.Intern("MinMaxF")

var Lit_123 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000584")

var Lit_124 *jrt.String = jrt.Intern("MinMaxI")

var Lit_125 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000586")

var Lit_126 *jrt.String = jrt.Intern("MinMaxS")

var Lit_127 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000588")

var Lit_128 *jrt.String = jrt.Intern("min")

var Lit_129 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000591")

var Lit_130 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000593")

var Lit_131 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000595")

var Lit_132 *jrt.String = jrt.Intern("SliceData")

var Lit_133 *jrt.String = jrt.Intern("UnsafeSliceData")

var Lit_134 *jrt.String = jrt.Intern("new")

var Lit_135 *jrt.String = jrt.Intern("AddrOf")

var Lit_136 *jrt.String = jrt.Intern("LitP")

var Lit_137 *jrt.String = jrt.Intern("NewR")

var Lit_138 *jrt.String = jrt.Intern("copy")

var Lit_139 *jrt.String = jrt.Intern("CopyString")

var Lit_140 *jrt.String = jrt.Intern("Copy")

var Lit_141 *jrt.String = jrt.Intern("print")

var Lit_142 *jrt.String = jrt.Intern("Print")

var Lit_143 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000600__367000604")

var Lit_144 *jrt.String = jrt.Intern("println")

var Lit_145 *jrt.String = jrt.Intern("clear")

var Lit_146 *jrt.String = jrt.Intern("ClearMap")

var Lit_147 *jrt.String = jrt.Intern("ClearSlice")

var Lit_148 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000610__367000614")

var Lit_149 *jrt.String = jrt.Intern("append")

var Lit_150 *jrt.String = jrt.Intern("AppendString")

var Lit_151 *jrt.String = jrt.Intern("AppendSpread")

var Lit_152 *jrt.String = jrt.Intern("Append")

var Lit_153 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000623")

var Lit_154 *jrt.String = jrt.Intern("close")

var Lit_155 *jrt.String = jrt.Intern("Close")

var Lit_156 *jrt.String = jrt.Intern("the builtin ")

var Lit_157 *jrt.String = jrt.Intern("unsafe.")

var Lit_158 *jrt.String = jrt.Intern("GR3")

var Lit_159 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000600__367000604$fn__367000605")

var Lit_160 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000600__367000604$fn__367000605$fn__367000606")

var Lit_161 *jrt.String = jrt.Intern("PrintArg")

var Lit_162 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000610__367000614$fn__367000615")

var Lit_163 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000610__367000614$fn__367000615$fn__367000616")

var Lit_164 *jrt.String = jrt.Intern("the call kind ")

var Lit_165 *jrt.String = jrt.Intern("ExprT")

var Lit_166 *jrt.String = jrt.Intern("Call")

var Lit_167 *jrt.String = jrt.Intern("arbace.go.build$cell_call$fn__367000324")

var Lit_168 *jrt.String = jrt.Intern("resCopies")

var Lit_169 *jrt.String = jrt.Intern("CallT")

var Lit_170 *jrt.String = jrt.Intern("ConvR")

var Lit_171 *jrt.String = jrt.Intern("IsNilR")

var Lit_172 *jrt.String = jrt.Intern("==")

var Lit_173 *jrt.String = jrt.Intern("NotB")

var Lit_174 *jrt.String = jrt.Intern("R")

var Lit_175 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$fn__367000172")

var Lit_176 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$field__367000174")

var Lit_177 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$iter__367000179__367000183")

var Lit_178 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$fn__367000189")

var Lit_179 *jrt.String = jrt.Intern("ConstB")

var Lit_180 *jrt.String = jrt.Intern("ThenB")

var Lit_181 *jrt.String = jrt.Intern("F")

var Lit_182 *jrt.String = jrt.Intern("I")

var Lit_183 *jrt.String = jrt.Intern("LK")

var Lit_184 *jrt.String = jrt.Intern("LL")

var Lit_185 *jrt.String = jrt.Intern("PtrToUnsafe")

var Lit_186 *jrt.String = jrt.Intern("S")

var Lit_187 *jrt.String = jrt.Intern("FieldP")

var Lit_188 *jrt.String = jrt.Intern("BoxP")

var Lit_189 *jrt.String = jrt.Intern("FieldOff")

var Lit_190 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$iter__367000179__367000183$fn__367000184")

var Lit_191 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$iter__367000179__367000183$fn__367000184$fn__367000185")

var Lit_192 *jrt.String = jrt.Intern("CallCompiled")

var Lit_193 *jrt.String = jrt.Intern("arbace.go.build$compiled_call_node$fn__367000350")

var Lit_194 *jrt.String = jrt.Intern("CvC64")

var Lit_195 *jrt.String = jrt.Intern("ConstR")

var Lit_196 *jrt.String = jrt.Intern("ConstF")

var Lit_197 *jrt.String = jrt.Intern("a constant of type ")

var Lit_198 *jrt.String = jrt.Intern("Cv")

var Lit_199 *jrt.String = jrt.Intern("Uto")

var Lit_200 *jrt.String = jrt.Intern("Ito")

var Lit_201 *jrt.String = jrt.Intern("Fto")

var Lit_202 *jrt.String = jrt.Intern("CvF32")

var Lit_203 *jrt.String = jrt.Intern("StrFromRune")

var Lit_204 *jrt.String = jrt.Intern("StrFromBytes")

var Lit_205 *jrt.String = jrt.Intern("StrFromRunes")

var Lit_206 *jrt.String = jrt.Intern("BytesFromStr")

var Lit_207 *jrt.String = jrt.Intern("RunesFromStr")

var Lit_208 *jrt.String = jrt.Intern("CvC128")

var Lit_209 *jrt.String = jrt.Intern("UintptrToUnsafe")

var Lit_210 *jrt.String = jrt.Intern("UnsafeToUintptr")

var Lit_211 *jrt.String = jrt.Intern("UnsafeToPtr")

var Lit_212 *jrt.String = jrt.Intern("SliceToArray")

var Lit_213 *jrt.String = jrt.Intern("SliceToArrayPtr")

var Lit_214 *jrt.String = jrt.Intern("the conversion ")

var Lit_215 *jrt.String = jrt.Intern(" to ")

var Lit_216 *jrt.String = jrt.Intern("Nop")

var Lit_217 *jrt.String = jrt.Intern("arbace.go.build$decl_stmt$fn__367000714")

var Lit_218 *jrt.String = jrt.Intern("arbace.go.build$decl_stmt$target__367000716")

var Lit_219 *jrt.String = jrt.Intern("Defer")

var Lit_220 *jrt.String = jrt.Intern("arbace.go.build$deferred_call$to_mini__367000945")

var Lit_221 *jrt.String = jrt.Intern("arbace.go.build$deferred_call$fn__367000947")

var Lit_222 *jrt.String = jrt.Intern("NonNilR")

var Lit_223 *jrt.String = jrt.Intern("deferring a call of kind ")

var Lit_224 *jrt.String = jrt.Intern("arbace.go.build$deferred_call$fn__367000952")

var Lit_225 *jrt.String = jrt.Intern("arbace.go.build$desc$fn__367000097")

var Lit_226 *jrt.String = jrt.Intern("arbace.go.build$desc$fn__367000099")

var Lit_227 *jrt.String = jrt.Intern("a value of type ")

var Lit_228 *jrt.String = jrt.Intern("an invalid type")

var Lit_229 *jrt.String = jrt.Intern("TBasic")

var Lit_230 *jrt.String = jrt.Intern("unsafe.Pointer")

var Lit_231 *jrt.String = jrt.Intern("goi's builder: the type parameter ")

var Lit_232 *jrt.String = jrt.Intern(" of an uninstantiated tree")

var Lit_233 *jrt.String = jrt.Intern("TMap")

var Lit_234 *jrt.String = jrt.Intern("TArray")

var Lit_235 *jrt.String = jrt.Intern("TChan")

var Lit_236 *jrt.String = jrt.Intern("any")

var Lit_237 *jrt.String = jrt.Intern("TIface")

var Lit_238 *jrt.String = jrt.Intern("TSlice")

var Lit_239 *jrt.String = jrt.Intern("TFunc")

var Lit_240 *jrt.String = jrt.Intern("TPtr")

var Lit_241 *jrt.String = jrt.Intern("TStruct")

var Lit_242 *jrt.String = jrt.Intern("the type ")

var Lit_243 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000478__367000482")

var Lit_244 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$fn__367000528")

var Lit_245 *jrt.String = jrt.Intern("TSetMethods")

var Lit_246 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$fn__367000530")

var Lit_247 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$fn__367000532")

var Lit_248 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$fn__367000534")

var Lit_249 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$fn__367000536")

var Lit_250 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000478__367000482$fn__367000483")

var Lit_251 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000478__367000482$fn__367000483$fn__367000484")

var Lit_252 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000478__367000482$fn__367000483$fn__367000512")

var Lit_253 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000478__367000482$fn__367000483$fn__367000519")

var Lit_254 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000478__367000482$fn__367000483$fn__367000522")

var Lit_255 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000478__367000482$fn__367000483$fn__367000484$fn__367000491")

var Lit_256 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000478__367000482$fn__367000483$fn__367000484$fn__367000498")

var Lit_257 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000478__367000482$fn__367000483$fn__367000484$fn__367000501")

var Lit_258 *jrt.String = jrt.Intern("goi: no method ")

var Lit_259 *jrt.String = jrt.Intern("not supported by goi yet")

var Lit_260 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000478__367000482$fn__367000483$fn__367000484$fn__367000501$fn__367000502")

var Lit_261 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000478__367000482$fn__367000483$fn__367000522$fn__367000523")

var Lit_262 *jrt.String = jrt.Intern("error")

var Lit_263 *jrt.String = jrt.Intern("arbace.lang.GoInterp")

var Lit_264 *jrt.String = jrt.Intern("java.util.HashMap")

var Lit_265 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_266 *jrt.String = jrt.Intern("ThenF")

var Lit_267 *jrt.String = jrt.Intern("ThenR")

var Lit_268 *jrt.String = jrt.Intern("ThenS")

var Lit_269 *jrt.String = jrt.Intern("Recv")

var Lit_270 *jrt.String = jrt.Intern("DerefP")

var Lit_271 *jrt.String = jrt.Intern("IndexS")

var Lit_272 *jrt.String = jrt.Intern("arbace.go.build$ex_STAR_$fn__367000280")

var Lit_273 *jrt.String = jrt.Intern("SliceString")

var Lit_274 *jrt.String = jrt.Intern("SliceSlice")

var Lit_275 *jrt.String = jrt.Intern("SliceArray")

var Lit_276 *jrt.String = jrt.Intern("MapGet")

var Lit_277 *jrt.String = jrt.Intern("ZeroR")

var Lit_278 *jrt.String = jrt.Intern("a type of a package not in the table, in ")

var Lit_279 *jrt.String = jrt.Intern("GR5")

var Lit_280 *jrt.String = jrt.Intern("the expression ")

var Lit_281 *jrt.String = jrt.Intern("ExprB")

var Lit_282 *jrt.String = jrt.Intern("ExprF")

var Lit_283 *jrt.String = jrt.Intern("ExprI")

var Lit_284 *jrt.String = jrt.Intern("ExprR")

var Lit_285 *jrt.String = jrt.Intern("ExprS")

var Lit_286 *jrt.String = jrt.Intern("LoadR")

var Lit_287 *jrt.String = jrt.Intern("arbace.go.build$field_sel$fn__367000365")

var Lit_288 *jrt.String = jrt.Intern("arbace.go.build$for_stmt$fn__367000783")

var Lit_289 *jrt.String = jrt.Intern("For")

var Lit_290 *jrt.String = jrt.Intern("arbace.go.build$free_locals$walk__367001047")

var Lit_291 *jrt.String = jrt.Intern("arbace.go.build$free_locals$fn__367001080")

var Lit_292 *jrt.String = jrt.Intern("FromMemR")

var Lit_293 *jrt.String = jrt.Intern("FuncValue")

var Lit_294 *jrt.String = jrt.Intern("MemberValue")

var Lit_295 *jrt.String = jrt.Intern("GoStmt")

var Lit_296 *jrt.String = jrt.Intern("arbace.go.build$go_string_node$fn__367000118")

var Lit_297 *jrt.String = jrt.Intern("ConstS")

var Lit_298 *jrt.String = jrt.Intern("ConstSB")

var Lit_299 *jrt.String = jrt.Intern("arbace.go.build$go_string_node$fn__367000120")

var Lit_300 *jrt.String = jrt.Intern("arbace.go.build$has_defer_QMARK_$walk__367001035")

var Lit_301 *jrt.String = jrt.Intern("IdxSlot")

var Lit_302 *jrt.String = jrt.Intern("IdxNewCell")

var Lit_303 *jrt.String = jrt.Intern("IdxStore")

var Lit_304 *jrt.String = jrt.Intern("arbace.go.build$iface_call$fn__367000409")

var Lit_305 *jrt.String = jrt.Intern("ErrorCall")

var Lit_306 *jrt.String = jrt.Intern("CompiledDispatchT")

var Lit_307 *jrt.String = jrt.Intern("CompiledDispatch")

var Lit_308 *jrt.String = jrt.Intern("ThenT")

var Lit_309 *jrt.String = jrt.Intern("CallIfaceT")

var Lit_310 *jrt.String = jrt.Intern("Then")

var Lit_311 *jrt.String = jrt.Intern("CallIface")

var Lit_312 *jrt.String = jrt.Intern("IfaceI")

var Lit_313 *jrt.String = jrt.Intern("IfaceF")

var Lit_314 *jrt.String = jrt.Intern("IfaceR")

var Lit_315 *jrt.String = jrt.Intern("IfaceS")

var Lit_316 *jrt.String = jrt.Intern("IfaceMethodValue")

var Lit_317 *jrt.String = jrt.Intern("interface {}")

var Lit_318 *jrt.String = jrt.Intern("+")

var Lit_319 *jrt.String = jrt.Intern("-")

var Lit_320 *jrt.String = jrt.Intern("SliceElemP")

var Lit_321 *jrt.String = jrt.Intern("ArrayElemP")

var Lit_322 *jrt.String = jrt.Intern("indexing ")

var Lit_323 *jrt.String = jrt.Intern("NewCellInit")

var Lit_324 *jrt.String = jrt.Intern("arbace.go.build$inst_tree$ty__367001209")

var Lit_325 *jrt.String = jrt.Intern("arbace.go.build$inst_tree$obj__367001211")

var Lit_326 *jrt.String = jrt.Intern("arbace.go.build$inst_tree$const_fix__367001213")

var Lit_327 *jrt.String = jrt.Intern("arbace.go.build$inst_tree$node__367001218")

var Lit_328 *jrt.String = jrt.Intern("arbace.go.build$inst_tree$node__367001218$fn__367001219")

var Lit_329 *jrt.String = jrt.Intern("Sizeof")

var Lit_330 *jrt.String = jrt.Intern("Offsetof")

var Lit_331 *jrt.String = jrt.Intern("Alignof")

var Lit_332 *jrt.String = jrt.Intern("InterpMethodCallable")

var Lit_333 *jrt.String = jrt.Intern("InterpCallable")

var Lit_334 *jrt.String = jrt.Intern("reflect")

var Lit_335 *jrt.String = jrt.Intern("TypeFor")

var Lit_336 *jrt.String = jrt.Intern("goiNilType")

var Lit_337 *jrt.String = jrt.Intern("goi: TypeFor of an interpreted interface")

var Lit_338 *jrt.String = jrt.Intern("reflect.TypeFor of the interpreted interface ")

var Lit_339 *jrt.String = jrt.Intern(": its reflect type is any (§5.2)")

var Lit_340 *jrt.String = jrt.Intern("G8")

var Lit_341 *jrt.String = jrt.Intern("arbace.go.build$instance_cell_STAR_$fn__367001270")

var Lit_342 *jrt.String = jrt.Intern("arbace.go.build$instance_cell_STAR_$fn__367001272")

var Lit_343 *jrt.String = jrt.Intern("arbace.go.build$instance_cell_STAR_$fn__367001272$fn__367001273")

var Lit_344 *jrt.String = jrt.Intern("[...]")

var Lit_345 *jrt.String = jrt.Intern("(*")

var Lit_346 *jrt.String = jrt.Intern(").")

var Lit_347 *jrt.String = jrt.Intern("LK64")

var Lit_348 *jrt.String = jrt.Intern("LL64")

var Lit_349 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001164")

var Lit_350 *jrt.String = jrt.Intern("arbace.go.build$isubst$terms__367001166")

var Lit_351 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001175")

var Lit_352 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001177")

var Lit_353 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001179")

var Lit_354 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001181")

var Lit_355 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001183")

var Lit_356 *jrt.String = jrt.Intern("arbace.go.build$isubst$terms__367001166$fn__367001168")

var Lit_357 *jrt.String = jrt.Intern("Jump")

var Lit_358 *jrt.String = jrt.Intern("arbace.go.build$layout_needed_QMARK_$walk__367000046")

var Lit_359 *jrt.String = jrt.Intern("arbace.go.build$layout_needed_QMARK_$walk__367000046$fn__367000048")

var Lit_360 *jrt.String = jrt.Intern("arbace.go.build$layout_needed_QMARK_$walk__367000046$fn__367000050")

var Lit_361 *jrt.String = jrt.Intern("arbace.go.build$layout_needed_QMARK_$walk__367000046$fn__367000052")

var Lit_362 *jrt.String = jrt.Intern("arbace.go.build$lazily$fn__367000017")

var Lit_363 *jrt.String = jrt.Intern("arbace.go.build$lazily$fn__367000017$fn__367000018")

var Lit_364 *jrt.String = jrt.Intern("goi: unsupported: ")

var Lit_365 *jrt.String = jrt.Intern("LitMap")

var Lit_366 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000250")

var Lit_367 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000252")

var Lit_368 *jrt.String = jrt.Intern("LitSlice")

var Lit_369 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000254")

var Lit_370 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000256")

var Lit_371 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000217")

var Lit_372 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000219__367000223")

var Lit_373 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000233")

var Lit_374 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000235")

var Lit_375 *jrt.String = jrt.Intern("ElemSize")

var Lit_376 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000237")

var Lit_377 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000239")

var Lit_378 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000219__367000223$fn__367000224")

var Lit_379 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000219__367000223$fn__367000224$fn__367000225")

var Lit_380 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000219__367000223$fn__367000224$fn__367000229")

var Lit_381 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000219__367000223$fn__367000224$fn__367000225$fn__367000226")

var Lit_382 *jrt.String = jrt.Intern("a literal key promoted through a pointer")

var Lit_383 *jrt.String = jrt.Intern("LoadF")

var Lit_384 *jrt.String = jrt.Intern("LoadI")

var Lit_385 *jrt.String = jrt.Intern("LoadS")

var Lit_386 *jrt.String = jrt.Intern("goi's builder: no location for ")

var Lit_387 *jrt.String = jrt.Intern("LocalF")

var Lit_388 *jrt.String = jrt.Intern("LocalI")

var Lit_389 *jrt.String = jrt.Intern("LocalR")

var Lit_390 *jrt.String = jrt.Intern("LocalS")

var Lit_391 *jrt.String = jrt.Intern("arbace.go.build$local_types$walk__367001186")

var Lit_392 *jrt.String = jrt.Intern("MemR")

var Lit_393 *jrt.String = jrt.Intern("GR8a")

var Lit_394 *jrt.String = jrt.Intern("arbace.go.build$method_candidates$walk__367000452")

var Lit_395 *jrt.String = jrt.Intern("arbace.go.build$method_count$iter__367000539__367000543")

var Lit_396 *jrt.String = jrt.Intern("arbace.go.build$method_count$iter__367000539__367000543$fn__367000544")

var Lit_397 *jrt.String = jrt.Intern("arbace.go.build$method_count$iter__367000539__367000543$fn__367000544$fn__367000545")

var Lit_398 *jrt.String = jrt.Intern("arbace.go.build$method_expr_node$fn__367000446")

var Lit_399 *jrt.String = jrt.Intern("-fm")

var Lit_400 *jrt.String = jrt.Intern("arbace.go.build$method_expr_node$fn__367000449")

var Lit_401 *jrt.String = jrt.Intern("BoundCompiled")

var Lit_402 *jrt.String = jrt.Intern("MethodValue")

var Lit_403 *jrt.String = jrt.Intern("TCompiled")

var Lit_404 *jrt.String = jrt.Intern("TNamedIface")

var Lit_405 *jrt.String = jrt.Intern("TNamed")

var Lit_406 *jrt.String = jrt.Intern("TShape")

var Lit_407 *jrt.String = jrt.Intern("arbace.go.build$named_desc1$fn__367000090")

var Lit_408 *jrt.String = jrt.Intern("TSetUnder")

var Lit_409 *jrt.String = jrt.Intern("used before it is complete")

var Lit_410 *jrt.String = jrt.Intern(", recursive, used before it is complete")

var Lit_411 *jrt.String = jrt.Intern("as built: GR9a-c")

var Lit_412 *jrt.String = jrt.Intern("SetC")

var Lit_413 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells$fn__367000774")

var Lit_414 *jrt.String = jrt.Intern("RenewCells")

var Lit_415 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells$fn__367000776")

var Lit_416 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells$fn__367000778")

var Lit_417 *jrt.String = jrt.Intern("VarP")

var Lit_418 *jrt.String = jrt.Intern("GlobalP")

var Lit_419 *jrt.String = jrt.Intern("goi's builder: ")

var Lit_420 *jrt.String = jrt.Intern(" is not a cell")

var Lit_421 *jrt.String = jrt.Intern("the address of a ")

var Lit_422 *jrt.String = jrt.Intern("arbace.go.build$prepare_place$freeze__367000682")

var Lit_423 *jrt.String = jrt.Intern("arbace.go.build$prepare_place$chain__367000684")

var Lit_424 *jrt.String = jrt.Intern("arbace.go.build$quiet_expr_QMARK_$fn__367000739")

var Lit_425 *jrt.String = jrt.Intern("arbace.go.build$quiet_expr_QMARK_$fn__367000741")

var Lit_426 *jrt.String = jrt.Intern("arbace.go.build$quiet_expr_QMARK_$fn__367000743")

var Lit_427 *jrt.String = jrt.Intern("arbace.go.build$quiet_expr_QMARK_$fn__367000745")

var Lit_428 *jrt.String = jrt.Intern("arbace.go.build$quiet_header_QMARK_$fn__367000755")

var Lit_429 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$conv_QMARK___367000828")

var Lit_430 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000831")

var Lit_431 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000836")

var Lit_432 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000838")

var Lit_433 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000841")

var Lit_434 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$mk__367000849")

var Lit_435 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000857")

var Lit_436 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000859")

var Lit_437 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000861")

var Lit_438 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000863")

var Lit_439 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000865")

var Lit_440 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000867")

var Lit_441 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000869")

var Lit_442 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000871")

var Lit_443 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000873")

var Lit_444 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000875")

var Lit_445 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000877")

var Lit_446 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000885")

var Lit_447 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000888")

var Lit_448 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000893")

var Lit_449 *jrt.String = jrt.Intern("RangeFunc")

var Lit_450 *jrt.String = jrt.Intern("RangeMap")

var Lit_451 *jrt.String = jrt.Intern("RangeInt")

var Lit_452 *jrt.String = jrt.Intern("RangeArray")

var Lit_453 *jrt.String = jrt.Intern("RangePtrArray")

var Lit_454 *jrt.String = jrt.Intern("RangeChan")

var Lit_455 *jrt.String = jrt.Intern("RangeString")

var Lit_456 *jrt.String = jrt.Intern("RangeSlice")

var Lit_457 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$mk__367000849$fn__367000850")

var Lit_458 *jrt.String = jrt.Intern("arbace.go.build$range_targets$fn__367000788")

var Lit_459 *jrt.String = jrt.Intern("arbace.go.build$range_targets$fn__367000790")

var Lit_460 *jrt.String = jrt.Intern("arbace.go.build$recursive_QMARK_$walk__367000037")

var Lit_461 *jrt.String = jrt.Intern("arbace.go.build$recursive_QMARK_$walk__367000037$fn__367000039")

var Lit_462 *jrt.String = jrt.Intern("DerefWrapP")

var Lit_463 *jrt.String = jrt.Intern("goi's builder: no receiver type for the method ")

var Lit_464 *jrt.String = jrt.Intern("a named type of ")

var Lit_465 *jrt.String = jrt.Intern("goi's builder: no method ")

var Lit_466 *jrt.String = jrt.Intern(" of ")

var Lit_467 *jrt.String = jrt.Intern("arbace.go.build$return_stmt$store__367000936")

var Lit_468 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000661")

var Lit_469 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000666")

var Lit_470 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000668")

var Lit_471 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000670")

var Lit_472 *jrt.String = jrt.Intern("Assert2")

var Lit_473 *jrt.String = jrt.Intern("MapGet2")

var Lit_474 *jrt.String = jrt.Intern("Recv2")

var Lit_475 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000676")

var Lit_476 *jrt.String = jrt.Intern("int32")

var Lit_477 *jrt.String = jrt.Intern("uint8")

var Lit_478 *jrt.String = jrt.Intern("main.")

var Lit_479 *jrt.String = jrt.Intern("map[")

var Lit_480 *jrt.String = jrt.Intern("]")

var Lit_481 *jrt.String = jrt.Intern("[")

var Lit_482 *jrt.String = jrt.Intern("<-chan ")

var Lit_483 *jrt.String = jrt.Intern("chan ")

var Lit_484 *jrt.String = jrt.Intern("chan<- ")

var Lit_485 *jrt.String = jrt.Intern("interface { ")

var Lit_486 *jrt.String = jrt.Intern(" }")

var Lit_487 *jrt.String = jrt.Intern("; ")

var Lit_488 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001231__367001235")

var Lit_489 *jrt.String = jrt.Intern("[]")

var Lit_490 *jrt.String = jrt.Intern("func")

var Lit_491 *jrt.String = jrt.Intern("*")

var Lit_492 *jrt.String = jrt.Intern("struct {}")

var Lit_493 *jrt.String = jrt.Intern("struct { ")

var Lit_494 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001241__367001245")

var Lit_495 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001231__367001235$fn__367001236")

var Lit_496 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001231__367001235$fn__367001236$fn__367001237")

var Lit_497 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001241__367001245$fn__367001246")

var Lit_498 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001241__367001245$fn__367001246$fn__367001247")

var Lit_499 *jrt.String = jrt.Intern(" ")

var Lit_500 *jrt.String = jrt.Intern("(")

var Lit_501 *jrt.String = jrt.Intern(")")

var Lit_502 *jrt.String = jrt.Intern(", ")

var Lit_503 *jrt.String = jrt.Intern("arbace.go.build$rt_sig$fn__367001256")

var Lit_504 *jrt.String = jrt.Intern(" (")

var Lit_505 *jrt.String = jrt.Intern("...")

var Lit_506 *jrt.String = jrt.Intern("arbace.go.build$select_recv$find_recv__367000995")

var Lit_507 *jrt.String = jrt.Intern("arbace.go.build$select_recv$replace_recv__367000997")

var Lit_508 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367001002__367001006")

var Lit_509 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$fn__367001024")

var Lit_510 *jrt.String = jrt.Intern("Select")

var Lit_511 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367001002__367001006$fn__367001007")

var Lit_512 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367001002__367001006$fn__367001007$fn__367001008")

var Lit_513 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367001002__367001006$fn__367001007$fn__367001016")

var Lit_514 *jrt.String = jrt.Intern("NewSelCase")

var Lit_515 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367001002__367001006$fn__367001007$fn__367001020")

var Lit_516 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367001002__367001006$fn__367001007$fn__367001008$fn__367001009")

var Lit_517 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367001002__367001006$fn__367001007$fn__367001008$fn__367001013")

var Lit_518 *jrt.String = jrt.Intern("Send")

var Lit_519 *jrt.String = jrt.Intern("arbace.go.build$set_iface_methods_now_BANG_$sig__367000078")

var Lit_520 *jrt.String = jrt.Intern("TSetIfaceMethods")

var Lit_521 *jrt.String = jrt.Intern("arbace.go.build$set_iface_methods_now_BANG_$fn__367000080")

var Lit_522 *jrt.String = jrt.Intern("SetF")

var Lit_523 *jrt.String = jrt.Intern("SetI")

var Lit_524 *jrt.String = jrt.Intern("SetR")

var Lit_525 *jrt.String = jrt.Intern("SetS")

var Lit_526 *jrt.String = jrt.Intern("arbace.go.build$shape_type$fn__367000058")

var Lit_527 *jrt.String = jrt.Intern("arbace.go.build$slot_layout$take_BANG___367000292")

var Lit_528 *jrt.String = jrt.Intern("arbace.go.build$slot_layout$fn__367000294")

var Lit_529 *jrt.String = jrt.Intern("arbace.go.build$slot_layout$fn__367000296")

var Lit_530 *jrt.String = jrt.Intern("If")

var Lit_531 *jrt.String = jrt.Intern("goi's builder: fallthrough outside a switch")

var Lit_532 *jrt.String = jrt.Intern("goi's builder: no continue target ")

var Lit_533 *jrt.String = jrt.Intern("arbace.go.build$stmt$fn__367001030")

var Lit_534 *jrt.String = jrt.Intern("goi's builder: no break target ")

var Lit_535 *jrt.String = jrt.Intern("arbace.go.build$stmt$fn__367001032")

var Lit_536 *jrt.String = jrt.Intern("the statement ")

var Lit_537 *jrt.String = jrt.Intern("StoreF")

var Lit_538 *jrt.String = jrt.Intern("StoreI")

var Lit_539 *jrt.String = jrt.Intern("StoreR")

var Lit_540 *jrt.String = jrt.Intern("StoreS")

var Lit_541 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000066")

var Lit_542 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000068")

var Lit_543 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000070")

var Lit_544 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000072")

var Lit_545 *jrt.String = jrt.Intern("command-line-arguments")

var Lit_546 *jrt.String = jrt.Intern("main")

var Lit_547 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000899")

var Lit_548 *jrt.String = jrt.Intern("Switch")

var Lit_549 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000899$iter__367000900__367000904")

var Lit_550 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000899$iter__367000900__367000904$fn__367000905")

var Lit_551 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000899$iter__367000900__367000904$fn__367000905$fn__367000906")

var Lit_552 *jrt.String = jrt.Intern("NewCase")

var Lit_553 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000899$iter__367000900__367000904$fn__367000905$iter__367000920__367000924")

var Lit_554 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000899$iter__367000900__367000904$fn__367000905$fn__367000930")

var Lit_555 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000899$iter__367000900__367000904$fn__367000905$fn__367000906$iter__367000907__367000911")

var Lit_556 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000899$iter__367000900__367000904$fn__367000905$fn__367000906$fn__367000917")

var Lit_557 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000899$iter__367000900__367000904$fn__367000905$fn__367000906$iter__367000907__367000911$fn__367000912")

var Lit_558 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000899$iter__367000900__367000904$fn__367000905$fn__367000906$iter__367000907__367000911$fn__367000912$fn__367000913")

var Lit_559 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000899$iter__367000900__367000904$fn__367000905$iter__367000920__367000924$fn__367000925")

var Lit_560 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000899$iter__367000900__367000904$fn__367000905$iter__367000920__367000924$fn__367000925$fn__367000926")

var Lit_561 *jrt.String = jrt.Intern(",")

var Lit_562 *jrt.String = jrt.Intern(";")

var Lit_563 *jrt.String = jrt.Intern("·")

var Lit_564 *jrt.String = jrt.Intern("arbace.go.build$temps_of$fn__367000636")

var Lit_565 *jrt.String = jrt.Intern("arbace.go.build$temps_of$fn__367000643")

var Lit_566 *jrt.String = jrt.Intern("arbace.go.build$temps_of$fn__367000652")

var Lit_567 *jrt.String = jrt.Intern("arbace.go.build$thunk_body$fn__367000435")

var Lit_568 *jrt.String = jrt.Intern("arbace.go.build$thunk_body$fn__367000438")

var Lit_569 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000972__367000976")

var Lit_570 *jrt.String = jrt.Intern("TypeSwitch")

var Lit_571 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000972__367000976$fn__367000977")

var Lit_572 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000972__367000976$fn__367000977$fn__367000978")

var Lit_573 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000972__367000976$fn__367000977$fn__367000986")

var Lit_574 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000972__367000976$fn__367000977$fn__367000988")

var Lit_575 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000972__367000976$fn__367000977$fn__367000990")

var Lit_576 *jrt.String = jrt.Intern("NewTCase")

var Lit_577 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000972__367000976$fn__367000977$fn__367000978$fn__367000979")

var Lit_578 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000972__367000976$fn__367000977$fn__367000978$fn__367000981")

var Lit_579 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000972__367000976$fn__367000977$fn__367000978$fn__367000983")

var Lit_580 *jrt.String = jrt.Intern("arbace.go.build$uidx_mask$fn__367000206")

var Lit_581 *jrt.String = jrt.Intern("bit-not")

var Lit_582 *jrt.String = jrt.Intern("Compl")

var Lit_583 *jrt.String = jrt.Intern("NegF")

var Lit_584 *jrt.String = jrt.Intern("Neg")

var Lit_585 *jrt.String = jrt.Intern("NegC64")

var Lit_586 *jrt.String = jrt.Intern("NegC128")

var Lit_587 *jrt.String = jrt.Intern("not")

var Lit_588 *jrt.String = jrt.Intern("not supported by goi yet: ")

var Lit_589 *jrt.String = jrt.Intern("CallValue")

var Lit_590 *jrt.String = jrt.Intern("arbace.go.build$value_call$fn__367000339")

var Lit_591 *jrt.String = jrt.Intern("CallValueT")

var Lit_592 *jrt.String = jrt.Intern("arbace.go.build$via_iface$iter__367000378__367000382")

var Lit_593 *jrt.String = jrt.Intern("arbace.go.build$via_iface$iter__367000378__367000382$fn__367000383")

var Lit_594 *jrt.String = jrt.Intern("arbace.go.build$via_iface$iter__367000378__367000382$fn__367000383$fn__367000384")

var Lit_595 *jrt.String = jrt.Intern("arbace.go.build$via_iface$iter__367000378__367000382$fn__367000383$fn__367000394")

var Lit_596 *jrt.String = jrt.Intern("arbace.go.build$via_iface$iter__367000378__367000382$fn__367000383$fn__367000384$fn__367000388")

var Lit_597 *jrt.String = jrt.Intern("NewCell")

var Lit_598 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistskn3,tagyn6,Stringyn1,&yn4,argskn4,linekn6,columnkn4,filekn7,privateyn2,xsyn4,whatyn2,gryn1,fkn7,dynamicyn1,myn2,ntyn3,ctxyn4,pathkn5,int32kn5,int16kn3,intkn5,int64kn4,uintkn6,uint64kn7,uintptrkn12,untyped-runekn6,uint16kn12,untyped-boolkn4,int8kn6,uint32kn11,untyped-intkn4,boolkn5,uint8yn2,tykn8,declaredyn3,tagyn1,uyn2,nmyn3,pkgyn1,dyn1,vyn4,wantyn1,kyn1,xyn1,syn1,nyn1,pyn2,knyn3,op*yn2,xnyn2,ynyn1,yyn2,xkyn2,ykyn9,ycount-tyv11,arbace.core5,in-nsMyn15,arbace.go.buildm2,R0,s1640,goi's builder (doc/go/GOI-SPEC.md §4.1): the checked tree (§3.7) made nodes, typed Go\n  closures of the back end arbace/goi, by its factories through arbace.lang.GoInterp's op\n  native (go/arbace/goi/registry.ae). It numbers each function's slots per kind (parameters and\n  results first, as the signature lays them out), makes the variables that live in Go memory\n  cells (captured, addressed, of a struct or array type, every package variable), gives each\n  jump target its codes, chooses each node's variant by its operands' types, and resolves each\n  call to the callee's cell, a closure, or the table's member. It decides nothing the checker\n  has not: no type, no constant, no resolution.\n\n  GR3 builds the interpreter's core: scalars, strings, slices, arrays, maps, structs, pointers,\n  functions and closures, all control flow with labels and goto, defer, panic and recover,\n  interface values without methods (§5.3 rules 1 and 2), the calls of compiled Go. GR4 adds\n  methods (their receiver laid after the parameters and results), method values and\n  expressions, the method sets of the types that go into interfaces (each entry the method or a\n  thunk: §5.3), interface method calls, type assertions and switches, embedding and promotion,\n  goroutines, channels, select and range over functions and channels. GR6 adds generics (§9.2):\n  each instance of a generic function, method or type built per type-argument list from the\n  generic declaration's checked tree with its type parameters substituted (inst-tree). A form\n  that needs what goi does not run is \"not supported by goi yet\" (§3.4), an ex-info with\n  :goi/unsupported.m2,R0,s1640,goi's builder (doc/go/GOI-SPEC.md §4.1): the checked tree (§3.7) made nodes, typed Go\n  closures of the back end arbace/goi, by its factories through arbace.lang.GoInterp's op\n  native (go/arbace/goi/registry.ae). It numbers each function's slots per kind (parameters and\n  results first, as the signature lays them out), makes the variables that live in Go memory\n  cells (captured, addressed, of a struct or array type, every package variable), gives each\n  jump target its codes, chooses each node's variant by its operands' types, and resolves each\n  call to the callee's cell, a closure, or the table's member. It decides nothing the checker\n  has not: no type, no constant, no resolution.\n\n  GR3 builds the interpreter's core: scalars, strings, slices, arrays, maps, structs, pointers,\n  functions and closures, all control flow with labels and goto, defer, panic and recover,\n  interface values without methods (§5.3 rules 1 and 2), the calls of compiled Go. GR4 adds\n  methods (their receiver laid after the parameters and results), method values and\n  expressions, the method sets of the types that go into interfaces (each entry the method or a\n  thunk: §5.3), interface method calls, type assertions and switches, embedding and promotion,\n  goroutines, channels, select and range over functions and channels. GR6 adds generics (§9.2):\n  each instance of a generic function, method or type built per type-argument list from the\n  generic declaration's checked tree with its type parameters substituted (inst-tree). A form\n  that needs what goi does not run is \"not supported by goi yet\" (§3.4), an ex-info with\n  :goi/unsupported.R1,v15,arbace.go.build2,opm10,R2,L1,V3,Myn2,nmm2,R3,R4,R5,R6,R0,s65,Makes what goi's factory nm makes of args (GoInterp's op native).R7,i33,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build2,oam10,R10,TR2,L1,V1,R11,R7,i38,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,unsupported!m10,R2,L1,V2,R12,R13,R0,s93,Ends the build of a form goi does not support yet (§3.4): what, the milestone that brings it.R7,i40,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,program-modem8,R0,s55,Program mode (bin/goi run, §2.7): set by arbace.go.run.R7,i45,R8,i1,R9,s18,arbace/go/build.aev11,arbace.core4,atomm8,R0,s55,Program mode (bin/goi run, §2.7): set by arbace.go.run.R7,i45,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build6,lazilym10,R2,L1,V1,R14,R0,s230,Builder f of a function's code for SetCode, built on its first call; in program mode a form\n  goi does not support ends the run as it would before the run (goi: unsupported, status 125:\n  GR6, the generic code built per instance).R7,i47,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,*ctx*m10,R15,TR7,i64,R8,i1,R9,s18,arbace/go/build.aeR0,s271,The package's build context: {:path :name :compiled? (path -> listed?) :types (a HashMap of\n  descriptors by checker type) :gen (named type -> its generation) :func-cell (function object\n  -> its *goi.Func) :global (variable object -> {:ptr :type}) :local-gen (an atom)}.v15,arbace.go.build9,local-genm8,R0,s152,The generations of local named types: one counter for every build, so that their\n  descriptors (interned by package, name and generation) stay distinct.R7,i70,R8,i1,R9,s18,arbace/go/build.ael1000000,m8,R0,s152,The generations of local named types: one counter for every build, so that their\n  descriptors (interned by package, name and generation) stay distinct.R7,i70,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,method-datam10,R2,L1,V1,R16,R0,s104,The checker's method data of method object m (its declaration checked): t/*method-obj*\n  while building.R7,i73,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build18,complete-instance!m10,R2,L1,V1,R17,R0,s86,Completes a generic type's instance (its underlying type, made lazily) while building.R7,i80,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,with-ctxm10,R2,L1,V2,R18,R14,R0,s129,Calls f with the package's build context ctx bound (and the checker's method data, the\n  instances' completion and methods: GR6).R7,i85,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,*fn*m10,R15,TR7,i93,R8,i1,R9,s18,arbace/go/build.aeR0,s362,The function being built: {:slots (volatile counts per kind) :locs (an IdentityHashMap of\n  variables to [:slot k n] or [:cell c]) :code (the next jump code) :defer (volatile) :targets\n  (the breakable statements, innermost last) :labels (a HashMap of label names to codes)\n  :results :calls (the calls of several results, by identity: their temporaries) :name}.v15,arbace.go.build9,compiled?m10,R10,TR2,L1,V1,R19,R7,i100,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,int-kwsS15,R20,R21,R22,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,m8,R10,TR7,i104,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,kindm10,R2,L1,V1,R35,R0,s79,The slot kind of a value of checker type ty: :I (integers, bool), :F, :S or :R.R7,i107,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,int-sfxm26,R30,s2,I8R21,s3,I16R20,s3,I32R23,s3,I64R22,s1,IR34,s2,U8R28,s3,U16R31,s3,U32R25,s3,U64R24,s1,UR26,s2,UPR32,s1,IR27,s3,I32m8,R10,TR7,i119,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,basic-ofm10,R10,TR2,L1,V1,R35,R7,i123,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,unsigned?m10,R10,TR2,L1,V1,R35,R7,i124,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,wide?m10,R10,TR2,L1,V1,R35,R7,i125,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build16,struct-or-array?m10,R10,TR2,L1,V1,R35,R7,i126,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build6,iface?m10,R10,TR2,L1,V1,R35,R7,i127,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,descm8,R36,TR7,i129,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,inst-type?m10,R10,TR2,L1,V1,R35,R7,i131,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build18,interpreted-named?m12,R10,TR2,L1,V1,R35,R0,s163,Whether named type ty is interpreted: of an interpreted package, or a generic type's instance\n  (a compiled package's too: gc compiled none of them for goi, §9.3).R7,i133,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,recursive?m12,R10,TR2,L1,V1,R17,R0,s64,Whether named type nt is reachable from its own underlying type.R7,i139,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build14,layout-needed?m12,R10,TR2,L1,V1,R17,R0,s593,Whether named type nt's layout is read before its underlying type is complete (GC70): nt is\n  the type of a struct's field, an array's element or a map's key or element (whose\n  constructors, StructOf, ArrayOf and MapOf, read their parts' layouts) among the types made\n  while nt's is (its parts, and the underlying types of the named types they reach). Its RT then\n  has its shape's layout first (`shape-type`, reflect.ArbaceSetLayout); a type reaching itself\n  only through pointers, slices, channels and functions needs nothing: its RT exists before its\n  underlying type is built (GR9a-c).R7,i162,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,shape-typem12,R10,TR2,L1,V1,R35,R0,s302,The shape of type ty (GR7a; since GR9a-c only a layout, GC70): a checker type of its layout\n  and pointer words, every pointer, map, channel and function an unsafe.Pointer, every slice a\n  []unsafe.Pointer, a recursive interpreted named type its underlying type's shape; other named\n  types themselves.R7,i191,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,tag-textm10,R10,TR2,L1,V1,R37,R7,i207,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,struct-partsm12,R10,TR2,L1,V1,R38,R0,s130,The parts of struct type u for the factories: names, field descriptors, tags, package paths\n  of unexported names, embedded flags.R7,i209,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,method-keym10,R2,L1,V2,R39,R40,R0,s74,A method's key in method sets (§5.3): its name, path.name when unexported.R7,i219,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build15,*iface-pending*m12,R10,TR15,TR7,i224,R8,i1,R9,s18,arbace/go/build.aeR0,s208,The interface descriptors whose methods wait for the outermost `desc` (GR7a): their\n  signatures may name a type still being built (`type Cons[a] struct{Tail List[a]}`, `List[a]`'s\n  method naming `Cons[a]`).v15,arbace.go.build22,set-iface-methods-now!m8,R36,TR7,i230,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build18,set-iface-methods!m12,R10,TR2,L1,V2,R41,R35,R0,s92,Gives interface descriptor d of type ty its methods, once the outermost descriptor is built.R7,i232,R8,i1,R9,s18,arbace/go/build.aem12,R10,TR2,L1,V2,R41,R35,R0,s87,Gives interface descriptor d of type ty its methods (keys and signatures' descriptors).R7,i239,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build17,*methods-pending*m12,R10,TR15,TR7,i247,R8,i1,R9,s18,arbace/go/build.aeR0,s177,The interpreted named types whose method sets wait for the outermost `desc` (GR9a): [descriptor\n  type] pairs, their methods' signatures possibly naming types still being built.v15,arbace.go.build12,method-countm8,R36,TR7,i252,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build18,set-named-methods!m8,R36,TR7,i252,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,reflect-kindm12,R10,TR2,L1,V1,R38,R0,s53,The reflect.Kind of the Go kind of underlying type u.R7,i254,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,local-gen-ofm10,R10,TR2,L1,V1,R35,R7,i267,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,inst-genm8,R36,TR7,i271,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build14,inst-type-namem8,R36,TR7,i271,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,desc-typesm8,R0,s170,The checker types of interpreted named types' descriptors (GR9d): descriptor ->\n  the type it was last made for, by which arbace.go.generic types Go values for inference.R7,i273,R8,i1,R9,s18,arbace/go/build.aem8,R0,s170,The checker types of interpreted named types' descriptors (GR9d): descriptor ->\n  the type it was last made for, by which arbace.go.generic types Go values for inference.R7,i273,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,named-desc1m8,R36,TR7,i277,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,named-descm10,R10,TR2,L1,V1,R35,R7,i279,R8,i1,R9,s18,arbace/go/build.aem10,R10,TR2,L1,V1,R35,R7,i286,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,desc1m8,R36,TR7,i343,R8,i1,R9,s18,arbace/go/build.aem10,R2,L1,V1,R35,R0,s75,The descriptor (a *goi.Type) of checker type ty, one per type in the build.R7,i345,R8,i1,R9,s18,arbace/go/build.aem10,R10,TR2,L1,V1,R35,R7,i370,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,int-bitsm12,R10,TR2,L1,V1,R42,R0,s57,Integer constant v as the int64 of its normalized I slot.R7,i404,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build14,go-string-nodem12,R10,TR2,L1,V1,Myn1,vm2,R3,R4,R0,s69,A string constant node of value v (the checker's: one char per byte).R7,i409,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build13,complex-valuem10,R10,TR2,L1,V2,R35,R42,R7,i416,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,const-nodem10,R2,L1,V3,R35,R42,R43,R0,s66,[kind node] of constant value v of type ty (want :B: a condition).R7,i423,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,new-slot!m10,R10,TR2,L1,V1,R44,R7,i438,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,next-code!m10,R10,TR2,L1,V0,R7,i444,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,label-code!m12,R10,TR2,L1,V1,R39,R0,s50,The goto code of label nm (assigned on first use).R7,i447,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,label-entrym10,R10,TR2,L1,V1,R39,R7,i454,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,cell-var?m10,R2,L1,V1,R45,R0,s53,Whether variable x lives in Go memory (a cell, §4.3).R7,i458,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build3,locm10,R10,TR2,L1,V1,R45,R7,i463,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,new-loc!m12,R10,TR2,L1,V1,R45,R0,s76,A location for a new variable x: a slot of its kind, or a C slot for a cell.R7,i467,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,temp!m10,R10,TR2,L1,V1,R44,R7,i474,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,local-nodem10,R10,TR2,L1,V2,R44,R46,R7,i478,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,as-kindm10,R2,L1,V2,V2,R44,R47,R43,R0,s54,Node [k n] as kind want (:B from an :I bool and back).R7,i480,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build6,load-pm12,R10,TR2,L1,V2,R48,R35,R0,s55,The value of type ty at place p, as a node of its kind.R7,i489,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,store-pm12,R10,TR2,L1,V3,R48,R49,R35,R0,s57,The statement storing node [k n] (of type ty) at place p.R7,i500,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,set-slotm10,R10,TR2,L1,V3,R44,R46,R47,R7,i512,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,expr-stmt-ofm10,R10,TR2,L1,V1,V2,R44,R47,R7,i515,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build2,exm8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,ex-asm8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,placem8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,lit-placem8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,lit-nodem8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,call-nodem8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,call-resultsm8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,build-fn-litm8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,builtinm8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,expr-or-stmtm8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,stmtm8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,stmt-listm8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,rhs-nodesm8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build17,method-value-nodem8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build23,iface-method-value-nodem8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build16,method-expr-nodem8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,assert-knm8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,elem-typem8,R36,TR7,i518,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build3,exkm8,R2,L1,V2,R47,R44,R7,i521,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build15,ensure-methods!m8,R36,TR7,i525,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build13,iface-contentm12,R10,TR2,L1,V2,V2,R44,R47,R35,R0,s192,Node [k n] of type ty as an interface's content (an R node): the value itself, its type's\nmethod set given first (§5.3; an interpreted named type's is given when its descriptor is made,\nGR9a).R7,i527,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,arith-namem10,R10,TR2,L1,V1,R50,R7,i545,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,cmp-namem12,s2,==s2,Eqs2,!=s2,Nes1,<s2,Lts2,<=s2,Les1,>s2,Gts2,>=s2,Gem8,R10,TR7,i549,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,const-ofm12,R10,TR2,L1,V1,R47,R0,s69,The constant value of node n when it is one (an operand's), else nil.R7,i551,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build13,local-slot-ofm12,R10,TR2,L1,V1,R47,R0,s71,The I slot of node n when it reads a local held in an I slot, else nil.R7,i556,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,int-binopm10,R2,L1,V4,R50,R35,R51,R52,R0,s72,x op y on integer type ty (nodes of the operands' checked trees xn, yn).R7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,float-binopm10,R10,TR2,L1,V4,R50,R35,R45,R53,R7,i578,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,binop-nodesm10,R2,L1,V5,R50,R35,R54,R55,R56,R0,s85,[k node] of arithmetic x op y of type ty on built operand nodes (for op= statements).R7,i582,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,count-nodem12,R10,TR2,L1,V1,R52,R0,s81,A shift count's node: an I (a constant count of any numeric kind as its integer).R7,i595,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,shift-nodem10,R10,TR2,L1,V4,R50,R35,R51,R52,R7,i605,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,nil-node?m10,R10,TR2,L1,V1,R47,R7,i610,R8,i1,R9,s18,arbace/go/build.ae")

var Lit_599 *jrt.String = jrt.Intern("arbace.go.build$eval367000004$loading__1927001464__auto____367000005")

var Lit_600 *jrt.String = jrt.Intern("arbace.go.build$eval367000008$fn__367000009")

var Lit_601 *jrt.String = jrt.Intern("arbace.go.build$op")

var Lit_602 *jrt.String = jrt.Intern("arbace.go.build$oa")

var Lit_603 *jrt.String = jrt.Intern("arbace.go.build$unsupported_BANG_")

var Lit_604 *jrt.String = jrt.Intern("arbace.go.build$lazily")

var Lit_605 *jrt.String = jrt.Intern("arbace.go.build$method_data")

var Lit_606 *jrt.String = jrt.Intern("arbace.go.build$complete_instance_BANG_")

var Lit_607 *jrt.String = jrt.Intern("arbace.go.build$with_ctx")

var Lit_608 *jrt.String = jrt.Intern("arbace.go.build$compiled_QMARK_")

var Lit_609 *jrt.String = jrt.Intern("arbace.go.build$kind")

var Lit_610 *jrt.String = jrt.Intern("arbace.go.build$basic_of")

var Lit_611 *jrt.String = jrt.Intern("arbace.go.build$unsigned_QMARK_")

var Lit_612 *jrt.String = jrt.Intern("arbace.go.build$wide_QMARK_")

var Lit_613 *jrt.String = jrt.Intern("arbace.go.build$struct_or_array_QMARK_")

var Lit_614 *jrt.String = jrt.Intern("arbace.go.build$iface_QMARK_")

var Lit_615 *jrt.String = jrt.Intern("arbace.go.build$inst_type_QMARK_")

var Lit_616 *jrt.String = jrt.Intern("arbace.go.build$interpreted_named_QMARK_")

var Lit_617 *jrt.String = jrt.Intern("arbace.go.build$recursive_QMARK_")

var Lit_618 *jrt.String = jrt.Intern("arbace.go.build$layout_needed_QMARK_")

var Lit_619 *jrt.String = jrt.Intern("arbace.go.build$shape_type")

var Lit_620 *jrt.String = jrt.Intern("arbace.go.build$tag_text")

var Lit_621 *jrt.String = jrt.Intern("arbace.go.build$struct_parts")

var Lit_622 *jrt.String = jrt.Intern("arbace.go.build$method_key")

var Lit_623 *jrt.String = jrt.Intern("arbace.go.build$set_iface_methods_BANG_")

var Lit_624 *jrt.String = jrt.Intern("arbace.go.build$set_iface_methods_now_BANG_")

var Lit_625 *jrt.String = jrt.Intern("arbace.go.build$reflect_kind")

var Lit_626 *jrt.String = jrt.Intern("arbace.go.build$local_gen_of")

var Lit_627 *jrt.String = jrt.Intern("arbace.go.build$named_desc")

var Lit_628 *jrt.String = jrt.Intern("arbace.go.build$named_desc1")

var Lit_629 *jrt.String = jrt.Intern("arbace.go.build$desc")

var Lit_630 *jrt.String = jrt.Intern("arbace.go.build$desc1")

var Lit_631 *jrt.String = jrt.Intern("arbace.go.build$int_bits")

var Lit_632 *jrt.String = jrt.Intern("arbace.go.build$go_string_node")

var Lit_633 *jrt.String = jrt.Intern("arbace.go.build$complex_value")

var Lit_634 *jrt.String = jrt.Intern("arbace.go.build$const_node")

var Lit_635 *jrt.String = jrt.Intern("arbace.go.build$new_slot_BANG_")

var Lit_636 *jrt.String = jrt.Intern("arbace.go.build$next_code_BANG_")

var Lit_637 *jrt.String = jrt.Intern("arbace.go.build$label_code_BANG_")

var Lit_638 *jrt.String = jrt.Intern("arbace.go.build$label_entry")

var Lit_639 *jrt.String = jrt.Intern("arbace.go.build$cell_var_QMARK_")

var Lit_640 *jrt.String = jrt.Intern("arbace.go.build$loc")

var Lit_641 *jrt.String = jrt.Intern("arbace.go.build$new_loc_BANG_")

var Lit_642 *jrt.String = jrt.Intern("arbace.go.build$temp_BANG_")

var Lit_643 *jrt.String = jrt.Intern("arbace.go.build$local_node")

var Lit_644 *jrt.String = jrt.Intern("arbace.go.build$as_kind")

var Lit_645 *jrt.String = jrt.Intern("arbace.go.build$load_p")

var Lit_646 *jrt.String = jrt.Intern("arbace.go.build$store_p")

var Lit_647 *jrt.String = jrt.Intern("arbace.go.build$set_slot")

var Lit_648 *jrt.String = jrt.Intern("arbace.go.build$expr_stmt_of")

var Lit_649 *jrt.String = jrt.Intern("arbace.go.build$exk")

var Lit_650 *jrt.String = jrt.Intern("arbace.go.build$iface_content")

var Lit_651 *jrt.String = jrt.Intern("arbace.go.build$arith_name")

var Lit_652 *jrt.String = jrt.Intern("arbace.go.build$const_of")

var Lit_653 *jrt.String = jrt.Intern("arbace.go.build$local_slot_of")

var Lit_654 *jrt.String = jrt.Intern("arbace.go.build$int_binop")

var Lit_655 *jrt.String = jrt.Intern("arbace.go.build$float_binop")

var Lit_656 *jrt.String = jrt.Intern("arbace.go.build$binop_nodes")

var Lit_657 *jrt.String = jrt.Intern("arbace.go.build$count_node")

var Lit_658 *jrt.String = jrt.Intern("arbace.go.build$shift_node")

var Lit_659 *jrt.String = jrt.Intern("arbace.go.build$nil_node_QMARK_")

var Lit_660 *jrt.String = jrt.Intern("kn8,arglistsyn3,op*yn2,xnyn2,ynkn3,dockn4,linekn6,columnkn4,filekn7,privateyn1,nyn2,tyyn4,idxsyn1,vyn1,xkn8,declaredyn1,kkn2,asyn2,knyn4,fromyn2,toyn4,wantyn3,sigyn1,_yn2,psyn2,rsyn8,variadicyn4,recvyn1,syn4,nodeyn4,argsyn3,cmpyn4,cellyn7,settersyn7,resultsyn4,modeyn6,calleeyn4,pathyn2,nmyn5,nodesyn5,tempsyn1,myn2,rtyn6,mtargsyn5,targsyn5,fpathyn3,selyn3,pkgyn3,rtyyn5,mnameyn1,ryn6,paramsyn1,Dyn1,dyn2,ndyn1,Tyn2,xryn2,styn1,pyn3,knsyn3,tysyn1,cyn1,tyn1,fyn4,predv15,arbace.go.build13,compare-nodesm10,R0,L1,V3,R1,R2,R3,R4,s35,[:B node] of x op y (a comparison).R5,i612,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,binary-nodem10,R8,TR0,L1,V1,R9,R5,i661,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build10,unary-nodem10,R8,TR0,L1,V1,R9,R5,i679,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,bytes-type?m10,R8,TR0,L1,V1,R10,R5,i692,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,runes-type?m10,R8,TR0,L1,V1,R10,R5,i693,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,conv-nodem10,R0,L1,V1,R9,R4,s49,[k node] of conversion T(x) (a non-constant one).R5,i695,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build12,addressable?m10,R8,TR0,L1,V1,R9,R5,i736,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,struct-ofm12,R8,TR0,L1,V1,R10,R4,s66,The struct type and its descriptor a field selection's step is on.R5,i739,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,value-placem12,R8,TR0,L1,V1,R9,R4,s112,A place holding the value of node n (of struct or array type): its own when addressable, else\n  its value's box.R5,i744,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,field-placem10,R0,L1,V1,R9,R4,s63,The place of field selection n ({:op :field :path :derefs :x}).R5,i752,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build5,uidx?m12,R8,TR0,L1,V1,R9,R4,s87,Whether index or bound n is of an unsigned type (gc's bounds errors print it unsigned).R5,i771,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,uidx-maskm12,R8,TR0,L1,V1,R11,R4,s84,Bits 0, 1, 2 set when a slice expression's bounds lo, hi, max are of unsigned types.R5,i776,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,index-placem12,R8,TR0,L1,V1,R9,R4,s78,The place of element (aget x i) of an array, a pointer to an array or a slice.R5,i781,R6,i1,R7,s18,arbace/go/build.aem10,R0,L1,V1,R9,R4,s43,The place (a P node) of addressable node n.R5,i794,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,elem-nodem12,R8,TR0,L1,V2,R12,R10,R4,s77,An element value node of type ty, as the factories take it (its kind's node).R5,i814,R6,i1,R7,s18,arbace/go/build.aem10,R0,L1,V1,R9,R4,s56,A struct or array literal as a new variable (its place).R5,i819,R6,i1,R7,s18,arbace/go/build.aem10,R8,TR0,L1,V1,R9,R5,i847,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build8,var-nodem10,R8,TR0,L1,V1,R13,R5,i862,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,global-nodem10,R8,TR0,L1,V1,R9,R5,i868,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build13,instance-cellm8,R14,TR5,i871,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build6,isubstm8,R14,TR5,i871,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build15,func-value-nodem12,R8,TR0,L1,V1,R9,R4,s120,The value of function node n: a generic function's instance (§9.2), a compiled member, an\n  interpreted function's cell.R5,i873,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build3,ex*m8,R14,TR5,i883,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build6,coercem12,R8,TR0,L1,V3,V4,R15,R9,R16,R17,R18,R19,R4,s167,Value [k n] of type from as one of type to it is assigned to (a named and an unnamed composite\n  type of one underlying type): converted, their RTs being two (GR9a-c).R5,i885,R6,i1,R7,s18,arbace/go/build.aem10,R0,L2,V1,R9,V2,R9,R20,R4,s138,[kind node] of expression node n (want: the type a nil takes, or :B for a condition; a value\n  of another composite type converted to it).R5,i898,R6,i1,R7,s18,arbace/go/build.aem10,R8,TR0,L1,V2,R9,R20,R5,i904,R6,i1,R7,s18,arbace/go/build.aem8,R0,L1,V2,R9,R15,R5,i965,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,slot-layoutm12,R8,TR0,L2,V1,R21,V2,V4,R22,R23,R24,R25,R26,R4,s280,The callee's slots of a signature [:func ps rs variadic]: the parameters', then the results',\n  numbered per kind in order (the variadic parameter an R); a method's receiver (of type recv)\n  after them (GR4), so that the arguments' slots are the signature's whatever the receiver.R5,i969,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build10,arg-setterm10,R8,TR0,L1,V2,V2,R15,R27,R28,R5,i982,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,error-type?m8,R14,TR5,i985,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build15,compiled-iface?m8,R14,TR5,i985,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build14,mem-converted?m12,R8,TR0,L1,V1,R10,R4,s153,Whether a value of type ty differs in Go memory from a frame: a function (a closure as a Go\n  func). An interface's content is the value itself (GR9a-c).R5,i987,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build8,mem-nodem12,R8,TR0,L1,V2,R17,R10,R4,s77,Node [k n] of type ty as compiled Go takes it (a closure as a Go func: MemR).R5,i994,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,arg-nodesm12,R8,TR0,L1,V3,R21,R29,R30,R4,s196,The argument nodes of a call to signature sig: fixed parameters', then the variadic slice's\n  (made from the trailing arguments, or the spread one); for compiled code (cmp) closures as Go\n  funcs.R5,i1000,R6,i1,R7,s18,arbace/go/build.aem12,R8,TR0,L1,V1,R9,R4,s71,The call of several results n, built once: {:t T :temps [[k slot]...]}.R5,i1018,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build6,sig-ofm10,R8,TR0,L1,V1,R10,R5,i1027,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,cell-callm12,R8,TR0,L1,V4,R31,R32,R33,R34,R4,s127,A call of function cell cell with setters, the callee's results in slots results: [k node] of\n  one result, else {:t T :temps}.R5,i1029,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,static-callm10,R8,TR0,L1,V4,R31,R21,R29,R34,R5,i1041,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build10,value-callm10,R8,TR0,L1,V4,R35,R21,R29,R34,R5,i1047,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build8,from-memm10,R8,TR0,L1,V2,V2,R15,R9,R10,R5,i1061,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build18,compiled-call-nodem12,R8,TR0,L1,V6,R36,R37,R21,R38,R34,R39,R4,s162,A compiled call of listed member path.nm of signature sig on argument nodes (a method's\n  receiver first): [k node], or {:t :temps} writing temps (made when nil).R5,i1066,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build13,compiled-callm10,R8,TR0,L1,V6,R36,R37,R21,R29,R26,R34,R5,i1076,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build12,recv-type-ofm12,R8,TR0,L1,V1,R40,R4,s78,The receiver type of method object m: its base named type, or a pointer to it.R5,i1082,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,method-cellm12,R8,TR0,L1,V1,R40,R4,s45,The *goi.Func of interpreted method object m.R5,i1090,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build15,generic-method?m10,R0,L1,V1,R40,R4,s87,Whether method object m is a generic type's or has type parameters of its own (go1.27).R5,i1095,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build13,method-targetm12,R8,TR0,L1,V3,R40,R41,R42,R4,s226,[cell receiver-type] of interpreted method m selected on named type rt (a generic type's\n  instance, for its methods; nil: m's own type) with a generic method's own type arguments\n  mtargs: an instance's cell (§9.2), else m's.R5,i1100,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build15,method-callablem10,R0,L1,V3,R40,R31,R37,R4,s129,The Callable of interpreted method object m (its cell) as Arbace calls it, the receiver\n  first: the var T.M's (§2.1, §7.1; GR5).R5,i1112,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build17,instance-callablem10,R0,L1,V4,R13,R43,R41,R37,R4,s232,GR9d: the Callable of generic function or method x's instance for targs (its receiver's type\n  arguments first) as Arbace calls it (a method: the receiver first, rt its instance type),\n  and the instance's signature: [callable sig].R5,i1122,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,path-derefsm12,R8,TR0,L1,V2,R10,R36,R4,s87,The implicit dereferences of a field selection along path from type ty (the checker's).R5,i1139,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,field-selm12,R8,TR0,L1,V2,R13,R44,R4,s70,The selection of the embedded fields fpath from node x: a :field node.R5,i1153,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,recv-nodem10,R0,L1,V1,R45,R4,s231,The receiver of method selection sel ({:op :method :recv :path :recv-adjust}) as the method\n  takes it: the embedded fields of its path selected, then its address or the value it points\n  to as the method's receiver asks: [k node].R5,i1165,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build18,interp-method-callm12,R8,TR0,L1,V3,R35,R29,R34,R4,s127,A call of interpreted method selection callee: its cell, the receiver laid after the\n  arguments (evaluated first, as Go does).R5,i1187,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,via-ifacem12,R8,TR0,L1,V4,R46,R47,R48,R21,R4,s182,The listed interface method I.name of compiled package pkg that type rty implements, its\n  signature identical to sig's (GR8a), as the table names it, or nil: the interfaces by name.R5,i1200,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,method-callm10,R8,TR0,L1,V3,R35,R29,R34,R5,i1213,R6,i1,R7,s18,arbace/go/build.aem10,R8,TR0,L1,V1,R10,R5,i1235,R6,i1,R7,s18,arbace/go/build.aem10,R8,TR0,L1,V1,R10,R5,i1237,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build15,iface-recv-nodem12,R8,TR0,L1,V1,R35,R4,s109,The interface content an interface method selection is called on (its embedded fields\n  selected): an R node.R5,i1239,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build10,iface-callm12,R8,TR0,L1,V3,R35,R29,R34,R4,s349,A call of interface method selection callee (§5.3): the content evaluated into a temporary,\n  then an interpreted type's method (its type's method set, an inline cache by the content's\n  reflect type), else the compiled\n  value's method (the static compiled interface's method expression, error's Error, or the\n  table's method of the dynamic type).R5,i1246,R6,i1,R7,s18,arbace/go/build.aem12,R8,TR0,L1,V1,R9,R4,s82,x.M of a concrete type (a method value): the receiver evaluated now, bound (§4.6).R5,i1282,R6,i1,R7,s18,arbace/go/build.aem12,R8,TR0,L1,V1,R9,R4,s78,x.M of an interface (a method value): the content's method bound to it (§4.6).R5,i1300,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build10,build-codem8,R14,TR5,i1310,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,local-objm10,R8,TR0,L1,V2,R37,R10,R5,i1312,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,local-refm10,R8,TR0,L1,V1,R13,R5,i1314,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,selectionm12,R8,TR0,L1,V2,R13,R49,R4,s125,The checker's selection node of lookup result r ({:kind :method|:iface-method ...}) on node x\n  (code_call.ae's select-expr).R5,i1316,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build10,thunk-bodym12,R8,TR0,L1,V3,R45,R50,R21,R4,s84,The body of a thunk calling selection sel with parameters params (of signature sig).R5,i1332,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build18,build-method-thunkm12,R8,TR0,L1,V4,R51,R49,R21,R37,R4,s198,The code of the method set entry of type D for lookup result r (signature sig): a method of\n  receiver D (laid last) calling the method through the embedded fields and pointers of its\n  path (§5.3).R5,i1345,R6,i1,R7,s18,arbace/go/build.aem12,R8,TR0,L1,V1,R9,R4,s76,T.M (a method expression): a function of the receiver first, a thunk (§4.6).R5,i1363,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build17,method-candidatesm12,R8,TR0,L1,V1,R10,R4,s156,[name pkg] of the methods that may be in type ty's method set: its named types' declared\n  methods, its embedded fields' and embedded interfaces', in order.R5,i1386,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build17,may-have-methods?m12,R8,TR0,L1,V1,R10,R4,s140,Whether type ty (concrete) may have an interpreted method set: an interpreted named type, a\n  pointer to one, a struct with embedded fields.R5,i1407,R6,i1,R7,s18,arbace/go/build.aem10,R0,L1,V2,R10,R52,R4,s173,Gives the descriptor d of concrete type ty its method set (once per build context, §5.3):\n  each method of ty's method set the method itself (its receiver is ty) or a thunk.R5,i1416,R6,i1,R7,s18,arbace/go/build.aem12,R8,TR0,L1,V1,R10,R4,s126,The number of methods in concrete type ty's method set that `ensure-methods!` may give (its\n  RT's method table's room, GR9a).R5,i1472,R6,i1,R7,s18,arbace/go/build.aem12,R8,TR0,L1,V2,R53,R10,R4,s171,Gives interpreted named type ty (descriptor nd) and its pointer type their method sets, and so\n  their RTs their method tables (GR9a: before any value of the type exists).R5,i1485,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build7,rt-namem8,R14,TR5,i1495,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build10,iface-namem12,R8,TR0,L1,V1,R10,R4,s85,The name gc's runtime gives static interface type ty in a failed assertion's message.R5,i1497,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,assert-descm10,R8,TR0,L1,V1,R54,R5,i1505,R6,i1,R7,s18,arbace/go/build.aem12,R8,TR0,L1,V3,R55,R54,R56,R4,s78,[k node] of content node xr asserted to type T (the static interface type st).R5,i1510,R6,i1,R7,s18,arbace/go/build.aem10,R0,L2,V1,R9,V2,R9,R34,R4,s79,[kind node] of a call of one result (mode :multi, or no result: {:t T :temps}).R5,i1521,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,call-stmtm12,R8,TR0,L1,V1,R9,R4,s51,The statement of call n as an expression statement.R5,i1544,R6,i1,R7,s18,arbace/go/build.aem10,R8,TR0,L1,V1,R10,R5,i1556,R6,i1,R7,s18,arbace/go/build.aem10,R0,L1,V2,R9,R34,R4,s81,A builtin's call: [k node], {:t ...} for mode :multi, a statement for mode :stmt.R5,i1558,R6,i1,R7,s18,arbace/go/build.aem10,R8,TR0,L1,V2,R34,R27,R5,i1643,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build13,slot-of-placem12,R8,TR0,L1,V1,R57,R4,s58,[k slot] when place p is a local held in a slot, else nil.R5,i1647,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,assign-tom10,R0,L1,V2,R57,R17,R4,s95,The statement assigning [k node] (of the place's type) to place p (:blank: evaluated, dropped).R5,i1654,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build8,temps-ofm12,R8,TR0,L1,V1,R58,R4,s81,Statements evaluating nodes kns into new temporaries, and the temporaries' nodes.R5,i1666,R6,i1,R7,s18,arbace/go/build.aem10,R0,L1,V2,R38,R59,R4,s138,The [k node]s of the right-hand values of an assignment or declaration (comma-ok forms as\n  two), for targets of types tys (a nil's type).R5,i1673,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build13,prepare-placem12,R8,TR0,L1,V1,R57,R4,s183,[statements place]: the operands of place p evaluated into temporaries now (an assignment's\n  first phase, §4.5: Go evaluates the places' index and pointer operands, then the values).R5,i1708,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,assign-stmtm8,R0,L1,V1,R9,R5,i1745,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build14,op-assign-stmtm8,R0,L1,V1,R9,R5,i1754,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build6,one-ofm10,R8,TR0,L1,V1,R10,R5,i1784,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,incdec-stmtm8,R0,L1,V1,R9,R5,i1790,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,zero-initm10,R8,TR0,L1,V1,R13,R5,i1797,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build8,init-varm12,R8,TR0,L1,V2,R13,R17,R4,s63,The statement giving new variable x its initial value [k node].R5,i1808,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,decl-stmtm10,R0,L1,V1,R52,R4,s83,A declaration {:op :decl :objs :init}: new variables (a reused one of := assigned).R5,i1817,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build4,jumpm10,R8,TR0,L1,V1,R60,R5,i1839,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,push-targetm10,R8,TR0,L1,V2,R61,R62,R5,i1841,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,innermostm10,R8,TR0,L1,V1,R63,R5,i1843,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build11,block-stmtsm10,R8,TR0,L1,V1,R9,R5,i1845,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build9,stmt-linem12,R8,TR0,L1,V1,R27,R4,s31,A statement's line (S51), or 0.R5,i1847,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build13,quiet-header?m8,R14,TR5,i1862,R6,i1,R7,s18,arbace/go/build.aev15,arbace.go.build12,quiet-basic?m10,R8,TR0,L1,V1,R10,R5,i1864,R6,i1,R7,s18,arbace/go/build.ae")

var Lit_661 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes")

var Lit_662 *jrt.String = jrt.Intern("arbace.go.build$binary_node")

var Lit_663 *jrt.String = jrt.Intern("arbace.go.build$unary_node")

var Lit_664 *jrt.String = jrt.Intern("arbace.go.build$bytes_type_QMARK_")

var Lit_665 *jrt.String = jrt.Intern("arbace.go.build$runes_type_QMARK_")

var Lit_666 *jrt.String = jrt.Intern("arbace.go.build$conv_node")

var Lit_667 *jrt.String = jrt.Intern("arbace.go.build$addressable_QMARK_")

var Lit_668 *jrt.String = jrt.Intern("arbace.go.build$struct_of")

var Lit_669 *jrt.String = jrt.Intern("arbace.go.build$value_place")

var Lit_670 *jrt.String = jrt.Intern("arbace.go.build$field_place")

var Lit_671 *jrt.String = jrt.Intern("arbace.go.build$uidx_QMARK_")

var Lit_672 *jrt.String = jrt.Intern("arbace.go.build$uidx_mask")

var Lit_673 *jrt.String = jrt.Intern("arbace.go.build$index_place")

var Lit_674 *jrt.String = jrt.Intern("arbace.go.build$place")

var Lit_675 *jrt.String = jrt.Intern("arbace.go.build$elem_node")

var Lit_676 *jrt.String = jrt.Intern("arbace.go.build$lit_place")

var Lit_677 *jrt.String = jrt.Intern("arbace.go.build$lit_node")

var Lit_678 *jrt.String = jrt.Intern("arbace.go.build$var_node")

var Lit_679 *jrt.String = jrt.Intern("arbace.go.build$global_node")

var Lit_680 *jrt.String = jrt.Intern("arbace.go.build$func_value_node")

var Lit_681 *jrt.String = jrt.Intern("arbace.go.build$coerce")

var Lit_682 *jrt.String = jrt.Intern("arbace.go.build$ex")

var Lit_683 *jrt.String = jrt.Intern("arbace.go.build$ex_STAR_")

var Lit_684 *jrt.String = jrt.Intern("arbace.go.build$ex_as")

var Lit_685 *jrt.String = jrt.Intern("arbace.go.build$slot_layout")

var Lit_686 *jrt.String = jrt.Intern("arbace.go.build$arg_setter")

var Lit_687 *jrt.String = jrt.Intern("arbace.go.build$mem_converted_QMARK_")

var Lit_688 *jrt.String = jrt.Intern("arbace.go.build$mem_node")

var Lit_689 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes")

var Lit_690 *jrt.String = jrt.Intern("arbace.go.build$call_results")

var Lit_691 *jrt.String = jrt.Intern("arbace.go.build$sig_of")

var Lit_692 *jrt.String = jrt.Intern("arbace.go.build$cell_call")

var Lit_693 *jrt.String = jrt.Intern("arbace.go.build$static_call")

var Lit_694 *jrt.String = jrt.Intern("arbace.go.build$value_call")

var Lit_695 *jrt.String = jrt.Intern("arbace.go.build$from_mem")

var Lit_696 *jrt.String = jrt.Intern("arbace.go.build$compiled_call_node")

var Lit_697 *jrt.String = jrt.Intern("arbace.go.build$compiled_call")

var Lit_698 *jrt.String = jrt.Intern("arbace.go.build$recv_type_of")

var Lit_699 *jrt.String = jrt.Intern("arbace.go.build$method_cell")

var Lit_700 *jrt.String = jrt.Intern("arbace.go.build$generic_method_QMARK_")

var Lit_701 *jrt.String = jrt.Intern("arbace.go.build$method_target")

var Lit_702 *jrt.String = jrt.Intern("arbace.go.build$method_callable")

var Lit_703 *jrt.String = jrt.Intern("arbace.go.build$instance_callable")

var Lit_704 *jrt.String = jrt.Intern("arbace.go.build$path_derefs")

var Lit_705 *jrt.String = jrt.Intern("arbace.go.build$field_sel")

var Lit_706 *jrt.String = jrt.Intern("arbace.go.build$recv_node")

var Lit_707 *jrt.String = jrt.Intern("arbace.go.build$interp_method_call")

var Lit_708 *jrt.String = jrt.Intern("arbace.go.build$via_iface")

var Lit_709 *jrt.String = jrt.Intern("arbace.go.build$method_call")

var Lit_710 *jrt.String = jrt.Intern("arbace.go.build$error_type_QMARK_")

var Lit_711 *jrt.String = jrt.Intern("arbace.go.build$compiled_iface_QMARK_")

var Lit_712 *jrt.String = jrt.Intern("arbace.go.build$iface_recv_node")

var Lit_713 *jrt.String = jrt.Intern("arbace.go.build$iface_call")

var Lit_714 *jrt.String = jrt.Intern("arbace.go.build$method_value_node")

var Lit_715 *jrt.String = jrt.Intern("arbace.go.build$iface_method_value_node")

var Lit_716 *jrt.String = jrt.Intern("arbace.go.build$local_obj")

var Lit_717 *jrt.String = jrt.Intern("arbace.go.build$local_ref")

var Lit_718 *jrt.String = jrt.Intern("arbace.go.build$selection")

var Lit_719 *jrt.String = jrt.Intern("arbace.go.build$thunk_body")

var Lit_720 *jrt.String = jrt.Intern("arbace.go.build$build_method_thunk")

var Lit_721 *jrt.String = jrt.Intern("arbace.go.build$method_expr_node")

var Lit_722 *jrt.String = jrt.Intern("arbace.go.build$method_candidates")

var Lit_723 *jrt.String = jrt.Intern("arbace.go.build$may_have_methods_QMARK_")

var Lit_724 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_")

var Lit_725 *jrt.String = jrt.Intern("arbace.go.build$method_count")

var Lit_726 *jrt.String = jrt.Intern("arbace.go.build$set_named_methods_BANG_")

var Lit_727 *jrt.String = jrt.Intern("arbace.go.build$iface_name")

var Lit_728 *jrt.String = jrt.Intern("arbace.go.build$assert_desc")

var Lit_729 *jrt.String = jrt.Intern("arbace.go.build$assert_kn")

var Lit_730 *jrt.String = jrt.Intern("arbace.go.build$call_node")

var Lit_731 *jrt.String = jrt.Intern("arbace.go.build$call_stmt")

var Lit_732 *jrt.String = jrt.Intern("arbace.go.build$elem_type")

var Lit_733 *jrt.String = jrt.Intern("arbace.go.build$builtin")

var Lit_734 *jrt.String = jrt.Intern("arbace.go.build$expr_or_stmt")

var Lit_735 *jrt.String = jrt.Intern("arbace.go.build$slot_of_place")

var Lit_736 *jrt.String = jrt.Intern("arbace.go.build$assign_to")

var Lit_737 *jrt.String = jrt.Intern("arbace.go.build$temps_of")

var Lit_738 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes")

var Lit_739 *jrt.String = jrt.Intern("arbace.go.build$prepare_place")

var Lit_740 *jrt.String = jrt.Intern("arbace.go.build$assign_stmt")

var Lit_741 *jrt.String = jrt.Intern("arbace.go.build$op_assign_stmt")

var Lit_742 *jrt.String = jrt.Intern("arbace.go.build$one_of")

var Lit_743 *jrt.String = jrt.Intern("arbace.go.build$incdec_stmt")

var Lit_744 *jrt.String = jrt.Intern("arbace.go.build$zero_init")

var Lit_745 *jrt.String = jrt.Intern("arbace.go.build$init_var")

var Lit_746 *jrt.String = jrt.Intern("arbace.go.build$decl_stmt")

var Lit_747 *jrt.String = jrt.Intern("arbace.go.build$jump")

var Lit_748 *jrt.String = jrt.Intern("arbace.go.build$push_target")

var Lit_749 *jrt.String = jrt.Intern("arbace.go.build$innermost")

var Lit_750 *jrt.String = jrt.Intern("arbace.go.build$block_stmts")

var Lit_751 *jrt.String = jrt.Intern("arbace.go.build$stmt_line")

var Lit_752 *jrt.String = jrt.Intern("arbace.go.build$quiet_basic_QMARK_")

var Lit_753 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn1,nkn4,linekn6,columnkn4,fileyn2,tykn3,docyn1,pyn1,byn1,syn5,stmtsyn4,objsyn1,tyn4,new?yn4,callyn1,cyn4,bodyyn3,lityn4,treeyn5,fnameyn8,capturesyn5,initsyn1,mkn5,ifacekn5,gtypekn9,recv-typekn4,typekn8,tag-typekn3,sigkn2,tokn4,recvkn3,varkn3,objkn6,paramskn3,lhskn4,objskn6,methodkn4,refskn4,rmapkn9,inst-formks3,goi5,labelkn8,label-idkn7,tparamskn2,idkn10,underlyingkn4,formyn1,xyn9,implicitskn8,declaredyn1,_yn2,psyn2,rsyn8,variadicyn1,iyn7,vargen?yn5,targsyn2,nmv15,arbace.go.build12,quiet-const?m10,R0,TR1,L1,V1,R2,R3,i1866,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build14,quiet-builtinsS8,s3,mins3,maxs3,news4,imags4,reals3,lens3,caps7,complexm8,R0,TR3,i1868,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build15,quiet-cmp-type?m10,R0,TR1,L1,V1,R6,R3,i1870,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,quiet-expr?m12,R0,TR1,L1,V1,R2,R7,s90,Whether checked expression n can neither panic nor call (conservative: unknown kinds can).R3,i1874,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build12,quiet-place?m12,R0,TR1,L1,V1,R8,R7,s56,Whether assigning to place p can neither panic nor call.R3,i1918,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build19,quiet-block-header?m10,R0,TR1,L1,V1,R9,R3,i1931,R4,i1,R5,s18,arbace/go/build.aem12,R0,TR1,L1,V1,R2,R7,s137,Whether statement n's own part (its nested statement lists left out: they store their own\n  lines) can neither panic nor call (GC26 (b)).R3,i1936,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build12,hoisted-linem12,R0,TR1,L1,V1,R2,R7,s334,A loop's hoisted line (GR5.1): a for or range statement whose own part is quiet and whose\n  body is one statement without statement lists of its own that can panic or call stores that\n  statement's line once, before the loop, rather than at each iteration (the frame's line is\n  then the same at every point that can raise); else nil.R3,i1975,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,stored-linem12,R0,TR1,L1,V1,R10,R7,s140,The line statement s stores in the frame before it runs (0: none, it can neither panic nor\n  call; GC26 (b)); a loop's hoisted line (GR5.1).R3,i1990,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,loop-bodym12,R0,TR1,L1,V1,R2,R7,s130,A for or range statement's body: a statement list storing its lines, or a hoisted line's\n  one statement without its line (GR5.1).R3,i1999,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,body-nodem12,R0,TR1,L1,V1,R11,R7,s165,A statement list's node (a SeqL with its labels' goto codes and the lines its statements that\n  can panic or call store in the frame, for traces: §10.6, GR5, GR5.1).R3,i2007,R4,i1,R5,s18,arbace/go/build.aem8,R1,L1,V1,R11,R3,i2024,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,block-nodem12,R0,TR1,L1,V1,R2,R7,s62,A block's node: its declarations (a let's) and its statements.R3,i2026,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,loop-targetm10,R0,TR1,L1,V1,R2,R3,i2039,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build19,per-iteration-cellsm10,R0,TR1,L1,V1,R12,R3,i2046,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build8,for-stmtm10,R0,TR1,L1,V1,R2,R3,i2051,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build13,range-targetsm12,R0,TR1,L1,V1,R2,R7,s99,The key and value targets of a range: [obj-or-place-or-nil ...] and whether they are new variables.R3,i2061,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,idx-setterm10,R0,TR1,L1,V3,R13,R14,R6,R3,i2068,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,at-setterm10,R0,TR1,L1,V3,R13,R14,R6,R3,i2079,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,any-setterm10,R0,TR1,L1,V3,R13,R14,R6,R3,i2090,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,has-call?m12,R0,TR1,L1,V1,R2,R7,s157,Whether checked node n has a call (not of a constant) or a receive in it (an array's length is\n  then not constant: the specification's len and range rules).R3,i2101,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build16,range-elem-typesm12,R0,TR1,L1,V1,R2,R7,s65,The types of a range's iteration values: [key value] (nil: none).R3,i2112,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,range-stmtm10,R0,TR1,L1,V1,R2,R3,i2127,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,switch-stmtm10,R0,TR1,L1,V1,R2,R3,i2207,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,return-stmtm10,R0,TR1,L1,V1,R2,R3,i2233,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build13,deferred-callm12,R0,TR1,L1,V1,R15,R7,s189,The parts of a deferred or go statement's call n (SPEC.md §7.9, §8.1): its callee and\n  arguments evaluated now into a frame of their own, the call made later from it: [setters T\n  counts].R3,i2249,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,defer-stmtm10,R0,TR1,L1,V1,R2,R3,i2291,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build7,go-stmtm10,R0,TR1,L1,V1,R2,R3,i2296,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,send-stmtm10,R0,TR1,L1,V1,R2,R3,i2300,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build16,type-switch-stmtm10,R0,TR1,L1,V1,R2,R3,i2304,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,select-recvm12,R0,TR1,L1,V1,R16,R7,s230,A receive clause's communication c (an expression statement, a declaration or an\n  assignment of a receive): [the receive node, the statement binding its values (nil: none)]\n  with the receive replaced by the select's temporaries.R3,i2331,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,select-stmtm10,R0,TR1,L1,V1,R2,R3,i2355,R4,i1,R5,s18,arbace/go/build.aem10,R1,L1,V1,R2,R7,s24,The node of statement n.R3,i2376,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,has-defer?m12,R0,TR1,L1,V1,R17,R7,s71,Whether a function's body defers (not counting its function literals').R3,i2418,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,free-localsm12,R0,TR1,L1,V1,R18,R7,s135,The local variables a function literal's body refers to that it does not declare: the cells\n  it captures, in order of first reference.R3,i2431,R4,i1,R5,s18,arbace/go/build.aem10,R1,L1,V3,R19,R20,R21,R7,s243,The *goi.Code of a function node (:func, :fn, :body) with its signature sig; captures, the\n  cells it receives first (a literal's); a method's receiver (:recv, of type :recv-type or its\n  method object's) laid after the parameters and results.R3,i2464,R4,i1,R5,s18,arbace/go/build.aem10,R1,L1,V1,R2,R7,s55,A function literal's closure node (its code built now).R3,i2516,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,build-funcm10,R1,L1,V1,R19,R7,s83,The code of a package-level function's checked tree (built on its first call, S18).R3,i2527,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,build-initsm10,R1,L1,V1,R22,R7,s160,The code of a package's initialization: its variables' initializers in initialization order\n  (trees {:op :var-init :lhs :rhs}), as a function of no parameters.R3,i2534,R4,i1,R5,s18,arbace/go/build.aem10,R1,L1,V2,R6,R23,R7,s135,Type ty with the types of map m replaced: type parameters, and the local named types of a\n  generic declaration copied for an instance.R3,i2551,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,type-keysS7,R24,R25,R26,R27,R28,R29,R30,m8,R0,TR3,i2583,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build8,obj-keysS3,R31,R32,R33,m8,R0,TR3,i2584,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,objs-keysS3,R34,R35,R36,m8,R0,TR3,i2585,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,skip-keysS10,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,m8,R0,TR3,i2586,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,local-typesm12,R0,TR1,L1,V1,R19,R7,s56,The local named types a checked tree declares, in order.R3,i2588,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,resolve-onm12,R0,TR1,L1,V2,R2,R47,R7,s183,A method selection on a type parameter (an interface method of its constraint) resolved for\n  the instance's type T: the method T's method set has (§9.2): a method, or an interface's.R3,i2601,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,inst-treem10,R1,L2,V2,R19,R23,V3,R19,R23,R48,R7,s368,The checked tree of a generic declaration for the type arguments of map m (type parameter ->\n  type): every type substituted, its local variables and local named types copied with their\n  types, the method selections on its type parameters resolved, its constants represented at\n  their types (a float32's rounded), the sizes that depended on type parameters constant.R3,i2619,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,instancesm8,R7,s89,The instances of generic functions and methods (§9.2): [object descriptors] -> *goi.Func.R3,i2699,R4,i1,R5,s18,arbace/go/build.aem8,R7,s89,The instances of generic functions and methods (§9.2): [object descriptors] -> *goi.Func.R3,i2699,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,inst-gensm8,R0,TR3,i2702,R4,i1,R5,s18,arbace/go/build.aem8,R0,TR3,i2702,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build6,rt-sigm8,R49,TR3,i2704,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build8,sym-namem8,R49,TR3,i2706,R4,i1,R5,s18,arbace/go/build.aem10,R1,L1,V1,R6,R7,s288,A type's name as gc's runtime writes it in an instance's name (its type arguments: cmd/compile's\n  LinkString), an assertion's message: named types by package path, a function-scoped one with its\n  ·N, an instance's and a generic function's local type's type arguments in brackets (GR9c).R3,i2708,R4,i1,R5,s18,arbace/go/build.aem12,R0,TR1,L1,V1,V4,R50,R51,R52,R53,R7,s63,A signature's text as gc's runtime writes it: (params) results.R3,i2741,R4,i1,R5,s18,arbace/go/build.aem12,R0,TR1,L1,V2,R54,R55,R7,s427,A named type's symbol as gc's noder names it (reader.go's mangle): its name, then in brackets\n  the type arguments of the generic function it is local to (an instance's copy of it,\n  :goi/implicits), ';', and its own (an instance's), each by rt-name; with vargen? a function-scoped\n  type's ·N after them (writer.go's qualifiedIdent), which the runtime's name of the type itself\n  leaves out (types/fmt.go's SplitVargenSuffix).R3,i2750,R4,i1,R5,s18,arbace/go/build.aem10,R1,L1,V1,R6,R7,s154,A generic type's instance's name, as gc's runtime names it: pkg.T[args] (GC31), and a generic\n  function's local type's: pkg.T[implicit args;args] (GR9c).R3,i2765,R4,i1,R5,s18,arbace/go/build.aem10,R1,L1,V1,R6,R7,s186,The generation of a generic type's instance: one per origin and type arguments' descriptors,\n  so that the instances' descriptors (interned by package, name and generation) are distinct.R3,i2772,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build13,instance-namem12,R0,TR1,L1,V1,R47,R7,s65,An instance's function name in traces, gc's: F[...], (*T[...]).M.R3,i2785,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build14,build-instancem12,R0,TR1,L1,V3,R47,R56,R57,R7,s116,The code of generic function or method x's instance for targs (its receiver's type arguments\n  first, then its own).R3,i2795,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build14,instance-cell*m8,R49,TR3,i2809,R4,i1,R5,s18,arbace/go/build.aem10,R1,L1,V2,R47,R56,R7,s361,The *goi.Func of generic function or method x instantiated with targs: one per type-argument\n  list (by their descriptors, G7 (a): no body shared between lists), its code built by its\n  package's build context (:ctx-of) on its first call, or now when building eagerly. GR8a:\n  reflect.TypeFor of an interpreted interface is reflect's goiNilType (nil, GC62 (a)).R3,i2811,R4,i1,R5,s18,arbace/go/build.aem10,R0,TR1,L1,V2,R47,R56,R3,i2823,R4,i1,R5,s18,arbace/go/build.ae")

var Lit_754 *jrt.String = jrt.Intern("arbace.go.build$quiet_const_QMARK_")

var Lit_755 *jrt.String = jrt.Intern("arbace.go.build$quiet_cmp_type_QMARK_")

var Lit_756 *jrt.String = jrt.Intern("arbace.go.build$quiet_expr_QMARK_")

var Lit_757 *jrt.String = jrt.Intern("arbace.go.build$quiet_place_QMARK_")

var Lit_758 *jrt.String = jrt.Intern("arbace.go.build$quiet_block_header_QMARK_")

var Lit_759 *jrt.String = jrt.Intern("arbace.go.build$quiet_header_QMARK_")

var Lit_760 *jrt.String = jrt.Intern("arbace.go.build$hoisted_line")

var Lit_761 *jrt.String = jrt.Intern("arbace.go.build$stored_line")

var Lit_762 *jrt.String = jrt.Intern("arbace.go.build$loop_body")

var Lit_763 *jrt.String = jrt.Intern("arbace.go.build$body_node")

var Lit_764 *jrt.String = jrt.Intern("arbace.go.build$stmt_list")

var Lit_765 *jrt.String = jrt.Intern("arbace.go.build$block_node")

var Lit_766 *jrt.String = jrt.Intern("arbace.go.build$loop_target")

var Lit_767 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells")

var Lit_768 *jrt.String = jrt.Intern("arbace.go.build$for_stmt")

var Lit_769 *jrt.String = jrt.Intern("arbace.go.build$range_targets")

var Lit_770 *jrt.String = jrt.Intern("arbace.go.build$idx_setter")

var Lit_771 *jrt.String = jrt.Intern("arbace.go.build$at_setter")

var Lit_772 *jrt.String = jrt.Intern("arbace.go.build$any_setter")

var Lit_773 *jrt.String = jrt.Intern("arbace.go.build$has_call_QMARK_")

var Lit_774 *jrt.String = jrt.Intern("arbace.go.build$range_elem_types")

var Lit_775 *jrt.String = jrt.Intern("arbace.go.build$range_stmt")

var Lit_776 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt")

var Lit_777 *jrt.String = jrt.Intern("arbace.go.build$return_stmt")

var Lit_778 *jrt.String = jrt.Intern("arbace.go.build$deferred_call")

var Lit_779 *jrt.String = jrt.Intern("arbace.go.build$defer_stmt")

var Lit_780 *jrt.String = jrt.Intern("arbace.go.build$go_stmt")

var Lit_781 *jrt.String = jrt.Intern("arbace.go.build$send_stmt")

var Lit_782 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt")

var Lit_783 *jrt.String = jrt.Intern("arbace.go.build$select_recv")

var Lit_784 *jrt.String = jrt.Intern("arbace.go.build$select_stmt")

var Lit_785 *jrt.String = jrt.Intern("arbace.go.build$stmt")

var Lit_786 *jrt.String = jrt.Intern("arbace.go.build$has_defer_QMARK_")

var Lit_787 *jrt.String = jrt.Intern("arbace.go.build$free_locals")

var Lit_788 *jrt.String = jrt.Intern("arbace.go.build$build_code")

var Lit_789 *jrt.String = jrt.Intern("arbace.go.build$build_fn_lit")

var Lit_790 *jrt.String = jrt.Intern("arbace.go.build$build_func")

var Lit_791 *jrt.String = jrt.Intern("arbace.go.build$build_inits")

var Lit_792 *jrt.String = jrt.Intern("arbace.go.build$isubst")

var Lit_793 *jrt.String = jrt.Intern("arbace.go.build$local_types")

var Lit_794 *jrt.String = jrt.Intern("arbace.go.build$resolve_on")

var Lit_795 *jrt.String = jrt.Intern("arbace.go.build$inst_tree")

var Lit_796 *jrt.String = jrt.Intern("arbace.go.build$rt_name")

var Lit_797 *jrt.String = jrt.Intern("arbace.go.build$rt_sig")

var Lit_798 *jrt.String = jrt.Intern("arbace.go.build$sym_name")

var Lit_799 *jrt.String = jrt.Intern("arbace.go.build$inst_type_name")

var Lit_800 *jrt.String = jrt.Intern("arbace.go.build$inst_gen")

var Lit_801 *jrt.String = jrt.Intern("arbace.go.build$instance_name")

var Lit_802 *jrt.String = jrt.Intern("arbace.go.build$build_instance")

var Lit_803 *jrt.String = jrt.Intern("arbace.go.build$instance_cell")

var Lit_804 *jrt.String = jrt.Intern("arbace.go.build$instance_cell_STAR_")
