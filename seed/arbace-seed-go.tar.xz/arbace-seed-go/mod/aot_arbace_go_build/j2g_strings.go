//line j2g_strings.ae:1
package aot_arbace_go_build

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn21,arbace.go.check.typesyn1,tyn21,arbace.go.check.constyn1,cyn19,arbace.go.check.envyn1,eyn20,arbace.go.check.codeyn4,codeyn20,arbace.go.check.declyn4,declkn3,docks3,goi11,unsupportedkn4,namekn3,pkgkn4,typekn8,ptr-recvkn3,objkn7,tparamskn4,funckn10,lazy-underkn9,compiled?kn1,Ikn7,float32kn7,float64kn13,untyped-floatkn1,Fkn6,stringkn14,untyped-stringkn1,Skn4,elsekn1,Rkn3,intkn5,int64kn4,uintkn6,uint64kn7,uintptrkn5,arraykn6,structkn5,targskn7,pointerkn3,mapkn5,slicekn4,chankn3,tagkn4,pathkn8,embeddedks3,goi3,genkn5,typeskn5,localkn3,genkn8,pkg-namekn7,invalidkn11,untyped-intkn12,untyped-boolkn15,untyped-complexkn4,recvkn4,bothkn4,sendkn9,interfacekn12,untyped-runekn11,untyped-nilkn14,unsafe-pointerkn9,complex64kn1,Bkn10,complex128kn5,slotskn4,codekn6,labelskn4,gotokn9,captured?kn10,addressed?kn4,locskn4,cellkn1,Ckn4,slotkn1,Tkn8,constantkn4,modekn7,unknownkn3,valkn2,opkn3,nilks15,arbace.go.build4,nodekn1,kkn4,nodekn5,valueks2,go2,opkn1,xkn1,ykn5,uint8kn5,int32kn2,tokn4,boolkn8,variablekn11,place-localkn11,place-fieldkn11,place-derefkn11,place-indexkn12,place-globalkn6,derefskn5,indexkn3,ptrkn6,globalkn5,derefkn5,fieldkn3,litkn4,kindkn6,fieldskn5,elemskn3,keykn7,entrieskn9,func-cellkn6,methodkn11,method-exprkn6,resultkn4,callkn1,tkn5,tempsks15,arbace.go.build4,minikn6,binarykn2,fnkn5,unaryks15,arbace.go.build7,selrecvkn2,vskn7,indexeskn9,map-indexkn5,parenkn13,convert-ifacekn4,formkn6,assertkn12,iface-methodkn4,addrkn4,convkn6,paramskn7,resultskn6,countskn6,spreadkn5,callskn5,multikn10,recv-namedkn11,method-cellkn8,rtparamskn11,recv-adjustkn9,panicwrapkn9,recv-typekn5,ifacekn3,varkn6,local?kn8,indirectkn3,viakn6,calleekn4,argskn5,tuplekn5,blockkn5,stmtskn4,exprkn6,returnkn6,valueskn3,sigkn4,bodykn12,methods-donekn9,ambiguouskn5,eagerkn6,statickn7,closurekn7,builtinkn4,stmtkn6,unsafekn8,deferredkn9,new-valuekn5,blankks15,arbace.go.build8,map-tempkn1,mkn5,vtypekn2,mtks15,arbace.go.build6,p-tempkn1,ckn9,place-mapkn8,comma-okkn2,okkn3,okskn3,lhskn3,rhskn5,placekn3,inckn4,linekn5,constkn4,objskn4,initkn7,targetskn5,labelkn3,letkn8,let-typekn5,declskn4,declkn5,rangekn4,overkn6,placeskn11,fallthroughkn9,has-deferkn5,breakkn8,continuekn10,local-typekn6,switchkn7,clauseskn9,op-assignkn11,type-switchkn2,ifkn4,condkn4,thenkn3,forkn4,postkn6,incdeckn9,directivekn6,assignkn2,gokn5,deferks3,goi5,labelkn4,loopkn3,brkkn4,contkn2,idkn14,per-iteration?ks15,arbace.go.build4,tempkn9,ptr-arraykn7,defaultkn4,fallkn3,lockn2,chkn2,ctkn4,bindkn4,commkn6,selectkn8,tag-typekn4,refskn6,sourcekn3,srckn4,filekn9,lit-countkn6,originkn3,allkn5,termskn10,comparablekn5,unionkn10,underlyingkn4,treekn6,ctx-ofv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.go.buildm2,R14,s1640,goi's builder (doc/go/GOI-SPEC.md §4.1): the checked tree (§3.7) made nodes, typed Go\n  closures of the back end arbace/goi, by its factories through arbace.lang.GoInterp's op\n  native (go/arbace/goi/registry.ae). It numbers each function's slots per kind (parameters and\n  results first, as the signature lays them out), makes the variables that live in Go memory\n  cells (captured, addressed, of a struct or array type, every package variable), gives each\n  jump target its codes, chooses each node's variant by its operands' types, and resolves each\n  call to the callee's cell, a closure, or the table's member. It decides nothing the checker\n  has not: no type, no constant, no resolution.\n\n  GR3 builds the interpreter's core: scalars, strings, slices, arrays, maps, structs, pointers,\n  functions and closures, all control flow with labels and goto, defer, panic and recover,\n  interface values without methods (§5.3 rules 1 and 2), the calls of compiled Go. GR4 adds\n  methods (their receiver laid after the parameters and results), method values and\n  expressions, the method sets of the types that go into interfaces (each entry the method or a\n  thunk: §5.3), interface method calls, type assertions and switches, embedding and promotion,\n  goroutines, channels, select and range over functions and channels. GR6 adds generics (§9.2):\n  each instance of a generic function, method or type built per type-argument list from the\n  generic declaration's checked tree with its type parameters substituted (inst-tree). A form\n  that needs what goi does not run is \"not supported by goi yet\" (§3.4), an ex-info with\n  :goi/unsupported.v11,arbace.core7,ex-infoR15,v15,arbace.go.build12,program-modev11,arbace.core7,ex-datav11,arbace.core5,flushv11,arbace.core19,pop-thread-bindingsv11,arbace.core7,printlnv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*R16,v19,arbace.go.check.env1,oR17,v21,arbace.go.check.types9,exported?R18,R19,R20,R21,R22,R23,v21,arbace.go.check.types4,infov20,arbace.go.check.decl15,instance-under!v15,arbace.go.build5,*ctx*v21,arbace.go.check.types12,*method-obj*v15,arbace.go.build11,method-datav21,arbace.go.check.types14,*subst-method*v20,arbace.go.check.decl12,subst-methodv21,arbace.go.check.types15,*resolve-named*v15,arbace.go.build18,complete-instance!R24,v21,arbace.go.check.types5,underv11,arbace.core8,keyword?v15,arbace.go.build7,int-kwsR25,S3,R26,R27,R28,R29,S2,R30,R31,R32,R33,R34,v21,arbace.go.check.types8,untyped?v21,arbace.go.check.types12,default-typev21,arbace.go.check.types9,unsigned?v11,arbace.core9,contains?S5,R35,R36,R37,R38,R39,v15,arbace.go.build8,basic-ofv11,arbace.core7,vector?S2,R40,R41,v21,arbace.go.check.types10,interface?v11,arbace.core3,notv21,arbace.go.check.types7,tparam?v21,arbace.go.check.types6,named?v11,arbace.core3,seqR42,v15,arbace.go.build10,inst-type?v15,arbace.go.build9,compiled?v15,arbace.go.build18,interpreted-named?R43,R40,R44,R45,R46,v11,arbace.core4,someR41,v21,arbace.go.check.const10,value-textv15,arbace.go.build2,oav11,arbace.core3,mapv15,arbace.go.build4,descv15,arbace.go.build8,tag-textR47,R48,R49,v15,arbace.go.build2,opv15,arbace.go.build10,method-keyR50,v11,arbace.core5,swap!v15,arbace.go.build9,local-genv11,arbace.core3,incv21,arbace.go.check.types12,update-info!v11,arbace.core5,assocR51,v15,arbace.go.build12,unsupported!v15,arbace.go.build8,inst-genR52,v15,arbace.go.build12,local-gen-ofR53,v15,arbace.go.build14,inst-type-nameR54,v15,arbace.go.build10,recursive?v15,arbace.go.build18,set-iface-methods!v11,arbace.core10,ex-messagev13,arbace.string9,includes?v15,arbace.go.build12,struct-partsR55,v21,arbace.go.check.types8,pointer?R56,R57,R28,R58,v11,arbace.core4,namev15,arbace.go.build10,named-descv21,arbace.go.check.types8,type-strR59,l1,R60,l0,R61,l2,R62,v11,arbace.core6,empty?R63,R31,R64,R65,v11,arbace.core10,bigintegerv11,arbace.core6,every?v21,arbace.go.check.const11,complex-valv21,arbace.go.check.const9,to-doubleR66,v11,arbace.core8,boolean?R67,S2,R68,R66,R30,S2,R26,R27,v15,arbace.go.build13,complex-valuev15,arbace.go.build14,go-string-nodev15,arbace.go.build8,int-bitsv11,arbace.core8,integer?v21,arbace.go.check.const7,int-valR69,v15,arbace.go.build4,*fn*v11,arbace.core6,updateR70,R71,v11,arbace.core9,volatile!R72,v15,arbace.go.build10,next-code!R73,R74,v15,arbace.go.build16,struct-or-array?R75,v15,arbace.go.build9,cell-var?R76,v15,arbace.go.build9,new-slot!R77,R78,v15,arbace.go.build4,kindv15,arbace.go.build7,as-kindR79,v15,arbace.go.build2,exv15,arbace.go.build6,iface?v15,arbace.go.build15,ensure-methods!m18,s1,*s3,Muls1,%s3,Rems6,bit-ors2,Ors1,/s3,Divs1,-s3,Subs7,bit-xors3,Xors7,bit-ands3,Ands11,bit-and-nots6,AndNots1,+s3,AddR80,R81,v11,arbace.core4,not=R82,R83,R84,v15,arbace.go.build7,int-sfxv15,arbace.go.build10,arith-namev15,arbace.go.build8,const-ofv15,arbace.go.build13,local-slot-ofv15,arbace.go.build5,wide?S3,s1,*s1,-s1,+S3,s1,*s1,-s1,+v15,arbace.go.build3,exkR26,S2,s2,>>s2,<<v15,arbace.go.build9,unsigned?v15,arbace.go.build11,float-binopv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core5,firstv21,arbace.go.check.const8,complex?v21,arbace.go.check.const7,re-partv15,arbace.go.build10,count-nodeR85,v15,arbace.go.build9,nil-node?v15,arbace.go.build5,temp!v15,arbace.go.build6,load-pv15,arbace.go.build10,local-nodeR86,R87,R88,R89,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv15,arbace.go.build13,compare-nodesv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core6,reducev15,arbace.go.build8,set-slotv15,arbace.go.build8,cmp-namev15,arbace.go.build13,iface-contentv11,arbace.core5,rangeR90,R91,R92,S2,s2,>>s2,<<v15,arbace.go.build10,shift-nodev15,arbace.go.build9,int-binopR93,R94,R95,v15,arbace.go.build11,bytes-type?v15,arbace.go.build11,runes-type?S2,R68,R66,S2,R68,R66,S2,R46,R22,R96,R97,S5,R98,R99,R100,R101,R102,v15,arbace.go.build12,addressable?v15,arbace.go.build5,placeR103,v15,arbace.go.build11,value-placeR104,R102,R105,R106,R101,v15,arbace.go.build11,index-placeR107,v15,arbace.go.build3,locR99,v15,arbace.go.build11,field-placeR108,R100,R98,R109,v15,arbace.go.build9,lit-placeR110,v11,arbace.core6,removeR111,v11,arbace.core4,longv15,arbace.go.build9,elem-nodeR112,v11,arbace.core6,repeatV1,l0,v11,arbace.core6,secondv15,arbace.go.build8,lit-nodev11,arbace.core5,applyv11,arbace.core3,maxR113,R114,v15,arbace.go.build13,instance-cellR115,S1,R85,v15,arbace.go.build10,const-nodeR116,v15,arbace.go.build17,method-value-nodeR117,v15,arbace.go.build16,method-expr-nodev15,arbace.go.build8,var-nodeR118,v15,arbace.go.build12,call-resultsR119,R120,R121,R122,R123,v15,arbace.go.build11,binary-nodev15,arbace.go.build9,elem-typeR124,R125,v15,arbace.go.build10,unary-nodev15,arbace.go.build12,build-fn-litR126,v21,arbace.go.check.types12,string-type?R127,v11,arbace.core6,concatR128,v15,arbace.go.build11,global-nodeR129,v15,arbace.go.build9,call-nodeR130,R131,v11,arbace.core6,pr-strR132,v15,arbace.go.build15,func-value-nodeR133,v15,arbace.go.build9,assert-knR134,v15,arbace.go.build23,iface-method-value-nodeR135,R136,v15,arbace.go.build9,conv-nodem8,R25,l0,R29,l0,R32,l0,R34,l0,v11,arbace.core3,vecv11,arbace.core11,map-indexedv11,arbace.core4,mapvR137,R138,R139,v15,arbace.go.build11,slot-layoutv15,arbace.go.build11,error-type?v15,arbace.go.build15,compiled-iface?v21,arbace.go.check.types16,empty-interface?v15,arbace.go.build14,mem-converted?v15,arbace.go.build9,*raw-any*v15,arbace.go.build8,mem-nodev11,arbace.core4,takev11,arbace.core4,lastv11,arbace.core4,dropR140,R141,R142,v11,arbace.core3,strv11,arbace.core4,compv15,arbace.go.build9,arg-nodesv15,arbace.go.build10,arg-setterv15,arbace.go.build9,cell-callv15,arbace.go.build8,from-memv15,arbace.go.build18,compiled-call-nodev15,arbace.go.build12,raw-packagesR143,R144,R145,v15,arbace.go.build15,generic-method?v15,arbace.go.build11,method-cellv15,arbace.go.build12,recv-type-ofv15,arbace.go.build11,path-derefsv11,arbace.core5,true?v11,arbace.core3,popR146,R147,v15,arbace.go.build9,field-selv15,arbace.go.build6,sig-ofv15,arbace.go.build13,method-targetR148,v15,arbace.go.build9,recv-nodev21,arbace.go.check.types10,deref-typev15,arbace.go.build13,compiled-callv15,arbace.go.build18,interp-method-callv15,arbace.go.build15,iface-recv-nodeR149,v11,arbace.core4,map?v19,arbace.go.check.env3,objR150,R151,R152,R153,v21,arbace.go.check.types11,method-datav15,arbace.go.build9,local-refR154,R155,v11,arbace.core4,intoV1,R156,R157,R158,R159,R160,R161,v15,arbace.go.build9,local-objv15,arbace.go.build9,selectionv15,arbace.go.build10,build-codeR162,R163,v15,arbace.go.build10,thunk-bodyv21,arbace.go.check.types11,lookup-implv15,arbace.go.build6,isubstv11,arbace.core6,zipmapv21,arbace.go.check.types10,methods-ofR164,v15,arbace.go.build17,may-have-methods?S2,R116,R134,R165,R166,v15,arbace.go.build18,build-method-thunkv15,arbace.go.build6,lazilyv15,arbace.go.build8,with-ctxS2,R116,R134,v11,arbace.core4,keepv15,arbace.go.build17,method-candidatesv15,arbace.go.build7,rt-namev15,arbace.go.build11,assert-descv15,arbace.go.build10,iface-namev15,arbace.go.build10,iface-callv15,arbace.go.build11,method-callR167,v15,arbace.go.build11,static-callR168,v15,arbace.go.build10,value-callR169,v15,arbace.go.build7,builtinR170,v15,arbace.go.build12,expr-stmt-ofR171,R172,v15,arbace.go.build12,expr-or-stmtR173,V1,l0,S2,R98,R52,R174,R175,R176,R177,R178,R179,v15,arbace.go.build7,store-pR180,v15,arbace.go.build13,slot-of-placeR181,R182,R183,v15,arbace.go.build9,rhs-nodesV2,nnR184,S2,R98,R52,S2,R99,R108,S2,R43,R45,R185,v15,arbace.go.build9,assign-toR186,v15,arbace.go.build13,prepare-placev15,arbace.go.build8,temps-ofv11,arbace.core6,mapcatR187,S2,s2,>>s2,<<v15,arbace.go.build11,binop-nodesS2,s2,>>s2,<<S2,s2,>>s2,<<V3,R180,l1,l0,v15,arbace.go.build14,op-assign-stmtR188,R189,R190,v15,arbace.go.build6,one-ofv15,arbace.go.build8,new-loc!d0,R191,R192,v15,arbace.go.build9,zero-initv15,arbace.go.build8,init-varR193,v11,arbace.core6,filterv15,arbace.go.build9,stmt-listR194,v15,arbace.go.build12,quiet-basic?v15,arbace.go.build12,quiet-const?S4,s3,nots1,-s7,bit-nots1,+v15,arbace.go.build11,quiet-expr?v11,arbace.core8,not-any?v15,arbace.go.build14,quiet-builtinsS2,s2,ors3,andv15,arbace.go.build15,quiet-cmp-type?S2,s2,>>s2,<<S2,s1,%s1,/S2,R34,R29,R195,R196,v15,arbace.go.build13,quiet-header?R197,R198,R199,S5,R35,R30,R40,R45,R44,R200,v15,arbace.go.build12,quiet-place?v11,arbace.core4,nil?R201,R202,R203,R204,R205,R206,R207,R208,R209,S2,s2,>>s2,<<S2,s1,%s1,/S2,R34,R29,R210,R211,R212,v15,arbace.go.build19,quiet-block-header?R213,R214,R215,R216,R217,R218,v15,arbace.go.build12,hoisted-lineS2,R214,R199,S8,R219,R209,R220,R218,R198,R159,R61,R216,v15,arbace.go.build9,stmt-linev15,arbace.go.build4,stmtv15,arbace.go.build11,label-code!v15,arbace.go.build11,stored-linev11,arbace.core4,pos?v15,arbace.go.build9,body-nodev15,arbace.go.build9,decl-stmtR221,R222,R223,R224,R225,v15,arbace.go.build11,label-entryR226,v15,arbace.go.build11,loop-targetv15,arbace.go.build19,per-iteration-cellsv15,arbace.go.build11,push-targetv15,arbace.go.build9,loop-bodyR227,v15,arbace.go.build9,has-call?v11,arbace.core4,valsv11,arbace.core6,dissocR228,V2,nnR35,V2,R35,R94,v15,arbace.go.build13,range-targetsv15,arbace.go.build16,range-elem-typesv11,arbace.core6,vectorv11,arbace.core7,filtervv11,arbace.core5,some?v15,arbace.go.build11,assign-stmtv15,arbace.go.build10,any-setterv15,arbace.go.build10,idx-setterv15,arbace.go.build9,at-setterv11,arbace.core8,identityV2,nnv11,arbace.core5,doallv21,arbace.go.check.types13,boolean-type?R229,R230,v15,arbace.go.build4,jumpR231,m8,R25,l0,R29,l0,R32,l0,R34,l0,v15,arbace.go.build9,call-stmtv15,arbace.go.build13,deferred-callv11,arbace.core7,vreset!R220,R232,l-1,R233,R234,R235,v15,arbace.go.build11,select-recvR219,v15,arbace.go.build7,go-stmtv15,arbace.go.build11,incdec-stmtv15,arbace.go.build10,defer-stmtv15,arbace.go.build10,range-stmtv15,arbace.go.build9,send-stmtv15,arbace.go.build10,block-nodev15,arbace.go.build11,switch-stmtv15,arbace.go.build16,type-switch-stmtR236,v15,arbace.go.build11,select-stmtv15,arbace.go.build9,innermostS2,R222,R207,v15,arbace.go.build11,return-stmtv15,arbace.go.build8,for-stmtR237,R238,S16,R149,R116,R238,R148,R137,R83,R108,R18,R237,R162,R150,R132,R20,R191,R95,R138,S16,R149,R116,R238,R148,R137,R83,R108,R18,R237,R162,R150,R132,R20,R191,R95,R138,S2,R98,R52,v11,arbace.core4,keysR239,R240,v15,arbace.go.build10,has-defer?R241,v15,arbace.go.build11,free-localsR242,m10,R25,l0,R29,l0,R32,l0,R34,l0,R77,l0,v20,arbace.go.check.decl11,instantiateR243,R244,v21,arbace.go.check.types10,terms-normR156,V1,R156,v21,arbace.go.check.types12,sort-methodsv21,arbace.go.check.types9,make-tsetR245,R246,R247,v15,arbace.go.build9,skip-keysv15,arbace.go.build9,type-keysv19,arbace.go.check.env4,obj?v20,arbace.go.check.code14,representationS1,R134,v11,arbace.core11,persistent!v11,arbace.core9,reduce-kvv11,arbace.core6,assoc!v15,arbace.go.build8,obj-keysv15,arbace.go.build9,objs-keysv11,arbace.core9,transientv15,arbace.go.build10,resolve-onS2,R149,R116,S2,R116,R134,S3,s7,Alignofs6,Sizeofs8,Offsetofv21,arbace.go.check.types6,sizeofv20,arbace.go.check.code14,offsetof-valuev21,arbace.go.check.types7,alignofv21,arbace.go.check.types11,const-type?v20,arbace.go.check.code10,conversionv11,arbace.core5,mergev11,arbace.core11,select-keysV2,R81,R83,v15,arbace.go.build11,local-typesv21,arbace.go.check.types9,new-namedV5,R20,R16,R17,R54,R52,R248,V5,R20,R16,R17,R54,R52,v21,arbace.go.check.types11,basic-namesv13,arbace.string4,joinv15,arbace.go.build6,rt-sigv15,arbace.go.build9,inst-gensR249,v15,arbace.go.build9,inst-treev15,arbace.go.build9,instancesR250,v15,arbace.go.build13,instance-namev15,arbace.go.build14,build-instance")

var Lit_1 *jrt.String = jrt.Intern("AnySlot")

var Lit_2 *jrt.String = jrt.Intern("AnyNewCell")

var Lit_3 *jrt.String = jrt.Intern("AnyCell")

var Lit_4 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_5 *jrt.String = jrt.Intern("AnyPlace")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes$fn__367000265")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes$fn__367000267")

var Lit_8 *jrt.String = jrt.Intern("MakeSliceOf")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes$fn__367000269")

var Lit_10 *jrt.String = jrt.Intern("ArgF")

var Lit_11 *jrt.String = jrt.Intern("ArgI")

var Lit_12 *jrt.String = jrt.Intern("ArgR")

var Lit_13 *jrt.String = jrt.Intern("ArgS")

var Lit_14 *jrt.String = jrt.Intern("BI")

var Lit_15 *jrt.String = jrt.Intern("IB")

var Lit_16 *jrt.String = jrt.Intern("goi's builder: a ")

var Lit_17 *jrt.String = jrt.Intern(" node where a ")

var Lit_18 *jrt.String = jrt.Intern(" is wanted")

var Lit_19 *jrt.String = jrt.Intern("AssertF")

var Lit_20 *jrt.String = jrt.Intern("AssertI")

var Lit_21 *jrt.String = jrt.Intern("AssertR")

var Lit_22 *jrt.String = jrt.Intern("AssertS")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.build$assign_stmt$fn__367000596")

var Lit_24 *jrt.String = jrt.Intern("Assign")

var Lit_25 *jrt.String = jrt.Intern("MapSet")

var Lit_26 *jrt.String = jrt.Intern("CellP")

var Lit_27 *jrt.String = jrt.Intern("AtSlot")

var Lit_28 *jrt.String = jrt.Intern("AtNewCell")

var Lit_29 *jrt.String = jrt.Intern("AtCell")

var Lit_30 *jrt.String = jrt.Intern("AtPlace")

var Lit_31 *jrt.String = jrt.Intern("and")

var Lit_32 *jrt.String = jrt.Intern("AndB")

var Lit_33 *jrt.String = jrt.Intern("or")

var Lit_34 *jrt.String = jrt.Intern("OrB")

var Lit_35 *jrt.String = jrt.Intern("K")

var Lit_36 *jrt.String = jrt.Intern("F32")

var Lit_37 *jrt.String = jrt.Intern("F64")

var Lit_38 *jrt.String = jrt.Intern("C64")

var Lit_39 *jrt.String = jrt.Intern("C128")

var Lit_40 *jrt.String = jrt.Intern("ConcatS")

var Lit_41 *jrt.String = jrt.Intern("<<")

var Lit_42 *jrt.String = jrt.Intern("Shl")

var Lit_43 *jrt.String = jrt.Intern("Shr")

var Lit_44 *jrt.String = jrt.Intern("U")

var Lit_45 *jrt.String = jrt.Intern("")

var Lit_46 *jrt.String = jrt.Intern("Seq")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.build$body_node$fn__367000666")

var Lit_48 *jrt.String = jrt.Intern("SeqL")

var Lit_49 *jrt.String = jrt.Intern("ProCell")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367001009__367001013")

var Lit_51 *jrt.String = jrt.Intern("NewCode")

var Lit_52 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367001009__367001013$fn__367001014")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367001009__367001013$fn__367001014$fn__367001015")

var Lit_54 *jrt.String = jrt.Intern("ProNewCell")

var Lit_55 *jrt.String = jrt.Intern("EpiCell")

var Lit_56 *jrt.String = jrt.Intern("ProZeroR")

var Lit_57 *jrt.String = jrt.Intern(".func")

var Lit_58 *jrt.String = jrt.Intern("FuncCell")

var Lit_59 *jrt.String = jrt.Intern("FuncSource")

var Lit_60 *jrt.String = jrt.Intern("SetCode")

var Lit_61 *jrt.String = jrt.Intern("MakeClosure")

var Lit_62 *jrt.String = jrt.Intern("arbace.go.build$build_fn_lit$fn__367001038")

var Lit_63 *jrt.String = jrt.Intern("a function without a body (assembly)")

var Lit_64 *jrt.String = jrt.Intern("out of scope: §1.1")

var Lit_65 *jrt.String = jrt.Intern("init")

var Lit_66 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001044__367001048")

var Lit_67 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001044__367001048$fn__367001049")

var Lit_68 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001044__367001048$fn__367001049$fn__367001050")

var Lit_69 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001044__367001048$fn__367001049$fn__367001054")

var Lit_70 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001044__367001048$fn__367001049$fn__367001050$fn__367001051")

var Lit_71 *jrt.String = jrt.Intern("_")

var Lit_72 *jrt.String = jrt.Intern("the generic function ")

var Lit_73 *jrt.String = jrt.Intern(".")

var Lit_74 *jrt.String = jrt.Intern(" (its body is not in the forms)")

var Lit_75 *jrt.String = jrt.Intern("GR6")

var Lit_76 *jrt.String = jrt.Intern("r")

var Lit_77 *jrt.String = jrt.Intern("arbace.go.build$build_method_thunk$fn__367000371")

var Lit_78 *jrt.String = jrt.Intern("arbace.go.build$build_method_thunk$fn__367000373")

var Lit_79 *jrt.String = jrt.Intern("p")

var Lit_80 *jrt.String = jrt.Intern("arbace.go.build$builtin$value__367000474")

var Lit_81 *jrt.String = jrt.Intern("Add")

var Lit_82 *jrt.String = jrt.Intern("UnsafeAdd")

var Lit_83 *jrt.String = jrt.Intern("make")

var Lit_84 *jrt.String = jrt.Intern("MakeMap")

var Lit_85 *jrt.String = jrt.Intern("MakeSlice")

var Lit_86 *jrt.String = jrt.Intern("MakeChan")

var Lit_87 *jrt.String = jrt.Intern("panic")

var Lit_88 *jrt.String = jrt.Intern("Panic")

var Lit_89 *jrt.String = jrt.Intern("StmtT")

var Lit_90 *jrt.String = jrt.Intern("recover")

var Lit_91 *jrt.String = jrt.Intern("DeferredRecover")

var Lit_92 *jrt.String = jrt.Intern("Recover")

var Lit_93 *jrt.String = jrt.Intern("StringData")

var Lit_94 *jrt.String = jrt.Intern("UnsafeStringData")

var Lit_95 *jrt.String = jrt.Intern("String")

var Lit_96 *jrt.String = jrt.Intern("UnsafeString")

var Lit_97 *jrt.String = jrt.Intern("Slice")

var Lit_98 *jrt.String = jrt.Intern("UnsafeSlice")

var Lit_99 *jrt.String = jrt.Intern("real")

var Lit_100 *jrt.String = jrt.Intern("RealF")

var Lit_101 *jrt.String = jrt.Intern("imag")

var Lit_102 *jrt.String = jrt.Intern("ImagF")

var Lit_103 *jrt.String = jrt.Intern("complex")

var Lit_104 *jrt.String = jrt.Intern("ComplexR")

var Lit_105 *jrt.String = jrt.Intern("cap")

var Lit_106 *jrt.String = jrt.Intern("CapSlice")

var Lit_107 *jrt.String = jrt.Intern("CapChan")

var Lit_108 *jrt.String = jrt.Intern("ThenI")

var Lit_109 *jrt.String = jrt.Intern("ConstI")

var Lit_110 *jrt.String = jrt.Intern("cap of ")

var Lit_111 *jrt.String = jrt.Intern("GR4")

var Lit_112 *jrt.String = jrt.Intern("delete")

var Lit_113 *jrt.String = jrt.Intern("Delete")

var Lit_114 *jrt.String = jrt.Intern("len")

var Lit_115 *jrt.String = jrt.Intern("LenS")

var Lit_116 *jrt.String = jrt.Intern("LenSlice")

var Lit_117 *jrt.String = jrt.Intern("LenMap")

var Lit_118 *jrt.String = jrt.Intern("LenChan")

var Lit_119 *jrt.String = jrt.Intern("len of ")

var Lit_120 *jrt.String = jrt.Intern("max")

var Lit_121 *jrt.String = jrt.Intern("MinMaxF")

var Lit_122 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000488")

var Lit_123 *jrt.String = jrt.Intern("MinMaxI")

var Lit_124 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000490")

var Lit_125 *jrt.String = jrt.Intern("MinMaxS")

var Lit_126 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000492")

var Lit_127 *jrt.String = jrt.Intern("min")

var Lit_128 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000495")

var Lit_129 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000497")

var Lit_130 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000499")

var Lit_131 *jrt.String = jrt.Intern("SliceData")

var Lit_132 *jrt.String = jrt.Intern("UnsafeSliceData")

var Lit_133 *jrt.String = jrt.Intern("new")

var Lit_134 *jrt.String = jrt.Intern("AddrOf")

var Lit_135 *jrt.String = jrt.Intern("LitP")

var Lit_136 *jrt.String = jrt.Intern("NewR")

var Lit_137 *jrt.String = jrt.Intern("copy")

var Lit_138 *jrt.String = jrt.Intern("CopyString")

var Lit_139 *jrt.String = jrt.Intern("Copy")

var Lit_140 *jrt.String = jrt.Intern("print")

var Lit_141 *jrt.String = jrt.Intern("Print")

var Lit_142 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000504__367000508")

var Lit_143 *jrt.String = jrt.Intern("println")

var Lit_144 *jrt.String = jrt.Intern("clear")

var Lit_145 *jrt.String = jrt.Intern("ClearMap")

var Lit_146 *jrt.String = jrt.Intern("ClearSlice")

var Lit_147 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000514__367000518")

var Lit_148 *jrt.String = jrt.Intern("append")

var Lit_149 *jrt.String = jrt.Intern("AppendString")

var Lit_150 *jrt.String = jrt.Intern("AppendSpread")

var Lit_151 *jrt.String = jrt.Intern("Append")

var Lit_152 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000527")

var Lit_153 *jrt.String = jrt.Intern("close")

var Lit_154 *jrt.String = jrt.Intern("Close")

var Lit_155 *jrt.String = jrt.Intern("the builtin ")

var Lit_156 *jrt.String = jrt.Intern("unsafe.")

var Lit_157 *jrt.String = jrt.Intern("GR3")

var Lit_158 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000504__367000508$fn__367000509")

var Lit_159 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000504__367000508$fn__367000509$fn__367000510")

var Lit_160 *jrt.String = jrt.Intern("PrintArg")

var Lit_161 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000514__367000518$fn__367000519")

var Lit_162 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000514__367000518$fn__367000519$fn__367000520")

var Lit_163 *jrt.String = jrt.Intern("the call kind ")

var Lit_164 *jrt.String = jrt.Intern("ExprT")

var Lit_165 *jrt.String = jrt.Intern("Call")

var Lit_166 *jrt.String = jrt.Intern("arbace.go.build$cell_call$fn__367000278")

var Lit_167 *jrt.String = jrt.Intern("resCopies")

var Lit_168 *jrt.String = jrt.Intern("CallT")

var Lit_169 *jrt.String = jrt.Intern("IsNilR")

var Lit_170 *jrt.String = jrt.Intern("==")

var Lit_171 *jrt.String = jrt.Intern("NotB")

var Lit_172 *jrt.String = jrt.Intern("R")

var Lit_173 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$fn__367000136")

var Lit_174 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$field__367000138")

var Lit_175 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$iter__367000143__367000147")

var Lit_176 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$fn__367000153")

var Lit_177 *jrt.String = jrt.Intern("ConstB")

var Lit_178 *jrt.String = jrt.Intern("ThenB")

var Lit_179 *jrt.String = jrt.Intern("F")

var Lit_180 *jrt.String = jrt.Intern("I")

var Lit_181 *jrt.String = jrt.Intern("LK")

var Lit_182 *jrt.String = jrt.Intern("LL")

var Lit_183 *jrt.String = jrt.Intern("S")

var Lit_184 *jrt.String = jrt.Intern("FieldP")

var Lit_185 *jrt.String = jrt.Intern("BoxP")

var Lit_186 *jrt.String = jrt.Intern("FieldOff")

var Lit_187 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$iter__367000143__367000147$fn__367000148")

var Lit_188 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$iter__367000143__367000147$fn__367000148$fn__367000149")

var Lit_189 *jrt.String = jrt.Intern("arbace.go.build$compiled_call$fn__367000307")

var Lit_190 *jrt.String = jrt.Intern("CallCompiled")

var Lit_191 *jrt.String = jrt.Intern("arbace.go.build$compiled_call_node$fn__367000304")

var Lit_192 *jrt.String = jrt.Intern("CvC64")

var Lit_193 *jrt.String = jrt.Intern("ConstR")

var Lit_194 *jrt.String = jrt.Intern("ConstF")

var Lit_195 *jrt.String = jrt.Intern("a constant of type ")

var Lit_196 *jrt.String = jrt.Intern("Cv")

var Lit_197 *jrt.String = jrt.Intern("Uto")

var Lit_198 *jrt.String = jrt.Intern("Ito")

var Lit_199 *jrt.String = jrt.Intern("Fto")

var Lit_200 *jrt.String = jrt.Intern("CvF32")

var Lit_201 *jrt.String = jrt.Intern("StrFromRune")

var Lit_202 *jrt.String = jrt.Intern("StrFromBytes")

var Lit_203 *jrt.String = jrt.Intern("StrFromRunes")

var Lit_204 *jrt.String = jrt.Intern("BytesFromStr")

var Lit_205 *jrt.String = jrt.Intern("RunesFromStr")

var Lit_206 *jrt.String = jrt.Intern("CvC128")

var Lit_207 *jrt.String = jrt.Intern("UintptrToUnsafe")

var Lit_208 *jrt.String = jrt.Intern("PtrToUnsafe")

var Lit_209 *jrt.String = jrt.Intern("UnsafeToUintptr")

var Lit_210 *jrt.String = jrt.Intern("UnsafeToPtr")

var Lit_211 *jrt.String = jrt.Intern("SliceToArray")

var Lit_212 *jrt.String = jrt.Intern("SliceToArrayPtr")

var Lit_213 *jrt.String = jrt.Intern("ConvR")

var Lit_214 *jrt.String = jrt.Intern("the conversion ")

var Lit_215 *jrt.String = jrt.Intern(" to ")

var Lit_216 *jrt.String = jrt.Intern("Nop")

var Lit_217 *jrt.String = jrt.Intern("arbace.go.build$decl_stmt$fn__367000618")

var Lit_218 *jrt.String = jrt.Intern("arbace.go.build$decl_stmt$target__367000620")

var Lit_219 *jrt.String = jrt.Intern("Defer")

var Lit_220 *jrt.String = jrt.Intern("arbace.go.build$deferred_call$to_mini__367000846")

var Lit_221 *jrt.String = jrt.Intern("arbace.go.build$deferred_call$fn__367000848")

var Lit_222 *jrt.String = jrt.Intern("NonNilR")

var Lit_223 *jrt.String = jrt.Intern("deferring a call of kind ")

var Lit_224 *jrt.String = jrt.Intern("arbace.go.build$deferred_call$fn__367000853")

var Lit_225 *jrt.String = jrt.Intern("a value of type ")

var Lit_226 *jrt.String = jrt.Intern("an invalid type")

var Lit_227 *jrt.String = jrt.Intern("TBasic")

var Lit_228 *jrt.String = jrt.Intern("unsafe.Pointer")

var Lit_229 *jrt.String = jrt.Intern("goi's builder: the type parameter ")

var Lit_230 *jrt.String = jrt.Intern(" of an uninstantiated tree")

var Lit_231 *jrt.String = jrt.Intern("TMap")

var Lit_232 *jrt.String = jrt.Intern("TArray")

var Lit_233 *jrt.String = jrt.Intern("TChan")

var Lit_234 *jrt.String = jrt.Intern("any")

var Lit_235 *jrt.String = jrt.Intern("TIface")

var Lit_236 *jrt.String = jrt.Intern("TSlice")

var Lit_237 *jrt.String = jrt.Intern("TFunc")

var Lit_238 *jrt.String = jrt.Intern("TPtr")

var Lit_239 *jrt.String = jrt.Intern("TStruct")

var Lit_240 *jrt.String = jrt.Intern("the type ")

var Lit_241 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000408__367000412")

var Lit_242 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$fn__367000450")

var Lit_243 *jrt.String = jrt.Intern("TSetMethods")

var Lit_244 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$fn__367000452")

var Lit_245 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$fn__367000454")

var Lit_246 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$fn__367000456")

var Lit_247 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$fn__367000458")

var Lit_248 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000408__367000412$fn__367000413")

var Lit_249 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000408__367000412$fn__367000413$fn__367000414")

var Lit_250 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000408__367000412$fn__367000413$fn__367000442")

var Lit_251 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000408__367000412$fn__367000413$fn__367000444")

var Lit_252 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000408__367000412$fn__367000413$fn__367000414$fn__367000425")

var Lit_253 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000408__367000412$fn__367000413$fn__367000414$fn__367000427")

var Lit_254 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000408__367000412$fn__367000413$fn__367000414$fn__367000427$fn__367000428")

var Lit_255 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000408__367000412$fn__367000413$fn__367000444$fn__367000445")

var Lit_256 *jrt.String = jrt.Intern("error")

var Lit_257 *jrt.String = jrt.Intern("arbace.lang.GoInterp")

var Lit_258 *jrt.String = jrt.Intern("java.util.HashMap")

var Lit_259 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_260 *jrt.String = jrt.Intern("ThenF")

var Lit_261 *jrt.String = jrt.Intern("ThenR")

var Lit_262 *jrt.String = jrt.Intern("ThenS")

var Lit_263 *jrt.String = jrt.Intern("Recv")

var Lit_264 *jrt.String = jrt.Intern("DerefP")

var Lit_265 *jrt.String = jrt.Intern("IndexS")

var Lit_266 *jrt.String = jrt.Intern("arbace.go.build$ex$fn__367000234")

var Lit_267 *jrt.String = jrt.Intern("SliceString")

var Lit_268 *jrt.String = jrt.Intern("SliceSlice")

var Lit_269 *jrt.String = jrt.Intern("SliceArray")

var Lit_270 *jrt.String = jrt.Intern("MapGet")

var Lit_271 *jrt.String = jrt.Intern("ZeroR")

var Lit_272 *jrt.String = jrt.Intern("a type of a package not in the table, in ")

var Lit_273 *jrt.String = jrt.Intern("GR5")

var Lit_274 *jrt.String = jrt.Intern("the expression ")

var Lit_275 *jrt.String = jrt.Intern("ExprB")

var Lit_276 *jrt.String = jrt.Intern("ExprF")

var Lit_277 *jrt.String = jrt.Intern("ExprI")

var Lit_278 *jrt.String = jrt.Intern("ExprR")

var Lit_279 *jrt.String = jrt.Intern("ExprS")

var Lit_280 *jrt.String = jrt.Intern("LoadR")

var Lit_281 *jrt.String = jrt.Intern("arbace.go.build$field_sel$fn__367000318")

var Lit_282 *jrt.String = jrt.Intern("arbace.go.build$for_stmt$fn__367000684")

var Lit_283 *jrt.String = jrt.Intern("For")

var Lit_284 *jrt.String = jrt.Intern("arbace.go.build$free_locals$walk__367000948")

var Lit_285 *jrt.String = jrt.Intern("arbace.go.build$free_locals$fn__367000981")

var Lit_286 *jrt.String = jrt.Intern("FromMemR")

var Lit_287 *jrt.String = jrt.Intern("FuncValue")

var Lit_288 *jrt.String = jrt.Intern("MemberValue")

var Lit_289 *jrt.String = jrt.Intern("GoStmt")

var Lit_290 *jrt.String = jrt.Intern("arbace.go.build$go_string_node$fn__367000082")

var Lit_291 *jrt.String = jrt.Intern("ConstS")

var Lit_292 *jrt.String = jrt.Intern("ConstSB")

var Lit_293 *jrt.String = jrt.Intern("arbace.go.build$go_string_node$fn__367000084")

var Lit_294 *jrt.String = jrt.Intern("arbace.go.build$has_defer_QMARK_$walk__367000936")

var Lit_295 *jrt.String = jrt.Intern("IdxSlot")

var Lit_296 *jrt.String = jrt.Intern("IdxNewCell")

var Lit_297 *jrt.String = jrt.Intern("IdxStore")

var Lit_298 *jrt.String = jrt.Intern("arbace.go.build$iface_call$fn__367000339")

var Lit_299 *jrt.String = jrt.Intern("ErrorCall")

var Lit_300 *jrt.String = jrt.Intern("CompiledDispatchT")

var Lit_301 *jrt.String = jrt.Intern("CompiledDispatch")

var Lit_302 *jrt.String = jrt.Intern("ThenT")

var Lit_303 *jrt.String = jrt.Intern("CallIfaceT")

var Lit_304 *jrt.String = jrt.Intern("Then")

var Lit_305 *jrt.String = jrt.Intern("CallIface")

var Lit_306 *jrt.String = jrt.Intern("IfaceI")

var Lit_307 *jrt.String = jrt.Intern("IfaceF")

var Lit_308 *jrt.String = jrt.Intern("IfaceR")

var Lit_309 *jrt.String = jrt.Intern("IfaceS")

var Lit_310 *jrt.String = jrt.Intern("IfaceMethodValue")

var Lit_311 *jrt.String = jrt.Intern("interface {}")

var Lit_312 *jrt.String = jrt.Intern("+")

var Lit_313 *jrt.String = jrt.Intern("-")

var Lit_314 *jrt.String = jrt.Intern("SliceElemP")

var Lit_315 *jrt.String = jrt.Intern("ArrayElemP")

var Lit_316 *jrt.String = jrt.Intern("indexing ")

var Lit_317 *jrt.String = jrt.Intern("NewCellInit")

var Lit_318 *jrt.String = jrt.Intern("arbace.go.build$inst_tree$ty__367001110")

var Lit_319 *jrt.String = jrt.Intern("arbace.go.build$inst_tree$obj__367001112")

var Lit_320 *jrt.String = jrt.Intern("arbace.go.build$inst_tree$const_fix__367001114")

var Lit_321 *jrt.String = jrt.Intern("arbace.go.build$inst_tree$node__367001119")

var Lit_322 *jrt.String = jrt.Intern("arbace.go.build$inst_tree$node__367001119$fn__367001120")

var Lit_323 *jrt.String = jrt.Intern("Sizeof")

var Lit_324 *jrt.String = jrt.Intern("Offsetof")

var Lit_325 *jrt.String = jrt.Intern("Alignof")

var Lit_326 *jrt.String = jrt.Intern("[")

var Lit_327 *jrt.String = jrt.Intern("]")

var Lit_328 *jrt.String = jrt.Intern(",")

var Lit_329 *jrt.String = jrt.Intern("arbace.go.build$instance_cell$fn__367001168")

var Lit_330 *jrt.String = jrt.Intern("arbace.go.build$instance_cell$fn__367001170")

var Lit_331 *jrt.String = jrt.Intern("arbace.go.build$instance_cell$fn__367001170$fn__367001171")

var Lit_332 *jrt.String = jrt.Intern("[...]")

var Lit_333 *jrt.String = jrt.Intern("(*")

var Lit_334 *jrt.String = jrt.Intern(").")

var Lit_335 *jrt.String = jrt.Intern("LK64")

var Lit_336 *jrt.String = jrt.Intern("LL64")

var Lit_337 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001065")

var Lit_338 *jrt.String = jrt.Intern("arbace.go.build$isubst$terms__367001067")

var Lit_339 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001076")

var Lit_340 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001078")

var Lit_341 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001080")

var Lit_342 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001082")

var Lit_343 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001084")

var Lit_344 *jrt.String = jrt.Intern("arbace.go.build$isubst$terms__367001067$fn__367001069")

var Lit_345 *jrt.String = jrt.Intern("Jump")

var Lit_346 *jrt.String = jrt.Intern("arbace.go.build$lazily$fn__367000017")

var Lit_347 *jrt.String = jrt.Intern("arbace.go.build$lazily$fn__367000017$fn__367000018")

var Lit_348 *jrt.String = jrt.Intern("goi: unsupported: ")

var Lit_349 *jrt.String = jrt.Intern("LitMap")

var Lit_350 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000210")

var Lit_351 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000212")

var Lit_352 *jrt.String = jrt.Intern("LitSlice")

var Lit_353 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000214")

var Lit_354 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000216")

var Lit_355 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000177")

var Lit_356 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000179__367000183")

var Lit_357 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000193")

var Lit_358 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000195")

var Lit_359 *jrt.String = jrt.Intern("ElemSize")

var Lit_360 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000197")

var Lit_361 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000199")

var Lit_362 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000179__367000183$fn__367000184")

var Lit_363 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000179__367000183$fn__367000184$fn__367000185")

var Lit_364 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000179__367000183$fn__367000184$fn__367000189")

var Lit_365 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000179__367000183$fn__367000184$fn__367000185$fn__367000186")

var Lit_366 *jrt.String = jrt.Intern("a literal key promoted through a pointer")

var Lit_367 *jrt.String = jrt.Intern("LoadF")

var Lit_368 *jrt.String = jrt.Intern("LoadI")

var Lit_369 *jrt.String = jrt.Intern("LoadS")

var Lit_370 *jrt.String = jrt.Intern("goi's builder: no location for ")

var Lit_371 *jrt.String = jrt.Intern("LocalF")

var Lit_372 *jrt.String = jrt.Intern("LocalI")

var Lit_373 *jrt.String = jrt.Intern("LocalR")

var Lit_374 *jrt.String = jrt.Intern("LocalS")

var Lit_375 *jrt.String = jrt.Intern("arbace.go.build$local_types$walk__367001087")

var Lit_376 *jrt.String = jrt.Intern("MemR")

var Lit_377 *jrt.String = jrt.Intern("RawR")

var Lit_378 *jrt.String = jrt.Intern("InterpMethodCallable")

var Lit_379 *jrt.String = jrt.Intern("arbace.go.build$method_candidates$walk__367000382")

var Lit_380 *jrt.String = jrt.Intern("arbace.go.build$method_expr_node$fn__367000376")

var Lit_381 *jrt.String = jrt.Intern("-fm")

var Lit_382 *jrt.String = jrt.Intern("arbace.go.build$method_expr_node$fn__367000379")

var Lit_383 *jrt.String = jrt.Intern("BoundCompiled")

var Lit_384 *jrt.String = jrt.Intern("MethodValue")

var Lit_385 *jrt.String = jrt.Intern("TCompiled")

var Lit_386 *jrt.String = jrt.Intern("TNamedIface")

var Lit_387 *jrt.String = jrt.Intern("TNamed")

var Lit_388 *jrt.String = jrt.Intern("the recursive pointer type ")

var Lit_389 *jrt.String = jrt.Intern("as built: GR3")

var Lit_390 *jrt.String = jrt.Intern("arbace.go.build$named_desc$fn__367000065")

var Lit_391 *jrt.String = jrt.Intern("TSetUnder")

var Lit_392 *jrt.String = jrt.Intern("used before it is complete")

var Lit_393 *jrt.String = jrt.Intern(", recursive through a slice, an array, a map or a function")

var Lit_394 *jrt.String = jrt.Intern("SetC")

var Lit_395 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells$fn__367000675")

var Lit_396 *jrt.String = jrt.Intern("RenewCells")

var Lit_397 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells$fn__367000677")

var Lit_398 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells$fn__367000679")

var Lit_399 *jrt.String = jrt.Intern("VarP")

var Lit_400 *jrt.String = jrt.Intern("GlobalP")

var Lit_401 *jrt.String = jrt.Intern("goi's builder: ")

var Lit_402 *jrt.String = jrt.Intern(" is not a cell")

var Lit_403 *jrt.String = jrt.Intern("the address of a ")

var Lit_404 *jrt.String = jrt.Intern("arbace.go.build$prepare_place$freeze__367000586")

var Lit_405 *jrt.String = jrt.Intern("arbace.go.build$prepare_place$chain__367000588")

var Lit_406 *jrt.String = jrt.Intern("arbace.go.build$quiet_expr_QMARK_$fn__367000643")

var Lit_407 *jrt.String = jrt.Intern("arbace.go.build$quiet_expr_QMARK_$fn__367000645")

var Lit_408 *jrt.String = jrt.Intern("arbace.go.build$quiet_expr_QMARK_$fn__367000647")

var Lit_409 *jrt.String = jrt.Intern("arbace.go.build$quiet_expr_QMARK_$fn__367000649")

var Lit_410 *jrt.String = jrt.Intern("arbace.go.build$quiet_header_QMARK_$fn__367000659")

var Lit_411 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$conv_QMARK___367000729")

var Lit_412 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000732")

var Lit_413 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000737")

var Lit_414 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000739")

var Lit_415 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000742")

var Lit_416 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$mk__367000750")

var Lit_417 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000758")

var Lit_418 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000760")

var Lit_419 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000762")

var Lit_420 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000764")

var Lit_421 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000766")

var Lit_422 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000768")

var Lit_423 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000770")

var Lit_424 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000772")

var Lit_425 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000774")

var Lit_426 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000776")

var Lit_427 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000778")

var Lit_428 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000786")

var Lit_429 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000789")

var Lit_430 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000794")

var Lit_431 *jrt.String = jrt.Intern("RangeFunc")

var Lit_432 *jrt.String = jrt.Intern("RangeMap")

var Lit_433 *jrt.String = jrt.Intern("RangeInt")

var Lit_434 *jrt.String = jrt.Intern("RangeArray")

var Lit_435 *jrt.String = jrt.Intern("RangePtrArray")

var Lit_436 *jrt.String = jrt.Intern("RangeChan")

var Lit_437 *jrt.String = jrt.Intern("RangeString")

var Lit_438 *jrt.String = jrt.Intern("RangeSlice")

var Lit_439 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$mk__367000750$fn__367000751")

var Lit_440 *jrt.String = jrt.Intern("arbace.go.build$range_targets$fn__367000689")

var Lit_441 *jrt.String = jrt.Intern("arbace.go.build$range_targets$fn__367000691")

var Lit_442 *jrt.String = jrt.Intern("arbace.go.build$recursive_QMARK_$walk__367000037")

var Lit_443 *jrt.String = jrt.Intern("arbace.go.build$recursive_QMARK_$walk__367000037$fn__367000039")

var Lit_444 *jrt.String = jrt.Intern("DerefWrapP")

var Lit_445 *jrt.String = jrt.Intern("goi's builder: no receiver type for the method ")

var Lit_446 *jrt.String = jrt.Intern("goi's builder: no method ")

var Lit_447 *jrt.String = jrt.Intern(" of ")

var Lit_448 *jrt.String = jrt.Intern("arbace.go.build$return_stmt$store__367000837")

var Lit_449 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000565")

var Lit_450 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000570")

var Lit_451 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000572")

var Lit_452 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000574")

var Lit_453 *jrt.String = jrt.Intern("Assert2")

var Lit_454 *jrt.String = jrt.Intern("MapGet2")

var Lit_455 *jrt.String = jrt.Intern("Recv2")

var Lit_456 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000580")

var Lit_457 *jrt.String = jrt.Intern("int32")

var Lit_458 *jrt.String = jrt.Intern("uint8")

var Lit_459 *jrt.String = jrt.Intern("command-line-arguments")

var Lit_460 *jrt.String = jrt.Intern("main.")

var Lit_461 *jrt.String = jrt.Intern("main")

var Lit_462 *jrt.String = jrt.Intern("map[")

var Lit_463 *jrt.String = jrt.Intern("<-chan ")

var Lit_464 *jrt.String = jrt.Intern("chan ")

var Lit_465 *jrt.String = jrt.Intern("chan<- ")

var Lit_466 *jrt.String = jrt.Intern("interface { ")

var Lit_467 *jrt.String = jrt.Intern(" }")

var Lit_468 *jrt.String = jrt.Intern("; ")

var Lit_469 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001132__367001136")

var Lit_470 *jrt.String = jrt.Intern("[]")

var Lit_471 *jrt.String = jrt.Intern("func")

var Lit_472 *jrt.String = jrt.Intern("*")

var Lit_473 *jrt.String = jrt.Intern("struct {}")

var Lit_474 *jrt.String = jrt.Intern("struct { ")

var Lit_475 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001142__367001146")

var Lit_476 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001132__367001136$fn__367001137")

var Lit_477 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001132__367001136$fn__367001137$fn__367001138")

var Lit_478 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001142__367001146$fn__367001147")

var Lit_479 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001142__367001146$fn__367001147$fn__367001148")

var Lit_480 *jrt.String = jrt.Intern(" ")

var Lit_481 *jrt.String = jrt.Intern("(")

var Lit_482 *jrt.String = jrt.Intern(")")

var Lit_483 *jrt.String = jrt.Intern(", ")

var Lit_484 *jrt.String = jrt.Intern("arbace.go.build$rt_sig$fn__367001157")

var Lit_485 *jrt.String = jrt.Intern(" (")

var Lit_486 *jrt.String = jrt.Intern("...")

var Lit_487 *jrt.String = jrt.Intern("arbace.go.build$select_recv$find_recv__367000896")

var Lit_488 *jrt.String = jrt.Intern("arbace.go.build$select_recv$replace_recv__367000898")

var Lit_489 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367000903__367000907")

var Lit_490 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$fn__367000925")

var Lit_491 *jrt.String = jrt.Intern("Select")

var Lit_492 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367000903__367000907$fn__367000908")

var Lit_493 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367000903__367000907$fn__367000908$fn__367000909")

var Lit_494 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367000903__367000907$fn__367000908$fn__367000917")

var Lit_495 *jrt.String = jrt.Intern("NewSelCase")

var Lit_496 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367000903__367000907$fn__367000908$fn__367000921")

var Lit_497 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367000903__367000907$fn__367000908$fn__367000909$fn__367000910")

var Lit_498 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367000903__367000907$fn__367000908$fn__367000909$fn__367000914")

var Lit_499 *jrt.String = jrt.Intern("Send")

var Lit_500 *jrt.String = jrt.Intern("arbace.go.build$set_iface_methods_BANG_$sig__367000059")

var Lit_501 *jrt.String = jrt.Intern("TSetIfaceMethods")

var Lit_502 *jrt.String = jrt.Intern("arbace.go.build$set_iface_methods_BANG_$fn__367000061")

var Lit_503 *jrt.String = jrt.Intern("SetF")

var Lit_504 *jrt.String = jrt.Intern("SetI")

var Lit_505 *jrt.String = jrt.Intern("SetR")

var Lit_506 *jrt.String = jrt.Intern("SetS")

var Lit_507 *jrt.String = jrt.Intern("arbace.go.build$slot_layout$take_BANG___367000246")

var Lit_508 *jrt.String = jrt.Intern("arbace.go.build$slot_layout$fn__367000248")

var Lit_509 *jrt.String = jrt.Intern("arbace.go.build$slot_layout$fn__367000250")

var Lit_510 *jrt.String = jrt.Intern("If")

var Lit_511 *jrt.String = jrt.Intern("goi's builder: fallthrough outside a switch")

var Lit_512 *jrt.String = jrt.Intern("goi's builder: no continue target ")

var Lit_513 *jrt.String = jrt.Intern("arbace.go.build$stmt$fn__367000931")

var Lit_514 *jrt.String = jrt.Intern("goi's builder: no break target ")

var Lit_515 *jrt.String = jrt.Intern("arbace.go.build$stmt$fn__367000933")

var Lit_516 *jrt.String = jrt.Intern("the statement ")

var Lit_517 *jrt.String = jrt.Intern("StoreF")

var Lit_518 *jrt.String = jrt.Intern("StoreI")

var Lit_519 *jrt.String = jrt.Intern("StoreR")

var Lit_520 *jrt.String = jrt.Intern("StoreS")

var Lit_521 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000048")

var Lit_522 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000050")

var Lit_523 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000052")

var Lit_524 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000054")

var Lit_525 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000800")

var Lit_526 *jrt.String = jrt.Intern("Switch")

var Lit_527 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000800$iter__367000801__367000805")

var Lit_528 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000800$iter__367000801__367000805$fn__367000806")

var Lit_529 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000800$iter__367000801__367000805$fn__367000806$fn__367000807")

var Lit_530 *jrt.String = jrt.Intern("NewCase")

var Lit_531 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000800$iter__367000801__367000805$fn__367000806$iter__367000821__367000825")

var Lit_532 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000800$iter__367000801__367000805$fn__367000806$fn__367000831")

var Lit_533 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000800$iter__367000801__367000805$fn__367000806$fn__367000807$iter__367000808__367000812")

var Lit_534 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000800$iter__367000801__367000805$fn__367000806$fn__367000807$fn__367000818")

var Lit_535 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000800$iter__367000801__367000805$fn__367000806$fn__367000807$iter__367000808__367000812$fn__367000813")

var Lit_536 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000800$iter__367000801__367000805$fn__367000806$fn__367000807$iter__367000808__367000812$fn__367000813$fn__367000814")

var Lit_537 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000800$iter__367000801__367000805$fn__367000806$iter__367000821__367000825$fn__367000826")

var Lit_538 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000800$iter__367000801__367000805$fn__367000806$iter__367000821__367000825$fn__367000826$fn__367000827")

var Lit_539 *jrt.String = jrt.Intern("arbace.go.build$temps_of$fn__367000540")

var Lit_540 *jrt.String = jrt.Intern("arbace.go.build$temps_of$fn__367000547")

var Lit_541 *jrt.String = jrt.Intern("arbace.go.build$temps_of$fn__367000556")

var Lit_542 *jrt.String = jrt.Intern("arbace.go.build$thunk_body$fn__367000365")

var Lit_543 *jrt.String = jrt.Intern("arbace.go.build$thunk_body$fn__367000368")

var Lit_544 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000873__367000877")

var Lit_545 *jrt.String = jrt.Intern("TypeSwitch")

var Lit_546 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000873__367000877$fn__367000878")

var Lit_547 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000873__367000877$fn__367000878$fn__367000879")

var Lit_548 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000873__367000877$fn__367000878$fn__367000887")

var Lit_549 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000873__367000877$fn__367000878$fn__367000889")

var Lit_550 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000873__367000877$fn__367000878$fn__367000891")

var Lit_551 *jrt.String = jrt.Intern("NewTCase")

var Lit_552 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000873__367000877$fn__367000878$fn__367000879$fn__367000880")

var Lit_553 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000873__367000877$fn__367000878$fn__367000879$fn__367000882")

var Lit_554 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367000873__367000877$fn__367000878$fn__367000879$fn__367000884")

var Lit_555 *jrt.String = jrt.Intern("bit-not")

var Lit_556 *jrt.String = jrt.Intern("Compl")

var Lit_557 *jrt.String = jrt.Intern("NegF")

var Lit_558 *jrt.String = jrt.Intern("Neg")

var Lit_559 *jrt.String = jrt.Intern("NegC64")

var Lit_560 *jrt.String = jrt.Intern("NegC128")

var Lit_561 *jrt.String = jrt.Intern("not")

var Lit_562 *jrt.String = jrt.Intern("not supported by goi yet: ")

var Lit_563 *jrt.String = jrt.Intern("CallValue")

var Lit_564 *jrt.String = jrt.Intern("arbace.go.build$value_call$fn__367000293")

var Lit_565 *jrt.String = jrt.Intern("CallValueT")

var Lit_566 *jrt.String = jrt.Intern("NewCell")

var Lit_567 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistskn3,tagyn6,Stringyn1,&yn4,argskn4,linekn6,columnkn4,filekn7,privateyn2,xsyn4,whatyn2,gryn1,fkn7,dynamicyn1,myn2,ntyn3,ctxyn4,pathkn5,int32kn5,int16kn3,intkn5,int64kn4,uintkn6,uint64kn7,uintptrkn12,untyped-runekn6,uint16kn12,untyped-boolkn4,int8kn6,uint32kn11,untyped-intkn4,boolkn5,uint8yn2,tykn8,declaredyn3,tagyn1,uyn2,nmyn3,pkgyn1,dyn1,vyn4,wantyn1,kyn1,xyn1,syn1,nyn1,pyn2,knyn3,op*yn2,xnyn2,ynyn1,yyn2,xkyn2,ykyn9,ycount-tyv11,arbace.core5,in-nsMyn15,arbace.go.buildm2,R0,s1640,goi's builder (doc/go/GOI-SPEC.md §4.1): the checked tree (§3.7) made nodes, typed Go\n  closures of the back end arbace/goi, by its factories through arbace.lang.GoInterp's op\n  native (go/arbace/goi/registry.ae). It numbers each function's slots per kind (parameters and\n  results first, as the signature lays them out), makes the variables that live in Go memory\n  cells (captured, addressed, of a struct or array type, every package variable), gives each\n  jump target its codes, chooses each node's variant by its operands' types, and resolves each\n  call to the callee's cell, a closure, or the table's member. It decides nothing the checker\n  has not: no type, no constant, no resolution.\n\n  GR3 builds the interpreter's core: scalars, strings, slices, arrays, maps, structs, pointers,\n  functions and closures, all control flow with labels and goto, defer, panic and recover,\n  interface values without methods (§5.3 rules 1 and 2), the calls of compiled Go. GR4 adds\n  methods (their receiver laid after the parameters and results), method values and\n  expressions, the method sets of the types that go into interfaces (each entry the method or a\n  thunk: §5.3), interface method calls, type assertions and switches, embedding and promotion,\n  goroutines, channels, select and range over functions and channels. GR6 adds generics (§9.2):\n  each instance of a generic function, method or type built per type-argument list from the\n  generic declaration's checked tree with its type parameters substituted (inst-tree). A form\n  that needs what goi does not run is \"not supported by goi yet\" (§3.4), an ex-info with\n  :goi/unsupported.m2,R0,s1640,goi's builder (doc/go/GOI-SPEC.md §4.1): the checked tree (§3.7) made nodes, typed Go\n  closures of the back end arbace/goi, by its factories through arbace.lang.GoInterp's op\n  native (go/arbace/goi/registry.ae). It numbers each function's slots per kind (parameters and\n  results first, as the signature lays them out), makes the variables that live in Go memory\n  cells (captured, addressed, of a struct or array type, every package variable), gives each\n  jump target its codes, chooses each node's variant by its operands' types, and resolves each\n  call to the callee's cell, a closure, or the table's member. It decides nothing the checker\n  has not: no type, no constant, no resolution.\n\n  GR3 builds the interpreter's core: scalars, strings, slices, arrays, maps, structs, pointers,\n  functions and closures, all control flow with labels and goto, defer, panic and recover,\n  interface values without methods (§5.3 rules 1 and 2), the calls of compiled Go. GR4 adds\n  methods (their receiver laid after the parameters and results), method values and\n  expressions, the method sets of the types that go into interfaces (each entry the method or a\n  thunk: §5.3), interface method calls, type assertions and switches, embedding and promotion,\n  goroutines, channels, select and range over functions and channels. GR6 adds generics (§9.2):\n  each instance of a generic function, method or type built per type-argument list from the\n  generic declaration's checked tree with its type parameters substituted (inst-tree). A form\n  that needs what goi does not run is \"not supported by goi yet\" (§3.4), an ex-info with\n  :goi/unsupported.R1,v15,arbace.go.build2,opm10,R2,L1,V3,Myn2,nmm2,R3,R4,R5,R6,R0,s65,Makes what goi's factory nm makes of args (GoInterp's op native).R7,i33,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build2,oam10,R10,TR2,L1,V1,R11,R7,i38,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,unsupported!m10,R2,L1,V2,R12,R13,R0,s93,Ends the build of a form goi does not support yet (§3.4): what, the milestone that brings it.R7,i40,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,program-modem8,R0,s55,Program mode (bin/goi run, §2.7): set by arbace.go.run.R7,i45,R8,i1,R9,s18,arbace/go/build.aev11,arbace.core4,atomm8,R0,s55,Program mode (bin/goi run, §2.7): set by arbace.go.run.R7,i45,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build6,lazilym10,R2,L1,V1,R14,R0,s230,Builder f of a function's code for SetCode, built on its first call; in program mode a form\n  goi does not support ends the run as it would before the run (goi: unsupported, status 125:\n  GR6, the generic code built per instance).R7,i47,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,*ctx*m10,R15,TR7,i64,R8,i1,R9,s18,arbace/go/build.aeR0,s271,The package's build context: {:path :name :compiled? (path -> listed?) :types (a HashMap of\n  descriptors by checker type) :gen (named type -> its generation) :func-cell (function object\n  -> its *goi.Func) :global (variable object -> {:ptr :type}) :local-gen (an atom)}.v15,arbace.go.build9,local-genm8,R0,s152,The generations of local named types: one counter for every build, so that their\n  descriptors (interned by package, name and generation) stay distinct.R7,i70,R8,i1,R9,s18,arbace/go/build.ael1000000,m8,R0,s152,The generations of local named types: one counter for every build, so that their\n  descriptors (interned by package, name and generation) stay distinct.R7,i70,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,method-datam10,R2,L1,V1,R16,R0,s104,The checker's method data of method object m (its declaration checked): t/*method-obj*\n  while building.R7,i73,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build18,complete-instance!m10,R2,L1,V1,R17,R0,s86,Completes a generic type's instance (its underlying type, made lazily) while building.R7,i80,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,with-ctxm10,R2,L1,V2,R18,R14,R0,s129,Calls f with the package's build context ctx bound (and the checker's method data, the\n  instances' completion and methods: GR6).R7,i85,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,*fn*m10,R15,TR7,i93,R8,i1,R9,s18,arbace/go/build.aeR0,s362,The function being built: {:slots (volatile counts per kind) :locs (an IdentityHashMap of\n  variables to [:slot k n] or [:cell c]) :code (the next jump code) :defer (volatile) :targets\n  (the breakable statements, innermost last) :labels (a HashMap of label names to codes)\n  :results :calls (the calls of several results, by identity: their temporaries) :name}.v15,arbace.go.build9,compiled?m10,R10,TR2,L1,V1,R19,R7,i100,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,int-kwsS15,R20,R21,R22,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,m8,R10,TR7,i104,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,kindm10,R2,L1,V1,R35,R0,s79,The slot kind of a value of checker type ty: :I (integers, bool), :F, :S or :R.R7,i107,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,int-sfxm26,R30,s2,I8R21,s3,I16R20,s3,I32R23,s3,I64R22,s1,IR34,s2,U8R28,s3,U16R31,s3,U32R25,s3,U64R24,s1,UR26,s2,UPR32,s1,IR27,s3,I32m8,R10,TR7,i119,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,basic-ofm10,R10,TR2,L1,V1,R35,R7,i123,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,unsigned?m10,R10,TR2,L1,V1,R35,R7,i124,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,wide?m10,R10,TR2,L1,V1,R35,R7,i125,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build16,struct-or-array?m10,R10,TR2,L1,V1,R35,R7,i126,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build6,iface?m10,R10,TR2,L1,V1,R35,R7,i127,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,descm8,R36,TR7,i129,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,inst-type?m10,R10,TR2,L1,V1,R35,R7,i131,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build18,interpreted-named?m12,R10,TR2,L1,V1,R35,R0,s163,Whether named type ty is interpreted: of an interpreted package, or a generic type's instance\n  (a compiled package's too: gc compiled none of them for goi, §9.3).R7,i133,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,recursive?m12,R10,TR2,L1,V1,R17,R0,s141,Whether named type nt is reachable from its own underlying type (so that reflect cannot make\n  its RT: its pointers are erased in Go memory).R7,i139,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,tag-textm10,R10,TR2,L1,V1,R37,R7,i163,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,struct-partsm12,R10,TR2,L1,V1,R38,R0,s130,The parts of struct type u for the factories: names, field descriptors, tags, package paths\n  of unexported names, embedded flags.R7,i165,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,method-keym10,R2,L1,V2,R39,R40,R0,s74,A method's key in method sets (§5.3): its name, path.name when unexported.R7,i175,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build18,set-iface-methods!m12,R10,TR2,L1,V2,R41,R35,R0,s87,Gives interface descriptor d of type ty its methods (keys and signatures' descriptors).R7,i180,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,local-gen-ofm10,R10,TR2,L1,V1,R35,R7,i188,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,inst-genm8,R36,TR7,i192,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build14,inst-type-namem8,R36,TR7,i192,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,named-descm10,R10,TR2,L1,V1,R35,R7,i194,R8,i1,R9,s18,arbace/go/build.aem10,R2,L1,V1,R35,R0,s75,The descriptor (a *goi.Type) of checker type ty, one per type in the build.R7,i238,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,int-bitsm12,R10,TR2,L1,V1,R42,R0,s57,Integer constant v as the int64 of its normalized I slot.R7,i274,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build14,go-string-nodem12,R10,TR2,L1,V1,Myn1,vm2,R3,R4,R0,s69,A string constant node of value v (the checker's: one char per byte).R7,i279,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build13,complex-valuem10,R10,TR2,L1,V2,R35,R42,R7,i286,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,const-nodem10,R2,L1,V3,R35,R42,R43,R0,s66,[kind node] of constant value v of type ty (want :B: a condition).R7,i293,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,new-slot!m10,R10,TR2,L1,V1,R44,R7,i308,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,next-code!m10,R10,TR2,L1,V0,R7,i314,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,label-code!m12,R10,TR2,L1,V1,R39,R0,s50,The goto code of label nm (assigned on first use).R7,i317,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,label-entrym10,R10,TR2,L1,V1,R39,R7,i324,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,cell-var?m10,R2,L1,V1,R45,R0,s53,Whether variable x lives in Go memory (a cell, §4.3).R7,i328,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build3,locm10,R10,TR2,L1,V1,R45,R7,i333,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,new-loc!m12,R10,TR2,L1,V1,R45,R0,s76,A location for a new variable x: a slot of its kind, or a C slot for a cell.R7,i337,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,temp!m10,R10,TR2,L1,V1,R44,R7,i344,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,local-nodem10,R10,TR2,L1,V2,R44,R46,R7,i348,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,as-kindm10,R2,L1,V2,V2,R44,R47,R43,R0,s54,Node [k n] as kind want (:B from an :I bool and back).R7,i350,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build6,load-pm12,R10,TR2,L1,V2,R48,R35,R0,s55,The value of type ty at place p, as a node of its kind.R7,i359,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,store-pm12,R10,TR2,L1,V3,R48,R49,R35,R0,s57,The statement storing node [k n] (of type ty) at place p.R7,i370,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,set-slotm10,R10,TR2,L1,V3,R44,R46,R47,R7,i382,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,expr-stmt-ofm10,R10,TR2,L1,V1,V2,R44,R47,R7,i385,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build2,exm8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,ex-asm8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,placem8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,lit-placem8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,lit-nodem8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,call-nodem8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,call-resultsm8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,build-fn-litm8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,builtinm8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,expr-or-stmtm8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,stmtm8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,stmt-listm8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,rhs-nodesm8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build17,method-value-nodem8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build23,iface-method-value-nodem8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build16,method-expr-nodem8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,assert-knm8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,elem-typem8,R36,TR7,i388,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build3,exkm8,R2,L1,V2,R47,R44,R7,i391,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build15,ensure-methods!m8,R36,TR7,i395,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build13,iface-contentm12,R10,TR2,L1,V2,V2,R44,R47,R35,R0,s143,Node [k n] of type ty as an interface's content (an R node): its method set given first, so\nthat a type with methods goes in as a proxy (§5.3).R7,i397,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,arith-namem10,R10,TR2,L1,V1,R50,R7,i414,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,cmp-namem12,s2,==s2,Eqs2,!=s2,Nes1,<s2,Lts2,<=s2,Les1,>s2,Gts2,>=s2,Gem8,R10,TR7,i418,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,const-ofm12,R10,TR2,L1,V1,R47,R0,s69,The constant value of node n when it is one (an operand's), else nil.R7,i420,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build13,local-slot-ofm12,R10,TR2,L1,V1,R47,R0,s71,The I slot of node n when it reads a local held in an I slot, else nil.R7,i425,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,int-binopm10,R2,L1,V4,R50,R35,R51,R52,R0,s72,x op y on integer type ty (nodes of the operands' checked trees xn, yn).R7,i433,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,float-binopm10,R10,TR2,L1,V4,R50,R35,R45,R53,R7,i447,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,binop-nodesm10,R2,L1,V5,R50,R35,R54,R55,R56,R0,s85,[k node] of arithmetic x op y of type ty on built operand nodes (for op= statements).R7,i451,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,count-nodem12,R10,TR2,L1,V1,R52,R0,s81,A shift count's node: an I (a constant count of any numeric kind as its integer).R7,i464,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,shift-nodem10,R10,TR2,L1,V4,R50,R35,R51,R52,R7,i474,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,nil-node?m10,R10,TR2,L1,V1,R47,R7,i479,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build13,compare-nodesm10,R2,L1,V3,R50,R51,R52,R0,s35,[:B node] of x op y (a comparison).R7,i481,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,binary-nodem10,R10,TR2,L1,V1,R47,R7,i521,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,unary-nodem10,R10,TR2,L1,V1,R47,R7,i539,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,bytes-type?m10,R10,TR2,L1,V1,R35,R7,i552,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,runes-type?m10,R10,TR2,L1,V1,R35,R7,i553,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,conv-nodem10,R2,L1,V1,R47,R0,s49,[k node] of conversion T(x) (a non-constant one).R7,i555,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,addressable?m10,R10,TR2,L1,V1,R47,R7,i596,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,struct-ofm12,R10,TR2,L1,V1,R35,R0,s66,The struct type and its descriptor a field selection's step is on.R7,i599,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,value-placem12,R10,TR2,L1,V1,R47,R0,s112,A place holding the value of node n (of struct or array type): its own when addressable, else\n  its value's box.R7,i604,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,field-placem10,R2,L1,V1,R47,R0,s63,The place of field selection n ({:op :field :path :derefs :x}).R7,i612,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,index-placem12,R10,TR2,L1,V1,R47,R0,s78,The place of element (aget x i) of an array, a pointer to an array or a slice.R7,i631,R8,i1,R9,s18,arbace/go/build.aem10,R2,L1,V1,R47,R0,s43,The place (a P node) of addressable node n.R7,i644,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,elem-nodem12,R10,TR2,L1,V2,R42,R35,R0,s77,An element value node of type ty, as the factories take it (its kind's node).R7,i664,R8,i1,R9,s18,arbace/go/build.aem10,R2,L1,V1,R47,R0,s56,A struct or array literal as a new variable (its place).R7,i669,R8,i1,R9,s18,arbace/go/build.ae")

var Lit_568 *jrt.String = jrt.Intern("arbace.go.build$eval367000004$loading__1927001464__auto____367000005")

var Lit_569 *jrt.String = jrt.Intern("arbace.go.build$eval367000008$fn__367000009")

var Lit_570 *jrt.String = jrt.Intern("arbace.go.build$op")

var Lit_571 *jrt.String = jrt.Intern("arbace.go.build$oa")

var Lit_572 *jrt.String = jrt.Intern("arbace.go.build$unsupported_BANG_")

var Lit_573 *jrt.String = jrt.Intern("arbace.go.build$lazily")

var Lit_574 *jrt.String = jrt.Intern("arbace.go.build$method_data")

var Lit_575 *jrt.String = jrt.Intern("arbace.go.build$complete_instance_BANG_")

var Lit_576 *jrt.String = jrt.Intern("arbace.go.build$with_ctx")

var Lit_577 *jrt.String = jrt.Intern("arbace.go.build$compiled_QMARK_")

var Lit_578 *jrt.String = jrt.Intern("arbace.go.build$kind")

var Lit_579 *jrt.String = jrt.Intern("arbace.go.build$basic_of")

var Lit_580 *jrt.String = jrt.Intern("arbace.go.build$unsigned_QMARK_")

var Lit_581 *jrt.String = jrt.Intern("arbace.go.build$wide_QMARK_")

var Lit_582 *jrt.String = jrt.Intern("arbace.go.build$struct_or_array_QMARK_")

var Lit_583 *jrt.String = jrt.Intern("arbace.go.build$iface_QMARK_")

var Lit_584 *jrt.String = jrt.Intern("arbace.go.build$inst_type_QMARK_")

var Lit_585 *jrt.String = jrt.Intern("arbace.go.build$interpreted_named_QMARK_")

var Lit_586 *jrt.String = jrt.Intern("arbace.go.build$recursive_QMARK_")

var Lit_587 *jrt.String = jrt.Intern("arbace.go.build$tag_text")

var Lit_588 *jrt.String = jrt.Intern("arbace.go.build$struct_parts")

var Lit_589 *jrt.String = jrt.Intern("arbace.go.build$method_key")

var Lit_590 *jrt.String = jrt.Intern("arbace.go.build$set_iface_methods_BANG_")

var Lit_591 *jrt.String = jrt.Intern("arbace.go.build$local_gen_of")

var Lit_592 *jrt.String = jrt.Intern("arbace.go.build$named_desc")

var Lit_593 *jrt.String = jrt.Intern("arbace.go.build$desc")

var Lit_594 *jrt.String = jrt.Intern("arbace.go.build$int_bits")

var Lit_595 *jrt.String = jrt.Intern("arbace.go.build$go_string_node")

var Lit_596 *jrt.String = jrt.Intern("arbace.go.build$complex_value")

var Lit_597 *jrt.String = jrt.Intern("arbace.go.build$const_node")

var Lit_598 *jrt.String = jrt.Intern("arbace.go.build$new_slot_BANG_")

var Lit_599 *jrt.String = jrt.Intern("arbace.go.build$next_code_BANG_")

var Lit_600 *jrt.String = jrt.Intern("arbace.go.build$label_code_BANG_")

var Lit_601 *jrt.String = jrt.Intern("arbace.go.build$label_entry")

var Lit_602 *jrt.String = jrt.Intern("arbace.go.build$cell_var_QMARK_")

var Lit_603 *jrt.String = jrt.Intern("arbace.go.build$loc")

var Lit_604 *jrt.String = jrt.Intern("arbace.go.build$new_loc_BANG_")

var Lit_605 *jrt.String = jrt.Intern("arbace.go.build$temp_BANG_")

var Lit_606 *jrt.String = jrt.Intern("arbace.go.build$local_node")

var Lit_607 *jrt.String = jrt.Intern("arbace.go.build$as_kind")

var Lit_608 *jrt.String = jrt.Intern("arbace.go.build$load_p")

var Lit_609 *jrt.String = jrt.Intern("arbace.go.build$store_p")

var Lit_610 *jrt.String = jrt.Intern("arbace.go.build$set_slot")

var Lit_611 *jrt.String = jrt.Intern("arbace.go.build$expr_stmt_of")

var Lit_612 *jrt.String = jrt.Intern("arbace.go.build$exk")

var Lit_613 *jrt.String = jrt.Intern("arbace.go.build$iface_content")

var Lit_614 *jrt.String = jrt.Intern("arbace.go.build$arith_name")

var Lit_615 *jrt.String = jrt.Intern("arbace.go.build$const_of")

var Lit_616 *jrt.String = jrt.Intern("arbace.go.build$local_slot_of")

var Lit_617 *jrt.String = jrt.Intern("arbace.go.build$int_binop")

var Lit_618 *jrt.String = jrt.Intern("arbace.go.build$float_binop")

var Lit_619 *jrt.String = jrt.Intern("arbace.go.build$binop_nodes")

var Lit_620 *jrt.String = jrt.Intern("arbace.go.build$count_node")

var Lit_621 *jrt.String = jrt.Intern("arbace.go.build$shift_node")

var Lit_622 *jrt.String = jrt.Intern("arbace.go.build$nil_node_QMARK_")

var Lit_623 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes")

var Lit_624 *jrt.String = jrt.Intern("arbace.go.build$binary_node")

var Lit_625 *jrt.String = jrt.Intern("arbace.go.build$unary_node")

var Lit_626 *jrt.String = jrt.Intern("arbace.go.build$bytes_type_QMARK_")

var Lit_627 *jrt.String = jrt.Intern("arbace.go.build$runes_type_QMARK_")

var Lit_628 *jrt.String = jrt.Intern("arbace.go.build$conv_node")

var Lit_629 *jrt.String = jrt.Intern("arbace.go.build$addressable_QMARK_")

var Lit_630 *jrt.String = jrt.Intern("arbace.go.build$struct_of")

var Lit_631 *jrt.String = jrt.Intern("arbace.go.build$value_place")

var Lit_632 *jrt.String = jrt.Intern("arbace.go.build$field_place")

var Lit_633 *jrt.String = jrt.Intern("arbace.go.build$index_place")

var Lit_634 *jrt.String = jrt.Intern("arbace.go.build$place")

var Lit_635 *jrt.String = jrt.Intern("arbace.go.build$elem_node")

var Lit_636 *jrt.String = jrt.Intern("arbace.go.build$lit_place")

var Lit_637 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn1,nkn4,linekn6,columnkn4,fileyn1,xkn8,declaredkn3,docyn4,wantyn1,kyn3,sigyn1,_yn2,psyn2,rsyn8,variadicyn4,recvyn1,syn4,nodeyn2,tykn7,dynamicyn2,knyn4,argsyn3,cmpyn4,cellyn7,settersyn7,resultsyn4,modeyn6,calleeyn4,pathyn2,nmyn5,nodesyn5,tempsyn1,myn2,rtyn6,mtargsyn5,fpathyn3,selyn1,ryn6,paramsyn1,Dyn1,dyn1,Tyn2,xryn2,styn1,pyn3,knsyn3,tysyn1,cyn1,tyn1,fyn4,predyn1,byn5,stmtsyn4,objsyn4,new?m10,R0,TR1,L1,V1,R2,R3,i697,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build8,var-nodem10,R0,TR1,L1,V1,R6,R3,i712,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,global-nodem10,R0,TR1,L1,V1,R2,R3,i718,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build13,instance-cellm8,R7,TR3,i721,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build6,isubstm8,R7,TR3,i721,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build15,func-value-nodem12,R0,TR1,L1,V1,R2,R8,s120,The value of function node n: a generic function's instance (§9.2), a compiled member, an\n  interpreted function's cell.R3,i723,R4,i1,R5,s18,arbace/go/build.aem10,R1,L2,V1,R2,V2,R2,R9,R8,s85,[kind node] of expression node n (want: the type a nil takes, or :B for a condition).R3,i733,R4,i1,R5,s18,arbace/go/build.aem8,R1,L1,V2,R2,R10,R3,i795,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,slot-layoutm12,R0,TR1,L2,V1,R11,V2,V4,R12,R13,R14,R15,R16,R8,s280,The callee's slots of a signature [:func ps rs variadic]: the parameters', then the results',\n  numbered per kind in order (the variadic parameter an R); a method's receiver (of type recv)\n  after them (GR4), so that the arguments' slots are the signature's whatever the receiver.R3,i799,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,arg-setterm10,R0,TR1,L1,V2,V2,R10,R17,R18,R3,i812,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,error-type?m8,R7,TR3,i815,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build15,compiled-iface?m8,R7,TR3,i815,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build14,mem-converted?m12,R0,TR1,L1,V1,R19,R8,s163,Whether a value of type ty differs in Go memory from a frame: a function (a closure as a Go\n  func), a compiled non-empty interface (a proxy as its wrapper, §5.3).R3,i817,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,*raw-any*m12,R20,TR0,TR3,i825,R4,i1,R5,s18,arbace/go/build.aeR8,s167,Whether the compiled callee being built looks at representations (runtime's and reflect's\n  functions): its empty interface arguments are given a proxy's value itself.v15,arbace.go.build12,raw-packagesS2,s7,runtimes7,reflectm8,R0,TR3,i830,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build8,mem-nodem12,R0,TR1,L1,V2,R21,R19,R8,s188,Node [k n] of type ty as compiled Go takes it (a closure as a Go func, a proxy as its wrapper:\n  MemR; for runtime's and reflect's functions an empty interface's proxy as its value: RawR).R3,i832,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,arg-nodesm12,R0,TR1,L1,V3,R11,R22,R23,R8,s196,The argument nodes of a call to signature sig: fixed parameters', then the variadic slice's\n  (made from the trailing arguments, or the spread one); for compiled code (cmp) closures as Go\n  funcs.R3,i842,R4,i1,R5,s18,arbace/go/build.aem12,R0,TR1,L1,V1,R2,R8,s71,The call of several results n, built once: {:t T :temps [[k slot]...]}.R3,i860,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build6,sig-ofm10,R0,TR1,L1,V1,R19,R3,i869,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,cell-callm12,R0,TR1,L1,V4,R24,R25,R26,R27,R8,s127,A call of function cell cell with setters, the callee's results in slots results: [k node] of\n  one result, else {:t T :temps}.R3,i871,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,static-callm10,R0,TR1,L1,V4,R24,R11,R22,R27,R3,i883,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,value-callm10,R0,TR1,L1,V4,R28,R11,R22,R27,R3,i889,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build8,from-memm10,R0,TR1,L1,V2,V2,R10,R2,R19,R3,i903,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build18,compiled-call-nodem12,R0,TR1,L1,V6,R29,R30,R11,R31,R27,R32,R8,s162,A compiled call of listed member path.nm of signature sig on argument nodes (a method's\n  receiver first): [k node], or {:t :temps} writing temps (made when nil).R3,i908,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build13,compiled-callm10,R0,TR1,L1,V6,R29,R30,R11,R22,R16,R27,R3,i918,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build12,recv-type-ofm12,R0,TR1,L1,V1,R33,R8,s78,The receiver type of method object m: its base named type, or a pointer to it.R3,i924,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,method-cellm12,R0,TR1,L1,V1,R33,R8,s45,The *goi.Func of interpreted method object m.R3,i932,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build15,generic-method?m10,R1,L1,V1,R33,R8,s87,Whether method object m is a generic type's or has type parameters of its own (go1.27).R3,i937,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build13,method-targetm12,R0,TR1,L1,V3,R33,R34,R35,R8,s226,[cell receiver-type] of interpreted method m selected on named type rt (a generic type's\n  instance, for its methods; nil: m's own type) with a generic method's own type arguments\n  mtargs: an instance's cell (§9.2), else m's.R3,i942,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build15,method-callablem10,R1,L1,V3,R33,R24,R30,R8,s129,The Callable of interpreted method object m (its cell) as Arbace calls it, the receiver\n  first: the var T.M's (§2.1, §7.1; GR5).R3,i954,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,path-derefsm12,R0,TR1,L1,V2,R19,R29,R8,s87,The implicit dereferences of a field selection along path from type ty (the checker's).R3,i964,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,field-selm12,R0,TR1,L1,V2,R6,R36,R8,s70,The selection of the embedded fields fpath from node x: a :field node.R3,i978,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,recv-nodem10,R1,L1,V1,R37,R8,s231,The receiver of method selection sel ({:op :method :recv :path :recv-adjust}) as the method\n  takes it: the embedded fields of its path selected, then its address or the value it points\n  to as the method's receiver asks: [k node].R3,i990,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build18,interp-method-callm12,R0,TR1,L1,V3,R28,R22,R27,R8,s127,A call of interpreted method selection callee: its cell, the receiver laid after the\n  arguments (evaluated first, as Go does).R3,i1012,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,method-callm10,R0,TR1,L1,V3,R28,R22,R27,R3,i1025,R4,i1,R5,s18,arbace/go/build.aem10,R0,TR1,L1,V1,R19,R3,i1038,R4,i1,R5,s18,arbace/go/build.aem10,R0,TR1,L1,V1,R19,R3,i1040,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build15,iface-recv-nodem12,R0,TR1,L1,V1,R28,R8,s109,The interface content an interface method selection is called on (its embedded fields\n  selected): an R node.R3,i1042,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,iface-callm12,R0,TR1,L1,V3,R28,R22,R27,R8,s317,A call of interface method selection callee (§5.3): the content evaluated into a temporary,\n  then a proxy's interpreted method (its type's method set, an inline cache), else the compiled\n  value's method (the static compiled interface's method expression, error's Error, or the\n  table's method of the dynamic type).R3,i1049,R4,i1,R5,s18,arbace/go/build.aem12,R0,TR1,L1,V1,R2,R8,s82,x.M of a concrete type (a method value): the receiver evaluated now, bound (§4.6).R3,i1084,R4,i1,R5,s18,arbace/go/build.aem12,R0,TR1,L1,V1,R2,R8,s78,x.M of an interface (a method value): the content's method bound to it (§4.6).R3,i1102,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,build-codem8,R7,TR3,i1112,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,local-objm10,R0,TR1,L1,V2,R30,R19,R3,i1114,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,local-refm10,R0,TR1,L1,V1,R6,R3,i1116,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,selectionm12,R0,TR1,L1,V2,R6,R38,R8,s125,The checker's selection node of lookup result r ({:kind :method|:iface-method ...}) on node x\n  (code_call.ae's select-expr).R3,i1118,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,thunk-bodym12,R0,TR1,L1,V3,R37,R39,R11,R8,s84,The body of a thunk calling selection sel with parameters params (of signature sig).R3,i1134,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build18,build-method-thunkm12,R0,TR1,L1,V4,R40,R38,R11,R30,R8,s198,The code of the method set entry of type D for lookup result r (signature sig): a method of\n  receiver D (laid last) calling the method through the embedded fields and pointers of its\n  path (§5.3).R3,i1147,R4,i1,R5,s18,arbace/go/build.aem12,R0,TR1,L1,V1,R2,R8,s76,T.M (a method expression): a function of the receiver first, a thunk (§4.6).R3,i1165,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build17,method-candidatesm12,R0,TR1,L1,V1,R19,R8,s156,[name pkg] of the methods that may be in type ty's method set: its named types' declared\n  methods, its embedded fields' and embedded interfaces', in order.R3,i1188,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build17,may-have-methods?m12,R0,TR1,L1,V1,R19,R8,s140,Whether type ty (concrete) may have an interpreted method set: an interpreted named type, a\n  pointer to one, a struct with embedded fields.R3,i1209,R4,i1,R5,s18,arbace/go/build.aem10,R1,L1,V2,R19,R41,R8,s173,Gives the descriptor d of concrete type ty its method set (once per build context, §5.3):\n  each method of ty's method set the method itself (its receiver is ty) or a thunk.R3,i1218,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build7,rt-namem8,R7,TR3,i1265,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,iface-namem12,R0,TR1,L1,V1,R19,R8,s85,The name gc's runtime gives static interface type ty in a failed assertion's message.R3,i1267,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,assert-descm10,R0,TR1,L1,V1,R42,R3,i1275,R4,i1,R5,s18,arbace/go/build.aem12,R0,TR1,L1,V3,R43,R42,R44,R8,s78,[k node] of content node xr asserted to type T (the static interface type st).R3,i1280,R4,i1,R5,s18,arbace/go/build.aem10,R1,L2,V1,R2,V2,R2,R27,R8,s79,[kind node] of a call of one result (mode :multi, or no result: {:t T :temps}).R3,i1291,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,call-stmtm12,R0,TR1,L1,V1,R2,R8,s51,The statement of call n as an expression statement.R3,i1314,R4,i1,R5,s18,arbace/go/build.aem10,R0,TR1,L1,V1,R19,R3,i1326,R4,i1,R5,s18,arbace/go/build.aem10,R1,L1,V2,R2,R27,R8,s81,A builtin's call: [k node], {:t ...} for mode :multi, a statement for mode :stmt.R3,i1328,R4,i1,R5,s18,arbace/go/build.aem10,R0,TR1,L1,V2,R27,R17,R3,i1413,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build13,slot-of-placem12,R0,TR1,L1,V1,R45,R8,s58,[k slot] when place p is a local held in a slot, else nil.R3,i1417,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,assign-tom10,R1,L1,V2,R45,R21,R8,s95,The statement assigning [k node] (of the place's type) to place p (:blank: evaluated, dropped).R3,i1424,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build8,temps-ofm12,R0,TR1,L1,V1,R46,R8,s81,Statements evaluating nodes kns into new temporaries, and the temporaries' nodes.R3,i1436,R4,i1,R5,s18,arbace/go/build.aem10,R1,L1,V2,R31,R47,R8,s138,The [k node]s of the right-hand values of an assignment or declaration (comma-ok forms as\n  two), for targets of types tys (a nil's type).R3,i1443,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build13,prepare-placem12,R0,TR1,L1,V1,R45,R8,s183,[statements place]: the operands of place p evaluated into temporaries now (an assignment's\n  first phase, §4.5: Go evaluates the places' index and pointer operands, then the values).R3,i1478,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,assign-stmtm8,R1,L1,V1,R2,R3,i1515,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build14,op-assign-stmtm8,R1,L1,V1,R2,R3,i1524,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build6,one-ofm10,R0,TR1,L1,V1,R19,R3,i1554,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,incdec-stmtm8,R1,L1,V1,R2,R3,i1560,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,zero-initm10,R0,TR1,L1,V1,R6,R3,i1567,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build8,init-varm12,R0,TR1,L1,V2,R6,R21,R8,s63,The statement giving new variable x its initial value [k node].R3,i1578,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,decl-stmtm10,R1,L1,V1,R41,R8,s83,A declaration {:op :decl :objs :init}: new variables (a reused one of := assigned).R3,i1587,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build4,jumpm10,R0,TR1,L1,V1,R48,R3,i1609,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,push-targetm10,R0,TR1,L1,V2,R49,R50,R3,i1611,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,innermostm10,R0,TR1,L1,V1,R51,R3,i1613,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,block-stmtsm10,R0,TR1,L1,V1,R2,R3,i1615,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,stmt-linem12,R0,TR1,L1,V1,R17,R8,s31,A statement's line (S51), or 0.R3,i1617,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build13,quiet-header?m8,R7,TR3,i1632,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build12,quiet-basic?m10,R0,TR1,L1,V1,R19,R3,i1634,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build12,quiet-const?m10,R0,TR1,L1,V1,R2,R3,i1636,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build14,quiet-builtinsS8,s3,mins3,maxs3,news4,imags4,reals3,lens3,caps7,complexm8,R0,TR3,i1638,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build15,quiet-cmp-type?m10,R0,TR1,L1,V1,R19,R3,i1640,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,quiet-expr?m12,R0,TR1,L1,V1,R2,R8,s90,Whether checked expression n can neither panic nor call (conservative: unknown kinds can).R3,i1644,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build12,quiet-place?m12,R0,TR1,L1,V1,R45,R8,s56,Whether assigning to place p can neither panic nor call.R3,i1688,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build19,quiet-block-header?m10,R0,TR1,L1,V1,R52,R3,i1701,R4,i1,R5,s18,arbace/go/build.aem12,R0,TR1,L1,V1,R2,R8,s137,Whether statement n's own part (its nested statement lists left out: they store their own\n  lines) can neither panic nor call (GC26 (b)).R3,i1706,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build12,hoisted-linem12,R0,TR1,L1,V1,R2,R8,s334,A loop's hoisted line (GR5.1): a for or range statement whose own part is quiet and whose\n  body is one statement without statement lists of its own that can panic or call stores that\n  statement's line once, before the loop, rather than at each iteration (the frame's line is\n  then the same at every point that can raise); else nil.R3,i1745,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,stored-linem12,R0,TR1,L1,V1,R17,R8,s140,The line statement s stores in the frame before it runs (0: none, it can neither panic nor\n  call; GC26 (b)); a loop's hoisted line (GR5.1).R3,i1760,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,loop-bodym12,R0,TR1,L1,V1,R2,R8,s130,A for or range statement's body: a statement list storing its lines, or a hoisted line's\n  one statement without its line (GR5.1).R3,i1769,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,body-nodem12,R0,TR1,L1,V1,R53,R8,s165,A statement list's node (a SeqL with its labels' goto codes and the lines its statements that\n  can panic or call store in the frame, for traces: §10.6, GR5, GR5.1).R3,i1777,R4,i1,R5,s18,arbace/go/build.aem8,R1,L1,V1,R53,R3,i1788,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,block-nodem12,R0,TR1,L1,V1,R2,R8,s62,A block's node: its declarations (a let's) and its statements.R3,i1790,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build11,loop-targetm10,R0,TR1,L1,V1,R2,R3,i1799,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build19,per-iteration-cellsm10,R0,TR1,L1,V1,R54,R3,i1806,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build8,for-stmtm10,R0,TR1,L1,V1,R2,R3,i1811,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build13,range-targetsm12,R0,TR1,L1,V1,R2,R8,s99,The key and value targets of a range: [obj-or-place-or-nil ...] and whether they are new variables.R3,i1821,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,idx-setterm10,R0,TR1,L1,V3,R49,R55,R19,R3,i1828,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,at-setterm10,R0,TR1,L1,V3,R49,R55,R19,R3,i1839,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build10,any-setterm10,R0,TR1,L1,V3,R49,R55,R19,R3,i1850,R4,i1,R5,s18,arbace/go/build.aev15,arbace.go.build9,has-call?m12,R0,TR1,L1,V1,R2,R8,s157,Whether checked node n has a call (not of a constant) or a receive in it (an array's length is\n  then not constant: the specification's len and range rules).R3,i1861,R4,i1,R5,s18,arbace/go/build.ae")

var Lit_638 *jrt.String = jrt.Intern("arbace.go.build$lit_node")

var Lit_639 *jrt.String = jrt.Intern("arbace.go.build$var_node")

var Lit_640 *jrt.String = jrt.Intern("arbace.go.build$global_node")

var Lit_641 *jrt.String = jrt.Intern("arbace.go.build$func_value_node")

var Lit_642 *jrt.String = jrt.Intern("arbace.go.build$ex")

var Lit_643 *jrt.String = jrt.Intern("arbace.go.build$ex_as")

var Lit_644 *jrt.String = jrt.Intern("arbace.go.build$slot_layout")

var Lit_645 *jrt.String = jrt.Intern("arbace.go.build$arg_setter")

var Lit_646 *jrt.String = jrt.Intern("arbace.go.build$mem_converted_QMARK_")

var Lit_647 *jrt.String = jrt.Intern("arbace.go.build$mem_node")

var Lit_648 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes")

var Lit_649 *jrt.String = jrt.Intern("arbace.go.build$call_results")

var Lit_650 *jrt.String = jrt.Intern("arbace.go.build$sig_of")

var Lit_651 *jrt.String = jrt.Intern("arbace.go.build$cell_call")

var Lit_652 *jrt.String = jrt.Intern("arbace.go.build$static_call")

var Lit_653 *jrt.String = jrt.Intern("arbace.go.build$value_call")

var Lit_654 *jrt.String = jrt.Intern("arbace.go.build$from_mem")

var Lit_655 *jrt.String = jrt.Intern("arbace.go.build$compiled_call_node")

var Lit_656 *jrt.String = jrt.Intern("arbace.go.build$compiled_call")

var Lit_657 *jrt.String = jrt.Intern("arbace.go.build$recv_type_of")

var Lit_658 *jrt.String = jrt.Intern("arbace.go.build$method_cell")

var Lit_659 *jrt.String = jrt.Intern("arbace.go.build$generic_method_QMARK_")

var Lit_660 *jrt.String = jrt.Intern("arbace.go.build$method_target")

var Lit_661 *jrt.String = jrt.Intern("arbace.go.build$method_callable")

var Lit_662 *jrt.String = jrt.Intern("arbace.go.build$path_derefs")

var Lit_663 *jrt.String = jrt.Intern("arbace.go.build$field_sel")

var Lit_664 *jrt.String = jrt.Intern("arbace.go.build$recv_node")

var Lit_665 *jrt.String = jrt.Intern("arbace.go.build$interp_method_call")

var Lit_666 *jrt.String = jrt.Intern("arbace.go.build$method_call")

var Lit_667 *jrt.String = jrt.Intern("arbace.go.build$error_type_QMARK_")

var Lit_668 *jrt.String = jrt.Intern("arbace.go.build$compiled_iface_QMARK_")

var Lit_669 *jrt.String = jrt.Intern("arbace.go.build$iface_recv_node")

var Lit_670 *jrt.String = jrt.Intern("arbace.go.build$iface_call")

var Lit_671 *jrt.String = jrt.Intern("arbace.go.build$method_value_node")

var Lit_672 *jrt.String = jrt.Intern("arbace.go.build$iface_method_value_node")

var Lit_673 *jrt.String = jrt.Intern("arbace.go.build$local_obj")

var Lit_674 *jrt.String = jrt.Intern("arbace.go.build$local_ref")

var Lit_675 *jrt.String = jrt.Intern("arbace.go.build$selection")

var Lit_676 *jrt.String = jrt.Intern("arbace.go.build$thunk_body")

var Lit_677 *jrt.String = jrt.Intern("arbace.go.build$build_method_thunk")

var Lit_678 *jrt.String = jrt.Intern("arbace.go.build$method_expr_node")

var Lit_679 *jrt.String = jrt.Intern("arbace.go.build$method_candidates")

var Lit_680 *jrt.String = jrt.Intern("arbace.go.build$may_have_methods_QMARK_")

var Lit_681 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_")

var Lit_682 *jrt.String = jrt.Intern("arbace.go.build$iface_name")

var Lit_683 *jrt.String = jrt.Intern("arbace.go.build$assert_desc")

var Lit_684 *jrt.String = jrt.Intern("arbace.go.build$assert_kn")

var Lit_685 *jrt.String = jrt.Intern("arbace.go.build$call_node")

var Lit_686 *jrt.String = jrt.Intern("arbace.go.build$call_stmt")

var Lit_687 *jrt.String = jrt.Intern("arbace.go.build$elem_type")

var Lit_688 *jrt.String = jrt.Intern("arbace.go.build$builtin")

var Lit_689 *jrt.String = jrt.Intern("arbace.go.build$expr_or_stmt")

var Lit_690 *jrt.String = jrt.Intern("arbace.go.build$slot_of_place")

var Lit_691 *jrt.String = jrt.Intern("arbace.go.build$assign_to")

var Lit_692 *jrt.String = jrt.Intern("arbace.go.build$temps_of")

var Lit_693 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes")

var Lit_694 *jrt.String = jrt.Intern("arbace.go.build$prepare_place")

var Lit_695 *jrt.String = jrt.Intern("arbace.go.build$assign_stmt")

var Lit_696 *jrt.String = jrt.Intern("arbace.go.build$op_assign_stmt")

var Lit_697 *jrt.String = jrt.Intern("arbace.go.build$one_of")

var Lit_698 *jrt.String = jrt.Intern("arbace.go.build$incdec_stmt")

var Lit_699 *jrt.String = jrt.Intern("arbace.go.build$zero_init")

var Lit_700 *jrt.String = jrt.Intern("arbace.go.build$init_var")

var Lit_701 *jrt.String = jrt.Intern("arbace.go.build$decl_stmt")

var Lit_702 *jrt.String = jrt.Intern("arbace.go.build$jump")

var Lit_703 *jrt.String = jrt.Intern("arbace.go.build$push_target")

var Lit_704 *jrt.String = jrt.Intern("arbace.go.build$innermost")

var Lit_705 *jrt.String = jrt.Intern("arbace.go.build$block_stmts")

var Lit_706 *jrt.String = jrt.Intern("arbace.go.build$stmt_line")

var Lit_707 *jrt.String = jrt.Intern("arbace.go.build$quiet_basic_QMARK_")

var Lit_708 *jrt.String = jrt.Intern("arbace.go.build$quiet_const_QMARK_")

var Lit_709 *jrt.String = jrt.Intern("arbace.go.build$quiet_cmp_type_QMARK_")

var Lit_710 *jrt.String = jrt.Intern("arbace.go.build$quiet_expr_QMARK_")

var Lit_711 *jrt.String = jrt.Intern("arbace.go.build$quiet_place_QMARK_")

var Lit_712 *jrt.String = jrt.Intern("arbace.go.build$quiet_block_header_QMARK_")

var Lit_713 *jrt.String = jrt.Intern("arbace.go.build$quiet_header_QMARK_")

var Lit_714 *jrt.String = jrt.Intern("arbace.go.build$hoisted_line")

var Lit_715 *jrt.String = jrt.Intern("arbace.go.build$stored_line")

var Lit_716 *jrt.String = jrt.Intern("arbace.go.build$loop_body")

var Lit_717 *jrt.String = jrt.Intern("arbace.go.build$body_node")

var Lit_718 *jrt.String = jrt.Intern("arbace.go.build$stmt_list")

var Lit_719 *jrt.String = jrt.Intern("arbace.go.build$block_node")

var Lit_720 *jrt.String = jrt.Intern("arbace.go.build$loop_target")

var Lit_721 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells")

var Lit_722 *jrt.String = jrt.Intern("arbace.go.build$for_stmt")

var Lit_723 *jrt.String = jrt.Intern("arbace.go.build$range_targets")

var Lit_724 *jrt.String = jrt.Intern("arbace.go.build$idx_setter")

var Lit_725 *jrt.String = jrt.Intern("arbace.go.build$at_setter")

var Lit_726 *jrt.String = jrt.Intern("arbace.go.build$any_setter")

var Lit_727 *jrt.String = jrt.Intern("arbace.go.build$has_call_QMARK_")

var Lit_728 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn1,nkn3,dockn4,linekn6,columnkn4,fileyn4,callyn1,cyn4,bodyyn3,lityn4,treeyn5,fnameyn8,capturesyn5,initsyn2,tyyn1,mkn5,ifacekn5,gtypekn9,recv-typekn4,typekn8,tag-typekn3,sigkn2,tokn4,recvkn3,varkn3,objkn6,paramskn3,lhskn4,objskn6,methodkn4,refskn4,rmapkn9,inst-formks3,goi5,labelkn8,label-idkn7,tparamskn2,idkn10,underlyingkn4,formyn1,xkn8,declaredyn1,_yn2,psyn2,rsyn8,variadicyn5,targsyn2,nmv15,arbace.go.build16,range-elem-typesm12,R0,TR1,L1,V1,R2,R3,s65,The types of a range's iteration values: [key value] (nil: none).R4,i1872,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,range-stmtm10,R0,TR1,L1,V1,R2,R4,i1887,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,switch-stmtm10,R0,TR1,L1,V1,R2,R4,i1967,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,return-stmtm10,R0,TR1,L1,V1,R2,R4,i1993,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,deferred-callm12,R0,TR1,L1,V1,R7,R3,s189,The parts of a deferred or go statement's call n (SPEC.md §7.9, §8.1): its callee and\n  arguments evaluated now into a frame of their own, the call made later from it: [setters T\n  counts].R4,i2009,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,defer-stmtm10,R0,TR1,L1,V1,R2,R4,i2051,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build7,go-stmtm10,R0,TR1,L1,V1,R2,R4,i2056,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,send-stmtm10,R0,TR1,L1,V1,R2,R4,i2060,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build16,type-switch-stmtm10,R0,TR1,L1,V1,R2,R4,i2064,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,select-recvm12,R0,TR1,L1,V1,R8,R3,s230,A receive clause's communication c (an expression statement, a declaration or an\n  assignment of a receive): [the receive node, the statement binding its values (nil: none)]\n  with the receive replaced by the select's temporaries.R4,i2091,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,select-stmtm10,R0,TR1,L1,V1,R2,R4,i2115,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V1,R2,R3,s24,The node of statement n.R4,i2136,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,has-defer?m12,R0,TR1,L1,V1,R9,R3,s71,Whether a function's body defers (not counting its function literals').R4,i2178,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,free-localsm12,R0,TR1,L1,V1,R10,R3,s135,The local variables a function literal's body refers to that it does not declare: the cells\n  it captures, in order of first reference.R4,i2191,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V3,R11,R12,R13,R3,s243,The *goi.Code of a function node (:func, :fn, :body) with its signature sig; captures, the\n  cells it receives first (a literal's); a method's receiver (:recv, of type :recv-type or its\n  method object's) laid after the parameters and results.R4,i2221,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V1,R2,R3,s55,A function literal's closure node (its code built now).R4,i2273,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,build-funcm10,R1,L1,V1,R11,R3,s83,The code of a package-level function's checked tree (built on its first call, S18).R4,i2284,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,build-initsm10,R1,L1,V1,R14,R3,s160,The code of a package's initialization: its variables' initializers in initialization order\n  (trees {:op :var-init :lhs :rhs}), as a function of no parameters.R4,i2291,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V2,R15,R16,R3,s135,Type ty with the types of map m replaced: type parameters, and the local named types of a\n  generic declaration copied for an instance.R4,i2308,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,type-keysS7,R17,R18,R19,R20,R21,R22,R23,m8,R0,TR4,i2338,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,obj-keysS3,R24,R25,R26,m8,R0,TR4,i2339,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,objs-keysS3,R27,R28,R29,m8,R0,TR4,i2340,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,skip-keysS10,R30,R31,R32,R33,R34,R35,R36,R37,R38,R39,m8,R0,TR4,i2341,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,local-typesm12,R0,TR1,L1,V1,R11,R3,s56,The local named types a checked tree declares, in order.R4,i2343,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,resolve-onm12,R0,TR1,L1,V2,R2,R40,R3,s183,A method selection on a type parameter (an interface method of its constraint) resolved for\n  the instance's type T: the method T's method set has (§9.2): a method, or an interface's.R4,i2356,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,inst-treem10,R1,L1,V2,R11,R16,R3,s368,The checked tree of a generic declaration for the type arguments of map m (type parameter ->\n  type): every type substituted, its local variables and local named types copied with their\n  types, the method selections on its type parameters resolved, its constants represented at\n  their types (a float32's rounded), the sizes that depended on type parameters constant.R4,i2374,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,instancesm8,R3,s89,The instances of generic functions and methods (§9.2): [object descriptors] -> *goi.Func.R4,i2451,R5,i1,R6,s18,arbace/go/build.aem8,R3,s89,The instances of generic functions and methods (§9.2): [object descriptors] -> *goi.Func.R4,i2451,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,inst-gensm8,R0,TR4,i2454,R5,i1,R6,s18,arbace/go/build.aem8,R0,TR4,i2454,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build6,rt-sigm8,R41,TR4,i2456,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V1,R15,R3,s119,A type's name as gc's runtime writes it (in an instance's name, an assertion's message):\n  named types by package path.R4,i2458,R5,i1,R6,s18,arbace/go/build.aem12,R0,TR1,L1,V1,V4,R42,R43,R44,R45,R3,s63,A signature's text as gc's runtime writes it: (params) results.R4,i2492,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V1,R15,R3,s72,A generic type's instance's name, as gc's runtime names it: pkg.T[args].R4,i2501,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V1,R15,R3,s186,The generation of a generic type's instance: one per origin and type arguments' descriptors,\n  so that the instances' descriptors (interned by package, name and generation) are distinct.R4,i2507,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,instance-namem12,R0,TR1,L1,V1,R40,R3,s65,An instance's function name in traces, gc's: F[...], (*T[...]).M.R4,i2520,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build14,build-instancem12,R0,TR1,L1,V3,R40,R46,R47,R3,s116,The code of generic function or method x's instance for targs (its receiver's type arguments\n  first, then its own).R4,i2530,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V2,R40,R46,R3,s268,The *goi.Func of generic function or method x instantiated with targs: one per type-argument\n  list (by their descriptors, G7 (a): no body shared between lists), its code built by its\n  package's build context (:ctx-of) on its first call, or now when building eagerly.R4,i2544,R5,i1,R6,s18,arbace/go/build.ae")

var Lit_729 *jrt.String = jrt.Intern("arbace.go.build$range_elem_types")

var Lit_730 *jrt.String = jrt.Intern("arbace.go.build$range_stmt")

var Lit_731 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt")

var Lit_732 *jrt.String = jrt.Intern("arbace.go.build$return_stmt")

var Lit_733 *jrt.String = jrt.Intern("arbace.go.build$deferred_call")

var Lit_734 *jrt.String = jrt.Intern("arbace.go.build$defer_stmt")

var Lit_735 *jrt.String = jrt.Intern("arbace.go.build$go_stmt")

var Lit_736 *jrt.String = jrt.Intern("arbace.go.build$send_stmt")

var Lit_737 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt")

var Lit_738 *jrt.String = jrt.Intern("arbace.go.build$select_recv")

var Lit_739 *jrt.String = jrt.Intern("arbace.go.build$select_stmt")

var Lit_740 *jrt.String = jrt.Intern("arbace.go.build$stmt")

var Lit_741 *jrt.String = jrt.Intern("arbace.go.build$has_defer_QMARK_")

var Lit_742 *jrt.String = jrt.Intern("arbace.go.build$free_locals")

var Lit_743 *jrt.String = jrt.Intern("arbace.go.build$build_code")

var Lit_744 *jrt.String = jrt.Intern("arbace.go.build$build_fn_lit")

var Lit_745 *jrt.String = jrt.Intern("arbace.go.build$build_func")

var Lit_746 *jrt.String = jrt.Intern("arbace.go.build$build_inits")

var Lit_747 *jrt.String = jrt.Intern("arbace.go.build$isubst")

var Lit_748 *jrt.String = jrt.Intern("arbace.go.build$local_types")

var Lit_749 *jrt.String = jrt.Intern("arbace.go.build$resolve_on")

var Lit_750 *jrt.String = jrt.Intern("arbace.go.build$inst_tree")

var Lit_751 *jrt.String = jrt.Intern("arbace.go.build$rt_name")

var Lit_752 *jrt.String = jrt.Intern("arbace.go.build$rt_sig")

var Lit_753 *jrt.String = jrt.Intern("arbace.go.build$inst_type_name")

var Lit_754 *jrt.String = jrt.Intern("arbace.go.build$inst_gen")

var Lit_755 *jrt.String = jrt.Intern("arbace.go.build$instance_name")

var Lit_756 *jrt.String = jrt.Intern("arbace.go.build$build_instance")

var Lit_757 *jrt.String = jrt.Intern("arbace.go.build$instance_cell")
