//line j2g_strings.ae:1
package aot_arbace_go_build

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn21,arbace.go.check.typesyn1,tyn21,arbace.go.check.constyn1,cyn19,arbace.go.check.envyn1,ekn3,docks3,goi11,unsupportedkn9,compiled?kn1,Ikn7,float32kn7,float64kn13,untyped-floatkn1,Fkn6,stringkn14,untyped-stringkn1,Skn4,elsekn1,Rkn3,intkn5,int64kn4,uintkn6,uint64kn7,uintptrkn5,arraykn6,structkn3,pkgkn7,pointerkn3,mapkn5,slicekn4,chankn4,funckn4,typekn4,namekn3,tagkn4,pathkn8,embeddedkn5,targskn5,localks3,goi3,genkn9,local-genkn3,genkn8,pkg-namekn5,typeskn7,invalidkn11,untyped-intkn12,untyped-boolkn15,untyped-complexkn4,recvkn4,bothkn4,sendkn9,interfacekn12,untyped-runekn11,untyped-nilkn14,unsafe-pointerkn9,complex64kn1,Bkn10,complex128kn5,slotskn4,codekn6,labelskn4,gotokn9,captured?kn10,addressed?kn4,locskn3,objkn4,cellkn1,Ckn4,slotkn1,Tkn8,constantkn4,modekn7,unknownkn3,valkn2,opkn3,nilks2,go2,opkn1,xkn1,ykn5,uint8kn5,int32kn2,tokn8,variablekn11,place-localkn11,place-fieldkn11,place-derefkn11,place-indexkn12,place-globalkn6,derefskn5,indexkn3,ptrkn6,globalkn5,derefkn5,fieldkn3,litkn4,kindkn5,valuekn6,fieldskn5,elemskn3,keykn7,entrieskn9,func-cellkn6,assertkn6,methodkn9,map-indexkn5,unarykn5,parenkn6,binaryks15,arbace.go.build4,nodekn4,formkn1,kkn4,nodekn12,iface-methodkn4,addrks15,arbace.go.build4,minikn13,convert-ifacekn4,callkn7,indexeskn6,resultkn1,tkn5,tempskn2,fnkn11,method-exprkn4,convkn6,paramskn7,resultskn6,countskn6,spreadkn5,callskn5,multikn11,recv-adjustkn6,calleekn4,argskn5,ifacekn6,statickn7,closurekn7,builtinkn4,stmtkn6,unsafekn9,new-valuekn5,blankks15,arbace.go.build8,map-tempkn1,mkn5,vtypekn2,mtks15,arbace.go.build6,p-tempkn1,ckn9,place-mapkn8,comma-okkn2,okkn3,lhskn3,rhskn5,placekn3,inckn4,linekn5,constkn4,objskn4,initkn7,targetskn5,stmtskn5,labelkn3,letkn8,let-typekn5,declsks3,goi5,labelkn4,loopkn3,brkkn4,contkn2,idkn14,per-iteration?kn4,condkn4,declkn4,postkn4,bodykn6,placesks15,arbace.go.build4,tempkn9,recv-typekn4,overkn9,ptr-arraykn6,switchkn6,valueskn7,defaultkn7,clauseskn4,fallkn3,lockn5,deferkn2,gokn6,incdeckn2,ifkn4,thenkn5,rangekn10,local-typekn5,blockkn6,assignkn9,directivekn9,op-assignkn11,type-switchkn11,fallthroughkn6,selectkn8,continuekn5,breakkn4,exprkn6,returnkn3,forkn3,sigkn8,tag-typekn4,refskn3,varkn6,local?kn9,lit-countv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.go.buildm2,R10,s1169,goi's builder (doc/go/GOI-SPEC.md §4.1): the checked tree (§3.7) made nodes, typed Go\n  closures of the back end arbace/goi, by its factories through arbace.lang.GoInterp's op\n  native (go/arbace/goi/registry.ae). It numbers each function's slots per kind (parameters and\n  results first, as the signature lays them out), makes the variables that live in Go memory\n  cells (captured, addressed, of a struct or array type, every package variable), gives each\n  jump target its codes, chooses each node's variant by its operands' types, and resolves each\n  call to the callee's cell, a closure, or the table's member. It decides nothing the checker\n  has not: no type, no constant, no resolution.\n\n  GR3 builds the interpreter's core: scalars, strings, slices, arrays, maps, structs, pointers,\n  functions and closures, all control flow with labels and goto, defer, panic and recover,\n  interface values without methods (§5.3 rules 1 and 2), the calls of compiled Go. Methods,\n  interfaces' methods, type switches and assertions, goroutines, channels and select are GR4's:\n  a form that needs them is \"not supported by goi yet\" (§3.4), an ex-info with\n  :goi/unsupported.v11,arbace.core7,ex-infoR11,R12,v15,arbace.go.build5,*ctx*v21,arbace.go.check.types5,underv11,arbace.core8,keyword?v15,arbace.go.build7,int-kwsR13,S3,R14,R15,R16,R17,S2,R18,R19,R20,R21,R22,v21,arbace.go.check.types8,untyped?v21,arbace.go.check.types12,default-typev21,arbace.go.check.types9,unsigned?v11,arbace.core9,contains?S5,R23,R24,R25,R26,R27,v15,arbace.go.build8,basic-ofv11,arbace.core7,vector?S2,R28,R29,v21,arbace.go.check.types10,interface?v11,arbace.core3,notv21,arbace.go.check.types7,tparam?v21,arbace.go.check.types6,named?R30,v21,arbace.go.check.types4,infov15,arbace.go.build9,compiled?v15,arbace.go.build18,interpreted-named?R31,R28,R32,R33,R34,R35,v11,arbace.core4,someR29,R36,v21,arbace.go.check.const10,value-textv15,arbace.go.build2,oav11,arbace.core3,mapR37,v15,arbace.go.build4,descv15,arbace.go.build8,tag-textR38,v21,arbace.go.check.types9,exported?R39,R40,v15,arbace.go.build2,opv15,arbace.go.build12,unsupported!v11,arbace.core3,seqR41,v21,arbace.go.check.types8,type-strR42,R43,v11,arbace.core5,swap!R44,v11,arbace.core3,incR45,v15,arbace.go.build10,recursive?R46,R47,v21,arbace.go.check.types12,update-info!v11,arbace.core5,assocv11,arbace.core10,ex-messagev13,arbace.string9,includes?v15,arbace.go.build12,struct-partsR48,v21,arbace.go.check.types8,pointer?R49,R50,R16,R51,v11,arbace.core4,namev15,arbace.go.build10,named-descR52,l1,R53,l0,R54,l2,R55,v11,arbace.core6,empty?R56,R19,R57,R58,v11,arbace.core10,bigintegerv11,arbace.core6,every?v21,arbace.go.check.const11,complex-valv21,arbace.go.check.const9,to-doubleR59,v11,arbace.core8,boolean?R60,S2,R61,R59,R18,S2,R14,R15,v15,arbace.go.build13,complex-valuev15,arbace.go.build14,go-string-nodev15,arbace.go.build8,int-bitsv11,arbace.core8,integer?v21,arbace.go.check.const7,int-valR62,v15,arbace.go.build4,*fn*v11,arbace.core6,updateR63,R64,v11,arbace.core9,volatile!R65,v15,arbace.go.build10,next-code!v19,arbace.go.check.env1,oR66,R67,v15,arbace.go.build16,struct-or-array?R68,R69,v15,arbace.go.build9,cell-var?R70,v15,arbace.go.build9,new-slot!R71,R72,v15,arbace.go.build4,kindv15,arbace.go.build7,as-kindR73,v15,arbace.go.build2,exv15,arbace.go.build6,iface?m18,s1,*s3,Muls1,%s3,Rems6,bit-ors2,Ors1,/s3,Divs1,-s3,Subs7,bit-xors3,Xors7,bit-ands3,Ands11,bit-and-nots6,AndNots1,+s3,AddR74,R75,v11,arbace.core4,not=R76,R77,R78,v15,arbace.go.build7,int-sfxv15,arbace.go.build10,arith-namev15,arbace.go.build8,const-ofv15,arbace.go.build13,local-slot-ofv15,arbace.go.build5,wide?S3,s1,*s1,-s1,+S3,s1,*s1,-s1,+v15,arbace.go.build3,exkR14,S2,s2,>>s2,<<v15,arbace.go.build9,unsigned?v15,arbace.go.build11,float-binopv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core5,firstv21,arbace.go.check.const8,complex?v21,arbace.go.check.const7,re-partv15,arbace.go.build10,count-nodeR79,v15,arbace.go.build9,nil-node?v15,arbace.go.build8,cmp-namev15,arbace.go.build13,iface-contentR80,R81,R82,v15,arbace.go.build13,compare-nodesS2,s2,>>s2,<<v15,arbace.go.build10,shift-nodev15,arbace.go.build9,int-binopR83,R84,R85,v15,arbace.go.build11,bytes-type?v15,arbace.go.build11,runes-type?S2,R61,R59,S2,R61,R59,R86,S5,R87,R88,R89,R90,R91,v15,arbace.go.build12,addressable?v15,arbace.go.build5,placeR92,v15,arbace.go.build11,value-placev11,arbace.core4,restR93,R91,R94,R95,R90,v15,arbace.go.build11,index-placeR96,v15,arbace.go.build3,locR88,v15,arbace.go.build11,field-placeR97,R89,R87,R98,v15,arbace.go.build9,lit-placeR99,v11,arbace.core6,removeR100,R101,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,longv15,arbace.go.build9,elem-nodeR102,v11,arbace.core6,repeatV1,l0,v11,arbace.core6,secondv15,arbace.go.build8,lit-nodev11,arbace.core5,applyv11,arbace.core3,maxR103,R104,v15,arbace.go.build6,load-pv15,arbace.go.build10,local-nodeR105,S1,R79,v15,arbace.go.build10,const-nodeR106,R107,R108,R109,v15,arbace.go.build10,unary-nodeR110,R111,v15,arbace.go.build11,binary-nodeR112,v11,arbace.core6,pr-strR113,R114,R115,R116,R117,R118,R119,R120,v15,arbace.go.build9,call-nodev11,arbace.core6,concatR121,v21,arbace.go.check.types12,string-type?R122,v15,arbace.go.build12,call-resultsR123,R124,R125,v15,arbace.go.build12,build-fn-litv15,arbace.go.build15,func-value-nodeR126,R127,v15,arbace.go.build9,conv-nodev15,arbace.go.build8,var-nodev15,arbace.go.build11,global-nodem8,R13,l0,R17,l0,R20,l0,R22,l0,v11,arbace.core3,vecv11,arbace.core11,map-indexedv11,arbace.core4,mapvR128,R129,R130,v15,arbace.go.build8,mem-nodev11,arbace.core4,takev11,arbace.core4,lastv11,arbace.core4,dropR131,R132,R133,v15,arbace.go.build11,slot-layoutv15,arbace.go.build9,arg-nodesv15,arbace.go.build10,arg-setterv15,arbace.go.build5,temp!v11,arbace.core3,strv11,arbace.core4,compv15,arbace.go.build8,from-memv21,arbace.go.check.types10,deref-typeR134,v15,arbace.go.build13,compiled-callv15,arbace.go.build6,sig-ofR135,R136,R137,v15,arbace.go.build11,method-callR138,v15,arbace.go.build11,static-callR139,v15,arbace.go.build10,value-callR140,v15,arbace.go.build7,builtinR141,v11,arbace.core4,map?v15,arbace.go.build12,expr-stmt-ofR142,v15,arbace.go.build12,expr-or-stmtR143,V1,l0,S2,R87,R42,R144,R145,R146,R147,R148,R149,v15,arbace.go.build7,store-pR150,v15,arbace.go.build13,slot-of-placev15,arbace.go.build8,set-slotR151,R152,R153,S2,R87,R42,S2,R88,R97,S2,R31,R33,R154,v15,arbace.go.build9,assign-tov15,arbace.go.build9,rhs-nodesR155,v15,arbace.go.build13,prepare-placev15,arbace.go.build8,temps-ofv11,arbace.core6,mapcatR156,S2,s2,>>s2,<<v15,arbace.go.build11,binop-nodesS2,s2,>>s2,<<S2,s2,>>s2,<<d4607182418800017408,V3,R150,l1,l0,v15,arbace.go.build14,op-assign-stmtR157,R158,R159,v15,arbace.go.build6,one-ofv15,arbace.go.build8,new-loc!d0,R160,R161,v15,arbace.go.build9,zero-initv15,arbace.go.build8,init-varv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapR162,v11,arbace.core6,filterv15,arbace.go.build9,stmt-listR163,v15,arbace.go.build4,stmtR164,v15,arbace.go.build11,label-code!v11,arbace.core4,pos?v15,arbace.go.build9,body-nodeR165,R166,v15,arbace.go.build9,decl-stmtR167,R168,R169,R170,R171,R172,v15,arbace.go.build11,label-entryR173,v15,arbace.go.build11,loop-targetR174,R175,v15,arbace.go.build19,per-iteration-cellsR176,v15,arbace.go.build11,push-targetR177,R178,R179,v15,arbace.go.build9,has-call?v11,arbace.core4,valsv11,arbace.core6,dissocR180,v15,arbace.go.build13,range-targetsR181,v15,arbace.go.build10,any-setterv15,arbace.go.build10,idx-setterR23,v15,arbace.go.build9,at-setterR182,R183,v11,arbace.core5,true?V2,nnv11,arbace.core4,nil?v11,arbace.core5,doallv21,arbace.go.check.types13,boolean-type?R184,R185,R186,R187,v15,arbace.go.build4,jumpR188,m8,R13,l0,R17,l0,R20,l0,R22,l0,v15,arbace.go.build9,call-stmtv11,arbace.core7,vreset!R189,R190,R191,v15,arbace.go.build11,incdec-stmtR192,R193,v15,arbace.go.build10,defer-stmtR194,v15,arbace.go.build10,range-stmtR195,R196,v15,arbace.go.build10,block-nodeR197,v15,arbace.go.build11,assign-stmtv15,arbace.go.build11,switch-stmtR198,R199,R200,R201,R202,R203,v15,arbace.go.build9,innermostR204,S2,R169,R183,R205,R206,v15,arbace.go.build11,return-stmtR207,v15,arbace.go.build8,for-stmtR208,R209,R210,R211,S17,R52,R137,R107,R210,R180,R128,R77,R97,R36,R209,R208,R211,R113,R69,R160,R85,R129,S17,R52,R137,R107,R210,R180,R128,R77,R97,R36,R209,R208,R211,R113,R69,R160,R85,R129,S2,R87,R42,R212,v11,arbace.core4,keysv11,arbace.core6,vectorv15,arbace.go.build10,has-defer?v15,arbace.go.build11,free-localsR213,v15,arbace.go.build10,build-codem10,R13,l0,R17,l0,R20,l0,R22,l0,R71,l0,")

var Lit_1 *jrt.String = jrt.Intern("AnySlot")

var Lit_2 *jrt.String = jrt.Intern("AnyNewCell")

var Lit_3 *jrt.String = jrt.Intern("AnyCell")

var Lit_4 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_5 *jrt.String = jrt.Intern("AnyPlace")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes$fn__367000223")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes$fn__367000225")

var Lit_8 *jrt.String = jrt.Intern("MakeSliceOf")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes$fn__367000227")

var Lit_10 *jrt.String = jrt.Intern("ArgF")

var Lit_11 *jrt.String = jrt.Intern("ArgI")

var Lit_12 *jrt.String = jrt.Intern("ArgR")

var Lit_13 *jrt.String = jrt.Intern("ArgS")

var Lit_14 *jrt.String = jrt.Intern("BI")

var Lit_15 *jrt.String = jrt.Intern("IB")

var Lit_16 *jrt.String = jrt.Intern("goi's builder: a ")

var Lit_17 *jrt.String = jrt.Intern(" node where a ")

var Lit_18 *jrt.String = jrt.Intern(" is wanted")

var Lit_19 *jrt.String = jrt.Intern("arbace.go.build$assign_stmt$fn__367000386")

var Lit_20 *jrt.String = jrt.Intern("Assign")

var Lit_21 *jrt.String = jrt.Intern("MapSet")

var Lit_22 *jrt.String = jrt.Intern("CellP")

var Lit_23 *jrt.String = jrt.Intern("AtSlot")

var Lit_24 *jrt.String = jrt.Intern("AtNewCell")

var Lit_25 *jrt.String = jrt.Intern("AtCell")

var Lit_26 *jrt.String = jrt.Intern("AtPlace")

var Lit_27 *jrt.String = jrt.Intern("and")

var Lit_28 *jrt.String = jrt.Intern("AndB")

var Lit_29 *jrt.String = jrt.Intern("or")

var Lit_30 *jrt.String = jrt.Intern("OrB")

var Lit_31 *jrt.String = jrt.Intern("K")

var Lit_32 *jrt.String = jrt.Intern("F32")

var Lit_33 *jrt.String = jrt.Intern("F64")

var Lit_34 *jrt.String = jrt.Intern("C64")

var Lit_35 *jrt.String = jrt.Intern("C128")

var Lit_36 *jrt.String = jrt.Intern("ConcatS")

var Lit_37 *jrt.String = jrt.Intern("<<")

var Lit_38 *jrt.String = jrt.Intern("Shl")

var Lit_39 *jrt.String = jrt.Intern("Shr")

var Lit_40 *jrt.String = jrt.Intern("U")

var Lit_41 *jrt.String = jrt.Intern("")

var Lit_42 *jrt.String = jrt.Intern("Seq")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.build$body_node$fn__367000420")

var Lit_44 *jrt.String = jrt.Intern("ProCell")

var Lit_45 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367000649__367000653")

var Lit_46 *jrt.String = jrt.Intern("NewCode")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367000649__367000653$fn__367000654")

var Lit_48 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367000649__367000653$fn__367000654$fn__367000655")

var Lit_49 *jrt.String = jrt.Intern("ProNewCell")

var Lit_50 *jrt.String = jrt.Intern("EpiCell")

var Lit_51 *jrt.String = jrt.Intern("ProZeroR")

var Lit_52 *jrt.String = jrt.Intern(".func")

var Lit_53 *jrt.String = jrt.Intern("FuncCell")

var Lit_54 *jrt.String = jrt.Intern("SetCode")

var Lit_55 *jrt.String = jrt.Intern("MakeClosure")

var Lit_56 *jrt.String = jrt.Intern("arbace.go.build$build_fn_lit$fn__367000675")

var Lit_57 *jrt.String = jrt.Intern("init")

var Lit_58 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367000681__367000685")

var Lit_59 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367000681__367000685$fn__367000686")

var Lit_60 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367000681__367000685$fn__367000686$fn__367000687")

var Lit_61 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367000681__367000685$fn__367000686$fn__367000691")

var Lit_62 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367000681__367000685$fn__367000686$fn__367000687$fn__367000688")

var Lit_63 *jrt.String = jrt.Intern("_")

var Lit_64 *jrt.String = jrt.Intern("arbace.go.build$builtin$value__367000278")

var Lit_65 *jrt.String = jrt.Intern("Add")

var Lit_66 *jrt.String = jrt.Intern("UnsafeAdd")

var Lit_67 *jrt.String = jrt.Intern("make")

var Lit_68 *jrt.String = jrt.Intern("MakeMap")

var Lit_69 *jrt.String = jrt.Intern("MakeSlice")

var Lit_70 *jrt.String = jrt.Intern("channels")

var Lit_71 *jrt.String = jrt.Intern("GR4")

var Lit_72 *jrt.String = jrt.Intern("panic")

var Lit_73 *jrt.String = jrt.Intern("Panic")

var Lit_74 *jrt.String = jrt.Intern("StmtT")

var Lit_75 *jrt.String = jrt.Intern("recover")

var Lit_76 *jrt.String = jrt.Intern("Recover")

var Lit_77 *jrt.String = jrt.Intern("StringData")

var Lit_78 *jrt.String = jrt.Intern("UnsafeStringData")

var Lit_79 *jrt.String = jrt.Intern("String")

var Lit_80 *jrt.String = jrt.Intern("UnsafeString")

var Lit_81 *jrt.String = jrt.Intern("Slice")

var Lit_82 *jrt.String = jrt.Intern("UnsafeSlice")

var Lit_83 *jrt.String = jrt.Intern("real")

var Lit_84 *jrt.String = jrt.Intern("RealF")

var Lit_85 *jrt.String = jrt.Intern("imag")

var Lit_86 *jrt.String = jrt.Intern("ImagF")

var Lit_87 *jrt.String = jrt.Intern("complex")

var Lit_88 *jrt.String = jrt.Intern("ComplexR")

var Lit_89 *jrt.String = jrt.Intern("cap")

var Lit_90 *jrt.String = jrt.Intern("CapSlice")

var Lit_91 *jrt.String = jrt.Intern("cap of ")

var Lit_92 *jrt.String = jrt.Intern("delete")

var Lit_93 *jrt.String = jrt.Intern("Delete")

var Lit_94 *jrt.String = jrt.Intern("len")

var Lit_95 *jrt.String = jrt.Intern("LenS")

var Lit_96 *jrt.String = jrt.Intern("LenSlice")

var Lit_97 *jrt.String = jrt.Intern("LenMap")

var Lit_98 *jrt.String = jrt.Intern("ThenI")

var Lit_99 *jrt.String = jrt.Intern("ConstI")

var Lit_100 *jrt.String = jrt.Intern("len of ")

var Lit_101 *jrt.String = jrt.Intern("max")

var Lit_102 *jrt.String = jrt.Intern("MinMaxF")

var Lit_103 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000292")

var Lit_104 *jrt.String = jrt.Intern("MinMaxI")

var Lit_105 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000294")

var Lit_106 *jrt.String = jrt.Intern("MinMaxS")

var Lit_107 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000296")

var Lit_108 *jrt.String = jrt.Intern("min")

var Lit_109 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000299")

var Lit_110 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000301")

var Lit_111 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000303")

var Lit_112 *jrt.String = jrt.Intern("SliceData")

var Lit_113 *jrt.String = jrt.Intern("UnsafeSliceData")

var Lit_114 *jrt.String = jrt.Intern("new")

var Lit_115 *jrt.String = jrt.Intern("AddrOf")

var Lit_116 *jrt.String = jrt.Intern("LitP")

var Lit_117 *jrt.String = jrt.Intern("NewR")

var Lit_118 *jrt.String = jrt.Intern("copy")

var Lit_119 *jrt.String = jrt.Intern("CopyString")

var Lit_120 *jrt.String = jrt.Intern("Copy")

var Lit_121 *jrt.String = jrt.Intern("print")

var Lit_122 *jrt.String = jrt.Intern("Print")

var Lit_123 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000308__367000312")

var Lit_124 *jrt.String = jrt.Intern("println")

var Lit_125 *jrt.String = jrt.Intern("clear")

var Lit_126 *jrt.String = jrt.Intern("ClearMap")

var Lit_127 *jrt.String = jrt.Intern("ClearSlice")

var Lit_128 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000318__367000322")

var Lit_129 *jrt.String = jrt.Intern("append")

var Lit_130 *jrt.String = jrt.Intern("AppendString")

var Lit_131 *jrt.String = jrt.Intern("AppendSpread")

var Lit_132 *jrt.String = jrt.Intern("Append")

var Lit_133 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000331")

var Lit_134 *jrt.String = jrt.Intern("close")

var Lit_135 *jrt.String = jrt.Intern("the builtin ")

var Lit_136 *jrt.String = jrt.Intern("unsafe.")

var Lit_137 *jrt.String = jrt.Intern("GR3")

var Lit_138 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000308__367000312$fn__367000313")

var Lit_139 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000308__367000312$fn__367000313$fn__367000314")

var Lit_140 *jrt.String = jrt.Intern("PrintArg")

var Lit_141 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000318__367000322$fn__367000323")

var Lit_142 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000318__367000322$fn__367000323$fn__367000324")

var Lit_143 *jrt.String = jrt.Intern("calls of interface methods")

var Lit_144 *jrt.String = jrt.Intern("the call kind ")

var Lit_145 *jrt.String = jrt.Intern("ExprT")

var Lit_146 *jrt.String = jrt.Intern("IsNilR")

var Lit_147 *jrt.String = jrt.Intern("==")

var Lit_148 *jrt.String = jrt.Intern("NotB")

var Lit_149 *jrt.String = jrt.Intern("R")

var Lit_150 *jrt.String = jrt.Intern("F")

var Lit_151 *jrt.String = jrt.Intern("I")

var Lit_152 *jrt.String = jrt.Intern("LK")

var Lit_153 *jrt.String = jrt.Intern("LL")

var Lit_154 *jrt.String = jrt.Intern("S")

var Lit_155 *jrt.String = jrt.Intern("CallCompiled")

var Lit_156 *jrt.String = jrt.Intern("arbace.go.build$compiled_call$fn__367000261")

var Lit_157 *jrt.String = jrt.Intern("CvC64")

var Lit_158 *jrt.String = jrt.Intern("ConstR")

var Lit_159 *jrt.String = jrt.Intern("ConstB")

var Lit_160 *jrt.String = jrt.Intern("ConstF")

var Lit_161 *jrt.String = jrt.Intern("a constant of type ")

var Lit_162 *jrt.String = jrt.Intern("Cv")

var Lit_163 *jrt.String = jrt.Intern("Uto")

var Lit_164 *jrt.String = jrt.Intern("Ito")

var Lit_165 *jrt.String = jrt.Intern("Fto")

var Lit_166 *jrt.String = jrt.Intern("CvF32")

var Lit_167 *jrt.String = jrt.Intern("StrFromRune")

var Lit_168 *jrt.String = jrt.Intern("StrFromBytes")

var Lit_169 *jrt.String = jrt.Intern("StrFromRunes")

var Lit_170 *jrt.String = jrt.Intern("BytesFromStr")

var Lit_171 *jrt.String = jrt.Intern("RunesFromStr")

var Lit_172 *jrt.String = jrt.Intern("CvC128")

var Lit_173 *jrt.String = jrt.Intern("UintptrToUnsafe")

var Lit_174 *jrt.String = jrt.Intern("PtrToUnsafe")

var Lit_175 *jrt.String = jrt.Intern("UnsafeToUintptr")

var Lit_176 *jrt.String = jrt.Intern("UnsafeToPtr")

var Lit_177 *jrt.String = jrt.Intern("SliceToArray")

var Lit_178 *jrt.String = jrt.Intern("SliceToArrayPtr")

var Lit_179 *jrt.String = jrt.Intern("ConvR")

var Lit_180 *jrt.String = jrt.Intern("the conversion ")

var Lit_181 *jrt.String = jrt.Intern(" to ")

var Lit_182 *jrt.String = jrt.Intern("Nop")

var Lit_183 *jrt.String = jrt.Intern("arbace.go.build$decl_stmt$fn__367000408")

var Lit_184 *jrt.String = jrt.Intern("arbace.go.build$decl_stmt$target__367000410")

var Lit_185 *jrt.String = jrt.Intern("arbace.go.build$defer_stmt$to_mini__367000560")

var Lit_186 *jrt.String = jrt.Intern("arbace.go.build$defer_stmt$fn__367000562")

var Lit_187 *jrt.String = jrt.Intern("deferring a call of kind ")

var Lit_188 *jrt.String = jrt.Intern("arbace.go.build$defer_stmt$fn__367000568")

var Lit_189 *jrt.String = jrt.Intern("Defer")

var Lit_190 *jrt.String = jrt.Intern("a value of type ")

var Lit_191 *jrt.String = jrt.Intern("an invalid type")

var Lit_192 *jrt.String = jrt.Intern("TBasic")

var Lit_193 *jrt.String = jrt.Intern("unsafe.Pointer")

var Lit_194 *jrt.String = jrt.Intern("type parameters")

var Lit_195 *jrt.String = jrt.Intern("GR6")

var Lit_196 *jrt.String = jrt.Intern("TMap")

var Lit_197 *jrt.String = jrt.Intern("TArray")

var Lit_198 *jrt.String = jrt.Intern("TChan")

var Lit_199 *jrt.String = jrt.Intern("any")

var Lit_200 *jrt.String = jrt.Intern("TIface")

var Lit_201 *jrt.String = jrt.Intern("TSlice")

var Lit_202 *jrt.String = jrt.Intern("TFunc")

var Lit_203 *jrt.String = jrt.Intern("TPtr")

var Lit_204 *jrt.String = jrt.Intern("TStruct")

var Lit_205 *jrt.String = jrt.Intern("the type ")

var Lit_206 *jrt.String = jrt.Intern("arbace.lang.GoInterp")

var Lit_207 *jrt.String = jrt.Intern("java.util.HashMap")

var Lit_208 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_209 *jrt.String = jrt.Intern("type assertions")

var Lit_210 *jrt.String = jrt.Intern("method values")

var Lit_211 *jrt.String = jrt.Intern("channel receives")

var Lit_212 *jrt.String = jrt.Intern("MapGet")

var Lit_213 *jrt.String = jrt.Intern("ZeroR")

var Lit_214 *jrt.String = jrt.Intern("a type of a package not in the table, in ")

var Lit_215 *jrt.String = jrt.Intern("GR5")

var Lit_216 *jrt.String = jrt.Intern("interface methods")

var Lit_217 *jrt.String = jrt.Intern("arbace.go.build$ex$fn__367000190")

var Lit_218 *jrt.String = jrt.Intern("SliceString")

var Lit_219 *jrt.String = jrt.Intern("SliceSlice")

var Lit_220 *jrt.String = jrt.Intern("SliceArray")

var Lit_221 *jrt.String = jrt.Intern("DerefP")

var Lit_222 *jrt.String = jrt.Intern("ThenF")

var Lit_223 *jrt.String = jrt.Intern("ThenR")

var Lit_224 *jrt.String = jrt.Intern("ThenS")

var Lit_225 *jrt.String = jrt.Intern("method expressions")

var Lit_226 *jrt.String = jrt.Intern("IndexS")

var Lit_227 *jrt.String = jrt.Intern("the expression ")

var Lit_228 *jrt.String = jrt.Intern("ExprB")

var Lit_229 *jrt.String = jrt.Intern("ExprF")

var Lit_230 *jrt.String = jrt.Intern("ExprI")

var Lit_231 *jrt.String = jrt.Intern("ExprR")

var Lit_232 *jrt.String = jrt.Intern("ExprS")

var Lit_233 *jrt.String = jrt.Intern("FieldOff")

var Lit_234 *jrt.String = jrt.Intern("FieldP")

var Lit_235 *jrt.String = jrt.Intern("LoadR")

var Lit_236 *jrt.String = jrt.Intern("arbace.go.build$for_stmt$fn__367000438")

var Lit_237 *jrt.String = jrt.Intern("For")

var Lit_238 *jrt.String = jrt.Intern("arbace.go.build$free_locals$walk__367000591")

var Lit_239 *jrt.String = jrt.Intern("arbace.go.build$free_locals$fn__367000624")

var Lit_240 *jrt.String = jrt.Intern("FromMemR")

var Lit_241 *jrt.String = jrt.Intern("MemberValue")

var Lit_242 *jrt.String = jrt.Intern("FuncValue")

var Lit_243 *jrt.String = jrt.Intern("arbace.go.build$go_string_node$fn__367000061")

var Lit_244 *jrt.String = jrt.Intern("ConstS")

var Lit_245 *jrt.String = jrt.Intern("ConstSB")

var Lit_246 *jrt.String = jrt.Intern("arbace.go.build$go_string_node$fn__367000063")

var Lit_247 *jrt.String = jrt.Intern("arbace.go.build$has_defer_QMARK_$walk__367000579")

var Lit_248 *jrt.String = jrt.Intern("IdxSlot")

var Lit_249 *jrt.String = jrt.Intern("IdxNewCell")

var Lit_250 *jrt.String = jrt.Intern("IdxStore")

var Lit_251 *jrt.String = jrt.Intern("IfaceI")

var Lit_252 *jrt.String = jrt.Intern("IfaceF")

var Lit_253 *jrt.String = jrt.Intern("IfaceR")

var Lit_254 *jrt.String = jrt.Intern("IfaceS")

var Lit_255 *jrt.String = jrt.Intern("+")

var Lit_256 *jrt.String = jrt.Intern("-")

var Lit_257 *jrt.String = jrt.Intern("SliceElemP")

var Lit_258 *jrt.String = jrt.Intern("ArrayElemP")

var Lit_259 *jrt.String = jrt.Intern("indexing ")

var Lit_260 *jrt.String = jrt.Intern("NewCellInit")

var Lit_261 *jrt.String = jrt.Intern("LK64")

var Lit_262 *jrt.String = jrt.Intern("LL64")

var Lit_263 *jrt.String = jrt.Intern("Jump")

var Lit_264 *jrt.String = jrt.Intern("LitMap")

var Lit_265 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000169")

var Lit_266 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000171")

var Lit_267 *jrt.String = jrt.Intern("LitSlice")

var Lit_268 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000173")

var Lit_269 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000175")

var Lit_270 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000136")

var Lit_271 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000138__367000142")

var Lit_272 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000152")

var Lit_273 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000154")

var Lit_274 *jrt.String = jrt.Intern("ElemSize")

var Lit_275 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000156")

var Lit_276 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000158")

var Lit_277 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000138__367000142$fn__367000143")

var Lit_278 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000138__367000142$fn__367000143$fn__367000144")

var Lit_279 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000138__367000142$fn__367000143$fn__367000148")

var Lit_280 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000138__367000142$fn__367000143$fn__367000144$fn__367000145")

var Lit_281 *jrt.String = jrt.Intern("a literal key promoted through a pointer")

var Lit_282 *jrt.String = jrt.Intern("LoadF")

var Lit_283 *jrt.String = jrt.Intern("LoadI")

var Lit_284 *jrt.String = jrt.Intern("LoadS")

var Lit_285 *jrt.String = jrt.Intern("goi's builder: no location for ")

var Lit_286 *jrt.String = jrt.Intern("LocalF")

var Lit_287 *jrt.String = jrt.Intern("LocalI")

var Lit_288 *jrt.String = jrt.Intern("LocalR")

var Lit_289 *jrt.String = jrt.Intern("LocalS")

var Lit_290 *jrt.String = jrt.Intern("MemR")

var Lit_291 *jrt.String = jrt.Intern("methods")

var Lit_292 *jrt.String = jrt.Intern("promoted methods")

var Lit_293 *jrt.String = jrt.Intern(".")

var Lit_294 *jrt.String = jrt.Intern("error")

var Lit_295 *jrt.String = jrt.Intern("the generic type ")

var Lit_296 *jrt.String = jrt.Intern("TCompiled")

var Lit_297 *jrt.String = jrt.Intern("TNamed")

var Lit_298 *jrt.String = jrt.Intern("the recursive pointer type ")

var Lit_299 *jrt.String = jrt.Intern("as built: GR3")

var Lit_300 *jrt.String = jrt.Intern("arbace.go.build$named_desc$fn__367000044")

var Lit_301 *jrt.String = jrt.Intern("TSetUnder")

var Lit_302 *jrt.String = jrt.Intern("used before it is complete")

var Lit_303 *jrt.String = jrt.Intern(", recursive through a slice, an array, a map or a function")

var Lit_304 *jrt.String = jrt.Intern("SetC")

var Lit_305 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells$fn__367000429")

var Lit_306 *jrt.String = jrt.Intern("RenewCells")

var Lit_307 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells$fn__367000431")

var Lit_308 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells$fn__367000433")

var Lit_309 *jrt.String = jrt.Intern("VarP")

var Lit_310 *jrt.String = jrt.Intern("GlobalP")

var Lit_311 *jrt.String = jrt.Intern("goi's builder: ")

var Lit_312 *jrt.String = jrt.Intern(" is not a cell")

var Lit_313 *jrt.String = jrt.Intern("the address of a ")

var Lit_314 *jrt.String = jrt.Intern("arbace.go.build$prepare_place$freeze__367000376")

var Lit_315 *jrt.String = jrt.Intern("arbace.go.build$prepare_place$chain__367000378")

var Lit_316 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$retarget__367000480")

var Lit_317 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$mk__367000482")

var Lit_318 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000490")

var Lit_319 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000492")

var Lit_320 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000494")

var Lit_321 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000496")

var Lit_322 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000498")

var Lit_323 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000500")

var Lit_324 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000502")

var Lit_325 *jrt.String = jrt.Intern("range over channels")

var Lit_326 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000504")

var Lit_327 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000506")

var Lit_328 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367000508")

var Lit_329 *jrt.String = jrt.Intern("range over functions")

var Lit_330 *jrt.String = jrt.Intern("RangeMap")

var Lit_331 *jrt.String = jrt.Intern("RangeInt")

var Lit_332 *jrt.String = jrt.Intern("RangeArray")

var Lit_333 *jrt.String = jrt.Intern("RangePtrArray")

var Lit_334 *jrt.String = jrt.Intern("RangeString")

var Lit_335 *jrt.String = jrt.Intern("RangeSlice")

var Lit_336 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$mk__367000482$fn__367000483")

var Lit_337 *jrt.String = jrt.Intern("arbace.go.build$range_targets$fn__367000443")

var Lit_338 *jrt.String = jrt.Intern("arbace.go.build$range_targets$fn__367000445")

var Lit_339 *jrt.String = jrt.Intern("arbace.go.build$recursive_QMARK_$walk__367000024")

var Lit_340 *jrt.String = jrt.Intern("arbace.go.build$recursive_QMARK_$walk__367000024$fn__367000026")

var Lit_341 *jrt.String = jrt.Intern("arbace.go.build$return_stmt$store__367000551")

var Lit_342 *jrt.String = jrt.Intern("MapGet2")

var Lit_343 *jrt.String = jrt.Intern("Then")

var Lit_344 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000370")

var Lit_345 *jrt.String = jrt.Intern("SetF")

var Lit_346 *jrt.String = jrt.Intern("SetI")

var Lit_347 *jrt.String = jrt.Intern("SetR")

var Lit_348 *jrt.String = jrt.Intern("SetS")

var Lit_349 *jrt.String = jrt.Intern("arbace.go.build$slot_layout$take_BANG___367000205")

var Lit_350 *jrt.String = jrt.Intern("arbace.go.build$slot_layout$fn__367000207")

var Lit_351 *jrt.String = jrt.Intern("arbace.go.build$slot_layout$fn__367000209")

var Lit_352 *jrt.String = jrt.Intern("Call")

var Lit_353 *jrt.String = jrt.Intern("arbace.go.build$static_call$fn__367000238")

var Lit_354 *jrt.String = jrt.Intern("resCopies")

var Lit_355 *jrt.String = jrt.Intern("CallT")

var Lit_356 *jrt.String = jrt.Intern("goroutines")

var Lit_357 *jrt.String = jrt.Intern("If")

var Lit_358 *jrt.String = jrt.Intern("type switches")

var Lit_359 *jrt.String = jrt.Intern("goi's builder: fallthrough outside a switch")

var Lit_360 *jrt.String = jrt.Intern("select")

var Lit_361 *jrt.String = jrt.Intern("goi's builder: no continue target ")

var Lit_362 *jrt.String = jrt.Intern("arbace.go.build$stmt$fn__367000574")

var Lit_363 *jrt.String = jrt.Intern("goi's builder: no break target ")

var Lit_364 *jrt.String = jrt.Intern("arbace.go.build$stmt$fn__367000576")

var Lit_365 *jrt.String = jrt.Intern("the statement ")

var Lit_366 *jrt.String = jrt.Intern("StoreF")

var Lit_367 *jrt.String = jrt.Intern("StoreI")

var Lit_368 *jrt.String = jrt.Intern("StoreR")

var Lit_369 *jrt.String = jrt.Intern("StoreS")

var Lit_370 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000035")

var Lit_371 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000037")

var Lit_372 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000039")

var Lit_373 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000041")

var Lit_374 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000514")

var Lit_375 *jrt.String = jrt.Intern("Switch")

var Lit_376 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000514$iter__367000515__367000519")

var Lit_377 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000514$iter__367000515__367000519$fn__367000520")

var Lit_378 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000514$iter__367000515__367000519$fn__367000520$fn__367000521")

var Lit_379 *jrt.String = jrt.Intern("NewCase")

var Lit_380 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000514$iter__367000515__367000519$fn__367000520$iter__367000535__367000539")

var Lit_381 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000514$iter__367000515__367000519$fn__367000520$fn__367000545")

var Lit_382 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000514$iter__367000515__367000519$fn__367000520$fn__367000521$iter__367000522__367000526")

var Lit_383 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000514$iter__367000515__367000519$fn__367000520$fn__367000521$fn__367000532")

var Lit_384 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000514$iter__367000515__367000519$fn__367000520$fn__367000521$iter__367000522__367000526$fn__367000527")

var Lit_385 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000514$iter__367000515__367000519$fn__367000520$fn__367000521$iter__367000522__367000526$fn__367000527$fn__367000528")

var Lit_386 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000514$iter__367000515__367000519$fn__367000520$iter__367000535__367000539$fn__367000540")

var Lit_387 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367000514$iter__367000515__367000519$fn__367000520$iter__367000535__367000539$fn__367000540$fn__367000541")

var Lit_388 *jrt.String = jrt.Intern("arbace.go.build$temps_of$fn__367000344")

var Lit_389 *jrt.String = jrt.Intern("arbace.go.build$temps_of$fn__367000351")

var Lit_390 *jrt.String = jrt.Intern("arbace.go.build$temps_of$fn__367000360")

var Lit_391 *jrt.String = jrt.Intern("bit-not")

var Lit_392 *jrt.String = jrt.Intern("Compl")

var Lit_393 *jrt.String = jrt.Intern("NegF")

var Lit_394 *jrt.String = jrt.Intern("Neg")

var Lit_395 *jrt.String = jrt.Intern("NegC64")

var Lit_396 *jrt.String = jrt.Intern("NegC128")

var Lit_397 *jrt.String = jrt.Intern("not")

var Lit_398 *jrt.String = jrt.Intern("not supported by goi yet: ")

var Lit_399 *jrt.String = jrt.Intern(" (")

var Lit_400 *jrt.String = jrt.Intern(")")

var Lit_401 *jrt.String = jrt.Intern("CallValue")

var Lit_402 *jrt.String = jrt.Intern("arbace.go.build$value_call$fn__367000250")

var Lit_403 *jrt.String = jrt.Intern("CallValueT")

var Lit_404 *jrt.String = jrt.Intern("BoxP")

var Lit_405 *jrt.String = jrt.Intern("NewCell")

var Lit_406 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistskn3,tagyn6,Stringyn1,&yn4,argskn4,linekn6,columnkn4,filekn7,privateyn2,xsyn4,whatyn2,grkn7,dynamicyn4,pathkn5,int32kn5,int16kn3,intkn5,int64kn4,uintkn6,uint64kn7,uintptrkn12,untyped-runekn6,uint16kn12,untyped-boolkn4,int8kn6,uint32kn11,untyped-intkn4,boolkn5,uint8yn2,tykn8,declaredyn2,ntyn3,tagyn1,uyn1,vyn4,wantyn1,kyn2,nmyn1,xyn1,syn1,nyn1,pyn2,knyn3,op*yn2,xnyn2,ynyn1,yyn2,xkyn2,ykyn9,ycount-tyyn1,_yn2,psyn2,rsyn8,variadicyn4,nodeyn3,sigyn3,cmpyn1,fyn4,modeyn6,calleeyn4,recvv11,arbace.core5,in-nsMyn15,arbace.go.buildm2,R0,s1169,goi's builder (doc/go/GOI-SPEC.md §4.1): the checked tree (§3.7) made nodes, typed Go\n  closures of the back end arbace/goi, by its factories through arbace.lang.GoInterp's op\n  native (go/arbace/goi/registry.ae). It numbers each function's slots per kind (parameters and\n  results first, as the signature lays them out), makes the variables that live in Go memory\n  cells (captured, addressed, of a struct or array type, every package variable), gives each\n  jump target its codes, chooses each node's variant by its operands' types, and resolves each\n  call to the callee's cell, a closure, or the table's member. It decides nothing the checker\n  has not: no type, no constant, no resolution.\n\n  GR3 builds the interpreter's core: scalars, strings, slices, arrays, maps, structs, pointers,\n  functions and closures, all control flow with labels and goto, defer, panic and recover,\n  interface values without methods (§5.3 rules 1 and 2), the calls of compiled Go. Methods,\n  interfaces' methods, type switches and assertions, goroutines, channels and select are GR4's:\n  a form that needs them is \"not supported by goi yet\" (§3.4), an ex-info with\n  :goi/unsupported.m2,R0,s1169,goi's builder (doc/go/GOI-SPEC.md §4.1): the checked tree (§3.7) made nodes, typed Go\n  closures of the back end arbace/goi, by its factories through arbace.lang.GoInterp's op\n  native (go/arbace/goi/registry.ae). It numbers each function's slots per kind (parameters and\n  results first, as the signature lays them out), makes the variables that live in Go memory\n  cells (captured, addressed, of a struct or array type, every package variable), gives each\n  jump target its codes, chooses each node's variant by its operands' types, and resolves each\n  call to the callee's cell, a closure, or the table's member. It decides nothing the checker\n  has not: no type, no constant, no resolution.\n\n  GR3 builds the interpreter's core: scalars, strings, slices, arrays, maps, structs, pointers,\n  functions and closures, all control flow with labels and goto, defer, panic and recover,\n  interface values without methods (§5.3 rules 1 and 2), the calls of compiled Go. Methods,\n  interfaces' methods, type switches and assertions, goroutines, channels and select are GR4's:\n  a form that needs them is \"not supported by goi yet\" (§3.4), an ex-info with\n  :goi/unsupported.R1,v15,arbace.go.build2,opm10,R2,L1,V3,Myn2,nmm2,R3,R4,R5,R6,R0,s65,Makes what goi's factory nm makes of args (GoInterp's op native).R7,i26,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build2,oam10,R10,TR2,L1,V1,R11,R7,i31,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,unsupported!m10,R2,L1,V2,R12,R13,R0,s93,Ends the build of a form goi does not support yet (§3.4): what, the milestone that brings it.R7,i33,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,*ctx*m10,R14,TR7,i40,R8,i1,R9,s18,arbace/go/build.aeR0,s271,The package's build context: {:path :name :compiled? (path -> listed?) :types (a HashMap of\n  descriptors by checker type) :gen (named type -> its generation) :func-cell (function object\n  -> its *goi.Func) :global (variable object -> {:ptr :type}) :local-gen (an atom)}.v15,arbace.go.build4,*fn*m10,R14,TR7,i46,R8,i1,R9,s18,arbace/go/build.aeR0,s362,The function being built: {:slots (volatile counts per kind) :locs (an IdentityHashMap of\n  variables to [:slot k n] or [:cell c]) :code (the next jump code) :defer (volatile) :targets\n  (the breakable statements, innermost last) :labels (a HashMap of label names to codes)\n  :results :calls (the calls of several results, by identity: their temporaries) :name}.v15,arbace.go.build9,compiled?m10,R10,TR2,L1,V1,R15,R7,i53,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,int-kwsS15,R16,R17,R18,R19,R20,R21,R22,R23,R24,R25,R26,R27,R28,R29,R30,m8,R10,TR7,i57,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,kindm10,R2,L1,V1,R31,R0,s79,The slot kind of a value of checker type ty: :I (integers, bool), :F, :S or :R.R7,i60,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,int-sfxm26,R26,s2,I8R17,s3,I16R16,s3,I32R19,s3,I64R18,s1,IR30,s2,U8R24,s3,U16R27,s3,U32R21,s3,U64R20,s1,UR22,s2,UPR28,s1,IR23,s3,I32m8,R10,TR7,i72,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,basic-ofm10,R10,TR2,L1,V1,R31,R7,i76,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,unsigned?m10,R10,TR2,L1,V1,R31,R7,i77,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,wide?m10,R10,TR2,L1,V1,R31,R7,i78,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build16,struct-or-array?m10,R10,TR2,L1,V1,R31,R7,i79,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build6,iface?m10,R10,TR2,L1,V1,R31,R7,i80,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,descm8,R32,TR7,i82,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build18,interpreted-named?m10,R10,TR2,L1,V1,R31,R7,i84,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,recursive?m12,R10,TR2,L1,V1,R33,R0,s141,Whether named type nt is reachable from its own underlying type (so that reflect cannot make\n  its RT: its pointers are erased in Go memory).R7,i87,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,tag-textm10,R10,TR2,L1,V1,R34,R7,i111,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,struct-partsm12,R10,TR2,L1,V1,R35,R0,s130,The parts of struct type u for the factories: names, field descriptors, tags, package paths\n  of unexported names, embedded flags.R7,i113,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,named-descm10,R10,TR2,L1,V1,R31,R7,i122,R8,i1,R9,s18,arbace/go/build.aem10,R2,L1,V1,R31,R0,s75,The descriptor (a *goi.Type) of checker type ty, one per type in the build.R7,i153,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,int-bitsm12,R10,TR2,L1,V1,R36,R0,s57,Integer constant v as the int64 of its normalized I slot.R7,i184,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build14,go-string-nodem12,R10,TR2,L1,V1,Myn1,vm2,R3,R4,R0,s69,A string constant node of value v (the checker's: one char per byte).R7,i189,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build13,complex-valuem10,R10,TR2,L1,V2,R31,R36,R7,i196,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,const-nodem10,R2,L1,V3,R31,R36,R37,R0,s66,[kind node] of constant value v of type ty (want :B: a condition).R7,i203,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,new-slot!m10,R10,TR2,L1,V1,R38,R7,i218,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,next-code!m10,R10,TR2,L1,V0,R7,i224,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,label-code!m12,R10,TR2,L1,V1,R39,R0,s50,The goto code of label nm (assigned on first use).R7,i227,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,label-entrym10,R10,TR2,L1,V1,R39,R7,i234,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,cell-var?m10,R2,L1,V1,R40,R0,s53,Whether variable x lives in Go memory (a cell, §4.3).R7,i238,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build3,locm10,R10,TR2,L1,V1,R40,R7,i243,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,new-loc!m12,R10,TR2,L1,V1,R40,R0,s76,A location for a new variable x: a slot of its kind, or a C slot for a cell.R7,i247,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,temp!m10,R10,TR2,L1,V1,R38,R7,i254,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,local-nodem10,R10,TR2,L1,V2,R38,R41,R7,i258,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,as-kindm10,R2,L1,V2,V2,R38,R42,R37,R0,s54,Node [k n] as kind want (:B from an :I bool and back).R7,i260,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build6,load-pm12,R10,TR2,L1,V2,R43,R31,R0,s55,The value of type ty at place p, as a node of its kind.R7,i269,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,store-pm12,R10,TR2,L1,V3,R43,R44,R31,R0,s57,The statement storing node [k n] (of type ty) at place p.R7,i280,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,set-slotm10,R10,TR2,L1,V3,R38,R41,R42,R7,i292,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,expr-stmt-ofm10,R10,TR2,L1,V1,V2,R38,R42,R7,i295,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build2,exm8,R32,TR7,i298,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,ex-asm8,R32,TR7,i298,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,placem8,R32,TR7,i298,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,lit-placem8,R32,TR7,i298,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,lit-nodem8,R32,TR7,i298,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,call-nodem8,R32,TR7,i298,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,call-resultsm8,R32,TR7,i298,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,build-fn-litm8,R32,TR7,i298,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,builtinm8,R32,TR7,i298,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,expr-or-stmtm8,R32,TR7,i298,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,stmtm8,R32,TR7,i298,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,stmt-listm8,R32,TR7,i298,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,rhs-nodesm8,R32,TR7,i298,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build3,exkm8,R2,L1,V2,R42,R38,R7,i300,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build13,iface-contentm12,R10,TR2,L1,V2,V2,R38,R42,R31,R0,s60,Node [k n] of type ty as an interface's content (an R node).R7,i304,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,arith-namem10,R10,TR2,L1,V1,R45,R7,i319,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,cmp-namem12,s2,==s2,Eqs2,!=s2,Nes1,<s2,Lts2,<=s2,Les1,>s2,Gts2,>=s2,Gem8,R10,TR7,i323,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,const-ofm12,R10,TR2,L1,V1,R42,R0,s69,The constant value of node n when it is one (an operand's), else nil.R7,i325,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build13,local-slot-ofm12,R10,TR2,L1,V1,R42,R0,s71,The I slot of node n when it reads a local held in an I slot, else nil.R7,i330,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,int-binopm10,R2,L1,V4,R45,R31,R46,R47,R0,s72,x op y on integer type ty (nodes of the operands' checked trees xn, yn).R7,i338,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,float-binopm10,R10,TR2,L1,V4,R45,R31,R40,R48,R7,i352,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,binop-nodesm10,R2,L1,V5,R45,R31,R49,R50,R51,R0,s85,[k node] of arithmetic x op y of type ty on built operand nodes (for op= statements).R7,i356,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,count-nodem12,R10,TR2,L1,V1,R47,R0,s81,A shift count's node: an I (a constant count of any numeric kind as its integer).R7,i369,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,shift-nodem10,R10,TR2,L1,V4,R45,R31,R46,R47,R7,i379,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,nil-node?m10,R10,TR2,L1,V1,R42,R7,i384,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build13,compare-nodesm10,R2,L1,V3,R45,R46,R47,R0,s35,[:B node] of x op y (a comparison).R7,i386,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,binary-nodem10,R10,TR2,L1,V1,R42,R7,i413,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,unary-nodem10,R10,TR2,L1,V1,R42,R7,i431,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,bytes-type?m10,R10,TR2,L1,V1,R31,R7,i444,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,runes-type?m10,R10,TR2,L1,V1,R31,R7,i445,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,conv-nodem10,R2,L1,V1,R42,R0,s49,[k node] of conversion T(x) (a non-constant one).R7,i447,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,addressable?m10,R10,TR2,L1,V1,R42,R7,i485,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,struct-ofm12,R10,TR2,L1,V1,R31,R0,s66,The struct type and its descriptor a field selection's step is on.R7,i488,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,value-placem12,R10,TR2,L1,V1,R42,R0,s112,A place holding the value of node n (of struct or array type): its own when addressable, else\n  its value's box.R7,i493,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,field-placem10,R2,L1,V1,R42,R0,s63,The place of field selection n ({:op :field :path :derefs :x}).R7,i501,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,index-placem12,R10,TR2,L1,V1,R42,R0,s78,The place of element (aget x i) of an array, a pointer to an array or a slice.R7,i520,R8,i1,R9,s18,arbace/go/build.aem10,R2,L1,V1,R42,R0,s43,The place (a P node) of addressable node n.R7,i533,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,elem-nodem12,R10,TR2,L1,V2,R36,R31,R0,s77,An element value node of type ty, as the factories take it (its kind's node).R7,i553,R8,i1,R9,s18,arbace/go/build.aem10,R2,L1,V1,R42,R0,s56,A struct or array literal as a new variable (its place).R7,i558,R8,i1,R9,s18,arbace/go/build.aem10,R10,TR2,L1,V1,R42,R7,i586,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,var-nodem10,R10,TR2,L1,V1,R40,R7,i601,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,global-nodem10,R10,TR2,L1,V1,R42,R7,i607,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build15,func-value-nodem10,R10,TR2,L1,V1,R40,R7,i610,R8,i1,R9,s18,arbace/go/build.aem10,R2,L2,V1,R42,V2,R42,R37,R0,s85,[kind node] of expression node n (want: the type a nil takes, or :B for a condition).R7,i615,R8,i1,R9,s18,arbace/go/build.aem8,R2,L1,V2,R42,R38,R7,i675,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,slot-layoutm12,R10,TR2,L1,V1,V4,R52,R53,R54,R55,R0,s153,The callee's slots of a signature [:func ps rs variadic]: the parameters', then the results',\n  numbered per kind in order (the variadic parameter an R).R7,i679,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,arg-setterm10,R10,TR2,L1,V2,V2,R38,R41,R56,R7,i689,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,mem-nodem12,R10,TR2,L1,V2,R44,R31,R0,s77,Node [k n] of type ty as compiled Go takes it (a closure as a Go func: MemR).R7,i692,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,arg-nodesm12,R10,TR2,L1,V3,R57,R6,R58,R0,s196,The argument nodes of a call to signature sig: fixed parameters', then the variadic slice's\n  (made from the trailing arguments, or the spread one); for compiled code (cmp) closures as Go\n  funcs.R7,i700,R8,i1,R9,s18,arbace/go/build.aem12,R10,TR2,L1,V1,R42,R0,s71,The call of several results n, built once: {:t T :temps [[k slot]...]}.R7,i718,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build6,sig-ofm10,R10,TR2,L1,V1,R31,R7,i727,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,static-callm10,R10,TR2,L1,V4,R59,R57,R6,R60,R7,i729,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,value-callm10,R10,TR2,L1,V4,R61,R57,R6,R60,R7,i742,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,from-memm10,R10,TR2,L1,V2,V2,R38,R42,R31,R7,i756,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build13,compiled-callm10,R10,TR2,L1,V6,R15,R39,R57,R6,R62,R60,R7,i761,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,method-callm10,R10,TR2,L1,V3,R61,R6,R60,R7,i769,R8,i1,R9,s18,arbace/go/build.aem10,R2,L2,V1,R42,V2,R42,R60,R0,s79,[kind node] of a call of one result (mode :multi, or no result: {:t T :temps}).R7,i788,R8,i1,R9,s18,arbace/go/build.ae")

var Lit_407 *jrt.String = jrt.Intern("arbace.go.build$eval367000004$loading__1927001464__auto____367000005")

var Lit_408 *jrt.String = jrt.Intern("arbace.go.build$eval367000008$fn__367000009")

var Lit_409 *jrt.String = jrt.Intern("arbace.go.build$op")

var Lit_410 *jrt.String = jrt.Intern("arbace.go.build$oa")

var Lit_411 *jrt.String = jrt.Intern("arbace.go.build$unsupported_BANG_")

var Lit_412 *jrt.String = jrt.Intern("arbace.go.build$compiled_QMARK_")

var Lit_413 *jrt.String = jrt.Intern("arbace.go.build$kind")

var Lit_414 *jrt.String = jrt.Intern("arbace.go.build$basic_of")

var Lit_415 *jrt.String = jrt.Intern("arbace.go.build$unsigned_QMARK_")

var Lit_416 *jrt.String = jrt.Intern("arbace.go.build$wide_QMARK_")

var Lit_417 *jrt.String = jrt.Intern("arbace.go.build$struct_or_array_QMARK_")

var Lit_418 *jrt.String = jrt.Intern("arbace.go.build$iface_QMARK_")

var Lit_419 *jrt.String = jrt.Intern("arbace.go.build$interpreted_named_QMARK_")

var Lit_420 *jrt.String = jrt.Intern("arbace.go.build$recursive_QMARK_")

var Lit_421 *jrt.String = jrt.Intern("arbace.go.build$tag_text")

var Lit_422 *jrt.String = jrt.Intern("arbace.go.build$struct_parts")

var Lit_423 *jrt.String = jrt.Intern("arbace.go.build$named_desc")

var Lit_424 *jrt.String = jrt.Intern("arbace.go.build$desc")

var Lit_425 *jrt.String = jrt.Intern("arbace.go.build$int_bits")

var Lit_426 *jrt.String = jrt.Intern("arbace.go.build$go_string_node")

var Lit_427 *jrt.String = jrt.Intern("arbace.go.build$complex_value")

var Lit_428 *jrt.String = jrt.Intern("arbace.go.build$const_node")

var Lit_429 *jrt.String = jrt.Intern("arbace.go.build$new_slot_BANG_")

var Lit_430 *jrt.String = jrt.Intern("arbace.go.build$next_code_BANG_")

var Lit_431 *jrt.String = jrt.Intern("arbace.go.build$label_code_BANG_")

var Lit_432 *jrt.String = jrt.Intern("arbace.go.build$label_entry")

var Lit_433 *jrt.String = jrt.Intern("arbace.go.build$cell_var_QMARK_")

var Lit_434 *jrt.String = jrt.Intern("arbace.go.build$loc")

var Lit_435 *jrt.String = jrt.Intern("arbace.go.build$new_loc_BANG_")

var Lit_436 *jrt.String = jrt.Intern("arbace.go.build$temp_BANG_")

var Lit_437 *jrt.String = jrt.Intern("arbace.go.build$local_node")

var Lit_438 *jrt.String = jrt.Intern("arbace.go.build$as_kind")

var Lit_439 *jrt.String = jrt.Intern("arbace.go.build$load_p")

var Lit_440 *jrt.String = jrt.Intern("arbace.go.build$store_p")

var Lit_441 *jrt.String = jrt.Intern("arbace.go.build$set_slot")

var Lit_442 *jrt.String = jrt.Intern("arbace.go.build$expr_stmt_of")

var Lit_443 *jrt.String = jrt.Intern("arbace.go.build$exk")

var Lit_444 *jrt.String = jrt.Intern("arbace.go.build$iface_content")

var Lit_445 *jrt.String = jrt.Intern("arbace.go.build$arith_name")

var Lit_446 *jrt.String = jrt.Intern("arbace.go.build$const_of")

var Lit_447 *jrt.String = jrt.Intern("arbace.go.build$local_slot_of")

var Lit_448 *jrt.String = jrt.Intern("arbace.go.build$int_binop")

var Lit_449 *jrt.String = jrt.Intern("arbace.go.build$float_binop")

var Lit_450 *jrt.String = jrt.Intern("arbace.go.build$binop_nodes")

var Lit_451 *jrt.String = jrt.Intern("arbace.go.build$count_node")

var Lit_452 *jrt.String = jrt.Intern("arbace.go.build$shift_node")

var Lit_453 *jrt.String = jrt.Intern("arbace.go.build$nil_node_QMARK_")

var Lit_454 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes")

var Lit_455 *jrt.String = jrt.Intern("arbace.go.build$binary_node")

var Lit_456 *jrt.String = jrt.Intern("arbace.go.build$unary_node")

var Lit_457 *jrt.String = jrt.Intern("arbace.go.build$bytes_type_QMARK_")

var Lit_458 *jrt.String = jrt.Intern("arbace.go.build$runes_type_QMARK_")

var Lit_459 *jrt.String = jrt.Intern("arbace.go.build$conv_node")

var Lit_460 *jrt.String = jrt.Intern("arbace.go.build$addressable_QMARK_")

var Lit_461 *jrt.String = jrt.Intern("arbace.go.build$struct_of")

var Lit_462 *jrt.String = jrt.Intern("arbace.go.build$value_place")

var Lit_463 *jrt.String = jrt.Intern("arbace.go.build$field_place")

var Lit_464 *jrt.String = jrt.Intern("arbace.go.build$index_place")

var Lit_465 *jrt.String = jrt.Intern("arbace.go.build$place")

var Lit_466 *jrt.String = jrt.Intern("arbace.go.build$elem_node")

var Lit_467 *jrt.String = jrt.Intern("arbace.go.build$lit_place")

var Lit_468 *jrt.String = jrt.Intern("arbace.go.build$lit_node")

var Lit_469 *jrt.String = jrt.Intern("arbace.go.build$var_node")

var Lit_470 *jrt.String = jrt.Intern("arbace.go.build$global_node")

var Lit_471 *jrt.String = jrt.Intern("arbace.go.build$func_value_node")

var Lit_472 *jrt.String = jrt.Intern("arbace.go.build$ex")

var Lit_473 *jrt.String = jrt.Intern("arbace.go.build$ex_as")

var Lit_474 *jrt.String = jrt.Intern("arbace.go.build$slot_layout")

var Lit_475 *jrt.String = jrt.Intern("arbace.go.build$arg_setter")

var Lit_476 *jrt.String = jrt.Intern("arbace.go.build$mem_node")

var Lit_477 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes")

var Lit_478 *jrt.String = jrt.Intern("arbace.go.build$call_results")

var Lit_479 *jrt.String = jrt.Intern("arbace.go.build$sig_of")

var Lit_480 *jrt.String = jrt.Intern("arbace.go.build$static_call")

var Lit_481 *jrt.String = jrt.Intern("arbace.go.build$value_call")

var Lit_482 *jrt.String = jrt.Intern("arbace.go.build$from_mem")

var Lit_483 *jrt.String = jrt.Intern("arbace.go.build$compiled_call")

var Lit_484 *jrt.String = jrt.Intern("arbace.go.build$method_call")

var Lit_485 *jrt.String = jrt.Intern("arbace.go.build$call_node")

var Lit_486 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn1,nkn3,dockn4,linekn6,columnkn4,fileyn2,tyyn4,modeyn1,syn1,pyn2,knyn3,knsyn5,nodesyn3,tysyn1,xyn1,dyn1,cyn1,tyn1,fyn4,predyn5,stmtsyn4,objsyn4,new?yn4,bodyyn3,lityn4,treeyn5,fnameyn8,capturesyn5,initsv15,arbace.go.build9,call-stmtm12,R0,TR1,L1,V1,R2,R3,s51,The statement of call n as an expression statement.R4,i806,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,elem-typem10,R0,TR1,L1,V1,R7,R4,i818,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V2,R2,R8,R3,s81,A builtin's call: [k node], {:t ...} for mode :multi, a statement for mode :stmt.R4,i820,R5,i1,R6,s18,arbace/go/build.aem10,R0,TR1,L1,V2,R8,R9,R4,i898,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,slot-of-placem12,R0,TR1,L1,V1,R10,R3,s58,[k slot] when place p is a local held in a slot, else nil.R4,i902,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,assign-tom10,R1,L1,V2,R10,R11,R3,s95,The statement assigning [k node] (of the place's type) to place p (:blank: evaluated, dropped).R4,i909,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,temps-ofm12,R0,TR1,L1,V1,R12,R3,s81,Statements evaluating nodes kns into new temporaries, and the temporaries' nodes.R4,i921,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V2,R13,R14,R3,s138,The [k node]s of the right-hand values of an assignment or declaration (comma-ok forms as\n  two), for targets of types tys (a nil's type).R4,i928,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,prepare-placem12,R0,TR1,L1,V1,R10,R3,s183,[statements place]: the operands of place p evaluated into temporaries now (an assignment's\n  first phase, §4.5: Go evaluates the places' index and pointer operands, then the values).R4,i944,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,assign-stmtm8,R1,L1,V1,R2,R4,i981,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build14,op-assign-stmtm8,R1,L1,V1,R2,R4,i990,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build6,one-ofm10,R0,TR1,L1,V1,R7,R4,i1020,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,incdec-stmtm8,R1,L1,V1,R2,R4,i1026,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,zero-initm10,R0,TR1,L1,V1,R15,R4,i1033,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,init-varm12,R0,TR1,L1,V2,R15,R11,R3,s63,The statement giving new variable x its initial value [k node].R4,i1044,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,decl-stmtm10,R1,L1,V1,R16,R3,s83,A declaration {:op :decl :objs :init}: new variables (a reused one of := assigned).R4,i1053,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build4,jumpm10,R0,TR1,L1,V1,R17,R4,i1075,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,push-targetm10,R0,TR1,L1,V2,R18,R19,R4,i1077,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,innermostm10,R0,TR1,L1,V1,R20,R4,i1079,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,block-stmtsm10,R0,TR1,L1,V1,R2,R4,i1081,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,body-nodem12,R0,TR1,L1,V1,R21,R3,s60,A statement list's node (a Seq with its labels' goto codes).R4,i1083,R5,i1,R6,s18,arbace/go/build.aem8,R1,L1,V1,R21,R4,i1091,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,block-nodem12,R0,TR1,L1,V1,R2,R3,s62,A block's node: its declarations (a let's) and its statements.R4,i1093,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,loop-targetm10,R0,TR1,L1,V1,R2,R4,i1102,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build19,per-iteration-cellsm10,R0,TR1,L1,V1,R22,R4,i1109,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,for-stmtm10,R0,TR1,L1,V1,R2,R4,i1114,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,range-targetsm12,R0,TR1,L1,V1,R2,R3,s99,The key and value targets of a range: [obj-or-place-or-nil ...] and whether they are new variables.R4,i1124,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,idx-setterm10,R0,TR1,L1,V3,R18,R23,R7,R4,i1131,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,at-setterm10,R0,TR1,L1,V3,R18,R23,R7,R4,i1142,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,any-setterm10,R0,TR1,L1,V3,R18,R23,R7,R4,i1153,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,has-call?m12,R0,TR1,L1,V1,R2,R3,s157,Whether checked node n has a call (not of a constant) or a receive in it (an array's length is\n  then not constant: the specification's len and range rules).R4,i1164,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,range-stmtm10,R0,TR1,L1,V1,R2,R4,i1175,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,switch-stmtm10,R0,TR1,L1,V1,R2,R4,i1226,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,return-stmtm10,R0,TR1,L1,V1,R2,R4,i1252,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,defer-stmtm10,R0,TR1,L1,V1,R2,R4,i1268,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V1,R2,R3,s24,The node of statement n.R4,i1303,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,has-defer?m12,R0,TR1,L1,V1,R24,R3,s71,Whether a function's body defers (not counting its function literals').R4,i1345,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,free-localsm12,R0,TR1,L1,V1,R25,R3,s135,The local variables a function literal's body refers to that it does not declare: the cells\n  it captures, in order of first reference.R4,i1358,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,build-codem10,R1,L1,V3,R26,R27,R28,R3,s131,The *goi.Code of a function node (:func, :fn, :body) with its signature sig; captures, the\n  cells it receives first (a literal's).R4,i1388,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V1,R2,R3,s55,A function literal's closure node (its code built now).R4,i1429,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,build-funcm10,R1,L1,V1,R26,R3,s83,The code of a package-level function's checked tree (built on its first call, S18).R4,i1439,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,build-initsm10,R1,L1,V1,R29,R3,s160,The code of a package's initialization: its variables' initializers in initialization order\n  (trees {:op :var-init :lhs :rhs}), as a function of no parameters.R4,i1444,R5,i1,R6,s18,arbace/go/build.ae")

var Lit_487 *jrt.String = jrt.Intern("arbace.go.build$call_stmt")

var Lit_488 *jrt.String = jrt.Intern("arbace.go.build$elem_type")

var Lit_489 *jrt.String = jrt.Intern("arbace.go.build$builtin")

var Lit_490 *jrt.String = jrt.Intern("arbace.go.build$expr_or_stmt")

var Lit_491 *jrt.String = jrt.Intern("arbace.go.build$slot_of_place")

var Lit_492 *jrt.String = jrt.Intern("arbace.go.build$assign_to")

var Lit_493 *jrt.String = jrt.Intern("arbace.go.build$temps_of")

var Lit_494 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes")

var Lit_495 *jrt.String = jrt.Intern("arbace.go.build$prepare_place")

var Lit_496 *jrt.String = jrt.Intern("arbace.go.build$assign_stmt")

var Lit_497 *jrt.String = jrt.Intern("arbace.go.build$op_assign_stmt")

var Lit_498 *jrt.String = jrt.Intern("arbace.go.build$one_of")

var Lit_499 *jrt.String = jrt.Intern("arbace.go.build$incdec_stmt")

var Lit_500 *jrt.String = jrt.Intern("arbace.go.build$zero_init")

var Lit_501 *jrt.String = jrt.Intern("arbace.go.build$init_var")

var Lit_502 *jrt.String = jrt.Intern("arbace.go.build$decl_stmt")

var Lit_503 *jrt.String = jrt.Intern("arbace.go.build$jump")

var Lit_504 *jrt.String = jrt.Intern("arbace.go.build$push_target")

var Lit_505 *jrt.String = jrt.Intern("arbace.go.build$innermost")

var Lit_506 *jrt.String = jrt.Intern("arbace.go.build$block_stmts")

var Lit_507 *jrt.String = jrt.Intern("arbace.go.build$body_node")

var Lit_508 *jrt.String = jrt.Intern("arbace.go.build$stmt_list")

var Lit_509 *jrt.String = jrt.Intern("arbace.go.build$block_node")

var Lit_510 *jrt.String = jrt.Intern("arbace.go.build$loop_target")

var Lit_511 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells")

var Lit_512 *jrt.String = jrt.Intern("arbace.go.build$for_stmt")

var Lit_513 *jrt.String = jrt.Intern("arbace.go.build$range_targets")

var Lit_514 *jrt.String = jrt.Intern("arbace.go.build$idx_setter")

var Lit_515 *jrt.String = jrt.Intern("arbace.go.build$at_setter")

var Lit_516 *jrt.String = jrt.Intern("arbace.go.build$any_setter")

var Lit_517 *jrt.String = jrt.Intern("arbace.go.build$has_call_QMARK_")

var Lit_518 *jrt.String = jrt.Intern("arbace.go.build$range_stmt")

var Lit_519 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt")

var Lit_520 *jrt.String = jrt.Intern("arbace.go.build$return_stmt")

var Lit_521 *jrt.String = jrt.Intern("arbace.go.build$defer_stmt")

var Lit_522 *jrt.String = jrt.Intern("arbace.go.build$stmt")

var Lit_523 *jrt.String = jrt.Intern("arbace.go.build$has_defer_QMARK_")

var Lit_524 *jrt.String = jrt.Intern("arbace.go.build$free_locals")

var Lit_525 *jrt.String = jrt.Intern("arbace.go.build$build_code")

var Lit_526 *jrt.String = jrt.Intern("arbace.go.build$build_fn_lit")

var Lit_527 *jrt.String = jrt.Intern("arbace.go.build$build_func")

var Lit_528 *jrt.String = jrt.Intern("arbace.go.build$build_inits")
