//line j2g_strings.ae:1
package aot_arbace_go_build

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn21,arbace.go.check.typesyn1,tyn21,arbace.go.check.constyn1,cyn19,arbace.go.check.envyn1,eyn20,arbace.go.check.codeyn4,codeyn20,arbace.go.check.declyn4,declkn3,dockn4,lineks3,goi11,unsupportedkn4,namekn3,pkgkn4,typekn8,ptr-recvkn3,objkn7,tparamskn4,funckn10,lazy-underkn9,compiled?kn1,Ikn7,float32kn7,float64kn13,untyped-floatkn1,Fkn6,stringkn14,untyped-stringkn1,Skn4,elsekn1,Rkn3,intkn5,int64kn4,uintkn6,uint64kn7,uintptrkn5,arraykn6,structkn5,targskn7,pointerkn3,mapkn5,slicekn4,chankn14,unsafe-pointerkn3,tagkn8,embeddedkn4,pathkn5,int32kn5,int16kn10,complex128kn9,interfacekn5,uint8kn9,complex64kn6,uint32kn6,uint16kn4,boolkn4,int8ks3,goi3,genkn5,typeskn11,table-type?kn5,localkn3,genkn7,invalidkn11,untyped-intkn12,untyped-boolkn15,untyped-complexkn4,recvkn4,bothkn4,sendkn12,untyped-runekn11,untyped-nilkn1,Bkn5,slotskn4,codekn6,labelskn4,gotokn9,captured?kn10,addressed?kn4,locskn4,cellkn1,Ckn4,slotkn7,tmp-logkn1,Tkn8,constantkn4,modekn7,unknownkn3,valkn2,opkn3,nilks15,arbace.go.build4,nodekn1,kkn4,nodekn5,valueks2,go2,opkn1,xkn1,ykn2,tokn8,variablekn11,place-localkn11,place-fieldkn11,place-derefkn11,place-indexkn12,place-globalkn6,derefskn5,indexkn3,ptrkn6,globalkn5,derefkn5,fieldkn3,litkn4,kindkn6,fieldskn5,elemskn3,keykn7,entrieskn9,func-cellkn6,methodkn11,method-exprkn6,resultkn4,callkn1,tkn5,tempsks15,arbace.go.build4,minikn6,binarykn2,fnkn5,unaryks15,arbace.go.build7,selrecvkn2,vskn7,indexeskn9,map-indexkn5,parenkn13,convert-ifacekn4,formkn6,assertkn12,iface-methodkn4,addrkn4,convkn6,paramskn7,resultskn6,countskn6,spreadkn5,callskn5,multikn10,recv-namedkn11,method-cellkn8,rtparamskn11,recv-adjustkn9,panicwrapkn9,recv-typekn9,pkg-scopekn5,aliaskn13,tparams-countkn5,ifacekn3,varkn6,local?kn8,indirectkn3,viakn6,calleekn4,argskn5,tuplekn5,blockkn5,stmtskn4,exprkn6,returnkn6,valueskn8,pkg-namekn3,sigkn4,bodyks3,goi8,internalkn12,methods-donekn9,ambiguousks15,arbace.go.build4,nonekn5,eagerkn4,keptkn6,statickn7,closurekn14,uintptrescapeskn7,builtinkn4,stmtkn6,unsafekn8,deferredkn9,new-valuekn5,blankks15,arbace.go.build8,map-tempkn1,mkn5,vtypekn2,mtks15,arbace.go.build6,p-tempkn1,ckn9,place-mapkn8,comma-okkn2,okkn3,okskn3,lhskn3,rhskn5,placekn3,inckn5,constkn4,objskn4,initkn3,letkn8,let-typekn5,declskn5,startkn5,afterkn5,moveskn2,ifkn3,forkn11,type-switchkn7,clauseskn4,thenkn6,switchkn5,rangekn5,labelkn6,selectkn4,declkn4,commkn7,targetskn4,overkn6,placeskn11,fallthroughkn9,has-deferkn5,breakkn8,continuekn10,local-typekn9,op-assignkn4,condkn4,postkn6,incdeckn9,directivekn6,assignkn2,gokn5,deferkn10,decl-labelkn4,planks3,goi5,labelkn4,loopkn3,brkkn4,contkn2,idkn14,per-iteration?ks15,arbace.go.build4,tempkn9,ptr-arraykn7,defaultkn4,fallkn3,lockn2,chkn2,ctkn4,bindks3,goi4,origkn8,tag-typekn4,refskn4,casekn7,gc-namekn3,dirks2,go3,endkn4,textkn9,line-dirskn6,sourcekn3,srckn4,filekn7,go-filekn7,gc-litskn6,gc-litkn9,lit-countkn6,originkn3,allkn5,termskn10,comparablekn5,unionks3,goi6,vargenks3,goi9,implicitskn10,underlyingkn4,treeks15,arbace.go.build8,nil-typekn6,ctx-ofv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.go.buildm2,R14,s1640,goi's builder (doc/go/GOI-SPEC.md §4.1): the checked tree (§3.7) made nodes, typed Go\n  closures of the back end arbace/goi, by its factories through arbace.lang.GoInterp's op\n  native (go/arbace/goi/registry.ae). It numbers each function's slots per kind (parameters and\n  results first, as the signature lays them out), makes the variables that live in Go memory\n  cells (captured, addressed, of a struct or array type, every package variable), gives each\n  jump target its codes, chooses each node's variant by its operands' types, and resolves each\n  call to the callee's cell, a closure, or the table's member. It decides nothing the checker\n  has not: no type, no constant, no resolution.\n\n  GR3 builds the interpreter's core: scalars, strings, slices, arrays, maps, structs, pointers,\n  functions and closures, all control flow with labels and goto, defer, panic and recover,\n  interface values without methods (§5.3 rules 1 and 2), the calls of compiled Go. GR4 adds\n  methods (their receiver laid after the parameters and results), method values and\n  expressions, the method sets of the types that go into interfaces (each entry the method or a\n  thunk: §5.3), interface method calls, type assertions and switches, embedding and promotion,\n  goroutines, channels, select and range over functions and channels. GR6 adds generics (§9.2):\n  each instance of a generic function, method or type built per type-argument list from the\n  generic declaration's checked tree with its type parameters substituted (inst-tree). A form\n  that needs what goi does not run is \"not supported by goi yet\" (§3.4), an ex-info with\n  :goi/unsupported.v15,arbace.go.build2,opl0,R15,v15,arbace.go.build11,*stmt-line*v11,arbace.core4,not=v15,arbace.go.build12,code-frames?v15,arbace.go.build10,at-line-i?v15,arbace.go.build9,frame-fn*v11,arbace.core7,ex-infoR16,v15,arbace.go.build12,program-modev11,arbace.core7,ex-datav11,arbace.core5,flushv11,arbace.core19,pop-thread-bindingsv11,arbace.core7,printlnv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*R17,v19,arbace.go.check.env1,oR18,v21,arbace.go.check.types9,exported?R19,R20,R21,R22,R23,R24,v21,arbace.go.check.types4,infov20,arbace.go.check.decl15,instance-under!v15,arbace.go.build5,*ctx*v21,arbace.go.check.types12,*method-obj*v15,arbace.go.build11,method-datav21,arbace.go.check.types14,*subst-method*v20,arbace.go.check.decl12,subst-methodv21,arbace.go.check.types15,*resolve-named*v15,arbace.go.build18,complete-instance!R25,v21,arbace.go.check.types8,type-strv21,arbace.go.check.types5,canonv21,arbace.go.check.types5,underv11,arbace.core8,keyword?v15,arbace.go.build7,int-kwsR26,S3,R27,R28,R29,R30,S2,R31,R32,R33,R34,R35,v21,arbace.go.check.types8,untyped?v21,arbace.go.check.types12,default-typev21,arbace.go.check.types9,unsigned?v11,arbace.core9,contains?S5,R36,R37,R38,R39,R40,v15,arbace.go.build8,basic-ofv11,arbace.core7,vector?S2,R41,R42,v21,arbace.go.check.types10,interface?v11,arbace.core3,notv21,arbace.go.check.types7,tparam?v21,arbace.go.check.types6,named?v11,arbace.core3,seqR43,v15,arbace.go.build10,inst-type?v15,arbace.go.build9,compiled?v15,arbace.go.build18,interpreted-named?R44,R41,R45,R46,R47,v11,arbace.core4,someR42,v15,arbace.go.build10,recursive?v15,arbace.go.build10,shape-typeR48,V2,R46,R48,v11,arbace.core4,mapvv11,arbace.core5,assocR49,R50,v21,arbace.go.check.const10,value-textv15,arbace.go.build2,oav11,arbace.core3,mapv15,arbace.go.build4,descv15,arbace.go.build8,tag-textR51,v15,arbace.go.build15,*iface-pending*v15,arbace.go.build22,set-iface-methods-now!v15,arbace.go.build10,method-keyR52,l5,R53,l4,R54,l16,R40,l12,v15,arbace.go.build12,unsupported!v15,arbace.go.build4,tstrl21,l17,l18,R55,l20,R27,l13,R56,l8,R28,l14,R37,l6,R57,l15,R58,l10,R59,l9,R39,l11,R31,l24,R38,l7,l26,R60,l1,R61,l3,R36,l2,l23,l19,l22,l25,R62,v11,arbace.core5,swap!v15,arbace.go.build9,local-genv11,arbace.core3,incv21,arbace.go.check.types12,update-info!v15,arbace.go.build11,named-desc1v15,arbace.go.build10,desc-typesR63,R64,v15,arbace.go.build8,inst-genR65,v15,arbace.go.build12,local-gen-ofR66,v15,arbace.go.build14,inst-type-nameR67,v15,arbace.go.build12,reflect-kindv15,arbace.go.build12,method-countv15,arbace.go.build18,set-iface-methods!v15,arbace.go.build14,layout-needed?v11,arbace.core10,ex-messagev13,arbace.string9,includes?v15,arbace.go.build12,struct-partsv15,arbace.go.build17,*methods-pending*v15,arbace.go.build18,set-named-methods!v15,arbace.go.build5,desc1R68,R69,R29,R70,v11,arbace.core4,namev15,arbace.go.build10,named-descR71,R72,R73,v11,arbace.core6,empty?R74,R32,R75,v11,arbace.core10,bigintegerv11,arbace.core6,every?v21,arbace.go.check.const11,complex-valv21,arbace.go.check.const9,to-doublev11,arbace.core8,boolean?R76,S2,R54,R57,S2,R27,R28,v15,arbace.go.build13,complex-valuev15,arbace.go.build14,go-string-nodev15,arbace.go.build8,int-bitsv11,arbace.core8,integer?v21,arbace.go.check.const7,int-valR77,v15,arbace.go.build4,*fn*v11,arbace.core6,updateR78,R79,v11,arbace.core9,volatile!R80,v15,arbace.go.build10,next-code!R81,R82,v15,arbace.go.build16,struct-or-array?R83,v15,arbace.go.build9,cell-var?R84,v15,arbace.go.build9,new-slot!R85,R86,v15,arbace.go.build4,kindR87,S2,R35,R33,v15,arbace.go.build7,as-kindR88,v15,arbace.go.build2,exv15,arbace.go.build6,iface?v15,arbace.go.build15,ensure-methods!m18,s1,*s3,Muls1,%s3,Rems6,bit-ors2,Ors1,/s3,Divs1,-s3,Subs7,bit-xors3,Xors7,bit-ands3,Ands11,bit-and-nots6,AndNots1,+s3,AddR89,R90,R91,R92,R93,v15,arbace.go.build7,int-sfxv15,arbace.go.build10,arith-namev15,arbace.go.build8,const-ofv15,arbace.go.build13,local-slot-ofv15,arbace.go.build5,wide?S3,s1,*s1,-s1,+S3,s1,*s1,-s1,+v15,arbace.go.build3,exkS2,s2,>>s2,<<v15,arbace.go.build9,unsigned?v15,arbace.go.build11,float-binopv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core5,firstv21,arbace.go.check.const8,complex?v21,arbace.go.check.const7,re-partv15,arbace.go.build10,count-nodeR94,v15,arbace.go.build9,nil-node?v15,arbace.go.build5,temp!v15,arbace.go.build6,load-pv15,arbace.go.build10,local-nodeR95,R96,R97,R98,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv15,arbace.go.build13,compare-nodesv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core6,reducev15,arbace.go.build8,set-slotv15,arbace.go.build8,cmp-namev15,arbace.go.build13,iface-contentv11,arbace.core5,rangeS2,R47,R44,R99,R100,R101,S2,s2,>>s2,<<v15,arbace.go.build10,shift-nodev15,arbace.go.build9,int-binopR102,v15,arbace.go.build11,bytes-type?v15,arbace.go.build11,runes-type?S2,R54,R57,S2,R54,R57,S2,R47,R23,R103,S5,R104,R105,R106,R107,R108,v15,arbace.go.build12,addressable?v15,arbace.go.build5,placeR109,v15,arbace.go.build11,value-placev11,arbace.core1,+v11,arbace.core11,map-indexedv15,arbace.go.build5,uidx?v11,arbace.core4,takev15,arbace.go.build13,at-index-lineR110,R108,R111,R112,R107,v15,arbace.go.build11,index-placeR113,v15,arbace.go.build3,locR105,v15,arbace.go.build11,field-placeR114,R106,R104,R115,v15,arbace.go.build9,lit-placeR116,v11,arbace.core6,removeR117,v21,arbace.go.check.types8,pointer?v11,arbace.core4,longv15,arbace.go.build9,elem-nodeR118,v11,arbace.core6,repeatV1,l0,v11,arbace.core6,secondv15,arbace.go.build8,lit-nodev11,arbace.core5,applyv11,arbace.core3,maxR119,R120,v15,arbace.go.build13,instance-cellR121,S5,R41,R44,R46,R42,R45,v15,arbace.go.build6,coercev15,arbace.go.build3,ex*S1,R94,v15,arbace.go.build10,const-nodeR122,v15,arbace.go.build17,method-value-nodeR123,v15,arbace.go.build16,method-expr-nodev15,arbace.go.build8,var-nodeR124,v15,arbace.go.build12,call-resultsR125,R126,R127,R128,R129,v15,arbace.go.build11,binary-nodev15,arbace.go.build9,elem-typeR130,R131,v15,arbace.go.build10,unary-nodev15,arbace.go.build12,build-fn-litR132,v21,arbace.go.check.types12,string-type?R133,v11,arbace.core6,concatR134,v15,arbace.go.build9,uidx-maskv15,arbace.go.build11,global-nodeR135,v15,arbace.go.build9,call-nodeR136,R137,v11,arbace.core6,pr-strR138,v15,arbace.go.build15,func-value-nodeR139,v15,arbace.go.build9,assert-knR140,v15,arbace.go.build23,iface-method-value-nodeR141,R142,v15,arbace.go.build9,conv-nodem8,R26,l0,R30,l0,R33,l0,R35,l0,v11,arbace.core3,vecR143,R144,R145,v15,arbace.go.build11,slot-layoutv15,arbace.go.build14,mem-converted?v15,arbace.go.build8,mem-nodev15,arbace.go.build8,kill-argv11,arbace.core4,lastv11,arbace.core4,dropR146,R147,R148,v11,arbace.core3,strv11,arbace.core4,compv15,arbace.go.build9,arg-nodesv15,arbace.go.build10,arg-setterv15,arbace.go.build9,cell-callv15,arbace.go.build8,from-memv15,arbace.go.build18,compiled-call-nodeR149,R150,R151,v15,arbace.go.build15,generic-method?v15,arbace.go.build11,method-cellv15,arbace.go.build12,recv-type-ofv11,arbace.core6,zipmapv20,arbace.go.check.decl5,substv15,arbace.go.build11,path-derefsv11,arbace.core5,true?v11,arbace.core3,popR152,R153,v15,arbace.go.build9,field-selv15,arbace.go.build6,sig-ofv15,arbace.go.build13,method-targetR154,v15,arbace.go.build9,recv-nodeR155,R156,R157,v21,arbace.go.check.types22,identical-ignore-tags?v21,arbace.go.check.types14,missing-methodv11,arbace.core7,sort-byv11,arbace.core3,keyv21,arbace.go.check.types10,deref-typev15,arbace.go.build9,via-ifacev15,arbace.go.build13,compiled-callv15,arbace.go.build18,interp-method-callv15,arbace.go.build15,iface-recv-nodeR158,v15,arbace.go.build11,error-type?v15,arbace.go.build15,compiled-iface?v11,arbace.core4,map?v19,arbace.go.check.env3,objR159,R160,R161,R162,v21,arbace.go.check.types11,method-datav15,arbace.go.build9,local-refR163,R164,v11,arbace.core4,intoV1,R165,R166,R167,R168,R169,R170,v15,arbace.go.build9,local-objv15,arbace.go.build9,selectionR171,v15,arbace.go.build10,build-codeR172,R173,v15,arbace.go.build10,thunk-bodyv21,arbace.go.check.types11,lookup-implv15,arbace.go.build6,isubstv21,arbace.go.check.types10,methods-ofv11,arbace.core3,setv15,arbace.go.build13,methods-givenv13,arbace.string4,joinv11,arbace.core4,sortR174,R175,v15,arbace.go.build17,may-have-methods?S2,R122,R140,R176,v13,arbace.string12,starts-with?V2,R177,nR177,R178,v15,arbace.go.build18,build-method-thunkv15,arbace.go.build6,lazilyv15,arbace.go.build8,with-ctxS2,R122,R140,V2,R177,nv11,arbace.core4,keepv15,arbace.go.build17,method-candidatesv15,arbace.go.build19,check-methods-kept!S2,R122,R140,S2,R122,R140,v21,arbace.go.check.types16,empty-interface?v15,arbace.go.build7,rt-namev15,arbace.go.build11,assert-descv15,arbace.go.build10,iface-nameR179,R180,R181,v19,arbace.go.check.env4,obj?R182,v11,arbace.core12,keep-indexedv15,arbace.go.build9,ptr-conv?v15,arbace.go.build10,call-node*v15,arbace.go.build8,kept-argv11,arbace.core6,vectorv15,arbace.go.build11,slots-clearv15,arbace.go.build13,call-escapes?v15,arbace.go.build9,keep-callv15,arbace.go.build10,iface-callv15,arbace.go.build11,method-callv15,arbace.go.build11,static-callv15,arbace.go.build10,value-callR183,v15,arbace.go.build7,builtinR184,v15,arbace.go.build12,expr-stmt-ofR185,R186,v15,arbace.go.build12,expr-or-stmtR187,V1,l0,S2,R104,R65,R188,R189,R190,R191,R192,R193,v15,arbace.go.build7,store-pR194,v15,arbace.go.build13,slot-of-placeR195,R196,R197,v15,arbace.go.build9,rhs-nodesV2,nnR198,S2,R104,R65,S2,R105,R114,S2,R44,R46,R199,v15,arbace.go.build9,assign-toR200,v15,arbace.go.build13,prepare-placev15,arbace.go.build8,temps-ofv11,arbace.core6,mapcatR201,S2,s2,>>s2,<<v15,arbace.go.build11,binop-nodesS2,s2,>>s2,<<S2,s2,>>s2,<<V3,R194,l1,l0,v15,arbace.go.build14,op-assign-stmtR202,R203,v15,arbace.go.build6,one-ofv15,arbace.go.build8,new-loc!d0,R204,R205,v15,arbace.go.build9,zero-initv15,arbace.go.build8,init-varv15,arbace.go.build8,ref-skipv11,arbace.core11,sequential?v15,arbace.go.build9,walk-objsv15,arbace.go.build6,id-setv11,arbace.core5,some?S2,R35,R33,R206,R207,R208,v15,arbace.go.build7,refs-ofv15,arbace.go.build9,plan-listR209,v15,arbace.go.build10,simple-opsv15,arbace.go.build12,terminal-opsR210,R211,v11,arbace.core5,mergev15,arbace.go.build10,plan-blockR212,R213,R214,R215,R216,R217,R218,R219,R220,R221,R222,v15,arbace.go.build9,plan-stmtv15,arbace.go.build8,plan-fn*v15,arbace.go.build9,live-off?v15,arbace.go.build9,has-goto?v15,arbace.go.build10,candidatesv15,arbace.go.build9,clear-op?S2,R35,R33,R223,v11,arbace.core6,filterv15,arbace.go.build9,stmt-listv15,arbace.go.build12,quiet-basic?v15,arbace.go.build12,quiet-const?S4,s3,nots1,-s7,bit-nots1,+v15,arbace.go.build11,quiet-expr?v11,arbace.core8,not-any?v15,arbace.go.build14,quiet-builtinsS2,s2,ors3,andv15,arbace.go.build15,quiet-cmp-type?S2,s2,>>s2,<<S2,s1,%s1,/S2,R35,R30,v15,arbace.go.build13,quiet-header?S5,R36,R31,R41,R46,R45,R224,v15,arbace.go.build12,quiet-place?v11,arbace.core4,nil?R225,R226,R227,R228,R229,R230,R231,S2,s2,>>s2,<<S2,s1,%s1,/S2,R35,R30,R232,v15,arbace.go.build19,quiet-block-header?R233,R234,R235,R236,v15,arbace.go.build12,hoisted-lineS2,R213,R218,S8,R237,R231,R238,R236,R221,R168,R73,R234,v15,arbace.go.build9,stmt-linev15,arbace.go.build4,stmtv15,arbace.go.build11,stored-linev15,arbace.go.build11,label-code!R239,v11,arbace.core4,pos?v15,arbace.go.build9,body-nodeR240,v15,arbace.go.build14,clear-slots-ofv15,arbace.go.build16,with-temp-clearsv15,arbace.go.build9,decl-stmtv15,arbace.go.build11,start-clearR241,R242,R243,R244,R245,v15,arbace.go.build11,label-entryR246,v15,arbace.go.build11,loop-targetv15,arbace.go.build19,per-iteration-cellsv15,arbace.go.build11,push-targetv15,arbace.go.build9,loop-bodyR247,v15,arbace.go.build9,has-call?v11,arbace.core4,valsv11,arbace.core6,dissocR248,V2,nnV2,R36,R52,v15,arbace.go.build13,range-targetsv15,arbace.go.build16,range-elem-typesv11,arbace.core7,filtervv15,arbace.go.build11,assign-stmtv15,arbace.go.build10,any-setterv15,arbace.go.build10,idx-setterv15,arbace.go.build9,at-setterv11,arbace.core8,identityV2,nnv11,arbace.core5,doallv21,arbace.go.check.types13,boolean-type?R249,R250,v15,arbace.go.build4,jumpR251,m8,R26,l0,R30,l0,R33,l0,R35,l0,v15,arbace.go.build9,call-stmtv15,arbace.go.build13,deferred-callv11,arbace.core7,vreset!R238,R252,l-1,R253,R254,v15,arbace.go.build12,at-case-linev15,arbace.go.build11,select-recvR237,v15,arbace.go.build7,go-stmtv15,arbace.go.build11,incdec-stmtv15,arbace.go.build10,defer-stmtv15,arbace.go.build10,range-stmtv15,arbace.go.build9,send-stmtv15,arbace.go.build10,block-nodev15,arbace.go.build11,switch-stmtv15,arbace.go.build16,type-switch-stmtv15,arbace.go.build11,select-stmtv15,arbace.go.build9,innermostS2,R242,R217,v15,arbace.go.build11,return-stmtR255,v15,arbace.go.build8,for-stmtv15,arbace.go.build5,stmt*R256,R257,S16,R158,R122,R257,R154,R143,R92,R114,R19,R256,R172,R159,R138,R21,R204,R102,R144,S16,R158,R122,R257,R154,R143,R92,R114,R19,R256,R172,R159,R138,R21,R204,R102,R144,R258,S2,R104,R65,v11,arbace.core4,keysR259,v15,arbace.go.build9,gc-prefixR260,R261,v11,arbace.core4,seq?v20,arbace.go.check.code9,head-namev20,arbace.go.check.code5,flinev11,arbace.core7,string?R262,V6,R167,R173,R216,R34,R215,R184,v15,arbace.go.build8,code-endR263,v11,arbace.core4,subsv11,arbace.core7,re-findp22,^(.*):([0-9]+):[0-9]+$p15,^(.*):([0-9]+)$v15,arbace.go.build12,gc-func-nameR264,R265,R266,R267,v15,arbace.go.build10,has-defer?R268,R269,v15,arbace.go.build7,plan-fnv15,arbace.go.build10,line-dirs!v15,arbace.go.build11,code-frame!S2,R35,R33,S2,R35,R33,v15,arbace.go.build11,free-localsR270,m10,R26,l0,R30,l0,R33,l0,R35,l0,R85,l0,v11,arbace.core3,minR271,v20,arbace.go.check.decl11,instantiateR272,v21,arbace.go.check.types10,terms-normR165,V1,R165,v21,arbace.go.check.types12,sort-methodsv21,arbace.go.check.types9,make-tsetR273,R274,R275,v15,arbace.go.build9,skip-keysv15,arbace.go.build9,type-keysv20,arbace.go.check.code14,representationS1,R140,v11,arbace.core11,persistent!v11,arbace.core9,reduce-kvv11,arbace.core6,assoc!v15,arbace.go.build8,obj-keysv15,arbace.go.build9,objs-keysv11,arbace.core9,transientv15,arbace.go.build10,resolve-onS2,R158,R122,S2,R122,R140,S3,s7,Alignofs6,Sizeofs8,Offsetofv21,arbace.go.check.types6,sizeofv20,arbace.go.check.code14,offsetof-valuev21,arbace.go.check.types7,alignofv21,arbace.go.check.types11,const-type?v20,arbace.go.check.code10,conversionv11,arbace.core11,select-keysV2,R90,R92,v15,arbace.go.build11,local-typesv21,arbace.go.check.types9,new-namedV6,R21,R17,R18,R171,R65,R276,R277,R278,V6,R21,R17,R18,R171,R65,R276,v15,arbace.go.build9,inst-treev21,arbace.go.check.types11,basic-namesS2,s22,command-line-argumentss4,mainv15,arbace.go.build8,sym-namev15,arbace.go.build6,rt-sigR276,v15,arbace.go.build9,inst-gensR279,v15,arbace.go.build14,instance-cell*R280,v15,arbace.go.build9,instancesR281,v15,arbace.go.build13,instance-nameV1,s7,reflectv15,arbace.go.build14,build-instance")

var Lit_1 *jrt.String = jrt.Intern("AnySlot")

var Lit_2 *jrt.String = jrt.Intern("AnyNewCell")

var Lit_3 *jrt.String = jrt.Intern("AnyCell")

var Lit_4 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_5 *jrt.String = jrt.Intern("AnyPlace")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes$fn__367000323")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes$fn__367000325")

var Lit_8 *jrt.String = jrt.Intern("MakeSliceOf")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes$fn__367000327")

var Lit_10 *jrt.String = jrt.Intern("ArgF")

var Lit_11 *jrt.String = jrt.Intern("ArgI")

var Lit_12 *jrt.String = jrt.Intern("ArgR")

var Lit_13 *jrt.String = jrt.Intern("ArgS")

var Lit_14 *jrt.String = jrt.Intern("BI")

var Lit_15 *jrt.String = jrt.Intern("IB")

var Lit_16 *jrt.String = jrt.Intern("goi's builder: a ")

var Lit_17 *jrt.String = jrt.Intern(" node where a ")

var Lit_18 *jrt.String = jrt.Intern(" is wanted")

var Lit_19 *jrt.String = jrt.Intern("AssertF")

var Lit_20 *jrt.String = jrt.Intern("AssertI")

var Lit_21 *jrt.String = jrt.Intern("AssertR")

var Lit_22 *jrt.String = jrt.Intern("AssertS")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.build$assign_stmt$fn__367000729")

var Lit_24 *jrt.String = jrt.Intern("Assign")

var Lit_25 *jrt.String = jrt.Intern("MapSet")

var Lit_26 *jrt.String = jrt.Intern("CellP")

var Lit_27 *jrt.String = jrt.Intern("AtLineR")

var Lit_28 *jrt.String = jrt.Intern("AtLineI")

var Lit_29 *jrt.String = jrt.Intern("AtSlot")

var Lit_30 *jrt.String = jrt.Intern("AtNewCell")

var Lit_31 *jrt.String = jrt.Intern("AtCell")

var Lit_32 *jrt.String = jrt.Intern("AtPlace")

var Lit_33 *jrt.String = jrt.Intern("and")

var Lit_34 *jrt.String = jrt.Intern("AndB")

var Lit_35 *jrt.String = jrt.Intern("or")

var Lit_36 *jrt.String = jrt.Intern("OrB")

var Lit_37 *jrt.String = jrt.Intern("K")

var Lit_38 *jrt.String = jrt.Intern("F32")

var Lit_39 *jrt.String = jrt.Intern("F64")

var Lit_40 *jrt.String = jrt.Intern("C64")

var Lit_41 *jrt.String = jrt.Intern("C128")

var Lit_42 *jrt.String = jrt.Intern("ConcatS")

var Lit_43 *jrt.String = jrt.Intern("<<")

var Lit_44 *jrt.String = jrt.Intern("Shl")

var Lit_45 *jrt.String = jrt.Intern("Shr")

var Lit_46 *jrt.String = jrt.Intern("U")

var Lit_47 *jrt.String = jrt.Intern("")

var Lit_48 *jrt.String = jrt.Intern("arbace.go.build$block_node$fn__367001015")

var Lit_49 *jrt.String = jrt.Intern("Seq")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.build$block_node$fn__367001019")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.build$block_node$fn__367001021")

var Lit_52 *jrt.String = jrt.Intern("SeqL")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.build$block_node$fn__367001015$fn__367001016")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.build$body_node$fn__367001004")

var Lit_55 *jrt.String = jrt.Intern("arbace.go.build$body_node$fn__367001006")

var Lit_56 *jrt.String = jrt.Intern("ProCell")

var Lit_57 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367001497__367001501")

var Lit_58 *jrt.String = jrt.Intern("ClearSlots")

var Lit_59 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367001521__367001525")

var Lit_60 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367001537__367001541")

var Lit_61 *jrt.String = jrt.Intern("NewCode")

var Lit_62 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367001497__367001501$fn__367001502")

var Lit_63 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367001497__367001501$fn__367001502$fn__367001503")

var Lit_64 *jrt.String = jrt.Intern("ProNewCell")

var Lit_65 *jrt.String = jrt.Intern("EpiCell")

var Lit_66 *jrt.String = jrt.Intern("ProZeroR")

var Lit_67 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367001521__367001525$fn__367001526")

var Lit_68 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367001521__367001525$fn__367001526$fn__367001527")

var Lit_69 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367001537__367001541$fn__367001542")

var Lit_70 *jrt.String = jrt.Intern("arbace.go.build$build_code$iter__367001537__367001541$fn__367001542$fn__367001543")

var Lit_71 *jrt.String = jrt.Intern(".func")

var Lit_72 *jrt.String = jrt.Intern(".")

var Lit_73 *jrt.String = jrt.Intern("FuncCell")

var Lit_74 *jrt.String = jrt.Intern("FuncSource")

var Lit_75 *jrt.String = jrt.Intern("SetCode")

var Lit_76 *jrt.String = jrt.Intern("MakeClosure")

var Lit_77 *jrt.String = jrt.Intern("arbace.go.build$build_fn_lit$fn__367001559")

var Lit_78 *jrt.String = jrt.Intern("a function without a body (assembly)")

var Lit_79 *jrt.String = jrt.Intern("out of scope: §1.1")

var Lit_80 *jrt.String = jrt.Intern("init")

var Lit_81 *jrt.String = jrt.Intern(".init")

var Lit_82 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001569__367001573")

var Lit_83 *jrt.String = jrt.Intern("arbace.go.build$build_inits$fn__367001589")

var Lit_84 *jrt.String = jrt.Intern("arbace.go.build$build_inits$fn__367001592")

var Lit_85 *jrt.String = jrt.Intern("FrameFn")

var Lit_86 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001569__367001573$fn__367001574")

var Lit_87 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001569__367001573$fn__367001574$fn__367001575")

var Lit_88 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001569__367001573$fn__367001574$fn__367001582")

var Lit_89 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001569__367001573$fn__367001574$fn__367001585")

var Lit_90 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001569__367001573$fn__367001574$fn__367001575$fn__367001576")

var Lit_91 *jrt.String = jrt.Intern("arbace.go.build$build_inits$iter__367001569__367001573$fn__367001574$fn__367001575$fn__367001579")

var Lit_92 *jrt.String = jrt.Intern("_")

var Lit_93 *jrt.String = jrt.Intern("the generic function ")

var Lit_94 *jrt.String = jrt.Intern(" (its body is not in the forms)")

var Lit_95 *jrt.String = jrt.Intern("GR6")

var Lit_96 *jrt.String = jrt.Intern("r")

var Lit_97 *jrt.String = jrt.Intern("arbace.go.build$build_method_thunk$fn__367000453")

var Lit_98 *jrt.String = jrt.Intern("arbace.go.build$build_method_thunk$fn__367000455")

var Lit_99 *jrt.String = jrt.Intern("CodeWrapper")

var Lit_100 *jrt.String = jrt.Intern("p")

var Lit_101 *jrt.String = jrt.Intern("arbace.go.build$builtin$value__367000607")

var Lit_102 *jrt.String = jrt.Intern("Add")

var Lit_103 *jrt.String = jrt.Intern("UnsafeAdd")

var Lit_104 *jrt.String = jrt.Intern("make")

var Lit_105 *jrt.String = jrt.Intern("MakeMap")

var Lit_106 *jrt.String = jrt.Intern("MakeSlice")

var Lit_107 *jrt.String = jrt.Intern("MakeChan")

var Lit_108 *jrt.String = jrt.Intern("panic")

var Lit_109 *jrt.String = jrt.Intern("Panic")

var Lit_110 *jrt.String = jrt.Intern("StmtT")

var Lit_111 *jrt.String = jrt.Intern("recover")

var Lit_112 *jrt.String = jrt.Intern("DeferredRecover")

var Lit_113 *jrt.String = jrt.Intern("Recover")

var Lit_114 *jrt.String = jrt.Intern("StringData")

var Lit_115 *jrt.String = jrt.Intern("UnsafeStringData")

var Lit_116 *jrt.String = jrt.Intern("String")

var Lit_117 *jrt.String = jrt.Intern("UnsafeString")

var Lit_118 *jrt.String = jrt.Intern("Slice")

var Lit_119 *jrt.String = jrt.Intern("UnsafeSlice")

var Lit_120 *jrt.String = jrt.Intern("real")

var Lit_121 *jrt.String = jrt.Intern("RealF")

var Lit_122 *jrt.String = jrt.Intern("imag")

var Lit_123 *jrt.String = jrt.Intern("ImagF")

var Lit_124 *jrt.String = jrt.Intern("complex")

var Lit_125 *jrt.String = jrt.Intern("ComplexR")

var Lit_126 *jrt.String = jrt.Intern("cap")

var Lit_127 *jrt.String = jrt.Intern("CapSlice")

var Lit_128 *jrt.String = jrt.Intern("CapChan")

var Lit_129 *jrt.String = jrt.Intern("ThenI")

var Lit_130 *jrt.String = jrt.Intern("ConstI")

var Lit_131 *jrt.String = jrt.Intern("cap of ")

var Lit_132 *jrt.String = jrt.Intern("GR4")

var Lit_133 *jrt.String = jrt.Intern("delete")

var Lit_134 *jrt.String = jrt.Intern("Delete")

var Lit_135 *jrt.String = jrt.Intern("len")

var Lit_136 *jrt.String = jrt.Intern("LenS")

var Lit_137 *jrt.String = jrt.Intern("LenSlice")

var Lit_138 *jrt.String = jrt.Intern("LenMap")

var Lit_139 *jrt.String = jrt.Intern("LenChan")

var Lit_140 *jrt.String = jrt.Intern("len of ")

var Lit_141 *jrt.String = jrt.Intern("max")

var Lit_142 *jrt.String = jrt.Intern("MinMaxF")

var Lit_143 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000621")

var Lit_144 *jrt.String = jrt.Intern("MinMaxI")

var Lit_145 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000623")

var Lit_146 *jrt.String = jrt.Intern("MinMaxS")

var Lit_147 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000625")

var Lit_148 *jrt.String = jrt.Intern("min")

var Lit_149 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000628")

var Lit_150 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000630")

var Lit_151 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000632")

var Lit_152 *jrt.String = jrt.Intern("SliceData")

var Lit_153 *jrt.String = jrt.Intern("UnsafeSliceData")

var Lit_154 *jrt.String = jrt.Intern("new")

var Lit_155 *jrt.String = jrt.Intern("AddrOf")

var Lit_156 *jrt.String = jrt.Intern("LitP")

var Lit_157 *jrt.String = jrt.Intern("NewR")

var Lit_158 *jrt.String = jrt.Intern("copy")

var Lit_159 *jrt.String = jrt.Intern("CopyString")

var Lit_160 *jrt.String = jrt.Intern("Copy")

var Lit_161 *jrt.String = jrt.Intern("print")

var Lit_162 *jrt.String = jrt.Intern("Print")

var Lit_163 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000637__367000641")

var Lit_164 *jrt.String = jrt.Intern("println")

var Lit_165 *jrt.String = jrt.Intern("clear")

var Lit_166 *jrt.String = jrt.Intern("ClearMap")

var Lit_167 *jrt.String = jrt.Intern("ClearSlice")

var Lit_168 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000647__367000651")

var Lit_169 *jrt.String = jrt.Intern("append")

var Lit_170 *jrt.String = jrt.Intern("AppendString")

var Lit_171 *jrt.String = jrt.Intern("AppendSpread")

var Lit_172 *jrt.String = jrt.Intern("Append")

var Lit_173 *jrt.String = jrt.Intern("arbace.go.build$builtin$fn__367000660")

var Lit_174 *jrt.String = jrt.Intern("close")

var Lit_175 *jrt.String = jrt.Intern("Close")

var Lit_176 *jrt.String = jrt.Intern("the builtin ")

var Lit_177 *jrt.String = jrt.Intern("unsafe.")

var Lit_178 *jrt.String = jrt.Intern("GR3")

var Lit_179 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000637__367000641$fn__367000642")

var Lit_180 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000637__367000641$fn__367000642$fn__367000643")

var Lit_181 *jrt.String = jrt.Intern("PrintArg")

var Lit_182 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000647__367000651$fn__367000652")

var Lit_183 *jrt.String = jrt.Intern("arbace.go.build$builtin$iter__367000647__367000651$fn__367000652$fn__367000653")

var Lit_184 *jrt.String = jrt.Intern("the call kind ")

var Lit_185 *jrt.String = jrt.Intern("ExprT")

var Lit_186 *jrt.String = jrt.Intern("arbace.go.build$candidates$cand_QMARK___367000799")

var Lit_187 *jrt.String = jrt.Intern("arbace.go.build$candidates$fn__367000803")

var Lit_188 *jrt.String = jrt.Intern("arbace.go.build$candidates$cand_QMARK___367000799$fn__367000800")

var Lit_189 *jrt.String = jrt.Intern("Call")

var Lit_190 *jrt.String = jrt.Intern("arbace.go.build$cell_call$fn__367000336")

var Lit_191 *jrt.String = jrt.Intern("resCopies")

var Lit_192 *jrt.String = jrt.Intern("CallT")

var Lit_193 *jrt.String = jrt.Intern(", ")

var Lit_194 *jrt.String = jrt.Intern("arbace.go.build$code_end$fn__367001420")

var Lit_195 *jrt.String = jrt.Intern("CodeFrame")

var Lit_196 *jrt.String = jrt.Intern("ConvR")

var Lit_197 *jrt.String = jrt.Intern("IsNilR")

var Lit_198 *jrt.String = jrt.Intern("==")

var Lit_199 *jrt.String = jrt.Intern("NotB")

var Lit_200 *jrt.String = jrt.Intern("R")

var Lit_201 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$fn__367000181")

var Lit_202 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$field__367000183")

var Lit_203 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$iter__367000188__367000192")

var Lit_204 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$fn__367000198")

var Lit_205 *jrt.String = jrt.Intern("ConstB")

var Lit_206 *jrt.String = jrt.Intern("ThenB")

var Lit_207 *jrt.String = jrt.Intern("F")

var Lit_208 *jrt.String = jrt.Intern("I")

var Lit_209 *jrt.String = jrt.Intern("LK")

var Lit_210 *jrt.String = jrt.Intern("LL")

var Lit_211 *jrt.String = jrt.Intern("PtrToUnsafe")

var Lit_212 *jrt.String = jrt.Intern("S")

var Lit_213 *jrt.String = jrt.Intern("FieldP")

var Lit_214 *jrt.String = jrt.Intern("BoxP")

var Lit_215 *jrt.String = jrt.Intern("FieldOff")

var Lit_216 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$iter__367000188__367000192$fn__367000193")

var Lit_217 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes$iter__367000188__367000192$fn__367000193$fn__367000194")

var Lit_218 *jrt.String = jrt.Intern("CallCompiled")

var Lit_219 *jrt.String = jrt.Intern("arbace.go.build$compiled_call_node$fn__367000362")

var Lit_220 *jrt.String = jrt.Intern("CvC64")

var Lit_221 *jrt.String = jrt.Intern("ConstR")

var Lit_222 *jrt.String = jrt.Intern("ConstF")

var Lit_223 *jrt.String = jrt.Intern("a constant of type ")

var Lit_224 *jrt.String = jrt.Intern("Cv")

var Lit_225 *jrt.String = jrt.Intern("Uto")

var Lit_226 *jrt.String = jrt.Intern("Ito")

var Lit_227 *jrt.String = jrt.Intern("Fto")

var Lit_228 *jrt.String = jrt.Intern("CvF32")

var Lit_229 *jrt.String = jrt.Intern("StrFromRune")

var Lit_230 *jrt.String = jrt.Intern("StrFromBytes")

var Lit_231 *jrt.String = jrt.Intern("StrFromRunes")

var Lit_232 *jrt.String = jrt.Intern("BytesFromStr")

var Lit_233 *jrt.String = jrt.Intern("RunesFromStr")

var Lit_234 *jrt.String = jrt.Intern("CvC128")

var Lit_235 *jrt.String = jrt.Intern("UintptrToUnsafe")

var Lit_236 *jrt.String = jrt.Intern("UnsafeToUintptr")

var Lit_237 *jrt.String = jrt.Intern("UnsafeToPtr")

var Lit_238 *jrt.String = jrt.Intern("SliceToArray")

var Lit_239 *jrt.String = jrt.Intern("SliceToArrayPtr")

var Lit_240 *jrt.String = jrt.Intern("the conversion ")

var Lit_241 *jrt.String = jrt.Intern(" to ")

var Lit_242 *jrt.String = jrt.Intern("Nop")

var Lit_243 *jrt.String = jrt.Intern("arbace.go.build$decl_stmt$fn__367000751")

var Lit_244 *jrt.String = jrt.Intern("arbace.go.build$decl_stmt$target__367000753")

var Lit_245 *jrt.String = jrt.Intern("Defer")

var Lit_246 *jrt.String = jrt.Intern("arbace.go.build$deferred_call$to_mini__367001199")

var Lit_247 *jrt.String = jrt.Intern("arbace.go.build$deferred_call$fn__367001201")

var Lit_248 *jrt.String = jrt.Intern("NonNilR")

var Lit_249 *jrt.String = jrt.Intern("deferring a call of kind ")

var Lit_250 *jrt.String = jrt.Intern("arbace.go.build$deferred_call$fn__367001206")

var Lit_251 *jrt.String = jrt.Intern("ThenT")

var Lit_252 *jrt.String = jrt.Intern("ThenR")

var Lit_253 *jrt.String = jrt.Intern("arbace.go.build$desc$fn__367000106")

var Lit_254 *jrt.String = jrt.Intern("arbace.go.build$desc$fn__367000108")

var Lit_255 *jrt.String = jrt.Intern("a value of type ")

var Lit_256 *jrt.String = jrt.Intern("an invalid type")

var Lit_257 *jrt.String = jrt.Intern("TBasic")

var Lit_258 *jrt.String = jrt.Intern("unsafe.Pointer")

var Lit_259 *jrt.String = jrt.Intern("goi's builder: the type parameter ")

var Lit_260 *jrt.String = jrt.Intern(" of an uninstantiated tree")

var Lit_261 *jrt.String = jrt.Intern("TMap")

var Lit_262 *jrt.String = jrt.Intern("TArray")

var Lit_263 *jrt.String = jrt.Intern("TChan")

var Lit_264 *jrt.String = jrt.Intern("any")

var Lit_265 *jrt.String = jrt.Intern("TIface")

var Lit_266 *jrt.String = jrt.Intern("TSlice")

var Lit_267 *jrt.String = jrt.Intern("TFunc")

var Lit_268 *jrt.String = jrt.Intern("TPtr")

var Lit_269 *jrt.String = jrt.Intern("TStruct")

var Lit_270 *jrt.String = jrt.Intern("the type ")

var Lit_271 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000493__367000497")

var Lit_272 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$fn__367000543")

var Lit_273 *jrt.String = jrt.Intern("TSetMethods")

var Lit_274 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$fn__367000545")

var Lit_275 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$fn__367000547")

var Lit_276 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$fn__367000549")

var Lit_277 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$fn__367000551")

var Lit_278 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000493__367000497$fn__367000498")

var Lit_279 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000493__367000497$fn__367000498$fn__367000499")

var Lit_280 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000493__367000497$fn__367000498$fn__367000527")

var Lit_281 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000493__367000497$fn__367000498$fn__367000534")

var Lit_282 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000493__367000497$fn__367000498$fn__367000537")

var Lit_283 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000493__367000497$fn__367000498$fn__367000499$fn__367000506")

var Lit_284 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000493__367000497$fn__367000498$fn__367000499$fn__367000513")

var Lit_285 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000493__367000497$fn__367000498$fn__367000499$fn__367000516")

var Lit_286 *jrt.String = jrt.Intern("goi: no method ")

var Lit_287 *jrt.String = jrt.Intern("not supported by goi yet")

var Lit_288 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000493__367000497$fn__367000498$fn__367000499$fn__367000516$fn__367000517")

var Lit_289 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_$iter__367000493__367000497$fn__367000498$fn__367000537$fn__367000538")

var Lit_290 *jrt.String = jrt.Intern("error")

var Lit_291 *jrt.String = jrt.Intern("arbace.lang.GoInterp")

var Lit_292 *jrt.String = jrt.Intern("java.util.HashMap")

var Lit_293 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_294 *jrt.String = jrt.Intern("ThenF")

var Lit_295 *jrt.String = jrt.Intern("ThenS")

var Lit_296 *jrt.String = jrt.Intern("Recv")

var Lit_297 *jrt.String = jrt.Intern("DerefP")

var Lit_298 *jrt.String = jrt.Intern("IndexS")

var Lit_299 *jrt.String = jrt.Intern("arbace.go.build$ex_STAR_$fn__367000292")

var Lit_300 *jrt.String = jrt.Intern("SliceString")

var Lit_301 *jrt.String = jrt.Intern("SliceSlice")

var Lit_302 *jrt.String = jrt.Intern("SliceArray")

var Lit_303 *jrt.String = jrt.Intern("MapGet")

var Lit_304 *jrt.String = jrt.Intern("ZeroR")

var Lit_305 *jrt.String = jrt.Intern("a type of a package not in the table, in ")

var Lit_306 *jrt.String = jrt.Intern("GR5")

var Lit_307 *jrt.String = jrt.Intern("the expression ")

var Lit_308 *jrt.String = jrt.Intern("ExprB")

var Lit_309 *jrt.String = jrt.Intern("ExprF")

var Lit_310 *jrt.String = jrt.Intern("ExprI")

var Lit_311 *jrt.String = jrt.Intern("ExprR")

var Lit_312 *jrt.String = jrt.Intern("ExprS")

var Lit_313 *jrt.String = jrt.Intern("LoadR")

var Lit_314 *jrt.String = jrt.Intern("arbace.go.build$field_sel$fn__367000377")

var Lit_315 *jrt.String = jrt.Intern("arbace.go.build$file_line_dirs$walk__367001423")

var Lit_316 *jrt.String = jrt.Intern("go/directive")

var Lit_317 *jrt.String = jrt.Intern("//line ")

var Lit_318 *jrt.String = jrt.Intern("0")

var Lit_319 *jrt.String = jrt.Intern("GOI_LIVENESS")

var Lit_320 *jrt.String = jrt.Intern("arbace.go.build$for_stmt$fn__367001037")

var Lit_321 *jrt.String = jrt.Intern("For")

var Lit_322 *jrt.String = jrt.Intern("arbace.go.build$free_locals$walk__367001380")

var Lit_323 *jrt.String = jrt.Intern("arbace.go.build$free_locals$fn__367001413")

var Lit_324 *jrt.String = jrt.Intern("FromMemR")

var Lit_325 *jrt.String = jrt.Intern("FuncValue")

var Lit_326 *jrt.String = jrt.Intern("MemberValue")

var Lit_327 *jrt.String = jrt.Intern("[...]")

var Lit_328 *jrt.String = jrt.Intern("(*")

var Lit_329 *jrt.String = jrt.Intern(")")

var Lit_330 *jrt.String = jrt.Intern("main")

var Lit_331 *jrt.String = jrt.Intern("GoStmt")

var Lit_332 *jrt.String = jrt.Intern("arbace.go.build$go_string_node$fn__367000127")

var Lit_333 *jrt.String = jrt.Intern("ConstS")

var Lit_334 *jrt.String = jrt.Intern("ConstSB")

var Lit_335 *jrt.String = jrt.Intern("arbace.go.build$go_string_node$fn__367000129")

var Lit_336 *jrt.String = jrt.Intern("arbace.go.build$has_defer_QMARK_$walk__367001368")

var Lit_337 *jrt.String = jrt.Intern("arbace.go.build$has_goto_QMARK_$walk__367000790")

var Lit_338 *jrt.String = jrt.Intern("arbace.go.build$has_goto_QMARK_$walk__367000790$fn__367000792")

var Lit_339 *jrt.String = jrt.Intern("IdxSlot")

var Lit_340 *jrt.String = jrt.Intern("IdxNewCell")

var Lit_341 *jrt.String = jrt.Intern("IdxStore")

var Lit_342 *jrt.String = jrt.Intern("arbace.go.build$iface_call$fn__367000421")

var Lit_343 *jrt.String = jrt.Intern("ErrorCall")

var Lit_344 *jrt.String = jrt.Intern("CompiledDispatchT")

var Lit_345 *jrt.String = jrt.Intern("CompiledDispatch")

var Lit_346 *jrt.String = jrt.Intern("CallIfaceT")

var Lit_347 *jrt.String = jrt.Intern("Then")

var Lit_348 *jrt.String = jrt.Intern("CallIface")

var Lit_349 *jrt.String = jrt.Intern("IfaceI")

var Lit_350 *jrt.String = jrt.Intern("IfaceF")

var Lit_351 *jrt.String = jrt.Intern("IfaceR")

var Lit_352 *jrt.String = jrt.Intern("IfaceS")

var Lit_353 *jrt.String = jrt.Intern("IfaceMethodValue")

var Lit_354 *jrt.String = jrt.Intern("interface {}")

var Lit_355 *jrt.String = jrt.Intern("+")

var Lit_356 *jrt.String = jrt.Intern("-")

var Lit_357 *jrt.String = jrt.Intern("SliceElemP")

var Lit_358 *jrt.String = jrt.Intern("ArrayElemP")

var Lit_359 *jrt.String = jrt.Intern("indexing ")

var Lit_360 *jrt.String = jrt.Intern("NewCellInit")

var Lit_361 *jrt.String = jrt.Intern("arbace.go.build$inst_tree$ty__367001648")

var Lit_362 *jrt.String = jrt.Intern("arbace.go.build$inst_tree$obj__367001650")

var Lit_363 *jrt.String = jrt.Intern("arbace.go.build$inst_tree$const_fix__367001652")

var Lit_364 *jrt.String = jrt.Intern("arbace.go.build$inst_tree$node__367001657")

var Lit_365 *jrt.String = jrt.Intern("arbace.go.build$inst_tree$node__367001657$fn__367001658")

var Lit_366 *jrt.String = jrt.Intern("Sizeof")

var Lit_367 *jrt.String = jrt.Intern("Offsetof")

var Lit_368 *jrt.String = jrt.Intern("Alignof")

var Lit_369 *jrt.String = jrt.Intern("InterpMethodCallable")

var Lit_370 *jrt.String = jrt.Intern("InterpCallable")

var Lit_371 *jrt.String = jrt.Intern("reflect")

var Lit_372 *jrt.String = jrt.Intern("TypeFor")

var Lit_373 *jrt.String = jrt.Intern("goiNilType")

var Lit_374 *jrt.String = jrt.Intern("goi: TypeFor of an interpreted interface")

var Lit_375 *jrt.String = jrt.Intern("reflect.TypeFor of the interpreted interface ")

var Lit_376 *jrt.String = jrt.Intern(": its reflect type is any (§5.2)")

var Lit_377 *jrt.String = jrt.Intern("G8")

var Lit_378 *jrt.String = jrt.Intern("arbace.go.build$instance_cell_STAR_$fn__367001709")

var Lit_379 *jrt.String = jrt.Intern("arbace.go.build$instance_cell_STAR_$fn__367001711")

var Lit_380 *jrt.String = jrt.Intern("arbace.go.build$instance_cell_STAR_$fn__367001711$fn__367001712")

var Lit_381 *jrt.String = jrt.Intern(").")

var Lit_382 *jrt.String = jrt.Intern("LK64")

var Lit_383 *jrt.String = jrt.Intern("LL64")

var Lit_384 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001603")

var Lit_385 *jrt.String = jrt.Intern("arbace.go.build$isubst$terms__367001605")

var Lit_386 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001614")

var Lit_387 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001616")

var Lit_388 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001618")

var Lit_389 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001620")

var Lit_390 *jrt.String = jrt.Intern("arbace.go.build$isubst$fn__367001622")

var Lit_391 *jrt.String = jrt.Intern("arbace.go.build$isubst$terms__367001605$fn__367001607")

var Lit_392 *jrt.String = jrt.Intern("Jump")

var Lit_393 *jrt.String = jrt.Intern("arbace.go.build$keep_call$fn__367000580")

var Lit_394 *jrt.String = jrt.Intern("arbace.go.build$keep_call$fn__367000582")

var Lit_395 *jrt.String = jrt.Intern("arbace.go.build$keep_call$fn__367000584")

var Lit_396 *jrt.String = jrt.Intern("arbace.go.build$keep_call$fn__367000587")

var Lit_397 *jrt.String = jrt.Intern("arbace.go.build$kill_arg$iter__367000940__367000944")

var Lit_398 *jrt.String = jrt.Intern("KillR")

var Lit_399 *jrt.String = jrt.Intern("KillS")

var Lit_400 *jrt.String = jrt.Intern("arbace.go.build$kill_arg$iter__367000940__367000944$fn__367000945")

var Lit_401 *jrt.String = jrt.Intern("arbace.go.build$kill_arg$iter__367000940__367000944$fn__367000945$fn__367000946")

var Lit_402 *jrt.String = jrt.Intern("arbace.go.build$layout_needed_QMARK_$walk__367000055")

var Lit_403 *jrt.String = jrt.Intern("arbace.go.build$layout_needed_QMARK_$walk__367000055$fn__367000057")

var Lit_404 *jrt.String = jrt.Intern("arbace.go.build$layout_needed_QMARK_$walk__367000055$fn__367000059")

var Lit_405 *jrt.String = jrt.Intern("arbace.go.build$layout_needed_QMARK_$walk__367000055$fn__367000061")

var Lit_406 *jrt.String = jrt.Intern("arbace.go.build$lazily$fn__367000025")

var Lit_407 *jrt.String = jrt.Intern("arbace.go.build$lazily$fn__367000025$fn__367000026")

var Lit_408 *jrt.String = jrt.Intern("goi: unsupported: ")

var Lit_409 *jrt.String = jrt.Intern("arbace.go.build$line_dirs_BANG_$walk__367001444")

var Lit_410 *jrt.String = jrt.Intern("arbace.go.build$line_dirs_BANG_$fn__367001449")

var Lit_411 *jrt.String = jrt.Intern("arbace.go.build$line_dirs_BANG_$fn__367001451")

var Lit_412 *jrt.String = jrt.Intern("arbace.go.build$line_dirs_BANG_$fn__367001453")

var Lit_413 *jrt.String = jrt.Intern("CodeLineDirs")

var Lit_414 *jrt.String = jrt.Intern("arbace.go.build$line_dirs_BANG_$fn__367001464")

var Lit_415 *jrt.String = jrt.Intern("arbace.go.build$line_dirs_BANG_$fn__367001466")

var Lit_416 *jrt.String = jrt.Intern("arbace.go.build$line_dirs_BANG_$fn__367001468")

var Lit_417 *jrt.String = jrt.Intern("arbace.go.build$line_dirs_BANG_$walk__367001444$fn__367001445")

var Lit_418 *jrt.String = jrt.Intern("LitMap")

var Lit_419 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000259")

var Lit_420 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000261")

var Lit_421 *jrt.String = jrt.Intern("LitSlice")

var Lit_422 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000263")

var Lit_423 *jrt.String = jrt.Intern("arbace.go.build$lit_node$fn__367000265")

var Lit_424 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000226")

var Lit_425 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000228__367000232")

var Lit_426 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000242")

var Lit_427 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000244")

var Lit_428 *jrt.String = jrt.Intern("ElemSize")

var Lit_429 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000246")

var Lit_430 *jrt.String = jrt.Intern("arbace.go.build$lit_place$fn__367000248")

var Lit_431 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000228__367000232$fn__367000233")

var Lit_432 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000228__367000232$fn__367000233$fn__367000234")

var Lit_433 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000228__367000232$fn__367000233$fn__367000238")

var Lit_434 *jrt.String = jrt.Intern("arbace.go.build$lit_place$iter__367000228__367000232$fn__367000233$fn__367000234$fn__367000235")

var Lit_435 *jrt.String = jrt.Intern("a literal key promoted through a pointer")

var Lit_436 *jrt.String = jrt.Intern("LoadF")

var Lit_437 *jrt.String = jrt.Intern("LoadI")

var Lit_438 *jrt.String = jrt.Intern("LoadS")

var Lit_439 *jrt.String = jrt.Intern("goi's builder: no location for ")

var Lit_440 *jrt.String = jrt.Intern("LocalF")

var Lit_441 *jrt.String = jrt.Intern("LocalI")

var Lit_442 *jrt.String = jrt.Intern("LocalR")

var Lit_443 *jrt.String = jrt.Intern("LocalS")

var Lit_444 *jrt.String = jrt.Intern("arbace.go.build$local_types$walk__367001625")

var Lit_445 *jrt.String = jrt.Intern("MemR")

var Lit_446 *jrt.String = jrt.Intern("GR8a")

var Lit_447 *jrt.String = jrt.Intern("arbace.go.build$method_candidates$walk__367000464")

var Lit_448 *jrt.String = jrt.Intern("arbace.go.build$method_count$iter__367000554__367000558")

var Lit_449 *jrt.String = jrt.Intern("arbace.go.build$method_count$iter__367000554__367000558$fn__367000559")

var Lit_450 *jrt.String = jrt.Intern("arbace.go.build$method_count$iter__367000554__367000558$fn__367000559$fn__367000560")

var Lit_451 *jrt.String = jrt.Intern("arbace.go.build$method_expr_node$fn__367000458")

var Lit_452 *jrt.String = jrt.Intern("-fm")

var Lit_453 *jrt.String = jrt.Intern("arbace.go.build$method_expr_node$fn__367000461")

var Lit_454 *jrt.String = jrt.Intern("BoundCompiled")

var Lit_455 *jrt.String = jrt.Intern("MethodValue")

var Lit_456 *jrt.String = jrt.Intern("TCompiled")

var Lit_457 *jrt.String = jrt.Intern("TNamedIface")

var Lit_458 *jrt.String = jrt.Intern("TNamed")

var Lit_459 *jrt.String = jrt.Intern("TShape")

var Lit_460 *jrt.String = jrt.Intern("arbace.go.build$named_desc1$fn__367000099")

var Lit_461 *jrt.String = jrt.Intern("TSetUnder")

var Lit_462 *jrt.String = jrt.Intern("used before it is complete")

var Lit_463 *jrt.String = jrt.Intern(", recursive, used before it is complete")

var Lit_464 *jrt.String = jrt.Intern("as built: GR9a-c")

var Lit_465 *jrt.String = jrt.Intern("SetC")

var Lit_466 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells$fn__367001028")

var Lit_467 *jrt.String = jrt.Intern("RenewCells")

var Lit_468 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells$fn__367001030")

var Lit_469 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells$fn__367001032")

var Lit_470 *jrt.String = jrt.Intern("VarP")

var Lit_471 *jrt.String = jrt.Intern("GlobalP")

var Lit_472 *jrt.String = jrt.Intern("goi's builder: ")

var Lit_473 *jrt.String = jrt.Intern(" is not a cell")

var Lit_474 *jrt.String = jrt.Intern("the address of a ")

var Lit_475 *jrt.String = jrt.Intern("arbace.go.build$plan_block$iter__367000810__367000814")

var Lit_476 *jrt.String = jrt.Intern("arbace.go.build$plan_block$iter__367000810__367000814$fn__367000815")

var Lit_477 *jrt.String = jrt.Intern("arbace.go.build$plan_block$iter__367000810__367000814$fn__367000815$fn__367000816")

var Lit_478 *jrt.String = jrt.Intern("GOI_LIVENESS_TRACE")

var Lit_479 *jrt.String = jrt.Intern("arbace.go.build$plan_fn$fn__367000857")

var Lit_480 *jrt.String = jrt.Intern("liveness: no plan:")

var Lit_481 *jrt.String = jrt.Intern("isEmpty")

var Lit_482 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_$iter__367000863__367000867")

var Lit_483 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_$iter__367000873__367000877")

var Lit_484 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_$fn__367000883")

var Lit_485 *jrt.String = jrt.Intern("liveness")

var Lit_486 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_$fn__367000883$fn__367000889")

var Lit_487 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_$fn__367000883$fn__367000895")

var Lit_488 *jrt.String = jrt.Intern("  ")

var Lit_489 *jrt.String = jrt.Intern("after")

var Lit_490 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_$fn__367000883$fn__367000903")

var Lit_491 *jrt.String = jrt.Intern("start")

var Lit_492 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_$fn__367000883$fn__367000905")

var Lit_493 *jrt.String = jrt.Intern("moves")

var Lit_494 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_$fn__367000883$fn__367000907")

var Lit_495 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_$fn__367000883$fn__367000912")

var Lit_496 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_$fn__367000883$fn__367000914")

var Lit_497 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_$fn__367000883$fn__367000916")

var Lit_498 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_$iter__367000863__367000867$fn__367000868")

var Lit_499 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_$iter__367000863__367000867$fn__367000868$fn__367000869")

var Lit_500 *jrt.String = jrt.Intern("containsKey")

var Lit_501 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_$iter__367000873__367000877$fn__367000878")

var Lit_502 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_$iter__367000873__367000877$fn__367000878$fn__367000879")

var Lit_503 *jrt.String = jrt.Intern("arbace.go.build$plan_list$iter__367000846__367000850")

var Lit_504 *jrt.String = jrt.Intern("arbace.go.build$plan_list$iter__367000846__367000850$fn__367000851")

var Lit_505 *jrt.String = jrt.Intern("arbace.go.build$plan_list$iter__367000846__367000850$fn__367000851$fn__367000852")

var Lit_506 *jrt.String = jrt.Intern("arbace.go.build$plan_stmt$sub__367000821")

var Lit_507 *jrt.String = jrt.Intern("arbace.go.build$prepare_place$freeze__367000719")

var Lit_508 *jrt.String = jrt.Intern("arbace.go.build$prepare_place$chain__367000721")

var Lit_509 *jrt.String = jrt.Intern("arbace.go.build$quiet_expr_QMARK_$fn__367000980")

var Lit_510 *jrt.String = jrt.Intern("arbace.go.build$quiet_expr_QMARK_$fn__367000982")

var Lit_511 *jrt.String = jrt.Intern("arbace.go.build$quiet_expr_QMARK_$fn__367000984")

var Lit_512 *jrt.String = jrt.Intern("arbace.go.build$quiet_expr_QMARK_$fn__367000986")

var Lit_513 *jrt.String = jrt.Intern("arbace.go.build$quiet_header_QMARK_$fn__367000996")

var Lit_514 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$conv_QMARK___367001082")

var Lit_515 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001085")

var Lit_516 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001090")

var Lit_517 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001092")

var Lit_518 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001095")

var Lit_519 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$mk__367001103")

var Lit_520 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001111")

var Lit_521 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001113")

var Lit_522 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001115")

var Lit_523 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001117")

var Lit_524 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001119")

var Lit_525 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001121")

var Lit_526 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001123")

var Lit_527 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001125")

var Lit_528 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001127")

var Lit_529 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001129")

var Lit_530 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001131")

var Lit_531 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001139")

var Lit_532 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001142")

var Lit_533 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$fn__367001147")

var Lit_534 *jrt.String = jrt.Intern("RangeFunc")

var Lit_535 *jrt.String = jrt.Intern("RangeMap")

var Lit_536 *jrt.String = jrt.Intern("RangeInt")

var Lit_537 *jrt.String = jrt.Intern("RangeArray")

var Lit_538 *jrt.String = jrt.Intern("RangePtrArray")

var Lit_539 *jrt.String = jrt.Intern("RangeChan")

var Lit_540 *jrt.String = jrt.Intern("RangeString")

var Lit_541 *jrt.String = jrt.Intern("RangeSlice")

var Lit_542 *jrt.String = jrt.Intern("arbace.go.build$range_stmt$mk__367001103$fn__367001104")

var Lit_543 *jrt.String = jrt.Intern("arbace.go.build$range_targets$fn__367001042")

var Lit_544 *jrt.String = jrt.Intern("arbace.go.build$range_targets$fn__367001044")

var Lit_545 *jrt.String = jrt.Intern("arbace.go.build$recursive_QMARK_$walk__367000046")

var Lit_546 *jrt.String = jrt.Intern("arbace.go.build$recursive_QMARK_$walk__367000046$fn__367000048")

var Lit_547 *jrt.String = jrt.Intern("DerefWrapP")

var Lit_548 *jrt.String = jrt.Intern("goi's builder: no receiver type for the method ")

var Lit_549 *jrt.String = jrt.Intern("a named type of ")

var Lit_550 *jrt.String = jrt.Intern("arbace.go.build$refs_of$fn__367000782")

var Lit_551 *jrt.String = jrt.Intern("goi's builder: no method ")

var Lit_552 *jrt.String = jrt.Intern(" of ")

var Lit_553 *jrt.String = jrt.Intern("arbace.go.build$return_stmt$store__367001190")

var Lit_554 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000698")

var Lit_555 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000703")

var Lit_556 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000705")

var Lit_557 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000707")

var Lit_558 *jrt.String = jrt.Intern("Assert2")

var Lit_559 *jrt.String = jrt.Intern("MapGet2")

var Lit_560 *jrt.String = jrt.Intern("Recv2")

var Lit_561 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes$fn__367000713")

var Lit_562 *jrt.String = jrt.Intern("int32")

var Lit_563 *jrt.String = jrt.Intern("uint8")

var Lit_564 *jrt.String = jrt.Intern("main.")

var Lit_565 *jrt.String = jrt.Intern("map[")

var Lit_566 *jrt.String = jrt.Intern("]")

var Lit_567 *jrt.String = jrt.Intern("[")

var Lit_568 *jrt.String = jrt.Intern("<-chan ")

var Lit_569 *jrt.String = jrt.Intern("chan ")

var Lit_570 *jrt.String = jrt.Intern("chan<- ")

var Lit_571 *jrt.String = jrt.Intern("interface { ")

var Lit_572 *jrt.String = jrt.Intern(" }")

var Lit_573 *jrt.String = jrt.Intern("; ")

var Lit_574 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001670__367001674")

var Lit_575 *jrt.String = jrt.Intern("[]")

var Lit_576 *jrt.String = jrt.Intern("func")

var Lit_577 *jrt.String = jrt.Intern("*")

var Lit_578 *jrt.String = jrt.Intern("struct {}")

var Lit_579 *jrt.String = jrt.Intern("struct { ")

var Lit_580 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001680__367001684")

var Lit_581 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001670__367001674$fn__367001675")

var Lit_582 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001670__367001674$fn__367001675$fn__367001676")

var Lit_583 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001680__367001684$fn__367001685")

var Lit_584 *jrt.String = jrt.Intern("arbace.go.build$rt_name$iter__367001680__367001684$fn__367001685$fn__367001686")

var Lit_585 *jrt.String = jrt.Intern(" ")

var Lit_586 *jrt.String = jrt.Intern("(")

var Lit_587 *jrt.String = jrt.Intern("arbace.go.build$rt_sig$fn__367001695")

var Lit_588 *jrt.String = jrt.Intern(" (")

var Lit_589 *jrt.String = jrt.Intern("...")

var Lit_590 *jrt.String = jrt.Intern("arbace.go.build$select_recv$find_recv__367001249")

var Lit_591 *jrt.String = jrt.Intern("arbace.go.build$select_recv$replace_recv__367001251")

var Lit_592 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367001257__367001261")

var Lit_593 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$fn__367001279")

var Lit_594 *jrt.String = jrt.Intern("Select")

var Lit_595 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367001257__367001261$fn__367001262")

var Lit_596 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367001257__367001261$fn__367001262$fn__367001263")

var Lit_597 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367001257__367001261$fn__367001262$fn__367001271")

var Lit_598 *jrt.String = jrt.Intern("NewSelCase")

var Lit_599 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367001257__367001261$fn__367001262$fn__367001275")

var Lit_600 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367001257__367001261$fn__367001262$fn__367001263$fn__367001264")

var Lit_601 *jrt.String = jrt.Intern("arbace.go.build$select_stmt$iter__367001257__367001261$fn__367001262$fn__367001263$fn__367001268")

var Lit_602 *jrt.String = jrt.Intern("Send")

var Lit_603 *jrt.String = jrt.Intern("arbace.go.build$set_iface_methods_now_BANG_$sig__367000087")

var Lit_604 *jrt.String = jrt.Intern("TSetIfaceMethods")

var Lit_605 *jrt.String = jrt.Intern("arbace.go.build$set_iface_methods_now_BANG_$fn__367000089")

var Lit_606 *jrt.String = jrt.Intern("SetF")

var Lit_607 *jrt.String = jrt.Intern("SetI")

var Lit_608 *jrt.String = jrt.Intern("SetR")

var Lit_609 *jrt.String = jrt.Intern("SetS")

var Lit_610 *jrt.String = jrt.Intern("arbace.go.build$shape_type$fn__367000067")

var Lit_611 *jrt.String = jrt.Intern("arbace.go.build$slot_layout$take_BANG___367000304")

var Lit_612 *jrt.String = jrt.Intern("arbace.go.build$slot_layout$fn__367000306")

var Lit_613 *jrt.String = jrt.Intern("arbace.go.build$slot_layout$fn__367000308")

var Lit_614 *jrt.String = jrt.Intern("arbace.go.build$slots_clear$fn__367000922")

var Lit_615 *jrt.String = jrt.Intern("arbace.go.build$slots_clear$fn__367000924")

var Lit_616 *jrt.String = jrt.Intern("arbace.go.build$stmt$node_fn__367001327")

var Lit_617 *jrt.String = jrt.Intern("arbace.go.build$stmt$fn__367001329")

var Lit_618 *jrt.String = jrt.Intern("arbace.go.build$stmt$fn__367001331")

var Lit_619 *jrt.String = jrt.Intern("arbace.go.build$stmt$iter__367001333__367001337")

var Lit_620 *jrt.String = jrt.Intern("arbace.go.build$stmt$iter__367001349__367001353")

var Lit_621 *jrt.String = jrt.Intern("arbace.go.build$stmt$iter__367001333__367001337$fn__367001338")

var Lit_622 *jrt.String = jrt.Intern("arbace.go.build$stmt$iter__367001333__367001337$fn__367001338$fn__367001339")

var Lit_623 *jrt.String = jrt.Intern("arbace.go.build$stmt$iter__367001349__367001353$fn__367001354")

var Lit_624 *jrt.String = jrt.Intern("arbace.go.build$stmt$iter__367001349__367001353$fn__367001354$fn__367001355")

var Lit_625 *jrt.String = jrt.Intern("If")

var Lit_626 *jrt.String = jrt.Intern("goi's builder: fallthrough outside a switch")

var Lit_627 *jrt.String = jrt.Intern("goi's builder: no continue target ")

var Lit_628 *jrt.String = jrt.Intern("arbace.go.build$stmt_STAR_$fn__367001285")

var Lit_629 *jrt.String = jrt.Intern("goi's builder: no break target ")

var Lit_630 *jrt.String = jrt.Intern("arbace.go.build$stmt_STAR_$fn__367001287")

var Lit_631 *jrt.String = jrt.Intern("the statement ")

var Lit_632 *jrt.String = jrt.Intern("StoreF")

var Lit_633 *jrt.String = jrt.Intern("StoreI")

var Lit_634 *jrt.String = jrt.Intern("StoreR")

var Lit_635 *jrt.String = jrt.Intern("StoreS")

var Lit_636 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000075")

var Lit_637 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000077")

var Lit_638 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000079")

var Lit_639 *jrt.String = jrt.Intern("arbace.go.build$struct_parts$fn__367000081")

var Lit_640 *jrt.String = jrt.Intern("command-line-arguments")

var Lit_641 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367001153")

var Lit_642 *jrt.String = jrt.Intern("Switch")

var Lit_643 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367001153$iter__367001154__367001158")

var Lit_644 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367001153$iter__367001154__367001158$fn__367001159")

var Lit_645 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367001153$iter__367001154__367001158$fn__367001159$fn__367001160")

var Lit_646 *jrt.String = jrt.Intern("NewCase")

var Lit_647 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367001153$iter__367001154__367001158$fn__367001159$iter__367001174__367001178")

var Lit_648 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367001153$iter__367001154__367001158$fn__367001159$fn__367001184")

var Lit_649 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367001153$iter__367001154__367001158$fn__367001159$fn__367001160$iter__367001161__367001165")

var Lit_650 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367001153$iter__367001154__367001158$fn__367001159$fn__367001160$fn__367001171")

var Lit_651 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367001153$iter__367001154__367001158$fn__367001159$fn__367001160$iter__367001161__367001165$fn__367001166")

var Lit_652 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367001153$iter__367001154__367001158$fn__367001159$fn__367001160$iter__367001161__367001165$fn__367001166$fn__367001167")

var Lit_653 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367001153$iter__367001154__367001158$fn__367001159$iter__367001174__367001178$fn__367001179")

var Lit_654 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt$fn__367001153$iter__367001154__367001158$fn__367001159$iter__367001174__367001178$fn__367001179$fn__367001180")

var Lit_655 *jrt.String = jrt.Intern(",")

var Lit_656 *jrt.String = jrt.Intern(";")

var Lit_657 *jrt.String = jrt.Intern("·")

var Lit_658 *jrt.String = jrt.Intern("arbace.go.build$temps_of$fn__367000673")

var Lit_659 *jrt.String = jrt.Intern("arbace.go.build$temps_of$fn__367000680")

var Lit_660 *jrt.String = jrt.Intern("arbace.go.build$temps_of$fn__367000689")

var Lit_661 *jrt.String = jrt.Intern("arbace.go.build$thunk_body$fn__367000447")

var Lit_662 *jrt.String = jrt.Intern("arbace.go.build$thunk_body$fn__367000450")

var Lit_663 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367001226__367001230")

var Lit_664 *jrt.String = jrt.Intern("TypeSwitch")

var Lit_665 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367001226__367001230$fn__367001231")

var Lit_666 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367001226__367001230$fn__367001231$fn__367001232")

var Lit_667 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367001226__367001230$fn__367001231$fn__367001240")

var Lit_668 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367001226__367001230$fn__367001231$fn__367001242")

var Lit_669 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367001226__367001230$fn__367001231$fn__367001244")

var Lit_670 *jrt.String = jrt.Intern("NewTCase")

var Lit_671 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367001226__367001230$fn__367001231$fn__367001232$fn__367001233")

var Lit_672 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367001226__367001230$fn__367001231$fn__367001232$fn__367001235")

var Lit_673 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt$iter__367001226__367001230$fn__367001231$fn__367001232$fn__367001237")

var Lit_674 *jrt.String = jrt.Intern("arbace.go.build$uidx_mask$fn__367000215")

var Lit_675 *jrt.String = jrt.Intern("bit-not")

var Lit_676 *jrt.String = jrt.Intern("Compl")

var Lit_677 *jrt.String = jrt.Intern("NegF")

var Lit_678 *jrt.String = jrt.Intern("Neg")

var Lit_679 *jrt.String = jrt.Intern("NegC64")

var Lit_680 *jrt.String = jrt.Intern("NegC128")

var Lit_681 *jrt.String = jrt.Intern("not")

var Lit_682 *jrt.String = jrt.Intern("not supported by goi yet: ")

var Lit_683 *jrt.String = jrt.Intern("CallValue")

var Lit_684 *jrt.String = jrt.Intern("arbace.go.build$value_call$fn__367000351")

var Lit_685 *jrt.String = jrt.Intern("CallValueT")

var Lit_686 *jrt.String = jrt.Intern("arbace.go.build$via_iface$iter__367000390__367000394")

var Lit_687 *jrt.String = jrt.Intern("arbace.go.build$via_iface$iter__367000390__367000394$fn__367000395")

var Lit_688 *jrt.String = jrt.Intern("arbace.go.build$via_iface$iter__367000390__367000394$fn__367000395$fn__367000396")

var Lit_689 *jrt.String = jrt.Intern("arbace.go.build$via_iface$iter__367000390__367000394$fn__367000395$fn__367000406")

var Lit_690 *jrt.String = jrt.Intern("arbace.go.build$via_iface$iter__367000390__367000394$fn__367000395$fn__367000396$fn__367000400")

var Lit_691 *jrt.String = jrt.Intern("arbace.go.build$with_temp_clears$fn__367001290")

var Lit_692 *jrt.String = jrt.Intern("arbace.go.build$with_temp_clears$iter__367001292__367001296")

var Lit_693 *jrt.String = jrt.Intern("arbace.go.build$with_temp_clears$iter__367001308__367001312")

var Lit_694 *jrt.String = jrt.Intern("arbace.go.build$with_temp_clears$iter__367001292__367001296$fn__367001297")

var Lit_695 *jrt.String = jrt.Intern("arbace.go.build$with_temp_clears$iter__367001292__367001296$fn__367001297$fn__367001298")

var Lit_696 *jrt.String = jrt.Intern("arbace.go.build$with_temp_clears$iter__367001308__367001312$fn__367001313")

var Lit_697 *jrt.String = jrt.Intern("arbace.go.build$with_temp_clears$iter__367001308__367001312$fn__367001313$fn__367001314")

var Lit_698 *jrt.String = jrt.Intern("NewCell")

var Lit_699 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistskn3,tagyn6,Stringyn1,&yn4,argskn4,linekn6,columnkn4,filekn7,privateyn2,xskn7,dynamicyn1,xyn1,nyn4,whatyn2,gryn1,fyn1,myn2,ntyn3,ctxyn4,pathyn2,tykn5,int32kn5,int16kn3,intkn5,int64kn4,uintkn6,uint64kn7,uintptrkn12,untyped-runekn6,uint16kn12,untyped-boolkn4,int8kn6,uint32kn11,untyped-intkn4,boolkn5,uint8kn8,declaredyn3,tagyn1,uyn2,nmyn3,pkgyn1,dyn1,vyn4,wantyn1,kyn1,syn1,pyn2,knyn3,op*v11,arbace.core5,in-nsMyn15,arbace.go.buildm2,R0,s1640,goi's builder (doc/go/GOI-SPEC.md §4.1): the checked tree (§3.7) made nodes, typed Go\n  closures of the back end arbace/goi, by its factories through arbace.lang.GoInterp's op\n  native (go/arbace/goi/registry.ae). It numbers each function's slots per kind (parameters and\n  results first, as the signature lays them out), makes the variables that live in Go memory\n  cells (captured, addressed, of a struct or array type, every package variable), gives each\n  jump target its codes, chooses each node's variant by its operands' types, and resolves each\n  call to the callee's cell, a closure, or the table's member. It decides nothing the checker\n  has not: no type, no constant, no resolution.\n\n  GR3 builds the interpreter's core: scalars, strings, slices, arrays, maps, structs, pointers,\n  functions and closures, all control flow with labels and goto, defer, panic and recover,\n  interface values without methods (§5.3 rules 1 and 2), the calls of compiled Go. GR4 adds\n  methods (their receiver laid after the parameters and results), method values and\n  expressions, the method sets of the types that go into interfaces (each entry the method or a\n  thunk: §5.3), interface method calls, type assertions and switches, embedding and promotion,\n  goroutines, channels, select and range over functions and channels. GR6 adds generics (§9.2):\n  each instance of a generic function, method or type built per type-argument list from the\n  generic declaration's checked tree with its type parameters substituted (inst-tree). A form\n  that needs what goi does not run is \"not supported by goi yet\" (§3.4), an ex-info with\n  :goi/unsupported.m2,R0,s1640,goi's builder (doc/go/GOI-SPEC.md §4.1): the checked tree (§3.7) made nodes, typed Go\n  closures of the back end arbace/goi, by its factories through arbace.lang.GoInterp's op\n  native (go/arbace/goi/registry.ae). It numbers each function's slots per kind (parameters and\n  results first, as the signature lays them out), makes the variables that live in Go memory\n  cells (captured, addressed, of a struct or array type, every package variable), gives each\n  jump target its codes, chooses each node's variant by its operands' types, and resolves each\n  call to the callee's cell, a closure, or the table's member. It decides nothing the checker\n  has not: no type, no constant, no resolution.\n\n  GR3 builds the interpreter's core: scalars, strings, slices, arrays, maps, structs, pointers,\n  functions and closures, all control flow with labels and goto, defer, panic and recover,\n  interface values without methods (§5.3 rules 1 and 2), the calls of compiled Go. GR4 adds\n  methods (their receiver laid after the parameters and results), method values and\n  expressions, the method sets of the types that go into interfaces (each entry the method or a\n  thunk: §5.3), interface method calls, type assertions and switches, embedding and promotion,\n  goroutines, channels, select and range over functions and channels. GR6 adds generics (§9.2):\n  each instance of a generic function, method or type built per type-argument list from the\n  generic declaration's checked tree with its type parameters substituted (inst-tree). A form\n  that needs what goi does not run is \"not supported by goi yet\" (§3.4), an ex-info with\n  :goi/unsupported.R1,v15,arbace.go.build2,opm10,R2,L1,V3,Myn2,nmm2,R3,R4,R5,R6,R0,s65,Makes what goi's factory nm makes of args (GoInterp's op native).R7,i33,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build2,oam10,R10,TR2,L1,V1,R11,R7,i38,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,code-frames?m10,R10,TR7,i40,R8,i1,R9,s18,arbace/go/build.aeR0,s142,Whether goi's back end takes the frames' data (CodeFrame, AtLineR: GOI-SPEC.md, \"Since v1:\n  frames\"); an executable built before it does not.v15,arbace.go.build10,at-line-i?m10,R10,TR7,i45,R8,i1,R9,s18,arbace/go/build.aeR0,s79,Whether goi's back end has AtLineI (mode :full's positions within a statement).v15,arbace.go.build11,*stmt-line*m10,R12,TR7,i49,R8,i1,R9,s18,arbace/go/build.aeR0,s77,The line the statement being built stores in its frame (body-node's), or nil.v15,arbace.go.build13,at-index-linem12,R10,TR2,L1,V2,R13,R14,R0,s165,Index operand node x of index or slice node n, evaluated at n's line (its [, mode :full's)\n  when that is not its statement's: gc's line of the bounds check's panic.R7,i53,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,frame-fn*m8,R10,TR7,i62,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,frame-fn?m10,R2,L1,V0,R0,s161,Whether goi's back end has FrameFn (the initializers' frames naming each its own file: GOI-SPEC.md,\n  \"Since v1: frames\"); an executable built before it has not.R7,i65,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,unsupported!m10,R2,L1,V2,R15,R16,R0,s93,Ends the build of a form goi does not support yet (§3.4): what, the milestone that brings it.R7,i71,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,program-modem8,R0,s55,Program mode (bin/goi run, §2.7): set by arbace.go.run.R7,i76,R8,i1,R9,s18,arbace/go/build.aev11,arbace.core4,atomm8,R0,s55,Program mode (bin/goi run, §2.7): set by arbace.go.run.R7,i76,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build6,lazilym10,R2,L1,V1,R17,R0,s230,Builder f of a function's code for SetCode, built on its first call; in program mode a form\n  goi does not support ends the run as it would before the run (goi: unsupported, status 125:\n  GR6, the generic code built per instance).R7,i78,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,*ctx*m10,R12,TR7,i95,R8,i1,R9,s18,arbace/go/build.aeR0,s271,The package's build context: {:path :name :compiled? (path -> listed?) :types (a HashMap of\n  descriptors by checker type) :gen (named type -> its generation) :func-cell (function object\n  -> its *goi.Func) :global (variable object -> {:ptr :type}) :local-gen (an atom)}.v15,arbace.go.build9,local-genm8,R0,s152,The generations of local named types: one counter for every build, so that their\n  descriptors (interned by package, name and generation) stay distinct.R7,i101,R8,i1,R9,s18,arbace/go/build.ael1000000,m8,R0,s152,The generations of local named types: one counter for every build, so that their\n  descriptors (interned by package, name and generation) stay distinct.R7,i101,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,method-datam10,R2,L1,V1,R18,R0,s104,The checker's method data of method object m (its declaration checked): t/*method-obj*\n  while building.R7,i104,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build18,complete-instance!m10,R2,L1,V1,R19,R0,s86,Completes a generic type's instance (its underlying type, made lazily) while building.R7,i111,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,with-ctxm10,R2,L1,V2,R20,R17,R0,s129,Calls f with the package's build context ctx bound (and the checker's method data, the\n  instances' completion and methods: GR6).R7,i116,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,*fn*m10,R12,TR7,i124,R8,i1,R9,s18,arbace/go/build.aeR0,s362,The function being built: {:slots (volatile counts per kind) :locs (an IdentityHashMap of\n  variables to [:slot k n] or [:cell c]) :code (the next jump code) :defer (volatile) :targets\n  (the breakable statements, innermost last) :labels (a HashMap of label names to codes)\n  :results :calls (the calls of several results, by identity: their temporaries) :name}.v15,arbace.go.build9,compiled?m10,R10,TR2,L1,V1,R21,R7,i131,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,tstrm12,R10,TR2,L1,V1,R22,R0,s122,Go's text of checker type ty without its spellings (uint8, int32, aliases resolved: GC157), as\n  gc's runtime names types.R7,i133,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,int-kwsS15,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,R35,R36,R37,m8,R10,TR7,i141,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,kindm10,R2,L1,V1,R22,R0,s79,The slot kind of a value of checker type ty: :I (integers, bool), :F, :S or :R.R7,i144,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,int-sfxm26,R33,s2,I8R24,s3,I16R23,s3,I32R26,s3,I64R25,s1,IR37,s2,U8R31,s3,U16R34,s3,U32R28,s3,U64R27,s1,UR29,s2,UPR35,s1,IR30,s3,I32m8,R10,TR7,i156,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,basic-ofm10,R10,TR2,L1,V1,R22,R7,i160,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,unsigned?m10,R10,TR2,L1,V1,R22,R7,i161,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,wide?m10,R10,TR2,L1,V1,R22,R7,i162,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build16,struct-or-array?m10,R10,TR2,L1,V1,R22,R7,i163,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build6,iface?m10,R10,TR2,L1,V1,R22,R7,i164,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,descm8,R38,TR7,i166,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,inst-type?m10,R10,TR2,L1,V1,R22,R7,i168,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build18,interpreted-named?m12,R10,TR2,L1,V1,R22,R0,s163,Whether named type ty is interpreted: of an interpreted package, or a generic type's instance\n  (a compiled package's too: gc compiled none of them for goi, §9.3).R7,i170,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,recursive?m12,R10,TR2,L1,V1,R19,R0,s64,Whether named type nt is reachable from its own underlying type.R7,i176,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build14,layout-needed?m12,R10,TR2,L1,V1,R19,R0,s593,Whether named type nt's layout is read before its underlying type is complete (GC70): nt is\n  the type of a struct's field, an array's element or a map's key or element (whose\n  constructors, StructOf, ArrayOf and MapOf, read their parts' layouts) among the types made\n  while nt's is (its parts, and the underlying types of the named types they reach). Its RT then\n  has its shape's layout first (`shape-type`, reflect.ArbaceSetLayout); a type reaching itself\n  only through pointers, slices, channels and functions needs nothing: its RT exists before its\n  underlying type is built (GR9a-c).R7,i199,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,shape-typem12,R10,TR2,L1,V1,R22,R0,s302,The shape of type ty (GR7a; since GR9a-c only a layout, GC70): a checker type of its layout\n  and pointer words, every pointer, map, channel and function an unsafe.Pointer, every slice a\n  []unsafe.Pointer, a recursive interpreted named type its underlying type's shape; other named\n  types themselves.R7,i228,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,tag-textm10,R10,TR2,L1,V1,R39,R7,i244,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,struct-partsm12,R10,TR2,L1,V1,R40,R0,s130,The parts of struct type u for the factories: names, field descriptors, tags, package paths\n  of unexported names, embedded flags.R7,i246,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,method-keym10,R2,L1,V2,R41,R42,R0,s74,A method's key in method sets (§5.3): its name, path.name when unexported.R7,i256,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build15,*iface-pending*m12,R10,TR12,TR7,i261,R8,i1,R9,s18,arbace/go/build.aeR0,s208,The interface descriptors whose methods wait for the outermost `desc` (GR7a): their\n  signatures may name a type still being built (`type Cons[a] struct{Tail List[a]}`, `List[a]`'s\n  method naming `Cons[a]`).v15,arbace.go.build22,set-iface-methods-now!m8,R38,TR7,i267,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build18,set-iface-methods!m12,R10,TR2,L1,V2,R43,R22,R0,s92,Gives interface descriptor d of type ty its methods, once the outermost descriptor is built.R7,i269,R8,i1,R9,s18,arbace/go/build.aem12,R10,TR2,L1,V2,R43,R22,R0,s87,Gives interface descriptor d of type ty its methods (keys and signatures' descriptors).R7,i276,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build17,*methods-pending*m12,R10,TR12,TR7,i284,R8,i1,R9,s18,arbace/go/build.aeR0,s177,The interpreted named types whose method sets wait for the outermost `desc` (GR9a): [descriptor\n  type] pairs, their methods' signatures possibly naming types still being built.v15,arbace.go.build12,method-countm8,R38,TR7,i289,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build18,set-named-methods!m8,R38,TR7,i289,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,reflect-kindm12,R10,TR2,L1,V1,R40,R0,s53,The reflect.Kind of the Go kind of underlying type u.R7,i291,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,local-gen-ofm10,R10,TR2,L1,V1,R22,R7,i304,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,inst-genm8,R38,TR7,i308,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build14,inst-type-namem8,R38,TR7,i308,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,desc-typesm8,R0,s170,The checker types of interpreted named types' descriptors (GR9d): descriptor ->\n  the type it was last made for, by which arbace.go.generic types Go values for inference.R7,i310,R8,i1,R9,s18,arbace/go/build.aem8,R0,s170,The checker types of interpreted named types' descriptors (GR9d): descriptor ->\n  the type it was last made for, by which arbace.go.generic types Go values for inference.R7,i310,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,named-desc1m8,R38,TR7,i314,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,named-descm10,R10,TR2,L1,V1,R22,R7,i316,R8,i1,R9,s18,arbace/go/build.aem10,R10,TR2,L1,V1,R22,R7,i323,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,desc1m8,R38,TR7,i380,R8,i1,R9,s18,arbace/go/build.aem10,R2,L1,V1,R22,R0,s75,The descriptor (a *goi.Type) of checker type ty, one per type in the build.R7,i382,R8,i1,R9,s18,arbace/go/build.aem10,R10,TR2,L1,V1,R22,R7,i409,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,int-bitsm12,R10,TR2,L1,V1,R44,R0,s57,Integer constant v as the int64 of its normalized I slot.R7,i443,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build14,go-string-nodem12,R10,TR2,L1,V1,Myn1,vm2,R3,R4,R0,s69,A string constant node of value v (the checker's: one char per byte).R7,i448,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build13,complex-valuem10,R10,TR2,L1,V2,R22,R44,R7,i455,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,const-nodem10,R2,L1,V3,R22,R44,R45,R0,s66,[kind node] of constant value v of type ty (want :B: a condition).R7,i462,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,new-slot!m10,R10,TR2,L1,V1,R46,R7,i477,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,next-code!m10,R10,TR2,L1,V0,R7,i483,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,label-code!m12,R10,TR2,L1,V1,R41,R0,s50,The goto code of label nm (assigned on first use).R7,i486,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build11,label-entrym10,R10,TR2,L1,V1,R41,R7,i493,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,cell-var?m10,R2,L1,V1,R13,R0,s53,Whether variable x lives in Go memory (a cell, §4.3).R7,i497,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build3,locm10,R10,TR2,L1,V1,R13,R7,i502,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,new-loc!m12,R10,TR2,L1,V1,R13,R0,s76,A location for a new variable x: a slot of its kind, or a C slot for a cell.R7,i506,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,temp!m12,R10,TR2,L1,V1,R46,R0,s173,A new temporary slot of kind k; one of R or S is logged for the statement being built, which clears it\n  when it has run (liveness: a temporary holds what no variable does).R7,i513,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,local-nodem10,R10,TR2,L1,V2,R46,R47,R7,i524,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,as-kindm10,R2,L1,V2,V2,R46,R14,R45,R0,s54,Node [k n] as kind want (:B from an :I bool and back).R7,i526,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build6,load-pm12,R10,TR2,L1,V2,R48,R22,R0,s55,The value of type ty at place p, as a node of its kind.R7,i535,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,store-pm12,R10,TR2,L1,V3,R48,R49,R22,R0,s57,The statement storing node [k n] (of type ty) at place p.R7,i546,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,set-slotm10,R10,TR2,L1,V3,R46,R47,R14,R7,i558,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,expr-stmt-ofm10,R10,TR2,L1,V1,V2,R46,R14,R7,i561,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build2,exm8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,ex-asm8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build5,placem8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,lit-placem8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,lit-nodem8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,call-nodem8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,call-resultsm8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,build-fn-litm8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build7,builtinm8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build12,expr-or-stmtm8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build4,stmtm8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,stmt-listm8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,rhs-nodesm8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build17,method-value-nodem8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build23,iface-method-value-nodem8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build16,method-expr-nodem8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,assert-knm8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build9,elem-typem8,R38,TR7,i564,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build3,exkm8,R2,L1,V2,R14,R46,R7,i567,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build15,ensure-methods!m8,R38,TR7,i571,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build13,iface-contentm12,R10,TR2,L1,V2,V2,R46,R14,R22,R0,s192,Node [k n] of type ty as an interface's content (an R node): the value itself, its type's\nmethod set given first (§5.3; an interpreted named type's is given when its descriptor is made,\nGR9a).R7,i573,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build10,arith-namem10,R10,TR2,L1,V1,R50,R7,i591,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,cmp-namem12,s2,==s2,Eqs2,!=s2,Nes1,<s2,Lts2,<=s2,Les1,>s2,Gts2,>=s2,Gem8,R10,TR7,i595,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build8,const-ofm12,R10,TR2,L1,V1,R14,R0,s69,The constant value of node n when it is one (an operand's), else nil.R7,i597,R8,i1,R9,s18,arbace/go/build.ae")

var Lit_700 *jrt.String = jrt.Intern("arbace.go.build$eval367000004$loading__1927001464__auto____367000005")

var Lit_701 *jrt.String = jrt.Intern("arbace.go.build$eval367000008$fn__367000009")

var Lit_702 *jrt.String = jrt.Intern("arbace.go.build$op")

var Lit_703 *jrt.String = jrt.Intern("arbace.go.build$oa")

var Lit_704 *jrt.String = jrt.Intern("arbace.go.build$fn__367000014")

var Lit_705 *jrt.String = jrt.Intern("arbace.go.build$fn__367000016")

var Lit_706 *jrt.String = jrt.Intern("arbace.go.build$at_index_line")

var Lit_707 *jrt.String = jrt.Intern("arbace.go.build$fn__367000019")

var Lit_708 *jrt.String = jrt.Intern("arbace.go.build$frame_fn_QMARK_")

var Lit_709 *jrt.String = jrt.Intern("arbace.go.build$unsupported_BANG_")

var Lit_710 *jrt.String = jrt.Intern("arbace.go.build$lazily")

var Lit_711 *jrt.String = jrt.Intern("arbace.go.build$method_data")

var Lit_712 *jrt.String = jrt.Intern("arbace.go.build$complete_instance_BANG_")

var Lit_713 *jrt.String = jrt.Intern("arbace.go.build$with_ctx")

var Lit_714 *jrt.String = jrt.Intern("arbace.go.build$compiled_QMARK_")

var Lit_715 *jrt.String = jrt.Intern("arbace.go.build$tstr")

var Lit_716 *jrt.String = jrt.Intern("arbace.go.build$kind")

var Lit_717 *jrt.String = jrt.Intern("arbace.go.build$basic_of")

var Lit_718 *jrt.String = jrt.Intern("arbace.go.build$unsigned_QMARK_")

var Lit_719 *jrt.String = jrt.Intern("arbace.go.build$wide_QMARK_")

var Lit_720 *jrt.String = jrt.Intern("arbace.go.build$struct_or_array_QMARK_")

var Lit_721 *jrt.String = jrt.Intern("arbace.go.build$iface_QMARK_")

var Lit_722 *jrt.String = jrt.Intern("arbace.go.build$inst_type_QMARK_")

var Lit_723 *jrt.String = jrt.Intern("arbace.go.build$interpreted_named_QMARK_")

var Lit_724 *jrt.String = jrt.Intern("arbace.go.build$recursive_QMARK_")

var Lit_725 *jrt.String = jrt.Intern("arbace.go.build$layout_needed_QMARK_")

var Lit_726 *jrt.String = jrt.Intern("arbace.go.build$shape_type")

var Lit_727 *jrt.String = jrt.Intern("arbace.go.build$tag_text")

var Lit_728 *jrt.String = jrt.Intern("arbace.go.build$struct_parts")

var Lit_729 *jrt.String = jrt.Intern("arbace.go.build$method_key")

var Lit_730 *jrt.String = jrt.Intern("arbace.go.build$set_iface_methods_BANG_")

var Lit_731 *jrt.String = jrt.Intern("arbace.go.build$set_iface_methods_now_BANG_")

var Lit_732 *jrt.String = jrt.Intern("arbace.go.build$reflect_kind")

var Lit_733 *jrt.String = jrt.Intern("arbace.go.build$local_gen_of")

var Lit_734 *jrt.String = jrt.Intern("arbace.go.build$named_desc")

var Lit_735 *jrt.String = jrt.Intern("arbace.go.build$named_desc1")

var Lit_736 *jrt.String = jrt.Intern("arbace.go.build$desc")

var Lit_737 *jrt.String = jrt.Intern("arbace.go.build$desc1")

var Lit_738 *jrt.String = jrt.Intern("arbace.go.build$int_bits")

var Lit_739 *jrt.String = jrt.Intern("arbace.go.build$go_string_node")

var Lit_740 *jrt.String = jrt.Intern("arbace.go.build$complex_value")

var Lit_741 *jrt.String = jrt.Intern("arbace.go.build$const_node")

var Lit_742 *jrt.String = jrt.Intern("arbace.go.build$new_slot_BANG_")

var Lit_743 *jrt.String = jrt.Intern("arbace.go.build$next_code_BANG_")

var Lit_744 *jrt.String = jrt.Intern("arbace.go.build$label_code_BANG_")

var Lit_745 *jrt.String = jrt.Intern("arbace.go.build$label_entry")

var Lit_746 *jrt.String = jrt.Intern("arbace.go.build$cell_var_QMARK_")

var Lit_747 *jrt.String = jrt.Intern("arbace.go.build$loc")

var Lit_748 *jrt.String = jrt.Intern("arbace.go.build$new_loc_BANG_")

var Lit_749 *jrt.String = jrt.Intern("arbace.go.build$temp_BANG_")

var Lit_750 *jrt.String = jrt.Intern("arbace.go.build$local_node")

var Lit_751 *jrt.String = jrt.Intern("arbace.go.build$as_kind")

var Lit_752 *jrt.String = jrt.Intern("arbace.go.build$load_p")

var Lit_753 *jrt.String = jrt.Intern("arbace.go.build$store_p")

var Lit_754 *jrt.String = jrt.Intern("arbace.go.build$set_slot")

var Lit_755 *jrt.String = jrt.Intern("arbace.go.build$expr_stmt_of")

var Lit_756 *jrt.String = jrt.Intern("arbace.go.build$exk")

var Lit_757 *jrt.String = jrt.Intern("arbace.go.build$iface_content")

var Lit_758 *jrt.String = jrt.Intern("arbace.go.build$arith_name")

var Lit_759 *jrt.String = jrt.Intern("arbace.go.build$const_of")

var Lit_760 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn1,nkn3,dockn4,linekn6,columnkn4,fileyn3,op*yn2,tyyn2,xnyn2,ynyn1,xyn1,yyn2,xkyn2,ykyn9,ycount-tyyn4,idxsyn1,vkn8,declaredyn1,kkn2,asyn2,knyn4,fromyn2,toyn4,wantyn3,sigyn1,_yn2,psyn2,rsyn8,variadicyn4,recvyn1,syn4,nodeyn4,argsyn3,cmpyn4,cellyn7,settersyn7,resultsyn4,modeyn6,calleeyn4,pathyn2,nmyn5,nodesyn5,tempsyn1,myn2,rtyn6,mtargsyn5,targsyn5,fpathyn3,selyn3,pkgyn3,rtyyn5,mnameyn1,ryn6,paramsyn1,Dyn1,dyn4,keysyn2,ndyn1,Tyn2,xryn2,styn1,ayn1,pv15,arbace.go.build13,local-slot-ofm12,R0,TR1,L1,V1,R2,R3,s71,The I slot of node n when it reads a local held in an I slot, else nil.R4,i602,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,int-binopm10,R1,L1,V4,R7,R8,R9,R10,R3,s72,x op y on integer type ty (nodes of the operands' checked trees xn, yn).R4,i610,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,float-binopm10,R0,TR1,L1,V4,R7,R8,R11,R12,R4,i624,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,binop-nodesm10,R1,L1,V5,R7,R8,R13,R14,R15,R3,s85,[k node] of arithmetic x op y of type ty on built operand nodes (for op= statements).R4,i628,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,count-nodem12,R0,TR1,L1,V1,R10,R3,s81,A shift count's node: an I (a constant count of any numeric kind as its integer).R4,i641,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,shift-nodem10,R0,TR1,L1,V4,R7,R8,R9,R10,R4,i651,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,nil-node?m10,R0,TR1,L1,V1,R2,R4,i656,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,compare-nodesm10,R1,L1,V3,R7,R9,R10,R3,s35,[:B node] of x op y (a comparison).R4,i658,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,binary-nodem10,R0,TR1,L1,V1,R2,R4,i707,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,unary-nodem10,R0,TR1,L1,V1,R2,R4,i725,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,bytes-type?m10,R0,TR1,L1,V1,R8,R4,i738,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,runes-type?m10,R0,TR1,L1,V1,R8,R4,i739,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,conv-nodem10,R1,L1,V1,R2,R3,s49,[k node] of conversion T(x) (a non-constant one).R4,i741,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build12,addressable?m10,R0,TR1,L1,V1,R2,R4,i787,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,struct-ofm12,R0,TR1,L1,V1,R8,R3,s66,The struct type and its descriptor a field selection's step is on.R4,i790,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,value-placem12,R0,TR1,L1,V1,R2,R3,s112,A place holding the value of node n (of struct or array type): its own when addressable, else\n  its value's box.R4,i795,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,field-placem10,R1,L1,V1,R2,R3,s63,The place of field selection n ({:op :field :path :derefs :x}).R4,i803,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build5,uidx?m12,R0,TR1,L1,V1,R2,R3,s87,Whether index or bound n is of an unsigned type (gc's bounds errors print it unsigned).R4,i822,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,uidx-maskm12,R0,TR1,L1,V1,R16,R3,s84,Bits 0, 1, 2 set when a slice expression's bounds lo, hi, max are of unsigned types.R4,i827,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,index-placem12,R0,TR1,L1,V1,R2,R3,s78,The place of element (aget x i) of an array, a pointer to an array or a slice.R4,i832,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V1,R2,R3,s43,The place (a P node) of addressable node n.R4,i845,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,elem-nodem12,R0,TR1,L1,V2,R17,R8,R3,s77,An element value node of type ty, as the factories take it (its kind's node).R4,i865,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V1,R2,R3,s56,A struct or array literal as a new variable (its place).R4,i870,R5,i1,R6,s18,arbace/go/build.aem10,R0,TR1,L1,V1,R2,R4,i898,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,var-nodem10,R0,TR1,L1,V1,R11,R4,i913,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,global-nodem10,R0,TR1,L1,V1,R2,R4,i919,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,instance-cellm8,R18,TR4,i922,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build6,isubstm8,R18,TR4,i922,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build15,func-value-nodem12,R0,TR1,L1,V1,R2,R3,s120,The value of function node n: a generic function's instance (§9.2), a compiled member, an\n  interpreted function's cell.R4,i924,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build3,ex*m8,R18,TR4,i934,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build6,coercem12,R0,TR1,L1,V3,V4,R19,R2,R20,R21,R22,R23,R3,s167,Value [k n] of type from as one of type to it is assigned to (a named and an unnamed composite\n  type of one underlying type): converted, their RTs being two (GR9a-c).R4,i936,R5,i1,R6,s18,arbace/go/build.aem10,R1,L2,V1,R2,V2,R2,R24,R3,s138,[kind node] of expression node n (want: the type a nil takes, or :B for a condition; a value\n  of another composite type converted to it).R4,i949,R5,i1,R6,s18,arbace/go/build.aem10,R0,TR1,L1,V2,R2,R24,R4,i955,R5,i1,R6,s18,arbace/go/build.aem8,R1,L1,V2,R2,R19,R4,i1018,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,slot-layoutm12,R0,TR1,L2,V1,R25,V2,V4,R26,R27,R28,R29,R30,R3,s280,The callee's slots of a signature [:func ps rs variadic]: the parameters', then the results',\n  numbered per kind in order (the variadic parameter an R); a method's receiver (of type recv)\n  after them (GR4), so that the arguments' slots are the signature's whatever the receiver.R4,i1022,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,arg-setterm10,R0,TR1,L1,V2,V2,R19,R31,R32,R4,i1035,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,error-type?m8,R18,TR4,i1038,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build15,compiled-iface?m8,R18,TR4,i1038,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,kill-argm8,R18,TR4,i1038,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build16,with-temp-clearsm8,R18,TR4,i1038,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build14,mem-converted?m12,R0,TR1,L1,V1,R8,R3,s153,Whether a value of type ty differs in Go memory from a frame: a function (a closure as a Go\n  func). An interface's content is the value itself (GR9a-c).R4,i1040,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,mem-nodem12,R0,TR1,L1,V2,R21,R8,R3,s77,Node [k n] of type ty as compiled Go takes it (a closure as a Go func: MemR).R4,i1047,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,arg-nodesm12,R0,TR1,L1,V3,R25,R33,R34,R3,s196,The argument nodes of a call to signature sig: fixed parameters', then the variadic slice's\n  (made from the trailing arguments, or the spread one); for compiled code (cmp) closures as Go\n  funcs.R4,i1053,R5,i1,R6,s18,arbace/go/build.aem12,R0,TR1,L1,V1,R2,R3,s71,The call of several results n, built once: {:t T :temps [[k slot]...]}.R4,i1071,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build6,sig-ofm10,R0,TR1,L1,V1,R8,R4,i1080,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,cell-callm12,R0,TR1,L1,V4,R35,R36,R37,R38,R3,s127,A call of function cell cell with setters, the callee's results in slots results: [k node] of\n  one result, else {:t T :temps}.R4,i1082,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,static-callm10,R0,TR1,L1,V4,R35,R25,R33,R38,R4,i1094,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,value-callm10,R0,TR1,L1,V4,R39,R25,R33,R38,R4,i1100,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,from-memm10,R0,TR1,L1,V2,V2,R19,R2,R8,R4,i1114,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build18,compiled-call-nodem12,R0,TR1,L1,V6,R40,R41,R25,R42,R38,R43,R3,s162,A compiled call of listed member path.nm of signature sig on argument nodes (a method's\n  receiver first): [k node], or {:t :temps} writing temps (made when nil).R4,i1119,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,compiled-callm10,R0,TR1,L1,V6,R40,R41,R25,R33,R30,R38,R4,i1129,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build12,recv-type-ofm12,R0,TR1,L1,V1,R44,R3,s78,The receiver type of method object m: its base named type, or a pointer to it.R4,i1135,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,method-cellm12,R0,TR1,L1,V1,R44,R3,s45,The *goi.Func of interpreted method object m.R4,i1143,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build15,generic-method?m10,R1,L1,V1,R44,R3,s87,Whether method object m is a generic type's or has type parameters of its own (go1.27).R4,i1148,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,method-targetm12,R0,TR1,L1,V3,R44,R45,R46,R3,s226,[cell receiver-type] of interpreted method m selected on named type rt (a generic type's\n  instance, for its methods; nil: m's own type) with a generic method's own type arguments\n  mtargs: an instance's cell (§9.2), else m's.R4,i1153,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build15,method-callablem10,R1,L1,V3,R44,R35,R41,R3,s129,The Callable of interpreted method object m (its cell) as Arbace calls it, the receiver\n  first: the var T.M's (§2.1, §7.1; GR5).R4,i1165,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build17,instance-callablem10,R1,L1,V4,R11,R47,R45,R41,R3,s232,GR9d: the Callable of generic function or method x's instance for targs (its receiver's type\n  arguments first) as Arbace calls it (a method: the receiver first, rt its instance type),\n  and the instance's signature: [callable sig].R4,i1175,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,path-derefsm12,R0,TR1,L1,V2,R8,R40,R3,s87,The implicit dereferences of a field selection along path from type ty (the checker's).R4,i1192,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,field-selm12,R0,TR1,L1,V2,R11,R48,R3,s70,The selection of the embedded fields fpath from node x: a :field node.R4,i1206,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,recv-nodem10,R1,L1,V1,R49,R3,s231,The receiver of method selection sel ({:op :method :recv :path :recv-adjust}) as the method\n  takes it: the embedded fields of its path selected, then its address or the value it points\n  to as the method's receiver asks: [k node].R4,i1218,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build18,interp-method-callm12,R0,TR1,L1,V3,R39,R33,R38,R3,s127,A call of interpreted method selection callee: its cell, the receiver laid after the\n  arguments (evaluated first, as Go does).R4,i1240,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,via-ifacem12,R0,TR1,L1,V4,R50,R51,R52,R25,R3,s182,The listed interface method I.name of compiled package pkg that type rty implements, its\n  signature identical to sig's (GR8a), as the table names it, or nil: the interfaces by name.R4,i1253,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,method-callm10,R0,TR1,L1,V3,R39,R33,R38,R4,i1266,R5,i1,R6,s18,arbace/go/build.aem10,R0,TR1,L1,V1,R8,R4,i1288,R5,i1,R6,s18,arbace/go/build.aem10,R0,TR1,L1,V1,R8,R4,i1290,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build15,iface-recv-nodem12,R0,TR1,L1,V1,R39,R3,s109,The interface content an interface method selection is called on (its embedded fields\n  selected): an R node.R4,i1292,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,iface-callm12,R0,TR1,L1,V3,R39,R33,R38,R3,s349,A call of interface method selection callee (§5.3): the content evaluated into a temporary,\n  then an interpreted type's method (its type's method set, an inline cache by the content's\n  reflect type), else the compiled\n  value's method (the static compiled interface's method expression, error's Error, or the\n  table's method of the dynamic type).R4,i1299,R5,i1,R6,s18,arbace/go/build.aem12,R0,TR1,L1,V1,R2,R3,s82,x.M of a concrete type (a method value): the receiver evaluated now, bound (§4.6).R4,i1335,R5,i1,R6,s18,arbace/go/build.aem12,R0,TR1,L1,V1,R2,R3,s78,x.M of an interface (a method value): the content's method bound to it (§4.6).R4,i1353,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,build-codem8,R18,TR4,i1363,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,local-objm10,R0,TR1,L1,V2,R41,R8,R4,i1365,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,local-refm10,R0,TR1,L1,V1,R11,R4,i1367,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,selectionm12,R0,TR1,L1,V2,R11,R53,R3,s125,The checker's selection node of lookup result r ({:kind :method|:iface-method ...}) on node x\n  (code_call.ae's select-expr).R4,i1369,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,thunk-bodym12,R0,TR1,L1,V3,R49,R54,R25,R3,s84,The body of a thunk calling selection sel with parameters params (of signature sig).R4,i1385,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build18,build-method-thunkm12,R0,TR1,L1,V4,R55,R53,R25,R41,R3,s198,The code of the method set entry of type D for lookup result r (signature sig): a method of\n  receiver D (laid last) calling the method through the embedded fields and pointers of its\n  path (§5.3).R4,i1398,R5,i1,R6,s18,arbace/go/build.aem12,R0,TR1,L1,V1,R2,R3,s76,T.M (a method expression): a function of the receiver first, a thunk (§4.6).R4,i1420,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build17,method-candidatesm12,R0,TR1,L1,V1,R8,R3,s156,[name pkg] of the methods that may be in type ty's method set: its named types' declared\n  methods, its embedded fields' and embedded interfaces', in order.R4,i1443,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build17,may-have-methods?m12,R0,TR1,L1,V1,R8,R3,s140,Whether type ty (concrete) may have an interpreted method set: an interpreted named type, a\n  pointer to one, a struct with embedded fields.R4,i1464,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,methods-givenm8,R0,TR4,i1477,R5,i1,R6,s18,arbace/go/build.aem8,R0,TR4,i1477,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build19,check-methods-kept!m12,R0,TR1,L1,V3,R8,R56,R57,R3,s100,Fails when the keys of the set about to be given to descriptor d of type ty lack one it already has.R4,i1479,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V2,R8,R56,R3,s173,Gives the descriptor d of concrete type ty its method set (once per build context, §5.3):\n  each method of ty's method set the method itself (its receiver is ty) or a thunk.R4,i1493,R5,i1,R6,s18,arbace/go/build.aem12,R0,TR1,L1,V1,R8,R3,s126,The number of methods in concrete type ty's method set that `ensure-methods!` may give (its\n  RT's method table's room, GR9a).R4,i1550,R5,i1,R6,s18,arbace/go/build.aem12,R0,TR1,L1,V2,R58,R8,R3,s171,Gives interpreted named type ty (descriptor nd) and its pointer type their method sets, and so\n  their RTs their method tables (GR9a: before any value of the type exists).R4,i1563,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build7,rt-namem8,R18,TR4,i1573,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,iface-namem12,R0,TR1,L1,V1,R8,R3,s85,The name gc's runtime gives static interface type ty in a failed assertion's message.R4,i1575,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,assert-descm10,R0,TR1,L1,V1,R59,R4,i1583,R5,i1,R6,s18,arbace/go/build.aem12,R0,TR1,L1,V3,R60,R59,R61,R3,s78,[k node] of content node xr asserted to type T (the static interface type st).R4,i1588,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,ptr-conv?m12,R0,TR1,L1,V1,R62,R3,s74,Whether argument node a is a conversion of an unsafe.Pointer to a uintptr.R4,i1605,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,call-escapes?m12,R0,TR1,L1,V1,R2,R3,s78,Whether call n is of a function or method with the pragma //go:uintptrescapes.R4,i1611,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,kept-argm12,R0,TR1,L1,V2,R62,R31,R3,s83,Argument node a (a pointer's conversion) with the pointer taken from caller slot s.R4,i1622,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,call-node*m8,R18,TR4,i1627,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,slots-clearm8,R18,TR4,i1627,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,keep-callm12,R0,TR1,L1,V2,R2,R38,R3,s156,Call n of a function with //go:uintptrescapes: its pointer conversions' operands are held in slots\n  during the call; [k node] or {:t :temps} as call-node*.R4,i1629,R5,i1,R6,s18,arbace/go/build.aem10,R1,L2,V1,R2,V2,R2,R38,R3,s79,[kind node] of a call of one result (mode :multi, or no result: {:t T :temps}).R4,i1651,R5,i1,R6,s18,arbace/go/build.aem10,R0,TR1,L1,V2,R2,R38,R4,i1656,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,call-stmtm12,R0,TR1,L1,V1,R2,R3,s51,The statement of call n as an expression statement.R4,i1678,R5,i1,R6,s18,arbace/go/build.aem10,R0,TR1,L1,V1,R8,R4,i1690,R5,i1,R6,s18,arbace/go/build.aem10,R1,L1,V2,R2,R38,R3,s81,A builtin's call: [k node], {:t ...} for mode :multi, a statement for mode :stmt.R4,i1692,R5,i1,R6,s18,arbace/go/build.aem10,R0,TR1,L1,V2,R38,R31,R4,i1777,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,slot-of-placem12,R0,TR1,L1,V1,R63,R3,s58,[k slot] when place p is a local held in a slot, else nil.R4,i1781,R5,i1,R6,s18,arbace/go/build.ae")

var Lit_761 *jrt.String = jrt.Intern("arbace.go.build$local_slot_of")

var Lit_762 *jrt.String = jrt.Intern("arbace.go.build$int_binop")

var Lit_763 *jrt.String = jrt.Intern("arbace.go.build$float_binop")

var Lit_764 *jrt.String = jrt.Intern("arbace.go.build$binop_nodes")

var Lit_765 *jrt.String = jrt.Intern("arbace.go.build$count_node")

var Lit_766 *jrt.String = jrt.Intern("arbace.go.build$shift_node")

var Lit_767 *jrt.String = jrt.Intern("arbace.go.build$nil_node_QMARK_")

var Lit_768 *jrt.String = jrt.Intern("arbace.go.build$compare_nodes")

var Lit_769 *jrt.String = jrt.Intern("arbace.go.build$binary_node")

var Lit_770 *jrt.String = jrt.Intern("arbace.go.build$unary_node")

var Lit_771 *jrt.String = jrt.Intern("arbace.go.build$bytes_type_QMARK_")

var Lit_772 *jrt.String = jrt.Intern("arbace.go.build$runes_type_QMARK_")

var Lit_773 *jrt.String = jrt.Intern("arbace.go.build$conv_node")

var Lit_774 *jrt.String = jrt.Intern("arbace.go.build$addressable_QMARK_")

var Lit_775 *jrt.String = jrt.Intern("arbace.go.build$struct_of")

var Lit_776 *jrt.String = jrt.Intern("arbace.go.build$value_place")

var Lit_777 *jrt.String = jrt.Intern("arbace.go.build$field_place")

var Lit_778 *jrt.String = jrt.Intern("arbace.go.build$uidx_QMARK_")

var Lit_779 *jrt.String = jrt.Intern("arbace.go.build$uidx_mask")

var Lit_780 *jrt.String = jrt.Intern("arbace.go.build$index_place")

var Lit_781 *jrt.String = jrt.Intern("arbace.go.build$place")

var Lit_782 *jrt.String = jrt.Intern("arbace.go.build$elem_node")

var Lit_783 *jrt.String = jrt.Intern("arbace.go.build$lit_place")

var Lit_784 *jrt.String = jrt.Intern("arbace.go.build$lit_node")

var Lit_785 *jrt.String = jrt.Intern("arbace.go.build$var_node")

var Lit_786 *jrt.String = jrt.Intern("arbace.go.build$global_node")

var Lit_787 *jrt.String = jrt.Intern("arbace.go.build$func_value_node")

var Lit_788 *jrt.String = jrt.Intern("arbace.go.build$coerce")

var Lit_789 *jrt.String = jrt.Intern("arbace.go.build$ex")

var Lit_790 *jrt.String = jrt.Intern("arbace.go.build$ex_STAR_")

var Lit_791 *jrt.String = jrt.Intern("arbace.go.build$ex_as")

var Lit_792 *jrt.String = jrt.Intern("arbace.go.build$slot_layout")

var Lit_793 *jrt.String = jrt.Intern("arbace.go.build$arg_setter")

var Lit_794 *jrt.String = jrt.Intern("arbace.go.build$mem_converted_QMARK_")

var Lit_795 *jrt.String = jrt.Intern("arbace.go.build$mem_node")

var Lit_796 *jrt.String = jrt.Intern("arbace.go.build$arg_nodes")

var Lit_797 *jrt.String = jrt.Intern("arbace.go.build$call_results")

var Lit_798 *jrt.String = jrt.Intern("arbace.go.build$sig_of")

var Lit_799 *jrt.String = jrt.Intern("arbace.go.build$cell_call")

var Lit_800 *jrt.String = jrt.Intern("arbace.go.build$static_call")

var Lit_801 *jrt.String = jrt.Intern("arbace.go.build$value_call")

var Lit_802 *jrt.String = jrt.Intern("arbace.go.build$from_mem")

var Lit_803 *jrt.String = jrt.Intern("arbace.go.build$compiled_call_node")

var Lit_804 *jrt.String = jrt.Intern("arbace.go.build$compiled_call")

var Lit_805 *jrt.String = jrt.Intern("arbace.go.build$recv_type_of")

var Lit_806 *jrt.String = jrt.Intern("arbace.go.build$method_cell")

var Lit_807 *jrt.String = jrt.Intern("arbace.go.build$generic_method_QMARK_")

var Lit_808 *jrt.String = jrt.Intern("arbace.go.build$method_target")

var Lit_809 *jrt.String = jrt.Intern("arbace.go.build$method_callable")

var Lit_810 *jrt.String = jrt.Intern("arbace.go.build$instance_callable")

var Lit_811 *jrt.String = jrt.Intern("arbace.go.build$path_derefs")

var Lit_812 *jrt.String = jrt.Intern("arbace.go.build$field_sel")

var Lit_813 *jrt.String = jrt.Intern("arbace.go.build$recv_node")

var Lit_814 *jrt.String = jrt.Intern("arbace.go.build$interp_method_call")

var Lit_815 *jrt.String = jrt.Intern("arbace.go.build$via_iface")

var Lit_816 *jrt.String = jrt.Intern("arbace.go.build$method_call")

var Lit_817 *jrt.String = jrt.Intern("arbace.go.build$error_type_QMARK_")

var Lit_818 *jrt.String = jrt.Intern("arbace.go.build$compiled_iface_QMARK_")

var Lit_819 *jrt.String = jrt.Intern("arbace.go.build$iface_recv_node")

var Lit_820 *jrt.String = jrt.Intern("arbace.go.build$iface_call")

var Lit_821 *jrt.String = jrt.Intern("arbace.go.build$method_value_node")

var Lit_822 *jrt.String = jrt.Intern("arbace.go.build$iface_method_value_node")

var Lit_823 *jrt.String = jrt.Intern("arbace.go.build$local_obj")

var Lit_824 *jrt.String = jrt.Intern("arbace.go.build$local_ref")

var Lit_825 *jrt.String = jrt.Intern("arbace.go.build$selection")

var Lit_826 *jrt.String = jrt.Intern("arbace.go.build$thunk_body")

var Lit_827 *jrt.String = jrt.Intern("arbace.go.build$build_method_thunk")

var Lit_828 *jrt.String = jrt.Intern("arbace.go.build$method_expr_node")

var Lit_829 *jrt.String = jrt.Intern("arbace.go.build$method_candidates")

var Lit_830 *jrt.String = jrt.Intern("arbace.go.build$may_have_methods_QMARK_")

var Lit_831 *jrt.String = jrt.Intern("arbace.go.build$check_methods_kept_BANG_")

var Lit_832 *jrt.String = jrt.Intern("arbace.go.build$ensure_methods_BANG_")

var Lit_833 *jrt.String = jrt.Intern("arbace.go.build$method_count")

var Lit_834 *jrt.String = jrt.Intern("arbace.go.build$set_named_methods_BANG_")

var Lit_835 *jrt.String = jrt.Intern("arbace.go.build$iface_name")

var Lit_836 *jrt.String = jrt.Intern("arbace.go.build$assert_desc")

var Lit_837 *jrt.String = jrt.Intern("arbace.go.build$assert_kn")

var Lit_838 *jrt.String = jrt.Intern("arbace.go.build$ptr_conv_QMARK_")

var Lit_839 *jrt.String = jrt.Intern("arbace.go.build$call_escapes_QMARK_")

var Lit_840 *jrt.String = jrt.Intern("arbace.go.build$kept_arg")

var Lit_841 *jrt.String = jrt.Intern("arbace.go.build$keep_call")

var Lit_842 *jrt.String = jrt.Intern("arbace.go.build$call_node")

var Lit_843 *jrt.String = jrt.Intern("arbace.go.build$call_node_STAR_")

var Lit_844 *jrt.String = jrt.Intern("arbace.go.build$call_stmt")

var Lit_845 *jrt.String = jrt.Intern("arbace.go.build$elem_type")

var Lit_846 *jrt.String = jrt.Intern("arbace.go.build$builtin")

var Lit_847 *jrt.String = jrt.Intern("arbace.go.build$expr_or_stmt")

var Lit_848 *jrt.String = jrt.Intern("arbace.go.build$slot_of_place")

var Lit_849 *jrt.String = jrt.Intern("kn8,arglistsyn1,pyn2,knkn3,dockn4,linekn6,columnkn4,filekn7,privateyn3,knsyn5,nodesyn3,tysyn1,nyn2,tyyn1,xyn1,dkn5,ifacekn6,methodkn4,refskn9,recv-typekn6,paramskn3,valkn5,fieldkn4,typekn8,tag-typekn3,sigks3,goi5,labelkn3,varks3,goi4,origkn4,formkn3,objkn4,objskn2,tokn7,resultsyn1,fkn3,tagyn15,IdentityHashMapyn25,java.util.IdentityHashMapyn2,xsyn4,bodyyn4,treekn6,returnkn9,op-assignkn6,assignkn4,exprkn4,sendkn6,incdeckn8,continuekn11,fallthroughkn5,breakkn4,gotokn8,declaredyn5,candsyn1,byn2,diyn1,syn5,stmtsyn2,rsyn2,ssyn2,csyn4,objsyn1,kkn2,asyn1,ayn1,cyn1,tyn4,predyn4,new?yn4,callyn4,nodeyn2,clyn5,extrayn3,lityn5,fnameyn4,codeyn7,gc-nameyn5,line0yn3,endyn5,args?yn5,declsyn8,src-fileyn7,go-fileyn8,capturesyn5,initsyn7,cell-ofyn1,mkn5,gtypekn4,recvkn3,lhskn4,rmapkn9,inst-formkn8,label-idkn7,tparamskn2,idkn10,underlyingyn9,implicitsv15,arbace.go.build9,assign-tom10,R0,L1,V2,R1,R2,R3,s95,The statement assigning [k node] (of the place's type) to place p (:blank: evaluated, dropped).R4,i1788,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,temps-ofm12,R7,TR0,L1,V1,R8,R3,s81,Statements evaluating nodes kns into new temporaries, and the temporaries' nodes.R4,i1800,R5,i1,R6,s18,arbace/go/build.aem10,R0,L1,V2,R9,R10,R3,s138,The [k node]s of the right-hand values of an assignment or declaration (comma-ok forms as\n  two), for targets of types tys (a nil's type).R4,i1807,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,prepare-placem12,R7,TR0,L1,V1,R1,R3,s183,[statements place]: the operands of place p evaluated into temporaries now (an assignment's\n  first phase, §4.5: Go evaluates the places' index and pointer operands, then the values).R4,i1842,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,assign-stmtm8,R0,L1,V1,R11,R4,i1879,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build14,op-assign-stmtm8,R0,L1,V1,R11,R4,i1888,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build6,one-ofm10,R7,TR0,L1,V1,R12,R4,i1918,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,incdec-stmtm8,R0,L1,V1,R11,R4,i1924,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,zero-initm10,R7,TR0,L1,V1,R13,R4,i1931,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,init-varm12,R7,TR0,L1,V2,R13,R2,R3,s63,The statement giving new variable x its initial value [k node].R4,i1942,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,decl-stmtm10,R0,L1,V1,R14,R3,s83,A declaration {:op :decl :objs :init}: new variables (a reused one of := assigned).R4,i1951,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,live-off?m8,R7,TR4,i1981,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,clear-op?m10,R7,TR4,i1983,R5,i1,R6,s18,arbace/go/build.aeR3,s151,Whether goi's back end has ClearSlots, KillR and KillS (an older executable has not: the slots are\n  then set by SetR and SetS, and no argument moves).v15,arbace.go.build8,ref-skipS18,R15,R16,R17,R18,R19,R20,R21,R22,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,m8,R7,TR4,i1988,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,walk-objsm12,R7,TR0,L1,V2,R33,R13,R3,s103,Calls (f obj) for each object that tree x names: a node's :obj, a declaration's :objs, a clause's :var.R4,i1991,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build7,refs-ofm12,R7,TR0,L1,MV2,Myn5,candsm2,R34,R35,R13,m2,R34,R36,R3,s85,The references in tree x to the candidates cands: an IdentityHashMap object -> count.R4,i2002,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build6,id-setm10,R7,TR0,L1,MV1,R37,m2,R34,R36,R4,i2009,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,has-goto?m10,R7,TR0,L1,V1,R38,R4,i2012,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,candidatesm12,R7,TR0,L1,V1,R39,R3,s150,The variables of function tree that liveness may clear: its parameters, receiver and locals held in\n  an R or S slot or a cell, not its named results.R4,i2022,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,simple-opsS6,R40,R41,R42,R43,R44,R45,m8,R7,TR4,i2038,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build12,terminal-opsS5,R46,R40,R47,R48,R49,m8,R7,TR4,i2039,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,plan-listm8,R50,TR4,i2041,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,plan-blockm12,R7,TR0,L1,V4,Myn4,planm2,R34,R35,R51,R52,R53,R3,s193,The plan of block b, the statement whose last use of di is in it: its let's declared variables and the\n  dead outer ones; a variable only its declarations use is cleared once they ran (:start).R4,i2043,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,plan-stmtm12,R7,TR0,L1,V4,Myn4,planm2,R34,R35,R51,R54,R53,R3,s93,Plans statement s, the last use of the variables di (a vector): its sub-lists, and its entry.R4,i2056,R5,i1,R6,s18,arbace/go/build.aem12,R7,TR0,L1,V4,Myn4,planm2,R34,R35,R51,R55,Myn4,deadm2,R34,R35,R3,s101,Plans a statement list: for each variable of dead (an IdentityHashMap) the statement of its last use.R4,i2081,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,plan-fn*m8,R50,TR4,i2095,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build7,plan-fnm10,R0,L1,V1,R39,R3,s219,The liveness plan of function tree (an IdentityHashMap statement -> entry), nil when there is none to make:\n  the function has a goto, or liveness is off (GOI_LIVENESS=0), or its tree is not of the shape the plan reads.R4,i2097,R5,i1,R6,s18,arbace/go/build.aem10,R7,TR0,L1,V1,R39,R4,i2106,R5,i1,R6,s18,arbace/go/build.aem12,R7,TR0,L1,V3,R56,R57,R58,R3,s61,The statement clearing R slots rs, S slots ss and C slots cs.R4,i2128,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build14,clear-slots-ofm12,R7,TR0,L1,V1,R59,R3,s98,The node clearing the slots of objects objs (those with a slot of R or S kind, or a cell), or nil.R4,i2135,R5,i1,R6,s18,arbace/go/build.aem12,R7,TR0,L1,V2,V4,R60,R11,R61,R2,R62,R3,s202,Node [k n] of an argument of the current simple statement, clearing the variables whose every reference\n  in the statement it holds as it is evaluated (the value then lives in the callee's frame alone).R4,i2148,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build4,jumpm10,R7,TR0,L1,V1,R63,R4,i2173,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,push-targetm10,R7,TR0,L1,V2,R64,R33,R4,i2175,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,innermostm10,R7,TR0,L1,V1,R65,R4,i2177,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,block-stmtsm10,R7,TR0,L1,V1,R11,R4,i2179,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,stmt-linem12,R7,TR0,L1,V1,R54,R3,s31,A statement's line (S51), or 0.R4,i2181,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,quiet-header?m8,R50,TR4,i2196,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build12,quiet-basic?m10,R7,TR0,L1,V1,R12,R4,i2198,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build12,quiet-const?m10,R7,TR0,L1,V1,R11,R4,i2200,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build14,quiet-builtinsS8,s3,mins3,maxs3,news4,imags4,reals3,lens3,caps7,complexm8,R7,TR4,i2202,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build15,quiet-cmp-type?m10,R7,TR0,L1,V1,R12,R4,i2204,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,quiet-expr?m12,R7,TR0,L1,V1,R11,R3,s90,Whether checked expression n can neither panic nor call (conservative: unknown kinds can).R4,i2208,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build12,quiet-place?m12,R7,TR0,L1,V1,R1,R3,s56,Whether assigning to place p can neither panic nor call.R4,i2252,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build19,quiet-block-header?m10,R7,TR0,L1,V1,R52,R4,i2265,R5,i1,R6,s18,arbace/go/build.aem12,R7,TR0,L1,V1,R11,R3,s137,Whether statement n's own part (its nested statement lists left out: they store their own\n  lines) can neither panic nor call (GC26 (b)).R4,i2270,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build12,hoisted-linem12,R7,TR0,L1,V1,R11,R3,s334,A loop's hoisted line (GR5.1): a for or range statement whose own part is quiet and whose\n  body is one statement without statement lists of its own that can panic or call stores that\n  statement's line once, before the loop, rather than at each iteration (the frame's line is\n  then the same at every point that can raise); else nil.R4,i2309,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,stored-linem12,R7,TR0,L1,V1,R54,R3,s140,The line statement s stores in the frame before it runs (0: none, it can neither panic nor\n  call; GC26 (b)); a loop's hoisted line (GR5.1).R4,i2324,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,loop-bodym12,R7,TR0,L1,V1,R11,R3,s130,A for or range statement's body: a statement list storing its lines, or a hoisted line's\n  one statement without its line (GR5.1).R4,i2333,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,body-nodem12,R7,TR0,L1,V1,R55,R3,s165,A statement list's node (a SeqL with its labels' goto codes and the lines its statements that\n  can panic or call store in the frame, for traces: §10.6, GR5, GR5.1).R4,i2341,R5,i1,R6,s18,arbace/go/build.aem8,R0,L1,V1,R55,R4,i2358,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,start-clearm12,R7,TR0,L1,V1,R11,R3,s100,The node clearing the variables dead from the start of block n (the liveness plan's :start), or nil.R4,i2360,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,block-nodem12,R7,TR0,L1,V1,R11,R3,s62,A block's node: its declarations (a let's) and its statements.R4,i2366,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,loop-targetm10,R7,TR0,L1,V1,R11,R4,i2390,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build19,per-iteration-cellsm10,R7,TR0,L1,V1,R59,R4,i2397,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,for-stmtm10,R7,TR0,L1,V1,R11,R4,i2402,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,range-targetsm12,R7,TR0,L1,V1,R11,R3,s99,The key and value targets of a range: [obj-or-place-or-nil ...] and whether they are new variables.R4,i2412,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,idx-setterm10,R7,TR0,L1,V3,R64,R66,R12,R4,i2419,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,at-setterm10,R7,TR0,L1,V3,R64,R66,R12,R4,i2430,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,any-setterm10,R7,TR0,L1,V3,R64,R66,R12,R4,i2441,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,has-call?m12,R7,TR0,L1,V1,R11,R3,s157,Whether checked node n has a call (not of a constant) or a receive in it (an array's length is\n  then not constant: the specification's len and range rules).R4,i2452,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build16,range-elem-typesm12,R7,TR0,L1,V1,R11,R3,s65,The types of a range's iteration values: [key value] (nil: none).R4,i2463,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,range-stmtm10,R7,TR0,L1,V1,R11,R4,i2478,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,switch-stmtm10,R7,TR0,L1,V1,R11,R4,i2558,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,return-stmtm10,R7,TR0,L1,V1,R11,R4,i2584,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build13,deferred-callm12,R7,TR0,L1,V1,R67,R3,s189,The parts of a deferred or go statement's call n (SPEC.md §7.9, §8.1): its callee and\n  arguments evaluated now into a frame of their own, the call made later from it: [setters T\n  counts].R4,i2600,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,defer-stmtm10,R7,TR0,L1,V1,R11,R4,i2657,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build7,go-stmtm10,R7,TR0,L1,V1,R11,R4,i2662,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,send-stmtm10,R7,TR0,L1,V1,R11,R4,i2666,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build16,type-switch-stmtm10,R7,TR0,L1,V1,R11,R4,i2670,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,select-recvm12,R7,TR0,L1,V1,R63,R3,s230,A receive clause's communication c (an expression statement, a declaration or an\n  assignment of a receive): [the receive node, the statement binding its values (nil: none)]\n  with the receive replaced by the select's temporaries.R4,i2697,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build12,at-case-linem12,R7,TR0,L1,V4,R68,R11,R69,R63,R3,s148,A select case's channel node, at the case's line when it has one of its own (gc's line of a\n  panic evaluating it: GOI-SPEC.md, \"Since v1: frames\").R4,i2721,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,select-stmtm10,R7,TR0,L1,V1,R11,R4,i2730,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build5,stmt*m12,R7,TR0,L1,V1,R11,R3,s24,The node of statement n.R4,i2751,R5,i1,R6,s18,arbace/go/build.aem12,R7,TR0,L1,V2,R33,R70,R3,s129,The node (f) builds, with the logged temporaries it used and the nodes after cleared once it has run; extra\n  (nodes) come first.R4,i2791,R5,i1,R6,s18,arbace/go/build.aem10,R0,L1,V1,R11,R3,s131,The node of statement n, followed by the clearing of the variables the liveness plan ends with it and of\n  the temporaries it used.R4,i2803,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,has-defer?m12,R7,TR0,L1,V1,R38,R3,s71,Whether a function's body defers (not counting its function literals').R4,i2830,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,free-localsm12,R7,TR0,L1,V1,R71,R3,s135,The local variables a function literal's body refers to that it does not declare: the cells\n  it captures, in order of first reference.R4,i2843,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,gc-prefixm10,R0,L1,V0,R3,s105,The package part of gc's names of the functions of the package being built: main's main, else\n  its path.R4,i2876,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build12,gc-func-namem12,R7,TR0,L1,V2,R39,R72,R3,s207,gc's name of the function of tree (built as fname): a literal's or an initialization's given\n  (:gc-name), a method's pkg.T.M or pkg.(*T).M (a generic type's pkg.T[...].M, pkg.(*T[...]).M),\n  else pkg.fname.R4,i2882,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,code-frame!m10,R0,L1,V5,R73,R74,R75,R76,R77,R3,s167,Gives code its frames' data for runtime's API (GOI-SPEC.md, \"Since v1: frames\"): gc's name,\n  the source directory, its first and last lines, whether it has arguments.R4,i2894,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,code-endm12,R7,TR0,L1,V1,R39,R3,s271,The last line of a function's code as gc's line table has it: its closing brace's (:go/end,\n  where a function that ends without a return returns and runs its deferred calls), or the line\n  of its last statement when that is a return (gc emits no code at the brace then).R4,i2902,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build14,file-line-dirsm10,R0,L1,V1,R78,R3,s186,The //line directives of a Go file's declaration forms decls, between the declarations and in\n  the functions' bodies, in order: [{:line :text}] (gc applies one to the rest of its file).R4,i2915,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,line-dirs!m12,R7,TR0,L1,V4,R73,R39,R79,R80,R3,s482,Gives code the //line directives that apply to function tree (gc's updateBase: a comment //line\n  FILE:LINE or FILE:LINE:COL makes the next line LINE of FILE, to the next directive or the file's\n  end; an empty FILE is ?? without COL, the file before with it), for its frames (GOI-SPEC.md,\n  \"Since v1: frames\"): its Go file's (go-file; the context's :line-dirs, every directive before\n  the function's end, between declarations and in other functions' bodies too), else its body's.R4,i2932,R5,i1,R6,s18,arbace/go/build.aem10,R0,L1,V3,R39,R72,R81,R3,s243,The *goi.Code of a function node (:func, :fn, :body) with its signature sig; captures, the\n  cells it receives first (a literal's); a method's receiver (:recv, of type :recv-type or its\n  method object's) laid after the parameters and results.R4,i2970,R5,i1,R6,s18,arbace/go/build.aem10,R0,L1,V1,R11,R3,s55,A function literal's closure node (its code built now).R4,i3037,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,build-funcm10,R0,L1,V1,R39,R3,s83,The code of a package-level function's checked tree (built on its first call, S18).R4,i3052,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,build-initsm10,R0,L1,V2,R82,R83,R3,s401,The code of a package's initialization: its variables' initializers in initialization order\n  (trees {:op :var-init :lhs :rhs}), as a function of no parameters. cell-of, when given: an\n  initializer's function cell (its file's), made its frame's function before it runs when it is\n  not the one before's (FrameFn: gc's package init function, one function whose lines are in each\n  initializer's file).R4,i3059,R5,i1,R6,s18,arbace/go/build.aem10,R0,L1,V2,R12,R84,R3,s135,Type ty with the types of map m replaced: type parameters, and the local named types of a\n  generic declaration copied for an instance.R4,i3097,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,type-keysS7,R15,R85,R18,R22,R23,R24,R31,m8,R7,TR4,i3129,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,obj-keysS3,R86,R26,R29,m8,R7,TR4,i3130,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,objs-keysS3,R19,R87,R30,m8,R7,TR4,i3131,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,skip-keysS10,R16,R17,R88,R89,R25,R90,R91,R92,R93,R28,m8,R7,TR4,i3132,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build11,local-typesm12,R7,TR0,L1,V1,R39,R3,s56,The local named types a checked tree declares, in order.R4,i3134,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build10,resolve-onm12,R7,TR0,L1,V2,R11,R13,R3,s183,A method selection on a type parameter (an interface method of its constraint) resolved for\n  the instance's type T: the method T's method set has (§9.2): a method, or an interface's.R4,i3147,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,inst-treem10,R0,L2,V2,R39,R84,V3,R39,R84,R94,R3,s368,The checked tree of a generic declaration for the type arguments of map m (type parameter ->\n  type): every type substituted, its local variables and local named types copied with their\n  types, the method selections on its type parameters resolved, its constants represented at\n  their types (a float32's rounded), the sizes that depended on type parameters constant.R4,i3165,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,instancesm8,R3,s89,The instances of generic functions and methods (§9.2): [object descriptors] -> *goi.Func.R4,i3245,R5,i1,R6,s18,arbace/go/build.aem8,R3,s89,The instances of generic functions and methods (§9.2): [object descriptors] -> *goi.Func.R4,i3245,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build9,inst-gensm8,R7,TR4,i3248,R5,i1,R6,s18,arbace/go/build.aem8,R7,TR4,i3248,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build6,rt-sigm8,R50,TR4,i3250,R5,i1,R6,s18,arbace/go/build.aev15,arbace.go.build8,sym-namem8,R50,TR4,i3252,R5,i1,R6,s18,arbace/go/build.aem10,R0,L1,V1,R12,R3,s288,A type's name as gc's runtime writes it in an instance's name (its type arguments: cmd/compile's\n  LinkString), an assertion's message: named types by package path, a function-scoped one with its\n  ·N, an instance's and a generic function's local type's type arguments in brackets (GR9c).R4,i3254,R5,i1,R6,s18,arbace/go/build.ae")

var Lit_850 *jrt.String = jrt.Intern("arbace.go.build$assign_to")

var Lit_851 *jrt.String = jrt.Intern("arbace.go.build$temps_of")

var Lit_852 *jrt.String = jrt.Intern("arbace.go.build$rhs_nodes")

var Lit_853 *jrt.String = jrt.Intern("arbace.go.build$prepare_place")

var Lit_854 *jrt.String = jrt.Intern("arbace.go.build$assign_stmt")

var Lit_855 *jrt.String = jrt.Intern("arbace.go.build$op_assign_stmt")

var Lit_856 *jrt.String = jrt.Intern("arbace.go.build$one_of")

var Lit_857 *jrt.String = jrt.Intern("arbace.go.build$incdec_stmt")

var Lit_858 *jrt.String = jrt.Intern("arbace.go.build$zero_init")

var Lit_859 *jrt.String = jrt.Intern("arbace.go.build$init_var")

var Lit_860 *jrt.String = jrt.Intern("arbace.go.build$decl_stmt")

var Lit_861 *jrt.String = jrt.Intern("arbace.go.build$fn__367000759")

var Lit_862 *jrt.String = jrt.Intern("arbace.go.build$fn__367000761")

var Lit_863 *jrt.String = jrt.Intern("arbace.go.build$walk_objs")

var Lit_864 *jrt.String = jrt.Intern("arbace.go.build$refs_of")

var Lit_865 *jrt.String = jrt.Intern("arbace.go.build$id_set")

var Lit_866 *jrt.String = jrt.Intern("arbace.go.build$has_goto_QMARK_")

var Lit_867 *jrt.String = jrt.Intern("arbace.go.build$candidates")

var Lit_868 *jrt.String = jrt.Intern("arbace.go.build$plan_block")

var Lit_869 *jrt.String = jrt.Intern("arbace.go.build$plan_stmt")

var Lit_870 *jrt.String = jrt.Intern("arbace.go.build$plan_list")

var Lit_871 *jrt.String = jrt.Intern("arbace.go.build$plan_fn")

var Lit_872 *jrt.String = jrt.Intern("arbace.go.build$plan_fn_STAR_")

var Lit_873 *jrt.String = jrt.Intern("arbace.go.build$slots_clear")

var Lit_874 *jrt.String = jrt.Intern("arbace.go.build$clear_slots_of")

var Lit_875 *jrt.String = jrt.Intern("arbace.go.build$kill_arg")

var Lit_876 *jrt.String = jrt.Intern("arbace.go.build$jump")

var Lit_877 *jrt.String = jrt.Intern("arbace.go.build$push_target")

var Lit_878 *jrt.String = jrt.Intern("arbace.go.build$innermost")

var Lit_879 *jrt.String = jrt.Intern("arbace.go.build$block_stmts")

var Lit_880 *jrt.String = jrt.Intern("arbace.go.build$stmt_line")

var Lit_881 *jrt.String = jrt.Intern("arbace.go.build$quiet_basic_QMARK_")

var Lit_882 *jrt.String = jrt.Intern("arbace.go.build$quiet_const_QMARK_")

var Lit_883 *jrt.String = jrt.Intern("arbace.go.build$quiet_cmp_type_QMARK_")

var Lit_884 *jrt.String = jrt.Intern("arbace.go.build$quiet_expr_QMARK_")

var Lit_885 *jrt.String = jrt.Intern("arbace.go.build$quiet_place_QMARK_")

var Lit_886 *jrt.String = jrt.Intern("arbace.go.build$quiet_block_header_QMARK_")

var Lit_887 *jrt.String = jrt.Intern("arbace.go.build$quiet_header_QMARK_")

var Lit_888 *jrt.String = jrt.Intern("arbace.go.build$hoisted_line")

var Lit_889 *jrt.String = jrt.Intern("arbace.go.build$stored_line")

var Lit_890 *jrt.String = jrt.Intern("arbace.go.build$loop_body")

var Lit_891 *jrt.String = jrt.Intern("arbace.go.build$body_node")

var Lit_892 *jrt.String = jrt.Intern("arbace.go.build$stmt_list")

var Lit_893 *jrt.String = jrt.Intern("arbace.go.build$start_clear")

var Lit_894 *jrt.String = jrt.Intern("arbace.go.build$block_node")

var Lit_895 *jrt.String = jrt.Intern("arbace.go.build$loop_target")

var Lit_896 *jrt.String = jrt.Intern("arbace.go.build$per_iteration_cells")

var Lit_897 *jrt.String = jrt.Intern("arbace.go.build$for_stmt")

var Lit_898 *jrt.String = jrt.Intern("arbace.go.build$range_targets")

var Lit_899 *jrt.String = jrt.Intern("arbace.go.build$idx_setter")

var Lit_900 *jrt.String = jrt.Intern("arbace.go.build$at_setter")

var Lit_901 *jrt.String = jrt.Intern("arbace.go.build$any_setter")

var Lit_902 *jrt.String = jrt.Intern("arbace.go.build$has_call_QMARK_")

var Lit_903 *jrt.String = jrt.Intern("arbace.go.build$range_elem_types")

var Lit_904 *jrt.String = jrt.Intern("arbace.go.build$range_stmt")

var Lit_905 *jrt.String = jrt.Intern("arbace.go.build$switch_stmt")

var Lit_906 *jrt.String = jrt.Intern("arbace.go.build$return_stmt")

var Lit_907 *jrt.String = jrt.Intern("arbace.go.build$deferred_call")

var Lit_908 *jrt.String = jrt.Intern("arbace.go.build$defer_stmt")

var Lit_909 *jrt.String = jrt.Intern("arbace.go.build$go_stmt")

var Lit_910 *jrt.String = jrt.Intern("arbace.go.build$send_stmt")

var Lit_911 *jrt.String = jrt.Intern("arbace.go.build$type_switch_stmt")

var Lit_912 *jrt.String = jrt.Intern("arbace.go.build$select_recv")

var Lit_913 *jrt.String = jrt.Intern("arbace.go.build$at_case_line")

var Lit_914 *jrt.String = jrt.Intern("arbace.go.build$select_stmt")

var Lit_915 *jrt.String = jrt.Intern("arbace.go.build$stmt_STAR_")

var Lit_916 *jrt.String = jrt.Intern("arbace.go.build$with_temp_clears")

var Lit_917 *jrt.String = jrt.Intern("arbace.go.build$stmt")

var Lit_918 *jrt.String = jrt.Intern("arbace.go.build$has_defer_QMARK_")

var Lit_919 *jrt.String = jrt.Intern("arbace.go.build$free_locals")

var Lit_920 *jrt.String = jrt.Intern("arbace.go.build$gc_prefix")

var Lit_921 *jrt.String = jrt.Intern("arbace.go.build$gc_func_name")

var Lit_922 *jrt.String = jrt.Intern("arbace.go.build$code_frame_BANG_")

var Lit_923 *jrt.String = jrt.Intern("arbace.go.build$code_end")

var Lit_924 *jrt.String = jrt.Intern("arbace.go.build$file_line_dirs")

var Lit_925 *jrt.String = jrt.Intern("arbace.go.build$line_dirs_BANG_")

var Lit_926 *jrt.String = jrt.Intern("arbace.go.build$build_code")

var Lit_927 *jrt.String = jrt.Intern("arbace.go.build$build_fn_lit")

var Lit_928 *jrt.String = jrt.Intern("arbace.go.build$build_func")

var Lit_929 *jrt.String = jrt.Intern("arbace.go.build$build_inits")

var Lit_930 *jrt.String = jrt.Intern("arbace.go.build$isubst")

var Lit_931 *jrt.String = jrt.Intern("arbace.go.build$local_types")

var Lit_932 *jrt.String = jrt.Intern("arbace.go.build$resolve_on")

var Lit_933 *jrt.String = jrt.Intern("arbace.go.build$inst_tree")

var Lit_934 *jrt.String = jrt.Intern("arbace.go.build$rt_name")

var Lit_935 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn1,_yn2,psyn2,rsyn8,variadickn3,dockn4,linekn6,columnkn4,fileyn1,iyn7,vargen?yn2,tyyn1,xyn5,targsyn2,nmkn8,declaredm12,R0,TR1,L1,V1,V4,R2,R3,R4,R5,R6,s63,A signature's text as gc's runtime writes it: (params) results.R7,i3288,R8,i1,R9,s18,arbace/go/build.aem12,R0,TR1,L1,V2,R10,R11,R6,s427,A named type's symbol as gc's noder names it (reader.go's mangle): its name, then in brackets\n  the type arguments of the generic function it is local to (an instance's copy of it,\n  :goi/implicits), ';', and its own (an instance's), each by rt-name; with vargen? a function-scoped\n  type's ·N after them (writer.go's qualifiedIdent), which the runtime's name of the type itself\n  leaves out (types/fmt.go's SplitVargenSuffix).R7,i3297,R8,i1,R9,s18,arbace/go/build.aem10,R1,L1,V1,R12,R6,s154,A generic type's instance's name, as gc's runtime names it: pkg.T[args] (GC31), and a generic\n  function's local type's: pkg.T[implicit args;args] (GR9c).R7,i3312,R8,i1,R9,s18,arbace/go/build.aem10,R1,L1,V1,R12,R6,s186,The generation of a generic type's instance: one per origin and type arguments' descriptors,\n  so that the instances' descriptors (interned by package, name and generation) are distinct.R7,i3319,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build13,instance-namem12,R0,TR1,L1,V1,R13,R6,s65,An instance's function name in traces, gc's: F[...], (*T[...]).M.R7,i3332,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build14,build-instancem12,R0,TR1,L1,V3,R13,R14,R15,R6,s116,The code of generic function or method x's instance for targs (its receiver's type arguments\n  first, then its own).R7,i3342,R8,i1,R9,s18,arbace/go/build.aev15,arbace.go.build14,instance-cell*m8,R16,TR7,i3356,R8,i1,R9,s18,arbace/go/build.aem10,R1,L1,V2,R13,R14,R6,s361,The *goi.Func of generic function or method x instantiated with targs: one per type-argument\n  list (by their descriptors, G7 (a): no body shared between lists), its code built by its\n  package's build context (:ctx-of) on its first call, or now when building eagerly. GR8a:\n  reflect.TypeFor of an interpreted interface is reflect's goiNilType (nil, GC62 (a)).R7,i3358,R8,i1,R9,s18,arbace/go/build.aem10,R0,TR1,L1,V2,R13,R14,R7,i3370,R8,i1,R9,s18,arbace/go/build.ae")

var Lit_936 *jrt.String = jrt.Intern("arbace.go.build$rt_sig")

var Lit_937 *jrt.String = jrt.Intern("arbace.go.build$sym_name")

var Lit_938 *jrt.String = jrt.Intern("arbace.go.build$inst_type_name")

var Lit_939 *jrt.String = jrt.Intern("arbace.go.build$inst_gen")

var Lit_940 *jrt.String = jrt.Intern("arbace.go.build$instance_name")

var Lit_941 *jrt.String = jrt.Intern("arbace.go.build$build_instance")

var Lit_942 *jrt.String = jrt.Intern("arbace.go.build$instance_cell")

var Lit_943 *jrt.String = jrt.Intern("arbace.go.build$instance_cell_STAR_")
