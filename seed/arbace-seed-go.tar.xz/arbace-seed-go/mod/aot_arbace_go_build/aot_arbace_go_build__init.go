//line aot_arbace_go_build__init.ae:1
package aot_arbace_go_build

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_build__init_part0_A_Unit0__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_build__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_build__init_part0_A_const_1) }
//line :1:1
func A_arbace_go_build__init_part0_A_Unit1__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_build__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_2)) }
//line :1:1
func A_arbace_go_build__init_part0_A_Unit2__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_go_build_eval367000004_loading__1927001464__auto____367000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_build_eval367000004_loading__1927001464__auto____367000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_501, false); A_arbace_go_build_eval367000004_loading__1927001464__auto____367000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_go_build__init_part0_A_Unit3__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_build__init_part0_A_const_1)).Equals_O__Z(A_arbace_go_build__init_part0_A_const_3) { return nil } else { var tmp1 any = A_arbace_go_build_eval367000008_fn__367000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_build_eval367000008_fn__367000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_502, false); A_arbace_go_build_eval367000008_fn__367000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
//line :1:1
func A_arbace_go_build__init_part0_A_Init__O() any { A_arbace_go_build__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_go_build__init_part0_A_Load__O() any { A_arbace_go_build__init_part0_A_Init(); A_arbace_go_build__init_part0_A_Unit0__O(); A_arbace_go_build__init_part0_A_Unit1__O(); A_arbace_go_build__init_part0_A_Unit2__O(); A_arbace_go_build__init_part0_A_Unit3__O(); A_arbace_go_build__init_part0_A_Unit4__O(); A_arbace_go_build__init_part0_A_Unit5__O(); A_arbace_go_build__init_part0_A_Unit6__O(); A_arbace_go_build__init_part0_A_Unit7__O(); A_arbace_go_build__init_part0_A_Unit8__O(); A_arbace_go_build__init_part0_A_Unit9__O(); A_arbace_go_build__init_part0_A_Unit10__O(); A_arbace_go_build__init_part0_A_Unit11__O(); A_arbace_go_build__init_part0_A_Unit12__O(); A_arbace_go_build__init_part0_A_Unit13__O(); A_arbace_go_build__init_part0_A_Unit14__O(); A_arbace_go_build__init_part0_A_Unit15__O(); A_arbace_go_build__init_part0_A_Unit16__O(); A_arbace_go_build__init_part0_A_Unit17__O(); A_arbace_go_build__init_part0_A_Unit18__O(); A_arbace_go_build__init_part0_A_Unit19__O(); A_arbace_go_build__init_part0_A_Unit20__O(); A_arbace_go_build__init_part0_A_Unit21__O(); A_arbace_go_build__init_part0_A_Unit22__O(); A_arbace_go_build__init_part0_A_Unit23__O(); A_arbace_go_build__init_part0_A_Unit24__O(); A_arbace_go_build__init_part0_A_Unit25__O(); A_arbace_go_build__init_part0_A_Unit26__O(); A_arbace_go_build__init_part0_A_Unit27__O(); A_arbace_go_build__init_part0_A_Unit28__O(); A_arbace_go_build__init_part0_A_Unit29__O(); A_arbace_go_build__init_part0_A_Unit30__O(); A_arbace_go_build__init_part0_A_Unit31__O(); A_arbace_go_build__init_part0_A_Unit32__O(); A_arbace_go_build__init_part0_A_Unit33__O(); A_arbace_go_build__init_part0_A_Unit34__O(); A_arbace_go_build__init_part0_A_Unit35__O(); A_arbace_go_build__init_part0_A_Unit36__O(); A_arbace_go_build__init_part0_A_Unit37__O(); A_arbace_go_build__init_part0_A_Unit38__O(); A_arbace_go_build__init_part0_A_Unit39__O(); A_arbace_go_build__init_part0_A_Unit40__O(); A_arbace_go_build__init_part0_A_Unit41__O(); A_arbace_go_build__init_part0_A_Unit42__O(); A_arbace_go_build__init_part0_A_Unit43__O(); A_arbace_go_build__init_part0_A_Unit44__O(); A_arbace_go_build__init_part0_A_Unit45__O(); A_arbace_go_build__init_part0_A_Unit46__O(); A_arbace_go_build__init_part0_A_Unit47__O(); A_arbace_go_build__init_part0_A_Unit48__O(); A_arbace_go_build__init_part0_A_Unit49__O(); A_arbace_go_build__init_part0_A_Unit50__O(); A_arbace_go_build__init_part0_A_Unit51__O(); A_arbace_go_build__init_part0_A_Unit52__O(); A_arbace_go_build__init_part0_A_Unit53__O(); A_arbace_go_build__init_part0_A_Unit54__O(); A_arbace_go_build__init_part0_A_Unit55__O(); A_arbace_go_build__init_part0_A_Unit56__O(); A_arbace_go_build__init_part0_A_Unit57__O(); A_arbace_go_build__init_part0_A_Unit58__O(); A_arbace_go_build__init_part0_A_Unit59__O(); A_arbace_go_build__init_part0_A_Unit60__O(); A_arbace_go_build__init_part0_A_Unit61__O(); A_arbace_go_build__init_part0_A_Unit62__O(); A_arbace_go_build__init_part0_A_Unit63__O(); A_arbace_go_build__init_part0_A_Unit64__O(); A_arbace_go_build__init_part0_A_Unit65__O(); A_arbace_go_build__init_part0_A_Unit66__O(); A_arbace_go_build__init_part0_A_Unit67__O(); A_arbace_go_build__init_part0_A_Unit68__O(); A_arbace_go_build__init_part0_A_Unit69__O(); A_arbace_go_build__init_part0_A_Unit70__O(); A_arbace_go_build__init_part0_A_Unit71__O(); A_arbace_go_build__init_part0_A_Unit72__O(); A_arbace_go_build__init_part0_A_Unit73__O(); A_arbace_go_build__init_part0_A_Unit74__O(); A_arbace_go_build__init_part0_A_Unit75__O(); A_arbace_go_build__init_part0_A_Unit76__O(); A_arbace_go_build__init_part0_A_Unit77__O(); A_arbace_go_build__init_part0_A_Unit78__O(); A_arbace_go_build__init_part0_A_Unit79__O(); A_arbace_go_build__init_part0_A_Unit80__O(); A_arbace_go_build__init_part0_A_Unit81__O(); A_arbace_go_build__init_part0_A_Unit82__O(); A_arbace_go_build__init_part0_A_Unit83__O(); A_arbace_go_build__init_part0_A_Unit84__O(); A_arbace_go_build__init_part0_A_Unit85__O(); A_arbace_go_build__init_part0_A_Unit86__O(); A_arbace_go_build__init_part0_A_Unit87__O(); A_arbace_go_build__init_part0_A_Unit88__O(); A_arbace_go_build__init_part0_A_Unit89__O(); A_arbace_go_build__init_part0_A_Unit90__O(); A_arbace_go_build__init_part0_A_Unit91__O(); A_arbace_go_build__init_part0_A_Unit92__O(); A_arbace_go_build__init_part0_A_Unit93__O(); A_arbace_go_build__init_part0_A_Unit94__O(); A_arbace_go_build__init_part0_A_Unit95__O(); A_arbace_go_build__init_part0_A_Unit96__O(); A_arbace_go_build__init_part0_A_Unit97__O(); A_arbace_go_build__init_part0_A_Unit98__O(); A_arbace_go_build__init_part0_A_Unit99__O(); return nil }



func A_arbace_go_build__init_A_Load__O() any { jrt.StartCheck(); A_arbace_go_build__init_part0_A_Init__O(); A_arbace_go_build__init_part1_A_Init__O(); A_arbace_go_build__init_part0_A_Load__O(); A_arbace_go_build__init_part1_A_Load__O(); return nil }























func A_arbace_go_build__init_part0_A_Unit4__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_4; var tmp2 any = A_arbace_go_build_op_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_build_op_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_503, true); A_arbace_go_build_op_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_5)); return A_arbace_go_build__init_part0_A_const_4 }




func A_arbace_go_build__init_part0_A_Unit5__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_6; var tmp2 any = A_arbace_go_build_oa_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_build_oa_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_504, false); A_arbace_go_build_oa_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_7)); return A_arbace_go_build__init_part0_A_const_6 }

func A_arbace_go_build__init_part0_A_Unit6__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_8; var tmp2 any = A_arbace_go_build_unsupported_BANG__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_build_unsupported_BANG__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_505, false); A_arbace_go_build_unsupported_BANG__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_9)); return A_arbace_go_build__init_part0_A_const_8 }






func A_arbace_go_build__init_part0_A_Unit7__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); A_arbace_go_build__init_part0_A_const_10.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_11)); return A_arbace_go_build__init_part0_A_const_10.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_build__init_part0_A_Unit8__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(49, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_13)); v__1927001498__auto____1 = A_arbace_go_build__init_part0_A_const_12; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_build__init_part0_A_const_12; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_16)); var tmp3 *lang.Var = A_arbace_go_build__init_part0_A_const_12; var tmp4 any; var root_6 any = A_arbace_go_build__init_part0_A_const_14.GetRawRoot__O(); var linked_7 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_6, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_8 lang.IFn
							if linked_7 == nil { ifn_8 = lang.IFn_Cast(root_6) } else { ifn_8 = nil }; var arg_9 any = A_arbace_go_build__init_part0_A_const_15; if linked_7 == nil { tmp4 = ifn_8.Invoke_O__O(arg_9) } else { tmp4 = linked_7.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_6, arg_9) }
//line :49:1
	tmp3.BindRoot_O__V(tmp4); return A_arbace_go_build__init_part0_A_const_12 } }


func A_arbace_go_build__init_part0_A_Unit9__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(52, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_17; var tmp2 any = A_arbace_go_build_method_data_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_build_method_data_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_506, false); A_arbace_go_build_method_data_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_18)); return A_arbace_go_build__init_part0_A_const_17 }






func A_arbace_go_build__init_part0_A_Unit10__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(59, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_19; var tmp2 any = A_arbace_go_build_with_ctx_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_build_with_ctx_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_507, false); A_arbace_go_build_with_ctx_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_20)); return A_arbace_go_build__init_part0_A_const_19 }





func A_arbace_go_build__init_part0_A_Unit11__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); A_arbace_go_build__init_part0_A_const_21.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_21; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_22)); return A_arbace_go_build__init_part0_A_const_21.SetDynamic_Z__Var(true).Ref() }






func A_arbace_go_build__init_part0_A_Unit12__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_23; var tmp2 any = A_arbace_go_build_compiled_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_go_build_compiled_QMARK__A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_508, false); A_arbace_go_build_compiled_QMARK__A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_24)); return A_arbace_go_build__init_part0_A_const_23 }



func A_arbace_go_build__init_part0_A_Unit13__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(76, 1); A_arbace_go_build__init_part0_A_const_25.BindRoot_O__V(A_arbace_go_build__init_part0_A_const_26); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_25; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_27)); return A_arbace_go_build__init_part0_A_const_25 }


func A_arbace_go_build__init_part0_A_Unit14__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(79, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_28; var tmp2 any = A_arbace_go_build_kind_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_build_kind_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_509, false); A_arbace_go_build_kind_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_29)); return A_arbace_go_build__init_part0_A_const_28 }











func A_arbace_go_build__init_part0_A_Unit15__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(91, 1); A_arbace_go_build__init_part0_A_const_30.BindRoot_O__V(A_arbace_go_build__init_part0_A_const_31); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_32)); return A_arbace_go_build__init_part0_A_const_30 }



func A_arbace_go_build__init_part0_A_Unit16__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_33; var tmp2 any = A_arbace_go_build_basic_of_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_build_basic_of_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_510, false); A_arbace_go_build_basic_of_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_34)); return A_arbace_go_build__init_part0_A_const_33 }
func A_arbace_go_build__init_part0_A_Unit17__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(96, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_35; var tmp2 any = A_arbace_go_build_unsigned_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_build_unsigned_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_511, false); A_arbace_go_build_unsigned_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_36)); return A_arbace_go_build__init_part0_A_const_35 }
func A_arbace_go_build__init_part0_A_Unit18__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_37; var tmp2 any = A_arbace_go_build_wide_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_build_wide_QMARK__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_512, false); A_arbace_go_build_wide_QMARK__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_38)); return A_arbace_go_build__init_part0_A_const_37 }
func A_arbace_go_build__init_part0_A_Unit19__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(98, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_39; var tmp2 any = A_arbace_go_build_struct_or_array_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_build_struct_or_array_QMARK__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_513, false); A_arbace_go_build_struct_or_array_QMARK__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_40)); return A_arbace_go_build__init_part0_A_const_39 }
func A_arbace_go_build__init_part0_A_Unit20__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_41; var tmp2 any = A_arbace_go_build_iface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_build_iface_QMARK__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_514, false); A_arbace_go_build_iface_QMARK__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_42)); return A_arbace_go_build__init_part0_A_const_41 }

func A_arbace_go_build__init_part0_A_Unit21__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_44)); return A_arbace_go_build__init_part0_A_const_43 }

func A_arbace_go_build__init_part0_A_Unit22__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_45; var tmp2 any = A_arbace_go_build_interpreted_named_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_build_interpreted_named_QMARK__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_515, false); A_arbace_go_build_interpreted_named_QMARK__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_46)); return A_arbace_go_build__init_part0_A_const_45 }


func A_arbace_go_build__init_part0_A_Unit23__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_47; var tmp2 any = A_arbace_go_build_recursive_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_go_build_recursive_QMARK__A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_516, false); A_arbace_go_build_recursive_QMARK__A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_48)); return A_arbace_go_build__init_part0_A_const_47 }























func A_arbace_go_build__init_part0_A_Unit24__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(130, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_49; var tmp2 any = A_arbace_go_build_tag_text_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_build_tag_text_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_517, false); A_arbace_go_build_tag_text_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_50)); return A_arbace_go_build__init_part0_A_const_49 }

func A_arbace_go_build__init_part0_A_Unit25__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_51; var tmp2 any = A_arbace_go_build_struct_parts_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_go_build_struct_parts_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_518, false); A_arbace_go_build_struct_parts_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_52)); return A_arbace_go_build__init_part0_A_const_51 }









func A_arbace_go_build__init_part0_A_Unit26__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(142, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_53; var tmp2 any = A_arbace_go_build_method_key_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_build_method_key_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_519, false); A_arbace_go_build_method_key_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_54)); return A_arbace_go_build__init_part0_A_const_53 }




func A_arbace_go_build__init_part0_A_Unit27__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(147, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_55; var tmp2 any = A_arbace_go_build_set_iface_methods_BANG__A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_go_build_set_iface_methods_BANG__A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_520, false); A_arbace_go_build_set_iface_methods_BANG__A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_56)); return A_arbace_go_build__init_part0_A_const_55 }







func A_arbace_go_build__init_part0_A_Unit28__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(155, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_57; var tmp2 any = A_arbace_go_build_local_gen_of_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_build_local_gen_of_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_521, false); A_arbace_go_build_local_gen_of_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_58)); return A_arbace_go_build__init_part0_A_const_57 }



func A_arbace_go_build__init_part0_A_Unit29__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(159, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_59; var tmp2 any = A_arbace_go_build_named_desc_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_go_build_named_desc_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_522, false); A_arbace_go_build_named_desc_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_60)); return A_arbace_go_build__init_part0_A_const_59 }








































func A_arbace_go_build__init_part0_A_Unit30__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(200, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_43; var tmp2 any = A_arbace_go_build_desc_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_build_desc_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_523, false); A_arbace_go_build_desc_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_61)); return A_arbace_go_build__init_part0_A_const_43 }



































func A_arbace_go_build__init_part0_A_Unit31__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(236, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_62; var tmp2 any = A_arbace_go_build_int_bits_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_go_build_int_bits_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_524, false); A_arbace_go_build_int_bits_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_63)); return A_arbace_go_build__init_part0_A_const_62 }




func A_arbace_go_build__init_part0_A_Unit32__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(241, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_64; var tmp2 any = A_arbace_go_build_go_string_node_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_build_go_string_node_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_525, false); A_arbace_go_build_go_string_node_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_65)); return A_arbace_go_build__init_part0_A_const_64 }






func A_arbace_go_build__init_part0_A_Unit33__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(248, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_66; var tmp2 any = A_arbace_go_build_complex_value_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_build_complex_value_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_526, false); A_arbace_go_build_complex_value_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_67)); return A_arbace_go_build__init_part0_A_const_66 }






func A_arbace_go_build__init_part0_A_Unit34__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(255, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_68; var tmp2 any = A_arbace_go_build_const_node_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_build_const_node_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_527, false); A_arbace_go_build_const_node_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_69)); return A_arbace_go_build__init_part0_A_const_68 }














func A_arbace_go_build__init_part0_A_Unit35__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(270, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_70; var tmp2 any = A_arbace_go_build_new_slot_BANG__A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_go_build_new_slot_BANG__A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_528, false); A_arbace_go_build_new_slot_BANG__A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_71)); return A_arbace_go_build__init_part0_A_const_70 }





func A_arbace_go_build__init_part0_A_Unit36__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(276, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_72; var tmp2 any = A_arbace_go_build_next_code_BANG__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_build_next_code_BANG__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_529, false); A_arbace_go_build_next_code_BANG__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_73)); return A_arbace_go_build__init_part0_A_const_72 }


func A_arbace_go_build__init_part0_A_Unit37__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(279, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_74; var tmp2 any = A_arbace_go_build_label_code_BANG__A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_go_build_label_code_BANG__A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_530, false); A_arbace_go_build_label_code_BANG__A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_75)); return A_arbace_go_build__init_part0_A_const_74 }






func A_arbace_go_build__init_part0_A_Unit38__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(286, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_76; var tmp2 any = A_arbace_go_build_label_entry_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_build_label_entry_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_531, false); A_arbace_go_build_label_entry_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_77)); return A_arbace_go_build__init_part0_A_const_76 }



func A_arbace_go_build__init_part0_A_Unit39__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(290, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_78; var tmp2 any = A_arbace_go_build_cell_var_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_go_build_cell_var_QMARK__A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_532, false); A_arbace_go_build_cell_var_QMARK__A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_79)); return A_arbace_go_build__init_part0_A_const_78 }




func A_arbace_go_build__init_part0_A_Unit40__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(295, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_80; var tmp2 any = A_arbace_go_build_loc_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_build_loc_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_533, false); A_arbace_go_build_loc_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_81)); return A_arbace_go_build__init_part0_A_const_80 }



func A_arbace_go_build__init_part0_A_Unit41__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(299, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_82; var tmp2 any = A_arbace_go_build_new_loc_BANG__A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_go_build_new_loc_BANG__A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_534, false); A_arbace_go_build_new_loc_BANG__A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_83)); return A_arbace_go_build__init_part0_A_const_82 }






func A_arbace_go_build__init_part0_A_Unit42__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(306, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_84; var tmp2 any = A_arbace_go_build_temp_BANG__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_build_temp_BANG__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_535, false); A_arbace_go_build_temp_BANG__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_85)); return A_arbace_go_build__init_part0_A_const_84 }



func A_arbace_go_build__init_part0_A_Unit43__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(310, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_86; var tmp2 any = A_arbace_go_build_local_node_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_go_build_local_node_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_536, false); A_arbace_go_build_local_node_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_87)); return A_arbace_go_build__init_part0_A_const_86 }

func A_arbace_go_build__init_part0_A_Unit44__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(312, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_88; var tmp2 any = A_arbace_go_build_as_kind_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_build_as_kind_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_537, false); A_arbace_go_build_as_kind_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_89)); return A_arbace_go_build__init_part0_A_const_88 }








func A_arbace_go_build__init_part0_A_Unit45__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(321, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_90; var tmp2 any = A_arbace_go_build_load_p_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_go_build_load_p_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_538, false); A_arbace_go_build_load_p_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_91)); return A_arbace_go_build__init_part0_A_const_90 }










func A_arbace_go_build__init_part0_A_Unit46__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(332, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_92; var tmp2 any = A_arbace_go_build_store_p_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_build_store_p_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_539, false); A_arbace_go_build_store_p_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_93)); return A_arbace_go_build__init_part0_A_const_92 }











func A_arbace_go_build__init_part0_A_Unit47__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(344, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_94; var tmp2 any = A_arbace_go_build_set_slot_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_build_set_slot_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_540, false); A_arbace_go_build_set_slot_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_95)); return A_arbace_go_build__init_part0_A_const_94 }


func A_arbace_go_build__init_part0_A_Unit48__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(347, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_96; var tmp2 any = A_arbace_go_build_expr_stmt_of_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_build_expr_stmt_of_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_541, false); A_arbace_go_build_expr_stmt_of_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_97)); return A_arbace_go_build__init_part0_A_const_96 }


func A_arbace_go_build__init_part0_A_Unit49__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_98; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_99)); return A_arbace_go_build__init_part0_A_const_98 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit50__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_100; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_101)); return A_arbace_go_build__init_part0_A_const_100 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit51__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_102; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_103)); return A_arbace_go_build__init_part0_A_const_102 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit52__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_104; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_105)); return A_arbace_go_build__init_part0_A_const_104 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit53__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_106; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_107)); return A_arbace_go_build__init_part0_A_const_106 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit54__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_108; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_109)); return A_arbace_go_build__init_part0_A_const_108 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit55__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_110; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_111)); return A_arbace_go_build__init_part0_A_const_110 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit56__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_112; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_113)); return A_arbace_go_build__init_part0_A_const_112 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit57__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_114; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_115)); return A_arbace_go_build__init_part0_A_const_114 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit58__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_116; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_117)); return A_arbace_go_build__init_part0_A_const_116 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit59__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_118; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_119)); return A_arbace_go_build__init_part0_A_const_118 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit60__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_120; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_121)); return A_arbace_go_build__init_part0_A_const_120 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit61__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_122; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_123)); return A_arbace_go_build__init_part0_A_const_122 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit62__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_124; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_125)); return A_arbace_go_build__init_part0_A_const_124 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit63__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_126; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_127)); return A_arbace_go_build__init_part0_A_const_126 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit64__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_128; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_129)); return A_arbace_go_build__init_part0_A_const_128 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit65__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_130; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_131)); return A_arbace_go_build__init_part0_A_const_130 }
//line :350:1
func A_arbace_go_build__init_part0_A_Unit66__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_132; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_133)); return A_arbace_go_build__init_part0_A_const_132 }


func A_arbace_go_build__init_part0_A_Unit67__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(353, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_134; var tmp2 any = A_arbace_go_build_exk_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_go_build_exk_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_542, false); A_arbace_go_build_exk_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_135)); return A_arbace_go_build__init_part0_A_const_134 }



func A_arbace_go_build__init_part0_A_Unit68__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(357, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_136; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_137)); return A_arbace_go_build__init_part0_A_const_136 }

func A_arbace_go_build__init_part0_A_Unit69__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(359, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_138; var tmp2 any = A_arbace_go_build_iface_content_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_build_iface_content_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_543, false); A_arbace_go_build_iface_content_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_139)); return A_arbace_go_build__init_part0_A_const_138 }
















func A_arbace_go_build__init_part0_A_Unit70__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(376, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_140; var tmp2 any = A_arbace_go_build_arith_name_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_go_build_arith_name_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_544, false); A_arbace_go_build_arith_name_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_141)); return A_arbace_go_build__init_part0_A_const_140 }



func A_arbace_go_build__init_part0_A_Unit71__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(380, 1); A_arbace_go_build__init_part0_A_const_142.BindRoot_O__V(A_arbace_go_build__init_part0_A_const_143); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_142; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_144)); return A_arbace_go_build__init_part0_A_const_142 }

func A_arbace_go_build__init_part0_A_Unit72__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(382, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_145; var tmp2 any = A_arbace_go_build_const_of_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_build_const_of_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_545, false); A_arbace_go_build_const_of_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_146)); return A_arbace_go_build__init_part0_A_const_145 }




func A_arbace_go_build__init_part0_A_Unit73__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(387, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_147; var tmp2 any = A_arbace_go_build_local_slot_of_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_go_build_local_slot_of_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_546, false); A_arbace_go_build_local_slot_of_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_148)); return A_arbace_go_build__init_part0_A_const_147 }







func A_arbace_go_build__init_part0_A_Unit74__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(395, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_149; var tmp2 any = A_arbace_go_build_int_binop_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_build_int_binop_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_547, false); A_arbace_go_build_int_binop_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_150)); return A_arbace_go_build__init_part0_A_const_149 }













func A_arbace_go_build__init_part0_A_Unit75__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(409, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_151; var tmp2 any = A_arbace_go_build_float_binop_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_go_build_float_binop_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_548, false); A_arbace_go_build_float_binop_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_151; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_152)); return A_arbace_go_build__init_part0_A_const_151 }



func A_arbace_go_build__init_part0_A_Unit76__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(413, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_153; var tmp2 any = A_arbace_go_build_binop_nodes_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_build_binop_nodes_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_549, false); A_arbace_go_build_binop_nodes_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_153; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_154)); return A_arbace_go_build__init_part0_A_const_153 }












func A_arbace_go_build__init_part0_A_Unit77__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(426, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_155; var tmp2 any = A_arbace_go_build_count_node_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_go_build_count_node_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_550, false); A_arbace_go_build_count_node_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_155; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_156)); return A_arbace_go_build__init_part0_A_const_155 }









func A_arbace_go_build__init_part0_A_Unit78__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(436, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_157; var tmp2 any = A_arbace_go_build_shift_node_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_build_shift_node_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_551, false); A_arbace_go_build_shift_node_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_157; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_158)); return A_arbace_go_build__init_part0_A_const_157 }




func A_arbace_go_build__init_part0_A_Unit79__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(441, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_159; var tmp2 any = A_arbace_go_build_nil_node_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_go_build_nil_node_QMARK__A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_552, false); A_arbace_go_build_nil_node_QMARK__A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_160)); return A_arbace_go_build__init_part0_A_const_159 }

func A_arbace_go_build__init_part0_A_Unit80__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(443, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_161; var tmp2 any = A_arbace_go_build_compare_nodes_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_build_compare_nodes_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_553, false); A_arbace_go_build_compare_nodes_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_162)); return A_arbace_go_build__init_part0_A_const_161 }







































func A_arbace_go_build__init_part0_A_Unit81__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(483, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_163; var tmp2 any = A_arbace_go_build_binary_node_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_go_build_binary_node_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_554, false); A_arbace_go_build_binary_node_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_164)); return A_arbace_go_build__init_part0_A_const_163 }

















func A_arbace_go_build__init_part0_A_Unit82__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(501, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_165; var tmp2 any = A_arbace_go_build_unary_node_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_build_unary_node_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_555, false); A_arbace_go_build_unary_node_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_166)); return A_arbace_go_build__init_part0_A_const_165 }












func A_arbace_go_build__init_part0_A_Unit83__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(514, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_167; var tmp2 any = A_arbace_go_build_bytes_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_go_build_bytes_type_QMARK__A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_556, false); A_arbace_go_build_bytes_type_QMARK__A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_167; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_168)); return A_arbace_go_build__init_part0_A_const_167 }
func A_arbace_go_build__init_part0_A_Unit84__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(515, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_169; var tmp2 any = A_arbace_go_build_runes_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_build_runes_type_QMARK__A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_557, false); A_arbace_go_build_runes_type_QMARK__A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_170)); return A_arbace_go_build__init_part0_A_const_169 }

func A_arbace_go_build__init_part0_A_Unit85__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(517, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_171; var tmp2 any = A_arbace_go_build_conv_node_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_go_build_conv_node_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_558, false); A_arbace_go_build_conv_node_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_172)); return A_arbace_go_build__init_part0_A_const_171 }








































func A_arbace_go_build__init_part0_A_Unit86__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(558, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_173; var tmp2 any = A_arbace_go_build_addressable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_build_addressable_QMARK__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_559, false); A_arbace_go_build_addressable_QMARK__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_173; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_174)); return A_arbace_go_build__init_part0_A_const_173 }


func A_arbace_go_build__init_part0_A_Unit87__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(561, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_175; var tmp2 any = A_arbace_go_build_struct_of_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_go_build_struct_of_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_560, false); A_arbace_go_build_struct_of_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_175; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_176)); return A_arbace_go_build__init_part0_A_const_175 }




func A_arbace_go_build__init_part0_A_Unit88__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(566, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_177; var tmp2 any = A_arbace_go_build_value_place_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_go_build_value_place_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_561, false); A_arbace_go_build_value_place_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_177; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_178)); return A_arbace_go_build__init_part0_A_const_177 }







func A_arbace_go_build__init_part0_A_Unit89__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(574, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_179; var tmp2 any = A_arbace_go_build_field_place_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_go_build_field_place_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_562, false); A_arbace_go_build_field_place_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_179; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_180)); return A_arbace_go_build__init_part0_A_const_179 }


















func A_arbace_go_build__init_part0_A_Unit90__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(593, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_181; var tmp2 any = A_arbace_go_build_index_place_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_build_index_place_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_563, false); A_arbace_go_build_index_place_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_181; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_182)); return A_arbace_go_build__init_part0_A_const_181 }












func A_arbace_go_build__init_part0_A_Unit91__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(606, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_102; var tmp2 any = A_arbace_go_build_place_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_go_build_place_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_564, false); A_arbace_go_build_place_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_183)); return A_arbace_go_build__init_part0_A_const_102 }



















func A_arbace_go_build__init_part0_A_Unit92__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(626, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_184; var tmp2 any = A_arbace_go_build_elem_node_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_go_build_elem_node_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_565, false); A_arbace_go_build_elem_node_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_184; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_185)); return A_arbace_go_build__init_part0_A_const_184 }




func A_arbace_go_build__init_part0_A_Unit93__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(631, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_104; var tmp2 any = A_arbace_go_build_lit_place_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_go_build_lit_place_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_566, false); A_arbace_go_build_lit_place_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_186)); return A_arbace_go_build__init_part0_A_const_104 }



























func A_arbace_go_build__init_part0_A_Unit94__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(659, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_106; var tmp2 any = A_arbace_go_build_lit_node_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_go_build_lit_node_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_567, false); A_arbace_go_build_lit_node_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_187)); return A_arbace_go_build__init_part0_A_const_106 }














func A_arbace_go_build__init_part0_A_Unit95__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(674, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_188; var tmp2 any = A_arbace_go_build_var_node_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_go_build_var_node_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_568, false); A_arbace_go_build_var_node_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_188; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_189)); return A_arbace_go_build__init_part0_A_const_188 }





func A_arbace_go_build__init_part0_A_Unit96__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(680, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_190; var tmp2 any = A_arbace_go_build_global_node_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_go_build_global_node_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_569, false); A_arbace_go_build_global_node_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_190; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_191)); return A_arbace_go_build__init_part0_A_const_190 }


func A_arbace_go_build__init_part0_A_Unit97__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(683, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_192; var tmp2 any = A_arbace_go_build_func_value_node_A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_go_build_func_value_node_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_570, false); A_arbace_go_build_func_value_node_A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_192; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_193)); return A_arbace_go_build__init_part0_A_const_192 }




func A_arbace_go_build__init_part0_A_Unit98__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(688, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_98; var tmp2 any = A_arbace_go_build_ex_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_go_build_ex_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_571, false); A_arbace_go_build_ex_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_194)); return A_arbace_go_build__init_part0_A_const_98 }





























































func A_arbace_go_build__init_part0_A_Unit99__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(750, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_100; var tmp2 any = A_arbace_go_build_ex_as_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_go_build_ex_as_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_572, false); A_arbace_go_build_ex_as_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_195)); return A_arbace_go_build__init_part0_A_const_100 }



func A_arbace_go_build__init_part1_A_Unit100__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(754, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_0; var tmp2 any = A_arbace_go_build_slot_layout_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_build_slot_layout_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_574, false); A_arbace_go_build_slot_layout_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_1)); return A_arbace_go_build__init_part1_A_const_0 }
//line :754:1
func A_arbace_go_build__init_part1_A_Init__O() any { A_arbace_go_build__init_part1_A_Init(); return nil }
//line :754:1
func A_arbace_go_build__init_part1_A_Load__O() any { A_arbace_go_build__init_part1_A_Init(); A_arbace_go_build__init_part1_A_Unit100__O(); A_arbace_go_build__init_part1_A_Unit101__O(); A_arbace_go_build__init_part1_A_Unit102__O(); A_arbace_go_build__init_part1_A_Unit103__O(); A_arbace_go_build__init_part1_A_Unit104__O(); A_arbace_go_build__init_part1_A_Unit105__O(); A_arbace_go_build__init_part1_A_Unit106__O(); A_arbace_go_build__init_part1_A_Unit107__O(); A_arbace_go_build__init_part1_A_Unit108__O(); A_arbace_go_build__init_part1_A_Unit109__O(); A_arbace_go_build__init_part1_A_Unit110__O(); A_arbace_go_build__init_part1_A_Unit111__O(); A_arbace_go_build__init_part1_A_Unit112__O(); A_arbace_go_build__init_part1_A_Unit113__O(); A_arbace_go_build__init_part1_A_Unit114__O(); A_arbace_go_build__init_part1_A_Unit115__O(); A_arbace_go_build__init_part1_A_Unit116__O(); A_arbace_go_build__init_part1_A_Unit117__O(); A_arbace_go_build__init_part1_A_Unit118__O(); A_arbace_go_build__init_part1_A_Unit119__O(); A_arbace_go_build__init_part1_A_Unit120__O(); A_arbace_go_build__init_part1_A_Unit121__O(); A_arbace_go_build__init_part1_A_Unit122__O(); A_arbace_go_build__init_part1_A_Unit123__O(); A_arbace_go_build__init_part1_A_Unit124__O(); A_arbace_go_build__init_part1_A_Unit125__O(); A_arbace_go_build__init_part1_A_Unit126__O(); A_arbace_go_build__init_part1_A_Unit127__O(); A_arbace_go_build__init_part1_A_Unit128__O(); A_arbace_go_build__init_part1_A_Unit129__O(); A_arbace_go_build__init_part1_A_Unit130__O(); A_arbace_go_build__init_part1_A_Unit131__O(); A_arbace_go_build__init_part1_A_Unit132__O(); A_arbace_go_build__init_part1_A_Unit133__O(); A_arbace_go_build__init_part1_A_Unit134__O(); A_arbace_go_build__init_part1_A_Unit135__O(); A_arbace_go_build__init_part1_A_Unit136__O(); A_arbace_go_build__init_part1_A_Unit137__O(); A_arbace_go_build__init_part1_A_Unit138__O(); A_arbace_go_build__init_part1_A_Unit139__O(); A_arbace_go_build__init_part1_A_Unit140__O(); A_arbace_go_build__init_part1_A_Unit141__O(); A_arbace_go_build__init_part1_A_Unit142__O(); A_arbace_go_build__init_part1_A_Unit143__O(); A_arbace_go_build__init_part1_A_Unit144__O(); A_arbace_go_build__init_part1_A_Unit145__O(); A_arbace_go_build__init_part1_A_Unit146__O(); A_arbace_go_build__init_part1_A_Unit147__O(); A_arbace_go_build__init_part1_A_Unit148__O(); A_arbace_go_build__init_part1_A_Unit149__O(); A_arbace_go_build__init_part1_A_Unit150__O(); A_arbace_go_build__init_part1_A_Unit151__O(); A_arbace_go_build__init_part1_A_Unit152__O(); A_arbace_go_build__init_part1_A_Unit153__O(); A_arbace_go_build__init_part1_A_Unit154__O(); A_arbace_go_build__init_part1_A_Unit155__O(); A_arbace_go_build__init_part1_A_Unit156__O(); A_arbace_go_build__init_part1_A_Unit157__O(); A_arbace_go_build__init_part1_A_Unit158__O(); A_arbace_go_build__init_part1_A_Unit159__O(); A_arbace_go_build__init_part1_A_Unit160__O(); A_arbace_go_build__init_part1_A_Unit161__O(); A_arbace_go_build__init_part1_A_Unit162__O(); A_arbace_go_build__init_part1_A_Unit163__O(); A_arbace_go_build__init_part1_A_Unit164__O(); A_arbace_go_build__init_part1_A_Unit165__O(); A_arbace_go_build__init_part1_A_Unit166__O(); A_arbace_go_build__init_part1_A_Unit167__O(); A_arbace_go_build__init_part1_A_Unit168__O(); A_arbace_go_build__init_part1_A_Unit169__O(); A_arbace_go_build__init_part1_A_Unit170__O(); A_arbace_go_build__init_part1_A_Unit171__O(); A_arbace_go_build__init_part1_A_Unit172__O(); A_arbace_go_build__init_part1_A_Unit173__O(); A_arbace_go_build__init_part1_A_Unit174__O(); A_arbace_go_build__init_part1_A_Unit175__O(); A_arbace_go_build__init_part1_A_Unit176__O(); A_arbace_go_build__init_part1_A_Unit177__O(); A_arbace_go_build__init_part1_A_Unit178__O(); A_arbace_go_build__init_part1_A_Unit179__O(); A_arbace_go_build__init_part1_A_Unit180__O(); A_arbace_go_build__init_part1_A_Unit181__O(); A_arbace_go_build__init_part1_A_Unit182__O(); A_arbace_go_build__init_part1_A_Unit183__O(); A_arbace_go_build__init_part1_A_Unit184__O(); A_arbace_go_build__init_part1_A_Unit185__O(); A_arbace_go_build__init_part1_A_Unit186__O(); A_arbace_go_build__init_part1_A_Unit187__O(); A_arbace_go_build__init_part1_A_Unit188__O(); A_arbace_go_build__init_part1_A_Unit189__O(); A_arbace_go_build__init_part1_A_Unit190__O(); A_arbace_go_build__init_part1_A_Unit191__O(); return nil }












func A_arbace_go_build__init_part1_A_Unit101__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(767, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_2; var tmp2 any = A_arbace_go_build_arg_setter_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_build_arg_setter_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_575, false); A_arbace_go_build_arg_setter_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_3)); return A_arbace_go_build__init_part1_A_const_2 }


func A_arbace_go_build__init_part1_A_Unit102__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(770, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_5)); return A_arbace_go_build__init_part1_A_const_4 }
//line :770:1
func A_arbace_go_build__init_part1_A_Unit103__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(770, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_7)); return A_arbace_go_build__init_part1_A_const_6 }

func A_arbace_go_build__init_part1_A_Unit104__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(772, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_8; var tmp2 any = A_arbace_go_build_mem_converted_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_build_mem_converted_QMARK__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_576, false); A_arbace_go_build_mem_converted_QMARK__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_9)); return A_arbace_go_build__init_part1_A_const_8 }







func A_arbace_go_build__init_part1_A_Unit105__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(780, 1); A_arbace_go_build__init_part1_A_const_10.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_11)); return A_arbace_go_build__init_part1_A_const_10.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_build__init_part1_A_Unit106__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(785, 1); A_arbace_go_build__init_part1_A_const_12.BindRoot_O__V(A_arbace_go_build__init_part1_A_const_13); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_14)); return A_arbace_go_build__init_part1_A_const_12 }

func A_arbace_go_build__init_part1_A_Unit107__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(787, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_15; var tmp2 any = A_arbace_go_build_mem_node_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_build_mem_node_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_577, false); A_arbace_go_build_mem_node_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_16)); return A_arbace_go_build__init_part1_A_const_15 }









func A_arbace_go_build__init_part1_A_Unit108__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(797, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_17; var tmp2 any = A_arbace_go_build_arg_nodes_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_build_arg_nodes_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_578, false); A_arbace_go_build_arg_nodes_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_18)); return A_arbace_go_build__init_part1_A_const_17 }

















func A_arbace_go_build__init_part1_A_Unit109__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(815, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_19; var tmp2 any = A_arbace_go_build_call_results_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_build_call_results_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_579, false); A_arbace_go_build_call_results_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_20)); return A_arbace_go_build__init_part1_A_const_19 }








func A_arbace_go_build__init_part1_A_Unit110__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(824, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_21; var tmp2 any = A_arbace_go_build_sig_of_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_build_sig_of_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_580, false); A_arbace_go_build_sig_of_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_22)); return A_arbace_go_build__init_part1_A_const_21 }

func A_arbace_go_build__init_part1_A_Unit111__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(826, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_23; var tmp2 any = A_arbace_go_build_cell_call_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_build_cell_call_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_581, false); A_arbace_go_build_cell_call_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_24)); return A_arbace_go_build__init_part1_A_const_23 }











func A_arbace_go_build__init_part1_A_Unit112__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(838, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_25; var tmp2 any = A_arbace_go_build_static_call_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_build_static_call_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_582, false); A_arbace_go_build_static_call_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_26)); return A_arbace_go_build__init_part1_A_const_25 }





func A_arbace_go_build__init_part1_A_Unit113__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(844, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_27; var tmp2 any = A_arbace_go_build_value_call_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_build_value_call_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_583, false); A_arbace_go_build_value_call_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_28)); return A_arbace_go_build__init_part1_A_const_27 }













func A_arbace_go_build__init_part1_A_Unit114__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(858, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_29; var tmp2 any = A_arbace_go_build_from_mem_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_build_from_mem_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_584, false); A_arbace_go_build_from_mem_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_30)); return A_arbace_go_build__init_part1_A_const_29 }




func A_arbace_go_build__init_part1_A_Unit115__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(863, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_31; var tmp2 any = A_arbace_go_build_compiled_call_node_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_go_build_compiled_call_node_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_585, false); A_arbace_go_build_compiled_call_node_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_32)); return A_arbace_go_build__init_part1_A_const_31 }









func A_arbace_go_build__init_part1_A_Unit116__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(873, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_33; var tmp2 any = A_arbace_go_build_compiled_call_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_build_compiled_call_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_586, false); A_arbace_go_build_compiled_call_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_34)); return A_arbace_go_build__init_part1_A_const_33 }





func A_arbace_go_build__init_part1_A_Unit117__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(879, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_35; var tmp2 any = A_arbace_go_build_recv_type_of_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_build_recv_type_of_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_587, false); A_arbace_go_build_recv_type_of_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_36)); return A_arbace_go_build__init_part1_A_const_35 }







func A_arbace_go_build__init_part1_A_Unit118__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(887, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_37; var tmp2 any = A_arbace_go_build_method_cell_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_build_method_cell_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_588, false); A_arbace_go_build_method_cell_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_38)); return A_arbace_go_build__init_part1_A_const_37 }




func A_arbace_go_build__init_part1_A_Unit119__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(892, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_39; var tmp2 any = A_arbace_go_build_path_derefs_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_build_path_derefs_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_589, false); A_arbace_go_build_path_derefs_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_40)); return A_arbace_go_build__init_part1_A_const_39 }













func A_arbace_go_build__init_part1_A_Unit120__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(906, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_41; var tmp2 any = A_arbace_go_build_field_sel_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_build_field_sel_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_590, false); A_arbace_go_build_field_sel_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_42)); return A_arbace_go_build__init_part1_A_const_41 }











func A_arbace_go_build__init_part1_A_Unit121__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(918, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_43; var tmp2 any = A_arbace_go_build_recv_node_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_build_recv_node_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_591, false); A_arbace_go_build_recv_node_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_44)); return A_arbace_go_build__init_part1_A_const_43 }





















func A_arbace_go_build__init_part1_A_Unit122__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(940, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_45; var tmp2 any = A_arbace_go_build_interp_method_call_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_build_interp_method_call_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_592, false); A_arbace_go_build_interp_method_call_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_46)); return A_arbace_go_build__init_part1_A_const_45 }












func A_arbace_go_build__init_part1_A_Unit123__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(953, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_47; var tmp2 any = A_arbace_go_build_method_call_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_go_build_method_call_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_593, false); A_arbace_go_build_method_call_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_48)); return A_arbace_go_build__init_part1_A_const_47 }













func A_arbace_go_build__init_part1_A_Unit124__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(967, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_4; var tmp2 any = A_arbace_go_build_error_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_build_error_type_QMARK__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_594, false); A_arbace_go_build_error_type_QMARK__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_49)); return A_arbace_go_build__init_part1_A_const_4 }

func A_arbace_go_build__init_part1_A_Unit125__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(969, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_6; var tmp2 any = A_arbace_go_build_compiled_iface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_go_build_compiled_iface_QMARK__A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_595, false); A_arbace_go_build_compiled_iface_QMARK__A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_50)); return A_arbace_go_build__init_part1_A_const_6 }

func A_arbace_go_build__init_part1_A_Unit126__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(971, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_51; var tmp2 any = A_arbace_go_build_iface_recv_node_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_build_iface_recv_node_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_596, false); A_arbace_go_build_iface_recv_node_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_52)); return A_arbace_go_build__init_part1_A_const_51 }






func A_arbace_go_build__init_part1_A_Unit127__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(978, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_53; var tmp2 any = A_arbace_go_build_iface_call_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_go_build_iface_call_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_597, false); A_arbace_go_build_iface_call_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_54)); return A_arbace_go_build__init_part1_A_const_53 }


































func A_arbace_go_build__init_part1_A_Unit128__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1013, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_55; var tmp2 any = A_arbace_go_build_method_value_node_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_build_method_value_node_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_598, false); A_arbace_go_build_method_value_node_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_56)); return A_arbace_go_build__init_part1_A_const_55 }
















func A_arbace_go_build__init_part1_A_Unit129__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1030, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_57; var tmp2 any = A_arbace_go_build_iface_method_value_node_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_go_build_iface_method_value_node_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_599, false); A_arbace_go_build_iface_method_value_node_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_58)); return A_arbace_go_build__init_part1_A_const_57 }









func A_arbace_go_build__init_part1_A_Unit130__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1040, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_59; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_60)); return A_arbace_go_build__init_part1_A_const_59 }

func A_arbace_go_build__init_part1_A_Unit131__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1042, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_61; var tmp2 any = A_arbace_go_build_local_obj_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_build_local_obj_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_600, false); A_arbace_go_build_local_obj_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_62)); return A_arbace_go_build__init_part1_A_const_61 }

func A_arbace_go_build__init_part1_A_Unit132__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1044, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_63; var tmp2 any = A_arbace_go_build_local_ref_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_go_build_local_ref_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_601, false); A_arbace_go_build_local_ref_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_64)); return A_arbace_go_build__init_part1_A_const_63 }

func A_arbace_go_build__init_part1_A_Unit133__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1046, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_65; var tmp2 any = A_arbace_go_build_selection_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_build_selection_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_602, false); A_arbace_go_build_selection_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_66)); return A_arbace_go_build__init_part1_A_const_65 }














func A_arbace_go_build__init_part1_A_Unit134__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1061, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_67; var tmp2 any = A_arbace_go_build_thunk_body_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_build_thunk_body_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_603, false); A_arbace_go_build_thunk_body_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_68)); return A_arbace_go_build__init_part1_A_const_67 }












func A_arbace_go_build__init_part1_A_Unit135__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1074, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_69; var tmp2 any = A_arbace_go_build_build_method_thunk_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_build_build_method_thunk_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_604, false); A_arbace_go_build_build_method_thunk_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_70)); return A_arbace_go_build__init_part1_A_const_69 }

















func A_arbace_go_build__init_part1_A_Unit136__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1092, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_71; var tmp2 any = A_arbace_go_build_method_expr_node_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_go_build_method_expr_node_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_605, false); A_arbace_go_build_method_expr_node_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_72)); return A_arbace_go_build__init_part1_A_const_71 }



















func A_arbace_go_build__init_part1_A_Unit137__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1112, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_73; var tmp2 any = A_arbace_go_build_method_candidates_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_build_method_candidates_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_606, false); A_arbace_go_build_method_candidates_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_74)); return A_arbace_go_build__init_part1_A_const_73 }




















func A_arbace_go_build__init_part1_A_Unit138__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1133, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_75; var tmp2 any = A_arbace_go_build_may_have_methods_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_go_build_may_have_methods_QMARK__A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_607, false); A_arbace_go_build_may_have_methods_QMARK__A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_76)); return A_arbace_go_build__init_part1_A_const_75 }








func A_arbace_go_build__init_part1_A_Unit139__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1142, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_77; var tmp2 any = A_arbace_go_build_ensure_methods_BANG__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_build_ensure_methods_BANG__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_608, false); A_arbace_go_build_ensure_methods_BANG__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_78)); return A_arbace_go_build__init_part1_A_const_77 }












































func A_arbace_go_build__init_part1_A_Unit140__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1187, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_79; var tmp2 any = A_arbace_go_build_iface_name_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_go_build_iface_name_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_609, false); A_arbace_go_build_iface_name_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_80)); return A_arbace_go_build__init_part1_A_const_79 }







func A_arbace_go_build__init_part1_A_Unit141__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1195, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_81; var tmp2 any = A_arbace_go_build_assert_desc_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_build_assert_desc_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_610, false); A_arbace_go_build_assert_desc_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_82)); return A_arbace_go_build__init_part1_A_const_81 }




func A_arbace_go_build__init_part1_A_Unit142__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1200, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_83; var tmp2 any = A_arbace_go_build_assert_kn_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_go_build_assert_kn_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_611, false); A_arbace_go_build_assert_kn_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_84)); return A_arbace_go_build__init_part1_A_const_83 }










func A_arbace_go_build__init_part1_A_Unit143__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1211, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_85; var tmp2 any = A_arbace_go_build_call_node_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_build_call_node_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_612, false); A_arbace_go_build_call_node_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_86)); return A_arbace_go_build__init_part1_A_const_85 }

















func A_arbace_go_build__init_part1_A_Unit144__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1229, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_87; var tmp2 any = A_arbace_go_build_call_stmt_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_go_build_call_stmt_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_613, false); A_arbace_go_build_call_stmt_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_88)); return A_arbace_go_build__init_part1_A_const_87 }











func A_arbace_go_build__init_part1_A_Unit145__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1241, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_89; var tmp2 any = A_arbace_go_build_elem_type_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_build_elem_type_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_614, false); A_arbace_go_build_elem_type_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_90)); return A_arbace_go_build__init_part1_A_const_89 }

func A_arbace_go_build__init_part1_A_Unit146__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1243, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_91; var tmp2 any = A_arbace_go_build_builtin_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_go_build_builtin_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_615, false); A_arbace_go_build_builtin_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_92)); return A_arbace_go_build__init_part1_A_const_91 }




















































































func A_arbace_go_build__init_part1_A_Unit147__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1328, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_93; var tmp2 any = A_arbace_go_build_expr_or_stmt_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_build_expr_or_stmt_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_616, false); A_arbace_go_build_expr_or_stmt_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_94)); return A_arbace_go_build__init_part1_A_const_93 }



func A_arbace_go_build__init_part1_A_Unit148__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1332, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_95; var tmp2 any = A_arbace_go_build_slot_of_place_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_build_slot_of_place_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_617, false); A_arbace_go_build_slot_of_place_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_96)); return A_arbace_go_build__init_part1_A_const_95 }






func A_arbace_go_build__init_part1_A_Unit149__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1339, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_97; var tmp2 any = A_arbace_go_build_assign_to_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_build_assign_to_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_618, false); A_arbace_go_build_assign_to_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_98)); return A_arbace_go_build__init_part1_A_const_97 }











func A_arbace_go_build__init_part1_A_Unit150__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1351, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_99; var tmp2 any = A_arbace_go_build_temps_of_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_go_build_temps_of_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_619, false); A_arbace_go_build_temps_of_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_100)); return A_arbace_go_build__init_part1_A_const_99 }






func A_arbace_go_build__init_part1_A_Unit151__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1358, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_101; var tmp2 any = A_arbace_go_build_rhs_nodes_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_build_rhs_nodes_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_620, false); A_arbace_go_build_rhs_nodes_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_102)); return A_arbace_go_build__init_part1_A_const_101 }


































func A_arbace_go_build__init_part1_A_Unit152__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1393, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_103; var tmp2 any = A_arbace_go_build_prepare_place_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_go_build_prepare_place_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_621, false); A_arbace_go_build_prepare_place_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_104)); return A_arbace_go_build__init_part1_A_const_103 }




































func A_arbace_go_build__init_part1_A_Unit153__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1430, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_105; var tmp2 any = A_arbace_go_build_assign_stmt_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_build_assign_stmt_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_622, false); A_arbace_go_build_assign_stmt_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_106)); return A_arbace_go_build__init_part1_A_const_105 }








func A_arbace_go_build__init_part1_A_Unit154__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1439, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_107; var tmp2 any = A_arbace_go_build_op_assign_stmt_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_go_build_op_assign_stmt_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_623, false); A_arbace_go_build_op_assign_stmt_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_108)); return A_arbace_go_build__init_part1_A_const_107 }





























func A_arbace_go_build__init_part1_A_Unit155__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1469, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_109; var tmp2 any = A_arbace_go_build_one_of_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_build_one_of_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_624, false); A_arbace_go_build_one_of_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_110)); return A_arbace_go_build__init_part1_A_const_109 }





func A_arbace_go_build__init_part1_A_Unit156__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1475, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_111; var tmp2 any = A_arbace_go_build_incdec_stmt_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_go_build_incdec_stmt_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_625, false); A_arbace_go_build_incdec_stmt_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_112)); return A_arbace_go_build__init_part1_A_const_111 }






func A_arbace_go_build__init_part1_A_Unit157__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1482, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_113; var tmp2 any = A_arbace_go_build_zero_init_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_build_zero_init_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_626, false); A_arbace_go_build_zero_init_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_114)); return A_arbace_go_build__init_part1_A_const_113 }










func A_arbace_go_build__init_part1_A_Unit158__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1493, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_115; var tmp2 any = A_arbace_go_build_init_var_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_go_build_init_var_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_627, false); A_arbace_go_build_init_var_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_116)); return A_arbace_go_build__init_part1_A_const_115 }








func A_arbace_go_build__init_part1_A_Unit159__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1502, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_117; var tmp2 any = A_arbace_go_build_decl_stmt_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_build_decl_stmt_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_628, false); A_arbace_go_build_decl_stmt_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_118)); return A_arbace_go_build__init_part1_A_const_117 }





















func A_arbace_go_build__init_part1_A_Unit160__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1524, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_119; var tmp2 any = A_arbace_go_build_jump_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_go_build_jump_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_629, false); A_arbace_go_build_jump_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_120)); return A_arbace_go_build__init_part1_A_const_119 }

func A_arbace_go_build__init_part1_A_Unit161__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_121; var tmp2 any = A_arbace_go_build_push_target_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_build_push_target_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_630, false); A_arbace_go_build_push_target_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_122)); return A_arbace_go_build__init_part1_A_const_121 }

func A_arbace_go_build__init_part1_A_Unit162__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1528, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_123; var tmp2 any = A_arbace_go_build_innermost_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_go_build_innermost_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_631, false); A_arbace_go_build_innermost_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_124)); return A_arbace_go_build__init_part1_A_const_123 }

func A_arbace_go_build__init_part1_A_Unit163__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1530, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_125; var tmp2 any = A_arbace_go_build_block_stmts_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_build_block_stmts_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_632, false); A_arbace_go_build_block_stmts_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_126)); return A_arbace_go_build__init_part1_A_const_125 }

func A_arbace_go_build__init_part1_A_Unit164__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1532, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_127; var tmp2 any = A_arbace_go_build_body_node_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_go_build_body_node_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_633, false); A_arbace_go_build_body_node_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_128)); return A_arbace_go_build__init_part1_A_const_127 }







func A_arbace_go_build__init_part1_A_Unit165__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1540, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_129; var tmp2 any = A_arbace_go_build_stmt_list_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_build_stmt_list_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_634, false); A_arbace_go_build_stmt_list_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_130)); return A_arbace_go_build__init_part1_A_const_129 }

func A_arbace_go_build__init_part1_A_Unit166__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1542, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_131; var tmp2 any = A_arbace_go_build_block_node_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_go_build_block_node_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_635, false); A_arbace_go_build_block_node_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_132)); return A_arbace_go_build__init_part1_A_const_131 }








func A_arbace_go_build__init_part1_A_Unit167__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1551, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_133; var tmp2 any = A_arbace_go_build_loop_target_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_build_loop_target_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_636, false); A_arbace_go_build_loop_target_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_134)); return A_arbace_go_build__init_part1_A_const_133 }






func A_arbace_go_build__init_part1_A_Unit168__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1558, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_135; var tmp2 any = A_arbace_go_build_per_iteration_cells_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_go_build_per_iteration_cells_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_637, false); A_arbace_go_build_per_iteration_cells_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_136)); return A_arbace_go_build__init_part1_A_const_135 }




func A_arbace_go_build__init_part1_A_Unit169__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1563, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_137; var tmp2 any = A_arbace_go_build_for_stmt_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_go_build_for_stmt_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_638, false); A_arbace_go_build_for_stmt_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_138)); return A_arbace_go_build__init_part1_A_const_137 }









func A_arbace_go_build__init_part1_A_Unit170__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1573, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_139; var tmp2 any = A_arbace_go_build_range_targets_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_go_build_range_targets_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_639, false); A_arbace_go_build_range_targets_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_140)); return A_arbace_go_build__init_part1_A_const_139 }






func A_arbace_go_build__init_part1_A_Unit171__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1580, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_141; var tmp2 any = A_arbace_go_build_idx_setter_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_build_idx_setter_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_640, false); A_arbace_go_build_idx_setter_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_142)); return A_arbace_go_build__init_part1_A_const_141 }










func A_arbace_go_build__init_part1_A_Unit172__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1591, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_143; var tmp2 any = A_arbace_go_build_at_setter_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_go_build_at_setter_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_641, false); A_arbace_go_build_at_setter_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_144)); return A_arbace_go_build__init_part1_A_const_143 }










func A_arbace_go_build__init_part1_A_Unit173__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1602, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_145; var tmp2 any = A_arbace_go_build_any_setter_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_go_build_any_setter_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_642, false); A_arbace_go_build_any_setter_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_146)); return A_arbace_go_build__init_part1_A_const_145 }










func A_arbace_go_build__init_part1_A_Unit174__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1613, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_147; var tmp2 any = A_arbace_go_build_has_call_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_go_build_has_call_QMARK__A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_643, false); A_arbace_go_build_has_call_QMARK__A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_148)); return A_arbace_go_build__init_part1_A_const_147 }










func A_arbace_go_build__init_part1_A_Unit175__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1624, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_149; var tmp2 any = A_arbace_go_build_range_stmt_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_go_build_range_stmt_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_644, false); A_arbace_go_build_range_stmt_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_150)); return A_arbace_go_build__init_part1_A_const_149 }








































































func A_arbace_go_build__init_part1_A_Unit176__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1697, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_151; var tmp2 any = A_arbace_go_build_switch_stmt_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_go_build_switch_stmt_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_645, false); A_arbace_go_build_switch_stmt_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_151; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_152)); return A_arbace_go_build__init_part1_A_const_151 }

























func A_arbace_go_build__init_part1_A_Unit177__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1723, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_153; var tmp2 any = A_arbace_go_build_return_stmt_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_go_build_return_stmt_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_646, false); A_arbace_go_build_return_stmt_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_153; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_154)); return A_arbace_go_build__init_part1_A_const_153 }















func A_arbace_go_build__init_part1_A_Unit178__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1739, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_155; var tmp2 any = A_arbace_go_build_deferred_call_A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_go_build_deferred_call_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_647, false); A_arbace_go_build_deferred_call_A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_155; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_156)); return A_arbace_go_build__init_part1_A_const_155 }






































func A_arbace_go_build__init_part1_A_Unit179__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1778, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_157; var tmp2 any = A_arbace_go_build_defer_stmt_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_go_build_defer_stmt_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_648, false); A_arbace_go_build_defer_stmt_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_157; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_158)); return A_arbace_go_build__init_part1_A_const_157 }




func A_arbace_go_build__init_part1_A_Unit180__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1783, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_159; var tmp2 any = A_arbace_go_build_go_stmt_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_go_build_go_stmt_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_649, false); A_arbace_go_build_go_stmt_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_160)); return A_arbace_go_build__init_part1_A_const_159 }



func A_arbace_go_build__init_part1_A_Unit181__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1787, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_161; var tmp2 any = A_arbace_go_build_send_stmt_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_build_send_stmt_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_650, false); A_arbace_go_build_send_stmt_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_162)); return A_arbace_go_build__init_part1_A_const_161 }



func A_arbace_go_build__init_part1_A_Unit182__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1791, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_163; var tmp2 any = A_arbace_go_build_type_switch_stmt_A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_go_build_type_switch_stmt_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_651, false); A_arbace_go_build_type_switch_stmt_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_164)); return A_arbace_go_build__init_part1_A_const_163 }


























func A_arbace_go_build__init_part1_A_Unit183__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1818, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_165; var tmp2 any = A_arbace_go_build_select_recv_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_go_build_select_recv_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_652, false); A_arbace_go_build_select_recv_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_166)); return A_arbace_go_build__init_part1_A_const_165 }























func A_arbace_go_build__init_part1_A_Unit184__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1842, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_167; var tmp2 any = A_arbace_go_build_select_stmt_A_New(); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_go_build_select_stmt_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_653, false); A_arbace_go_build_select_stmt_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_167; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_168)); return A_arbace_go_build__init_part1_A_const_167 }




















func A_arbace_go_build__init_part1_A_Unit185__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1863, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_169; var tmp2 any = A_arbace_go_build_stmt_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_go_build_stmt_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_654, false); A_arbace_go_build_stmt_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_170)); return A_arbace_go_build__init_part1_A_const_169 }









































func A_arbace_go_build__init_part1_A_Unit186__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1905, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_171; var tmp2 any = A_arbace_go_build_has_defer_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_go_build_has_defer_QMARK__A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_655, false); A_arbace_go_build_has_defer_QMARK__A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_172)); return A_arbace_go_build__init_part1_A_const_171 }












func A_arbace_go_build__init_part1_A_Unit187__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1918, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_173; var tmp2 any = A_arbace_go_build_free_locals_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_go_build_free_locals_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_656, false); A_arbace_go_build_free_locals_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_173; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_174)); return A_arbace_go_build__init_part1_A_const_173 }





























func A_arbace_go_build__init_part1_A_Unit188__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1948, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_59; var tmp2 any = A_arbace_go_build_build_code_A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_go_build_build_code_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_657, false); A_arbace_go_build_build_code_A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_175)); return A_arbace_go_build__init_part1_A_const_59 }

















































func A_arbace_go_build__init_part1_A_Unit189__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1998, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_176; var tmp2 any = A_arbace_go_build_build_fn_lit_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_go_build_build_fn_lit_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_658, false); A_arbace_go_build_build_fn_lit_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_176; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_177)); return A_arbace_go_build__init_part1_A_const_176 }









func A_arbace_go_build__init_part1_A_Unit190__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2008, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_178; var tmp2 any = A_arbace_go_build_build_func_A_New(); var tmp3 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_go_build_build_func_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_659, false); A_arbace_go_build_build_func_A_fn_class = fncls__86d; tmp3 = fncls__86d } else { tmp3 = fncls__86 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_178; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_179)); return A_arbace_go_build__init_part1_A_const_178 }






func A_arbace_go_build__init_part1_A_Unit191__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2015, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_180; var tmp2 any = A_arbace_go_build_build_inits_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_go_build_build_inits_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_660, false); A_arbace_go_build_build_inits_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_180; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_181)); return A_arbace_go_build__init_part1_A_const_180 }



type A_arbace_go_build__init_A struct{ jrt.Object }

func A_arbace_go_build__init_A_New() *A_arbace_go_build__init_A { t := &A_arbace_go_build__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_build__init_A) Ctor() {}

func (t *A_arbace_go_build__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_build__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_build__init_A_class }

func (t *A_arbace_go_build__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_build__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_build__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_build__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_build__init_A); return ok }

func A_arbace_go_build__init_A_Cast(x any) *A_arbace_go_build__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_build__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_build__init_A_class)) }; return v }



type A_arbace_go_build__init_part0_A struct{ jrt.Object }

var A_arbace_go_build__init_part0_A_const_pool *jrt.RefArray

var A_arbace_go_build__init_part0_A_const_0 *lang.Var

var A_arbace_go_build__init_part0_A_const_1 any

var A_arbace_go_build__init_part0_A_const_2 any

var A_arbace_go_build__init_part0_A_const_3 any

var A_arbace_go_build__init_part0_A_const_4 *lang.Var

var A_arbace_go_build__init_part0_A_const_5 any

var A_arbace_go_build__init_part0_A_const_6 *lang.Var

var A_arbace_go_build__init_part0_A_const_7 any

var A_arbace_go_build__init_part0_A_const_8 *lang.Var

var A_arbace_go_build__init_part0_A_const_9 any

var A_arbace_go_build__init_part0_A_const_10 *lang.Var

var A_arbace_go_build__init_part0_A_const_11 any

var A_arbace_go_build__init_part0_A_const_12 *lang.Var

var A_arbace_go_build__init_part0_A_const_13 any

var A_arbace_go_build__init_part0_A_const_14 *lang.Var

var A_arbace_go_build__init_part0_A_const_15 any

var A_arbace_go_build__init_part0_A_const_16 any

var A_arbace_go_build__init_part0_A_const_17 *lang.Var

var A_arbace_go_build__init_part0_A_const_18 any

var A_arbace_go_build__init_part0_A_const_19 *lang.Var

var A_arbace_go_build__init_part0_A_const_20 any

var A_arbace_go_build__init_part0_A_const_21 *lang.Var

var A_arbace_go_build__init_part0_A_const_22 any

var A_arbace_go_build__init_part0_A_const_23 *lang.Var

var A_arbace_go_build__init_part0_A_const_24 any

var A_arbace_go_build__init_part0_A_const_25 *lang.Var

var A_arbace_go_build__init_part0_A_const_26 any

var A_arbace_go_build__init_part0_A_const_27 any

var A_arbace_go_build__init_part0_A_const_28 *lang.Var

var A_arbace_go_build__init_part0_A_const_29 any

var A_arbace_go_build__init_part0_A_const_30 *lang.Var

var A_arbace_go_build__init_part0_A_const_31 any

var A_arbace_go_build__init_part0_A_const_32 any

var A_arbace_go_build__init_part0_A_const_33 *lang.Var

var A_arbace_go_build__init_part0_A_const_34 any

var A_arbace_go_build__init_part0_A_const_35 *lang.Var

var A_arbace_go_build__init_part0_A_const_36 any

var A_arbace_go_build__init_part0_A_const_37 *lang.Var

var A_arbace_go_build__init_part0_A_const_38 any

var A_arbace_go_build__init_part0_A_const_39 *lang.Var

var A_arbace_go_build__init_part0_A_const_40 any

var A_arbace_go_build__init_part0_A_const_41 *lang.Var

var A_arbace_go_build__init_part0_A_const_42 any

var A_arbace_go_build__init_part0_A_const_43 *lang.Var

var A_arbace_go_build__init_part0_A_const_44 any

var A_arbace_go_build__init_part0_A_const_45 *lang.Var

var A_arbace_go_build__init_part0_A_const_46 any

var A_arbace_go_build__init_part0_A_const_47 *lang.Var

var A_arbace_go_build__init_part0_A_const_48 any

var A_arbace_go_build__init_part0_A_const_49 *lang.Var

var A_arbace_go_build__init_part0_A_const_50 any

var A_arbace_go_build__init_part0_A_const_51 *lang.Var

var A_arbace_go_build__init_part0_A_const_52 any

var A_arbace_go_build__init_part0_A_const_53 *lang.Var

var A_arbace_go_build__init_part0_A_const_54 any

var A_arbace_go_build__init_part0_A_const_55 *lang.Var

var A_arbace_go_build__init_part0_A_const_56 any

var A_arbace_go_build__init_part0_A_const_57 *lang.Var

var A_arbace_go_build__init_part0_A_const_58 any

var A_arbace_go_build__init_part0_A_const_59 *lang.Var

var A_arbace_go_build__init_part0_A_const_60 any

var A_arbace_go_build__init_part0_A_const_61 any

var A_arbace_go_build__init_part0_A_const_62 *lang.Var

var A_arbace_go_build__init_part0_A_const_63 any

var A_arbace_go_build__init_part0_A_const_64 *lang.Var

var A_arbace_go_build__init_part0_A_const_65 any

var A_arbace_go_build__init_part0_A_const_66 *lang.Var

var A_arbace_go_build__init_part0_A_const_67 any

var A_arbace_go_build__init_part0_A_const_68 *lang.Var

var A_arbace_go_build__init_part0_A_const_69 any

var A_arbace_go_build__init_part0_A_const_70 *lang.Var

var A_arbace_go_build__init_part0_A_const_71 any

var A_arbace_go_build__init_part0_A_const_72 *lang.Var

var A_arbace_go_build__init_part0_A_const_73 any

var A_arbace_go_build__init_part0_A_const_74 *lang.Var

var A_arbace_go_build__init_part0_A_const_75 any

var A_arbace_go_build__init_part0_A_const_76 *lang.Var

var A_arbace_go_build__init_part0_A_const_77 any

var A_arbace_go_build__init_part0_A_const_78 *lang.Var

var A_arbace_go_build__init_part0_A_const_79 any

var A_arbace_go_build__init_part0_A_const_80 *lang.Var

var A_arbace_go_build__init_part0_A_const_81 any

var A_arbace_go_build__init_part0_A_const_82 *lang.Var

var A_arbace_go_build__init_part0_A_const_83 any

var A_arbace_go_build__init_part0_A_const_84 *lang.Var

var A_arbace_go_build__init_part0_A_const_85 any

var A_arbace_go_build__init_part0_A_const_86 *lang.Var

var A_arbace_go_build__init_part0_A_const_87 any

var A_arbace_go_build__init_part0_A_const_88 *lang.Var

var A_arbace_go_build__init_part0_A_const_89 any

var A_arbace_go_build__init_part0_A_const_90 *lang.Var

var A_arbace_go_build__init_part0_A_const_91 any

var A_arbace_go_build__init_part0_A_const_92 *lang.Var

var A_arbace_go_build__init_part0_A_const_93 any

var A_arbace_go_build__init_part0_A_const_94 *lang.Var

var A_arbace_go_build__init_part0_A_const_95 any

var A_arbace_go_build__init_part0_A_const_96 *lang.Var

var A_arbace_go_build__init_part0_A_const_97 any

var A_arbace_go_build__init_part0_A_const_98 *lang.Var

var A_arbace_go_build__init_part0_A_const_99 any

var A_arbace_go_build__init_part0_A_const_100 *lang.Var

var A_arbace_go_build__init_part0_A_const_101 any

var A_arbace_go_build__init_part0_A_const_102 *lang.Var

var A_arbace_go_build__init_part0_A_const_103 any

var A_arbace_go_build__init_part0_A_const_104 *lang.Var

var A_arbace_go_build__init_part0_A_const_105 any

var A_arbace_go_build__init_part0_A_const_106 *lang.Var

var A_arbace_go_build__init_part0_A_const_107 any

var A_arbace_go_build__init_part0_A_const_108 *lang.Var

var A_arbace_go_build__init_part0_A_const_109 any

var A_arbace_go_build__init_part0_A_const_110 *lang.Var

var A_arbace_go_build__init_part0_A_const_111 any

var A_arbace_go_build__init_part0_A_const_112 *lang.Var

var A_arbace_go_build__init_part0_A_const_113 any

var A_arbace_go_build__init_part0_A_const_114 *lang.Var

var A_arbace_go_build__init_part0_A_const_115 any

var A_arbace_go_build__init_part0_A_const_116 *lang.Var

var A_arbace_go_build__init_part0_A_const_117 any

var A_arbace_go_build__init_part0_A_const_118 *lang.Var

var A_arbace_go_build__init_part0_A_const_119 any

var A_arbace_go_build__init_part0_A_const_120 *lang.Var

var A_arbace_go_build__init_part0_A_const_121 any

var A_arbace_go_build__init_part0_A_const_122 *lang.Var

var A_arbace_go_build__init_part0_A_const_123 any

var A_arbace_go_build__init_part0_A_const_124 *lang.Var

var A_arbace_go_build__init_part0_A_const_125 any

var A_arbace_go_build__init_part0_A_const_126 *lang.Var

var A_arbace_go_build__init_part0_A_const_127 any

var A_arbace_go_build__init_part0_A_const_128 *lang.Var

var A_arbace_go_build__init_part0_A_const_129 any

var A_arbace_go_build__init_part0_A_const_130 *lang.Var

var A_arbace_go_build__init_part0_A_const_131 any

var A_arbace_go_build__init_part0_A_const_132 *lang.Var

var A_arbace_go_build__init_part0_A_const_133 any

var A_arbace_go_build__init_part0_A_const_134 *lang.Var

var A_arbace_go_build__init_part0_A_const_135 any

var A_arbace_go_build__init_part0_A_const_136 *lang.Var

var A_arbace_go_build__init_part0_A_const_137 any

var A_arbace_go_build__init_part0_A_const_138 *lang.Var

var A_arbace_go_build__init_part0_A_const_139 any

var A_arbace_go_build__init_part0_A_const_140 *lang.Var

var A_arbace_go_build__init_part0_A_const_141 any

var A_arbace_go_build__init_part0_A_const_142 *lang.Var

var A_arbace_go_build__init_part0_A_const_143 any

var A_arbace_go_build__init_part0_A_const_144 any

var A_arbace_go_build__init_part0_A_const_145 *lang.Var

var A_arbace_go_build__init_part0_A_const_146 any

var A_arbace_go_build__init_part0_A_const_147 *lang.Var

var A_arbace_go_build__init_part0_A_const_148 any

var A_arbace_go_build__init_part0_A_const_149 *lang.Var

var A_arbace_go_build__init_part0_A_const_150 any

var A_arbace_go_build__init_part0_A_const_151 *lang.Var

var A_arbace_go_build__init_part0_A_const_152 any

var A_arbace_go_build__init_part0_A_const_153 *lang.Var

var A_arbace_go_build__init_part0_A_const_154 any

var A_arbace_go_build__init_part0_A_const_155 *lang.Var

var A_arbace_go_build__init_part0_A_const_156 any

var A_arbace_go_build__init_part0_A_const_157 *lang.Var

var A_arbace_go_build__init_part0_A_const_158 any

var A_arbace_go_build__init_part0_A_const_159 *lang.Var

var A_arbace_go_build__init_part0_A_const_160 any

var A_arbace_go_build__init_part0_A_const_161 *lang.Var

var A_arbace_go_build__init_part0_A_const_162 any

var A_arbace_go_build__init_part0_A_const_163 *lang.Var

var A_arbace_go_build__init_part0_A_const_164 any

var A_arbace_go_build__init_part0_A_const_165 *lang.Var

var A_arbace_go_build__init_part0_A_const_166 any

var A_arbace_go_build__init_part0_A_const_167 *lang.Var

var A_arbace_go_build__init_part0_A_const_168 any

var A_arbace_go_build__init_part0_A_const_169 *lang.Var

var A_arbace_go_build__init_part0_A_const_170 any

var A_arbace_go_build__init_part0_A_const_171 *lang.Var

var A_arbace_go_build__init_part0_A_const_172 any

var A_arbace_go_build__init_part0_A_const_173 *lang.Var

var A_arbace_go_build__init_part0_A_const_174 any

var A_arbace_go_build__init_part0_A_const_175 *lang.Var

var A_arbace_go_build__init_part0_A_const_176 any

var A_arbace_go_build__init_part0_A_const_177 *lang.Var

var A_arbace_go_build__init_part0_A_const_178 any

var A_arbace_go_build__init_part0_A_const_179 *lang.Var

var A_arbace_go_build__init_part0_A_const_180 any

var A_arbace_go_build__init_part0_A_const_181 *lang.Var

var A_arbace_go_build__init_part0_A_const_182 any

var A_arbace_go_build__init_part0_A_const_183 any

var A_arbace_go_build__init_part0_A_const_184 *lang.Var

var A_arbace_go_build__init_part0_A_const_185 any

var A_arbace_go_build__init_part0_A_const_186 any

var A_arbace_go_build__init_part0_A_const_187 any

var A_arbace_go_build__init_part0_A_const_188 *lang.Var

var A_arbace_go_build__init_part0_A_const_189 any

var A_arbace_go_build__init_part0_A_const_190 *lang.Var

var A_arbace_go_build__init_part0_A_const_191 any

var A_arbace_go_build__init_part0_A_const_192 *lang.Var

var A_arbace_go_build__init_part0_A_const_193 any

var A_arbace_go_build__init_part0_A_const_194 any

var A_arbace_go_build__init_part0_A_const_195 any

var A_arbace_go_build__init_part0_A_init jrt.ClassInit

func A_arbace_go_build__init_part0_A_Init() { if !A_arbace_go_build__init_part0_A_init.Done() { A_arbace_go_build__init_part0_A_init.Run(A_arbace_go_build__init_part0_A_clinit) } }

func A_arbace_go_build__init_part0_A_clinit() { A_arbace_go_build__init_part0_A_clinit_p0(); A_arbace_go_build__init_part0_A_clinit_p1(); A_arbace_go_build__init_part0_A_clinit_p2(); A_arbace_go_build__init_part0_A_clinit_p3(); A_arbace_go_build__init_part0_A_clinit_p4(); A_arbace_go_build__init_part0_A_clinit_p5(); A_arbace_go_build__init_part0_A_clinit_p6(); A_arbace_go_build__init_part0_A_clinit_p7(); A_arbace_go_build__init_part0_A_clinit_p8(); A_arbace_go_build__init_part0_A_clinit_p9(); A_arbace_go_build__init_part0_A_clinit_p10(); A_arbace_go_build__init_part0_A_clinit_p11(); A_arbace_go_build__init_part0_A_clinit_p12(); A_arbace_go_build__init_part0_A_clinit_p13(); A_arbace_go_build__init_part0_A_clinit_p14() }

func A_arbace_go_build__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_build__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_500, 253); A_arbace_go_build__init_part0_A_const_0 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[57]); A_arbace_go_build__init_part0_A_const_1 = A_arbace_go_build__init_part0_A_const_pool.A[58]; A_arbace_go_build__init_part0_A_const_2 = A_arbace_go_build__init_part0_A_const_pool.A[59]; A_arbace_go_build__init_part0_A_const_3 = A_arbace_go_build__init_part0_A_const_pool.A[60]; A_arbace_go_build__init_part0_A_const_4 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[61]); A_arbace_go_build__init_part0_A_const_5 = A_arbace_go_build__init_part0_A_const_pool.A[62]; A_arbace_go_build__init_part0_A_const_6 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[63]); A_arbace_go_build__init_part0_A_const_7 = A_arbace_go_build__init_part0_A_const_pool.A[64]; A_arbace_go_build__init_part0_A_const_8 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[65]); A_arbace_go_build__init_part0_A_const_9 = A_arbace_go_build__init_part0_A_const_pool.A[66]; A_arbace_go_build__init_part0_A_const_10 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[67]); A_arbace_go_build__init_part0_A_const_11 = A_arbace_go_build__init_part0_A_const_pool.A[68]; A_arbace_go_build__init_part0_A_const_12 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[69]) }

func A_arbace_go_build__init_part0_A_clinit_p1() { A_arbace_go_build__init_part0_A_const_13 = A_arbace_go_build__init_part0_A_const_pool.A[70]; A_arbace_go_build__init_part0_A_const_14 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[71]); A_arbace_go_build__init_part0_A_const_15 = A_arbace_go_build__init_part0_A_const_pool.A[72]; A_arbace_go_build__init_part0_A_const_16 = A_arbace_go_build__init_part0_A_const_pool.A[73]; A_arbace_go_build__init_part0_A_const_17 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[74]); A_arbace_go_build__init_part0_A_const_18 = A_arbace_go_build__init_part0_A_const_pool.A[75]; A_arbace_go_build__init_part0_A_const_19 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[76]); A_arbace_go_build__init_part0_A_const_20 = A_arbace_go_build__init_part0_A_const_pool.A[77]; A_arbace_go_build__init_part0_A_const_21 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[78]); A_arbace_go_build__init_part0_A_const_22 = A_arbace_go_build__init_part0_A_const_pool.A[79]; A_arbace_go_build__init_part0_A_const_23 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[80]); A_arbace_go_build__init_part0_A_const_24 = A_arbace_go_build__init_part0_A_const_pool.A[81]; A_arbace_go_build__init_part0_A_const_25 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[82]); A_arbace_go_build__init_part0_A_const_26 = A_arbace_go_build__init_part0_A_const_pool.A[83] }

func A_arbace_go_build__init_part0_A_clinit_p2() { A_arbace_go_build__init_part0_A_const_27 = A_arbace_go_build__init_part0_A_const_pool.A[84]; A_arbace_go_build__init_part0_A_const_28 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[85]); A_arbace_go_build__init_part0_A_const_29 = A_arbace_go_build__init_part0_A_const_pool.A[86]; A_arbace_go_build__init_part0_A_const_30 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[87]); A_arbace_go_build__init_part0_A_const_31 = A_arbace_go_build__init_part0_A_const_pool.A[88]; A_arbace_go_build__init_part0_A_const_32 = A_arbace_go_build__init_part0_A_const_pool.A[89]; A_arbace_go_build__init_part0_A_const_33 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[90]); A_arbace_go_build__init_part0_A_const_34 = A_arbace_go_build__init_part0_A_const_pool.A[91]; A_arbace_go_build__init_part0_A_const_35 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[92]); A_arbace_go_build__init_part0_A_const_36 = A_arbace_go_build__init_part0_A_const_pool.A[93]; A_arbace_go_build__init_part0_A_const_37 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[94]); A_arbace_go_build__init_part0_A_const_38 = A_arbace_go_build__init_part0_A_const_pool.A[95]; A_arbace_go_build__init_part0_A_const_39 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[96]); A_arbace_go_build__init_part0_A_const_40 = A_arbace_go_build__init_part0_A_const_pool.A[97] }

func A_arbace_go_build__init_part0_A_clinit_p3() { A_arbace_go_build__init_part0_A_const_41 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[98]); A_arbace_go_build__init_part0_A_const_42 = A_arbace_go_build__init_part0_A_const_pool.A[99]; A_arbace_go_build__init_part0_A_const_43 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[100]); A_arbace_go_build__init_part0_A_const_44 = A_arbace_go_build__init_part0_A_const_pool.A[101]; A_arbace_go_build__init_part0_A_const_45 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[102]); A_arbace_go_build__init_part0_A_const_46 = A_arbace_go_build__init_part0_A_const_pool.A[103]; A_arbace_go_build__init_part0_A_const_47 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[104]); A_arbace_go_build__init_part0_A_const_48 = A_arbace_go_build__init_part0_A_const_pool.A[105]; A_arbace_go_build__init_part0_A_const_49 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[106]); A_arbace_go_build__init_part0_A_const_50 = A_arbace_go_build__init_part0_A_const_pool.A[107]; A_arbace_go_build__init_part0_A_const_51 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[108]); A_arbace_go_build__init_part0_A_const_52 = A_arbace_go_build__init_part0_A_const_pool.A[109]; A_arbace_go_build__init_part0_A_const_53 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[110]) }

func A_arbace_go_build__init_part0_A_clinit_p4() { A_arbace_go_build__init_part0_A_const_54 = A_arbace_go_build__init_part0_A_const_pool.A[111]; A_arbace_go_build__init_part0_A_const_55 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[112]); A_arbace_go_build__init_part0_A_const_56 = A_arbace_go_build__init_part0_A_const_pool.A[113]; A_arbace_go_build__init_part0_A_const_57 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[114]); A_arbace_go_build__init_part0_A_const_58 = A_arbace_go_build__init_part0_A_const_pool.A[115]; A_arbace_go_build__init_part0_A_const_59 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[116]); A_arbace_go_build__init_part0_A_const_60 = A_arbace_go_build__init_part0_A_const_pool.A[117]; A_arbace_go_build__init_part0_A_const_61 = A_arbace_go_build__init_part0_A_const_pool.A[118]; A_arbace_go_build__init_part0_A_const_62 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[119]); A_arbace_go_build__init_part0_A_const_63 = A_arbace_go_build__init_part0_A_const_pool.A[120]; A_arbace_go_build__init_part0_A_const_64 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[121]); A_arbace_go_build__init_part0_A_const_65 = A_arbace_go_build__init_part0_A_const_pool.A[122]; A_arbace_go_build__init_part0_A_const_66 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[123]); A_arbace_go_build__init_part0_A_const_67 = A_arbace_go_build__init_part0_A_const_pool.A[124] }

func A_arbace_go_build__init_part0_A_clinit_p5() { A_arbace_go_build__init_part0_A_const_68 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[125]); A_arbace_go_build__init_part0_A_const_69 = A_arbace_go_build__init_part0_A_const_pool.A[126]; A_arbace_go_build__init_part0_A_const_70 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[127]); A_arbace_go_build__init_part0_A_const_71 = A_arbace_go_build__init_part0_A_const_pool.A[128]; A_arbace_go_build__init_part0_A_const_72 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[129]); A_arbace_go_build__init_part0_A_const_73 = A_arbace_go_build__init_part0_A_const_pool.A[130]; A_arbace_go_build__init_part0_A_const_74 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[131]); A_arbace_go_build__init_part0_A_const_75 = A_arbace_go_build__init_part0_A_const_pool.A[132]; A_arbace_go_build__init_part0_A_const_76 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[133]); A_arbace_go_build__init_part0_A_const_77 = A_arbace_go_build__init_part0_A_const_pool.A[134]; A_arbace_go_build__init_part0_A_const_78 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[135]); A_arbace_go_build__init_part0_A_const_79 = A_arbace_go_build__init_part0_A_const_pool.A[136]; A_arbace_go_build__init_part0_A_const_80 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[137]) }

func A_arbace_go_build__init_part0_A_clinit_p6() { A_arbace_go_build__init_part0_A_const_81 = A_arbace_go_build__init_part0_A_const_pool.A[138]; A_arbace_go_build__init_part0_A_const_82 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[139]); A_arbace_go_build__init_part0_A_const_83 = A_arbace_go_build__init_part0_A_const_pool.A[140]; A_arbace_go_build__init_part0_A_const_84 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[141]); A_arbace_go_build__init_part0_A_const_85 = A_arbace_go_build__init_part0_A_const_pool.A[142]; A_arbace_go_build__init_part0_A_const_86 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[143]); A_arbace_go_build__init_part0_A_const_87 = A_arbace_go_build__init_part0_A_const_pool.A[144]; A_arbace_go_build__init_part0_A_const_88 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[145]); A_arbace_go_build__init_part0_A_const_89 = A_arbace_go_build__init_part0_A_const_pool.A[146]; A_arbace_go_build__init_part0_A_const_90 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[147]); A_arbace_go_build__init_part0_A_const_91 = A_arbace_go_build__init_part0_A_const_pool.A[148]; A_arbace_go_build__init_part0_A_const_92 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[149]); A_arbace_go_build__init_part0_A_const_93 = A_arbace_go_build__init_part0_A_const_pool.A[150] }

func A_arbace_go_build__init_part0_A_clinit_p7() { A_arbace_go_build__init_part0_A_const_94 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[151]); A_arbace_go_build__init_part0_A_const_95 = A_arbace_go_build__init_part0_A_const_pool.A[152]; A_arbace_go_build__init_part0_A_const_96 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[153]); A_arbace_go_build__init_part0_A_const_97 = A_arbace_go_build__init_part0_A_const_pool.A[154]; A_arbace_go_build__init_part0_A_const_98 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[155]); A_arbace_go_build__init_part0_A_const_99 = A_arbace_go_build__init_part0_A_const_pool.A[156]; A_arbace_go_build__init_part0_A_const_100 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[157]); A_arbace_go_build__init_part0_A_const_101 = A_arbace_go_build__init_part0_A_const_pool.A[158]; A_arbace_go_build__init_part0_A_const_102 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[159]); A_arbace_go_build__init_part0_A_const_103 = A_arbace_go_build__init_part0_A_const_pool.A[160]; A_arbace_go_build__init_part0_A_const_104 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[161]); A_arbace_go_build__init_part0_A_const_105 = A_arbace_go_build__init_part0_A_const_pool.A[162]; A_arbace_go_build__init_part0_A_const_106 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[163]) }

func A_arbace_go_build__init_part0_A_clinit_p8() { A_arbace_go_build__init_part0_A_const_107 = A_arbace_go_build__init_part0_A_const_pool.A[164]; A_arbace_go_build__init_part0_A_const_108 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[165]); A_arbace_go_build__init_part0_A_const_109 = A_arbace_go_build__init_part0_A_const_pool.A[166]; A_arbace_go_build__init_part0_A_const_110 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[167]); A_arbace_go_build__init_part0_A_const_111 = A_arbace_go_build__init_part0_A_const_pool.A[168]; A_arbace_go_build__init_part0_A_const_112 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[169]); A_arbace_go_build__init_part0_A_const_113 = A_arbace_go_build__init_part0_A_const_pool.A[170]; A_arbace_go_build__init_part0_A_const_114 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[171]); A_arbace_go_build__init_part0_A_const_115 = A_arbace_go_build__init_part0_A_const_pool.A[172]; A_arbace_go_build__init_part0_A_const_116 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[173]); A_arbace_go_build__init_part0_A_const_117 = A_arbace_go_build__init_part0_A_const_pool.A[174]; A_arbace_go_build__init_part0_A_const_118 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[175]); A_arbace_go_build__init_part0_A_const_119 = A_arbace_go_build__init_part0_A_const_pool.A[176] }

func A_arbace_go_build__init_part0_A_clinit_p9() { A_arbace_go_build__init_part0_A_const_120 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[177]); A_arbace_go_build__init_part0_A_const_121 = A_arbace_go_build__init_part0_A_const_pool.A[178]; A_arbace_go_build__init_part0_A_const_122 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[179]); A_arbace_go_build__init_part0_A_const_123 = A_arbace_go_build__init_part0_A_const_pool.A[180]; A_arbace_go_build__init_part0_A_const_124 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[181]); A_arbace_go_build__init_part0_A_const_125 = A_arbace_go_build__init_part0_A_const_pool.A[182]; A_arbace_go_build__init_part0_A_const_126 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[183]); A_arbace_go_build__init_part0_A_const_127 = A_arbace_go_build__init_part0_A_const_pool.A[184]; A_arbace_go_build__init_part0_A_const_128 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[185]); A_arbace_go_build__init_part0_A_const_129 = A_arbace_go_build__init_part0_A_const_pool.A[186]; A_arbace_go_build__init_part0_A_const_130 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[187]); A_arbace_go_build__init_part0_A_const_131 = A_arbace_go_build__init_part0_A_const_pool.A[188]; A_arbace_go_build__init_part0_A_const_132 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[189]) }

func A_arbace_go_build__init_part0_A_clinit_p10() { A_arbace_go_build__init_part0_A_const_133 = A_arbace_go_build__init_part0_A_const_pool.A[190]; A_arbace_go_build__init_part0_A_const_134 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[191]); A_arbace_go_build__init_part0_A_const_135 = A_arbace_go_build__init_part0_A_const_pool.A[192]; A_arbace_go_build__init_part0_A_const_136 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[193]); A_arbace_go_build__init_part0_A_const_137 = A_arbace_go_build__init_part0_A_const_pool.A[194]; A_arbace_go_build__init_part0_A_const_138 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[195]); A_arbace_go_build__init_part0_A_const_139 = A_arbace_go_build__init_part0_A_const_pool.A[196]; A_arbace_go_build__init_part0_A_const_140 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[197]); A_arbace_go_build__init_part0_A_const_141 = A_arbace_go_build__init_part0_A_const_pool.A[198]; A_arbace_go_build__init_part0_A_const_142 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[199]); A_arbace_go_build__init_part0_A_const_143 = A_arbace_go_build__init_part0_A_const_pool.A[200]; A_arbace_go_build__init_part0_A_const_144 = A_arbace_go_build__init_part0_A_const_pool.A[201]; A_arbace_go_build__init_part0_A_const_145 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[202]); A_arbace_go_build__init_part0_A_const_146 = A_arbace_go_build__init_part0_A_const_pool.A[203] }

func A_arbace_go_build__init_part0_A_clinit_p11() { A_arbace_go_build__init_part0_A_const_147 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[204]); A_arbace_go_build__init_part0_A_const_148 = A_arbace_go_build__init_part0_A_const_pool.A[205]; A_arbace_go_build__init_part0_A_const_149 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[206]); A_arbace_go_build__init_part0_A_const_150 = A_arbace_go_build__init_part0_A_const_pool.A[207]; A_arbace_go_build__init_part0_A_const_151 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[208]); A_arbace_go_build__init_part0_A_const_152 = A_arbace_go_build__init_part0_A_const_pool.A[209]; A_arbace_go_build__init_part0_A_const_153 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[210]); A_arbace_go_build__init_part0_A_const_154 = A_arbace_go_build__init_part0_A_const_pool.A[211]; A_arbace_go_build__init_part0_A_const_155 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[212]); A_arbace_go_build__init_part0_A_const_156 = A_arbace_go_build__init_part0_A_const_pool.A[213]; A_arbace_go_build__init_part0_A_const_157 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[214]); A_arbace_go_build__init_part0_A_const_158 = A_arbace_go_build__init_part0_A_const_pool.A[215]; A_arbace_go_build__init_part0_A_const_159 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[216]) }

func A_arbace_go_build__init_part0_A_clinit_p12() { A_arbace_go_build__init_part0_A_const_160 = A_arbace_go_build__init_part0_A_const_pool.A[217]; A_arbace_go_build__init_part0_A_const_161 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[218]); A_arbace_go_build__init_part0_A_const_162 = A_arbace_go_build__init_part0_A_const_pool.A[219]; A_arbace_go_build__init_part0_A_const_163 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[220]); A_arbace_go_build__init_part0_A_const_164 = A_arbace_go_build__init_part0_A_const_pool.A[221]; A_arbace_go_build__init_part0_A_const_165 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[222]); A_arbace_go_build__init_part0_A_const_166 = A_arbace_go_build__init_part0_A_const_pool.A[223]; A_arbace_go_build__init_part0_A_const_167 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[224]); A_arbace_go_build__init_part0_A_const_168 = A_arbace_go_build__init_part0_A_const_pool.A[225]; A_arbace_go_build__init_part0_A_const_169 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[226]); A_arbace_go_build__init_part0_A_const_170 = A_arbace_go_build__init_part0_A_const_pool.A[227]; A_arbace_go_build__init_part0_A_const_171 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[228]); A_arbace_go_build__init_part0_A_const_172 = A_arbace_go_build__init_part0_A_const_pool.A[229] }

func A_arbace_go_build__init_part0_A_clinit_p13() { A_arbace_go_build__init_part0_A_const_173 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[230]); A_arbace_go_build__init_part0_A_const_174 = A_arbace_go_build__init_part0_A_const_pool.A[231]; A_arbace_go_build__init_part0_A_const_175 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[232]); A_arbace_go_build__init_part0_A_const_176 = A_arbace_go_build__init_part0_A_const_pool.A[233]; A_arbace_go_build__init_part0_A_const_177 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[234]); A_arbace_go_build__init_part0_A_const_178 = A_arbace_go_build__init_part0_A_const_pool.A[235]; A_arbace_go_build__init_part0_A_const_179 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[236]); A_arbace_go_build__init_part0_A_const_180 = A_arbace_go_build__init_part0_A_const_pool.A[237]; A_arbace_go_build__init_part0_A_const_181 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[238]); A_arbace_go_build__init_part0_A_const_182 = A_arbace_go_build__init_part0_A_const_pool.A[239]; A_arbace_go_build__init_part0_A_const_183 = A_arbace_go_build__init_part0_A_const_pool.A[240]; A_arbace_go_build__init_part0_A_const_184 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[241]); A_arbace_go_build__init_part0_A_const_185 = A_arbace_go_build__init_part0_A_const_pool.A[242]; A_arbace_go_build__init_part0_A_const_186 = A_arbace_go_build__init_part0_A_const_pool.A[243] }

func A_arbace_go_build__init_part0_A_clinit_p14() { A_arbace_go_build__init_part0_A_const_187 = A_arbace_go_build__init_part0_A_const_pool.A[244]; A_arbace_go_build__init_part0_A_const_188 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[245]); A_arbace_go_build__init_part0_A_const_189 = A_arbace_go_build__init_part0_A_const_pool.A[246]; A_arbace_go_build__init_part0_A_const_190 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[247]); A_arbace_go_build__init_part0_A_const_191 = A_arbace_go_build__init_part0_A_const_pool.A[248]; A_arbace_go_build__init_part0_A_const_192 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[249]); A_arbace_go_build__init_part0_A_const_193 = A_arbace_go_build__init_part0_A_const_pool.A[250]; A_arbace_go_build__init_part0_A_const_194 = A_arbace_go_build__init_part0_A_const_pool.A[251]; A_arbace_go_build__init_part0_A_const_195 = A_arbace_go_build__init_part0_A_const_pool.A[252] }

func A_arbace_go_build__init_part0_A_New() *A_arbace_go_build__init_part0_A { A_arbace_go_build__init_part0_A_Init(); t := &A_arbace_go_build__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_go_build__init_part0_A) Ctor() {}

func (t *A_arbace_go_build__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_build__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_go_build__init_part0_A_class }

func (t *A_arbace_go_build__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_build__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_build__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_build__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_build__init_part0_A); return ok }

func A_arbace_go_build__init_part0_A_Cast(x any) *A_arbace_go_build__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_build__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_build__init_part0_A_class)) }; return v }



type A_arbace_go_build__init_part1_A struct{ jrt.Object }

var A_arbace_go_build__init_part1_A_const_pool *jrt.RefArray

var A_arbace_go_build__init_part1_A_const_0 *lang.Var

var A_arbace_go_build__init_part1_A_const_1 any

var A_arbace_go_build__init_part1_A_const_2 *lang.Var

var A_arbace_go_build__init_part1_A_const_3 any

var A_arbace_go_build__init_part1_A_const_4 *lang.Var

var A_arbace_go_build__init_part1_A_const_5 any

var A_arbace_go_build__init_part1_A_const_6 *lang.Var

var A_arbace_go_build__init_part1_A_const_7 any

var A_arbace_go_build__init_part1_A_const_8 *lang.Var

var A_arbace_go_build__init_part1_A_const_9 any

var A_arbace_go_build__init_part1_A_const_10 *lang.Var

var A_arbace_go_build__init_part1_A_const_11 any

var A_arbace_go_build__init_part1_A_const_12 *lang.Var

var A_arbace_go_build__init_part1_A_const_13 any

var A_arbace_go_build__init_part1_A_const_14 any

var A_arbace_go_build__init_part1_A_const_15 *lang.Var

var A_arbace_go_build__init_part1_A_const_16 any

var A_arbace_go_build__init_part1_A_const_17 *lang.Var

var A_arbace_go_build__init_part1_A_const_18 any

var A_arbace_go_build__init_part1_A_const_19 *lang.Var

var A_arbace_go_build__init_part1_A_const_20 any

var A_arbace_go_build__init_part1_A_const_21 *lang.Var

var A_arbace_go_build__init_part1_A_const_22 any

var A_arbace_go_build__init_part1_A_const_23 *lang.Var

var A_arbace_go_build__init_part1_A_const_24 any

var A_arbace_go_build__init_part1_A_const_25 *lang.Var

var A_arbace_go_build__init_part1_A_const_26 any

var A_arbace_go_build__init_part1_A_const_27 *lang.Var

var A_arbace_go_build__init_part1_A_const_28 any

var A_arbace_go_build__init_part1_A_const_29 *lang.Var

var A_arbace_go_build__init_part1_A_const_30 any

var A_arbace_go_build__init_part1_A_const_31 *lang.Var

var A_arbace_go_build__init_part1_A_const_32 any

var A_arbace_go_build__init_part1_A_const_33 *lang.Var

var A_arbace_go_build__init_part1_A_const_34 any

var A_arbace_go_build__init_part1_A_const_35 *lang.Var

var A_arbace_go_build__init_part1_A_const_36 any

var A_arbace_go_build__init_part1_A_const_37 *lang.Var

var A_arbace_go_build__init_part1_A_const_38 any

var A_arbace_go_build__init_part1_A_const_39 *lang.Var

var A_arbace_go_build__init_part1_A_const_40 any

var A_arbace_go_build__init_part1_A_const_41 *lang.Var

var A_arbace_go_build__init_part1_A_const_42 any

var A_arbace_go_build__init_part1_A_const_43 *lang.Var

var A_arbace_go_build__init_part1_A_const_44 any

var A_arbace_go_build__init_part1_A_const_45 *lang.Var

var A_arbace_go_build__init_part1_A_const_46 any

var A_arbace_go_build__init_part1_A_const_47 *lang.Var

var A_arbace_go_build__init_part1_A_const_48 any

var A_arbace_go_build__init_part1_A_const_49 any

var A_arbace_go_build__init_part1_A_const_50 any

var A_arbace_go_build__init_part1_A_const_51 *lang.Var

var A_arbace_go_build__init_part1_A_const_52 any

var A_arbace_go_build__init_part1_A_const_53 *lang.Var

var A_arbace_go_build__init_part1_A_const_54 any

var A_arbace_go_build__init_part1_A_const_55 *lang.Var

var A_arbace_go_build__init_part1_A_const_56 any

var A_arbace_go_build__init_part1_A_const_57 *lang.Var

var A_arbace_go_build__init_part1_A_const_58 any

var A_arbace_go_build__init_part1_A_const_59 *lang.Var

var A_arbace_go_build__init_part1_A_const_60 any

var A_arbace_go_build__init_part1_A_const_61 *lang.Var

var A_arbace_go_build__init_part1_A_const_62 any

var A_arbace_go_build__init_part1_A_const_63 *lang.Var

var A_arbace_go_build__init_part1_A_const_64 any

var A_arbace_go_build__init_part1_A_const_65 *lang.Var

var A_arbace_go_build__init_part1_A_const_66 any

var A_arbace_go_build__init_part1_A_const_67 *lang.Var

var A_arbace_go_build__init_part1_A_const_68 any

var A_arbace_go_build__init_part1_A_const_69 *lang.Var

var A_arbace_go_build__init_part1_A_const_70 any

var A_arbace_go_build__init_part1_A_const_71 *lang.Var

var A_arbace_go_build__init_part1_A_const_72 any

var A_arbace_go_build__init_part1_A_const_73 *lang.Var

var A_arbace_go_build__init_part1_A_const_74 any

var A_arbace_go_build__init_part1_A_const_75 *lang.Var

var A_arbace_go_build__init_part1_A_const_76 any

var A_arbace_go_build__init_part1_A_const_77 *lang.Var

var A_arbace_go_build__init_part1_A_const_78 any

var A_arbace_go_build__init_part1_A_const_79 *lang.Var

var A_arbace_go_build__init_part1_A_const_80 any

var A_arbace_go_build__init_part1_A_const_81 *lang.Var

var A_arbace_go_build__init_part1_A_const_82 any

var A_arbace_go_build__init_part1_A_const_83 *lang.Var

var A_arbace_go_build__init_part1_A_const_84 any

var A_arbace_go_build__init_part1_A_const_85 *lang.Var

var A_arbace_go_build__init_part1_A_const_86 any

var A_arbace_go_build__init_part1_A_const_87 *lang.Var

var A_arbace_go_build__init_part1_A_const_88 any

var A_arbace_go_build__init_part1_A_const_89 *lang.Var

var A_arbace_go_build__init_part1_A_const_90 any

var A_arbace_go_build__init_part1_A_const_91 *lang.Var

var A_arbace_go_build__init_part1_A_const_92 any

var A_arbace_go_build__init_part1_A_const_93 *lang.Var

var A_arbace_go_build__init_part1_A_const_94 any

var A_arbace_go_build__init_part1_A_const_95 *lang.Var

var A_arbace_go_build__init_part1_A_const_96 any

var A_arbace_go_build__init_part1_A_const_97 *lang.Var

var A_arbace_go_build__init_part1_A_const_98 any

var A_arbace_go_build__init_part1_A_const_99 *lang.Var

var A_arbace_go_build__init_part1_A_const_100 any

var A_arbace_go_build__init_part1_A_const_101 *lang.Var

var A_arbace_go_build__init_part1_A_const_102 any

var A_arbace_go_build__init_part1_A_const_103 *lang.Var

var A_arbace_go_build__init_part1_A_const_104 any

var A_arbace_go_build__init_part1_A_const_105 *lang.Var

var A_arbace_go_build__init_part1_A_const_106 any

var A_arbace_go_build__init_part1_A_const_107 *lang.Var

var A_arbace_go_build__init_part1_A_const_108 any

var A_arbace_go_build__init_part1_A_const_109 *lang.Var

var A_arbace_go_build__init_part1_A_const_110 any

var A_arbace_go_build__init_part1_A_const_111 *lang.Var

var A_arbace_go_build__init_part1_A_const_112 any

var A_arbace_go_build__init_part1_A_const_113 *lang.Var

var A_arbace_go_build__init_part1_A_const_114 any

var A_arbace_go_build__init_part1_A_const_115 *lang.Var

var A_arbace_go_build__init_part1_A_const_116 any

var A_arbace_go_build__init_part1_A_const_117 *lang.Var

var A_arbace_go_build__init_part1_A_const_118 any

var A_arbace_go_build__init_part1_A_const_119 *lang.Var

var A_arbace_go_build__init_part1_A_const_120 any

var A_arbace_go_build__init_part1_A_const_121 *lang.Var

var A_arbace_go_build__init_part1_A_const_122 any

var A_arbace_go_build__init_part1_A_const_123 *lang.Var

var A_arbace_go_build__init_part1_A_const_124 any

var A_arbace_go_build__init_part1_A_const_125 *lang.Var

var A_arbace_go_build__init_part1_A_const_126 any

var A_arbace_go_build__init_part1_A_const_127 *lang.Var

var A_arbace_go_build__init_part1_A_const_128 any

var A_arbace_go_build__init_part1_A_const_129 *lang.Var

var A_arbace_go_build__init_part1_A_const_130 any

var A_arbace_go_build__init_part1_A_const_131 *lang.Var

var A_arbace_go_build__init_part1_A_const_132 any

var A_arbace_go_build__init_part1_A_const_133 *lang.Var

var A_arbace_go_build__init_part1_A_const_134 any

var A_arbace_go_build__init_part1_A_const_135 *lang.Var

var A_arbace_go_build__init_part1_A_const_136 any

var A_arbace_go_build__init_part1_A_const_137 *lang.Var

var A_arbace_go_build__init_part1_A_const_138 any

var A_arbace_go_build__init_part1_A_const_139 *lang.Var

var A_arbace_go_build__init_part1_A_const_140 any

var A_arbace_go_build__init_part1_A_const_141 *lang.Var

var A_arbace_go_build__init_part1_A_const_142 any

var A_arbace_go_build__init_part1_A_const_143 *lang.Var

var A_arbace_go_build__init_part1_A_const_144 any

var A_arbace_go_build__init_part1_A_const_145 *lang.Var

var A_arbace_go_build__init_part1_A_const_146 any

var A_arbace_go_build__init_part1_A_const_147 *lang.Var

var A_arbace_go_build__init_part1_A_const_148 any

var A_arbace_go_build__init_part1_A_const_149 *lang.Var

var A_arbace_go_build__init_part1_A_const_150 any

var A_arbace_go_build__init_part1_A_const_151 *lang.Var

var A_arbace_go_build__init_part1_A_const_152 any

var A_arbace_go_build__init_part1_A_const_153 *lang.Var

var A_arbace_go_build__init_part1_A_const_154 any

var A_arbace_go_build__init_part1_A_const_155 *lang.Var

var A_arbace_go_build__init_part1_A_const_156 any

var A_arbace_go_build__init_part1_A_const_157 *lang.Var

var A_arbace_go_build__init_part1_A_const_158 any

var A_arbace_go_build__init_part1_A_const_159 *lang.Var

var A_arbace_go_build__init_part1_A_const_160 any

var A_arbace_go_build__init_part1_A_const_161 *lang.Var

var A_arbace_go_build__init_part1_A_const_162 any

var A_arbace_go_build__init_part1_A_const_163 *lang.Var

var A_arbace_go_build__init_part1_A_const_164 any

var A_arbace_go_build__init_part1_A_const_165 *lang.Var

var A_arbace_go_build__init_part1_A_const_166 any

var A_arbace_go_build__init_part1_A_const_167 *lang.Var

var A_arbace_go_build__init_part1_A_const_168 any

var A_arbace_go_build__init_part1_A_const_169 *lang.Var

var A_arbace_go_build__init_part1_A_const_170 any

var A_arbace_go_build__init_part1_A_const_171 *lang.Var

var A_arbace_go_build__init_part1_A_const_172 any

var A_arbace_go_build__init_part1_A_const_173 *lang.Var

var A_arbace_go_build__init_part1_A_const_174 any

var A_arbace_go_build__init_part1_A_const_175 any

var A_arbace_go_build__init_part1_A_const_176 *lang.Var

var A_arbace_go_build__init_part1_A_const_177 any

var A_arbace_go_build__init_part1_A_const_178 *lang.Var

var A_arbace_go_build__init_part1_A_const_179 any

var A_arbace_go_build__init_part1_A_const_180 *lang.Var

var A_arbace_go_build__init_part1_A_const_181 any

var A_arbace_go_build__init_part1_A_init jrt.ClassInit

func A_arbace_go_build__init_part1_A_Init() { if !A_arbace_go_build__init_part1_A_init.Done() { A_arbace_go_build__init_part1_A_init.Run(A_arbace_go_build__init_part1_A_clinit) } }

func A_arbace_go_build__init_part1_A_clinit() { A_arbace_go_build__init_part1_A_clinit_p0(); A_arbace_go_build__init_part1_A_clinit_p1(); A_arbace_go_build__init_part1_A_clinit_p2() }

func A_arbace_go_build__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_build__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_573, 227); A_arbace_go_build__init_part1_A_const_0 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[59]); A_arbace_go_build__init_part1_A_const_1 = A_arbace_go_build__init_part1_A_const_pool.A[60]; A_arbace_go_build__init_part1_A_const_2 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[61]); A_arbace_go_build__init_part1_A_const_3 = A_arbace_go_build__init_part1_A_const_pool.A[62]; A_arbace_go_build__init_part1_A_const_4 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[63]); A_arbace_go_build__init_part1_A_const_5 = A_arbace_go_build__init_part1_A_const_pool.A[64]; A_arbace_go_build__init_part1_A_const_6 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[65]); A_arbace_go_build__init_part1_A_const_7 = A_arbace_go_build__init_part1_A_const_pool.A[66]; A_arbace_go_build__init_part1_A_const_8 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[67]); A_arbace_go_build__init_part1_A_const_9 = A_arbace_go_build__init_part1_A_const_pool.A[68]; A_arbace_go_build__init_part1_A_const_10 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[69]); A_arbace_go_build__init_part1_A_const_11 = A_arbace_go_build__init_part1_A_const_pool.A[70] }

func A_arbace_go_build__init_part1_A_clinit_p1() { A_arbace_go_build__init_part1_A_const_12 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[71]); A_arbace_go_build__init_part1_A_const_13 = A_arbace_go_build__init_part1_A_const_pool.A[72]; A_arbace_go_build__init_part1_A_const_14 = A_arbace_go_build__init_part1_A_const_pool.A[73]; A_arbace_go_build__init_part1_A_const_15 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[74]); A_arbace_go_build__init_part1_A_const_16 = A_arbace_go_build__init_part1_A_const_pool.A[75]; A_arbace_go_build__init_part1_A_const_17 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[76]); A_arbace_go_build__init_part1_A_const_18 = A_arbace_go_build__init_part1_A_const_pool.A[77] }

func A_arbace_go_build__init_part1_A_clinit_p2() { var tmp1 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp1 = A_arbace_go_build__init_part0_A_const_110; A_arbace_go_build__init_part1_A_const_19 = tmp1; A_arbace_go_build__init_part1_A_const_20 = A_arbace_go_build__init_part1_A_const_pool.A[78]; A_arbace_go_build__init_part1_A_const_21 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[79]); A_arbace_go_build__init_part1_A_const_22 = A_arbace_go_build__init_part1_A_const_pool.A[80]; A_arbace_go_build__init_part1_A_const_23 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[81]); A_arbace_go_build__init_part1_A_const_24 = A_arbace_go_build__init_part1_A_const_pool.A[82]; A_arbace_go_build__init_part1_A_const_25 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[83]); A_arbace_go_build__init_part1_A_const_26 = A_arbace_go_build__init_part1_A_const_pool.A[84]; A_arbace_go_build__init_part1_A_const_27 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[85]); A_arbace_go_build__init_part1_A_const_28 = A_arbace_go_build__init_part1_A_const_pool.A[86]; A_arbace_go_build__init_part1_A_const_29 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[87]); A_arbace_go_build__init_part1_A_const_30 = A_arbace_go_build__init_part1_A_const_pool.A[88]; A_arbace_go_build__init_part1_A_const_31 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[89]); A_arbace_go_build__init_part1_A_const_32 = A_arbace_go_build__init_part1_A_const_pool.A[90]; A_arbace_go_build__init_part1_A_const_33 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[91]); A_arbace_go_build__init_part1_A_const_34 = A_arbace_go_build__init_part1_A_const_pool.A[92]; A_arbace_go_build__init_part1_A_const_35 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[93]); A_arbace_go_build__init_part1_A_const_36 = A_arbace_go_build__init_part1_A_const_pool.A[94]; A_arbace_go_build__init_part1_A_const_37 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[95]); A_arbace_go_build__init_part1_A_const_38 = A_arbace_go_build__init_part1_A_const_pool.A[96]; A_arbace_go_build__init_part1_A_const_39 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[97]); A_arbace_go_build__init_part1_A_const_40 = A_arbace_go_build__init_part1_A_const_pool.A[98]; A_arbace_go_build__init_part1_A_const_41 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[99]); A_arbace_go_build__init_part1_A_const_42 = A_arbace_go_build__init_part1_A_const_pool.A[100]; A_arbace_go_build__init_part1_A_const_43 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[101]); A_arbace_go_build__init_part1_A_const_44 = A_arbace_go_build__init_part1_A_const_pool.A[102]; A_arbace_go_build__init_part1_A_const_45 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[103]); A_arbace_go_build__init_part1_A_const_46 = A_arbace_go_build__init_part1_A_const_pool.A[104]; A_arbace_go_build__init_part1_A_const_47 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[105]); A_arbace_go_build__init_part1_A_const_48 = A_arbace_go_build__init_part1_A_const_pool.A[106]; A_arbace_go_build__init_part1_A_const_49 = A_arbace_go_build__init_part1_A_const_pool.A[107]; A_arbace_go_build__init_part1_A_const_50 = A_arbace_go_build__init_part1_A_const_pool.A[108]; A_arbace_go_build__init_part1_A_const_51 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[109]); A_arbace_go_build__init_part1_A_const_52 = A_arbace_go_build__init_part1_A_const_pool.A[110]; A_arbace_go_build__init_part1_A_const_53 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[111]); A_arbace_go_build__init_part1_A_const_54 = A_arbace_go_build__init_part1_A_const_pool.A[112]; var tmp2 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp2 = A_arbace_go_build__init_part0_A_const_124; A_arbace_go_build__init_part1_A_const_55 = tmp2; A_arbace_go_build__init_part1_A_const_56 = A_arbace_go_build__init_part1_A_const_pool.A[113]; var tmp3 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp3 = A_arbace_go_build__init_part0_A_const_126; A_arbace_go_build__init_part1_A_const_57 = tmp3; A_arbace_go_build__init_part1_A_const_58 = A_arbace_go_build__init_part1_A_const_pool.A[114]; A_arbace_go_build__init_part1_A_const_59 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[115]); A_arbace_go_build__init_part1_A_const_60 = A_arbace_go_build__init_part1_A_const_pool.A[116]; A_arbace_go_build__init_part1_A_const_61 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[117]); A_arbace_go_build__init_part1_A_const_62 = A_arbace_go_build__init_part1_A_const_pool.A[118]; A_arbace_go_build__init_part1_A_const_63 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[119]); A_arbace_go_build__init_part1_A_const_64 = A_arbace_go_build__init_part1_A_const_pool.A[120]; A_arbace_go_build__init_part1_A_const_65 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[121]); A_arbace_go_build__init_part1_A_const_66 = A_arbace_go_build__init_part1_A_const_pool.A[122]; A_arbace_go_build__init_part1_A_const_67 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[123]); A_arbace_go_build__init_part1_A_const_68 = A_arbace_go_build__init_part1_A_const_pool.A[124]; A_arbace_go_build__init_part1_A_const_69 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[125]); A_arbace_go_build__init_part1_A_const_70 = A_arbace_go_build__init_part1_A_const_pool.A[126]; var tmp4 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp4 = A_arbace_go_build__init_part0_A_const_128; A_arbace_go_build__init_part1_A_const_71 = tmp4; A_arbace_go_build__init_part1_A_const_72 = A_arbace_go_build__init_part1_A_const_pool.A[127]; A_arbace_go_build__init_part1_A_const_73 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[128]); A_arbace_go_build__init_part1_A_const_74 = A_arbace_go_build__init_part1_A_const_pool.A[129]; A_arbace_go_build__init_part1_A_const_75 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[130]); A_arbace_go_build__init_part1_A_const_76 = A_arbace_go_build__init_part1_A_const_pool.A[131]; var tmp5 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp5 = A_arbace_go_build__init_part0_A_const_136; A_arbace_go_build__init_part1_A_const_77 = tmp5; A_arbace_go_build__init_part1_A_const_78 = A_arbace_go_build__init_part1_A_const_pool.A[132]; A_arbace_go_build__init_part1_A_const_79 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[133]); A_arbace_go_build__init_part1_A_const_80 = A_arbace_go_build__init_part1_A_const_pool.A[134]; A_arbace_go_build__init_part1_A_const_81 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[135]); A_arbace_go_build__init_part1_A_const_82 = A_arbace_go_build__init_part1_A_const_pool.A[136]; var tmp6 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp6 = A_arbace_go_build__init_part0_A_const_130; A_arbace_go_build__init_part1_A_const_83 = tmp6; A_arbace_go_build__init_part1_A_const_84 = A_arbace_go_build__init_part1_A_const_pool.A[137]; var tmp7 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp7 = A_arbace_go_build__init_part0_A_const_108; A_arbace_go_build__init_part1_A_const_85 = tmp7; A_arbace_go_build__init_part1_A_const_86 = A_arbace_go_build__init_part1_A_const_pool.A[138]; A_arbace_go_build__init_part1_A_const_87 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[139]); A_arbace_go_build__init_part1_A_const_88 = A_arbace_go_build__init_part1_A_const_pool.A[140]; var tmp8 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp8 = A_arbace_go_build__init_part0_A_const_132; A_arbace_go_build__init_part1_A_const_89 = tmp8; A_arbace_go_build__init_part1_A_const_90 = A_arbace_go_build__init_part1_A_const_pool.A[141]; var tmp9 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp9 = A_arbace_go_build__init_part0_A_const_114; A_arbace_go_build__init_part1_A_const_91 = tmp9; A_arbace_go_build__init_part1_A_const_92 = A_arbace_go_build__init_part1_A_const_pool.A[142]; var tmp10 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp10 = A_arbace_go_build__init_part0_A_const_116; A_arbace_go_build__init_part1_A_const_93 = tmp10; A_arbace_go_build__init_part1_A_const_94 = A_arbace_go_build__init_part1_A_const_pool.A[143]; A_arbace_go_build__init_part1_A_const_95 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[144]); A_arbace_go_build__init_part1_A_const_96 = A_arbace_go_build__init_part1_A_const_pool.A[145]; A_arbace_go_build__init_part1_A_const_97 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[146]); A_arbace_go_build__init_part1_A_const_98 = A_arbace_go_build__init_part1_A_const_pool.A[147]; A_arbace_go_build__init_part1_A_const_99 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[148]); A_arbace_go_build__init_part1_A_const_100 = A_arbace_go_build__init_part1_A_const_pool.A[149]; var tmp11 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp11 = A_arbace_go_build__init_part0_A_const_122; A_arbace_go_build__init_part1_A_const_101 = tmp11; A_arbace_go_build__init_part1_A_const_102 = A_arbace_go_build__init_part1_A_const_pool.A[150]; A_arbace_go_build__init_part1_A_const_103 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[151]); A_arbace_go_build__init_part1_A_const_104 = A_arbace_go_build__init_part1_A_const_pool.A[152]; A_arbace_go_build__init_part1_A_const_105 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[153]); A_arbace_go_build__init_part1_A_const_106 = A_arbace_go_build__init_part1_A_const_pool.A[154]; A_arbace_go_build__init_part1_A_const_107 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[155]); A_arbace_go_build__init_part1_A_const_108 = A_arbace_go_build__init_part1_A_const_pool.A[156]; A_arbace_go_build__init_part1_A_const_109 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[157]); A_arbace_go_build__init_part1_A_const_110 = A_arbace_go_build__init_part1_A_const_pool.A[158]; A_arbace_go_build__init_part1_A_const_111 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[159]); A_arbace_go_build__init_part1_A_const_112 = A_arbace_go_build__init_part1_A_const_pool.A[160]; A_arbace_go_build__init_part1_A_const_113 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[161]); A_arbace_go_build__init_part1_A_const_114 = A_arbace_go_build__init_part1_A_const_pool.A[162]; A_arbace_go_build__init_part1_A_const_115 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[163]); A_arbace_go_build__init_part1_A_const_116 = A_arbace_go_build__init_part1_A_const_pool.A[164]; A_arbace_go_build__init_part1_A_const_117 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[165]); A_arbace_go_build__init_part1_A_const_118 = A_arbace_go_build__init_part1_A_const_pool.A[166]; A_arbace_go_build__init_part1_A_const_119 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[167]); A_arbace_go_build__init_part1_A_const_120 = A_arbace_go_build__init_part1_A_const_pool.A[168]; A_arbace_go_build__init_part1_A_const_121 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[169]); A_arbace_go_build__init_part1_A_const_122 = A_arbace_go_build__init_part1_A_const_pool.A[170]; A_arbace_go_build__init_part1_A_const_123 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[171]); A_arbace_go_build__init_part1_A_const_124 = A_arbace_go_build__init_part1_A_const_pool.A[172]; A_arbace_go_build__init_part1_A_const_125 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[173]); A_arbace_go_build__init_part1_A_const_126 = A_arbace_go_build__init_part1_A_const_pool.A[174]; A_arbace_go_build__init_part1_A_const_127 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[175]); A_arbace_go_build__init_part1_A_const_128 = A_arbace_go_build__init_part1_A_const_pool.A[176]; var tmp12 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp12 = A_arbace_go_build__init_part0_A_const_120; A_arbace_go_build__init_part1_A_const_129 = tmp12; A_arbace_go_build__init_part1_A_const_130 = A_arbace_go_build__init_part1_A_const_pool.A[177]; A_arbace_go_build__init_part1_A_const_131 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[178]); A_arbace_go_build__init_part1_A_const_132 = A_arbace_go_build__init_part1_A_const_pool.A[179]; A_arbace_go_build__init_part1_A_const_133 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[180]); A_arbace_go_build__init_part1_A_const_134 = A_arbace_go_build__init_part1_A_const_pool.A[181]; A_arbace_go_build__init_part1_A_const_135 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[182]); A_arbace_go_build__init_part1_A_const_136 = A_arbace_go_build__init_part1_A_const_pool.A[183]; A_arbace_go_build__init_part1_A_const_137 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[184]); A_arbace_go_build__init_part1_A_const_138 = A_arbace_go_build__init_part1_A_const_pool.A[185]; A_arbace_go_build__init_part1_A_const_139 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[186]); A_arbace_go_build__init_part1_A_const_140 = A_arbace_go_build__init_part1_A_const_pool.A[187]; A_arbace_go_build__init_part1_A_const_141 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[188]); A_arbace_go_build__init_part1_A_const_142 = A_arbace_go_build__init_part1_A_const_pool.A[189]; A_arbace_go_build__init_part1_A_const_143 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[190]); A_arbace_go_build__init_part1_A_const_144 = A_arbace_go_build__init_part1_A_const_pool.A[191]; A_arbace_go_build__init_part1_A_const_145 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[192]); A_arbace_go_build__init_part1_A_const_146 = A_arbace_go_build__init_part1_A_const_pool.A[193]; A_arbace_go_build__init_part1_A_const_147 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[194]); A_arbace_go_build__init_part1_A_const_148 = A_arbace_go_build__init_part1_A_const_pool.A[195]; A_arbace_go_build__init_part1_A_const_149 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[196]); A_arbace_go_build__init_part1_A_const_150 = A_arbace_go_build__init_part1_A_const_pool.A[197]; A_arbace_go_build__init_part1_A_const_151 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[198]); A_arbace_go_build__init_part1_A_const_152 = A_arbace_go_build__init_part1_A_const_pool.A[199]; A_arbace_go_build__init_part1_A_const_153 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[200]); A_arbace_go_build__init_part1_A_const_154 = A_arbace_go_build__init_part1_A_const_pool.A[201]; A_arbace_go_build__init_part1_A_const_155 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[202]); A_arbace_go_build__init_part1_A_const_156 = A_arbace_go_build__init_part1_A_const_pool.A[203]; A_arbace_go_build__init_part1_A_const_157 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[204]); A_arbace_go_build__init_part1_A_const_158 = A_arbace_go_build__init_part1_A_const_pool.A[205]; A_arbace_go_build__init_part1_A_const_159 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[206]); A_arbace_go_build__init_part1_A_const_160 = A_arbace_go_build__init_part1_A_const_pool.A[207]; A_arbace_go_build__init_part1_A_const_161 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[208]); A_arbace_go_build__init_part1_A_const_162 = A_arbace_go_build__init_part1_A_const_pool.A[209]; A_arbace_go_build__init_part1_A_const_163 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[210]); A_arbace_go_build__init_part1_A_const_164 = A_arbace_go_build__init_part1_A_const_pool.A[211]; A_arbace_go_build__init_part1_A_const_165 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[212]); A_arbace_go_build__init_part1_A_const_166 = A_arbace_go_build__init_part1_A_const_pool.A[213]; A_arbace_go_build__init_part1_A_const_167 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[214]); A_arbace_go_build__init_part1_A_const_168 = A_arbace_go_build__init_part1_A_const_pool.A[215]; var tmp13 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp13 = A_arbace_go_build__init_part0_A_const_118; A_arbace_go_build__init_part1_A_const_169 = tmp13; A_arbace_go_build__init_part1_A_const_170 = A_arbace_go_build__init_part1_A_const_pool.A[216]; A_arbace_go_build__init_part1_A_const_171 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[217]); A_arbace_go_build__init_part1_A_const_172 = A_arbace_go_build__init_part1_A_const_pool.A[218]; A_arbace_go_build__init_part1_A_const_173 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[219]); A_arbace_go_build__init_part1_A_const_174 = A_arbace_go_build__init_part1_A_const_pool.A[220]; A_arbace_go_build__init_part1_A_const_175 = A_arbace_go_build__init_part1_A_const_pool.A[221]; var tmp14 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp14 = A_arbace_go_build__init_part0_A_const_112; A_arbace_go_build__init_part1_A_const_176 = tmp14; A_arbace_go_build__init_part1_A_const_177 = A_arbace_go_build__init_part1_A_const_pool.A[222]; A_arbace_go_build__init_part1_A_const_178 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[223]); A_arbace_go_build__init_part1_A_const_179 = A_arbace_go_build__init_part1_A_const_pool.A[224]; A_arbace_go_build__init_part1_A_const_180 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[225]); A_arbace_go_build__init_part1_A_const_181 = A_arbace_go_build__init_part1_A_const_pool.A[226] }

func A_arbace_go_build__init_part1_A_New() *A_arbace_go_build__init_part1_A { A_arbace_go_build__init_part1_A_Init(); t := &A_arbace_go_build__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_go_build__init_part1_A) Ctor() {}

func (t *A_arbace_go_build__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_build__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_go_build__init_part1_A_class }

func (t *A_arbace_go_build__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_build__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_build__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_build__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_build__init_part1_A); return ok }

func A_arbace_go_build__init_part1_A_Cast(x any) *A_arbace_go_build__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_build__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_build__init_part1_A_class)) }; return v }
