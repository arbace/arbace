//line aot_arbace_go_build__init.ae:1
package aot_arbace_go_build

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_build__init_part0_A_Unit0__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_build__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_build__init_part0_A_const_1) }
//line :1:1
func A_arbace_go_build__init_part0_A_Unit1__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_build__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_2)) }
//line :1:1
func A_arbace_go_build__init_part0_A_Unit2__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_go_build_eval367000004_loading__1927001464__auto____367000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_build_eval367000004_loading__1927001464__auto____367000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_599, false, nil); A_arbace_go_build_eval367000004_loading__1927001464__auto____367000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_go_build__init_part0_A_Unit3__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_build__init_part0_A_const_1)).Equals_O__Z(A_arbace_go_build__init_part0_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_go_build_eval367000008_fn__367000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_build_eval367000008_fn__367000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_600, false, nil); A_arbace_go_build_eval367000008_fn__367000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }
//line :1:1
func A_arbace_go_build__init_part0_A_Init__O() any { A_arbace_go_build__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_go_build__init_part0_A_Load__O() any { A_arbace_go_build__init_part0_A_Init(); A_arbace_go_build__init_part0_A_Unit0__O(); A_arbace_go_build__init_part0_A_Unit1__O(); A_arbace_go_build__init_part0_A_Unit2__O(); A_arbace_go_build__init_part0_A_Unit3__O(); A_arbace_go_build__init_part0_A_Unit4__O(); A_arbace_go_build__init_part0_A_Unit5__O(); A_arbace_go_build__init_part0_A_Unit6__O(); A_arbace_go_build__init_part0_A_Unit7__O(); A_arbace_go_build__init_part0_A_Unit8__O(); A_arbace_go_build__init_part0_A_Unit9__O(); A_arbace_go_build__init_part0_A_Unit10__O(); A_arbace_go_build__init_part0_A_Unit11__O(); A_arbace_go_build__init_part0_A_Unit12__O(); A_arbace_go_build__init_part0_A_Unit13__O(); A_arbace_go_build__init_part0_A_Unit14__O(); A_arbace_go_build__init_part0_A_Unit15__O(); A_arbace_go_build__init_part0_A_Unit16__O(); A_arbace_go_build__init_part0_A_Unit17__O(); A_arbace_go_build__init_part0_A_Unit18__O(); A_arbace_go_build__init_part0_A_Unit19__O(); A_arbace_go_build__init_part0_A_Unit20__O(); A_arbace_go_build__init_part0_A_Unit21__O(); A_arbace_go_build__init_part0_A_Unit22__O(); A_arbace_go_build__init_part0_A_Unit23__O(); A_arbace_go_build__init_part0_A_Unit24__O(); A_arbace_go_build__init_part0_A_Unit25__O(); A_arbace_go_build__init_part0_A_Unit26__O(); A_arbace_go_build__init_part0_A_Unit27__O(); A_arbace_go_build__init_part0_A_Unit28__O(); A_arbace_go_build__init_part0_A_Unit29__O(); A_arbace_go_build__init_part0_A_Unit30__O(); A_arbace_go_build__init_part0_A_Unit31__O(); A_arbace_go_build__init_part0_A_Unit32__O(); A_arbace_go_build__init_part0_A_Unit33__O(); A_arbace_go_build__init_part0_A_Unit34__O(); A_arbace_go_build__init_part0_A_Unit35__O(); A_arbace_go_build__init_part0_A_Unit36__O(); A_arbace_go_build__init_part0_A_Unit37__O(); A_arbace_go_build__init_part0_A_Unit38__O(); A_arbace_go_build__init_part0_A_Unit39__O(); A_arbace_go_build__init_part0_A_Unit40__O(); A_arbace_go_build__init_part0_A_Unit41__O(); A_arbace_go_build__init_part0_A_Unit42__O(); A_arbace_go_build__init_part0_A_Unit43__O(); A_arbace_go_build__init_part0_A_Unit44__O(); A_arbace_go_build__init_part0_A_Unit45__O(); A_arbace_go_build__init_part0_A_Unit46__O(); A_arbace_go_build__init_part0_A_Unit47__O(); A_arbace_go_build__init_part0_A_Unit48__O(); A_arbace_go_build__init_part0_A_Unit49__O(); A_arbace_go_build__init_part0_A_Unit50__O(); A_arbace_go_build__init_part0_A_Unit51__O(); A_arbace_go_build__init_part0_A_Unit52__O(); A_arbace_go_build__init_part0_A_Unit53__O(); A_arbace_go_build__init_part0_A_Unit54__O(); A_arbace_go_build__init_part0_A_Unit55__O(); A_arbace_go_build__init_part0_A_Unit56__O(); A_arbace_go_build__init_part0_A_Unit57__O(); A_arbace_go_build__init_part0_A_Unit58__O(); A_arbace_go_build__init_part0_A_Unit59__O(); A_arbace_go_build__init_part0_A_Unit60__O(); A_arbace_go_build__init_part0_A_Unit61__O(); A_arbace_go_build__init_part0_A_Unit62__O(); A_arbace_go_build__init_part0_A_Unit63__O(); A_arbace_go_build__init_part0_A_Unit64__O(); A_arbace_go_build__init_part0_A_Unit65__O(); A_arbace_go_build__init_part0_A_Unit66__O(); A_arbace_go_build__init_part0_A_Unit67__O(); A_arbace_go_build__init_part0_A_Unit68__O(); A_arbace_go_build__init_part0_A_Unit69__O(); A_arbace_go_build__init_part0_A_Unit70__O(); A_arbace_go_build__init_part0_A_Unit71__O(); A_arbace_go_build__init_part0_A_Unit72__O(); A_arbace_go_build__init_part0_A_Unit73__O(); A_arbace_go_build__init_part0_A_Unit74__O(); A_arbace_go_build__init_part0_A_Unit75__O(); A_arbace_go_build__init_part0_A_Unit76__O(); A_arbace_go_build__init_part0_A_Unit77__O(); A_arbace_go_build__init_part0_A_Unit78__O(); A_arbace_go_build__init_part0_A_Unit79__O(); A_arbace_go_build__init_part0_A_Unit80__O(); A_arbace_go_build__init_part0_A_Unit81__O(); A_arbace_go_build__init_part0_A_Unit82__O(); A_arbace_go_build__init_part0_A_Unit83__O(); A_arbace_go_build__init_part0_A_Unit84__O(); A_arbace_go_build__init_part0_A_Unit85__O(); A_arbace_go_build__init_part0_A_Unit86__O(); A_arbace_go_build__init_part0_A_Unit87__O(); A_arbace_go_build__init_part0_A_Unit88__O(); A_arbace_go_build__init_part0_A_Unit89__O(); A_arbace_go_build__init_part0_A_Unit90__O(); A_arbace_go_build__init_part0_A_Unit91__O(); A_arbace_go_build__init_part0_A_Unit92__O(); A_arbace_go_build__init_part0_A_Unit93__O(); A_arbace_go_build__init_part0_A_Unit94__O(); A_arbace_go_build__init_part0_A_Unit95__O(); A_arbace_go_build__init_part0_A_Unit96__O(); A_arbace_go_build__init_part0_A_Unit97__O(); A_arbace_go_build__init_part0_A_Unit98__O(); A_arbace_go_build__init_part0_A_Unit99__O(); return nil }



func A_arbace_go_build__init_A_Load__O() any { jrt.StartCheck(); A_arbace_go_build__init_part0_A_Init__O(); A_arbace_go_build__init_part1_A_Init__O(); A_arbace_go_build__init_part2_A_Init__O(); A_arbace_go_build__init_part0_A_Load__O(); A_arbace_go_build__init_part1_A_Load__O(); A_arbace_go_build__init_part2_A_Load__O(); return nil }



























func A_arbace_go_build__init_part0_A_Unit4__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_4; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__6 any = A_arbace_go_build_op_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_build_op_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_601, true, nil); A_arbace_go_build_op_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__6, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_5)); return A_arbace_go_build__init_part0_A_const_4 }




func A_arbace_go_build__init_part0_A_Unit5__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_go_build_oa_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_build_oa_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_602, false, nil); A_arbace_go_build_oa_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_7)); return A_arbace_go_build__init_part0_A_const_6 }

func A_arbace_go_build__init_part0_A_Unit6__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_go_build_unsupported_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_build_unsupported_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_603, false, nil); A_arbace_go_build_unsupported_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_9)); return A_arbace_go_build__init_part0_A_const_8 }




func A_arbace_go_build__init_part0_A_Unit7__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_11)); v__1927001498__auto____1 = A_arbace_go_build__init_part0_A_const_10; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_build__init_part0_A_const_10; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_13)); var tmp3 *lang.Var = A_arbace_go_build__init_part0_A_const_10; var tmp4 any; var root_11 any = A_arbace_go_build__init_part0_A_const_12.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = jrt.Boolean_FALSE.Ref(); if linked_12 == nil { tmp4 = ifn_13.Invoke_O__O(arg_14) } else { tmp4 = linked_12.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_11, arg_14) }; tmp3.BindRoot_O__V(tmp4); return A_arbace_go_build__init_part0_A_const_10 } }

func A_arbace_go_build__init_part0_A_Unit8__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_build_lazily_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_build_lazily_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_604, false, nil); A_arbace_go_build_lazily_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_15)); return A_arbace_go_build__init_part0_A_const_14 }
















func A_arbace_go_build__init_part0_A_Unit9__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); A_arbace_go_build__init_part0_A_const_16.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_17)); return A_arbace_go_build__init_part0_A_const_16.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_build__init_part0_A_Unit10__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_19)); v__1927001498__auto____1 = A_arbace_go_build__init_part0_A_const_18; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_build__init_part0_A_const_18; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_21)); var tmp3 *lang.Var = A_arbace_go_build__init_part0_A_const_18; var tmp4 any; var root_17 any = A_arbace_go_build__init_part0_A_const_12.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_19 lang.IFn
							if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_go_build__init_part0_A_const_20; if linked_18 == nil { tmp4 = ifn_19.Invoke_O__O(arg_20) } else { tmp4 = linked_18.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_17, arg_20) }
//line :70:1
	tmp3.BindRoot_O__V(tmp4); return A_arbace_go_build__init_part0_A_const_18 } }


func A_arbace_go_build__init_part0_A_Unit11__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_build_method_data_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_build_method_data_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_605, false, nil); A_arbace_go_build_method_data_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_23)); return A_arbace_go_build__init_part0_A_const_22 }






func A_arbace_go_build__init_part0_A_Unit12__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_go_build_complete_instance_BANG__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_build_complete_instance_BANG__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_606, false, nil); A_arbace_go_build_complete_instance_BANG__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_25)); return A_arbace_go_build__init_part0_A_const_24 }




func A_arbace_go_build__init_part0_A_Unit13__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(85, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_go_build_with_ctx_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_build_with_ctx_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_607, false, nil); A_arbace_go_build_with_ctx_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_27)); return A_arbace_go_build__init_part0_A_const_26 }







func A_arbace_go_build__init_part0_A_Unit14__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(93, 1); A_arbace_go_build__init_part0_A_const_28.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_29)); return A_arbace_go_build__init_part0_A_const_28.SetDynamic_Z__Var(true).Ref() }






func A_arbace_go_build__init_part0_A_Unit15__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(100, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_go_build_compiled_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_build_compiled_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_608, false, nil); A_arbace_go_build_compiled_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_31)); return A_arbace_go_build__init_part0_A_const_30 }

func A_arbace_go_build__init_part0_A_Unit16__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(102, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_go_build_tstr_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_build_tstr_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_609, false, nil); A_arbace_go_build_tstr_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_33)); return A_arbace_go_build__init_part0_A_const_32 }







func A_arbace_go_build__init_part0_A_Unit17__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(110, 1); A_arbace_go_build__init_part0_A_const_34.BindRoot_O__V(A_arbace_go_build__init_part0_A_const_35); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_34; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_36)); return A_arbace_go_build__init_part0_A_const_34 }


func A_arbace_go_build__init_part0_A_Unit18__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(113, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_go_build_kind_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_build_kind_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_610, false, nil); A_arbace_go_build_kind_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_38)); return A_arbace_go_build__init_part0_A_const_37 }











func A_arbace_go_build__init_part0_A_Unit19__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(125, 1); A_arbace_go_build__init_part0_A_const_39.BindRoot_O__V(A_arbace_go_build__init_part0_A_const_40); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_39; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_41)); return A_arbace_go_build__init_part0_A_const_39 }



func A_arbace_go_build__init_part0_A_Unit20__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(129, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_go_build_basic_of_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_build_basic_of_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_611, false, nil); A_arbace_go_build_basic_of_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_43)); return A_arbace_go_build__init_part0_A_const_42 }
func A_arbace_go_build__init_part0_A_Unit21__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(130, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_go_build_unsigned_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_build_unsigned_QMARK__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_612, false, nil); A_arbace_go_build_unsigned_QMARK__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_45)); return A_arbace_go_build__init_part0_A_const_44 }
func A_arbace_go_build__init_part0_A_Unit22__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(131, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_go_build_wide_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_build_wide_QMARK__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_613, false, nil); A_arbace_go_build_wide_QMARK__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_47)); return A_arbace_go_build__init_part0_A_const_46 }
func A_arbace_go_build__init_part0_A_Unit23__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_go_build_struct_or_array_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_build_struct_or_array_QMARK__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_614, false, nil); A_arbace_go_build_struct_or_array_QMARK__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_49)); return A_arbace_go_build__init_part0_A_const_48 }
func A_arbace_go_build__init_part0_A_Unit24__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(133, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_go_build_iface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_build_iface_QMARK__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_615, false, nil); A_arbace_go_build_iface_QMARK__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_51)); return A_arbace_go_build__init_part0_A_const_50 }

func A_arbace_go_build__init_part0_A_Unit25__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(135, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_52; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_53)); return A_arbace_go_build__init_part0_A_const_52 }

func A_arbace_go_build__init_part0_A_Unit26__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(137, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_go_build_inst_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_build_inst_type_QMARK__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_616, false, nil); A_arbace_go_build_inst_type_QMARK__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_55)); return A_arbace_go_build__init_part0_A_const_54 }

func A_arbace_go_build__init_part0_A_Unit27__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_go_build_interpreted_named_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_build_interpreted_named_QMARK__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_617, false, nil); A_arbace_go_build_interpreted_named_QMARK__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_57)); return A_arbace_go_build__init_part0_A_const_56 }





func A_arbace_go_build__init_part0_A_Unit28__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(145, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_go_build_recursive_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_build_recursive_QMARK__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_618, false, nil); A_arbace_go_build_recursive_QMARK__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_59)); return A_arbace_go_build__init_part0_A_const_58 }






















func A_arbace_go_build__init_part0_A_Unit29__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(168, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_go_build_layout_needed_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_build_layout_needed_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_619, false, nil); A_arbace_go_build_layout_needed_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_61)); return A_arbace_go_build__init_part0_A_const_60 }




























func A_arbace_go_build__init_part0_A_Unit30__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(197, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_go_build_shape_type_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_build_shape_type_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_620, false, nil); A_arbace_go_build_shape_type_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_63)); return A_arbace_go_build__init_part0_A_const_62 }















func A_arbace_go_build__init_part0_A_Unit31__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(213, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_go_build_tag_text_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_build_tag_text_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_621, false, nil); A_arbace_go_build_tag_text_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_65)); return A_arbace_go_build__init_part0_A_const_64 }

func A_arbace_go_build__init_part0_A_Unit32__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(215, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_go_build_struct_parts_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_build_struct_parts_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_622, false, nil); A_arbace_go_build_struct_parts_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_67)); return A_arbace_go_build__init_part0_A_const_66 }









func A_arbace_go_build__init_part0_A_Unit33__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(225, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_go_build_method_key_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_build_method_key_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_623, false, nil); A_arbace_go_build_method_key_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_69)); return A_arbace_go_build__init_part0_A_const_68 }




func A_arbace_go_build__init_part0_A_Unit34__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(230, 1); A_arbace_go_build__init_part0_A_const_70.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_70; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_71)); return A_arbace_go_build__init_part0_A_const_70.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_build__init_part0_A_Unit35__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(236, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_72; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_73)); return A_arbace_go_build__init_part0_A_const_72 }

func A_arbace_go_build__init_part0_A_Unit36__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(238, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_go_build_set_iface_methods_BANG__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_build_set_iface_methods_BANG__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_624, false, nil); A_arbace_go_build_set_iface_methods_BANG__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_75)); return A_arbace_go_build__init_part0_A_const_74 }






func A_arbace_go_build__init_part0_A_Unit37__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(245, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_go_build_set_iface_methods_now_BANG__A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_build_set_iface_methods_now_BANG__A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_625, false, nil); A_arbace_go_build_set_iface_methods_now_BANG__A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_76)); return A_arbace_go_build__init_part0_A_const_72 }







func A_arbace_go_build__init_part0_A_Unit38__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(253, 1); A_arbace_go_build__init_part0_A_const_77.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_77; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_78)); return A_arbace_go_build__init_part0_A_const_77.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_build__init_part0_A_Unit39__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(258, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_79; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_80)); return A_arbace_go_build__init_part0_A_const_79 }
//line :258:1
func A_arbace_go_build__init_part0_A_Unit40__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(258, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_81; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_82)); return A_arbace_go_build__init_part0_A_const_81 }

func A_arbace_go_build__init_part0_A_Unit41__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(260, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_go_build_reflect_kind_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_build_reflect_kind_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_626, false, nil); A_arbace_go_build_reflect_kind_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_84)); return A_arbace_go_build__init_part0_A_const_83 }












func A_arbace_go_build__init_part0_A_Unit42__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(273, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_go_build_local_gen_of_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_go_build_local_gen_of_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_627, false, nil); A_arbace_go_build_local_gen_of_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_86)); return A_arbace_go_build__init_part0_A_const_85 }



func A_arbace_go_build__init_part0_A_Unit43__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(277, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_87; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_88)); return A_arbace_go_build__init_part0_A_const_87 }
//line :277:1
func A_arbace_go_build__init_part0_A_Unit44__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(277, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_89; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_90)); return A_arbace_go_build__init_part0_A_const_89 }

func A_arbace_go_build__init_part0_A_Unit45__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(279, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_91; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_92)); v__1927001498__auto____1 = A_arbace_go_build__init_part0_A_const_91; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_build__init_part0_A_const_91; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_93)); var tmp3 *lang.Var = A_arbace_go_build__init_part0_A_const_91; tmp3.BindRoot_O__V(jrt.ConcurrentHashMap_New()); return A_arbace_go_build__init_part0_A_const_91 } }



func A_arbace_go_build__init_part0_A_Unit46__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(283, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_94; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_95)); return A_arbace_go_build__init_part0_A_const_94 }

func A_arbace_go_build__init_part0_A_Unit47__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(285, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_96; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_go_build_named_desc_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_build_named_desc_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_628, false, nil); A_arbace_go_build_named_desc_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_97)); return A_arbace_go_build__init_part0_A_const_96 }






func A_arbace_go_build__init_part0_A_Unit48__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(292, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_94; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_go_build_named_desc1_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_go_build_named_desc1_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_629, false, nil); A_arbace_go_build_named_desc1_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_98)); return A_arbace_go_build__init_part0_A_const_94 }
























































func A_arbace_go_build__init_part0_A_Unit49__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(349, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_99; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_100)); return A_arbace_go_build__init_part0_A_const_99 }

func A_arbace_go_build__init_part0_A_Unit50__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(351, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_go_build_desc_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_go_build_desc_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_630, false, nil); A_arbace_go_build_desc_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_101)); return A_arbace_go_build__init_part0_A_const_52 }


























func A_arbace_go_build__init_part0_A_Unit51__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(378, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_go_build_desc1_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_go_build_desc1_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_631, false, nil); A_arbace_go_build_desc1_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_102)); return A_arbace_go_build__init_part0_A_const_99 }

































func A_arbace_go_build__init_part0_A_Unit52__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(412, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_103; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_go_build_int_bits_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_go_build_int_bits_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_632, false, nil); A_arbace_go_build_int_bits_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_104)); return A_arbace_go_build__init_part0_A_const_103 }




func A_arbace_go_build__init_part0_A_Unit53__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(417, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_go_build_go_string_node_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_build_go_string_node_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_633, false, nil); A_arbace_go_build_go_string_node_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_106)); return A_arbace_go_build__init_part0_A_const_105 }






func A_arbace_go_build__init_part0_A_Unit54__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(424, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_go_build_complex_value_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_go_build_complex_value_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_634, false, nil); A_arbace_go_build_complex_value_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_108)); return A_arbace_go_build__init_part0_A_const_107 }






func A_arbace_go_build__init_part0_A_Unit55__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(431, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_109; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_go_build_const_node_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_go_build_const_node_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_635, false, nil); A_arbace_go_build_const_node_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_110)); return A_arbace_go_build__init_part0_A_const_109 }














func A_arbace_go_build__init_part0_A_Unit56__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(446, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_go_build_new_slot_BANG__A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_go_build_new_slot_BANG__A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_636, false, nil); A_arbace_go_build_new_slot_BANG__A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_112)); return A_arbace_go_build__init_part0_A_const_111 }





func A_arbace_go_build__init_part0_A_Unit57__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(452, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_go_build_next_code_BANG__A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_go_build_next_code_BANG__A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_637, false, nil); A_arbace_go_build_next_code_BANG__A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_114)); return A_arbace_go_build__init_part0_A_const_113 }


func A_arbace_go_build__init_part0_A_Unit58__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(455, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_115; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_go_build_label_code_BANG__A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_go_build_label_code_BANG__A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_638, false, nil); A_arbace_go_build_label_code_BANG__A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_116)); return A_arbace_go_build__init_part0_A_const_115 }






func A_arbace_go_build__init_part0_A_Unit59__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(462, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_117; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_go_build_label_entry_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_go_build_label_entry_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_639, false, nil); A_arbace_go_build_label_entry_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_118)); return A_arbace_go_build__init_part0_A_const_117 }



func A_arbace_go_build__init_part0_A_Unit60__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(466, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_119; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_go_build_cell_var_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_go_build_cell_var_QMARK__A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_640, false, nil); A_arbace_go_build_cell_var_QMARK__A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_120)); return A_arbace_go_build__init_part0_A_const_119 }




func A_arbace_go_build__init_part0_A_Unit61__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(471, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_go_build_loc_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_go_build_loc_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_641, false, nil); A_arbace_go_build_loc_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_122)); return A_arbace_go_build__init_part0_A_const_121 }



func A_arbace_go_build__init_part0_A_Unit62__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(475, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_go_build_new_loc_BANG__A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_go_build_new_loc_BANG__A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_642, false, nil); A_arbace_go_build_new_loc_BANG__A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_124)); return A_arbace_go_build__init_part0_A_const_123 }






func A_arbace_go_build__init_part0_A_Unit63__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(482, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_go_build_temp_BANG__A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_go_build_temp_BANG__A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_643, false, nil); A_arbace_go_build_temp_BANG__A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_126)); return A_arbace_go_build__init_part0_A_const_125 }



func A_arbace_go_build__init_part0_A_Unit64__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(486, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_go_build_local_node_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_go_build_local_node_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_644, false, nil); A_arbace_go_build_local_node_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_128)); return A_arbace_go_build__init_part0_A_const_127 }

func A_arbace_go_build__init_part0_A_Unit65__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(488, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_go_build_as_kind_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_go_build_as_kind_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_645, false, nil); A_arbace_go_build_as_kind_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_130)); return A_arbace_go_build__init_part0_A_const_129 }








func A_arbace_go_build__init_part0_A_Unit66__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(497, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_go_build_load_p_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_go_build_load_p_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_646, false, nil); A_arbace_go_build_load_p_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_132)); return A_arbace_go_build__init_part0_A_const_131 }










func A_arbace_go_build__init_part0_A_Unit67__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(508, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_go_build_store_p_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_go_build_store_p_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_647, false, nil); A_arbace_go_build_store_p_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_134)); return A_arbace_go_build__init_part0_A_const_133 }











func A_arbace_go_build__init_part0_A_Unit68__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_go_build_set_slot_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_go_build_set_slot_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_648, false, nil); A_arbace_go_build_set_slot_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_136)); return A_arbace_go_build__init_part0_A_const_135 }


func A_arbace_go_build__init_part0_A_Unit69__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(523, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_137; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_go_build_expr_stmt_of_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_go_build_expr_stmt_of_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_649, false, nil); A_arbace_go_build_expr_stmt_of_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_138)); return A_arbace_go_build__init_part0_A_const_137 }


func A_arbace_go_build__init_part0_A_Unit70__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_139; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_140)); return A_arbace_go_build__init_part0_A_const_139 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit71__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_141; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_142)); return A_arbace_go_build__init_part0_A_const_141 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit72__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_143; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_144)); return A_arbace_go_build__init_part0_A_const_143 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit73__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_145; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_146)); return A_arbace_go_build__init_part0_A_const_145 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit74__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_147; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_148)); return A_arbace_go_build__init_part0_A_const_147 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit75__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_149; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_150)); return A_arbace_go_build__init_part0_A_const_149 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit76__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_151; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_152)); return A_arbace_go_build__init_part0_A_const_151 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit77__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_153; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_154)); return A_arbace_go_build__init_part0_A_const_153 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit78__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_155; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_156)); return A_arbace_go_build__init_part0_A_const_155 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit79__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_157; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_158)); return A_arbace_go_build__init_part0_A_const_157 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit80__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_159; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_160)); return A_arbace_go_build__init_part0_A_const_159 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit81__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_161; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_162)); return A_arbace_go_build__init_part0_A_const_161 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit82__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_163; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_164)); return A_arbace_go_build__init_part0_A_const_163 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit83__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_165; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_166)); return A_arbace_go_build__init_part0_A_const_165 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit84__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_167; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_168)); return A_arbace_go_build__init_part0_A_const_167 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit85__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_169; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_170)); return A_arbace_go_build__init_part0_A_const_169 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit86__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_171; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_172)); return A_arbace_go_build__init_part0_A_const_171 }
//line :526:1
func A_arbace_go_build__init_part0_A_Unit87__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_173; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_174)); return A_arbace_go_build__init_part0_A_const_173 }


func A_arbace_go_build__init_part0_A_Unit88__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(529, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_175; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_go_build_exk_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_go_build_exk_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_650, false, nil); A_arbace_go_build_exk_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_175; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_176)); return A_arbace_go_build__init_part0_A_const_175 }



func A_arbace_go_build__init_part0_A_Unit89__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(533, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_177; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_178)); return A_arbace_go_build__init_part0_A_const_177 }

func A_arbace_go_build__init_part0_A_Unit90__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(535, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_179; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_go_build_iface_content_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_go_build_iface_content_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_651, false, nil); A_arbace_go_build_iface_content_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_179; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_180)); return A_arbace_go_build__init_part0_A_const_179 }

















func A_arbace_go_build__init_part0_A_Unit91__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(553, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_181; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_go_build_arith_name_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_go_build_arith_name_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_652, false, nil); A_arbace_go_build_arith_name_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_181; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_182)); return A_arbace_go_build__init_part0_A_const_181 }



func A_arbace_go_build__init_part0_A_Unit92__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(557, 1); A_arbace_go_build__init_part0_A_const_183.BindRoot_O__V(A_arbace_go_build__init_part0_A_const_184); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_183; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_185)); return A_arbace_go_build__init_part0_A_const_183 }

func A_arbace_go_build__init_part0_A_Unit93__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(559, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_186; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_go_build_const_of_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_go_build_const_of_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_653, false, nil); A_arbace_go_build_const_of_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_186; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_187)); return A_arbace_go_build__init_part0_A_const_186 }




func A_arbace_go_build__init_part0_A_Unit94__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(564, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_188; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_go_build_local_slot_of_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_go_build_local_slot_of_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_654, false, nil); A_arbace_go_build_local_slot_of_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_188; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_189)); return A_arbace_go_build__init_part0_A_const_188 }







func A_arbace_go_build__init_part0_A_Unit95__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(572, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_190; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_go_build_int_binop_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_go_build_int_binop_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_655, false, nil); A_arbace_go_build_int_binop_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_190; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_191)); return A_arbace_go_build__init_part0_A_const_190 }













func A_arbace_go_build__init_part0_A_Unit96__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(586, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_192; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_go_build_float_binop_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_go_build_float_binop_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_656, false, nil); A_arbace_go_build_float_binop_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_192; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_193)); return A_arbace_go_build__init_part0_A_const_192 }



func A_arbace_go_build__init_part0_A_Unit97__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(590, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_194; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_go_build_binop_nodes_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_go_build_binop_nodes_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_657, false, nil); A_arbace_go_build_binop_nodes_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_194; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_195)); return A_arbace_go_build__init_part0_A_const_194 }












func A_arbace_go_build__init_part0_A_Unit98__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(603, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_196; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_go_build_count_node_A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_go_build_count_node_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_658, false, nil); A_arbace_go_build_count_node_A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_196; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_197)); return A_arbace_go_build__init_part0_A_const_196 }









func A_arbace_go_build__init_part0_A_Unit99__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(613, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_198; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_go_build_shift_node_A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_go_build_shift_node_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_659, false, nil); A_arbace_go_build_shift_node_A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_198; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_199)); return A_arbace_go_build__init_part0_A_const_198 }




func A_arbace_go_build__init_part1_A_Unit100__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(618, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_go_build_nil_node_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_build_nil_node_QMARK__A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_661, false, nil); A_arbace_go_build_nil_node_QMARK__A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_1)); return A_arbace_go_build__init_part1_A_const_0 }
//line :618:1
func A_arbace_go_build__init_part1_A_Init__O() any { A_arbace_go_build__init_part1_A_Init(); return nil }
//line :618:1
func A_arbace_go_build__init_part1_A_Load__O() any { A_arbace_go_build__init_part1_A_Init(); A_arbace_go_build__init_part1_A_Unit100__O(); A_arbace_go_build__init_part1_A_Unit101__O(); A_arbace_go_build__init_part1_A_Unit102__O(); A_arbace_go_build__init_part1_A_Unit103__O(); A_arbace_go_build__init_part1_A_Unit104__O(); A_arbace_go_build__init_part1_A_Unit105__O(); A_arbace_go_build__init_part1_A_Unit106__O(); A_arbace_go_build__init_part1_A_Unit107__O(); A_arbace_go_build__init_part1_A_Unit108__O(); A_arbace_go_build__init_part1_A_Unit109__O(); A_arbace_go_build__init_part1_A_Unit110__O(); A_arbace_go_build__init_part1_A_Unit111__O(); A_arbace_go_build__init_part1_A_Unit112__O(); A_arbace_go_build__init_part1_A_Unit113__O(); A_arbace_go_build__init_part1_A_Unit114__O(); A_arbace_go_build__init_part1_A_Unit115__O(); A_arbace_go_build__init_part1_A_Unit116__O(); A_arbace_go_build__init_part1_A_Unit117__O(); A_arbace_go_build__init_part1_A_Unit118__O(); A_arbace_go_build__init_part1_A_Unit119__O(); A_arbace_go_build__init_part1_A_Unit120__O(); A_arbace_go_build__init_part1_A_Unit121__O(); A_arbace_go_build__init_part1_A_Unit122__O(); A_arbace_go_build__init_part1_A_Unit123__O(); A_arbace_go_build__init_part1_A_Unit124__O(); A_arbace_go_build__init_part1_A_Unit125__O(); A_arbace_go_build__init_part1_A_Unit126__O(); A_arbace_go_build__init_part1_A_Unit127__O(); A_arbace_go_build__init_part1_A_Unit128__O(); A_arbace_go_build__init_part1_A_Unit129__O(); A_arbace_go_build__init_part1_A_Unit130__O(); A_arbace_go_build__init_part1_A_Unit131__O(); A_arbace_go_build__init_part1_A_Unit132__O(); A_arbace_go_build__init_part1_A_Unit133__O(); A_arbace_go_build__init_part1_A_Unit134__O(); A_arbace_go_build__init_part1_A_Unit135__O(); A_arbace_go_build__init_part1_A_Unit136__O(); A_arbace_go_build__init_part1_A_Unit137__O(); A_arbace_go_build__init_part1_A_Unit138__O(); A_arbace_go_build__init_part1_A_Unit139__O(); A_arbace_go_build__init_part1_A_Unit140__O(); A_arbace_go_build__init_part1_A_Unit141__O(); A_arbace_go_build__init_part1_A_Unit142__O(); A_arbace_go_build__init_part1_A_Unit143__O(); A_arbace_go_build__init_part1_A_Unit144__O(); A_arbace_go_build__init_part1_A_Unit145__O(); A_arbace_go_build__init_part1_A_Unit146__O(); A_arbace_go_build__init_part1_A_Unit147__O(); A_arbace_go_build__init_part1_A_Unit148__O(); A_arbace_go_build__init_part1_A_Unit149__O(); A_arbace_go_build__init_part1_A_Unit150__O(); A_arbace_go_build__init_part1_A_Unit151__O(); A_arbace_go_build__init_part1_A_Unit152__O(); A_arbace_go_build__init_part1_A_Unit153__O(); A_arbace_go_build__init_part1_A_Unit154__O(); A_arbace_go_build__init_part1_A_Unit155__O(); A_arbace_go_build__init_part1_A_Unit156__O(); A_arbace_go_build__init_part1_A_Unit157__O(); A_arbace_go_build__init_part1_A_Unit158__O(); A_arbace_go_build__init_part1_A_Unit159__O(); A_arbace_go_build__init_part1_A_Unit160__O(); A_arbace_go_build__init_part1_A_Unit161__O(); A_arbace_go_build__init_part1_A_Unit162__O(); A_arbace_go_build__init_part1_A_Unit163__O(); A_arbace_go_build__init_part1_A_Unit164__O(); A_arbace_go_build__init_part1_A_Unit165__O(); A_arbace_go_build__init_part1_A_Unit166__O(); A_arbace_go_build__init_part1_A_Unit167__O(); A_arbace_go_build__init_part1_A_Unit168__O(); A_arbace_go_build__init_part1_A_Unit169__O(); A_arbace_go_build__init_part1_A_Unit170__O(); A_arbace_go_build__init_part1_A_Unit171__O(); A_arbace_go_build__init_part1_A_Unit172__O(); A_arbace_go_build__init_part1_A_Unit173__O(); A_arbace_go_build__init_part1_A_Unit174__O(); A_arbace_go_build__init_part1_A_Unit175__O(); A_arbace_go_build__init_part1_A_Unit176__O(); A_arbace_go_build__init_part1_A_Unit177__O(); A_arbace_go_build__init_part1_A_Unit178__O(); A_arbace_go_build__init_part1_A_Unit179__O(); A_arbace_go_build__init_part1_A_Unit180__O(); A_arbace_go_build__init_part1_A_Unit181__O(); A_arbace_go_build__init_part1_A_Unit182__O(); A_arbace_go_build__init_part1_A_Unit183__O(); A_arbace_go_build__init_part1_A_Unit184__O(); A_arbace_go_build__init_part1_A_Unit185__O(); A_arbace_go_build__init_part1_A_Unit186__O(); A_arbace_go_build__init_part1_A_Unit187__O(); A_arbace_go_build__init_part1_A_Unit188__O(); A_arbace_go_build__init_part1_A_Unit189__O(); A_arbace_go_build__init_part1_A_Unit190__O(); A_arbace_go_build__init_part1_A_Unit191__O(); A_arbace_go_build__init_part1_A_Unit192__O(); A_arbace_go_build__init_part1_A_Unit193__O(); A_arbace_go_build__init_part1_A_Unit194__O(); A_arbace_go_build__init_part1_A_Unit195__O(); A_arbace_go_build__init_part1_A_Unit196__O(); A_arbace_go_build__init_part1_A_Unit197__O(); A_arbace_go_build__init_part1_A_Unit198__O(); A_arbace_go_build__init_part1_A_Unit199__O(); return nil }

func A_arbace_go_build__init_part1_A_Unit101__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(620, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_go_build_compare_nodes_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_build_compare_nodes_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_662, false, nil); A_arbace_go_build_compare_nodes_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_3)); return A_arbace_go_build__init_part1_A_const_2 }
















































func A_arbace_go_build__init_part1_A_Unit102__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(669, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_go_build_binary_node_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_build_binary_node_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_663, false, nil); A_arbace_go_build_binary_node_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_5)); return A_arbace_go_build__init_part1_A_const_4 }

















func A_arbace_go_build__init_part1_A_Unit103__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(687, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_go_build_unary_node_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_build_unary_node_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_664, false, nil); A_arbace_go_build_unary_node_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_7)); return A_arbace_go_build__init_part1_A_const_6 }












func A_arbace_go_build__init_part1_A_Unit104__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(700, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_go_build_bytes_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_build_bytes_type_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_665, false, nil); A_arbace_go_build_bytes_type_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_9)); return A_arbace_go_build__init_part1_A_const_8 }
func A_arbace_go_build__init_part1_A_Unit105__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(701, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_go_build_runes_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_build_runes_type_QMARK__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_666, false, nil); A_arbace_go_build_runes_type_QMARK__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_11)); return A_arbace_go_build__init_part1_A_const_10 }

func A_arbace_go_build__init_part1_A_Unit106__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(703, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_go_build_conv_node_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_build_conv_node_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_667, false, nil); A_arbace_go_build_conv_node_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_13)); return A_arbace_go_build__init_part1_A_const_12 }













































func A_arbace_go_build__init_part1_A_Unit107__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(749, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_build_addressable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_build_addressable_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_668, false, nil); A_arbace_go_build_addressable_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_15)); return A_arbace_go_build__init_part1_A_const_14 }


func A_arbace_go_build__init_part1_A_Unit108__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(752, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_go_build_struct_of_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_build_struct_of_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_669, false, nil); A_arbace_go_build_struct_of_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_17)); return A_arbace_go_build__init_part1_A_const_16 }




func A_arbace_go_build__init_part1_A_Unit109__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(757, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_go_build_value_place_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_build_value_place_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_670, false, nil); A_arbace_go_build_value_place_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_19)); return A_arbace_go_build__init_part1_A_const_18 }







func A_arbace_go_build__init_part1_A_Unit110__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(765, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_build_field_place_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_build_field_place_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_671, false, nil); A_arbace_go_build_field_place_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_21)); return A_arbace_go_build__init_part1_A_const_20 }


















func A_arbace_go_build__init_part1_A_Unit111__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(784, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_go_build_uidx_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_build_uidx_QMARK__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_672, false, nil); A_arbace_go_build_uidx_QMARK__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_23)); return A_arbace_go_build__init_part1_A_const_22 }




func A_arbace_go_build__init_part1_A_Unit112__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(789, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_go_build_uidx_mask_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_build_uidx_mask_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_673, false, nil); A_arbace_go_build_uidx_mask_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_25)); return A_arbace_go_build__init_part1_A_const_24 }




func A_arbace_go_build__init_part1_A_Unit113__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(794, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_go_build_index_place_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_build_index_place_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_674, false, nil); A_arbace_go_build_index_place_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_27)); return A_arbace_go_build__init_part1_A_const_26 }












func A_arbace_go_build__init_part1_A_Unit114__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(807, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_go_build_place_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_build_place_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_675, false, nil); A_arbace_go_build_place_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_29)); return A_arbace_go_build__init_part1_A_const_28 }



















func A_arbace_go_build__init_part1_A_Unit115__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(827, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_go_build_elem_node_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_build_elem_node_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_676, false, nil); A_arbace_go_build_elem_node_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_31)); return A_arbace_go_build__init_part1_A_const_30 }




func A_arbace_go_build__init_part1_A_Unit116__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(832, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_go_build_lit_place_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_build_lit_place_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_677, false, nil); A_arbace_go_build_lit_place_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_33)); return A_arbace_go_build__init_part1_A_const_32 }



























func A_arbace_go_build__init_part1_A_Unit117__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(860, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_go_build_lit_node_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_build_lit_node_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_678, false, nil); A_arbace_go_build_lit_node_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_35)); return A_arbace_go_build__init_part1_A_const_34 }














func A_arbace_go_build__init_part1_A_Unit118__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(875, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_go_build_var_node_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_build_var_node_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_679, false, nil); A_arbace_go_build_var_node_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_37)); return A_arbace_go_build__init_part1_A_const_36 }





func A_arbace_go_build__init_part1_A_Unit119__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(881, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_go_build_global_node_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_build_global_node_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_680, false, nil); A_arbace_go_build_global_node_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_39)); return A_arbace_go_build__init_part1_A_const_38 }


func A_arbace_go_build__init_part1_A_Unit120__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(884, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_40; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_41)); return A_arbace_go_build__init_part1_A_const_40 }
//line :884:1
func A_arbace_go_build__init_part1_A_Unit121__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(884, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_42; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_43)); return A_arbace_go_build__init_part1_A_const_42 }

func A_arbace_go_build__init_part1_A_Unit122__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(886, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_go_build_func_value_node_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_build_func_value_node_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_681, false, nil); A_arbace_go_build_func_value_node_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_45)); return A_arbace_go_build__init_part1_A_const_44 }









func A_arbace_go_build__init_part1_A_Unit123__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(896, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_46; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_47)); return A_arbace_go_build__init_part1_A_const_46 }

func A_arbace_go_build__init_part1_A_Unit124__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(898, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_go_build_coerce_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_build_coerce_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_682, false, nil); A_arbace_go_build_coerce_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_49)); return A_arbace_go_build__init_part1_A_const_48 }












func A_arbace_go_build__init_part1_A_Unit125__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(911, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_go_build_ex_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_build_ex_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_683, false, nil); A_arbace_go_build_ex_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_51)); return A_arbace_go_build__init_part1_A_const_50 }





func A_arbace_go_build__init_part1_A_Unit126__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(917, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_go_build_ex_STAR__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_build_ex_STAR__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_684, false, nil); A_arbace_go_build_ex_STAR__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_52)); return A_arbace_go_build__init_part1_A_const_46 }




























































func A_arbace_go_build__init_part1_A_Unit127__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(978, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_go_build_ex_as_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_build_ex_as_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_685, false, nil); A_arbace_go_build_ex_as_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_54)); return A_arbace_go_build__init_part1_A_const_53 }



func A_arbace_go_build__init_part1_A_Unit128__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(982, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_go_build_slot_layout_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_build_slot_layout_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_686, false, nil); A_arbace_go_build_slot_layout_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_56)); return A_arbace_go_build__init_part1_A_const_55 }












func A_arbace_go_build__init_part1_A_Unit129__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(995, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_go_build_arg_setter_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_build_arg_setter_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_687, false, nil); A_arbace_go_build_arg_setter_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_58)); return A_arbace_go_build__init_part1_A_const_57 }


func A_arbace_go_build__init_part1_A_Unit130__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(998, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_59; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_60)); return A_arbace_go_build__init_part1_A_const_59 }
//line :998:1
func A_arbace_go_build__init_part1_A_Unit131__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(998, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_61; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_62)); return A_arbace_go_build__init_part1_A_const_61 }

func A_arbace_go_build__init_part1_A_Unit132__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1000, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_go_build_mem_converted_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_build_mem_converted_QMARK__A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_688, false, nil); A_arbace_go_build_mem_converted_QMARK__A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_64)); return A_arbace_go_build__init_part1_A_const_63 }






func A_arbace_go_build__init_part1_A_Unit133__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1007, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_go_build_mem_node_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_build_mem_node_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_689, false, nil); A_arbace_go_build_mem_node_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_66)); return A_arbace_go_build__init_part1_A_const_65 }





func A_arbace_go_build__init_part1_A_Unit134__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1013, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_go_build_arg_nodes_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_build_arg_nodes_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_690, false, nil); A_arbace_go_build_arg_nodes_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_68)); return A_arbace_go_build__init_part1_A_const_67 }

















func A_arbace_go_build__init_part1_A_Unit135__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1031, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_go_build_call_results_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_build_call_results_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_691, false, nil); A_arbace_go_build_call_results_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_70)); return A_arbace_go_build__init_part1_A_const_69 }








func A_arbace_go_build__init_part1_A_Unit136__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1040, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_go_build_sig_of_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_build_sig_of_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_692, false, nil); A_arbace_go_build_sig_of_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_72)); return A_arbace_go_build__init_part1_A_const_71 }

func A_arbace_go_build__init_part1_A_Unit137__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1042, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_go_build_cell_call_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_go_build_cell_call_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_693, false, nil); A_arbace_go_build_cell_call_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_74)); return A_arbace_go_build__init_part1_A_const_73 }











func A_arbace_go_build__init_part1_A_Unit138__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1054, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_go_build_static_call_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_build_static_call_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_694, false, nil); A_arbace_go_build_static_call_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_76)); return A_arbace_go_build__init_part1_A_const_75 }





func A_arbace_go_build__init_part1_A_Unit139__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1060, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_go_build_value_call_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_go_build_value_call_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_695, false, nil); A_arbace_go_build_value_call_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_78)); return A_arbace_go_build__init_part1_A_const_77 }













func A_arbace_go_build__init_part1_A_Unit140__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1074, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_go_build_from_mem_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_go_build_from_mem_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_696, false, nil); A_arbace_go_build_from_mem_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_80)); return A_arbace_go_build__init_part1_A_const_79 }




func A_arbace_go_build__init_part1_A_Unit141__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1079, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_go_build_compiled_call_node_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_go_build_compiled_call_node_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_697, false, nil); A_arbace_go_build_compiled_call_node_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_82)); return A_arbace_go_build__init_part1_A_const_81 }









func A_arbace_go_build__init_part1_A_Unit142__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1089, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_go_build_compiled_call_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_go_build_compiled_call_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_698, false, nil); A_arbace_go_build_compiled_call_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_84)); return A_arbace_go_build__init_part1_A_const_83 }





func A_arbace_go_build__init_part1_A_Unit143__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1095, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_go_build_recv_type_of_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_build_recv_type_of_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_699, false, nil); A_arbace_go_build_recv_type_of_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_86)); return A_arbace_go_build__init_part1_A_const_85 }







func A_arbace_go_build__init_part1_A_Unit144__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1103, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_go_build_method_cell_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_go_build_method_cell_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_700, false, nil); A_arbace_go_build_method_cell_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_88)); return A_arbace_go_build__init_part1_A_const_87 }




func A_arbace_go_build__init_part1_A_Unit145__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1108, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_89; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_go_build_generic_method_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_go_build_generic_method_QMARK__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_701, false, nil); A_arbace_go_build_generic_method_QMARK__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_90)); return A_arbace_go_build__init_part1_A_const_89 }




func A_arbace_go_build__init_part1_A_Unit146__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1113, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_go_build_method_target_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_go_build_method_target_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_702, false, nil); A_arbace_go_build_method_target_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_92)); return A_arbace_go_build__init_part1_A_const_91 }











func A_arbace_go_build__init_part1_A_Unit147__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1125, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_go_build_method_callable_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_go_build_method_callable_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_703, false, nil); A_arbace_go_build_method_callable_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_94)); return A_arbace_go_build__init_part1_A_const_93 }









func A_arbace_go_build__init_part1_A_Unit148__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1135, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_go_build_instance_callable_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_go_build_instance_callable_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_704, false, nil); A_arbace_go_build_instance_callable_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_96)); return A_arbace_go_build__init_part1_A_const_95 }
















func A_arbace_go_build__init_part1_A_Unit149__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1152, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_go_build_path_derefs_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_go_build_path_derefs_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_705, false, nil); A_arbace_go_build_path_derefs_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_98)); return A_arbace_go_build__init_part1_A_const_97 }













func A_arbace_go_build__init_part1_A_Unit150__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1166, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_go_build_field_sel_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_go_build_field_sel_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_706, false, nil); A_arbace_go_build_field_sel_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_100)); return A_arbace_go_build__init_part1_A_const_99 }











func A_arbace_go_build__init_part1_A_Unit151__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1178, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_go_build_recv_node_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_go_build_recv_node_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_707, false, nil); A_arbace_go_build_recv_node_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_102)); return A_arbace_go_build__init_part1_A_const_101 }





















func A_arbace_go_build__init_part1_A_Unit152__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1200, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_103; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_go_build_interp_method_call_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_go_build_interp_method_call_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_708, false, nil); A_arbace_go_build_interp_method_call_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_104)); return A_arbace_go_build__init_part1_A_const_103 }












func A_arbace_go_build__init_part1_A_Unit153__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1213, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_go_build_via_iface_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_go_build_via_iface_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_709, false, nil); A_arbace_go_build_via_iface_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_106)); return A_arbace_go_build__init_part1_A_const_105 }












func A_arbace_go_build__init_part1_A_Unit154__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1226, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_go_build_method_call_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_go_build_method_call_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_710, false, nil); A_arbace_go_build_method_call_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_108)); return A_arbace_go_build__init_part1_A_const_107 }





















func A_arbace_go_build__init_part1_A_Unit155__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1248, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_go_build_error_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_go_build_error_type_QMARK__A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_711, false, nil); A_arbace_go_build_error_type_QMARK__A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_109)); return A_arbace_go_build__init_part1_A_const_59 }

func A_arbace_go_build__init_part1_A_Unit156__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1250, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_go_build_compiled_iface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_go_build_compiled_iface_QMARK__A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_712, false, nil); A_arbace_go_build_compiled_iface_QMARK__A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_110)); return A_arbace_go_build__init_part1_A_const_61 }

func A_arbace_go_build__init_part1_A_Unit157__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1252, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_go_build_iface_recv_node_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_go_build_iface_recv_node_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_713, false, nil); A_arbace_go_build_iface_recv_node_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_112)); return A_arbace_go_build__init_part1_A_const_111 }






func A_arbace_go_build__init_part1_A_Unit158__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1259, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_go_build_iface_call_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_go_build_iface_call_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_714, false, nil); A_arbace_go_build_iface_call_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_114)); return A_arbace_go_build__init_part1_A_const_113 }



































func A_arbace_go_build__init_part1_A_Unit159__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1295, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_115; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_go_build_method_value_node_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_go_build_method_value_node_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_715, false, nil); A_arbace_go_build_method_value_node_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_116)); return A_arbace_go_build__init_part1_A_const_115 }

















func A_arbace_go_build__init_part1_A_Unit160__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1313, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_117; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_go_build_iface_method_value_node_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_go_build_iface_method_value_node_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_716, false, nil); A_arbace_go_build_iface_method_value_node_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_118)); return A_arbace_go_build__init_part1_A_const_117 }









func A_arbace_go_build__init_part1_A_Unit161__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1323, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_119; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_120)); return A_arbace_go_build__init_part1_A_const_119 }

func A_arbace_go_build__init_part1_A_Unit162__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1325, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_go_build_local_obj_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_go_build_local_obj_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_717, false, nil); A_arbace_go_build_local_obj_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_122)); return A_arbace_go_build__init_part1_A_const_121 }

func A_arbace_go_build__init_part1_A_Unit163__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1327, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_go_build_local_ref_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_go_build_local_ref_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_718, false, nil); A_arbace_go_build_local_ref_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_124)); return A_arbace_go_build__init_part1_A_const_123 }

func A_arbace_go_build__init_part1_A_Unit164__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1329, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_go_build_selection_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_go_build_selection_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_719, false, nil); A_arbace_go_build_selection_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_126)); return A_arbace_go_build__init_part1_A_const_125 }















func A_arbace_go_build__init_part1_A_Unit165__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1345, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_go_build_thunk_body_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_go_build_thunk_body_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_720, false, nil); A_arbace_go_build_thunk_body_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_128)); return A_arbace_go_build__init_part1_A_const_127 }












func A_arbace_go_build__init_part1_A_Unit166__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1358, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_go_build_build_method_thunk_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_go_build_build_method_thunk_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_721, false, nil); A_arbace_go_build_build_method_thunk_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_130)); return A_arbace_go_build__init_part1_A_const_129 }

















func A_arbace_go_build__init_part1_A_Unit167__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1376, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_go_build_method_expr_node_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_go_build_method_expr_node_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_722, false, nil); A_arbace_go_build_method_expr_node_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_132)); return A_arbace_go_build__init_part1_A_const_131 }






















func A_arbace_go_build__init_part1_A_Unit168__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1399, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_go_build_method_candidates_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_go_build_method_candidates_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_723, false, nil); A_arbace_go_build_method_candidates_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_134)); return A_arbace_go_build__init_part1_A_const_133 }




















func A_arbace_go_build__init_part1_A_Unit169__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1420, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_go_build_may_have_methods_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_go_build_may_have_methods_QMARK__A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_724, false, nil); A_arbace_go_build_may_have_methods_QMARK__A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_136)); return A_arbace_go_build__init_part1_A_const_135 }












func A_arbace_go_build__init_part1_A_Unit170__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1433, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_137; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_138)); v__1927001498__auto____1 = A_arbace_go_build__init_part1_A_const_137; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_build__init_part1_A_const_137; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_139)); var tmp3 *lang.Var = A_arbace_go_build__init_part1_A_const_137; tmp3.BindRoot_O__V(jrt.IdentityHashMap_New()); return A_arbace_go_build__init_part1_A_const_137 } }

func A_arbace_go_build__init_part1_A_Unit171__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1435, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_140; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_go_build_check_methods_kept_BANG__A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_go_build_check_methods_kept_BANG__A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_725, false, nil); A_arbace_go_build_check_methods_kept_BANG__A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_141)); return A_arbace_go_build__init_part1_A_const_140 }













func A_arbace_go_build__init_part1_A_Unit172__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1449, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_142; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_go_build_ensure_methods_BANG__A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_go_build_ensure_methods_BANG__A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_726, false, nil); A_arbace_go_build_ensure_methods_BANG__A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_143)); return A_arbace_go_build__init_part1_A_const_142 }
























































func A_arbace_go_build__init_part1_A_Unit173__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1506, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_144; var tmp2 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_go_build_method_count_A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_go_build_method_count_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_727, false, nil); A_arbace_go_build_method_count_A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_145)); return A_arbace_go_build__init_part1_A_const_144 }












func A_arbace_go_build__init_part1_A_Unit174__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1519, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_146; var tmp2 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_go_build_set_named_methods_BANG__A_New(); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_go_build_set_named_methods_BANG__A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_728, false, nil); A_arbace_go_build_set_named_methods_BANG__A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_147)); return A_arbace_go_build__init_part1_A_const_146 }









func A_arbace_go_build__init_part1_A_Unit175__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1529, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_148; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_149)); return A_arbace_go_build__init_part1_A_const_148 }

func A_arbace_go_build__init_part1_A_Unit176__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1531, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_150; var tmp2 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_go_build_iface_name_A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_go_build_iface_name_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_729, false, nil); A_arbace_go_build_iface_name_A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_151)); return A_arbace_go_build__init_part1_A_const_150 }







func A_arbace_go_build__init_part1_A_Unit177__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1539, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_152; var tmp2 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_go_build_assert_desc_A_New(); var tmp3 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_go_build_assert_desc_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_730, false, nil); A_arbace_go_build_assert_desc_A_fn_class = fncls__139d; tmp3 = fncls__139d } else { tmp3 = fncls__139 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_153)); return A_arbace_go_build__init_part1_A_const_152 }




func A_arbace_go_build__init_part1_A_Unit178__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1544, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_154; var tmp2 *lang.Compiler_AOTFn; var fnbody__142 any = A_arbace_go_build_assert_kn_A_New(); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_go_build_assert_kn_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_731, false, nil); A_arbace_go_build_assert_kn_A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_155)); return A_arbace_go_build__init_part1_A_const_154 }










func A_arbace_go_build__init_part1_A_Unit179__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1555, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_156; var tmp2 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_go_build_call_node_A_New(); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_go_build_call_node_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_732, false, nil); A_arbace_go_build_call_node_A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_157)); return A_arbace_go_build__init_part1_A_const_156 }






















func A_arbace_go_build__init_part1_A_Unit180__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1578, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_158; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_go_build_call_stmt_A_New(); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_go_build_call_stmt_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_733, false, nil); A_arbace_go_build_call_stmt_A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_159)); return A_arbace_go_build__init_part1_A_const_158 }











func A_arbace_go_build__init_part1_A_Unit181__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1590, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_160; var tmp2 *lang.Compiler_AOTFn; var fnbody__148 any = A_arbace_go_build_elem_type_A_New(); var tmp3 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_go_build_elem_type_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_734, false, nil); A_arbace_go_build_elem_type_A_fn_class = fncls__147d; tmp3 = fncls__147d } else { tmp3 = fncls__147 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__148, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_160; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_161)); return A_arbace_go_build__init_part1_A_const_160 }

func A_arbace_go_build__init_part1_A_Unit182__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1592, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_162; var tmp2 *lang.Compiler_AOTFn; var fnbody__150 any = A_arbace_go_build_builtin_A_New(); var tmp3 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_go_build_builtin_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_735, false, nil); A_arbace_go_build_builtin_A_fn_class = fncls__149d; tmp3 = fncls__149d } else { tmp3 = fncls__149 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__150, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_163)); return A_arbace_go_build__init_part1_A_const_162 }




















































































func A_arbace_go_build__init_part1_A_Unit183__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1677, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_164; var tmp2 *lang.Compiler_AOTFn; var fnbody__152 any = A_arbace_go_build_expr_or_stmt_A_New(); var tmp3 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_go_build_expr_or_stmt_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_736, false, nil); A_arbace_go_build_expr_or_stmt_A_fn_class = fncls__151d; tmp3 = fncls__151d } else { tmp3 = fncls__151 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__152, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_164; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_165)); return A_arbace_go_build__init_part1_A_const_164 }



func A_arbace_go_build__init_part1_A_Unit184__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1681, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_166; var tmp2 *lang.Compiler_AOTFn; var fnbody__154 any = A_arbace_go_build_slot_of_place_A_New(); var tmp3 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_go_build_slot_of_place_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_737, false, nil); A_arbace_go_build_slot_of_place_A_fn_class = fncls__153d; tmp3 = fncls__153d } else { tmp3 = fncls__153 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__154, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_166; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_167)); return A_arbace_go_build__init_part1_A_const_166 }






func A_arbace_go_build__init_part1_A_Unit185__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1688, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_168; var tmp2 *lang.Compiler_AOTFn; var fnbody__156 any = A_arbace_go_build_assign_to_A_New(); var tmp3 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_go_build_assign_to_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_738, false, nil); A_arbace_go_build_assign_to_A_fn_class = fncls__155d; tmp3 = fncls__155d } else { tmp3 = fncls__155 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__156, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_168; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_169)); return A_arbace_go_build__init_part1_A_const_168 }











func A_arbace_go_build__init_part1_A_Unit186__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1700, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_170; var tmp2 *lang.Compiler_AOTFn; var fnbody__158 any = A_arbace_go_build_temps_of_A_New(); var tmp3 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_go_build_temps_of_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_739, false, nil); A_arbace_go_build_temps_of_A_fn_class = fncls__157d; tmp3 = fncls__157d } else { tmp3 = fncls__157 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__158, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_170; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_171)); return A_arbace_go_build__init_part1_A_const_170 }






func A_arbace_go_build__init_part1_A_Unit187__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1707, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_172; var tmp2 *lang.Compiler_AOTFn; var fnbody__160 any = A_arbace_go_build_rhs_nodes_A_New(); var tmp3 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_go_build_rhs_nodes_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_740, false, nil); A_arbace_go_build_rhs_nodes_A_fn_class = fncls__159d; tmp3 = fncls__159d } else { tmp3 = fncls__159 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__160, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_172; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_173)); return A_arbace_go_build__init_part1_A_const_172 }


































func A_arbace_go_build__init_part1_A_Unit188__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1742, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_174; var tmp2 *lang.Compiler_AOTFn; var fnbody__162 any = A_arbace_go_build_prepare_place_A_New(); var tmp3 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_go_build_prepare_place_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_741, false, nil); A_arbace_go_build_prepare_place_A_fn_class = fncls__161d; tmp3 = fncls__161d } else { tmp3 = fncls__161 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_174; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_175)); return A_arbace_go_build__init_part1_A_const_174 }




































func A_arbace_go_build__init_part1_A_Unit189__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1779, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_176; var tmp2 *lang.Compiler_AOTFn; var fnbody__164 any = A_arbace_go_build_assign_stmt_A_New(); var tmp3 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_go_build_assign_stmt_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_742, false, nil); A_arbace_go_build_assign_stmt_A_fn_class = fncls__163d; tmp3 = fncls__163d } else { tmp3 = fncls__163 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__164, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_176; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_177)); return A_arbace_go_build__init_part1_A_const_176 }








func A_arbace_go_build__init_part1_A_Unit190__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1788, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_178; var tmp2 *lang.Compiler_AOTFn; var fnbody__166 any = A_arbace_go_build_op_assign_stmt_A_New(); var tmp3 *jrt.Class; var fncls__165 *jrt.Class = A_arbace_go_build_op_assign_stmt_A_fn_class; if fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_743, false, nil); A_arbace_go_build_op_assign_stmt_A_fn_class = fncls__165d; tmp3 = fncls__165d } else { tmp3 = fncls__165 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__166, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_178; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_179)); return A_arbace_go_build__init_part1_A_const_178 }





























func A_arbace_go_build__init_part1_A_Unit191__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1818, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_180; var tmp2 *lang.Compiler_AOTFn; var fnbody__168 any = A_arbace_go_build_one_of_A_New(); var tmp3 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_go_build_one_of_A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_744, false, nil); A_arbace_go_build_one_of_A_fn_class = fncls__167d; tmp3 = fncls__167d } else { tmp3 = fncls__167 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__168, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_180; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_181)); return A_arbace_go_build__init_part1_A_const_180 }





func A_arbace_go_build__init_part1_A_Unit192__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1824, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_182; var tmp2 *lang.Compiler_AOTFn; var fnbody__170 any = A_arbace_go_build_incdec_stmt_A_New(); var tmp3 *jrt.Class; var fncls__169 *jrt.Class = A_arbace_go_build_incdec_stmt_A_fn_class; if fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_745, false, nil); A_arbace_go_build_incdec_stmt_A_fn_class = fncls__169d; tmp3 = fncls__169d } else { tmp3 = fncls__169 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__170, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_182; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_183)); return A_arbace_go_build__init_part1_A_const_182 }






func A_arbace_go_build__init_part1_A_Unit193__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1831, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_184; var tmp2 *lang.Compiler_AOTFn; var fnbody__172 any = A_arbace_go_build_zero_init_A_New(); var tmp3 *jrt.Class; var fncls__171 *jrt.Class = A_arbace_go_build_zero_init_A_fn_class; if fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_746, false, nil); A_arbace_go_build_zero_init_A_fn_class = fncls__171d; tmp3 = fncls__171d } else { tmp3 = fncls__171 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__172, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_184; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_185)); return A_arbace_go_build__init_part1_A_const_184 }










func A_arbace_go_build__init_part1_A_Unit194__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1842, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_186; var tmp2 *lang.Compiler_AOTFn; var fnbody__174 any = A_arbace_go_build_init_var_A_New(); var tmp3 *jrt.Class; var fncls__173 *jrt.Class = A_arbace_go_build_init_var_A_fn_class; if fncls__173 == nil { var fncls__173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_747, false, nil); A_arbace_go_build_init_var_A_fn_class = fncls__173d; tmp3 = fncls__173d } else { tmp3 = fncls__173 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__174, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_186; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_187)); return A_arbace_go_build__init_part1_A_const_186 }








func A_arbace_go_build__init_part1_A_Unit195__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1851, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_188; var tmp2 *lang.Compiler_AOTFn; var fnbody__176 any = A_arbace_go_build_decl_stmt_A_New(); var tmp3 *jrt.Class; var fncls__175 *jrt.Class = A_arbace_go_build_decl_stmt_A_fn_class; if fncls__175 == nil { var fncls__175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_748, false, nil); A_arbace_go_build_decl_stmt_A_fn_class = fncls__175d; tmp3 = fncls__175d } else { tmp3 = fncls__175 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__176, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_188; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_189)); return A_arbace_go_build__init_part1_A_const_188 }





















func A_arbace_go_build__init_part1_A_Unit196__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1873, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_190; var tmp2 *lang.Compiler_AOTFn; var fnbody__178 any = A_arbace_go_build_jump_A_New(); var tmp3 *jrt.Class; var fncls__177 *jrt.Class = A_arbace_go_build_jump_A_fn_class; if fncls__177 == nil { var fncls__177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_749, false, nil); A_arbace_go_build_jump_A_fn_class = fncls__177d; tmp3 = fncls__177d } else { tmp3 = fncls__177 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__178, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_190; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_191)); return A_arbace_go_build__init_part1_A_const_190 }

func A_arbace_go_build__init_part1_A_Unit197__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1875, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_192; var tmp2 *lang.Compiler_AOTFn; var fnbody__180 any = A_arbace_go_build_push_target_A_New(); var tmp3 *jrt.Class; var fncls__179 *jrt.Class = A_arbace_go_build_push_target_A_fn_class; if fncls__179 == nil { var fncls__179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_750, false, nil); A_arbace_go_build_push_target_A_fn_class = fncls__179d; tmp3 = fncls__179d } else { tmp3 = fncls__179 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__180, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_192; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_193)); return A_arbace_go_build__init_part1_A_const_192 }

func A_arbace_go_build__init_part1_A_Unit198__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1877, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_194; var tmp2 *lang.Compiler_AOTFn; var fnbody__182 any = A_arbace_go_build_innermost_A_New(); var tmp3 *jrt.Class; var fncls__181 *jrt.Class = A_arbace_go_build_innermost_A_fn_class; if fncls__181 == nil { var fncls__181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_751, false, nil); A_arbace_go_build_innermost_A_fn_class = fncls__181d; tmp3 = fncls__181d } else { tmp3 = fncls__181 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__182, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_194; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_195)); return A_arbace_go_build__init_part1_A_const_194 }

func A_arbace_go_build__init_part1_A_Unit199__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1879, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_196; var tmp2 *lang.Compiler_AOTFn; var fnbody__184 any = A_arbace_go_build_block_stmts_A_New(); var tmp3 *jrt.Class; var fncls__183 *jrt.Class = A_arbace_go_build_block_stmts_A_fn_class; if fncls__183 == nil { var fncls__183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_752, false, nil); A_arbace_go_build_block_stmts_A_fn_class = fncls__183d; tmp3 = fncls__183d } else { tmp3 = fncls__183 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__184, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_196; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_197)); return A_arbace_go_build__init_part1_A_const_196 }

func A_arbace_go_build__init_part2_A_Unit200__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1881, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_go_build_stmt_line_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_build_stmt_line_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_754, false, nil); A_arbace_go_build_stmt_line_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_1)); return A_arbace_go_build__init_part2_A_const_0 }
//line :1881:1
func A_arbace_go_build__init_part2_A_Init__O() any { A_arbace_go_build__init_part2_A_Init(); return nil }
//line :1881:1
func A_arbace_go_build__init_part2_A_Load__O() any { A_arbace_go_build__init_part2_A_Init(); A_arbace_go_build__init_part2_A_Unit200__O(); A_arbace_go_build__init_part2_A_Unit201__O(); A_arbace_go_build__init_part2_A_Unit202__O(); A_arbace_go_build__init_part2_A_Unit203__O(); A_arbace_go_build__init_part2_A_Unit204__O(); A_arbace_go_build__init_part2_A_Unit205__O(); A_arbace_go_build__init_part2_A_Unit206__O(); A_arbace_go_build__init_part2_A_Unit207__O(); A_arbace_go_build__init_part2_A_Unit208__O(); A_arbace_go_build__init_part2_A_Unit209__O(); A_arbace_go_build__init_part2_A_Unit210__O(); A_arbace_go_build__init_part2_A_Unit211__O(); A_arbace_go_build__init_part2_A_Unit212__O(); A_arbace_go_build__init_part2_A_Unit213__O(); A_arbace_go_build__init_part2_A_Unit214__O(); A_arbace_go_build__init_part2_A_Unit215__O(); A_arbace_go_build__init_part2_A_Unit216__O(); A_arbace_go_build__init_part2_A_Unit217__O(); A_arbace_go_build__init_part2_A_Unit218__O(); A_arbace_go_build__init_part2_A_Unit219__O(); A_arbace_go_build__init_part2_A_Unit220__O(); A_arbace_go_build__init_part2_A_Unit221__O(); A_arbace_go_build__init_part2_A_Unit222__O(); A_arbace_go_build__init_part2_A_Unit223__O(); A_arbace_go_build__init_part2_A_Unit224__O(); A_arbace_go_build__init_part2_A_Unit225__O(); A_arbace_go_build__init_part2_A_Unit226__O(); A_arbace_go_build__init_part2_A_Unit227__O(); A_arbace_go_build__init_part2_A_Unit228__O(); A_arbace_go_build__init_part2_A_Unit229__O(); A_arbace_go_build__init_part2_A_Unit230__O(); A_arbace_go_build__init_part2_A_Unit231__O(); A_arbace_go_build__init_part2_A_Unit232__O(); A_arbace_go_build__init_part2_A_Unit233__O(); A_arbace_go_build__init_part2_A_Unit234__O(); A_arbace_go_build__init_part2_A_Unit235__O(); A_arbace_go_build__init_part2_A_Unit236__O(); A_arbace_go_build__init_part2_A_Unit237__O(); A_arbace_go_build__init_part2_A_Unit238__O(); A_arbace_go_build__init_part2_A_Unit239__O(); A_arbace_go_build__init_part2_A_Unit240__O(); A_arbace_go_build__init_part2_A_Unit241__O(); A_arbace_go_build__init_part2_A_Unit242__O(); A_arbace_go_build__init_part2_A_Unit243__O(); A_arbace_go_build__init_part2_A_Unit244__O(); A_arbace_go_build__init_part2_A_Unit245__O(); A_arbace_go_build__init_part2_A_Unit246__O(); A_arbace_go_build__init_part2_A_Unit247__O(); A_arbace_go_build__init_part2_A_Unit248__O(); A_arbace_go_build__init_part2_A_Unit249__O(); A_arbace_go_build__init_part2_A_Unit250__O(); A_arbace_go_build__init_part2_A_Unit251__O(); A_arbace_go_build__init_part2_A_Unit252__O(); A_arbace_go_build__init_part2_A_Unit253__O(); A_arbace_go_build__init_part2_A_Unit254__O(); A_arbace_go_build__init_part2_A_Unit255__O(); A_arbace_go_build__init_part2_A_Unit256__O(); A_arbace_go_build__init_part2_A_Unit257__O(); A_arbace_go_build__init_part2_A_Unit258__O(); A_arbace_go_build__init_part2_A_Unit259__O(); A_arbace_go_build__init_part2_A_Unit260__O(); A_arbace_go_build__init_part2_A_Unit261__O(); A_arbace_go_build__init_part2_A_Unit262__O(); A_arbace_go_build__init_part2_A_Unit263__O(); return nil }














func A_arbace_go_build__init_part2_A_Unit201__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1896, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_3)); return A_arbace_go_build__init_part2_A_const_2 }

func A_arbace_go_build__init_part2_A_Unit202__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1898, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_go_build_quiet_basic_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_build_quiet_basic_QMARK__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_755, false, nil); A_arbace_go_build_quiet_basic_QMARK__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_5)); return A_arbace_go_build__init_part2_A_const_4 }

func A_arbace_go_build__init_part2_A_Unit203__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1900, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_go_build_quiet_const_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_build_quiet_const_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_756, false, nil); A_arbace_go_build_quiet_const_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_7)); return A_arbace_go_build__init_part2_A_const_6 }

func A_arbace_go_build__init_part2_A_Unit204__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1902, 1); A_arbace_go_build__init_part2_A_const_8.BindRoot_O__V(A_arbace_go_build__init_part2_A_const_9); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_10)); return A_arbace_go_build__init_part2_A_const_8 }

func A_arbace_go_build__init_part2_A_Unit205__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1904, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_go_build_quiet_cmp_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_build_quiet_cmp_type_QMARK__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_757, false, nil); A_arbace_go_build_quiet_cmp_type_QMARK__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_12)); return A_arbace_go_build__init_part2_A_const_11 }



func A_arbace_go_build__init_part2_A_Unit206__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1908, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_go_build_quiet_expr_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_build_quiet_expr_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_758, false, nil); A_arbace_go_build_quiet_expr_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_14)); return A_arbace_go_build__init_part2_A_const_13 }











































func A_arbace_go_build__init_part2_A_Unit207__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1952, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_go_build_quiet_place_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_build_quiet_place_QMARK__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_759, false, nil); A_arbace_go_build_quiet_place_QMARK__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_16)); return A_arbace_go_build__init_part2_A_const_15 }












func A_arbace_go_build__init_part2_A_Unit208__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1965, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_go_build_quiet_block_header_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_build_quiet_block_header_QMARK__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_760, false, nil); A_arbace_go_build_quiet_block_header_QMARK__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_18)); return A_arbace_go_build__init_part2_A_const_17 }




func A_arbace_go_build__init_part2_A_Unit209__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1970, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_build_quiet_header_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_build_quiet_header_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_761, false, nil); A_arbace_go_build_quiet_header_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_19)); return A_arbace_go_build__init_part2_A_const_2 }






































func A_arbace_go_build__init_part2_A_Unit210__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2009, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_go_build_hoisted_line_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_build_hoisted_line_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_762, false, nil); A_arbace_go_build_hoisted_line_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_21)); return A_arbace_go_build__init_part2_A_const_20 }














func A_arbace_go_build__init_part2_A_Unit211__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2024, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_go_build_stored_line_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_build_stored_line_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_763, false, nil); A_arbace_go_build_stored_line_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_23)); return A_arbace_go_build__init_part2_A_const_22 }








func A_arbace_go_build__init_part2_A_Unit212__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2033, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_build_loop_body_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_build_loop_body_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_764, false, nil); A_arbace_go_build_loop_body_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_25)); return A_arbace_go_build__init_part2_A_const_24 }







func A_arbace_go_build__init_part2_A_Unit213__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2041, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_go_build_body_node_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_build_body_node_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_765, false, nil); A_arbace_go_build_body_node_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_27)); return A_arbace_go_build__init_part2_A_const_26 }
















func A_arbace_go_build__init_part2_A_Unit214__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2058, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_go_build_stmt_list_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_build_stmt_list_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_766, false, nil); A_arbace_go_build_stmt_list_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_29)); return A_arbace_go_build__init_part2_A_const_28 }

func A_arbace_go_build__init_part2_A_Unit215__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2060, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_go_build_block_node_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_build_block_node_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_767, false, nil); A_arbace_go_build_block_node_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_31)); return A_arbace_go_build__init_part2_A_const_30 }












func A_arbace_go_build__init_part2_A_Unit216__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2073, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_go_build_loop_target_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_build_loop_target_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_768, false, nil); A_arbace_go_build_loop_target_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_33)); return A_arbace_go_build__init_part2_A_const_32 }






func A_arbace_go_build__init_part2_A_Unit217__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2080, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_go_build_per_iteration_cells_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_build_per_iteration_cells_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_769, false, nil); A_arbace_go_build_per_iteration_cells_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_35)); return A_arbace_go_build__init_part2_A_const_34 }




func A_arbace_go_build__init_part2_A_Unit218__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2085, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_go_build_for_stmt_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_build_for_stmt_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_770, false, nil); A_arbace_go_build_for_stmt_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_37)); return A_arbace_go_build__init_part2_A_const_36 }









func A_arbace_go_build__init_part2_A_Unit219__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2095, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_go_build_range_targets_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_build_range_targets_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_771, false, nil); A_arbace_go_build_range_targets_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_39)); return A_arbace_go_build__init_part2_A_const_38 }






func A_arbace_go_build__init_part2_A_Unit220__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2102, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_go_build_idx_setter_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_build_idx_setter_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_772, false, nil); A_arbace_go_build_idx_setter_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_41)); return A_arbace_go_build__init_part2_A_const_40 }










func A_arbace_go_build__init_part2_A_Unit221__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2113, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_go_build_at_setter_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_build_at_setter_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_773, false, nil); A_arbace_go_build_at_setter_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_43)); return A_arbace_go_build__init_part2_A_const_42 }










func A_arbace_go_build__init_part2_A_Unit222__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2124, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_go_build_any_setter_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_build_any_setter_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_774, false, nil); A_arbace_go_build_any_setter_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_45)); return A_arbace_go_build__init_part2_A_const_44 }










func A_arbace_go_build__init_part2_A_Unit223__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2135, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_go_build_has_call_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_build_has_call_QMARK__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_775, false, nil); A_arbace_go_build_has_call_QMARK__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_47)); return A_arbace_go_build__init_part2_A_const_46 }










func A_arbace_go_build__init_part2_A_Unit224__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2146, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_go_build_range_elem_types_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_build_range_elem_types_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_776, false, nil); A_arbace_go_build_range_elem_types_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_49)); return A_arbace_go_build__init_part2_A_const_48 }














func A_arbace_go_build__init_part2_A_Unit225__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2161, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_go_build_range_stmt_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_build_range_stmt_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_777, false, nil); A_arbace_go_build_range_stmt_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_51)); return A_arbace_go_build__init_part2_A_const_50 }















































































func A_arbace_go_build__init_part2_A_Unit226__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2241, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_go_build_switch_stmt_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_build_switch_stmt_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_778, false, nil); A_arbace_go_build_switch_stmt_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_53)); return A_arbace_go_build__init_part2_A_const_52 }

























func A_arbace_go_build__init_part2_A_Unit227__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2267, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_go_build_return_stmt_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_build_return_stmt_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_779, false, nil); A_arbace_go_build_return_stmt_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_55)); return A_arbace_go_build__init_part2_A_const_54 }















func A_arbace_go_build__init_part2_A_Unit228__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2283, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_go_build_deferred_call_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_build_deferred_call_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_780, false, nil); A_arbace_go_build_deferred_call_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_57)); return A_arbace_go_build__init_part2_A_const_56 }









































func A_arbace_go_build__init_part2_A_Unit229__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2325, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_go_build_defer_stmt_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_build_defer_stmt_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_781, false, nil); A_arbace_go_build_defer_stmt_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_59)); return A_arbace_go_build__init_part2_A_const_58 }




func A_arbace_go_build__init_part2_A_Unit230__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2330, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_go_build_go_stmt_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_build_go_stmt_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_782, false, nil); A_arbace_go_build_go_stmt_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_61)); return A_arbace_go_build__init_part2_A_const_60 }



func A_arbace_go_build__init_part2_A_Unit231__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2334, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_go_build_send_stmt_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_build_send_stmt_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_783, false, nil); A_arbace_go_build_send_stmt_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_63)); return A_arbace_go_build__init_part2_A_const_62 }



func A_arbace_go_build__init_part2_A_Unit232__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2338, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_go_build_type_switch_stmt_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_build_type_switch_stmt_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_784, false, nil); A_arbace_go_build_type_switch_stmt_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_65)); return A_arbace_go_build__init_part2_A_const_64 }


























func A_arbace_go_build__init_part2_A_Unit233__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2365, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_go_build_select_recv_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_build_select_recv_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_785, false, nil); A_arbace_go_build_select_recv_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_67)); return A_arbace_go_build__init_part2_A_const_66 }























func A_arbace_go_build__init_part2_A_Unit234__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2389, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_go_build_select_stmt_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_go_build_select_stmt_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_786, false, nil); A_arbace_go_build_select_stmt_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_69)); return A_arbace_go_build__init_part2_A_const_68 }




















func A_arbace_go_build__init_part2_A_Unit235__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2410, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_go_build_stmt_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_build_stmt_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_787, false, nil); A_arbace_go_build_stmt_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_71)); return A_arbace_go_build__init_part2_A_const_70 }









































func A_arbace_go_build__init_part2_A_Unit236__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2452, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_go_build_has_defer_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_go_build_has_defer_QMARK__A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_788, false, nil); A_arbace_go_build_has_defer_QMARK__A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_73)); return A_arbace_go_build__init_part2_A_const_72 }












func A_arbace_go_build__init_part2_A_Unit237__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2465, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_go_build_free_locals_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_go_build_free_locals_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_789, false, nil); A_arbace_go_build_free_locals_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_75)); return A_arbace_go_build__init_part2_A_const_74 }
































func A_arbace_go_build__init_part2_A_Unit238__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2498, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_go_build_build_code_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_go_build_build_code_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_790, false, nil); A_arbace_go_build_build_code_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_77)); return A_arbace_go_build__init_part2_A_const_76 }



















































func A_arbace_go_build__init_part2_A_Unit239__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2550, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_go_build_build_fn_lit_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_go_build_build_fn_lit_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_791, false, nil); A_arbace_go_build_build_fn_lit_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_79)); return A_arbace_go_build__init_part2_A_const_78 }










func A_arbace_go_build__init_part2_A_Unit240__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2561, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_go_build_build_func_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_build_build_func_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_792, false, nil); A_arbace_go_build_build_func_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_81)); return A_arbace_go_build__init_part2_A_const_80 }






func A_arbace_go_build__init_part2_A_Unit241__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2568, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_go_build_build_inits_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_go_build_build_inits_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_793, false, nil); A_arbace_go_build_build_inits_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_83)); return A_arbace_go_build__init_part2_A_const_82 }
















func A_arbace_go_build__init_part2_A_Unit242__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2585, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_go_build_isubst_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_go_build_isubst_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_794, false, nil); A_arbace_go_build_isubst_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_85)); return A_arbace_go_build__init_part2_A_const_84 }































func A_arbace_go_build__init_part2_A_Unit243__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2617, 1); A_arbace_go_build__init_part2_A_const_86.BindRoot_O__V(A_arbace_go_build__init_part2_A_const_87); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_86; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_88)); return A_arbace_go_build__init_part2_A_const_86 }
func A_arbace_go_build__init_part2_A_Unit244__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2618, 1); A_arbace_go_build__init_part2_A_const_89.BindRoot_O__V(A_arbace_go_build__init_part2_A_const_90); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_89; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_91)); return A_arbace_go_build__init_part2_A_const_89 }
func A_arbace_go_build__init_part2_A_Unit245__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2619, 1); A_arbace_go_build__init_part2_A_const_92.BindRoot_O__V(A_arbace_go_build__init_part2_A_const_93); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_92; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_94)); return A_arbace_go_build__init_part2_A_const_92 }
func A_arbace_go_build__init_part2_A_Unit246__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2620, 1); A_arbace_go_build__init_part2_A_const_95.BindRoot_O__V(A_arbace_go_build__init_part2_A_const_96); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_95; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_97)); return A_arbace_go_build__init_part2_A_const_95 }

func A_arbace_go_build__init_part2_A_Unit247__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2622, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_go_build_local_types_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_go_build_local_types_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_795, false, nil); A_arbace_go_build_local_types_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_99)); return A_arbace_go_build__init_part2_A_const_98 }












func A_arbace_go_build__init_part2_A_Unit248__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2635, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_100; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_go_build_resolve_on_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_go_build_resolve_on_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_796, false, nil); A_arbace_go_build_resolve_on_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_101)); return A_arbace_go_build__init_part2_A_const_100 }

















func A_arbace_go_build__init_part2_A_Unit249__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2653, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_102; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_go_build_inst_tree_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_go_build_inst_tree_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_797, false, nil); A_arbace_go_build_inst_tree_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_103)); return A_arbace_go_build__init_part2_A_const_102 }















































































func A_arbace_go_build__init_part2_A_Unit250__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2733, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_104; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_105)); v__1927001498__auto____1 = A_arbace_go_build__init_part2_A_const_104; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_build__init_part2_A_const_104; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_106)); var tmp3 *lang.Var = A_arbace_go_build__init_part2_A_const_104; tmp3.BindRoot_O__V(jrt.ConcurrentHashMap_New()); return A_arbace_go_build__init_part2_A_const_104 } }


func A_arbace_go_build__init_part2_A_Unit251__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2736, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_107; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_108)); v__1927001498__auto____1 = A_arbace_go_build__init_part2_A_const_107; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_go_build__init_part2_A_const_107; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_109)); var tmp3 *lang.Var = A_arbace_go_build__init_part2_A_const_107; tmp3.BindRoot_O__V(jrt.ConcurrentHashMap_New()); return A_arbace_go_build__init_part2_A_const_107 } }

func A_arbace_go_build__init_part2_A_Unit252__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2738, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_110; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_111)); return A_arbace_go_build__init_part2_A_const_110 }

func A_arbace_go_build__init_part2_A_Unit253__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2740, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_112; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_113)); return A_arbace_go_build__init_part2_A_const_112 }

func A_arbace_go_build__init_part2_A_Unit254__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2742, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_go_build_rt_name_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_go_build_rt_name_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_798, false, nil); A_arbace_go_build_rt_name_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_115)); return A_arbace_go_build__init_part2_A_const_114 }

































func A_arbace_go_build__init_part2_A_Unit255__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2776, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_110; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_go_build_rt_sig_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_go_build_rt_sig_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_799, false, nil); A_arbace_go_build_rt_sig_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_116)); return A_arbace_go_build__init_part2_A_const_110 }








func A_arbace_go_build__init_part2_A_Unit256__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2785, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_112; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_go_build_sym_name_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_go_build_sym_name_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_800, false, nil); A_arbace_go_build_sym_name_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_117)); return A_arbace_go_build__init_part2_A_const_112 }














func A_arbace_go_build__init_part2_A_Unit257__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2800, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_118; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_go_build_inst_type_name_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_go_build_inst_type_name_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_801, false, nil); A_arbace_go_build_inst_type_name_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_119)); return A_arbace_go_build__init_part2_A_const_118 }






func A_arbace_go_build__init_part2_A_Unit258__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2807, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_120; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_go_build_inst_gen_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_go_build_inst_gen_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_802, false, nil); A_arbace_go_build_inst_gen_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_121)); return A_arbace_go_build__init_part2_A_const_120 }












func A_arbace_go_build__init_part2_A_Unit259__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2820, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_122; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_go_build_instance_name_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_go_build_instance_name_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_803, false, nil); A_arbace_go_build_instance_name_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_123)); return A_arbace_go_build__init_part2_A_const_122 }









func A_arbace_go_build__init_part2_A_Unit260__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2830, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_124; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_go_build_build_instance_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_go_build_build_instance_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_804, false, nil); A_arbace_go_build_build_instance_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_125)); return A_arbace_go_build__init_part2_A_const_124 }













func A_arbace_go_build__init_part2_A_Unit261__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2844, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_126; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_127)); return A_arbace_go_build__init_part2_A_const_126 }

func A_arbace_go_build__init_part2_A_Unit262__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2846, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_128; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_go_build_instance_cell_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_go_build_instance_cell_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_805, false, nil); A_arbace_go_build_instance_cell_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_129)); return A_arbace_go_build__init_part2_A_const_128 }











func A_arbace_go_build__init_part2_A_Unit263__O() any { A_arbace_go_build__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2858, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part2_A_const_126; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_go_build_instance_cell_STAR__A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_go_build_instance_cell_STAR__A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_806, false, nil); A_arbace_go_build_instance_cell_STAR__A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_build__init_part2_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part2_A_const_130)); return A_arbace_go_build__init_part2_A_const_126 }



type A_arbace_go_build__init_A struct{ jrt.Object }

func A_arbace_go_build__init_A_New() *A_arbace_go_build__init_A { t := &A_arbace_go_build__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_build__init_A) Ctor() {}

func (t *A_arbace_go_build__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_build__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_build__init_A_class }

func (t *A_arbace_go_build__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_build__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_build__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_build__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_build__init_A); return ok }

func A_arbace_go_build__init_A_Cast(x any) *A_arbace_go_build__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_build__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_build__init_A_class)) }; return v }



type A_arbace_go_build__init_part0_A struct{ jrt.Object }

var A_arbace_go_build__init_part0_A_const_pool *jrt.RefArray

var A_arbace_go_build__init_part0_A_const_0 *lang.Var

var A_arbace_go_build__init_part0_A_const_1 any

var A_arbace_go_build__init_part0_A_const_2 any

var A_arbace_go_build__init_part0_A_const_3 any

var A_arbace_go_build__init_part0_A_const_4 *lang.Var

var A_arbace_go_build__init_part0_A_const_5 any

var A_arbace_go_build__init_part0_A_const_6 *lang.Var

var A_arbace_go_build__init_part0_A_const_7 any

var A_arbace_go_build__init_part0_A_const_8 *lang.Var

var A_arbace_go_build__init_part0_A_const_9 any

var A_arbace_go_build__init_part0_A_const_10 *lang.Var

var A_arbace_go_build__init_part0_A_const_11 any

var A_arbace_go_build__init_part0_A_const_12 *lang.Var

var A_arbace_go_build__init_part0_A_const_13 any

var A_arbace_go_build__init_part0_A_const_14 *lang.Var

var A_arbace_go_build__init_part0_A_const_15 any

var A_arbace_go_build__init_part0_A_const_16 *lang.Var

var A_arbace_go_build__init_part0_A_const_17 any

var A_arbace_go_build__init_part0_A_const_18 *lang.Var

var A_arbace_go_build__init_part0_A_const_19 any

var A_arbace_go_build__init_part0_A_const_20 any

var A_arbace_go_build__init_part0_A_const_21 any

var A_arbace_go_build__init_part0_A_const_22 *lang.Var

var A_arbace_go_build__init_part0_A_const_23 any

var A_arbace_go_build__init_part0_A_const_24 *lang.Var

var A_arbace_go_build__init_part0_A_const_25 any

var A_arbace_go_build__init_part0_A_const_26 *lang.Var

var A_arbace_go_build__init_part0_A_const_27 any

var A_arbace_go_build__init_part0_A_const_28 *lang.Var

var A_arbace_go_build__init_part0_A_const_29 any

var A_arbace_go_build__init_part0_A_const_30 *lang.Var

var A_arbace_go_build__init_part0_A_const_31 any

var A_arbace_go_build__init_part0_A_const_32 *lang.Var

var A_arbace_go_build__init_part0_A_const_33 any

var A_arbace_go_build__init_part0_A_const_34 *lang.Var

var A_arbace_go_build__init_part0_A_const_35 any

var A_arbace_go_build__init_part0_A_const_36 any

var A_arbace_go_build__init_part0_A_const_37 *lang.Var

var A_arbace_go_build__init_part0_A_const_38 any

var A_arbace_go_build__init_part0_A_const_39 *lang.Var

var A_arbace_go_build__init_part0_A_const_40 any

var A_arbace_go_build__init_part0_A_const_41 any

var A_arbace_go_build__init_part0_A_const_42 *lang.Var

var A_arbace_go_build__init_part0_A_const_43 any

var A_arbace_go_build__init_part0_A_const_44 *lang.Var

var A_arbace_go_build__init_part0_A_const_45 any

var A_arbace_go_build__init_part0_A_const_46 *lang.Var

var A_arbace_go_build__init_part0_A_const_47 any

var A_arbace_go_build__init_part0_A_const_48 *lang.Var

var A_arbace_go_build__init_part0_A_const_49 any

var A_arbace_go_build__init_part0_A_const_50 *lang.Var

var A_arbace_go_build__init_part0_A_const_51 any

var A_arbace_go_build__init_part0_A_const_52 *lang.Var

var A_arbace_go_build__init_part0_A_const_53 any

var A_arbace_go_build__init_part0_A_const_54 *lang.Var

var A_arbace_go_build__init_part0_A_const_55 any

var A_arbace_go_build__init_part0_A_const_56 *lang.Var

var A_arbace_go_build__init_part0_A_const_57 any

var A_arbace_go_build__init_part0_A_const_58 *lang.Var

var A_arbace_go_build__init_part0_A_const_59 any

var A_arbace_go_build__init_part0_A_const_60 *lang.Var

var A_arbace_go_build__init_part0_A_const_61 any

var A_arbace_go_build__init_part0_A_const_62 *lang.Var

var A_arbace_go_build__init_part0_A_const_63 any

var A_arbace_go_build__init_part0_A_const_64 *lang.Var

var A_arbace_go_build__init_part0_A_const_65 any

var A_arbace_go_build__init_part0_A_const_66 *lang.Var

var A_arbace_go_build__init_part0_A_const_67 any

var A_arbace_go_build__init_part0_A_const_68 *lang.Var

var A_arbace_go_build__init_part0_A_const_69 any

var A_arbace_go_build__init_part0_A_const_70 *lang.Var

var A_arbace_go_build__init_part0_A_const_71 any

var A_arbace_go_build__init_part0_A_const_72 *lang.Var

var A_arbace_go_build__init_part0_A_const_73 any

var A_arbace_go_build__init_part0_A_const_74 *lang.Var

var A_arbace_go_build__init_part0_A_const_75 any

var A_arbace_go_build__init_part0_A_const_76 any

var A_arbace_go_build__init_part0_A_const_77 *lang.Var

var A_arbace_go_build__init_part0_A_const_78 any

var A_arbace_go_build__init_part0_A_const_79 *lang.Var

var A_arbace_go_build__init_part0_A_const_80 any

var A_arbace_go_build__init_part0_A_const_81 *lang.Var

var A_arbace_go_build__init_part0_A_const_82 any

var A_arbace_go_build__init_part0_A_const_83 *lang.Var

var A_arbace_go_build__init_part0_A_const_84 any

var A_arbace_go_build__init_part0_A_const_85 *lang.Var

var A_arbace_go_build__init_part0_A_const_86 any

var A_arbace_go_build__init_part0_A_const_87 *lang.Var

var A_arbace_go_build__init_part0_A_const_88 any

var A_arbace_go_build__init_part0_A_const_89 *lang.Var

var A_arbace_go_build__init_part0_A_const_90 any

var A_arbace_go_build__init_part0_A_const_91 *lang.Var

var A_arbace_go_build__init_part0_A_const_92 any

var A_arbace_go_build__init_part0_A_const_93 any

var A_arbace_go_build__init_part0_A_const_94 *lang.Var

var A_arbace_go_build__init_part0_A_const_95 any

var A_arbace_go_build__init_part0_A_const_96 *lang.Var

var A_arbace_go_build__init_part0_A_const_97 any

var A_arbace_go_build__init_part0_A_const_98 any

var A_arbace_go_build__init_part0_A_const_99 *lang.Var

var A_arbace_go_build__init_part0_A_const_100 any

var A_arbace_go_build__init_part0_A_const_101 any

var A_arbace_go_build__init_part0_A_const_102 any

var A_arbace_go_build__init_part0_A_const_103 *lang.Var

var A_arbace_go_build__init_part0_A_const_104 any

var A_arbace_go_build__init_part0_A_const_105 *lang.Var

var A_arbace_go_build__init_part0_A_const_106 any

var A_arbace_go_build__init_part0_A_const_107 *lang.Var

var A_arbace_go_build__init_part0_A_const_108 any

var A_arbace_go_build__init_part0_A_const_109 *lang.Var

var A_arbace_go_build__init_part0_A_const_110 any

var A_arbace_go_build__init_part0_A_const_111 *lang.Var

var A_arbace_go_build__init_part0_A_const_112 any

var A_arbace_go_build__init_part0_A_const_113 *lang.Var

var A_arbace_go_build__init_part0_A_const_114 any

var A_arbace_go_build__init_part0_A_const_115 *lang.Var

var A_arbace_go_build__init_part0_A_const_116 any

var A_arbace_go_build__init_part0_A_const_117 *lang.Var

var A_arbace_go_build__init_part0_A_const_118 any

var A_arbace_go_build__init_part0_A_const_119 *lang.Var

var A_arbace_go_build__init_part0_A_const_120 any

var A_arbace_go_build__init_part0_A_const_121 *lang.Var

var A_arbace_go_build__init_part0_A_const_122 any

var A_arbace_go_build__init_part0_A_const_123 *lang.Var

var A_arbace_go_build__init_part0_A_const_124 any

var A_arbace_go_build__init_part0_A_const_125 *lang.Var

var A_arbace_go_build__init_part0_A_const_126 any

var A_arbace_go_build__init_part0_A_const_127 *lang.Var

var A_arbace_go_build__init_part0_A_const_128 any

var A_arbace_go_build__init_part0_A_const_129 *lang.Var

var A_arbace_go_build__init_part0_A_const_130 any

var A_arbace_go_build__init_part0_A_const_131 *lang.Var

var A_arbace_go_build__init_part0_A_const_132 any

var A_arbace_go_build__init_part0_A_const_133 *lang.Var

var A_arbace_go_build__init_part0_A_const_134 any

var A_arbace_go_build__init_part0_A_const_135 *lang.Var

var A_arbace_go_build__init_part0_A_const_136 any

var A_arbace_go_build__init_part0_A_const_137 *lang.Var

var A_arbace_go_build__init_part0_A_const_138 any

var A_arbace_go_build__init_part0_A_const_139 *lang.Var

var A_arbace_go_build__init_part0_A_const_140 any

var A_arbace_go_build__init_part0_A_const_141 *lang.Var

var A_arbace_go_build__init_part0_A_const_142 any

var A_arbace_go_build__init_part0_A_const_143 *lang.Var

var A_arbace_go_build__init_part0_A_const_144 any

var A_arbace_go_build__init_part0_A_const_145 *lang.Var

var A_arbace_go_build__init_part0_A_const_146 any

var A_arbace_go_build__init_part0_A_const_147 *lang.Var

var A_arbace_go_build__init_part0_A_const_148 any

var A_arbace_go_build__init_part0_A_const_149 *lang.Var

var A_arbace_go_build__init_part0_A_const_150 any

var A_arbace_go_build__init_part0_A_const_151 *lang.Var

var A_arbace_go_build__init_part0_A_const_152 any

var A_arbace_go_build__init_part0_A_const_153 *lang.Var

var A_arbace_go_build__init_part0_A_const_154 any

var A_arbace_go_build__init_part0_A_const_155 *lang.Var

var A_arbace_go_build__init_part0_A_const_156 any

var A_arbace_go_build__init_part0_A_const_157 *lang.Var

var A_arbace_go_build__init_part0_A_const_158 any

var A_arbace_go_build__init_part0_A_const_159 *lang.Var

var A_arbace_go_build__init_part0_A_const_160 any

var A_arbace_go_build__init_part0_A_const_161 *lang.Var

var A_arbace_go_build__init_part0_A_const_162 any

var A_arbace_go_build__init_part0_A_const_163 *lang.Var

var A_arbace_go_build__init_part0_A_const_164 any

var A_arbace_go_build__init_part0_A_const_165 *lang.Var

var A_arbace_go_build__init_part0_A_const_166 any

var A_arbace_go_build__init_part0_A_const_167 *lang.Var

var A_arbace_go_build__init_part0_A_const_168 any

var A_arbace_go_build__init_part0_A_const_169 *lang.Var

var A_arbace_go_build__init_part0_A_const_170 any

var A_arbace_go_build__init_part0_A_const_171 *lang.Var

var A_arbace_go_build__init_part0_A_const_172 any

var A_arbace_go_build__init_part0_A_const_173 *lang.Var

var A_arbace_go_build__init_part0_A_const_174 any

var A_arbace_go_build__init_part0_A_const_175 *lang.Var

var A_arbace_go_build__init_part0_A_const_176 any

var A_arbace_go_build__init_part0_A_const_177 *lang.Var

var A_arbace_go_build__init_part0_A_const_178 any

var A_arbace_go_build__init_part0_A_const_179 *lang.Var

var A_arbace_go_build__init_part0_A_const_180 any

var A_arbace_go_build__init_part0_A_const_181 *lang.Var

var A_arbace_go_build__init_part0_A_const_182 any

var A_arbace_go_build__init_part0_A_const_183 *lang.Var

var A_arbace_go_build__init_part0_A_const_184 any

var A_arbace_go_build__init_part0_A_const_185 any

var A_arbace_go_build__init_part0_A_const_186 *lang.Var

var A_arbace_go_build__init_part0_A_const_187 any

var A_arbace_go_build__init_part0_A_const_188 *lang.Var

var A_arbace_go_build__init_part0_A_const_189 any

var A_arbace_go_build__init_part0_A_const_190 *lang.Var

var A_arbace_go_build__init_part0_A_const_191 any

var A_arbace_go_build__init_part0_A_const_192 *lang.Var

var A_arbace_go_build__init_part0_A_const_193 any

var A_arbace_go_build__init_part0_A_const_194 *lang.Var

var A_arbace_go_build__init_part0_A_const_195 any

var A_arbace_go_build__init_part0_A_const_196 *lang.Var

var A_arbace_go_build__init_part0_A_const_197 any

var A_arbace_go_build__init_part0_A_const_198 *lang.Var

var A_arbace_go_build__init_part0_A_const_199 any

var A_arbace_go_build__init_part0_A_init jrt.ClassInit

func A_arbace_go_build__init_part0_A_Init() { if !A_arbace_go_build__init_part0_A_init.Done() { A_arbace_go_build__init_part0_A_init.Run(A_arbace_go_build__init_part0_A_clinit) } }

func A_arbace_go_build__init_part0_A_clinit() { A_arbace_go_build__init_part0_A_clinit_p0(); A_arbace_go_build__init_part0_A_clinit_p1(); A_arbace_go_build__init_part0_A_clinit_p2(); A_arbace_go_build__init_part0_A_clinit_p3(); A_arbace_go_build__init_part0_A_clinit_p4(); A_arbace_go_build__init_part0_A_clinit_p5(); A_arbace_go_build__init_part0_A_clinit_p6(); A_arbace_go_build__init_part0_A_clinit_p7(); A_arbace_go_build__init_part0_A_clinit_p8(); A_arbace_go_build__init_part0_A_clinit_p9(); A_arbace_go_build__init_part0_A_clinit_p10(); A_arbace_go_build__init_part0_A_clinit_p11(); A_arbace_go_build__init_part0_A_clinit_p12(); A_arbace_go_build__init_part0_A_clinit_p13(); A_arbace_go_build__init_part0_A_clinit_p14(); A_arbace_go_build__init_part0_A_clinit_p15() }

func A_arbace_go_build__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_build__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_598, 257); A_arbace_go_build__init_part0_A_const_0 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[57]); A_arbace_go_build__init_part0_A_const_1 = A_arbace_go_build__init_part0_A_const_pool.A[58]; A_arbace_go_build__init_part0_A_const_2 = A_arbace_go_build__init_part0_A_const_pool.A[59]; A_arbace_go_build__init_part0_A_const_3 = A_arbace_go_build__init_part0_A_const_pool.A[60]; A_arbace_go_build__init_part0_A_const_4 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[61]); A_arbace_go_build__init_part0_A_const_5 = A_arbace_go_build__init_part0_A_const_pool.A[62]; A_arbace_go_build__init_part0_A_const_6 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[63]); A_arbace_go_build__init_part0_A_const_7 = A_arbace_go_build__init_part0_A_const_pool.A[64]; A_arbace_go_build__init_part0_A_const_8 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[65]); A_arbace_go_build__init_part0_A_const_9 = A_arbace_go_build__init_part0_A_const_pool.A[66]; A_arbace_go_build__init_part0_A_const_10 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[67]); A_arbace_go_build__init_part0_A_const_11 = A_arbace_go_build__init_part0_A_const_pool.A[68]; A_arbace_go_build__init_part0_A_const_12 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[69]) }

func A_arbace_go_build__init_part0_A_clinit_p1() { A_arbace_go_build__init_part0_A_const_13 = A_arbace_go_build__init_part0_A_const_pool.A[70]; A_arbace_go_build__init_part0_A_const_14 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[71]); A_arbace_go_build__init_part0_A_const_15 = A_arbace_go_build__init_part0_A_const_pool.A[72]; A_arbace_go_build__init_part0_A_const_16 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[73]); A_arbace_go_build__init_part0_A_const_17 = A_arbace_go_build__init_part0_A_const_pool.A[74]; A_arbace_go_build__init_part0_A_const_18 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[75]); A_arbace_go_build__init_part0_A_const_19 = A_arbace_go_build__init_part0_A_const_pool.A[76]; A_arbace_go_build__init_part0_A_const_20 = A_arbace_go_build__init_part0_A_const_pool.A[77]; A_arbace_go_build__init_part0_A_const_21 = A_arbace_go_build__init_part0_A_const_pool.A[78]; A_arbace_go_build__init_part0_A_const_22 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[79]); A_arbace_go_build__init_part0_A_const_23 = A_arbace_go_build__init_part0_A_const_pool.A[80]; A_arbace_go_build__init_part0_A_const_24 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[81]); A_arbace_go_build__init_part0_A_const_25 = A_arbace_go_build__init_part0_A_const_pool.A[82]; A_arbace_go_build__init_part0_A_const_26 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[83]) }

func A_arbace_go_build__init_part0_A_clinit_p2() { A_arbace_go_build__init_part0_A_const_27 = A_arbace_go_build__init_part0_A_const_pool.A[84]; A_arbace_go_build__init_part0_A_const_28 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[85]); A_arbace_go_build__init_part0_A_const_29 = A_arbace_go_build__init_part0_A_const_pool.A[86]; A_arbace_go_build__init_part0_A_const_30 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[87]); A_arbace_go_build__init_part0_A_const_31 = A_arbace_go_build__init_part0_A_const_pool.A[88]; A_arbace_go_build__init_part0_A_const_32 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[89]); A_arbace_go_build__init_part0_A_const_33 = A_arbace_go_build__init_part0_A_const_pool.A[90]; A_arbace_go_build__init_part0_A_const_34 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[91]); A_arbace_go_build__init_part0_A_const_35 = A_arbace_go_build__init_part0_A_const_pool.A[92]; A_arbace_go_build__init_part0_A_const_36 = A_arbace_go_build__init_part0_A_const_pool.A[93]; A_arbace_go_build__init_part0_A_const_37 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[94]); A_arbace_go_build__init_part0_A_const_38 = A_arbace_go_build__init_part0_A_const_pool.A[95]; A_arbace_go_build__init_part0_A_const_39 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[96]); A_arbace_go_build__init_part0_A_const_40 = A_arbace_go_build__init_part0_A_const_pool.A[97] }

func A_arbace_go_build__init_part0_A_clinit_p3() { A_arbace_go_build__init_part0_A_const_41 = A_arbace_go_build__init_part0_A_const_pool.A[98]; A_arbace_go_build__init_part0_A_const_42 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[99]); A_arbace_go_build__init_part0_A_const_43 = A_arbace_go_build__init_part0_A_const_pool.A[100]; A_arbace_go_build__init_part0_A_const_44 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[101]); A_arbace_go_build__init_part0_A_const_45 = A_arbace_go_build__init_part0_A_const_pool.A[102]; A_arbace_go_build__init_part0_A_const_46 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[103]); A_arbace_go_build__init_part0_A_const_47 = A_arbace_go_build__init_part0_A_const_pool.A[104]; A_arbace_go_build__init_part0_A_const_48 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[105]); A_arbace_go_build__init_part0_A_const_49 = A_arbace_go_build__init_part0_A_const_pool.A[106]; A_arbace_go_build__init_part0_A_const_50 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[107]); A_arbace_go_build__init_part0_A_const_51 = A_arbace_go_build__init_part0_A_const_pool.A[108]; A_arbace_go_build__init_part0_A_const_52 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[109]); A_arbace_go_build__init_part0_A_const_53 = A_arbace_go_build__init_part0_A_const_pool.A[110] }

func A_arbace_go_build__init_part0_A_clinit_p4() { A_arbace_go_build__init_part0_A_const_54 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[111]); A_arbace_go_build__init_part0_A_const_55 = A_arbace_go_build__init_part0_A_const_pool.A[112]; A_arbace_go_build__init_part0_A_const_56 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[113]); A_arbace_go_build__init_part0_A_const_57 = A_arbace_go_build__init_part0_A_const_pool.A[114]; A_arbace_go_build__init_part0_A_const_58 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[115]); A_arbace_go_build__init_part0_A_const_59 = A_arbace_go_build__init_part0_A_const_pool.A[116]; A_arbace_go_build__init_part0_A_const_60 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[117]); A_arbace_go_build__init_part0_A_const_61 = A_arbace_go_build__init_part0_A_const_pool.A[118]; A_arbace_go_build__init_part0_A_const_62 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[119]); A_arbace_go_build__init_part0_A_const_63 = A_arbace_go_build__init_part0_A_const_pool.A[120]; A_arbace_go_build__init_part0_A_const_64 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[121]); A_arbace_go_build__init_part0_A_const_65 = A_arbace_go_build__init_part0_A_const_pool.A[122]; A_arbace_go_build__init_part0_A_const_66 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[123]) }

func A_arbace_go_build__init_part0_A_clinit_p5() { A_arbace_go_build__init_part0_A_const_67 = A_arbace_go_build__init_part0_A_const_pool.A[124]; A_arbace_go_build__init_part0_A_const_68 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[125]); A_arbace_go_build__init_part0_A_const_69 = A_arbace_go_build__init_part0_A_const_pool.A[126]; A_arbace_go_build__init_part0_A_const_70 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[127]); A_arbace_go_build__init_part0_A_const_71 = A_arbace_go_build__init_part0_A_const_pool.A[128]; A_arbace_go_build__init_part0_A_const_72 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[129]); A_arbace_go_build__init_part0_A_const_73 = A_arbace_go_build__init_part0_A_const_pool.A[130]; A_arbace_go_build__init_part0_A_const_74 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[131]); A_arbace_go_build__init_part0_A_const_75 = A_arbace_go_build__init_part0_A_const_pool.A[132]; A_arbace_go_build__init_part0_A_const_76 = A_arbace_go_build__init_part0_A_const_pool.A[133]; A_arbace_go_build__init_part0_A_const_77 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[134]); A_arbace_go_build__init_part0_A_const_78 = A_arbace_go_build__init_part0_A_const_pool.A[135]; A_arbace_go_build__init_part0_A_const_79 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[136]); A_arbace_go_build__init_part0_A_const_80 = A_arbace_go_build__init_part0_A_const_pool.A[137] }

func A_arbace_go_build__init_part0_A_clinit_p6() { A_arbace_go_build__init_part0_A_const_81 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[138]); A_arbace_go_build__init_part0_A_const_82 = A_arbace_go_build__init_part0_A_const_pool.A[139]; A_arbace_go_build__init_part0_A_const_83 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[140]); A_arbace_go_build__init_part0_A_const_84 = A_arbace_go_build__init_part0_A_const_pool.A[141]; A_arbace_go_build__init_part0_A_const_85 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[142]); A_arbace_go_build__init_part0_A_const_86 = A_arbace_go_build__init_part0_A_const_pool.A[143]; A_arbace_go_build__init_part0_A_const_87 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[144]); A_arbace_go_build__init_part0_A_const_88 = A_arbace_go_build__init_part0_A_const_pool.A[145]; A_arbace_go_build__init_part0_A_const_89 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[146]); A_arbace_go_build__init_part0_A_const_90 = A_arbace_go_build__init_part0_A_const_pool.A[147]; A_arbace_go_build__init_part0_A_const_91 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[148]); A_arbace_go_build__init_part0_A_const_92 = A_arbace_go_build__init_part0_A_const_pool.A[149]; A_arbace_go_build__init_part0_A_const_93 = A_arbace_go_build__init_part0_A_const_pool.A[150] }

func A_arbace_go_build__init_part0_A_clinit_p7() { A_arbace_go_build__init_part0_A_const_94 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[151]); A_arbace_go_build__init_part0_A_const_95 = A_arbace_go_build__init_part0_A_const_pool.A[152]; A_arbace_go_build__init_part0_A_const_96 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[153]); A_arbace_go_build__init_part0_A_const_97 = A_arbace_go_build__init_part0_A_const_pool.A[154]; A_arbace_go_build__init_part0_A_const_98 = A_arbace_go_build__init_part0_A_const_pool.A[155]; A_arbace_go_build__init_part0_A_const_99 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[156]); A_arbace_go_build__init_part0_A_const_100 = A_arbace_go_build__init_part0_A_const_pool.A[157]; A_arbace_go_build__init_part0_A_const_101 = A_arbace_go_build__init_part0_A_const_pool.A[158]; A_arbace_go_build__init_part0_A_const_102 = A_arbace_go_build__init_part0_A_const_pool.A[159]; A_arbace_go_build__init_part0_A_const_103 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[160]); A_arbace_go_build__init_part0_A_const_104 = A_arbace_go_build__init_part0_A_const_pool.A[161]; A_arbace_go_build__init_part0_A_const_105 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[162]); A_arbace_go_build__init_part0_A_const_106 = A_arbace_go_build__init_part0_A_const_pool.A[163]; A_arbace_go_build__init_part0_A_const_107 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[164]) }

func A_arbace_go_build__init_part0_A_clinit_p8() { A_arbace_go_build__init_part0_A_const_108 = A_arbace_go_build__init_part0_A_const_pool.A[165]; A_arbace_go_build__init_part0_A_const_109 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[166]); A_arbace_go_build__init_part0_A_const_110 = A_arbace_go_build__init_part0_A_const_pool.A[167]; A_arbace_go_build__init_part0_A_const_111 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[168]); A_arbace_go_build__init_part0_A_const_112 = A_arbace_go_build__init_part0_A_const_pool.A[169]; A_arbace_go_build__init_part0_A_const_113 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[170]); A_arbace_go_build__init_part0_A_const_114 = A_arbace_go_build__init_part0_A_const_pool.A[171]; A_arbace_go_build__init_part0_A_const_115 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[172]); A_arbace_go_build__init_part0_A_const_116 = A_arbace_go_build__init_part0_A_const_pool.A[173]; A_arbace_go_build__init_part0_A_const_117 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[174]); A_arbace_go_build__init_part0_A_const_118 = A_arbace_go_build__init_part0_A_const_pool.A[175]; A_arbace_go_build__init_part0_A_const_119 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[176]); A_arbace_go_build__init_part0_A_const_120 = A_arbace_go_build__init_part0_A_const_pool.A[177] }

func A_arbace_go_build__init_part0_A_clinit_p9() { A_arbace_go_build__init_part0_A_const_121 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[178]); A_arbace_go_build__init_part0_A_const_122 = A_arbace_go_build__init_part0_A_const_pool.A[179]; A_arbace_go_build__init_part0_A_const_123 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[180]); A_arbace_go_build__init_part0_A_const_124 = A_arbace_go_build__init_part0_A_const_pool.A[181]; A_arbace_go_build__init_part0_A_const_125 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[182]); A_arbace_go_build__init_part0_A_const_126 = A_arbace_go_build__init_part0_A_const_pool.A[183]; A_arbace_go_build__init_part0_A_const_127 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[184]); A_arbace_go_build__init_part0_A_const_128 = A_arbace_go_build__init_part0_A_const_pool.A[185]; A_arbace_go_build__init_part0_A_const_129 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[186]); A_arbace_go_build__init_part0_A_const_130 = A_arbace_go_build__init_part0_A_const_pool.A[187]; A_arbace_go_build__init_part0_A_const_131 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[188]); A_arbace_go_build__init_part0_A_const_132 = A_arbace_go_build__init_part0_A_const_pool.A[189]; A_arbace_go_build__init_part0_A_const_133 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[190]) }

func A_arbace_go_build__init_part0_A_clinit_p10() { A_arbace_go_build__init_part0_A_const_134 = A_arbace_go_build__init_part0_A_const_pool.A[191]; A_arbace_go_build__init_part0_A_const_135 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[192]); A_arbace_go_build__init_part0_A_const_136 = A_arbace_go_build__init_part0_A_const_pool.A[193]; A_arbace_go_build__init_part0_A_const_137 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[194]); A_arbace_go_build__init_part0_A_const_138 = A_arbace_go_build__init_part0_A_const_pool.A[195]; A_arbace_go_build__init_part0_A_const_139 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[196]); A_arbace_go_build__init_part0_A_const_140 = A_arbace_go_build__init_part0_A_const_pool.A[197]; A_arbace_go_build__init_part0_A_const_141 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[198]); A_arbace_go_build__init_part0_A_const_142 = A_arbace_go_build__init_part0_A_const_pool.A[199]; A_arbace_go_build__init_part0_A_const_143 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[200]); A_arbace_go_build__init_part0_A_const_144 = A_arbace_go_build__init_part0_A_const_pool.A[201]; A_arbace_go_build__init_part0_A_const_145 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[202]); A_arbace_go_build__init_part0_A_const_146 = A_arbace_go_build__init_part0_A_const_pool.A[203] }

func A_arbace_go_build__init_part0_A_clinit_p11() { A_arbace_go_build__init_part0_A_const_147 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[204]); A_arbace_go_build__init_part0_A_const_148 = A_arbace_go_build__init_part0_A_const_pool.A[205]; A_arbace_go_build__init_part0_A_const_149 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[206]); A_arbace_go_build__init_part0_A_const_150 = A_arbace_go_build__init_part0_A_const_pool.A[207]; A_arbace_go_build__init_part0_A_const_151 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[208]); A_arbace_go_build__init_part0_A_const_152 = A_arbace_go_build__init_part0_A_const_pool.A[209]; A_arbace_go_build__init_part0_A_const_153 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[210]); A_arbace_go_build__init_part0_A_const_154 = A_arbace_go_build__init_part0_A_const_pool.A[211]; A_arbace_go_build__init_part0_A_const_155 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[212]); A_arbace_go_build__init_part0_A_const_156 = A_arbace_go_build__init_part0_A_const_pool.A[213]; A_arbace_go_build__init_part0_A_const_157 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[214]); A_arbace_go_build__init_part0_A_const_158 = A_arbace_go_build__init_part0_A_const_pool.A[215]; A_arbace_go_build__init_part0_A_const_159 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[216]) }

func A_arbace_go_build__init_part0_A_clinit_p12() { A_arbace_go_build__init_part0_A_const_160 = A_arbace_go_build__init_part0_A_const_pool.A[217]; A_arbace_go_build__init_part0_A_const_161 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[218]); A_arbace_go_build__init_part0_A_const_162 = A_arbace_go_build__init_part0_A_const_pool.A[219]; A_arbace_go_build__init_part0_A_const_163 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[220]); A_arbace_go_build__init_part0_A_const_164 = A_arbace_go_build__init_part0_A_const_pool.A[221]; A_arbace_go_build__init_part0_A_const_165 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[222]); A_arbace_go_build__init_part0_A_const_166 = A_arbace_go_build__init_part0_A_const_pool.A[223]; A_arbace_go_build__init_part0_A_const_167 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[224]); A_arbace_go_build__init_part0_A_const_168 = A_arbace_go_build__init_part0_A_const_pool.A[225]; A_arbace_go_build__init_part0_A_const_169 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[226]); A_arbace_go_build__init_part0_A_const_170 = A_arbace_go_build__init_part0_A_const_pool.A[227]; A_arbace_go_build__init_part0_A_const_171 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[228]); A_arbace_go_build__init_part0_A_const_172 = A_arbace_go_build__init_part0_A_const_pool.A[229] }

func A_arbace_go_build__init_part0_A_clinit_p13() { A_arbace_go_build__init_part0_A_const_173 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[230]); A_arbace_go_build__init_part0_A_const_174 = A_arbace_go_build__init_part0_A_const_pool.A[231]; A_arbace_go_build__init_part0_A_const_175 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[232]); A_arbace_go_build__init_part0_A_const_176 = A_arbace_go_build__init_part0_A_const_pool.A[233]; A_arbace_go_build__init_part0_A_const_177 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[234]); A_arbace_go_build__init_part0_A_const_178 = A_arbace_go_build__init_part0_A_const_pool.A[235]; A_arbace_go_build__init_part0_A_const_179 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[236]); A_arbace_go_build__init_part0_A_const_180 = A_arbace_go_build__init_part0_A_const_pool.A[237]; A_arbace_go_build__init_part0_A_const_181 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[238]); A_arbace_go_build__init_part0_A_const_182 = A_arbace_go_build__init_part0_A_const_pool.A[239]; A_arbace_go_build__init_part0_A_const_183 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[240]); A_arbace_go_build__init_part0_A_const_184 = A_arbace_go_build__init_part0_A_const_pool.A[241]; A_arbace_go_build__init_part0_A_const_185 = A_arbace_go_build__init_part0_A_const_pool.A[242] }

func A_arbace_go_build__init_part0_A_clinit_p14() { A_arbace_go_build__init_part0_A_const_186 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[243]); A_arbace_go_build__init_part0_A_const_187 = A_arbace_go_build__init_part0_A_const_pool.A[244]; A_arbace_go_build__init_part0_A_const_188 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[245]); A_arbace_go_build__init_part0_A_const_189 = A_arbace_go_build__init_part0_A_const_pool.A[246]; A_arbace_go_build__init_part0_A_const_190 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[247]); A_arbace_go_build__init_part0_A_const_191 = A_arbace_go_build__init_part0_A_const_pool.A[248]; A_arbace_go_build__init_part0_A_const_192 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[249]); A_arbace_go_build__init_part0_A_const_193 = A_arbace_go_build__init_part0_A_const_pool.A[250]; A_arbace_go_build__init_part0_A_const_194 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[251]); A_arbace_go_build__init_part0_A_const_195 = A_arbace_go_build__init_part0_A_const_pool.A[252]; A_arbace_go_build__init_part0_A_const_196 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[253]); A_arbace_go_build__init_part0_A_const_197 = A_arbace_go_build__init_part0_A_const_pool.A[254]; A_arbace_go_build__init_part0_A_const_198 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[255]) }

func A_arbace_go_build__init_part0_A_clinit_p15() { A_arbace_go_build__init_part0_A_const_199 = A_arbace_go_build__init_part0_A_const_pool.A[256] }

func A_arbace_go_build__init_part0_A_New() *A_arbace_go_build__init_part0_A { A_arbace_go_build__init_part0_A_Init(); t := &A_arbace_go_build__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_go_build__init_part0_A) Ctor() {}

func (t *A_arbace_go_build__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_build__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_go_build__init_part0_A_class }

func (t *A_arbace_go_build__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_build__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_build__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_build__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_build__init_part0_A); return ok }

func A_arbace_go_build__init_part0_A_Cast(x any) *A_arbace_go_build__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_build__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_build__init_part0_A_class)) }; return v }



type A_arbace_go_build__init_part1_A struct{ jrt.Object }

var A_arbace_go_build__init_part1_A_const_pool *jrt.RefArray

var A_arbace_go_build__init_part1_A_const_0 *lang.Var

var A_arbace_go_build__init_part1_A_const_1 any

var A_arbace_go_build__init_part1_A_const_2 *lang.Var

var A_arbace_go_build__init_part1_A_const_3 any

var A_arbace_go_build__init_part1_A_const_4 *lang.Var

var A_arbace_go_build__init_part1_A_const_5 any

var A_arbace_go_build__init_part1_A_const_6 *lang.Var

var A_arbace_go_build__init_part1_A_const_7 any

var A_arbace_go_build__init_part1_A_const_8 *lang.Var

var A_arbace_go_build__init_part1_A_const_9 any

var A_arbace_go_build__init_part1_A_const_10 *lang.Var

var A_arbace_go_build__init_part1_A_const_11 any

var A_arbace_go_build__init_part1_A_const_12 *lang.Var

var A_arbace_go_build__init_part1_A_const_13 any

var A_arbace_go_build__init_part1_A_const_14 *lang.Var

var A_arbace_go_build__init_part1_A_const_15 any

var A_arbace_go_build__init_part1_A_const_16 *lang.Var

var A_arbace_go_build__init_part1_A_const_17 any

var A_arbace_go_build__init_part1_A_const_18 *lang.Var

var A_arbace_go_build__init_part1_A_const_19 any

var A_arbace_go_build__init_part1_A_const_20 *lang.Var

var A_arbace_go_build__init_part1_A_const_21 any

var A_arbace_go_build__init_part1_A_const_22 *lang.Var

var A_arbace_go_build__init_part1_A_const_23 any

var A_arbace_go_build__init_part1_A_const_24 *lang.Var

var A_arbace_go_build__init_part1_A_const_25 any

var A_arbace_go_build__init_part1_A_const_26 *lang.Var

var A_arbace_go_build__init_part1_A_const_27 any

var A_arbace_go_build__init_part1_A_const_28 *lang.Var

var A_arbace_go_build__init_part1_A_const_29 any

var A_arbace_go_build__init_part1_A_const_30 *lang.Var

var A_arbace_go_build__init_part1_A_const_31 any

var A_arbace_go_build__init_part1_A_const_32 *lang.Var

var A_arbace_go_build__init_part1_A_const_33 any

var A_arbace_go_build__init_part1_A_const_34 *lang.Var

var A_arbace_go_build__init_part1_A_const_35 any

var A_arbace_go_build__init_part1_A_const_36 *lang.Var

var A_arbace_go_build__init_part1_A_const_37 any

var A_arbace_go_build__init_part1_A_const_38 *lang.Var

var A_arbace_go_build__init_part1_A_const_39 any

var A_arbace_go_build__init_part1_A_const_40 *lang.Var

var A_arbace_go_build__init_part1_A_const_41 any

var A_arbace_go_build__init_part1_A_const_42 *lang.Var

var A_arbace_go_build__init_part1_A_const_43 any

var A_arbace_go_build__init_part1_A_const_44 *lang.Var

var A_arbace_go_build__init_part1_A_const_45 any

var A_arbace_go_build__init_part1_A_const_46 *lang.Var

var A_arbace_go_build__init_part1_A_const_47 any

var A_arbace_go_build__init_part1_A_const_48 *lang.Var

var A_arbace_go_build__init_part1_A_const_49 any

var A_arbace_go_build__init_part1_A_const_50 *lang.Var

var A_arbace_go_build__init_part1_A_const_51 any

var A_arbace_go_build__init_part1_A_const_52 any

var A_arbace_go_build__init_part1_A_const_53 *lang.Var

var A_arbace_go_build__init_part1_A_const_54 any

var A_arbace_go_build__init_part1_A_const_55 *lang.Var

var A_arbace_go_build__init_part1_A_const_56 any

var A_arbace_go_build__init_part1_A_const_57 *lang.Var

var A_arbace_go_build__init_part1_A_const_58 any

var A_arbace_go_build__init_part1_A_const_59 *lang.Var

var A_arbace_go_build__init_part1_A_const_60 any

var A_arbace_go_build__init_part1_A_const_61 *lang.Var

var A_arbace_go_build__init_part1_A_const_62 any

var A_arbace_go_build__init_part1_A_const_63 *lang.Var

var A_arbace_go_build__init_part1_A_const_64 any

var A_arbace_go_build__init_part1_A_const_65 *lang.Var

var A_arbace_go_build__init_part1_A_const_66 any

var A_arbace_go_build__init_part1_A_const_67 *lang.Var

var A_arbace_go_build__init_part1_A_const_68 any

var A_arbace_go_build__init_part1_A_const_69 *lang.Var

var A_arbace_go_build__init_part1_A_const_70 any

var A_arbace_go_build__init_part1_A_const_71 *lang.Var

var A_arbace_go_build__init_part1_A_const_72 any

var A_arbace_go_build__init_part1_A_const_73 *lang.Var

var A_arbace_go_build__init_part1_A_const_74 any

var A_arbace_go_build__init_part1_A_const_75 *lang.Var

var A_arbace_go_build__init_part1_A_const_76 any

var A_arbace_go_build__init_part1_A_const_77 *lang.Var

var A_arbace_go_build__init_part1_A_const_78 any

var A_arbace_go_build__init_part1_A_const_79 *lang.Var

var A_arbace_go_build__init_part1_A_const_80 any

var A_arbace_go_build__init_part1_A_const_81 *lang.Var

var A_arbace_go_build__init_part1_A_const_82 any

var A_arbace_go_build__init_part1_A_const_83 *lang.Var

var A_arbace_go_build__init_part1_A_const_84 any

var A_arbace_go_build__init_part1_A_const_85 *lang.Var

var A_arbace_go_build__init_part1_A_const_86 any

var A_arbace_go_build__init_part1_A_const_87 *lang.Var

var A_arbace_go_build__init_part1_A_const_88 any

var A_arbace_go_build__init_part1_A_const_89 *lang.Var

var A_arbace_go_build__init_part1_A_const_90 any

var A_arbace_go_build__init_part1_A_const_91 *lang.Var

var A_arbace_go_build__init_part1_A_const_92 any

var A_arbace_go_build__init_part1_A_const_93 *lang.Var

var A_arbace_go_build__init_part1_A_const_94 any

var A_arbace_go_build__init_part1_A_const_95 *lang.Var

var A_arbace_go_build__init_part1_A_const_96 any

var A_arbace_go_build__init_part1_A_const_97 *lang.Var

var A_arbace_go_build__init_part1_A_const_98 any

var A_arbace_go_build__init_part1_A_const_99 *lang.Var

var A_arbace_go_build__init_part1_A_const_100 any

var A_arbace_go_build__init_part1_A_const_101 *lang.Var

var A_arbace_go_build__init_part1_A_const_102 any

var A_arbace_go_build__init_part1_A_const_103 *lang.Var

var A_arbace_go_build__init_part1_A_const_104 any

var A_arbace_go_build__init_part1_A_const_105 *lang.Var

var A_arbace_go_build__init_part1_A_const_106 any

var A_arbace_go_build__init_part1_A_const_107 *lang.Var

var A_arbace_go_build__init_part1_A_const_108 any

var A_arbace_go_build__init_part1_A_const_109 any

var A_arbace_go_build__init_part1_A_const_110 any

var A_arbace_go_build__init_part1_A_const_111 *lang.Var

var A_arbace_go_build__init_part1_A_const_112 any

var A_arbace_go_build__init_part1_A_const_113 *lang.Var

var A_arbace_go_build__init_part1_A_const_114 any

var A_arbace_go_build__init_part1_A_const_115 *lang.Var

var A_arbace_go_build__init_part1_A_const_116 any

var A_arbace_go_build__init_part1_A_const_117 *lang.Var

var A_arbace_go_build__init_part1_A_const_118 any

var A_arbace_go_build__init_part1_A_const_119 *lang.Var

var A_arbace_go_build__init_part1_A_const_120 any

var A_arbace_go_build__init_part1_A_const_121 *lang.Var

var A_arbace_go_build__init_part1_A_const_122 any

var A_arbace_go_build__init_part1_A_const_123 *lang.Var

var A_arbace_go_build__init_part1_A_const_124 any

var A_arbace_go_build__init_part1_A_const_125 *lang.Var

var A_arbace_go_build__init_part1_A_const_126 any

var A_arbace_go_build__init_part1_A_const_127 *lang.Var

var A_arbace_go_build__init_part1_A_const_128 any

var A_arbace_go_build__init_part1_A_const_129 *lang.Var

var A_arbace_go_build__init_part1_A_const_130 any

var A_arbace_go_build__init_part1_A_const_131 *lang.Var

var A_arbace_go_build__init_part1_A_const_132 any

var A_arbace_go_build__init_part1_A_const_133 *lang.Var

var A_arbace_go_build__init_part1_A_const_134 any

var A_arbace_go_build__init_part1_A_const_135 *lang.Var

var A_arbace_go_build__init_part1_A_const_136 any

var A_arbace_go_build__init_part1_A_const_137 *lang.Var

var A_arbace_go_build__init_part1_A_const_138 any

var A_arbace_go_build__init_part1_A_const_139 any

var A_arbace_go_build__init_part1_A_const_140 *lang.Var

var A_arbace_go_build__init_part1_A_const_141 any

var A_arbace_go_build__init_part1_A_const_142 *lang.Var

var A_arbace_go_build__init_part1_A_const_143 any

var A_arbace_go_build__init_part1_A_const_144 *lang.Var

var A_arbace_go_build__init_part1_A_const_145 any

var A_arbace_go_build__init_part1_A_const_146 *lang.Var

var A_arbace_go_build__init_part1_A_const_147 any

var A_arbace_go_build__init_part1_A_const_148 *lang.Var

var A_arbace_go_build__init_part1_A_const_149 any

var A_arbace_go_build__init_part1_A_const_150 *lang.Var

var A_arbace_go_build__init_part1_A_const_151 any

var A_arbace_go_build__init_part1_A_const_152 *lang.Var

var A_arbace_go_build__init_part1_A_const_153 any

var A_arbace_go_build__init_part1_A_const_154 *lang.Var

var A_arbace_go_build__init_part1_A_const_155 any

var A_arbace_go_build__init_part1_A_const_156 *lang.Var

var A_arbace_go_build__init_part1_A_const_157 any

var A_arbace_go_build__init_part1_A_const_158 *lang.Var

var A_arbace_go_build__init_part1_A_const_159 any

var A_arbace_go_build__init_part1_A_const_160 *lang.Var

var A_arbace_go_build__init_part1_A_const_161 any

var A_arbace_go_build__init_part1_A_const_162 *lang.Var

var A_arbace_go_build__init_part1_A_const_163 any

var A_arbace_go_build__init_part1_A_const_164 *lang.Var

var A_arbace_go_build__init_part1_A_const_165 any

var A_arbace_go_build__init_part1_A_const_166 *lang.Var

var A_arbace_go_build__init_part1_A_const_167 any

var A_arbace_go_build__init_part1_A_const_168 *lang.Var

var A_arbace_go_build__init_part1_A_const_169 any

var A_arbace_go_build__init_part1_A_const_170 *lang.Var

var A_arbace_go_build__init_part1_A_const_171 any

var A_arbace_go_build__init_part1_A_const_172 *lang.Var

var A_arbace_go_build__init_part1_A_const_173 any

var A_arbace_go_build__init_part1_A_const_174 *lang.Var

var A_arbace_go_build__init_part1_A_const_175 any

var A_arbace_go_build__init_part1_A_const_176 *lang.Var

var A_arbace_go_build__init_part1_A_const_177 any

var A_arbace_go_build__init_part1_A_const_178 *lang.Var

var A_arbace_go_build__init_part1_A_const_179 any

var A_arbace_go_build__init_part1_A_const_180 *lang.Var

var A_arbace_go_build__init_part1_A_const_181 any

var A_arbace_go_build__init_part1_A_const_182 *lang.Var

var A_arbace_go_build__init_part1_A_const_183 any

var A_arbace_go_build__init_part1_A_const_184 *lang.Var

var A_arbace_go_build__init_part1_A_const_185 any

var A_arbace_go_build__init_part1_A_const_186 *lang.Var

var A_arbace_go_build__init_part1_A_const_187 any

var A_arbace_go_build__init_part1_A_const_188 *lang.Var

var A_arbace_go_build__init_part1_A_const_189 any

var A_arbace_go_build__init_part1_A_const_190 *lang.Var

var A_arbace_go_build__init_part1_A_const_191 any

var A_arbace_go_build__init_part1_A_const_192 *lang.Var

var A_arbace_go_build__init_part1_A_const_193 any

var A_arbace_go_build__init_part1_A_const_194 *lang.Var

var A_arbace_go_build__init_part1_A_const_195 any

var A_arbace_go_build__init_part1_A_const_196 *lang.Var

var A_arbace_go_build__init_part1_A_const_197 any

var A_arbace_go_build__init_part1_A_init jrt.ClassInit

func A_arbace_go_build__init_part1_A_Init() { if !A_arbace_go_build__init_part1_A_init.Done() { A_arbace_go_build__init_part1_A_init.Run(A_arbace_go_build__init_part1_A_clinit) } }

func A_arbace_go_build__init_part1_A_clinit() { A_arbace_go_build__init_part1_A_clinit_p0(); A_arbace_go_build__init_part1_A_clinit_p1(); A_arbace_go_build__init_part1_A_clinit_p2(); A_arbace_go_build__init_part1_A_clinit_p3() }

func A_arbace_go_build__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_build__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_660, 245); A_arbace_go_build__init_part1_A_const_0 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[65]); A_arbace_go_build__init_part1_A_const_1 = A_arbace_go_build__init_part1_A_const_pool.A[66]; A_arbace_go_build__init_part1_A_const_2 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[67]); A_arbace_go_build__init_part1_A_const_3 = A_arbace_go_build__init_part1_A_const_pool.A[68]; A_arbace_go_build__init_part1_A_const_4 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[69]); A_arbace_go_build__init_part1_A_const_5 = A_arbace_go_build__init_part1_A_const_pool.A[70]; A_arbace_go_build__init_part1_A_const_6 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[71]); A_arbace_go_build__init_part1_A_const_7 = A_arbace_go_build__init_part1_A_const_pool.A[72]; A_arbace_go_build__init_part1_A_const_8 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[73]); A_arbace_go_build__init_part1_A_const_9 = A_arbace_go_build__init_part1_A_const_pool.A[74]; A_arbace_go_build__init_part1_A_const_10 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[75]); A_arbace_go_build__init_part1_A_const_11 = A_arbace_go_build__init_part1_A_const_pool.A[76] }

func A_arbace_go_build__init_part1_A_clinit_p1() { A_arbace_go_build__init_part1_A_const_12 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[77]); A_arbace_go_build__init_part1_A_const_13 = A_arbace_go_build__init_part1_A_const_pool.A[78]; A_arbace_go_build__init_part1_A_const_14 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[79]); A_arbace_go_build__init_part1_A_const_15 = A_arbace_go_build__init_part1_A_const_pool.A[80]; A_arbace_go_build__init_part1_A_const_16 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[81]); A_arbace_go_build__init_part1_A_const_17 = A_arbace_go_build__init_part1_A_const_pool.A[82]; A_arbace_go_build__init_part1_A_const_18 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[83]); A_arbace_go_build__init_part1_A_const_19 = A_arbace_go_build__init_part1_A_const_pool.A[84]; A_arbace_go_build__init_part1_A_const_20 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[85]); A_arbace_go_build__init_part1_A_const_21 = A_arbace_go_build__init_part1_A_const_pool.A[86]; A_arbace_go_build__init_part1_A_const_22 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[87]); A_arbace_go_build__init_part1_A_const_23 = A_arbace_go_build__init_part1_A_const_pool.A[88]; A_arbace_go_build__init_part1_A_const_24 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[89]) }

func A_arbace_go_build__init_part1_A_clinit_p2() { A_arbace_go_build__init_part1_A_const_25 = A_arbace_go_build__init_part1_A_const_pool.A[90]; A_arbace_go_build__init_part1_A_const_26 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[91]); A_arbace_go_build__init_part1_A_const_27 = A_arbace_go_build__init_part1_A_const_pool.A[92] }

func A_arbace_go_build__init_part1_A_clinit_p3() { var tmp1 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp1 = A_arbace_go_build__init_part0_A_const_143; A_arbace_go_build__init_part1_A_const_28 = tmp1; A_arbace_go_build__init_part1_A_const_29 = A_arbace_go_build__init_part1_A_const_pool.A[93]; A_arbace_go_build__init_part1_A_const_30 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[94]); A_arbace_go_build__init_part1_A_const_31 = A_arbace_go_build__init_part1_A_const_pool.A[95]; var tmp2 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp2 = A_arbace_go_build__init_part0_A_const_145; A_arbace_go_build__init_part1_A_const_32 = tmp2; A_arbace_go_build__init_part1_A_const_33 = A_arbace_go_build__init_part1_A_const_pool.A[96]; var tmp3 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp3 = A_arbace_go_build__init_part0_A_const_147; A_arbace_go_build__init_part1_A_const_34 = tmp3; A_arbace_go_build__init_part1_A_const_35 = A_arbace_go_build__init_part1_A_const_pool.A[97]; A_arbace_go_build__init_part1_A_const_36 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[98]); A_arbace_go_build__init_part1_A_const_37 = A_arbace_go_build__init_part1_A_const_pool.A[99]; A_arbace_go_build__init_part1_A_const_38 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[100]); A_arbace_go_build__init_part1_A_const_39 = A_arbace_go_build__init_part1_A_const_pool.A[101]; A_arbace_go_build__init_part1_A_const_40 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[102]); A_arbace_go_build__init_part1_A_const_41 = A_arbace_go_build__init_part1_A_const_pool.A[103]; A_arbace_go_build__init_part1_A_const_42 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[104]); A_arbace_go_build__init_part1_A_const_43 = A_arbace_go_build__init_part1_A_const_pool.A[105]; A_arbace_go_build__init_part1_A_const_44 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[106]); A_arbace_go_build__init_part1_A_const_45 = A_arbace_go_build__init_part1_A_const_pool.A[107]; A_arbace_go_build__init_part1_A_const_46 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[108]); A_arbace_go_build__init_part1_A_const_47 = A_arbace_go_build__init_part1_A_const_pool.A[109]; A_arbace_go_build__init_part1_A_const_48 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[110]); A_arbace_go_build__init_part1_A_const_49 = A_arbace_go_build__init_part1_A_const_pool.A[111]; var tmp4 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp4 = A_arbace_go_build__init_part0_A_const_139; A_arbace_go_build__init_part1_A_const_50 = tmp4; A_arbace_go_build__init_part1_A_const_51 = A_arbace_go_build__init_part1_A_const_pool.A[112]; A_arbace_go_build__init_part1_A_const_52 = A_arbace_go_build__init_part1_A_const_pool.A[113]; var tmp5 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp5 = A_arbace_go_build__init_part0_A_const_141; A_arbace_go_build__init_part1_A_const_53 = tmp5; A_arbace_go_build__init_part1_A_const_54 = A_arbace_go_build__init_part1_A_const_pool.A[114]; A_arbace_go_build__init_part1_A_const_55 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[115]); A_arbace_go_build__init_part1_A_const_56 = A_arbace_go_build__init_part1_A_const_pool.A[116]; A_arbace_go_build__init_part1_A_const_57 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[117]); A_arbace_go_build__init_part1_A_const_58 = A_arbace_go_build__init_part1_A_const_pool.A[118]; A_arbace_go_build__init_part1_A_const_59 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[119]); A_arbace_go_build__init_part1_A_const_60 = A_arbace_go_build__init_part1_A_const_pool.A[120]; A_arbace_go_build__init_part1_A_const_61 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[121]); A_arbace_go_build__init_part1_A_const_62 = A_arbace_go_build__init_part1_A_const_pool.A[122]; A_arbace_go_build__init_part1_A_const_63 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[123]); A_arbace_go_build__init_part1_A_const_64 = A_arbace_go_build__init_part1_A_const_pool.A[124]; A_arbace_go_build__init_part1_A_const_65 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[125]); A_arbace_go_build__init_part1_A_const_66 = A_arbace_go_build__init_part1_A_const_pool.A[126]; A_arbace_go_build__init_part1_A_const_67 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[127]); A_arbace_go_build__init_part1_A_const_68 = A_arbace_go_build__init_part1_A_const_pool.A[128]; var tmp6 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp6 = A_arbace_go_build__init_part0_A_const_151; A_arbace_go_build__init_part1_A_const_69 = tmp6; A_arbace_go_build__init_part1_A_const_70 = A_arbace_go_build__init_part1_A_const_pool.A[129]; A_arbace_go_build__init_part1_A_const_71 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[130]); A_arbace_go_build__init_part1_A_const_72 = A_arbace_go_build__init_part1_A_const_pool.A[131]; A_arbace_go_build__init_part1_A_const_73 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[132]); A_arbace_go_build__init_part1_A_const_74 = A_arbace_go_build__init_part1_A_const_pool.A[133]; A_arbace_go_build__init_part1_A_const_75 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[134]); A_arbace_go_build__init_part1_A_const_76 = A_arbace_go_build__init_part1_A_const_pool.A[135]; A_arbace_go_build__init_part1_A_const_77 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[136]); A_arbace_go_build__init_part1_A_const_78 = A_arbace_go_build__init_part1_A_const_pool.A[137]; A_arbace_go_build__init_part1_A_const_79 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[138]); A_arbace_go_build__init_part1_A_const_80 = A_arbace_go_build__init_part1_A_const_pool.A[139]; A_arbace_go_build__init_part1_A_const_81 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[140]); A_arbace_go_build__init_part1_A_const_82 = A_arbace_go_build__init_part1_A_const_pool.A[141]; A_arbace_go_build__init_part1_A_const_83 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[142]); A_arbace_go_build__init_part1_A_const_84 = A_arbace_go_build__init_part1_A_const_pool.A[143]; A_arbace_go_build__init_part1_A_const_85 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[144]); A_arbace_go_build__init_part1_A_const_86 = A_arbace_go_build__init_part1_A_const_pool.A[145]; A_arbace_go_build__init_part1_A_const_87 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[146]); A_arbace_go_build__init_part1_A_const_88 = A_arbace_go_build__init_part1_A_const_pool.A[147]; A_arbace_go_build__init_part1_A_const_89 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[148]); A_arbace_go_build__init_part1_A_const_90 = A_arbace_go_build__init_part1_A_const_pool.A[149]; A_arbace_go_build__init_part1_A_const_91 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[150]); A_arbace_go_build__init_part1_A_const_92 = A_arbace_go_build__init_part1_A_const_pool.A[151]; A_arbace_go_build__init_part1_A_const_93 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[152]); A_arbace_go_build__init_part1_A_const_94 = A_arbace_go_build__init_part1_A_const_pool.A[153]; A_arbace_go_build__init_part1_A_const_95 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[154]); A_arbace_go_build__init_part1_A_const_96 = A_arbace_go_build__init_part1_A_const_pool.A[155]; A_arbace_go_build__init_part1_A_const_97 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[156]); A_arbace_go_build__init_part1_A_const_98 = A_arbace_go_build__init_part1_A_const_pool.A[157]; A_arbace_go_build__init_part1_A_const_99 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[158]); A_arbace_go_build__init_part1_A_const_100 = A_arbace_go_build__init_part1_A_const_pool.A[159]; A_arbace_go_build__init_part1_A_const_101 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[160]); A_arbace_go_build__init_part1_A_const_102 = A_arbace_go_build__init_part1_A_const_pool.A[161]; A_arbace_go_build__init_part1_A_const_103 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[162]); A_arbace_go_build__init_part1_A_const_104 = A_arbace_go_build__init_part1_A_const_pool.A[163]; A_arbace_go_build__init_part1_A_const_105 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[164]); A_arbace_go_build__init_part1_A_const_106 = A_arbace_go_build__init_part1_A_const_pool.A[165]; A_arbace_go_build__init_part1_A_const_107 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[166]); A_arbace_go_build__init_part1_A_const_108 = A_arbace_go_build__init_part1_A_const_pool.A[167]; A_arbace_go_build__init_part1_A_const_109 = A_arbace_go_build__init_part1_A_const_pool.A[168]; A_arbace_go_build__init_part1_A_const_110 = A_arbace_go_build__init_part1_A_const_pool.A[169]; A_arbace_go_build__init_part1_A_const_111 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[170]); A_arbace_go_build__init_part1_A_const_112 = A_arbace_go_build__init_part1_A_const_pool.A[171]; A_arbace_go_build__init_part1_A_const_113 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[172]); A_arbace_go_build__init_part1_A_const_114 = A_arbace_go_build__init_part1_A_const_pool.A[173]; var tmp7 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp7 = A_arbace_go_build__init_part0_A_const_165; A_arbace_go_build__init_part1_A_const_115 = tmp7; A_arbace_go_build__init_part1_A_const_116 = A_arbace_go_build__init_part1_A_const_pool.A[174]; var tmp8 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp8 = A_arbace_go_build__init_part0_A_const_167; A_arbace_go_build__init_part1_A_const_117 = tmp8; A_arbace_go_build__init_part1_A_const_118 = A_arbace_go_build__init_part1_A_const_pool.A[175]; A_arbace_go_build__init_part1_A_const_119 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[176]); A_arbace_go_build__init_part1_A_const_120 = A_arbace_go_build__init_part1_A_const_pool.A[177]; A_arbace_go_build__init_part1_A_const_121 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[178]); A_arbace_go_build__init_part1_A_const_122 = A_arbace_go_build__init_part1_A_const_pool.A[179]; A_arbace_go_build__init_part1_A_const_123 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[180]); A_arbace_go_build__init_part1_A_const_124 = A_arbace_go_build__init_part1_A_const_pool.A[181]; A_arbace_go_build__init_part1_A_const_125 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[182]); A_arbace_go_build__init_part1_A_const_126 = A_arbace_go_build__init_part1_A_const_pool.A[183]; A_arbace_go_build__init_part1_A_const_127 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[184]); A_arbace_go_build__init_part1_A_const_128 = A_arbace_go_build__init_part1_A_const_pool.A[185]; A_arbace_go_build__init_part1_A_const_129 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[186]); A_arbace_go_build__init_part1_A_const_130 = A_arbace_go_build__init_part1_A_const_pool.A[187]; var tmp9 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp9 = A_arbace_go_build__init_part0_A_const_169; A_arbace_go_build__init_part1_A_const_131 = tmp9; A_arbace_go_build__init_part1_A_const_132 = A_arbace_go_build__init_part1_A_const_pool.A[188]; A_arbace_go_build__init_part1_A_const_133 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[189]); A_arbace_go_build__init_part1_A_const_134 = A_arbace_go_build__init_part1_A_const_pool.A[190]; A_arbace_go_build__init_part1_A_const_135 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[191]); A_arbace_go_build__init_part1_A_const_136 = A_arbace_go_build__init_part1_A_const_pool.A[192]; A_arbace_go_build__init_part1_A_const_137 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[193]); A_arbace_go_build__init_part1_A_const_138 = A_arbace_go_build__init_part1_A_const_pool.A[194]; A_arbace_go_build__init_part1_A_const_139 = A_arbace_go_build__init_part1_A_const_pool.A[195]; A_arbace_go_build__init_part1_A_const_140 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[196]); A_arbace_go_build__init_part1_A_const_141 = A_arbace_go_build__init_part1_A_const_pool.A[197]; var tmp10 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp10 = A_arbace_go_build__init_part0_A_const_177; A_arbace_go_build__init_part1_A_const_142 = tmp10; A_arbace_go_build__init_part1_A_const_143 = A_arbace_go_build__init_part1_A_const_pool.A[198]; var tmp11 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp11 = A_arbace_go_build__init_part0_A_const_79; A_arbace_go_build__init_part1_A_const_144 = tmp11; A_arbace_go_build__init_part1_A_const_145 = A_arbace_go_build__init_part1_A_const_pool.A[199]; var tmp12 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp12 = A_arbace_go_build__init_part0_A_const_81; A_arbace_go_build__init_part1_A_const_146 = tmp12; A_arbace_go_build__init_part1_A_const_147 = A_arbace_go_build__init_part1_A_const_pool.A[200]; A_arbace_go_build__init_part1_A_const_148 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[201]); A_arbace_go_build__init_part1_A_const_149 = A_arbace_go_build__init_part1_A_const_pool.A[202]; A_arbace_go_build__init_part1_A_const_150 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[203]); A_arbace_go_build__init_part1_A_const_151 = A_arbace_go_build__init_part1_A_const_pool.A[204]; A_arbace_go_build__init_part1_A_const_152 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[205]); A_arbace_go_build__init_part1_A_const_153 = A_arbace_go_build__init_part1_A_const_pool.A[206]; var tmp13 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp13 = A_arbace_go_build__init_part0_A_const_171; A_arbace_go_build__init_part1_A_const_154 = tmp13; A_arbace_go_build__init_part1_A_const_155 = A_arbace_go_build__init_part1_A_const_pool.A[207]; var tmp14 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp14 = A_arbace_go_build__init_part0_A_const_149; A_arbace_go_build__init_part1_A_const_156 = tmp14; A_arbace_go_build__init_part1_A_const_157 = A_arbace_go_build__init_part1_A_const_pool.A[208]; A_arbace_go_build__init_part1_A_const_158 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[209]); A_arbace_go_build__init_part1_A_const_159 = A_arbace_go_build__init_part1_A_const_pool.A[210]; var tmp15 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp15 = A_arbace_go_build__init_part0_A_const_173; A_arbace_go_build__init_part1_A_const_160 = tmp15; A_arbace_go_build__init_part1_A_const_161 = A_arbace_go_build__init_part1_A_const_pool.A[211]; var tmp16 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp16 = A_arbace_go_build__init_part0_A_const_155; A_arbace_go_build__init_part1_A_const_162 = tmp16; A_arbace_go_build__init_part1_A_const_163 = A_arbace_go_build__init_part1_A_const_pool.A[212]; var tmp17 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp17 = A_arbace_go_build__init_part0_A_const_157; A_arbace_go_build__init_part1_A_const_164 = tmp17; A_arbace_go_build__init_part1_A_const_165 = A_arbace_go_build__init_part1_A_const_pool.A[213]; A_arbace_go_build__init_part1_A_const_166 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[214]); A_arbace_go_build__init_part1_A_const_167 = A_arbace_go_build__init_part1_A_const_pool.A[215]; A_arbace_go_build__init_part1_A_const_168 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[216]); A_arbace_go_build__init_part1_A_const_169 = A_arbace_go_build__init_part1_A_const_pool.A[217]; A_arbace_go_build__init_part1_A_const_170 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[218]); A_arbace_go_build__init_part1_A_const_171 = A_arbace_go_build__init_part1_A_const_pool.A[219]; var tmp18 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp18 = A_arbace_go_build__init_part0_A_const_163; A_arbace_go_build__init_part1_A_const_172 = tmp18; A_arbace_go_build__init_part1_A_const_173 = A_arbace_go_build__init_part1_A_const_pool.A[220]; A_arbace_go_build__init_part1_A_const_174 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[221]); A_arbace_go_build__init_part1_A_const_175 = A_arbace_go_build__init_part1_A_const_pool.A[222]; A_arbace_go_build__init_part1_A_const_176 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[223]); A_arbace_go_build__init_part1_A_const_177 = A_arbace_go_build__init_part1_A_const_pool.A[224]; A_arbace_go_build__init_part1_A_const_178 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[225]); A_arbace_go_build__init_part1_A_const_179 = A_arbace_go_build__init_part1_A_const_pool.A[226]; A_arbace_go_build__init_part1_A_const_180 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[227]); A_arbace_go_build__init_part1_A_const_181 = A_arbace_go_build__init_part1_A_const_pool.A[228]; A_arbace_go_build__init_part1_A_const_182 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[229]); A_arbace_go_build__init_part1_A_const_183 = A_arbace_go_build__init_part1_A_const_pool.A[230]; A_arbace_go_build__init_part1_A_const_184 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[231]); A_arbace_go_build__init_part1_A_const_185 = A_arbace_go_build__init_part1_A_const_pool.A[232]; A_arbace_go_build__init_part1_A_const_186 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[233]); A_arbace_go_build__init_part1_A_const_187 = A_arbace_go_build__init_part1_A_const_pool.A[234]; A_arbace_go_build__init_part1_A_const_188 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[235]); A_arbace_go_build__init_part1_A_const_189 = A_arbace_go_build__init_part1_A_const_pool.A[236]; A_arbace_go_build__init_part1_A_const_190 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[237]); A_arbace_go_build__init_part1_A_const_191 = A_arbace_go_build__init_part1_A_const_pool.A[238]; A_arbace_go_build__init_part1_A_const_192 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[239]); A_arbace_go_build__init_part1_A_const_193 = A_arbace_go_build__init_part1_A_const_pool.A[240]; A_arbace_go_build__init_part1_A_const_194 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[241]); A_arbace_go_build__init_part1_A_const_195 = A_arbace_go_build__init_part1_A_const_pool.A[242]; A_arbace_go_build__init_part1_A_const_196 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[243]); A_arbace_go_build__init_part1_A_const_197 = A_arbace_go_build__init_part1_A_const_pool.A[244] }

func A_arbace_go_build__init_part1_A_New() *A_arbace_go_build__init_part1_A { A_arbace_go_build__init_part1_A_Init(); t := &A_arbace_go_build__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_go_build__init_part1_A) Ctor() {}

func (t *A_arbace_go_build__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_build__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_go_build__init_part1_A_class }

func (t *A_arbace_go_build__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_build__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_build__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_build__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_build__init_part1_A); return ok }

func A_arbace_go_build__init_part1_A_Cast(x any) *A_arbace_go_build__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_build__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_build__init_part1_A_class)) }; return v }



type A_arbace_go_build__init_part2_A struct{ jrt.Object }

var A_arbace_go_build__init_part2_A_const_pool *jrt.RefArray

var A_arbace_go_build__init_part2_A_const_0 *lang.Var

var A_arbace_go_build__init_part2_A_const_1 any

var A_arbace_go_build__init_part2_A_const_2 *lang.Var

var A_arbace_go_build__init_part2_A_const_3 any

var A_arbace_go_build__init_part2_A_const_4 *lang.Var

var A_arbace_go_build__init_part2_A_const_5 any

var A_arbace_go_build__init_part2_A_const_6 *lang.Var

var A_arbace_go_build__init_part2_A_const_7 any

var A_arbace_go_build__init_part2_A_const_8 *lang.Var

var A_arbace_go_build__init_part2_A_const_9 any

var A_arbace_go_build__init_part2_A_const_10 any

var A_arbace_go_build__init_part2_A_const_11 *lang.Var

var A_arbace_go_build__init_part2_A_const_12 any

var A_arbace_go_build__init_part2_A_const_13 *lang.Var

var A_arbace_go_build__init_part2_A_const_14 any

var A_arbace_go_build__init_part2_A_const_15 *lang.Var

var A_arbace_go_build__init_part2_A_const_16 any

var A_arbace_go_build__init_part2_A_const_17 *lang.Var

var A_arbace_go_build__init_part2_A_const_18 any

var A_arbace_go_build__init_part2_A_const_19 any

var A_arbace_go_build__init_part2_A_const_20 *lang.Var

var A_arbace_go_build__init_part2_A_const_21 any

var A_arbace_go_build__init_part2_A_const_22 *lang.Var

var A_arbace_go_build__init_part2_A_const_23 any

var A_arbace_go_build__init_part2_A_const_24 *lang.Var

var A_arbace_go_build__init_part2_A_const_25 any

var A_arbace_go_build__init_part2_A_const_26 *lang.Var

var A_arbace_go_build__init_part2_A_const_27 any

var A_arbace_go_build__init_part2_A_const_28 *lang.Var

var A_arbace_go_build__init_part2_A_const_29 any

var A_arbace_go_build__init_part2_A_const_30 *lang.Var

var A_arbace_go_build__init_part2_A_const_31 any

var A_arbace_go_build__init_part2_A_const_32 *lang.Var

var A_arbace_go_build__init_part2_A_const_33 any

var A_arbace_go_build__init_part2_A_const_34 *lang.Var

var A_arbace_go_build__init_part2_A_const_35 any

var A_arbace_go_build__init_part2_A_const_36 *lang.Var

var A_arbace_go_build__init_part2_A_const_37 any

var A_arbace_go_build__init_part2_A_const_38 *lang.Var

var A_arbace_go_build__init_part2_A_const_39 any

var A_arbace_go_build__init_part2_A_const_40 *lang.Var

var A_arbace_go_build__init_part2_A_const_41 any

var A_arbace_go_build__init_part2_A_const_42 *lang.Var

var A_arbace_go_build__init_part2_A_const_43 any

var A_arbace_go_build__init_part2_A_const_44 *lang.Var

var A_arbace_go_build__init_part2_A_const_45 any

var A_arbace_go_build__init_part2_A_const_46 *lang.Var

var A_arbace_go_build__init_part2_A_const_47 any

var A_arbace_go_build__init_part2_A_const_48 *lang.Var

var A_arbace_go_build__init_part2_A_const_49 any

var A_arbace_go_build__init_part2_A_const_50 *lang.Var

var A_arbace_go_build__init_part2_A_const_51 any

var A_arbace_go_build__init_part2_A_const_52 *lang.Var

var A_arbace_go_build__init_part2_A_const_53 any

var A_arbace_go_build__init_part2_A_const_54 *lang.Var

var A_arbace_go_build__init_part2_A_const_55 any

var A_arbace_go_build__init_part2_A_const_56 *lang.Var

var A_arbace_go_build__init_part2_A_const_57 any

var A_arbace_go_build__init_part2_A_const_58 *lang.Var

var A_arbace_go_build__init_part2_A_const_59 any

var A_arbace_go_build__init_part2_A_const_60 *lang.Var

var A_arbace_go_build__init_part2_A_const_61 any

var A_arbace_go_build__init_part2_A_const_62 *lang.Var

var A_arbace_go_build__init_part2_A_const_63 any

var A_arbace_go_build__init_part2_A_const_64 *lang.Var

var A_arbace_go_build__init_part2_A_const_65 any

var A_arbace_go_build__init_part2_A_const_66 *lang.Var

var A_arbace_go_build__init_part2_A_const_67 any

var A_arbace_go_build__init_part2_A_const_68 *lang.Var

var A_arbace_go_build__init_part2_A_const_69 any

var A_arbace_go_build__init_part2_A_const_70 *lang.Var

var A_arbace_go_build__init_part2_A_const_71 any

var A_arbace_go_build__init_part2_A_const_72 *lang.Var

var A_arbace_go_build__init_part2_A_const_73 any

var A_arbace_go_build__init_part2_A_const_74 *lang.Var

var A_arbace_go_build__init_part2_A_const_75 any

var A_arbace_go_build__init_part2_A_const_76 *lang.Var

var A_arbace_go_build__init_part2_A_const_77 any

var A_arbace_go_build__init_part2_A_const_78 *lang.Var

var A_arbace_go_build__init_part2_A_const_79 any

var A_arbace_go_build__init_part2_A_const_80 *lang.Var

var A_arbace_go_build__init_part2_A_const_81 any

var A_arbace_go_build__init_part2_A_const_82 *lang.Var

var A_arbace_go_build__init_part2_A_const_83 any

var A_arbace_go_build__init_part2_A_const_84 *lang.Var

var A_arbace_go_build__init_part2_A_const_85 any

var A_arbace_go_build__init_part2_A_const_86 *lang.Var

var A_arbace_go_build__init_part2_A_const_87 any

var A_arbace_go_build__init_part2_A_const_88 any

var A_arbace_go_build__init_part2_A_const_89 *lang.Var

var A_arbace_go_build__init_part2_A_const_90 any

var A_arbace_go_build__init_part2_A_const_91 any

var A_arbace_go_build__init_part2_A_const_92 *lang.Var

var A_arbace_go_build__init_part2_A_const_93 any

var A_arbace_go_build__init_part2_A_const_94 any

var A_arbace_go_build__init_part2_A_const_95 *lang.Var

var A_arbace_go_build__init_part2_A_const_96 any

var A_arbace_go_build__init_part2_A_const_97 any

var A_arbace_go_build__init_part2_A_const_98 *lang.Var

var A_arbace_go_build__init_part2_A_const_99 any

var A_arbace_go_build__init_part2_A_const_100 *lang.Var

var A_arbace_go_build__init_part2_A_const_101 any

var A_arbace_go_build__init_part2_A_const_102 *lang.Var

var A_arbace_go_build__init_part2_A_const_103 any

var A_arbace_go_build__init_part2_A_const_104 *lang.Var

var A_arbace_go_build__init_part2_A_const_105 any

var A_arbace_go_build__init_part2_A_const_106 any

var A_arbace_go_build__init_part2_A_const_107 *lang.Var

var A_arbace_go_build__init_part2_A_const_108 any

var A_arbace_go_build__init_part2_A_const_109 any

var A_arbace_go_build__init_part2_A_const_110 *lang.Var

var A_arbace_go_build__init_part2_A_const_111 any

var A_arbace_go_build__init_part2_A_const_112 *lang.Var

var A_arbace_go_build__init_part2_A_const_113 any

var A_arbace_go_build__init_part2_A_const_114 *lang.Var

var A_arbace_go_build__init_part2_A_const_115 any

var A_arbace_go_build__init_part2_A_const_116 any

var A_arbace_go_build__init_part2_A_const_117 any

var A_arbace_go_build__init_part2_A_const_118 *lang.Var

var A_arbace_go_build__init_part2_A_const_119 any

var A_arbace_go_build__init_part2_A_const_120 *lang.Var

var A_arbace_go_build__init_part2_A_const_121 any

var A_arbace_go_build__init_part2_A_const_122 *lang.Var

var A_arbace_go_build__init_part2_A_const_123 any

var A_arbace_go_build__init_part2_A_const_124 *lang.Var

var A_arbace_go_build__init_part2_A_const_125 any

var A_arbace_go_build__init_part2_A_const_126 *lang.Var

var A_arbace_go_build__init_part2_A_const_127 any

var A_arbace_go_build__init_part2_A_const_128 *lang.Var

var A_arbace_go_build__init_part2_A_const_129 any

var A_arbace_go_build__init_part2_A_const_130 any

var A_arbace_go_build__init_part2_A_init jrt.ClassInit

func A_arbace_go_build__init_part2_A_Init() { if !A_arbace_go_build__init_part2_A_init.Done() { A_arbace_go_build__init_part2_A_init.Run(A_arbace_go_build__init_part2_A_clinit) } }

func A_arbace_go_build__init_part2_A_clinit() { A_arbace_go_build__init_part2_A_clinit_p0(); A_arbace_go_build__init_part2_A_clinit_p1(); A_arbace_go_build__init_part2_A_clinit_p2(); A_arbace_go_build__init_part2_A_clinit_p3() }

func A_arbace_go_build__init_part2_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_build__init_part2_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_753, 180); A_arbace_go_build__init_part2_A_const_0 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[58]); A_arbace_go_build__init_part2_A_const_1 = A_arbace_go_build__init_part2_A_const_pool.A[59]; A_arbace_go_build__init_part2_A_const_2 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[60]); A_arbace_go_build__init_part2_A_const_3 = A_arbace_go_build__init_part2_A_const_pool.A[61]; A_arbace_go_build__init_part2_A_const_4 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[62]); A_arbace_go_build__init_part2_A_const_5 = A_arbace_go_build__init_part2_A_const_pool.A[63]; A_arbace_go_build__init_part2_A_const_6 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[64]); A_arbace_go_build__init_part2_A_const_7 = A_arbace_go_build__init_part2_A_const_pool.A[65]; A_arbace_go_build__init_part2_A_const_8 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[66]); A_arbace_go_build__init_part2_A_const_9 = A_arbace_go_build__init_part2_A_const_pool.A[67]; A_arbace_go_build__init_part2_A_const_10 = A_arbace_go_build__init_part2_A_const_pool.A[68]; A_arbace_go_build__init_part2_A_const_11 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[69]); A_arbace_go_build__init_part2_A_const_12 = A_arbace_go_build__init_part2_A_const_pool.A[70] }

func A_arbace_go_build__init_part2_A_clinit_p1() { A_arbace_go_build__init_part2_A_const_13 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[71]); A_arbace_go_build__init_part2_A_const_14 = A_arbace_go_build__init_part2_A_const_pool.A[72]; A_arbace_go_build__init_part2_A_const_15 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[73]); A_arbace_go_build__init_part2_A_const_16 = A_arbace_go_build__init_part2_A_const_pool.A[74]; A_arbace_go_build__init_part2_A_const_17 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[75]); A_arbace_go_build__init_part2_A_const_18 = A_arbace_go_build__init_part2_A_const_pool.A[76]; A_arbace_go_build__init_part2_A_const_19 = A_arbace_go_build__init_part2_A_const_pool.A[77]; A_arbace_go_build__init_part2_A_const_20 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[78]); A_arbace_go_build__init_part2_A_const_21 = A_arbace_go_build__init_part2_A_const_pool.A[79]; A_arbace_go_build__init_part2_A_const_22 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[80]); A_arbace_go_build__init_part2_A_const_23 = A_arbace_go_build__init_part2_A_const_pool.A[81]; A_arbace_go_build__init_part2_A_const_24 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[82]); A_arbace_go_build__init_part2_A_const_25 = A_arbace_go_build__init_part2_A_const_pool.A[83] }

func A_arbace_go_build__init_part2_A_clinit_p2() { A_arbace_go_build__init_part2_A_const_26 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[84]); A_arbace_go_build__init_part2_A_const_27 = A_arbace_go_build__init_part2_A_const_pool.A[85] }

func A_arbace_go_build__init_part2_A_clinit_p3() { var tmp1 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp1 = A_arbace_go_build__init_part0_A_const_161; A_arbace_go_build__init_part2_A_const_28 = tmp1; A_arbace_go_build__init_part2_A_const_29 = A_arbace_go_build__init_part2_A_const_pool.A[86]; A_arbace_go_build__init_part2_A_const_30 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[87]); A_arbace_go_build__init_part2_A_const_31 = A_arbace_go_build__init_part2_A_const_pool.A[88]; A_arbace_go_build__init_part2_A_const_32 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[89]); A_arbace_go_build__init_part2_A_const_33 = A_arbace_go_build__init_part2_A_const_pool.A[90]; A_arbace_go_build__init_part2_A_const_34 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[91]); A_arbace_go_build__init_part2_A_const_35 = A_arbace_go_build__init_part2_A_const_pool.A[92]; A_arbace_go_build__init_part2_A_const_36 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[93]); A_arbace_go_build__init_part2_A_const_37 = A_arbace_go_build__init_part2_A_const_pool.A[94]; A_arbace_go_build__init_part2_A_const_38 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[95]); A_arbace_go_build__init_part2_A_const_39 = A_arbace_go_build__init_part2_A_const_pool.A[96]; A_arbace_go_build__init_part2_A_const_40 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[97]); A_arbace_go_build__init_part2_A_const_41 = A_arbace_go_build__init_part2_A_const_pool.A[98]; A_arbace_go_build__init_part2_A_const_42 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[99]); A_arbace_go_build__init_part2_A_const_43 = A_arbace_go_build__init_part2_A_const_pool.A[100]; A_arbace_go_build__init_part2_A_const_44 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[101]); A_arbace_go_build__init_part2_A_const_45 = A_arbace_go_build__init_part2_A_const_pool.A[102]; A_arbace_go_build__init_part2_A_const_46 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[103]); A_arbace_go_build__init_part2_A_const_47 = A_arbace_go_build__init_part2_A_const_pool.A[104]; A_arbace_go_build__init_part2_A_const_48 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[105]); A_arbace_go_build__init_part2_A_const_49 = A_arbace_go_build__init_part2_A_const_pool.A[106]; A_arbace_go_build__init_part2_A_const_50 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[107]); A_arbace_go_build__init_part2_A_const_51 = A_arbace_go_build__init_part2_A_const_pool.A[108]; A_arbace_go_build__init_part2_A_const_52 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[109]); A_arbace_go_build__init_part2_A_const_53 = A_arbace_go_build__init_part2_A_const_pool.A[110]; A_arbace_go_build__init_part2_A_const_54 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[111]); A_arbace_go_build__init_part2_A_const_55 = A_arbace_go_build__init_part2_A_const_pool.A[112]; A_arbace_go_build__init_part2_A_const_56 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[113]); A_arbace_go_build__init_part2_A_const_57 = A_arbace_go_build__init_part2_A_const_pool.A[114]; A_arbace_go_build__init_part2_A_const_58 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[115]); A_arbace_go_build__init_part2_A_const_59 = A_arbace_go_build__init_part2_A_const_pool.A[116]; A_arbace_go_build__init_part2_A_const_60 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[117]); A_arbace_go_build__init_part2_A_const_61 = A_arbace_go_build__init_part2_A_const_pool.A[118]; A_arbace_go_build__init_part2_A_const_62 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[119]); A_arbace_go_build__init_part2_A_const_63 = A_arbace_go_build__init_part2_A_const_pool.A[120]; A_arbace_go_build__init_part2_A_const_64 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[121]); A_arbace_go_build__init_part2_A_const_65 = A_arbace_go_build__init_part2_A_const_pool.A[122]; A_arbace_go_build__init_part2_A_const_66 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[123]); A_arbace_go_build__init_part2_A_const_67 = A_arbace_go_build__init_part2_A_const_pool.A[124]; A_arbace_go_build__init_part2_A_const_68 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[125]); A_arbace_go_build__init_part2_A_const_69 = A_arbace_go_build__init_part2_A_const_pool.A[126]; var tmp2 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp2 = A_arbace_go_build__init_part0_A_const_159; A_arbace_go_build__init_part2_A_const_70 = tmp2; A_arbace_go_build__init_part2_A_const_71 = A_arbace_go_build__init_part2_A_const_pool.A[127]; A_arbace_go_build__init_part2_A_const_72 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[128]); A_arbace_go_build__init_part2_A_const_73 = A_arbace_go_build__init_part2_A_const_pool.A[129]; A_arbace_go_build__init_part2_A_const_74 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[130]); A_arbace_go_build__init_part2_A_const_75 = A_arbace_go_build__init_part2_A_const_pool.A[131]; var tmp3 *lang.Var; A_arbace_go_build__init_part1_A_Init(); tmp3 = A_arbace_go_build__init_part1_A_const_119; A_arbace_go_build__init_part2_A_const_76 = tmp3; A_arbace_go_build__init_part2_A_const_77 = A_arbace_go_build__init_part2_A_const_pool.A[132]; var tmp4 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp4 = A_arbace_go_build__init_part0_A_const_153; A_arbace_go_build__init_part2_A_const_78 = tmp4; A_arbace_go_build__init_part2_A_const_79 = A_arbace_go_build__init_part2_A_const_pool.A[133]; A_arbace_go_build__init_part2_A_const_80 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[134]); A_arbace_go_build__init_part2_A_const_81 = A_arbace_go_build__init_part2_A_const_pool.A[135]; A_arbace_go_build__init_part2_A_const_82 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[136]); A_arbace_go_build__init_part2_A_const_83 = A_arbace_go_build__init_part2_A_const_pool.A[137]; var tmp5 *lang.Var; A_arbace_go_build__init_part1_A_Init(); tmp5 = A_arbace_go_build__init_part1_A_const_42; A_arbace_go_build__init_part2_A_const_84 = tmp5; A_arbace_go_build__init_part2_A_const_85 = A_arbace_go_build__init_part2_A_const_pool.A[138]; A_arbace_go_build__init_part2_A_const_86 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[139]); A_arbace_go_build__init_part2_A_const_87 = A_arbace_go_build__init_part2_A_const_pool.A[140]; A_arbace_go_build__init_part2_A_const_88 = A_arbace_go_build__init_part2_A_const_pool.A[141]; A_arbace_go_build__init_part2_A_const_89 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[142]); A_arbace_go_build__init_part2_A_const_90 = A_arbace_go_build__init_part2_A_const_pool.A[143]; A_arbace_go_build__init_part2_A_const_91 = A_arbace_go_build__init_part2_A_const_pool.A[144]; A_arbace_go_build__init_part2_A_const_92 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[145]); A_arbace_go_build__init_part2_A_const_93 = A_arbace_go_build__init_part2_A_const_pool.A[146]; A_arbace_go_build__init_part2_A_const_94 = A_arbace_go_build__init_part2_A_const_pool.A[147]; A_arbace_go_build__init_part2_A_const_95 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[148]); A_arbace_go_build__init_part2_A_const_96 = A_arbace_go_build__init_part2_A_const_pool.A[149]; A_arbace_go_build__init_part2_A_const_97 = A_arbace_go_build__init_part2_A_const_pool.A[150]; A_arbace_go_build__init_part2_A_const_98 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[151]); A_arbace_go_build__init_part2_A_const_99 = A_arbace_go_build__init_part2_A_const_pool.A[152]; A_arbace_go_build__init_part2_A_const_100 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[153]); A_arbace_go_build__init_part2_A_const_101 = A_arbace_go_build__init_part2_A_const_pool.A[154]; A_arbace_go_build__init_part2_A_const_102 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[155]); A_arbace_go_build__init_part2_A_const_103 = A_arbace_go_build__init_part2_A_const_pool.A[156]; A_arbace_go_build__init_part2_A_const_104 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[157]); A_arbace_go_build__init_part2_A_const_105 = A_arbace_go_build__init_part2_A_const_pool.A[158]; A_arbace_go_build__init_part2_A_const_106 = A_arbace_go_build__init_part2_A_const_pool.A[159]; A_arbace_go_build__init_part2_A_const_107 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[160]); A_arbace_go_build__init_part2_A_const_108 = A_arbace_go_build__init_part2_A_const_pool.A[161]; A_arbace_go_build__init_part2_A_const_109 = A_arbace_go_build__init_part2_A_const_pool.A[162]; A_arbace_go_build__init_part2_A_const_110 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[163]); A_arbace_go_build__init_part2_A_const_111 = A_arbace_go_build__init_part2_A_const_pool.A[164]; A_arbace_go_build__init_part2_A_const_112 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[165]); A_arbace_go_build__init_part2_A_const_113 = A_arbace_go_build__init_part2_A_const_pool.A[166]; var tmp6 *lang.Var; A_arbace_go_build__init_part1_A_Init(); tmp6 = A_arbace_go_build__init_part1_A_const_148; A_arbace_go_build__init_part2_A_const_114 = tmp6; A_arbace_go_build__init_part2_A_const_115 = A_arbace_go_build__init_part2_A_const_pool.A[167]; A_arbace_go_build__init_part2_A_const_116 = A_arbace_go_build__init_part2_A_const_pool.A[168]; A_arbace_go_build__init_part2_A_const_117 = A_arbace_go_build__init_part2_A_const_pool.A[169]; var tmp7 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp7 = A_arbace_go_build__init_part0_A_const_89; A_arbace_go_build__init_part2_A_const_118 = tmp7; A_arbace_go_build__init_part2_A_const_119 = A_arbace_go_build__init_part2_A_const_pool.A[170]; var tmp8 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp8 = A_arbace_go_build__init_part0_A_const_87; A_arbace_go_build__init_part2_A_const_120 = tmp8; A_arbace_go_build__init_part2_A_const_121 = A_arbace_go_build__init_part2_A_const_pool.A[171]; A_arbace_go_build__init_part2_A_const_122 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[172]); A_arbace_go_build__init_part2_A_const_123 = A_arbace_go_build__init_part2_A_const_pool.A[173]; A_arbace_go_build__init_part2_A_const_124 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[174]); A_arbace_go_build__init_part2_A_const_125 = A_arbace_go_build__init_part2_A_const_pool.A[175]; A_arbace_go_build__init_part2_A_const_126 = lang.Var_Cast(A_arbace_go_build__init_part2_A_const_pool.A[176]); A_arbace_go_build__init_part2_A_const_127 = A_arbace_go_build__init_part2_A_const_pool.A[177]; var tmp9 *lang.Var; A_arbace_go_build__init_part1_A_Init(); tmp9 = A_arbace_go_build__init_part1_A_const_40; A_arbace_go_build__init_part2_A_const_128 = tmp9; A_arbace_go_build__init_part2_A_const_129 = A_arbace_go_build__init_part2_A_const_pool.A[178]; A_arbace_go_build__init_part2_A_const_130 = A_arbace_go_build__init_part2_A_const_pool.A[179] }

func A_arbace_go_build__init_part2_A_New() *A_arbace_go_build__init_part2_A { A_arbace_go_build__init_part2_A_Init(); t := &A_arbace_go_build__init_part2_A{}; t.Ctor(); return t }

func (t *A_arbace_go_build__init_part2_A) Ctor() {}

func (t *A_arbace_go_build__init_part2_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_build__init_part2_A) GetClass__Class() *jrt.Class { return A_arbace_go_build__init_part2_A_class }

func (t *A_arbace_go_build__init_part2_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_build__init_part2_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_build__init_part2_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_build__init_part2_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_build__init_part2_A); return ok }

func A_arbace_go_build__init_part2_A_Cast(x any) *A_arbace_go_build__init_part2_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_build__init_part2_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_build__init_part2_A_class)) }; return v }
