//line aot_arbace_go_build__init.ae:1
package aot_arbace_go_build

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_build__init_part0_A_Unit0__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_build__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_build__init_part0_A_const_1) }
//line :1:1
func A_arbace_go_build__init_part0_A_Unit1__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_build__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_2)) }
//line :1:1
func A_arbace_go_build__init_part0_A_Unit2__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_go_build_eval367000004_loading__1927001464__auto____367000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_build_eval367000004_loading__1927001464__auto____367000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_407, false); A_arbace_go_build_eval367000004_loading__1927001464__auto____367000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_go_build__init_part0_A_Unit3__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_build__init_part0_A_const_1)).Equals_O__Z(A_arbace_go_build__init_part0_A_const_3) { return nil } else { var tmp1 any = A_arbace_go_build_eval367000008_fn__367000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_build_eval367000008_fn__367000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_408, false); A_arbace_go_build_eval367000008_fn__367000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
//line :1:1
func A_arbace_go_build__init_part0_A_Init__O() any { A_arbace_go_build__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_go_build__init_part0_A_Load__O() any { A_arbace_go_build__init_part0_A_Init(); A_arbace_go_build__init_part0_A_Unit0__O(); A_arbace_go_build__init_part0_A_Unit1__O(); A_arbace_go_build__init_part0_A_Unit2__O(); A_arbace_go_build__init_part0_A_Unit3__O(); A_arbace_go_build__init_part0_A_Unit4__O(); A_arbace_go_build__init_part0_A_Unit5__O(); A_arbace_go_build__init_part0_A_Unit6__O(); A_arbace_go_build__init_part0_A_Unit7__O(); A_arbace_go_build__init_part0_A_Unit8__O(); A_arbace_go_build__init_part0_A_Unit9__O(); A_arbace_go_build__init_part0_A_Unit10__O(); A_arbace_go_build__init_part0_A_Unit11__O(); A_arbace_go_build__init_part0_A_Unit12__O(); A_arbace_go_build__init_part0_A_Unit13__O(); A_arbace_go_build__init_part0_A_Unit14__O(); A_arbace_go_build__init_part0_A_Unit15__O(); A_arbace_go_build__init_part0_A_Unit16__O(); A_arbace_go_build__init_part0_A_Unit17__O(); A_arbace_go_build__init_part0_A_Unit18__O(); A_arbace_go_build__init_part0_A_Unit19__O(); A_arbace_go_build__init_part0_A_Unit20__O(); A_arbace_go_build__init_part0_A_Unit21__O(); A_arbace_go_build__init_part0_A_Unit22__O(); A_arbace_go_build__init_part0_A_Unit23__O(); A_arbace_go_build__init_part0_A_Unit24__O(); A_arbace_go_build__init_part0_A_Unit25__O(); A_arbace_go_build__init_part0_A_Unit26__O(); A_arbace_go_build__init_part0_A_Unit27__O(); A_arbace_go_build__init_part0_A_Unit28__O(); A_arbace_go_build__init_part0_A_Unit29__O(); A_arbace_go_build__init_part0_A_Unit30__O(); A_arbace_go_build__init_part0_A_Unit31__O(); A_arbace_go_build__init_part0_A_Unit32__O(); A_arbace_go_build__init_part0_A_Unit33__O(); A_arbace_go_build__init_part0_A_Unit34__O(); A_arbace_go_build__init_part0_A_Unit35__O(); A_arbace_go_build__init_part0_A_Unit36__O(); A_arbace_go_build__init_part0_A_Unit37__O(); A_arbace_go_build__init_part0_A_Unit38__O(); A_arbace_go_build__init_part0_A_Unit39__O(); A_arbace_go_build__init_part0_A_Unit40__O(); A_arbace_go_build__init_part0_A_Unit41__O(); A_arbace_go_build__init_part0_A_Unit42__O(); A_arbace_go_build__init_part0_A_Unit43__O(); A_arbace_go_build__init_part0_A_Unit44__O(); A_arbace_go_build__init_part0_A_Unit45__O(); A_arbace_go_build__init_part0_A_Unit46__O(); A_arbace_go_build__init_part0_A_Unit47__O(); A_arbace_go_build__init_part0_A_Unit48__O(); A_arbace_go_build__init_part0_A_Unit49__O(); A_arbace_go_build__init_part0_A_Unit50__O(); A_arbace_go_build__init_part0_A_Unit51__O(); A_arbace_go_build__init_part0_A_Unit52__O(); A_arbace_go_build__init_part0_A_Unit53__O(); A_arbace_go_build__init_part0_A_Unit54__O(); A_arbace_go_build__init_part0_A_Unit55__O(); A_arbace_go_build__init_part0_A_Unit56__O(); A_arbace_go_build__init_part0_A_Unit57__O(); A_arbace_go_build__init_part0_A_Unit58__O(); A_arbace_go_build__init_part0_A_Unit59__O(); A_arbace_go_build__init_part0_A_Unit60__O(); A_arbace_go_build__init_part0_A_Unit61__O(); A_arbace_go_build__init_part0_A_Unit62__O(); A_arbace_go_build__init_part0_A_Unit63__O(); A_arbace_go_build__init_part0_A_Unit64__O(); A_arbace_go_build__init_part0_A_Unit65__O(); A_arbace_go_build__init_part0_A_Unit66__O(); A_arbace_go_build__init_part0_A_Unit67__O(); A_arbace_go_build__init_part0_A_Unit68__O(); A_arbace_go_build__init_part0_A_Unit69__O(); A_arbace_go_build__init_part0_A_Unit70__O(); A_arbace_go_build__init_part0_A_Unit71__O(); A_arbace_go_build__init_part0_A_Unit72__O(); A_arbace_go_build__init_part0_A_Unit73__O(); A_arbace_go_build__init_part0_A_Unit74__O(); A_arbace_go_build__init_part0_A_Unit75__O(); A_arbace_go_build__init_part0_A_Unit76__O(); A_arbace_go_build__init_part0_A_Unit77__O(); A_arbace_go_build__init_part0_A_Unit78__O(); A_arbace_go_build__init_part0_A_Unit79__O(); A_arbace_go_build__init_part0_A_Unit80__O(); A_arbace_go_build__init_part0_A_Unit81__O(); A_arbace_go_build__init_part0_A_Unit82__O(); A_arbace_go_build__init_part0_A_Unit83__O(); A_arbace_go_build__init_part0_A_Unit84__O(); A_arbace_go_build__init_part0_A_Unit85__O(); A_arbace_go_build__init_part0_A_Unit86__O(); A_arbace_go_build__init_part0_A_Unit87__O(); A_arbace_go_build__init_part0_A_Unit88__O(); A_arbace_go_build__init_part0_A_Unit89__O(); A_arbace_go_build__init_part0_A_Unit90__O(); A_arbace_go_build__init_part0_A_Unit91__O(); A_arbace_go_build__init_part0_A_Unit92__O(); A_arbace_go_build__init_part0_A_Unit93__O(); A_arbace_go_build__init_part0_A_Unit94__O(); A_arbace_go_build__init_part0_A_Unit95__O(); A_arbace_go_build__init_part0_A_Unit96__O(); A_arbace_go_build__init_part0_A_Unit97__O(); A_arbace_go_build__init_part0_A_Unit98__O(); A_arbace_go_build__init_part0_A_Unit99__O(); return nil }



func A_arbace_go_build__init_A_Load__O() any { jrt.StartCheck(); A_arbace_go_build__init_part0_A_Init__O(); A_arbace_go_build__init_part1_A_Init__O(); A_arbace_go_build__init_part0_A_Load__O(); A_arbace_go_build__init_part1_A_Load__O(); return nil }




















func A_arbace_go_build__init_part0_A_Unit4__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_4; var tmp2 any = A_arbace_go_build_op_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_build_op_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_409, true); A_arbace_go_build_op_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_5)); return A_arbace_go_build__init_part0_A_const_4 }




func A_arbace_go_build__init_part0_A_Unit5__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_6; var tmp2 any = A_arbace_go_build_oa_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_build_oa_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_410, false); A_arbace_go_build_oa_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_7)); return A_arbace_go_build__init_part0_A_const_6 }

func A_arbace_go_build__init_part0_A_Unit6__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_8; var tmp2 any = A_arbace_go_build_unsupported_BANG__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_build_unsupported_BANG__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_411, false); A_arbace_go_build_unsupported_BANG__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_9)); return A_arbace_go_build__init_part0_A_const_8 }






func A_arbace_go_build__init_part0_A_Unit7__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); A_arbace_go_build__init_part0_A_const_10.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_11)); return A_arbace_go_build__init_part0_A_const_10.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_build__init_part0_A_Unit8__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); A_arbace_go_build__init_part0_A_const_12.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_13)); return A_arbace_go_build__init_part0_A_const_12.SetDynamic_Z__Var(true).Ref() }






func A_arbace_go_build__init_part0_A_Unit9__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_14; var tmp2 any = A_arbace_go_build_compiled_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_build_compiled_QMARK__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_412, false); A_arbace_go_build_compiled_QMARK__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_15)); return A_arbace_go_build__init_part0_A_const_14 }



func A_arbace_go_build__init_part0_A_Unit10__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(57, 1); A_arbace_go_build__init_part0_A_const_16.BindRoot_O__V(A_arbace_go_build__init_part0_A_const_17); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_18)); return A_arbace_go_build__init_part0_A_const_16 }


func A_arbace_go_build__init_part0_A_Unit11__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_19; var tmp2 any = A_arbace_go_build_kind_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_build_kind_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_413, false); A_arbace_go_build_kind_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_20)); return A_arbace_go_build__init_part0_A_const_19 }











func A_arbace_go_build__init_part0_A_Unit12__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); A_arbace_go_build__init_part0_A_const_21.BindRoot_O__V(A_arbace_go_build__init_part0_A_const_22); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_21; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_23)); return A_arbace_go_build__init_part0_A_const_21 }



func A_arbace_go_build__init_part0_A_Unit13__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(76, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_24; var tmp2 any = A_arbace_go_build_basic_of_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_build_basic_of_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_414, false); A_arbace_go_build_basic_of_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_25)); return A_arbace_go_build__init_part0_A_const_24 }
func A_arbace_go_build__init_part0_A_Unit14__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(77, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_26; var tmp2 any = A_arbace_go_build_unsigned_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_build_unsigned_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_415, false); A_arbace_go_build_unsigned_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_27)); return A_arbace_go_build__init_part0_A_const_26 }
func A_arbace_go_build__init_part0_A_Unit15__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(78, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_28; var tmp2 any = A_arbace_go_build_wide_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_build_wide_QMARK__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_416, false); A_arbace_go_build_wide_QMARK__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_29)); return A_arbace_go_build__init_part0_A_const_28 }
func A_arbace_go_build__init_part0_A_Unit16__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(79, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_30; var tmp2 any = A_arbace_go_build_struct_or_array_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_build_struct_or_array_QMARK__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_417, false); A_arbace_go_build_struct_or_array_QMARK__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_31)); return A_arbace_go_build__init_part0_A_const_30 }
func A_arbace_go_build__init_part0_A_Unit17__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_32; var tmp2 any = A_arbace_go_build_iface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_go_build_iface_QMARK__A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_418, false); A_arbace_go_build_iface_QMARK__A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_33)); return A_arbace_go_build__init_part0_A_const_32 }

func A_arbace_go_build__init_part0_A_Unit18__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(82, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_34; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_35)); return A_arbace_go_build__init_part0_A_const_34 }

func A_arbace_go_build__init_part0_A_Unit19__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(84, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_36; var tmp2 any = A_arbace_go_build_interpreted_named_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_build_interpreted_named_QMARK__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_419, false); A_arbace_go_build_interpreted_named_QMARK__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_37)); return A_arbace_go_build__init_part0_A_const_36 }


func A_arbace_go_build__init_part0_A_Unit20__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(87, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_38; var tmp2 any = A_arbace_go_build_recursive_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_build_recursive_QMARK__A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_420, false); A_arbace_go_build_recursive_QMARK__A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_39)); return A_arbace_go_build__init_part0_A_const_38 }























func A_arbace_go_build__init_part0_A_Unit21__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(111, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_40; var tmp2 any = A_arbace_go_build_tag_text_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_build_tag_text_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_421, false); A_arbace_go_build_tag_text_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_41)); return A_arbace_go_build__init_part0_A_const_40 }

func A_arbace_go_build__init_part0_A_Unit22__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(113, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_42; var tmp2 any = A_arbace_go_build_struct_parts_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_build_struct_parts_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_422, false); A_arbace_go_build_struct_parts_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_43)); return A_arbace_go_build__init_part0_A_const_42 }








func A_arbace_go_build__init_part0_A_Unit23__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(122, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_44; var tmp2 any = A_arbace_go_build_named_desc_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_build_named_desc_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_423, false); A_arbace_go_build_named_desc_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_45)); return A_arbace_go_build__init_part0_A_const_44 }






























func A_arbace_go_build__init_part0_A_Unit24__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(153, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_34; var tmp2 any = A_arbace_go_build_desc_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_build_desc_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_424, false); A_arbace_go_build_desc_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_46)); return A_arbace_go_build__init_part0_A_const_34 }






























func A_arbace_go_build__init_part0_A_Unit25__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(184, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_47; var tmp2 any = A_arbace_go_build_int_bits_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_build_int_bits_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_425, false); A_arbace_go_build_int_bits_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_48)); return A_arbace_go_build__init_part0_A_const_47 }




func A_arbace_go_build__init_part0_A_Unit26__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(189, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_49; var tmp2 any = A_arbace_go_build_go_string_node_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_go_build_go_string_node_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_426, false); A_arbace_go_build_go_string_node_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_50)); return A_arbace_go_build__init_part0_A_const_49 }






func A_arbace_go_build__init_part0_A_Unit27__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(196, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_51; var tmp2 any = A_arbace_go_build_complex_value_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_build_complex_value_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_427, false); A_arbace_go_build_complex_value_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_52)); return A_arbace_go_build__init_part0_A_const_51 }






func A_arbace_go_build__init_part0_A_Unit28__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(203, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_53; var tmp2 any = A_arbace_go_build_const_node_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_go_build_const_node_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_428, false); A_arbace_go_build_const_node_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_54)); return A_arbace_go_build__init_part0_A_const_53 }














func A_arbace_go_build__init_part0_A_Unit29__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(218, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_55; var tmp2 any = A_arbace_go_build_new_slot_BANG__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_build_new_slot_BANG__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_429, false); A_arbace_go_build_new_slot_BANG__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_56)); return A_arbace_go_build__init_part0_A_const_55 }





func A_arbace_go_build__init_part0_A_Unit30__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(224, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_57; var tmp2 any = A_arbace_go_build_next_code_BANG__A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_go_build_next_code_BANG__A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_430, false); A_arbace_go_build_next_code_BANG__A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_58)); return A_arbace_go_build__init_part0_A_const_57 }


func A_arbace_go_build__init_part0_A_Unit31__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(227, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_59; var tmp2 any = A_arbace_go_build_label_code_BANG__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_build_label_code_BANG__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_431, false); A_arbace_go_build_label_code_BANG__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_60)); return A_arbace_go_build__init_part0_A_const_59 }






func A_arbace_go_build__init_part0_A_Unit32__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(234, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_61; var tmp2 any = A_arbace_go_build_label_entry_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_go_build_label_entry_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_432, false); A_arbace_go_build_label_entry_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_62)); return A_arbace_go_build__init_part0_A_const_61 }



func A_arbace_go_build__init_part0_A_Unit33__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(238, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_63; var tmp2 any = A_arbace_go_build_cell_var_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_build_cell_var_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_433, false); A_arbace_go_build_cell_var_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_64)); return A_arbace_go_build__init_part0_A_const_63 }




func A_arbace_go_build__init_part0_A_Unit34__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(243, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_65; var tmp2 any = A_arbace_go_build_loc_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_go_build_loc_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_434, false); A_arbace_go_build_loc_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_66)); return A_arbace_go_build__init_part0_A_const_65 }



func A_arbace_go_build__init_part0_A_Unit35__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(247, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_67; var tmp2 any = A_arbace_go_build_new_loc_BANG__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_build_new_loc_BANG__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_435, false); A_arbace_go_build_new_loc_BANG__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_68)); return A_arbace_go_build__init_part0_A_const_67 }






func A_arbace_go_build__init_part0_A_Unit36__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(254, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_69; var tmp2 any = A_arbace_go_build_temp_BANG__A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_build_temp_BANG__A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_436, false); A_arbace_go_build_temp_BANG__A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_70)); return A_arbace_go_build__init_part0_A_const_69 }



func A_arbace_go_build__init_part0_A_Unit37__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(258, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_71; var tmp2 any = A_arbace_go_build_local_node_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_build_local_node_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_437, false); A_arbace_go_build_local_node_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_72)); return A_arbace_go_build__init_part0_A_const_71 }

func A_arbace_go_build__init_part0_A_Unit38__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(260, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_73; var tmp2 any = A_arbace_go_build_as_kind_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_go_build_as_kind_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_438, false); A_arbace_go_build_as_kind_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_74)); return A_arbace_go_build__init_part0_A_const_73 }








func A_arbace_go_build__init_part0_A_Unit39__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(269, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_75; var tmp2 any = A_arbace_go_build_load_p_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_build_load_p_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_439, false); A_arbace_go_build_load_p_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_76)); return A_arbace_go_build__init_part0_A_const_75 }










func A_arbace_go_build__init_part0_A_Unit40__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(280, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_77; var tmp2 any = A_arbace_go_build_store_p_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_go_build_store_p_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_440, false); A_arbace_go_build_store_p_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_78)); return A_arbace_go_build__init_part0_A_const_77 }











func A_arbace_go_build__init_part0_A_Unit41__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(292, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_79; var tmp2 any = A_arbace_go_build_set_slot_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_build_set_slot_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_441, false); A_arbace_go_build_set_slot_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_80)); return A_arbace_go_build__init_part0_A_const_79 }


func A_arbace_go_build__init_part0_A_Unit42__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(295, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_81; var tmp2 any = A_arbace_go_build_expr_stmt_of_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_go_build_expr_stmt_of_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_442, false); A_arbace_go_build_expr_stmt_of_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_82)); return A_arbace_go_build__init_part0_A_const_81 }


func A_arbace_go_build__init_part0_A_Unit43__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_83; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_84)); return A_arbace_go_build__init_part0_A_const_83 }
//line :298:1
func A_arbace_go_build__init_part0_A_Unit44__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_85; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_86)); return A_arbace_go_build__init_part0_A_const_85 }
//line :298:1
func A_arbace_go_build__init_part0_A_Unit45__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_87; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_88)); return A_arbace_go_build__init_part0_A_const_87 }
//line :298:1
func A_arbace_go_build__init_part0_A_Unit46__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_89; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_90)); return A_arbace_go_build__init_part0_A_const_89 }
//line :298:1
func A_arbace_go_build__init_part0_A_Unit47__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_91; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_92)); return A_arbace_go_build__init_part0_A_const_91 }
//line :298:1
func A_arbace_go_build__init_part0_A_Unit48__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_93; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_94)); return A_arbace_go_build__init_part0_A_const_93 }
//line :298:1
func A_arbace_go_build__init_part0_A_Unit49__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_95; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_96)); return A_arbace_go_build__init_part0_A_const_95 }
//line :298:1
func A_arbace_go_build__init_part0_A_Unit50__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_97; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_98)); return A_arbace_go_build__init_part0_A_const_97 }
//line :298:1
func A_arbace_go_build__init_part0_A_Unit51__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_99; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_100)); return A_arbace_go_build__init_part0_A_const_99 }
//line :298:1
func A_arbace_go_build__init_part0_A_Unit52__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_101; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_102)); return A_arbace_go_build__init_part0_A_const_101 }
//line :298:1
func A_arbace_go_build__init_part0_A_Unit53__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_103; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_104)); return A_arbace_go_build__init_part0_A_const_103 }
//line :298:1
func A_arbace_go_build__init_part0_A_Unit54__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_105; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_106)); return A_arbace_go_build__init_part0_A_const_105 }
//line :298:1
func A_arbace_go_build__init_part0_A_Unit55__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_107; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_108)); return A_arbace_go_build__init_part0_A_const_107 }

func A_arbace_go_build__init_part0_A_Unit56__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(300, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_109; var tmp2 any = A_arbace_go_build_exk_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_build_exk_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_443, false); A_arbace_go_build_exk_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_110)); return A_arbace_go_build__init_part0_A_const_109 }



func A_arbace_go_build__init_part0_A_Unit57__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(304, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_111; var tmp2 any = A_arbace_go_build_iface_content_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_go_build_iface_content_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_444, false); A_arbace_go_build_iface_content_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_112)); return A_arbace_go_build__init_part0_A_const_111 }














func A_arbace_go_build__init_part0_A_Unit58__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(319, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_113; var tmp2 any = A_arbace_go_build_arith_name_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_build_arith_name_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_445, false); A_arbace_go_build_arith_name_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_114)); return A_arbace_go_build__init_part0_A_const_113 }



func A_arbace_go_build__init_part0_A_Unit59__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(323, 1); A_arbace_go_build__init_part0_A_const_115.BindRoot_O__V(A_arbace_go_build__init_part0_A_const_116); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_115; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_117)); return A_arbace_go_build__init_part0_A_const_115 }

func A_arbace_go_build__init_part0_A_Unit60__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(325, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_118; var tmp2 any = A_arbace_go_build_const_of_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_go_build_const_of_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_446, false); A_arbace_go_build_const_of_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_119)); return A_arbace_go_build__init_part0_A_const_118 }




func A_arbace_go_build__init_part0_A_Unit61__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_120; var tmp2 any = A_arbace_go_build_local_slot_of_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_build_local_slot_of_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_447, false); A_arbace_go_build_local_slot_of_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_121)); return A_arbace_go_build__init_part0_A_const_120 }







func A_arbace_go_build__init_part0_A_Unit62__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(338, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_122; var tmp2 any = A_arbace_go_build_int_binop_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_go_build_int_binop_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_448, false); A_arbace_go_build_int_binop_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_123)); return A_arbace_go_build__init_part0_A_const_122 }













func A_arbace_go_build__init_part0_A_Unit63__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(352, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_124; var tmp2 any = A_arbace_go_build_float_binop_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_build_float_binop_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_449, false); A_arbace_go_build_float_binop_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_125)); return A_arbace_go_build__init_part0_A_const_124 }



func A_arbace_go_build__init_part0_A_Unit64__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(356, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_126; var tmp2 any = A_arbace_go_build_binop_nodes_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_build_binop_nodes_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_450, false); A_arbace_go_build_binop_nodes_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_127)); return A_arbace_go_build__init_part0_A_const_126 }












func A_arbace_go_build__init_part0_A_Unit65__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(369, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_128; var tmp2 any = A_arbace_go_build_count_node_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_build_count_node_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_451, false); A_arbace_go_build_count_node_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_129)); return A_arbace_go_build__init_part0_A_const_128 }









func A_arbace_go_build__init_part0_A_Unit66__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(379, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_130; var tmp2 any = A_arbace_go_build_shift_node_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_go_build_shift_node_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_452, false); A_arbace_go_build_shift_node_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_131)); return A_arbace_go_build__init_part0_A_const_130 }




func A_arbace_go_build__init_part0_A_Unit67__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(384, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_132; var tmp2 any = A_arbace_go_build_nil_node_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_build_nil_node_QMARK__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_453, false); A_arbace_go_build_nil_node_QMARK__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_133)); return A_arbace_go_build__init_part0_A_const_132 }

func A_arbace_go_build__init_part0_A_Unit68__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(386, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_134; var tmp2 any = A_arbace_go_build_compare_nodes_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_go_build_compare_nodes_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_454, false); A_arbace_go_build_compare_nodes_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_135)); return A_arbace_go_build__init_part0_A_const_134 }


























func A_arbace_go_build__init_part0_A_Unit69__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(413, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_136; var tmp2 any = A_arbace_go_build_binary_node_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_build_binary_node_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_455, false); A_arbace_go_build_binary_node_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_137)); return A_arbace_go_build__init_part0_A_const_136 }

















func A_arbace_go_build__init_part0_A_Unit70__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(431, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_138; var tmp2 any = A_arbace_go_build_unary_node_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_go_build_unary_node_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_456, false); A_arbace_go_build_unary_node_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_139)); return A_arbace_go_build__init_part0_A_const_138 }












func A_arbace_go_build__init_part0_A_Unit71__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(444, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_140; var tmp2 any = A_arbace_go_build_bytes_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_build_bytes_type_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_457, false); A_arbace_go_build_bytes_type_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_141)); return A_arbace_go_build__init_part0_A_const_140 }
func A_arbace_go_build__init_part0_A_Unit72__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(445, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_142; var tmp2 any = A_arbace_go_build_runes_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_go_build_runes_type_QMARK__A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_458, false); A_arbace_go_build_runes_type_QMARK__A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_143)); return A_arbace_go_build__init_part0_A_const_142 }

func A_arbace_go_build__init_part0_A_Unit73__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(447, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_144; var tmp2 any = A_arbace_go_build_conv_node_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_build_conv_node_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_459, false); A_arbace_go_build_conv_node_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_145)); return A_arbace_go_build__init_part0_A_const_144 }





































func A_arbace_go_build__init_part0_A_Unit74__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(485, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_146; var tmp2 any = A_arbace_go_build_addressable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_go_build_addressable_QMARK__A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_460, false); A_arbace_go_build_addressable_QMARK__A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_147)); return A_arbace_go_build__init_part0_A_const_146 }


func A_arbace_go_build__init_part0_A_Unit75__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(488, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_148; var tmp2 any = A_arbace_go_build_struct_of_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_build_struct_of_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_461, false); A_arbace_go_build_struct_of_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_149)); return A_arbace_go_build__init_part0_A_const_148 }




func A_arbace_go_build__init_part0_A_Unit76__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(493, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_150; var tmp2 any = A_arbace_go_build_value_place_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_go_build_value_place_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_462, false); A_arbace_go_build_value_place_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_151)); return A_arbace_go_build__init_part0_A_const_150 }







func A_arbace_go_build__init_part0_A_Unit77__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(501, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_152; var tmp2 any = A_arbace_go_build_field_place_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_build_field_place_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_463, false); A_arbace_go_build_field_place_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_153)); return A_arbace_go_build__init_part0_A_const_152 }


















func A_arbace_go_build__init_part0_A_Unit78__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_154; var tmp2 any = A_arbace_go_build_index_place_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_go_build_index_place_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_464, false); A_arbace_go_build_index_place_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_155)); return A_arbace_go_build__init_part0_A_const_154 }












func A_arbace_go_build__init_part0_A_Unit79__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(533, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_87; var tmp2 any = A_arbace_go_build_place_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_build_place_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_465, false); A_arbace_go_build_place_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_156)); return A_arbace_go_build__init_part0_A_const_87 }



















func A_arbace_go_build__init_part0_A_Unit80__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(553, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_157; var tmp2 any = A_arbace_go_build_elem_node_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_go_build_elem_node_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_466, false); A_arbace_go_build_elem_node_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_157; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_158)); return A_arbace_go_build__init_part0_A_const_157 }




func A_arbace_go_build__init_part0_A_Unit81__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(558, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_89; var tmp2 any = A_arbace_go_build_lit_place_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_build_lit_place_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_467, false); A_arbace_go_build_lit_place_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_159)); return A_arbace_go_build__init_part0_A_const_89 }



























func A_arbace_go_build__init_part0_A_Unit82__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(586, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_91; var tmp2 any = A_arbace_go_build_lit_node_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_go_build_lit_node_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_468, false); A_arbace_go_build_lit_node_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_160)); return A_arbace_go_build__init_part0_A_const_91 }














func A_arbace_go_build__init_part0_A_Unit83__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(601, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_161; var tmp2 any = A_arbace_go_build_var_node_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_build_var_node_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_469, false); A_arbace_go_build_var_node_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_162)); return A_arbace_go_build__init_part0_A_const_161 }





func A_arbace_go_build__init_part0_A_Unit84__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(607, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_163; var tmp2 any = A_arbace_go_build_global_node_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_go_build_global_node_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_470, false); A_arbace_go_build_global_node_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_164)); return A_arbace_go_build__init_part0_A_const_163 }


func A_arbace_go_build__init_part0_A_Unit85__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(610, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_165; var tmp2 any = A_arbace_go_build_func_value_node_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_go_build_func_value_node_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_471, false); A_arbace_go_build_func_value_node_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_166)); return A_arbace_go_build__init_part0_A_const_165 }




func A_arbace_go_build__init_part0_A_Unit86__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(615, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_83; var tmp2 any = A_arbace_go_build_ex_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_go_build_ex_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_472, false); A_arbace_go_build_ex_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_167)); return A_arbace_go_build__init_part0_A_const_83 }



























































func A_arbace_go_build__init_part0_A_Unit87__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(675, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_85; var tmp2 any = A_arbace_go_build_ex_as_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_build_ex_as_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_473, false); A_arbace_go_build_ex_as_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_168)); return A_arbace_go_build__init_part0_A_const_85 }



func A_arbace_go_build__init_part0_A_Unit88__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(679, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_169; var tmp2 any = A_arbace_go_build_slot_layout_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_go_build_slot_layout_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_474, false); A_arbace_go_build_slot_layout_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_170)); return A_arbace_go_build__init_part0_A_const_169 }









func A_arbace_go_build__init_part0_A_Unit89__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(689, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_171; var tmp2 any = A_arbace_go_build_arg_setter_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_go_build_arg_setter_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_475, false); A_arbace_go_build_arg_setter_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_172)); return A_arbace_go_build__init_part0_A_const_171 }


func A_arbace_go_build__init_part0_A_Unit90__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(692, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_173; var tmp2 any = A_arbace_go_build_mem_node_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_go_build_mem_node_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_476, false); A_arbace_go_build_mem_node_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_173; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_174)); return A_arbace_go_build__init_part0_A_const_173 }







func A_arbace_go_build__init_part0_A_Unit91__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(700, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_175; var tmp2 any = A_arbace_go_build_arg_nodes_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_go_build_arg_nodes_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_477, false); A_arbace_go_build_arg_nodes_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_175; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_176)); return A_arbace_go_build__init_part0_A_const_175 }

















func A_arbace_go_build__init_part0_A_Unit92__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(718, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_95; var tmp2 any = A_arbace_go_build_call_results_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_go_build_call_results_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_478, false); A_arbace_go_build_call_results_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_177)); return A_arbace_go_build__init_part0_A_const_95 }








func A_arbace_go_build__init_part0_A_Unit93__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(727, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_178; var tmp2 any = A_arbace_go_build_sig_of_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_go_build_sig_of_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_479, false); A_arbace_go_build_sig_of_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_178; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_179)); return A_arbace_go_build__init_part0_A_const_178 }

func A_arbace_go_build__init_part0_A_Unit94__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(729, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_180; var tmp2 any = A_arbace_go_build_static_call_A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_go_build_static_call_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_480, false); A_arbace_go_build_static_call_A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_180; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_181)); return A_arbace_go_build__init_part0_A_const_180 }












func A_arbace_go_build__init_part0_A_Unit95__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(742, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_182; var tmp2 any = A_arbace_go_build_value_call_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_go_build_value_call_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_481, false); A_arbace_go_build_value_call_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_182; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_183)); return A_arbace_go_build__init_part0_A_const_182 }













func A_arbace_go_build__init_part0_A_Unit96__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(756, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_184; var tmp2 any = A_arbace_go_build_from_mem_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_go_build_from_mem_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_482, false); A_arbace_go_build_from_mem_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_184; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_185)); return A_arbace_go_build__init_part0_A_const_184 }




func A_arbace_go_build__init_part0_A_Unit97__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(761, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_186; var tmp2 any = A_arbace_go_build_compiled_call_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_build_compiled_call_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_483, false); A_arbace_go_build_compiled_call_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_186; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_187)); return A_arbace_go_build__init_part0_A_const_186 }







func A_arbace_go_build__init_part0_A_Unit98__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(769, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_188; var tmp2 any = A_arbace_go_build_method_call_A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_go_build_method_call_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_484, false); A_arbace_go_build_method_call_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_188; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_189)); return A_arbace_go_build__init_part0_A_const_188 }


















func A_arbace_go_build__init_part0_A_Unit99__O() any { A_arbace_go_build__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(788, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part0_A_const_93; var tmp2 any = A_arbace_go_build_call_node_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_go_build_call_node_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_485, false); A_arbace_go_build_call_node_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part0_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part0_A_const_190)); return A_arbace_go_build__init_part0_A_const_93 }

















func A_arbace_go_build__init_part1_A_Unit100__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(806, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_0; var tmp2 any = A_arbace_go_build_call_stmt_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_build_call_stmt_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_487, false); A_arbace_go_build_call_stmt_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_1)); return A_arbace_go_build__init_part1_A_const_0 }
//line :806:1
func A_arbace_go_build__init_part1_A_Init__O() any { A_arbace_go_build__init_part1_A_Init(); return nil }
//line :806:1
func A_arbace_go_build__init_part1_A_Load__O() any { A_arbace_go_build__init_part1_A_Init(); A_arbace_go_build__init_part1_A_Unit100__O(); A_arbace_go_build__init_part1_A_Unit101__O(); A_arbace_go_build__init_part1_A_Unit102__O(); A_arbace_go_build__init_part1_A_Unit103__O(); A_arbace_go_build__init_part1_A_Unit104__O(); A_arbace_go_build__init_part1_A_Unit105__O(); A_arbace_go_build__init_part1_A_Unit106__O(); A_arbace_go_build__init_part1_A_Unit107__O(); A_arbace_go_build__init_part1_A_Unit108__O(); A_arbace_go_build__init_part1_A_Unit109__O(); A_arbace_go_build__init_part1_A_Unit110__O(); A_arbace_go_build__init_part1_A_Unit111__O(); A_arbace_go_build__init_part1_A_Unit112__O(); A_arbace_go_build__init_part1_A_Unit113__O(); A_arbace_go_build__init_part1_A_Unit114__O(); A_arbace_go_build__init_part1_A_Unit115__O(); A_arbace_go_build__init_part1_A_Unit116__O(); A_arbace_go_build__init_part1_A_Unit117__O(); A_arbace_go_build__init_part1_A_Unit118__O(); A_arbace_go_build__init_part1_A_Unit119__O(); A_arbace_go_build__init_part1_A_Unit120__O(); A_arbace_go_build__init_part1_A_Unit121__O(); A_arbace_go_build__init_part1_A_Unit122__O(); A_arbace_go_build__init_part1_A_Unit123__O(); A_arbace_go_build__init_part1_A_Unit124__O(); A_arbace_go_build__init_part1_A_Unit125__O(); A_arbace_go_build__init_part1_A_Unit126__O(); A_arbace_go_build__init_part1_A_Unit127__O(); A_arbace_go_build__init_part1_A_Unit128__O(); A_arbace_go_build__init_part1_A_Unit129__O(); A_arbace_go_build__init_part1_A_Unit130__O(); A_arbace_go_build__init_part1_A_Unit131__O(); A_arbace_go_build__init_part1_A_Unit132__O(); A_arbace_go_build__init_part1_A_Unit133__O(); A_arbace_go_build__init_part1_A_Unit134__O(); A_arbace_go_build__init_part1_A_Unit135__O(); A_arbace_go_build__init_part1_A_Unit136__O(); A_arbace_go_build__init_part1_A_Unit137__O(); A_arbace_go_build__init_part1_A_Unit138__O(); A_arbace_go_build__init_part1_A_Unit139__O(); A_arbace_go_build__init_part1_A_Unit140__O(); A_arbace_go_build__init_part1_A_Unit141__O(); return nil }











func A_arbace_go_build__init_part1_A_Unit101__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(818, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_2; var tmp2 any = A_arbace_go_build_elem_type_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_build_elem_type_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_488, false); A_arbace_go_build_elem_type_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_3)); return A_arbace_go_build__init_part1_A_const_2 }

func A_arbace_go_build__init_part1_A_Unit102__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(820, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_4; var tmp2 any = A_arbace_go_build_builtin_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_build_builtin_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_489, false); A_arbace_go_build_builtin_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_5)); return A_arbace_go_build__init_part1_A_const_4 }













































































func A_arbace_go_build__init_part1_A_Unit103__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(898, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_6; var tmp2 any = A_arbace_go_build_expr_or_stmt_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_build_expr_or_stmt_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_490, false); A_arbace_go_build_expr_or_stmt_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_7)); return A_arbace_go_build__init_part1_A_const_6 }



func A_arbace_go_build__init_part1_A_Unit104__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(902, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_8; var tmp2 any = A_arbace_go_build_slot_of_place_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_build_slot_of_place_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_491, false); A_arbace_go_build_slot_of_place_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_9)); return A_arbace_go_build__init_part1_A_const_8 }






func A_arbace_go_build__init_part1_A_Unit105__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(909, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_10; var tmp2 any = A_arbace_go_build_assign_to_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_build_assign_to_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_492, false); A_arbace_go_build_assign_to_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_11)); return A_arbace_go_build__init_part1_A_const_10 }











func A_arbace_go_build__init_part1_A_Unit106__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(921, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_12; var tmp2 any = A_arbace_go_build_temps_of_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_build_temps_of_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_493, false); A_arbace_go_build_temps_of_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_13)); return A_arbace_go_build__init_part1_A_const_12 }






func A_arbace_go_build__init_part1_A_Unit107__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(928, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_14; var tmp2 any = A_arbace_go_build_rhs_nodes_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_build_rhs_nodes_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_494, false); A_arbace_go_build_rhs_nodes_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_15)); return A_arbace_go_build__init_part1_A_const_14 }















func A_arbace_go_build__init_part1_A_Unit108__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(944, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_16; var tmp2 any = A_arbace_go_build_prepare_place_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_build_prepare_place_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_495, false); A_arbace_go_build_prepare_place_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_17)); return A_arbace_go_build__init_part1_A_const_16 }




































func A_arbace_go_build__init_part1_A_Unit109__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(981, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_18; var tmp2 any = A_arbace_go_build_assign_stmt_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_build_assign_stmt_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_496, false); A_arbace_go_build_assign_stmt_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_19)); return A_arbace_go_build__init_part1_A_const_18 }








func A_arbace_go_build__init_part1_A_Unit110__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(990, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_20; var tmp2 any = A_arbace_go_build_op_assign_stmt_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_build_op_assign_stmt_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_497, false); A_arbace_go_build_op_assign_stmt_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_21)); return A_arbace_go_build__init_part1_A_const_20 }





























func A_arbace_go_build__init_part1_A_Unit111__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1020, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_22; var tmp2 any = A_arbace_go_build_one_of_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_go_build_one_of_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_498, false); A_arbace_go_build_one_of_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_23)); return A_arbace_go_build__init_part1_A_const_22 }





func A_arbace_go_build__init_part1_A_Unit112__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1026, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_24; var tmp2 any = A_arbace_go_build_incdec_stmt_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_build_incdec_stmt_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_499, false); A_arbace_go_build_incdec_stmt_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_25)); return A_arbace_go_build__init_part1_A_const_24 }






func A_arbace_go_build__init_part1_A_Unit113__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1033, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_26; var tmp2 any = A_arbace_go_build_zero_init_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_build_zero_init_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_500, false); A_arbace_go_build_zero_init_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_27)); return A_arbace_go_build__init_part1_A_const_26 }










func A_arbace_go_build__init_part1_A_Unit114__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1044, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_28; var tmp2 any = A_arbace_go_build_init_var_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_build_init_var_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_501, false); A_arbace_go_build_init_var_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_29)); return A_arbace_go_build__init_part1_A_const_28 }








func A_arbace_go_build__init_part1_A_Unit115__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1053, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_30; var tmp2 any = A_arbace_go_build_decl_stmt_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_build_decl_stmt_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_502, false); A_arbace_go_build_decl_stmt_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_31)); return A_arbace_go_build__init_part1_A_const_30 }





















func A_arbace_go_build__init_part1_A_Unit116__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1075, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_32; var tmp2 any = A_arbace_go_build_jump_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_build_jump_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_503, false); A_arbace_go_build_jump_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_33)); return A_arbace_go_build__init_part1_A_const_32 }

func A_arbace_go_build__init_part1_A_Unit117__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1077, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_34; var tmp2 any = A_arbace_go_build_push_target_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_build_push_target_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_504, false); A_arbace_go_build_push_target_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_35)); return A_arbace_go_build__init_part1_A_const_34 }

func A_arbace_go_build__init_part1_A_Unit118__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1079, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_36; var tmp2 any = A_arbace_go_build_innermost_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_build_innermost_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_505, false); A_arbace_go_build_innermost_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_37)); return A_arbace_go_build__init_part1_A_const_36 }

func A_arbace_go_build__init_part1_A_Unit119__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1081, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_38; var tmp2 any = A_arbace_go_build_block_stmts_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_go_build_block_stmts_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_506, false); A_arbace_go_build_block_stmts_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_39)); return A_arbace_go_build__init_part1_A_const_38 }

func A_arbace_go_build__init_part1_A_Unit120__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1083, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_40; var tmp2 any = A_arbace_go_build_body_node_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_build_body_node_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_507, false); A_arbace_go_build_body_node_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_41)); return A_arbace_go_build__init_part1_A_const_40 }







func A_arbace_go_build__init_part1_A_Unit121__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1091, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_42; var tmp2 any = A_arbace_go_build_stmt_list_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_go_build_stmt_list_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_508, false); A_arbace_go_build_stmt_list_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_43)); return A_arbace_go_build__init_part1_A_const_42 }

func A_arbace_go_build__init_part1_A_Unit122__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1093, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_44; var tmp2 any = A_arbace_go_build_block_node_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_build_block_node_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_509, false); A_arbace_go_build_block_node_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_45)); return A_arbace_go_build__init_part1_A_const_44 }








func A_arbace_go_build__init_part1_A_Unit123__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1102, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_46; var tmp2 any = A_arbace_go_build_loop_target_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_go_build_loop_target_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_510, false); A_arbace_go_build_loop_target_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_47)); return A_arbace_go_build__init_part1_A_const_46 }






func A_arbace_go_build__init_part1_A_Unit124__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1109, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_48; var tmp2 any = A_arbace_go_build_per_iteration_cells_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_build_per_iteration_cells_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_511, false); A_arbace_go_build_per_iteration_cells_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_49)); return A_arbace_go_build__init_part1_A_const_48 }




func A_arbace_go_build__init_part1_A_Unit125__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1114, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_50; var tmp2 any = A_arbace_go_build_for_stmt_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_go_build_for_stmt_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_512, false); A_arbace_go_build_for_stmt_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_51)); return A_arbace_go_build__init_part1_A_const_50 }









func A_arbace_go_build__init_part1_A_Unit126__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1124, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_52; var tmp2 any = A_arbace_go_build_range_targets_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_build_range_targets_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_513, false); A_arbace_go_build_range_targets_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_53)); return A_arbace_go_build__init_part1_A_const_52 }






func A_arbace_go_build__init_part1_A_Unit127__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1131, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_54; var tmp2 any = A_arbace_go_build_idx_setter_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_go_build_idx_setter_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_514, false); A_arbace_go_build_idx_setter_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_55)); return A_arbace_go_build__init_part1_A_const_54 }










func A_arbace_go_build__init_part1_A_Unit128__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1142, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_56; var tmp2 any = A_arbace_go_build_at_setter_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_build_at_setter_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_515, false); A_arbace_go_build_at_setter_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_57)); return A_arbace_go_build__init_part1_A_const_56 }










func A_arbace_go_build__init_part1_A_Unit129__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1153, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_58; var tmp2 any = A_arbace_go_build_any_setter_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_build_any_setter_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_516, false); A_arbace_go_build_any_setter_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_59)); return A_arbace_go_build__init_part1_A_const_58 }










func A_arbace_go_build__init_part1_A_Unit130__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1164, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_60; var tmp2 any = A_arbace_go_build_has_call_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_build_has_call_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_517, false); A_arbace_go_build_has_call_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_61)); return A_arbace_go_build__init_part1_A_const_60 }










func A_arbace_go_build__init_part1_A_Unit131__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1175, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_62; var tmp2 any = A_arbace_go_build_range_stmt_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_go_build_range_stmt_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_518, false); A_arbace_go_build_range_stmt_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_63)); return A_arbace_go_build__init_part1_A_const_62 }


















































func A_arbace_go_build__init_part1_A_Unit132__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1226, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_64; var tmp2 any = A_arbace_go_build_switch_stmt_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_build_switch_stmt_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_519, false); A_arbace_go_build_switch_stmt_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_65)); return A_arbace_go_build__init_part1_A_const_64 }

























func A_arbace_go_build__init_part1_A_Unit133__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1252, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_66; var tmp2 any = A_arbace_go_build_return_stmt_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_go_build_return_stmt_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_520, false); A_arbace_go_build_return_stmt_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_67)); return A_arbace_go_build__init_part1_A_const_66 }















func A_arbace_go_build__init_part1_A_Unit134__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1268, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_68; var tmp2 any = A_arbace_go_build_defer_stmt_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_build_defer_stmt_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_521, false); A_arbace_go_build_defer_stmt_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_69)); return A_arbace_go_build__init_part1_A_const_68 }


































func A_arbace_go_build__init_part1_A_Unit135__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1303, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_70; var tmp2 any = A_arbace_go_build_stmt_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_go_build_stmt_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_522, false); A_arbace_go_build_stmt_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_71)); return A_arbace_go_build__init_part1_A_const_70 }









































func A_arbace_go_build__init_part1_A_Unit136__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1345, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_72; var tmp2 any = A_arbace_go_build_has_defer_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_build_has_defer_QMARK__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_523, false); A_arbace_go_build_has_defer_QMARK__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_73)); return A_arbace_go_build__init_part1_A_const_72 }












func A_arbace_go_build__init_part1_A_Unit137__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1358, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_74; var tmp2 any = A_arbace_go_build_free_locals_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_go_build_free_locals_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_524, false); A_arbace_go_build_free_locals_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_75)); return A_arbace_go_build__init_part1_A_const_74 }





























func A_arbace_go_build__init_part1_A_Unit138__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1388, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_76; var tmp2 any = A_arbace_go_build_build_code_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_build_build_code_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_525, false); A_arbace_go_build_build_code_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_77)); return A_arbace_go_build__init_part1_A_const_76 }








































func A_arbace_go_build__init_part1_A_Unit139__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1429, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_78; var tmp2 any = A_arbace_go_build_build_fn_lit_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_go_build_build_fn_lit_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_526, false); A_arbace_go_build_build_fn_lit_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_79)); return A_arbace_go_build__init_part1_A_const_78 }









func A_arbace_go_build__init_part1_A_Unit140__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1439, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_80; var tmp2 any = A_arbace_go_build_build_func_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_build_build_func_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_527, false); A_arbace_go_build_build_func_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_81)); return A_arbace_go_build__init_part1_A_const_80 }




func A_arbace_go_build__init_part1_A_Unit141__O() any { A_arbace_go_build__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1444, 1); var tmp1 *lang.Var = A_arbace_go_build__init_part1_A_const_82; var tmp2 any = A_arbace_go_build_build_inits_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_go_build_build_inits_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_528, false); A_arbace_go_build_build_inits_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_build__init_part1_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_build__init_part1_A_const_83)); return A_arbace_go_build__init_part1_A_const_82 }



type A_arbace_go_build__init_A struct{ jrt.Object }

func A_arbace_go_build__init_A_New() *A_arbace_go_build__init_A { t := &A_arbace_go_build__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_build__init_A) Ctor() {}

func (t *A_arbace_go_build__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_build__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_build__init_A_class }

func (t *A_arbace_go_build__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_build__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_build__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_build__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_build__init_A); return ok }

func A_arbace_go_build__init_A_Cast(x any) *A_arbace_go_build__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_build__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_build__init_A_class)) }; return v }



type A_arbace_go_build__init_part0_A struct{ jrt.Object }

var A_arbace_go_build__init_part0_A_const_pool *jrt.RefArray

var A_arbace_go_build__init_part0_A_const_0 *lang.Var

var A_arbace_go_build__init_part0_A_const_1 any

var A_arbace_go_build__init_part0_A_const_2 any

var A_arbace_go_build__init_part0_A_const_3 any

var A_arbace_go_build__init_part0_A_const_4 *lang.Var

var A_arbace_go_build__init_part0_A_const_5 any

var A_arbace_go_build__init_part0_A_const_6 *lang.Var

var A_arbace_go_build__init_part0_A_const_7 any

var A_arbace_go_build__init_part0_A_const_8 *lang.Var

var A_arbace_go_build__init_part0_A_const_9 any

var A_arbace_go_build__init_part0_A_const_10 *lang.Var

var A_arbace_go_build__init_part0_A_const_11 any

var A_arbace_go_build__init_part0_A_const_12 *lang.Var

var A_arbace_go_build__init_part0_A_const_13 any

var A_arbace_go_build__init_part0_A_const_14 *lang.Var

var A_arbace_go_build__init_part0_A_const_15 any

var A_arbace_go_build__init_part0_A_const_16 *lang.Var

var A_arbace_go_build__init_part0_A_const_17 any

var A_arbace_go_build__init_part0_A_const_18 any

var A_arbace_go_build__init_part0_A_const_19 *lang.Var

var A_arbace_go_build__init_part0_A_const_20 any

var A_arbace_go_build__init_part0_A_const_21 *lang.Var

var A_arbace_go_build__init_part0_A_const_22 any

var A_arbace_go_build__init_part0_A_const_23 any

var A_arbace_go_build__init_part0_A_const_24 *lang.Var

var A_arbace_go_build__init_part0_A_const_25 any

var A_arbace_go_build__init_part0_A_const_26 *lang.Var

var A_arbace_go_build__init_part0_A_const_27 any

var A_arbace_go_build__init_part0_A_const_28 *lang.Var

var A_arbace_go_build__init_part0_A_const_29 any

var A_arbace_go_build__init_part0_A_const_30 *lang.Var

var A_arbace_go_build__init_part0_A_const_31 any

var A_arbace_go_build__init_part0_A_const_32 *lang.Var

var A_arbace_go_build__init_part0_A_const_33 any

var A_arbace_go_build__init_part0_A_const_34 *lang.Var

var A_arbace_go_build__init_part0_A_const_35 any

var A_arbace_go_build__init_part0_A_const_36 *lang.Var

var A_arbace_go_build__init_part0_A_const_37 any

var A_arbace_go_build__init_part0_A_const_38 *lang.Var

var A_arbace_go_build__init_part0_A_const_39 any

var A_arbace_go_build__init_part0_A_const_40 *lang.Var

var A_arbace_go_build__init_part0_A_const_41 any

var A_arbace_go_build__init_part0_A_const_42 *lang.Var

var A_arbace_go_build__init_part0_A_const_43 any

var A_arbace_go_build__init_part0_A_const_44 *lang.Var

var A_arbace_go_build__init_part0_A_const_45 any

var A_arbace_go_build__init_part0_A_const_46 any

var A_arbace_go_build__init_part0_A_const_47 *lang.Var

var A_arbace_go_build__init_part0_A_const_48 any

var A_arbace_go_build__init_part0_A_const_49 *lang.Var

var A_arbace_go_build__init_part0_A_const_50 any

var A_arbace_go_build__init_part0_A_const_51 *lang.Var

var A_arbace_go_build__init_part0_A_const_52 any

var A_arbace_go_build__init_part0_A_const_53 *lang.Var

var A_arbace_go_build__init_part0_A_const_54 any

var A_arbace_go_build__init_part0_A_const_55 *lang.Var

var A_arbace_go_build__init_part0_A_const_56 any

var A_arbace_go_build__init_part0_A_const_57 *lang.Var

var A_arbace_go_build__init_part0_A_const_58 any

var A_arbace_go_build__init_part0_A_const_59 *lang.Var

var A_arbace_go_build__init_part0_A_const_60 any

var A_arbace_go_build__init_part0_A_const_61 *lang.Var

var A_arbace_go_build__init_part0_A_const_62 any

var A_arbace_go_build__init_part0_A_const_63 *lang.Var

var A_arbace_go_build__init_part0_A_const_64 any

var A_arbace_go_build__init_part0_A_const_65 *lang.Var

var A_arbace_go_build__init_part0_A_const_66 any

var A_arbace_go_build__init_part0_A_const_67 *lang.Var

var A_arbace_go_build__init_part0_A_const_68 any

var A_arbace_go_build__init_part0_A_const_69 *lang.Var

var A_arbace_go_build__init_part0_A_const_70 any

var A_arbace_go_build__init_part0_A_const_71 *lang.Var

var A_arbace_go_build__init_part0_A_const_72 any

var A_arbace_go_build__init_part0_A_const_73 *lang.Var

var A_arbace_go_build__init_part0_A_const_74 any

var A_arbace_go_build__init_part0_A_const_75 *lang.Var

var A_arbace_go_build__init_part0_A_const_76 any

var A_arbace_go_build__init_part0_A_const_77 *lang.Var

var A_arbace_go_build__init_part0_A_const_78 any

var A_arbace_go_build__init_part0_A_const_79 *lang.Var

var A_arbace_go_build__init_part0_A_const_80 any

var A_arbace_go_build__init_part0_A_const_81 *lang.Var

var A_arbace_go_build__init_part0_A_const_82 any

var A_arbace_go_build__init_part0_A_const_83 *lang.Var

var A_arbace_go_build__init_part0_A_const_84 any

var A_arbace_go_build__init_part0_A_const_85 *lang.Var

var A_arbace_go_build__init_part0_A_const_86 any

var A_arbace_go_build__init_part0_A_const_87 *lang.Var

var A_arbace_go_build__init_part0_A_const_88 any

var A_arbace_go_build__init_part0_A_const_89 *lang.Var

var A_arbace_go_build__init_part0_A_const_90 any

var A_arbace_go_build__init_part0_A_const_91 *lang.Var

var A_arbace_go_build__init_part0_A_const_92 any

var A_arbace_go_build__init_part0_A_const_93 *lang.Var

var A_arbace_go_build__init_part0_A_const_94 any

var A_arbace_go_build__init_part0_A_const_95 *lang.Var

var A_arbace_go_build__init_part0_A_const_96 any

var A_arbace_go_build__init_part0_A_const_97 *lang.Var

var A_arbace_go_build__init_part0_A_const_98 any

var A_arbace_go_build__init_part0_A_const_99 *lang.Var

var A_arbace_go_build__init_part0_A_const_100 any

var A_arbace_go_build__init_part0_A_const_101 *lang.Var

var A_arbace_go_build__init_part0_A_const_102 any

var A_arbace_go_build__init_part0_A_const_103 *lang.Var

var A_arbace_go_build__init_part0_A_const_104 any

var A_arbace_go_build__init_part0_A_const_105 *lang.Var

var A_arbace_go_build__init_part0_A_const_106 any

var A_arbace_go_build__init_part0_A_const_107 *lang.Var

var A_arbace_go_build__init_part0_A_const_108 any

var A_arbace_go_build__init_part0_A_const_109 *lang.Var

var A_arbace_go_build__init_part0_A_const_110 any

var A_arbace_go_build__init_part0_A_const_111 *lang.Var

var A_arbace_go_build__init_part0_A_const_112 any

var A_arbace_go_build__init_part0_A_const_113 *lang.Var

var A_arbace_go_build__init_part0_A_const_114 any

var A_arbace_go_build__init_part0_A_const_115 *lang.Var

var A_arbace_go_build__init_part0_A_const_116 any

var A_arbace_go_build__init_part0_A_const_117 any

var A_arbace_go_build__init_part0_A_const_118 *lang.Var

var A_arbace_go_build__init_part0_A_const_119 any

var A_arbace_go_build__init_part0_A_const_120 *lang.Var

var A_arbace_go_build__init_part0_A_const_121 any

var A_arbace_go_build__init_part0_A_const_122 *lang.Var

var A_arbace_go_build__init_part0_A_const_123 any

var A_arbace_go_build__init_part0_A_const_124 *lang.Var

var A_arbace_go_build__init_part0_A_const_125 any

var A_arbace_go_build__init_part0_A_const_126 *lang.Var

var A_arbace_go_build__init_part0_A_const_127 any

var A_arbace_go_build__init_part0_A_const_128 *lang.Var

var A_arbace_go_build__init_part0_A_const_129 any

var A_arbace_go_build__init_part0_A_const_130 *lang.Var

var A_arbace_go_build__init_part0_A_const_131 any

var A_arbace_go_build__init_part0_A_const_132 *lang.Var

var A_arbace_go_build__init_part0_A_const_133 any

var A_arbace_go_build__init_part0_A_const_134 *lang.Var

var A_arbace_go_build__init_part0_A_const_135 any

var A_arbace_go_build__init_part0_A_const_136 *lang.Var

var A_arbace_go_build__init_part0_A_const_137 any

var A_arbace_go_build__init_part0_A_const_138 *lang.Var

var A_arbace_go_build__init_part0_A_const_139 any

var A_arbace_go_build__init_part0_A_const_140 *lang.Var

var A_arbace_go_build__init_part0_A_const_141 any

var A_arbace_go_build__init_part0_A_const_142 *lang.Var

var A_arbace_go_build__init_part0_A_const_143 any

var A_arbace_go_build__init_part0_A_const_144 *lang.Var

var A_arbace_go_build__init_part0_A_const_145 any

var A_arbace_go_build__init_part0_A_const_146 *lang.Var

var A_arbace_go_build__init_part0_A_const_147 any

var A_arbace_go_build__init_part0_A_const_148 *lang.Var

var A_arbace_go_build__init_part0_A_const_149 any

var A_arbace_go_build__init_part0_A_const_150 *lang.Var

var A_arbace_go_build__init_part0_A_const_151 any

var A_arbace_go_build__init_part0_A_const_152 *lang.Var

var A_arbace_go_build__init_part0_A_const_153 any

var A_arbace_go_build__init_part0_A_const_154 *lang.Var

var A_arbace_go_build__init_part0_A_const_155 any

var A_arbace_go_build__init_part0_A_const_156 any

var A_arbace_go_build__init_part0_A_const_157 *lang.Var

var A_arbace_go_build__init_part0_A_const_158 any

var A_arbace_go_build__init_part0_A_const_159 any

var A_arbace_go_build__init_part0_A_const_160 any

var A_arbace_go_build__init_part0_A_const_161 *lang.Var

var A_arbace_go_build__init_part0_A_const_162 any

var A_arbace_go_build__init_part0_A_const_163 *lang.Var

var A_arbace_go_build__init_part0_A_const_164 any

var A_arbace_go_build__init_part0_A_const_165 *lang.Var

var A_arbace_go_build__init_part0_A_const_166 any

var A_arbace_go_build__init_part0_A_const_167 any

var A_arbace_go_build__init_part0_A_const_168 any

var A_arbace_go_build__init_part0_A_const_169 *lang.Var

var A_arbace_go_build__init_part0_A_const_170 any

var A_arbace_go_build__init_part0_A_const_171 *lang.Var

var A_arbace_go_build__init_part0_A_const_172 any

var A_arbace_go_build__init_part0_A_const_173 *lang.Var

var A_arbace_go_build__init_part0_A_const_174 any

var A_arbace_go_build__init_part0_A_const_175 *lang.Var

var A_arbace_go_build__init_part0_A_const_176 any

var A_arbace_go_build__init_part0_A_const_177 any

var A_arbace_go_build__init_part0_A_const_178 *lang.Var

var A_arbace_go_build__init_part0_A_const_179 any

var A_arbace_go_build__init_part0_A_const_180 *lang.Var

var A_arbace_go_build__init_part0_A_const_181 any

var A_arbace_go_build__init_part0_A_const_182 *lang.Var

var A_arbace_go_build__init_part0_A_const_183 any

var A_arbace_go_build__init_part0_A_const_184 *lang.Var

var A_arbace_go_build__init_part0_A_const_185 any

var A_arbace_go_build__init_part0_A_const_186 *lang.Var

var A_arbace_go_build__init_part0_A_const_187 any

var A_arbace_go_build__init_part0_A_const_188 *lang.Var

var A_arbace_go_build__init_part0_A_const_189 any

var A_arbace_go_build__init_part0_A_const_190 any

var A_arbace_go_build__init_part0_A_init jrt.ClassInit

func A_arbace_go_build__init_part0_A_Init() { if !A_arbace_go_build__init_part0_A_init.Done() { A_arbace_go_build__init_part0_A_init.Run(A_arbace_go_build__init_part0_A_clinit) } }

func A_arbace_go_build__init_part0_A_clinit() { A_arbace_go_build__init_part0_A_clinit_p0(); A_arbace_go_build__init_part0_A_clinit_p1(); A_arbace_go_build__init_part0_A_clinit_p2(); A_arbace_go_build__init_part0_A_clinit_p3(); A_arbace_go_build__init_part0_A_clinit_p4(); A_arbace_go_build__init_part0_A_clinit_p5(); A_arbace_go_build__init_part0_A_clinit_p6(); A_arbace_go_build__init_part0_A_clinit_p7(); A_arbace_go_build__init_part0_A_clinit_p8(); A_arbace_go_build__init_part0_A_clinit_p9(); A_arbace_go_build__init_part0_A_clinit_p10(); A_arbace_go_build__init_part0_A_clinit_p11(); A_arbace_go_build__init_part0_A_clinit_p12(); A_arbace_go_build__init_part0_A_clinit_p13(); A_arbace_go_build__init_part0_A_clinit_p14() }

func A_arbace_go_build__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_build__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_406, 254); A_arbace_go_build__init_part0_A_const_0 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[63]); A_arbace_go_build__init_part0_A_const_1 = A_arbace_go_build__init_part0_A_const_pool.A[64]; A_arbace_go_build__init_part0_A_const_2 = A_arbace_go_build__init_part0_A_const_pool.A[65]; A_arbace_go_build__init_part0_A_const_3 = A_arbace_go_build__init_part0_A_const_pool.A[66]; A_arbace_go_build__init_part0_A_const_4 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[67]); A_arbace_go_build__init_part0_A_const_5 = A_arbace_go_build__init_part0_A_const_pool.A[68]; A_arbace_go_build__init_part0_A_const_6 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[69]); A_arbace_go_build__init_part0_A_const_7 = A_arbace_go_build__init_part0_A_const_pool.A[70]; A_arbace_go_build__init_part0_A_const_8 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[71]); A_arbace_go_build__init_part0_A_const_9 = A_arbace_go_build__init_part0_A_const_pool.A[72]; A_arbace_go_build__init_part0_A_const_10 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[73]); A_arbace_go_build__init_part0_A_const_11 = A_arbace_go_build__init_part0_A_const_pool.A[74]; A_arbace_go_build__init_part0_A_const_12 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[75]) }

func A_arbace_go_build__init_part0_A_clinit_p1() { A_arbace_go_build__init_part0_A_const_13 = A_arbace_go_build__init_part0_A_const_pool.A[76]; A_arbace_go_build__init_part0_A_const_14 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[77]); A_arbace_go_build__init_part0_A_const_15 = A_arbace_go_build__init_part0_A_const_pool.A[78]; A_arbace_go_build__init_part0_A_const_16 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[79]); A_arbace_go_build__init_part0_A_const_17 = A_arbace_go_build__init_part0_A_const_pool.A[80]; A_arbace_go_build__init_part0_A_const_18 = A_arbace_go_build__init_part0_A_const_pool.A[81]; A_arbace_go_build__init_part0_A_const_19 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[82]); A_arbace_go_build__init_part0_A_const_20 = A_arbace_go_build__init_part0_A_const_pool.A[83]; A_arbace_go_build__init_part0_A_const_21 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[84]); A_arbace_go_build__init_part0_A_const_22 = A_arbace_go_build__init_part0_A_const_pool.A[85]; A_arbace_go_build__init_part0_A_const_23 = A_arbace_go_build__init_part0_A_const_pool.A[86]; A_arbace_go_build__init_part0_A_const_24 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[87]); A_arbace_go_build__init_part0_A_const_25 = A_arbace_go_build__init_part0_A_const_pool.A[88]; A_arbace_go_build__init_part0_A_const_26 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[89]) }

func A_arbace_go_build__init_part0_A_clinit_p2() { A_arbace_go_build__init_part0_A_const_27 = A_arbace_go_build__init_part0_A_const_pool.A[90]; A_arbace_go_build__init_part0_A_const_28 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[91]); A_arbace_go_build__init_part0_A_const_29 = A_arbace_go_build__init_part0_A_const_pool.A[92]; A_arbace_go_build__init_part0_A_const_30 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[93]); A_arbace_go_build__init_part0_A_const_31 = A_arbace_go_build__init_part0_A_const_pool.A[94]; A_arbace_go_build__init_part0_A_const_32 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[95]); A_arbace_go_build__init_part0_A_const_33 = A_arbace_go_build__init_part0_A_const_pool.A[96]; A_arbace_go_build__init_part0_A_const_34 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[97]); A_arbace_go_build__init_part0_A_const_35 = A_arbace_go_build__init_part0_A_const_pool.A[98]; A_arbace_go_build__init_part0_A_const_36 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[99]); A_arbace_go_build__init_part0_A_const_37 = A_arbace_go_build__init_part0_A_const_pool.A[100]; A_arbace_go_build__init_part0_A_const_38 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[101]); A_arbace_go_build__init_part0_A_const_39 = A_arbace_go_build__init_part0_A_const_pool.A[102] }

func A_arbace_go_build__init_part0_A_clinit_p3() { A_arbace_go_build__init_part0_A_const_40 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[103]); A_arbace_go_build__init_part0_A_const_41 = A_arbace_go_build__init_part0_A_const_pool.A[104]; A_arbace_go_build__init_part0_A_const_42 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[105]); A_arbace_go_build__init_part0_A_const_43 = A_arbace_go_build__init_part0_A_const_pool.A[106]; A_arbace_go_build__init_part0_A_const_44 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[107]); A_arbace_go_build__init_part0_A_const_45 = A_arbace_go_build__init_part0_A_const_pool.A[108]; A_arbace_go_build__init_part0_A_const_46 = A_arbace_go_build__init_part0_A_const_pool.A[109]; A_arbace_go_build__init_part0_A_const_47 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[110]); A_arbace_go_build__init_part0_A_const_48 = A_arbace_go_build__init_part0_A_const_pool.A[111]; A_arbace_go_build__init_part0_A_const_49 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[112]); A_arbace_go_build__init_part0_A_const_50 = A_arbace_go_build__init_part0_A_const_pool.A[113]; A_arbace_go_build__init_part0_A_const_51 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[114]); A_arbace_go_build__init_part0_A_const_52 = A_arbace_go_build__init_part0_A_const_pool.A[115] }

func A_arbace_go_build__init_part0_A_clinit_p4() { A_arbace_go_build__init_part0_A_const_53 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[116]); A_arbace_go_build__init_part0_A_const_54 = A_arbace_go_build__init_part0_A_const_pool.A[117]; A_arbace_go_build__init_part0_A_const_55 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[118]); A_arbace_go_build__init_part0_A_const_56 = A_arbace_go_build__init_part0_A_const_pool.A[119]; A_arbace_go_build__init_part0_A_const_57 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[120]); A_arbace_go_build__init_part0_A_const_58 = A_arbace_go_build__init_part0_A_const_pool.A[121]; A_arbace_go_build__init_part0_A_const_59 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[122]); A_arbace_go_build__init_part0_A_const_60 = A_arbace_go_build__init_part0_A_const_pool.A[123]; A_arbace_go_build__init_part0_A_const_61 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[124]); A_arbace_go_build__init_part0_A_const_62 = A_arbace_go_build__init_part0_A_const_pool.A[125]; A_arbace_go_build__init_part0_A_const_63 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[126]); A_arbace_go_build__init_part0_A_const_64 = A_arbace_go_build__init_part0_A_const_pool.A[127]; A_arbace_go_build__init_part0_A_const_65 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[128]) }

func A_arbace_go_build__init_part0_A_clinit_p5() { A_arbace_go_build__init_part0_A_const_66 = A_arbace_go_build__init_part0_A_const_pool.A[129]; A_arbace_go_build__init_part0_A_const_67 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[130]); A_arbace_go_build__init_part0_A_const_68 = A_arbace_go_build__init_part0_A_const_pool.A[131]; A_arbace_go_build__init_part0_A_const_69 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[132]); A_arbace_go_build__init_part0_A_const_70 = A_arbace_go_build__init_part0_A_const_pool.A[133]; A_arbace_go_build__init_part0_A_const_71 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[134]); A_arbace_go_build__init_part0_A_const_72 = A_arbace_go_build__init_part0_A_const_pool.A[135]; A_arbace_go_build__init_part0_A_const_73 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[136]); A_arbace_go_build__init_part0_A_const_74 = A_arbace_go_build__init_part0_A_const_pool.A[137]; A_arbace_go_build__init_part0_A_const_75 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[138]); A_arbace_go_build__init_part0_A_const_76 = A_arbace_go_build__init_part0_A_const_pool.A[139]; A_arbace_go_build__init_part0_A_const_77 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[140]); A_arbace_go_build__init_part0_A_const_78 = A_arbace_go_build__init_part0_A_const_pool.A[141] }

func A_arbace_go_build__init_part0_A_clinit_p6() { A_arbace_go_build__init_part0_A_const_79 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[142]); A_arbace_go_build__init_part0_A_const_80 = A_arbace_go_build__init_part0_A_const_pool.A[143]; A_arbace_go_build__init_part0_A_const_81 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[144]); A_arbace_go_build__init_part0_A_const_82 = A_arbace_go_build__init_part0_A_const_pool.A[145]; A_arbace_go_build__init_part0_A_const_83 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[146]); A_arbace_go_build__init_part0_A_const_84 = A_arbace_go_build__init_part0_A_const_pool.A[147]; A_arbace_go_build__init_part0_A_const_85 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[148]); A_arbace_go_build__init_part0_A_const_86 = A_arbace_go_build__init_part0_A_const_pool.A[149]; A_arbace_go_build__init_part0_A_const_87 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[150]); A_arbace_go_build__init_part0_A_const_88 = A_arbace_go_build__init_part0_A_const_pool.A[151]; A_arbace_go_build__init_part0_A_const_89 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[152]); A_arbace_go_build__init_part0_A_const_90 = A_arbace_go_build__init_part0_A_const_pool.A[153]; A_arbace_go_build__init_part0_A_const_91 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[154]) }

func A_arbace_go_build__init_part0_A_clinit_p7() { A_arbace_go_build__init_part0_A_const_92 = A_arbace_go_build__init_part0_A_const_pool.A[155]; A_arbace_go_build__init_part0_A_const_93 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[156]); A_arbace_go_build__init_part0_A_const_94 = A_arbace_go_build__init_part0_A_const_pool.A[157]; A_arbace_go_build__init_part0_A_const_95 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[158]); A_arbace_go_build__init_part0_A_const_96 = A_arbace_go_build__init_part0_A_const_pool.A[159]; A_arbace_go_build__init_part0_A_const_97 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[160]); A_arbace_go_build__init_part0_A_const_98 = A_arbace_go_build__init_part0_A_const_pool.A[161]; A_arbace_go_build__init_part0_A_const_99 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[162]); A_arbace_go_build__init_part0_A_const_100 = A_arbace_go_build__init_part0_A_const_pool.A[163]; A_arbace_go_build__init_part0_A_const_101 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[164]); A_arbace_go_build__init_part0_A_const_102 = A_arbace_go_build__init_part0_A_const_pool.A[165]; A_arbace_go_build__init_part0_A_const_103 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[166]); A_arbace_go_build__init_part0_A_const_104 = A_arbace_go_build__init_part0_A_const_pool.A[167] }

func A_arbace_go_build__init_part0_A_clinit_p8() { A_arbace_go_build__init_part0_A_const_105 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[168]); A_arbace_go_build__init_part0_A_const_106 = A_arbace_go_build__init_part0_A_const_pool.A[169]; A_arbace_go_build__init_part0_A_const_107 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[170]); A_arbace_go_build__init_part0_A_const_108 = A_arbace_go_build__init_part0_A_const_pool.A[171]; A_arbace_go_build__init_part0_A_const_109 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[172]); A_arbace_go_build__init_part0_A_const_110 = A_arbace_go_build__init_part0_A_const_pool.A[173]; A_arbace_go_build__init_part0_A_const_111 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[174]); A_arbace_go_build__init_part0_A_const_112 = A_arbace_go_build__init_part0_A_const_pool.A[175]; A_arbace_go_build__init_part0_A_const_113 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[176]); A_arbace_go_build__init_part0_A_const_114 = A_arbace_go_build__init_part0_A_const_pool.A[177]; A_arbace_go_build__init_part0_A_const_115 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[178]); A_arbace_go_build__init_part0_A_const_116 = A_arbace_go_build__init_part0_A_const_pool.A[179]; A_arbace_go_build__init_part0_A_const_117 = A_arbace_go_build__init_part0_A_const_pool.A[180] }

func A_arbace_go_build__init_part0_A_clinit_p9() { A_arbace_go_build__init_part0_A_const_118 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[181]); A_arbace_go_build__init_part0_A_const_119 = A_arbace_go_build__init_part0_A_const_pool.A[182]; A_arbace_go_build__init_part0_A_const_120 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[183]); A_arbace_go_build__init_part0_A_const_121 = A_arbace_go_build__init_part0_A_const_pool.A[184]; A_arbace_go_build__init_part0_A_const_122 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[185]); A_arbace_go_build__init_part0_A_const_123 = A_arbace_go_build__init_part0_A_const_pool.A[186]; A_arbace_go_build__init_part0_A_const_124 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[187]); A_arbace_go_build__init_part0_A_const_125 = A_arbace_go_build__init_part0_A_const_pool.A[188]; A_arbace_go_build__init_part0_A_const_126 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[189]); A_arbace_go_build__init_part0_A_const_127 = A_arbace_go_build__init_part0_A_const_pool.A[190]; A_arbace_go_build__init_part0_A_const_128 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[191]); A_arbace_go_build__init_part0_A_const_129 = A_arbace_go_build__init_part0_A_const_pool.A[192]; A_arbace_go_build__init_part0_A_const_130 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[193]) }

func A_arbace_go_build__init_part0_A_clinit_p10() { A_arbace_go_build__init_part0_A_const_131 = A_arbace_go_build__init_part0_A_const_pool.A[194]; A_arbace_go_build__init_part0_A_const_132 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[195]); A_arbace_go_build__init_part0_A_const_133 = A_arbace_go_build__init_part0_A_const_pool.A[196]; A_arbace_go_build__init_part0_A_const_134 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[197]); A_arbace_go_build__init_part0_A_const_135 = A_arbace_go_build__init_part0_A_const_pool.A[198]; A_arbace_go_build__init_part0_A_const_136 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[199]); A_arbace_go_build__init_part0_A_const_137 = A_arbace_go_build__init_part0_A_const_pool.A[200]; A_arbace_go_build__init_part0_A_const_138 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[201]); A_arbace_go_build__init_part0_A_const_139 = A_arbace_go_build__init_part0_A_const_pool.A[202]; A_arbace_go_build__init_part0_A_const_140 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[203]); A_arbace_go_build__init_part0_A_const_141 = A_arbace_go_build__init_part0_A_const_pool.A[204]; A_arbace_go_build__init_part0_A_const_142 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[205]); A_arbace_go_build__init_part0_A_const_143 = A_arbace_go_build__init_part0_A_const_pool.A[206] }

func A_arbace_go_build__init_part0_A_clinit_p11() { A_arbace_go_build__init_part0_A_const_144 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[207]); A_arbace_go_build__init_part0_A_const_145 = A_arbace_go_build__init_part0_A_const_pool.A[208]; A_arbace_go_build__init_part0_A_const_146 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[209]); A_arbace_go_build__init_part0_A_const_147 = A_arbace_go_build__init_part0_A_const_pool.A[210]; A_arbace_go_build__init_part0_A_const_148 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[211]); A_arbace_go_build__init_part0_A_const_149 = A_arbace_go_build__init_part0_A_const_pool.A[212]; A_arbace_go_build__init_part0_A_const_150 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[213]); A_arbace_go_build__init_part0_A_const_151 = A_arbace_go_build__init_part0_A_const_pool.A[214]; A_arbace_go_build__init_part0_A_const_152 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[215]); A_arbace_go_build__init_part0_A_const_153 = A_arbace_go_build__init_part0_A_const_pool.A[216]; A_arbace_go_build__init_part0_A_const_154 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[217]); A_arbace_go_build__init_part0_A_const_155 = A_arbace_go_build__init_part0_A_const_pool.A[218]; A_arbace_go_build__init_part0_A_const_156 = A_arbace_go_build__init_part0_A_const_pool.A[219] }

func A_arbace_go_build__init_part0_A_clinit_p12() { A_arbace_go_build__init_part0_A_const_157 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[220]); A_arbace_go_build__init_part0_A_const_158 = A_arbace_go_build__init_part0_A_const_pool.A[221]; A_arbace_go_build__init_part0_A_const_159 = A_arbace_go_build__init_part0_A_const_pool.A[222]; A_arbace_go_build__init_part0_A_const_160 = A_arbace_go_build__init_part0_A_const_pool.A[223]; A_arbace_go_build__init_part0_A_const_161 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[224]); A_arbace_go_build__init_part0_A_const_162 = A_arbace_go_build__init_part0_A_const_pool.A[225]; A_arbace_go_build__init_part0_A_const_163 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[226]); A_arbace_go_build__init_part0_A_const_164 = A_arbace_go_build__init_part0_A_const_pool.A[227]; A_arbace_go_build__init_part0_A_const_165 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[228]); A_arbace_go_build__init_part0_A_const_166 = A_arbace_go_build__init_part0_A_const_pool.A[229]; A_arbace_go_build__init_part0_A_const_167 = A_arbace_go_build__init_part0_A_const_pool.A[230]; A_arbace_go_build__init_part0_A_const_168 = A_arbace_go_build__init_part0_A_const_pool.A[231]; A_arbace_go_build__init_part0_A_const_169 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[232]); A_arbace_go_build__init_part0_A_const_170 = A_arbace_go_build__init_part0_A_const_pool.A[233] }

func A_arbace_go_build__init_part0_A_clinit_p13() { A_arbace_go_build__init_part0_A_const_171 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[234]); A_arbace_go_build__init_part0_A_const_172 = A_arbace_go_build__init_part0_A_const_pool.A[235]; A_arbace_go_build__init_part0_A_const_173 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[236]); A_arbace_go_build__init_part0_A_const_174 = A_arbace_go_build__init_part0_A_const_pool.A[237]; A_arbace_go_build__init_part0_A_const_175 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[238]); A_arbace_go_build__init_part0_A_const_176 = A_arbace_go_build__init_part0_A_const_pool.A[239]; A_arbace_go_build__init_part0_A_const_177 = A_arbace_go_build__init_part0_A_const_pool.A[240]; A_arbace_go_build__init_part0_A_const_178 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[241]); A_arbace_go_build__init_part0_A_const_179 = A_arbace_go_build__init_part0_A_const_pool.A[242]; A_arbace_go_build__init_part0_A_const_180 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[243]); A_arbace_go_build__init_part0_A_const_181 = A_arbace_go_build__init_part0_A_const_pool.A[244]; A_arbace_go_build__init_part0_A_const_182 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[245]); A_arbace_go_build__init_part0_A_const_183 = A_arbace_go_build__init_part0_A_const_pool.A[246] }

func A_arbace_go_build__init_part0_A_clinit_p14() { A_arbace_go_build__init_part0_A_const_184 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[247]); A_arbace_go_build__init_part0_A_const_185 = A_arbace_go_build__init_part0_A_const_pool.A[248]; A_arbace_go_build__init_part0_A_const_186 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[249]); A_arbace_go_build__init_part0_A_const_187 = A_arbace_go_build__init_part0_A_const_pool.A[250]; A_arbace_go_build__init_part0_A_const_188 = lang.Var_Cast(A_arbace_go_build__init_part0_A_const_pool.A[251]); A_arbace_go_build__init_part0_A_const_189 = A_arbace_go_build__init_part0_A_const_pool.A[252]; A_arbace_go_build__init_part0_A_const_190 = A_arbace_go_build__init_part0_A_const_pool.A[253] }

func A_arbace_go_build__init_part0_A_New() *A_arbace_go_build__init_part0_A { A_arbace_go_build__init_part0_A_Init(); t := &A_arbace_go_build__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_go_build__init_part0_A) Ctor() {}

func (t *A_arbace_go_build__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_build__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_go_build__init_part0_A_class }

func (t *A_arbace_go_build__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_build__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_build__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_build__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_build__init_part0_A); return ok }

func A_arbace_go_build__init_part0_A_Cast(x any) *A_arbace_go_build__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_build__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_build__init_part0_A_class)) }; return v }



type A_arbace_go_build__init_part1_A struct{ jrt.Object }

var A_arbace_go_build__init_part1_A_const_pool *jrt.RefArray

var A_arbace_go_build__init_part1_A_const_0 *lang.Var

var A_arbace_go_build__init_part1_A_const_1 any

var A_arbace_go_build__init_part1_A_const_2 *lang.Var

var A_arbace_go_build__init_part1_A_const_3 any

var A_arbace_go_build__init_part1_A_const_4 *lang.Var

var A_arbace_go_build__init_part1_A_const_5 any

var A_arbace_go_build__init_part1_A_const_6 *lang.Var

var A_arbace_go_build__init_part1_A_const_7 any

var A_arbace_go_build__init_part1_A_const_8 *lang.Var

var A_arbace_go_build__init_part1_A_const_9 any

var A_arbace_go_build__init_part1_A_const_10 *lang.Var

var A_arbace_go_build__init_part1_A_const_11 any

var A_arbace_go_build__init_part1_A_const_12 *lang.Var

var A_arbace_go_build__init_part1_A_const_13 any

var A_arbace_go_build__init_part1_A_const_14 *lang.Var

var A_arbace_go_build__init_part1_A_const_15 any

var A_arbace_go_build__init_part1_A_const_16 *lang.Var

var A_arbace_go_build__init_part1_A_const_17 any

var A_arbace_go_build__init_part1_A_const_18 *lang.Var

var A_arbace_go_build__init_part1_A_const_19 any

var A_arbace_go_build__init_part1_A_const_20 *lang.Var

var A_arbace_go_build__init_part1_A_const_21 any

var A_arbace_go_build__init_part1_A_const_22 *lang.Var

var A_arbace_go_build__init_part1_A_const_23 any

var A_arbace_go_build__init_part1_A_const_24 *lang.Var

var A_arbace_go_build__init_part1_A_const_25 any

var A_arbace_go_build__init_part1_A_const_26 *lang.Var

var A_arbace_go_build__init_part1_A_const_27 any

var A_arbace_go_build__init_part1_A_const_28 *lang.Var

var A_arbace_go_build__init_part1_A_const_29 any

var A_arbace_go_build__init_part1_A_const_30 *lang.Var

var A_arbace_go_build__init_part1_A_const_31 any

var A_arbace_go_build__init_part1_A_const_32 *lang.Var

var A_arbace_go_build__init_part1_A_const_33 any

var A_arbace_go_build__init_part1_A_const_34 *lang.Var

var A_arbace_go_build__init_part1_A_const_35 any

var A_arbace_go_build__init_part1_A_const_36 *lang.Var

var A_arbace_go_build__init_part1_A_const_37 any

var A_arbace_go_build__init_part1_A_const_38 *lang.Var

var A_arbace_go_build__init_part1_A_const_39 any

var A_arbace_go_build__init_part1_A_const_40 *lang.Var

var A_arbace_go_build__init_part1_A_const_41 any

var A_arbace_go_build__init_part1_A_const_42 *lang.Var

var A_arbace_go_build__init_part1_A_const_43 any

var A_arbace_go_build__init_part1_A_const_44 *lang.Var

var A_arbace_go_build__init_part1_A_const_45 any

var A_arbace_go_build__init_part1_A_const_46 *lang.Var

var A_arbace_go_build__init_part1_A_const_47 any

var A_arbace_go_build__init_part1_A_const_48 *lang.Var

var A_arbace_go_build__init_part1_A_const_49 any

var A_arbace_go_build__init_part1_A_const_50 *lang.Var

var A_arbace_go_build__init_part1_A_const_51 any

var A_arbace_go_build__init_part1_A_const_52 *lang.Var

var A_arbace_go_build__init_part1_A_const_53 any

var A_arbace_go_build__init_part1_A_const_54 *lang.Var

var A_arbace_go_build__init_part1_A_const_55 any

var A_arbace_go_build__init_part1_A_const_56 *lang.Var

var A_arbace_go_build__init_part1_A_const_57 any

var A_arbace_go_build__init_part1_A_const_58 *lang.Var

var A_arbace_go_build__init_part1_A_const_59 any

var A_arbace_go_build__init_part1_A_const_60 *lang.Var

var A_arbace_go_build__init_part1_A_const_61 any

var A_arbace_go_build__init_part1_A_const_62 *lang.Var

var A_arbace_go_build__init_part1_A_const_63 any

var A_arbace_go_build__init_part1_A_const_64 *lang.Var

var A_arbace_go_build__init_part1_A_const_65 any

var A_arbace_go_build__init_part1_A_const_66 *lang.Var

var A_arbace_go_build__init_part1_A_const_67 any

var A_arbace_go_build__init_part1_A_const_68 *lang.Var

var A_arbace_go_build__init_part1_A_const_69 any

var A_arbace_go_build__init_part1_A_const_70 *lang.Var

var A_arbace_go_build__init_part1_A_const_71 any

var A_arbace_go_build__init_part1_A_const_72 *lang.Var

var A_arbace_go_build__init_part1_A_const_73 any

var A_arbace_go_build__init_part1_A_const_74 *lang.Var

var A_arbace_go_build__init_part1_A_const_75 any

var A_arbace_go_build__init_part1_A_const_76 *lang.Var

var A_arbace_go_build__init_part1_A_const_77 any

var A_arbace_go_build__init_part1_A_const_78 *lang.Var

var A_arbace_go_build__init_part1_A_const_79 any

var A_arbace_go_build__init_part1_A_const_80 *lang.Var

var A_arbace_go_build__init_part1_A_const_81 any

var A_arbace_go_build__init_part1_A_const_82 *lang.Var

var A_arbace_go_build__init_part1_A_const_83 any

var A_arbace_go_build__init_part1_A_init jrt.ClassInit

func A_arbace_go_build__init_part1_A_Init() { if !A_arbace_go_build__init_part1_A_init.Done() { A_arbace_go_build__init_part1_A_init.Run(A_arbace_go_build__init_part1_A_clinit) } }

func A_arbace_go_build__init_part1_A_clinit() { A_arbace_go_build__init_part1_A_clinit_p0(); A_arbace_go_build__init_part1_A_clinit_p1() }

func A_arbace_go_build__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_build__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_486, 108); A_arbace_go_build__init_part1_A_const_0 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[30]); A_arbace_go_build__init_part1_A_const_1 = A_arbace_go_build__init_part1_A_const_pool.A[31]; A_arbace_go_build__init_part1_A_const_2 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[32]); A_arbace_go_build__init_part1_A_const_3 = A_arbace_go_build__init_part1_A_const_pool.A[33] }

func A_arbace_go_build__init_part1_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp1 = A_arbace_go_build__init_part0_A_const_99; A_arbace_go_build__init_part1_A_const_4 = tmp1; A_arbace_go_build__init_part1_A_const_5 = A_arbace_go_build__init_part1_A_const_pool.A[34]; var tmp2 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp2 = A_arbace_go_build__init_part0_A_const_101; A_arbace_go_build__init_part1_A_const_6 = tmp2; A_arbace_go_build__init_part1_A_const_7 = A_arbace_go_build__init_part1_A_const_pool.A[35]; A_arbace_go_build__init_part1_A_const_8 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[36]); A_arbace_go_build__init_part1_A_const_9 = A_arbace_go_build__init_part1_A_const_pool.A[37]; A_arbace_go_build__init_part1_A_const_10 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[38]); A_arbace_go_build__init_part1_A_const_11 = A_arbace_go_build__init_part1_A_const_pool.A[39]; A_arbace_go_build__init_part1_A_const_12 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[40]); A_arbace_go_build__init_part1_A_const_13 = A_arbace_go_build__init_part1_A_const_pool.A[41]; var tmp3 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp3 = A_arbace_go_build__init_part0_A_const_107; A_arbace_go_build__init_part1_A_const_14 = tmp3; A_arbace_go_build__init_part1_A_const_15 = A_arbace_go_build__init_part1_A_const_pool.A[42]; A_arbace_go_build__init_part1_A_const_16 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[43]); A_arbace_go_build__init_part1_A_const_17 = A_arbace_go_build__init_part1_A_const_pool.A[44]; A_arbace_go_build__init_part1_A_const_18 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[45]); A_arbace_go_build__init_part1_A_const_19 = A_arbace_go_build__init_part1_A_const_pool.A[46]; A_arbace_go_build__init_part1_A_const_20 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[47]); A_arbace_go_build__init_part1_A_const_21 = A_arbace_go_build__init_part1_A_const_pool.A[48]; A_arbace_go_build__init_part1_A_const_22 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[49]); A_arbace_go_build__init_part1_A_const_23 = A_arbace_go_build__init_part1_A_const_pool.A[50]; A_arbace_go_build__init_part1_A_const_24 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[51]); A_arbace_go_build__init_part1_A_const_25 = A_arbace_go_build__init_part1_A_const_pool.A[52]; A_arbace_go_build__init_part1_A_const_26 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[53]); A_arbace_go_build__init_part1_A_const_27 = A_arbace_go_build__init_part1_A_const_pool.A[54]; A_arbace_go_build__init_part1_A_const_28 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[55]); A_arbace_go_build__init_part1_A_const_29 = A_arbace_go_build__init_part1_A_const_pool.A[56]; A_arbace_go_build__init_part1_A_const_30 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[57]); A_arbace_go_build__init_part1_A_const_31 = A_arbace_go_build__init_part1_A_const_pool.A[58]; A_arbace_go_build__init_part1_A_const_32 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[59]); A_arbace_go_build__init_part1_A_const_33 = A_arbace_go_build__init_part1_A_const_pool.A[60]; A_arbace_go_build__init_part1_A_const_34 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[61]); A_arbace_go_build__init_part1_A_const_35 = A_arbace_go_build__init_part1_A_const_pool.A[62]; A_arbace_go_build__init_part1_A_const_36 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[63]); A_arbace_go_build__init_part1_A_const_37 = A_arbace_go_build__init_part1_A_const_pool.A[64]; A_arbace_go_build__init_part1_A_const_38 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[65]); A_arbace_go_build__init_part1_A_const_39 = A_arbace_go_build__init_part1_A_const_pool.A[66]; A_arbace_go_build__init_part1_A_const_40 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[67]); A_arbace_go_build__init_part1_A_const_41 = A_arbace_go_build__init_part1_A_const_pool.A[68]; var tmp4 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp4 = A_arbace_go_build__init_part0_A_const_105; A_arbace_go_build__init_part1_A_const_42 = tmp4; A_arbace_go_build__init_part1_A_const_43 = A_arbace_go_build__init_part1_A_const_pool.A[69]; A_arbace_go_build__init_part1_A_const_44 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[70]); A_arbace_go_build__init_part1_A_const_45 = A_arbace_go_build__init_part1_A_const_pool.A[71]; A_arbace_go_build__init_part1_A_const_46 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[72]); A_arbace_go_build__init_part1_A_const_47 = A_arbace_go_build__init_part1_A_const_pool.A[73]; A_arbace_go_build__init_part1_A_const_48 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[74]); A_arbace_go_build__init_part1_A_const_49 = A_arbace_go_build__init_part1_A_const_pool.A[75]; A_arbace_go_build__init_part1_A_const_50 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[76]); A_arbace_go_build__init_part1_A_const_51 = A_arbace_go_build__init_part1_A_const_pool.A[77]; A_arbace_go_build__init_part1_A_const_52 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[78]); A_arbace_go_build__init_part1_A_const_53 = A_arbace_go_build__init_part1_A_const_pool.A[79]; A_arbace_go_build__init_part1_A_const_54 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[80]); A_arbace_go_build__init_part1_A_const_55 = A_arbace_go_build__init_part1_A_const_pool.A[81]; A_arbace_go_build__init_part1_A_const_56 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[82]); A_arbace_go_build__init_part1_A_const_57 = A_arbace_go_build__init_part1_A_const_pool.A[83]; A_arbace_go_build__init_part1_A_const_58 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[84]); A_arbace_go_build__init_part1_A_const_59 = A_arbace_go_build__init_part1_A_const_pool.A[85]; A_arbace_go_build__init_part1_A_const_60 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[86]); A_arbace_go_build__init_part1_A_const_61 = A_arbace_go_build__init_part1_A_const_pool.A[87]; A_arbace_go_build__init_part1_A_const_62 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[88]); A_arbace_go_build__init_part1_A_const_63 = A_arbace_go_build__init_part1_A_const_pool.A[89]; A_arbace_go_build__init_part1_A_const_64 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[90]); A_arbace_go_build__init_part1_A_const_65 = A_arbace_go_build__init_part1_A_const_pool.A[91]; A_arbace_go_build__init_part1_A_const_66 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[92]); A_arbace_go_build__init_part1_A_const_67 = A_arbace_go_build__init_part1_A_const_pool.A[93]; A_arbace_go_build__init_part1_A_const_68 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[94]); A_arbace_go_build__init_part1_A_const_69 = A_arbace_go_build__init_part1_A_const_pool.A[95]; var tmp5 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp5 = A_arbace_go_build__init_part0_A_const_103; A_arbace_go_build__init_part1_A_const_70 = tmp5; A_arbace_go_build__init_part1_A_const_71 = A_arbace_go_build__init_part1_A_const_pool.A[96]; A_arbace_go_build__init_part1_A_const_72 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[97]); A_arbace_go_build__init_part1_A_const_73 = A_arbace_go_build__init_part1_A_const_pool.A[98]; A_arbace_go_build__init_part1_A_const_74 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[99]); A_arbace_go_build__init_part1_A_const_75 = A_arbace_go_build__init_part1_A_const_pool.A[100]; A_arbace_go_build__init_part1_A_const_76 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[101]); A_arbace_go_build__init_part1_A_const_77 = A_arbace_go_build__init_part1_A_const_pool.A[102]; var tmp6 *lang.Var; A_arbace_go_build__init_part0_A_Init(); tmp6 = A_arbace_go_build__init_part0_A_const_97; A_arbace_go_build__init_part1_A_const_78 = tmp6; A_arbace_go_build__init_part1_A_const_79 = A_arbace_go_build__init_part1_A_const_pool.A[103]; A_arbace_go_build__init_part1_A_const_80 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[104]); A_arbace_go_build__init_part1_A_const_81 = A_arbace_go_build__init_part1_A_const_pool.A[105]; A_arbace_go_build__init_part1_A_const_82 = lang.Var_Cast(A_arbace_go_build__init_part1_A_const_pool.A[106]); A_arbace_go_build__init_part1_A_const_83 = A_arbace_go_build__init_part1_A_const_pool.A[107] }

func A_arbace_go_build__init_part1_A_New() *A_arbace_go_build__init_part1_A { A_arbace_go_build__init_part1_A_Init(); t := &A_arbace_go_build__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_go_build__init_part1_A) Ctor() {}

func (t *A_arbace_go_build__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_build__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_go_build__init_part1_A_class }

func (t *A_arbace_go_build__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_build__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_build__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_build__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_build__init_part1_A); return ok }

func A_arbace_go_build__init_part1_A_Cast(x any) *A_arbace_go_build__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_build__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_build__init_part1_A_class)) }; return v }
